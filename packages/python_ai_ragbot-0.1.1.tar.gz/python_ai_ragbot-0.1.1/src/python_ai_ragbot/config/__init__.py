from .defaults import DEFAULTS
from .validate import deep_merge, normalize_config