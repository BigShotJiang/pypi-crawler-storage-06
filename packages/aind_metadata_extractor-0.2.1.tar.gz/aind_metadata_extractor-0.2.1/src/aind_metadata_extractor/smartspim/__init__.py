"""Package for extracting SmartSPIM metadata inputs"""
