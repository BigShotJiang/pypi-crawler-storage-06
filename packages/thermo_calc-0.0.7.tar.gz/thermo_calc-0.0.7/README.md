# thermo-calc
Wrapper around Thermo-calc's TC-Python SDK
