"""Google Drive 网盘驱动模块"""

from .drive import GoogleDrive

__all__ = ["GoogleDrive"]
