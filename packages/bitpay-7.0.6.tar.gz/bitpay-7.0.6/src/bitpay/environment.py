from enum import Enum


class Environment(Enum):
    TEST = "Test"
    PROD = "Prod"
