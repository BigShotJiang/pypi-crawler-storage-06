from triplethreading._core import hello_from_bin


def hello() -> str:
    return hello_from_bin()
