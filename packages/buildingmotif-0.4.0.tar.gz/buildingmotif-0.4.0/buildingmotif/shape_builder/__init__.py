from buildingmotif.shape_builder.shape import NodeShape, PropertyShape  # noqa
