from ._streaming import slope_of

__all__ = ["slope_of"]
