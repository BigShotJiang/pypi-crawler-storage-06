"""
Sarmat.
"""
VERSION = "4.3.2"

__version__ = VERSION
