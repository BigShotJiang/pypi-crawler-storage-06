from dataclasses import dataclass

from stac_asset import Config


@dataclass
class DownloadConfig(Config):
    pass
