API
===

.. autosummary::
   :toctree: generated
   :recursive:

   stactask
