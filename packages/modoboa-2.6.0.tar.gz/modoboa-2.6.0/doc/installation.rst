############
Installation
############

Requirements
===============
You will need a Server to perform well with at least:

* CPU: 2
* RAM: 2GB
* Disk: 10GB
* Python 3.8+
* Postgres 12+ or MariaDB 10.4+ or MySQL 8+ or sqlite3 or LDAP

.. note:: **👀 Heads up for modoboa versions 1.15 and later**

   Python 2 support has been dropped with modoboa version 1.15.
   If you still have Python 2 installed on your system either uninstall it
   or force modoboa user to run with Python 3.

If you want to run virus scan on your server you will need **4GB** of RAM.

Recommended way
===============

If you start from scratch and want to deploy a complete mail server,
you will love the `modoboa installer
<https://github.com/modoboa/modoboa-installer>`_! It is the easiest
and the quickest way to setup a fully functional server (modoboa,
postfix, dovecot, amavis and more) on one machine.

.. warning::

   For now, only Debian based Linux distributions are
   supported. We do our best to improve compatibility but if you use
   another Linux or a UNIX system, you will have to install Modoboa
   :ref:`manually <by_hand>`.

To use it, just run the following commands in your terminal:

.. sourcecode:: bash

  > git clone https://github.com/modoboa/modoboa-installer
  > cd modoboa-installer
  > sudo ./run.py <your domain>


if you get this warning - '/usr/bin/env: ‘python’: No such file or directory', do make sure sure python is installed on your server. Sometimes python is installed but the installer can't detect it or which python version to run, especially on a debian based system. Then run this command first.

.. sourcecode:: bash

   > sudo apt-get install python3-virtualenv python3-pip

For the sake of simplicity, you can also install the ``python-is-python3`` package.
It allows you to use ``python`` command.

Wait a few minutes and you're done \o/

.. _by_hand:

Manual installation
===================

For those who need a manual installation or who just want to setup a
specific part, here are the steps you must follow:

.. toctree::
   :maxdepth: 1

   manual_installation/modoboa
   manual_installation/webserver
   manual_installation/dovecot
   manual_installation/postfix
   manual_installation/opendkim
   manual_installation/radicale
   manual_installation/amavis

Extensions
----------

Only few commands are needed to add a new extension to your setup.

In case you use a dedicated user and/or a virtualenv, do not forget to
use them:

.. sourcecode:: bash

   > sudo -u <modoboa_user> -i bash
   > source <virtuenv_path>/bin/activate

Then, run the following commands:

.. sourcecode:: bash

   > pip install <EXTENSION>==<VERSION>
   > cd <modoboa_instance_dir>
   > python manage.py migrate
   > python manage.py collectstatic
   > python manage.py check --deploy

Then, restart your web server.
