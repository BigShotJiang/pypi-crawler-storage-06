default_app_config = "modoboa.calendars.apps.CalendarsConfig"
