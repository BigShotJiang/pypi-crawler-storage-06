from django.apps import AppConfig


class AutoconfigConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "modoboa.autoconfig"
