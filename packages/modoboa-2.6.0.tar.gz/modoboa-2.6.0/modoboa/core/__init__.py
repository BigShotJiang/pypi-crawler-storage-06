"""App config for core."""

default_app_config = "modoboa.core.apps.CoreConfig"
