"""
Test suite for Eigen Ingenuity Python Library
This test suite tests the local development version of the library, not the installed version.
"""
