---
name: 🚀 Feature Request
about: Suggest an idea for this project
title: ''
labels: 'enhancement'
assignees: ''

---

<!-- We keep adding new features and enhancements to Blinka 🚀
and would love ❤ to see what new challenge you have got for us... 🙂 -->
