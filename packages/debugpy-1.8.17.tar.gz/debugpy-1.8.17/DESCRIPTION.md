debugpy is an implementation of the Debug Adapter Protocol for Python.

The source code and the issue tracker is [hosted on GitHub](https://github.com/microsoft/debugpy/).
