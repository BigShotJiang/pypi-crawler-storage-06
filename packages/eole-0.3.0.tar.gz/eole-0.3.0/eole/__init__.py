import os

__version__ = "0.3.0"
ROOT_DIR = os.path.abspath(os.path.dirname(__file__))
