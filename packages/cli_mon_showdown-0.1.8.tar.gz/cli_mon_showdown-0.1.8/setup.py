"""
Setup script for cli-mon-showdown.

This file is kept for compatibility with older build tools.
All configuration is in pyproject.toml.
"""

from setuptools import setup

# All configuration is in pyproject.toml
setup()