#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   __init__.py
@Time    :   2025/09/09 14:40:18
@Author  :   firstElfin 
@Version :   0.0
@Desc    :   图像去重代码重构, from LiuGuDong
'''

from imgDedup.scripts.dedupCli import dedupImgCli

__version__ = "1.0.0"
