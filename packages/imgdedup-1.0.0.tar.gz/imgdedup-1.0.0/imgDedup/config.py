#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File    :   config.py
@Time    :   2025/09/09 14:55:23
@Author  :   firstElfin 
@Version :   0.0
@Desc    :   dedupImg config file
'''

