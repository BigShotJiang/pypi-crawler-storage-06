from django.dispatch import Signal



scheduler_init = Signal()
scheduler_embedded_init = Signal()
