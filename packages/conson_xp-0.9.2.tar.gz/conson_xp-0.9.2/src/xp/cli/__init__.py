"""CLI interface for XP tool"""

from .main import cli

__all__ = ["cli"]
