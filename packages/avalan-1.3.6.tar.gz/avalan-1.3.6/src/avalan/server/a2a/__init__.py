"""Utilities for exposing Avalan via the A2A protocol."""

from .router import router, well_known_router  # noqa: F401
