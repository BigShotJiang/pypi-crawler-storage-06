class HubAccessDeniedException(Exception):
    pass
