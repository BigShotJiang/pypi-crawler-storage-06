__version__ = "0.1.1"

from .definehtml import DefineHtml, DefineHtmlGenerationError

__all__ = ["DefineHtml", "DefineHtmlGenerationError", "__version__"]