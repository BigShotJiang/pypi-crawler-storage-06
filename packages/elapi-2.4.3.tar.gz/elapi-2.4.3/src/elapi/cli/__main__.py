from .elapi import app
from .. import APP_NAME

app(prog_name=APP_NAME)
