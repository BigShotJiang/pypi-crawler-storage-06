from accli._version import VERSION

from accli.cli import app

from accli.AcceleratorTaskDispatcher import *

from accli.AcceleratorJobProjectService import AcceleratorJobProjectService, Fs

AjobCliService = AcceleratorJobProjectService

