# Please strictly put double quote to use this info for git tag 
# Read developer guide for git tag command with regex
VERSION = "v0.8.0" 