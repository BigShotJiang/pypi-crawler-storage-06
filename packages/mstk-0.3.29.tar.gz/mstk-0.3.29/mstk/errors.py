class PackmolError(Exception):
    pass


class GmxError(Exception):
    pass


class SchedulerError(Exception):
    pass
