class FFTermNotFoundError(Exception):
    pass


class TypingNotSupportedError(Exception):
    pass


class TypingUndefinedError(Exception):
    pass


class ChargeIncrementNonZeroError(Exception):
    pass
