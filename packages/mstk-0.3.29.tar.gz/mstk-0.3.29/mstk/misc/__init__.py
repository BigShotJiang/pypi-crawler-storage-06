from .singleton import Singleton
from .docmeta import DocstringMeta