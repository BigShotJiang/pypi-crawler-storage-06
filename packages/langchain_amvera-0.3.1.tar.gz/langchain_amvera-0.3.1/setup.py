"""Setup script for langchain-amvera package."""

from setuptools import setup

# Используем pyproject.toml для конфигурации
setup()