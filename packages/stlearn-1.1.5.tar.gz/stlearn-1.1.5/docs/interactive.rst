.. highlight:: shell

===================
Interactive Web App
===================


Launch stlearn in your local
----------------------------

Run the launch command in the terminal:
::

	stlearn launch

After that, you can access `https://<IP address>:5000` in your web browser.
