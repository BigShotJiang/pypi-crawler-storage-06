References
----------
.. [Coifman05] Coifman *et al.* (2005),
   *Geometric diffusions as a tool for harmonic analysis and structure definition of data: Diffusion maps*,
   `PNAS <https://doi.org/10.1038/nmeth.3971>`__.

.. [Haghverdi15] Haghverdi *et al.* (2015),
   *Diffusion maps for high-dimensional single-cell analysis of differentiation data*,
   `Bioinformatics <https://doi.org/10.1093/bioinformatics/btv325>`__.

.. [Haghverdi16] Haghverdi *et al.* (2016),
   *Diffusion pseudotime robustly reconstructs branching cellular lineages*,
   `Nature Methods <https://doi.org/10.1038/nmeth.3971>`__.

.. [Wolf18] Wolf *et al.* (2018),
   *Scanpy: large-scale single-cell gene expression data analysis*,
   `Genome Biology <https://doi.org/10.1186/s13059-017-1382-0>`__.

.. [Pedregosa11] Pedregosa *et al.* (2011),
   *Scikit-learn: Machine Learning in Python*,
   `JMLR <http://www.jmlr.org/papers/v12/pedregosa11a.html>`__.

.. [McInnes18] McInnes & Healy (2018),
   *UMAP: Uniform Manifold Approximation and Projection for Dimension Reduction*,
   `arXiv <https://arxiv.org/abs/1802.03426>`__.

.. [Weinreb16] Weinreb *et al.* (2016),
   *SPRING: a kinetic interface for visualizing high dimensional single-cell expression data*,
   `bioRxiv <https://doi.org/10.1101/090332>`__.

.. [Satija15] Satija *et al.* (2015),
   *Spatial reconstruction of single-cell gene expression data*,
   `Nature Biotechnology <https://doi.org/10.1038/nbt.3192>`__.

.. [Zheng17] Zheng *et al.* (2017),
   *Massively parallel digital transcriptional profiling of single cells*,
   `Nature Communications <https://doi.org/10.1038/ncomms14049>`__.

.. [Weinreb17] Weinreb *et al.* (2016),
   *SPRING: a kinetic interface for visualizing high dimensional single-cell expression data*,
   `bioRxiv <https://doi.org/10.1101/090332>`__.

.. [Blondel08] Blondel *et al.* (2008),
   *Fast unfolding of communities in large networks*,
   `J. Stat. Mech. <https://doi.org/10.1088/1742-5468/2008/10/P10008>`__.

.. [Levine15] Levine *et al.* (2015),
   *Data-Driven Phenotypic Dissection of AML Reveals Progenitor--like Cells that Correlate with Prognosis*,
   `Cell <https://doi.org/10.1016/j.cell.2015.05.047>`__.

.. [Traag17]  (2017),
   *Louvain*,
   `GitHub <https://doi.org/10.5281/zenodo.35117>`__.

.. [Lambiotte09] Lambiotte *et al.* (2009)
   *Laplacian Dynamics and Multiscale Modular Structure in Networks*
   `arXiv <https://arxiv.org/abs/0812.1770>`__.
