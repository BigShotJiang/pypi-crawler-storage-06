#!/usr/bin/env python

"""Package entry point."""

from stlearn.app import cli

if __name__ == "__main__":  # pragma: no cover
    cli.main()
