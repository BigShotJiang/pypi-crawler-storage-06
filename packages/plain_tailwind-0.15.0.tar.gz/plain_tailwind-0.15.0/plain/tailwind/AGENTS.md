# Plain Tailwind AGENTS.md

- Use `data-` attributes and Tailwind `data-` selectors for conditional styling instead of `{% if %}` statements inside of HTML `class` attributes.
