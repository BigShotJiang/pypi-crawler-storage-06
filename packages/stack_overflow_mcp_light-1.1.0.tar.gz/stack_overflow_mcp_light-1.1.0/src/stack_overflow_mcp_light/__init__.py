"""Stack Overflow MCP Server - A Model Context Protocol server for Stack Overflow API operations."""

__version__ = "1.0.0"
__author__ = "Minh Doan"
__description__ = "MCP server for Stack Overflow API operations"
