"""Stack Exchange API tools for the MCP server."""
