

custom_print module requires **Python 3.12** or greater.

It was tested on AlmaLinux, Red Hat 9, CentOS Stream 9, and Windows 10.

Find the **README.md** file at https://github.com/acma82/custom_print



## Friday, December 27, 2024





