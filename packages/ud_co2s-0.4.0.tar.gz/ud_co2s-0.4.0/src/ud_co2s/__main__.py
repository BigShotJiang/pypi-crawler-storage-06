"""Make the CLI runnable using python -m ud_co2s."""

from .cli import app

app(prog_name="ud-co2s")
