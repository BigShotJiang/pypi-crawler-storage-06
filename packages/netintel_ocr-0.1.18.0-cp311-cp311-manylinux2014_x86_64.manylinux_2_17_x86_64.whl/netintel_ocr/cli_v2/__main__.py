"""
CLI entry point for running as module
"""

from .main import main

if __name__ == '__main__':
    main()