"""
CLI utilities for NetIntel-OCR
"""

from .version_info import VersionInfo, __version__

__all__ = ['VersionInfo', '__version__']