"""
PintorPintor - Biblioteca simples para análise PCA
Autor: Pedro Pintor - Versão: 1.0.0
"""

from .core import PintorPintor

__version__ = "1.0.0"
__all__ = ["PintorPintor"]
