# fastgraphFPMS

Python library in C++ for graph and optimisation.

## Installation

Use this command to install fastgraphFPMS :

```bash
pip install fastgraphFPMS
```

Thanks for downloading.