## Configuraciones ParamsX

configuraciones = {
    "profile_name": "default",
    "region_name": "eu-south-2",
    "entornos": ['DEV','PROD'],
    "parameter_list":[
        "params1",
        "params2"
    ]
}

