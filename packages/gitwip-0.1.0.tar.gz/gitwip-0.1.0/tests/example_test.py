def test_example() -> None:
    assert not True == False
