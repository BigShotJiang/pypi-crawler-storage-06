"""API entry point for the `gitwip` package."""

__all__: list[str] = []
