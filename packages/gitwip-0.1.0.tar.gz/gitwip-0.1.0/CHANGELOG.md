# gitwip Changelog

All notable changes to this project will be documented in this file.

---

<!-- ## Unreleased

### Added

### Changed

### Fixed

### Removed

### Known Issues

---

-->

## 0.1.0 | 2025-09-19

Initial release.

---
