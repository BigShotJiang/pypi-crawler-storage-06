# [gitwip](https://4mbl.link/gh/gitwip)

> Lists non-primary git branches in a directory tree.

## Table of Contents

* [Table of Contents](#table-of-contents)
  * [Installation](#installation)
* [Usage](#usage)
* [License](#license)

### Installation

Use pip to install `gitwip`.

```bash
pip install --upgrade gitwip
```

## Usage

```bash
gitwip ~/code
```

## License

MIT
