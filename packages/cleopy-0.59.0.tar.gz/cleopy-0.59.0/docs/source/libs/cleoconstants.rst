CLEO Constants
==============

Header file: ``<libs/cleoconstants.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/cleoconstants.hpp>`_

.. doxygennamespace:: dimmed_constants
   :project: libs
   :content-only:
   :desc-only:
   :outline:
   :members:
   :protected-members:
   :private-members:
   :undoc-members:
   :no-link:

.. doxygennamespace:: dimless_constants
   :project: libs
   :content-only:
   :desc-only:
   :outline:
   :members:
   :protected-members:
   :private-members:
   :undoc-members:
   :no-link:

.. doxygennamespace:: LIMITVALUES
   :project: libs
   :content-only:
   :desc-only:
   :outline:
   :members:
   :protected-members:
   :private-members:
   :undoc-members:
   :no-link:
