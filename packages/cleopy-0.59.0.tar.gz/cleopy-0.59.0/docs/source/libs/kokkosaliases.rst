Kokkos Aliases
==============

Header file: ``<libs/kokkosaliases.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/kokkosaliases.hpp>`_

.. doxygenfile:: libs/kokkosaliases.hpp
   :project: libs
