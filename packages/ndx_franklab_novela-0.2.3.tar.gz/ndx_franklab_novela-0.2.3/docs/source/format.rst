
.. _ndx-franklab-novela:

*******************
ndx-franklab-novela
*******************

Version |release| |today|

.. .. contents::

.. include:: _format_auto_docs/format_spec_main.inc
