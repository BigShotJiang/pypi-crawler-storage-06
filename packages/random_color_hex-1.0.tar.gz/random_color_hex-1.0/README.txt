# random_color_hex
Generate random CSS-style hex colors like #RRGGBB.

Usage:
import random_color_hex as RCH
print(RCH.main())