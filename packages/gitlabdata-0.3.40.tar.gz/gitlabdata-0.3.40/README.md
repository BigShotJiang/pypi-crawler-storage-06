## Data Team

The [handbook](https://about.gitlab.com/handbook/business-ops/data-team/data-infrastructure) is the single source of truth for all of our documentation. 

### Contributing

We welcome contributions and improvements, please see the [contribution guidelines](CONTRIBUTING.md).

### License

This code is distributed under the MIT license, please see the [LICENSE](LICENSE) file.
