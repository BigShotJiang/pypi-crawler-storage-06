"""Framework-specific adapters for different AI agent frameworks."""
