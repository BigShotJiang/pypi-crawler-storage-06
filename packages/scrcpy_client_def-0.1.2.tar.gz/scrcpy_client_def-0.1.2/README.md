# scrcpy client definitions

The scrcpy client HID and inject definitions, which is used to easily develop applications based on scrcpy-server with Python.
