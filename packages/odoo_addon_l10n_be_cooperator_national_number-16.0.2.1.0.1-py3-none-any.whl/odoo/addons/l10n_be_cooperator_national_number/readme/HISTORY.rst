16.0.2.0.0 (2024-06-14)
~~~~~~~~~~~~~~~~~~~~~~~

**Misc**

- `#136 <https://github.com/OCA/cooperative/issues/136>`_, `#136 <https://github.com/OCA/cooperative/issues/136>`_


16.0.1.3.0 (2024-06-14)
~~~~~~~~~~~~~~~~~~~~~~~

**Bugfixes**

- Allow removal of national number. (`#139 <https://github.com/OCA/cooperative/issues/139>`_)


16.0.1.2.0 (2024-06-11)
~~~~~~~~~~~~~~~~~~~~~~~

**Features**

- Added several convenience functions to get national number values on
  ``res.partner``. (`#134 <https://github.com/OCA/cooperative/issues/134>`_)


16.0.1.1.0 (2024-06-11)
~~~~~~~~~~~~~~~~~~~~~~~

**Features**

- Added ``get_display_national_number`` and ``get_require_national_number``
  convenience methods to ``res.company``. (`#133 <https://github.com/OCA/cooperative/issues/133>`_)
