# Copyright (c) Alibaba, Inc. and its affiliates.

__version__ = '1.0.2'
__release_datetime__ = '2025-09-23 18:00:00'
