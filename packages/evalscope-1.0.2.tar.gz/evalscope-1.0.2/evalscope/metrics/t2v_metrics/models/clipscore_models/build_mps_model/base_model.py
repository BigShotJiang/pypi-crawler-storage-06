from dataclasses import dataclass


@dataclass
class BaseModelConfig:
    pass
