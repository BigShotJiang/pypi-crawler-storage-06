default_app_config = 'omero_biomero.apps.OmeroBiomeroConfig'
