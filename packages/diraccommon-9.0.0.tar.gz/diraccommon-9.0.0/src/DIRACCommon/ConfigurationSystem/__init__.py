"""
DIRACCommon.ConfigurationSystem - Configuration system components
"""
