# Init file for WorkloadManagementSystem.Client.JobState tests
