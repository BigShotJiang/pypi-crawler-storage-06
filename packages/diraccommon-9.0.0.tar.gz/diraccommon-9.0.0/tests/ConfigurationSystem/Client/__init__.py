"""
DIRACCommon.ConfigurationSystem.Client tests
"""
