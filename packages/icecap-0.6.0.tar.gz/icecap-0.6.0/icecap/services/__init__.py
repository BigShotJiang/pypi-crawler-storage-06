"""The module will contain services to interact with the game world."""
