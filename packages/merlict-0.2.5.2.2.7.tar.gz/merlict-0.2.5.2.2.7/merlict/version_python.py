# Set the pyhton package version of merlict here manually.
__version__ = "0.2.5"
