# I was written by: merlict/c89/almagamate_merlict_c89_and_set_version.py. Do not modify me manually.
__version__ = "2.2.7"
