from .. import TestCase  # noqa: TID252


class TestContent(TestCase):
    pass
