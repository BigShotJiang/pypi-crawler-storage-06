Wrapper
=======

.. automodule:: siotls.wrapper

   .. autoclass:: WrappedSocket
      :members:
