Trust
=====

.. automodule:: siotls.trust
   :members: TrustStore, load_certifi_ca_certificates, load_system_ca_certificates, get_ca_certificates, get_truststore


Backends
--------


.. toctree::
   :maxdepth: 1

   backends/openssl

