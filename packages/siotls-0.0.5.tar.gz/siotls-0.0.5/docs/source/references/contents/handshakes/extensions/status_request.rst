Status Request
==============

.. automodule:: siotls.contents.handshakes.extensions.status_request
   :members:
