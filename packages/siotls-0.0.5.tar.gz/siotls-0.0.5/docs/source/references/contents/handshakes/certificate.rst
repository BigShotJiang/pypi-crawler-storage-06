Certificate
===========

.. automodule:: siotls.contents.handshakes.certificate
   :members:
