Certificate Verify
==================

.. automodule:: siotls.contents.handshakes.certificate_verify
   :members:
