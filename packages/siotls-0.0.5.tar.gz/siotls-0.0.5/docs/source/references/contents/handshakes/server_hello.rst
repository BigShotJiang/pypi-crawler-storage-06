Server Hello/Hello Retry Request
================================

.. automodule:: siotls.contents.handshakes.server_hello
   :members:
