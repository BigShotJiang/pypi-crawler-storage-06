.. _SNI:

Server Name (SNI)
=================

.. automodule:: siotls.contents.handshakes.extensions.server_name
   :members:
