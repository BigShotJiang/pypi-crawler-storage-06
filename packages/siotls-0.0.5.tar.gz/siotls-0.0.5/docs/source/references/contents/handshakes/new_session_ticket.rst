New Session Ticket
==================

.. automodule:: siotls.contents.handshakes.new_session_ticket
   :members:
