Certificate Type
================

.. automodule:: siotls.contents.handshakes.extensions.certificate_type
   :members:
