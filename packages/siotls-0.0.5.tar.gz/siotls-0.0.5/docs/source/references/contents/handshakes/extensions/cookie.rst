Cookie
======

.. automodule:: siotls.contents.handshakes.extensions.cookie
   :members:
