Supported Versions
==================

.. automodule:: siotls.contents.handshakes.extensions.supported_versions
   :members:
