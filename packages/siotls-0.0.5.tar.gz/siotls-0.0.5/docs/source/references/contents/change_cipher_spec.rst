Change Cipher Spec
==================

.. automodule:: siotls.contents.change_cipher_spec
   :members:
