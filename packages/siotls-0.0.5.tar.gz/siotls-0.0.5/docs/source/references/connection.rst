Connection
==========

.. module:: siotls.connection

   .. autoclass:: TLSConnection
      :members:
