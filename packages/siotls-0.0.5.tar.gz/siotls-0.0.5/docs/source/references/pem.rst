PEM Decoder
===========

.. automodule:: siotls.pem
   :members: decode_pem, decode_pem_certificate, decode_pem_certificate_chain, decode_pem_private_key, decode_pem_public_key
   :undoc-members:
