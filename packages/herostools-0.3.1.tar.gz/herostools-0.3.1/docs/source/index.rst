.. herostools documentation master file, created by
   sphinx-quickstart on Fri Jan 17 13:10:44 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

HEROS Tools documentation
=========================

herostools is a collection of useful services for your HEROS environment. They can readily be launched by BOSS or
instantiated from your python environment of choice.

Find a list of existing tools below.

.. toctree::
   :maxdepth: 2
   :caption: Tools:

   aggregator
