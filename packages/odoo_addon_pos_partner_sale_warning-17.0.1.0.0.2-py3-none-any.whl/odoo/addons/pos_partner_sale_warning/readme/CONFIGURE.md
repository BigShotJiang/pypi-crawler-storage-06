This module requires "sale_management" module to be installed.

When installed go to the "Settings/Sales" menu and scroll to the "Quotations & Orders" section.

Activate the "Sale Warnings" checkbox.
