Odoo allows to configure warnings for partners and products to be shown when a new sales order is created.

However those warnings will not be shown for a POS order.
