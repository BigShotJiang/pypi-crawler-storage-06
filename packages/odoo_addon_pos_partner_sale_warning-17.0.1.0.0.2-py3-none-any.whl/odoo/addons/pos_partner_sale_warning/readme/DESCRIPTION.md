This module shows partner warnings when a partner is selected in POS.
