TODO: add support for product messages
