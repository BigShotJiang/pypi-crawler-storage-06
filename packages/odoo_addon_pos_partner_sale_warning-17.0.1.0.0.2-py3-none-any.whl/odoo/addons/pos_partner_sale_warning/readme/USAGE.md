On a partner form open the "Internal Notes" tab, and select a message type in the "WARNING ON THE SALES ORDER" field.  Add the warning text to be shown in the field below.

When this partner is selected in POS a warning will be shown. Depending on the warning type it can be a blocking or a non-blocking one.
