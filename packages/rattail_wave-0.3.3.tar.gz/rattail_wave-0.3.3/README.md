
# rattail-wave

Rattail is a retail software framework, released under the GNU General
Public License.

This package contains software interfaces for
[Wave](https://www.waveapps.com/).

Please see the [Rattail Project](https://rattailproject.org/) for more
information.
