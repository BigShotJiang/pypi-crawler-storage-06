"""Documentation generation for legacy web analysis results."""

__version__ = "1.0.0"