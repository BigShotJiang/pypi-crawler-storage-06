"""Module entrypoint delegating to the CLI handler."""

from __future__ import annotations

from legacy_web_mcp.cli import main

if __name__ == "__main__":
    main()
