"""
Tests for the pydantic-cwe package.
"""