from .weaknesses import *

from .catalog import WeaknessCatalog