"""A module containing some high level capabilities."""
