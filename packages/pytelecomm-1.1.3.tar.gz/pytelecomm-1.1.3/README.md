[![Hatch project](https://img.shields.io/badge/%F0%9F%A5%9A-Hatch-4051b5.svg)](https://github.com/capn-freako/pytelecomm)

# PyTeleComm

Exploration of telecommunications theory in Python.
