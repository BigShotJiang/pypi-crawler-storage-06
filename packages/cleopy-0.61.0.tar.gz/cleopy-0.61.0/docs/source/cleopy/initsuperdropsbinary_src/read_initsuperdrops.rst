READ_INITSUPERDROPS
===================

.. automodule:: cleopy.initsuperdropsbinary_src.read_initsuperdrops
   :members:
