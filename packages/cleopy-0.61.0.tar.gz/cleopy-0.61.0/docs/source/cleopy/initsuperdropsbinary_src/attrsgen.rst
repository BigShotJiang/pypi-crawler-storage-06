ATTRSGEN
========

.. automodule:: cleopy.initsuperdropsbinary_src.attrsgen
   :members:
