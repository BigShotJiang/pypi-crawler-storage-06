THERMODYNGEN
============

Combines thermogen and windsgen into single object

.. automodule:: cleopy.thermobinary_src.thermodyngen
  :members:
