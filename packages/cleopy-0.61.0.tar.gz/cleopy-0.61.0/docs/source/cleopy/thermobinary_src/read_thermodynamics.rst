READ_THERMODYNAMICS
===================

.. automodule:: cleopy.thermobinary_src.read_thermodynamics
  :members:
