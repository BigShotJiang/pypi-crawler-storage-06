Thread-Safe Superdroplet Shuffling Algorithms
=============================================

Header file: ``<libs/superdrops/collisions/shuffle.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/superdrops/collisions/shuffle.hpp>`_

.. doxygenfunction:: shuffle_supers
   :project: superdrops

.. doxygenfunction:: device_swap
   :project: superdrops

.. doxygenfunction:: fisher_yates_shuffle
   :project: superdrops
