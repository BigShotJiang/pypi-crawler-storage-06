Collision Kinetics
==================

Header file: ``<libs/superdrops/collisions/collisionkinetics.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/superdrops/collisions/collisionkinetics.hpp>`_

.. doxygenfunction:: collision_kinetic_energy
   :project: superdrops

.. doxygenfunction:: coal_surfenergy
   :project: superdrops

.. doxygenfunction:: surfenergy
   :project: superdrops

.. doxygenfunction:: total_surfenergy
   :project: superdrops
