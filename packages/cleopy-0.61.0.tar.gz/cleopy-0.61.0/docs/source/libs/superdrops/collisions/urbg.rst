Randomness Generation
=====================

Header file: ``<libs/superdrops/collisions/urbg.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/superdrops/collisions/urbg.hpp>`_

.. doxygenstruct:: URBG
   :project: superdrops
   :private-members:
   :protected-members:
   :members:
   :undoc-members:
