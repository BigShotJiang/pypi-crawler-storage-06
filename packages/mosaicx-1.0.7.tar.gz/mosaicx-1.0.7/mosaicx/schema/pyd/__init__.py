"""
Pydantic Model Storage Directory

Generated Pydantic class .py files are stored here when no custom path is specified.
"""
