# [Claude-Sonnet-4-Search](https://poe.com/Claude-Sonnet-4-Search){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Input Text | 115 points/1k tokens |
| Input Image | 115 points/1k tokens |
| Bot Message | 843 points/message |
| Chat History | Input rates are applied |
| Chat History Cache Discount | 90% discount oncached chat history |
| Initial Points Cost | 870+ points |

**Last Checked:** 2025-08-05 23:17:52.359681


## Bot Information

**Creator:** @anthropic

**Description:** Claude Sonnet 4 with access to real-time information from the web. Supports customizable thinking budget of up to 126k tokens.
To instruct the bot to use more thinking effort, add --thinking_budget and a number ranging from 0 to 126,000 to the end of your message.

**Extra:** Powered by Anthropic: claude-sonnet-4-20250514. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Claude-Sonnet-4-Search`

**Object Type:** model

**Created:** 1750451236340

**Owned By:** poe

**Root:** Claude-Sonnet-4-Search
