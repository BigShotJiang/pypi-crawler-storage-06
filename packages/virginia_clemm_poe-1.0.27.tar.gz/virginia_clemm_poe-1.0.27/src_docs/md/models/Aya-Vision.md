# [Aya-Vision](https://poe.com/Aya-Vision){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Total Cost | 0 points/message |
| Initial Points Cost | 0 points |

**Last Checked:** 2025-08-05 23:15:27.275730


## Bot Information

**Creator:** @cohere

**Description:** Aya Vision is a 32B open-weights multimodal model with advanced capabilities optimized for a variety of vision-language use cases. It is model trained to excel in 23 languages in both vision and text: Arabic, Chinese (simplified & traditional), Czech, Dutch, English, French, German, Greek, Hebrew, Hindi, Indonesian, Italian, Japanese, Korean, Persian, Polish, Portuguese, Romanian, Russian, Spanish, Turkish, Ukrainian, and Vietnamese.

**Extra:** Powered by a server managed by @cohere. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Aya-Vision`

**Object Type:** model

**Created:** 1741042614242

**Owned By:** poe

**Root:** Aya-Vision
