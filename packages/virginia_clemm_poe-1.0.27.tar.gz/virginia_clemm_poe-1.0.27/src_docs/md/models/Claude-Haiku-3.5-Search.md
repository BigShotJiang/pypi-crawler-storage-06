# [Claude-Haiku-3.5-Search](https://poe.com/Claude-Haiku-3.5-Search){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Input Text | 30 points/1k tokens |
| Input Image | 30 points/1k tokens |
| Bot Message | 92 points/message |
| Chat History | Input rates are applied |
| Chat History Cache Discount | 90% discount oncached chat history |
| Initial Points Cost | 99+ points |

**Last Checked:** 2025-08-05 23:16:15.185407


## Bot Information

**Creator:** @anthropic

**Description:** Claude Haiku 3.5 with access to real-time information from the web.

**Extra:** Powered by Anthropic: claude-3-5-haiku-20241022. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Claude-Haiku-3.5-Search`

**Object Type:** model

**Created:** 1747285932473

**Owned By:** poe

**Root:** Claude-Haiku-3.5-Search
