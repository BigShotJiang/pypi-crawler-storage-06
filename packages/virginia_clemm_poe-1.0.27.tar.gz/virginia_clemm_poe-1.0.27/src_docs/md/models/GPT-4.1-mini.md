# [GPT-4.1-mini](https://poe.com/GPT-4.1-mini){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Input Text | 12 points/1k tokens |
| Input Image | 12 points/1k tokens |
| Bot Message | 22 points/message |
| Chat History | Input rates are applied |
| Chat History Cache Discount | 75% discount oncached chat history |
| Initial Points Cost | 25+ points |

**Last Checked:** 2025-08-05 23:22:45.530107


## Bot Information

**Creator:** @openai

**Description:** GPT-4.1 mini is a small, fast & affordable model that matches or beats GPT-4o in many intelligence and vision-related tasks. Supports 1M tokens of context.

**Extra:** Powered by OpenAI: gpt-4.1-mini-2025-04-14. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `GPT-4.1-mini`

**Object Type:** model

**Created:** 1744675260112

**Owned By:** poe

**Root:** GPT-4.1-mini
