# NOMAD Camels driver for keithley_197a

Driver for keithley_197a written for the measurement software [NOMAD Camels](https://fau-lap.github.io/NOMAD-CAMELS/).


## Documentation

For more information and instruments visit the [documentation](https://fau-lap.github.io/NOMAD-CAMELS/doc/instruments/instruments.html).

## Changelog

### 0.1.0

Initial release. Basic reading of DV & AC voltage and  current.