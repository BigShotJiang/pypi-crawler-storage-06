"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "b79965f06445d2520e3af07e904bce38d05eecc2"
short_id = "b79965f"
