from setuptools import setup

setup(
    name='meu_pacote_kiyono',
    version='0.1.0',
    description='Meu pacote',
    long_description='Meu pacote',
    author='Marcos Kiyono',
    author_email='kiyono.marcos@gmail.com',
    python_requires='>=3.8,<4.0',
    install_requires=['httpx'],
)