class KillEventException(Exception):
    """
    Exception raised when the kill event is set
    """

    pass
