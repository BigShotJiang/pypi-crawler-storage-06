import {Box} from "@mui/material";

export const ShowCameras = () => {
    return (
        <Box>

        </Box>
    )
}