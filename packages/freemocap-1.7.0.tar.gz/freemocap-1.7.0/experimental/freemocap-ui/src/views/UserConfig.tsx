interface Props {
    recordingSessionLocation: string;
}

export const UserConfig = (
    props: Props
) => {
    return null;
}