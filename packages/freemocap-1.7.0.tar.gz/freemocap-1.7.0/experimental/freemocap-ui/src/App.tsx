import React from 'react';
import {Paperbase} from "./layout/Paperbase";

function App() {
    return (
        <React.Fragment>
            <Paperbase/>
        </React.Fragment>
    );
}

export default App;
