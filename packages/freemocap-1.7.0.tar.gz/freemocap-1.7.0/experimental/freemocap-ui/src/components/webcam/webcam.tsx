import {default as Webcam} from 'react-webcam';

export const SomeWebcam = () => {
    return <Webcam/>
}