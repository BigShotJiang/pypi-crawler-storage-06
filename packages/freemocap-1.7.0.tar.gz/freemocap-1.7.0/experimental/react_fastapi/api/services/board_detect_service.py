from typing import NamedTuple


class ImageResponse(NamedTuple):
    image: bytes
    webcam_id: str


class BoardDetectService:
    pass
