class MediapipeSkeletonDetectionService:
    pass
