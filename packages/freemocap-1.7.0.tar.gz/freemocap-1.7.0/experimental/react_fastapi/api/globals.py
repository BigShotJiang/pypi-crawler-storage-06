# TODO: The globals that are saved here will be replaced by different solutions upcoming
