ACCOUNT_APP_ID = "django_project_base.account"
MERGE_USERS_QS_CK = f"merge-users-list-%d"  # noqa: F541
RESET_USER_PASSWORD_VERIFICATION_CODE = "reset-user-password-ver-identifier-"
