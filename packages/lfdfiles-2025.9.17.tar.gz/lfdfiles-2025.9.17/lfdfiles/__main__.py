# lfdfiles/__main__.py

"""Lfdfiles package command line script."""

from .lfdfiles import main

main()
