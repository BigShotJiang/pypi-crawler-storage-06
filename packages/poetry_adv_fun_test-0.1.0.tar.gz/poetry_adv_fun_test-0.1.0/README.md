![CI](https://github.com/saileshmishraindia/poetry-device-lib-testing/actions/workflows/python-ci.yml/badge.svg)
[![codecov](https://codecov.io/gh/saileshmishraindia/poetry-device-lib-testing/branch/main/graph/badge.svg)](https://codecov.io/gh/saileshmishraindia/poetry-device-lib-testing)
[![PyPI version](https://img.shields.io/pypi/v/poetry-demo-sailesh.svg)](https://pypi.org/project/poetry-demo/)
 


