# Elite SDK For Python PMR Fork

This fork was created to fix issues found while working in the Mechatronics Department of Poli USP

It provides the same functionality than the original SDK but with better type checking and translated documentation

## Overview

### Installation

```bash
pip install elirobots_pmr_sdk
# or
pip3 install elirobots_pmr_sdk
```

### Documentation

TBD

### Feedback

Original project at `https://github.com/JunJie-zhang-o/eliterobot.git`
