"""
Author: Elite_zhangjunjie
CreateDate:
LastEditors: Elite_zhangjunjie
LastEditTime: 2022-05-10 14:53:32
Description:
"""

__all__ = ["EC"]

__version__ = "0.0.1"


from pmr_elirobots_sdk._ec import _EC as EC
