from .general_template import GeneralTemplate
