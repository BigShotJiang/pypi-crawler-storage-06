"""
Apimaker Zillow Integration

Future implementation for Zillow data collection via Apimaker API.
"""

# Future imports will go here
# from .listings import get_zillow_listings, get_listings_summary
# from .property_details import get_property_details, get_property_details_summary

__all__ = []
