# brotli-stubs

Type stubs for [brotli](https://github.com/google/brotli/tree/master/python)
