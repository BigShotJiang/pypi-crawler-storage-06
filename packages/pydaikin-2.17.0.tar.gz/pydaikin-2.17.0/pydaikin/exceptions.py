"""Daikin exceptions."""


class DaikinException(Exception):
    """Daikin base exception class."""
