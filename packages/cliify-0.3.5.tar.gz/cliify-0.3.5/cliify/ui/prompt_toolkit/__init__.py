from cliify.ui.prompt_toolkit.SplitConsole import SplitConsole
from cliify.ui.prompt_toolkit.Console import InterpreterConsole as Console