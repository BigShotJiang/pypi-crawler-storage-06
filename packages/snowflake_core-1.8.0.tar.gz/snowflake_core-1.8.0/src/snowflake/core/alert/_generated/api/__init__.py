from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.alert._generated.api.alert_api import AlertApi

__all__ = [
    "AlertApi",
]
