from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from snowflake.core.notification_integration._generated.api.notification_integration_api import (
    NotificationIntegrationApi,
)

__all__ = [
    "NotificationIntegrationApi",
]
