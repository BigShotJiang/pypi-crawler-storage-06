# -*- coding: utf-8 -*-
from django.dispatch import Signal

user_accept_consent = Signal()
user_decline_consent = Signal()
