# Lolgram In-App Bot

A Python library for creating and managing in-apps within the Lolgram platform, similar to python-telegram-bot.

## Installation
```bash
pip install lolgram-inapp-bot