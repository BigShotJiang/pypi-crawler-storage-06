from .base import KittyCadBaseModel


class ObjectSetMaterialParamsPbr(KittyCadBaseModel):
    """The response from the `ObjectSetMaterialParamsPbr` endpoint."""
