from .base import KittyCadBaseModel


class DefaultCameraSetView(KittyCadBaseModel):
    """The response from the `DefaultCameraSetView` command."""
