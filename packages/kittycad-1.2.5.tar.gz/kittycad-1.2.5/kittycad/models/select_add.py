from .base import KittyCadBaseModel


class SelectAdd(KittyCadBaseModel):
    """The response from the `SelectAdd` endpoint."""
