"""

Easy to use suzaku，like tkinter

"""

from .event import *
from .styles import *
from .var import *
from .widgets import SkApp
from .widgets import SkAppWindow as SkAppWindow
from .widgets import SkCard
from .widgets import SkCheckItem as SkCheckbox
from .widgets import SkEntry, SkFrame
from .widgets import SkText as SkLabel
from .widgets import SkTextButton as SkButton
from .widgets import SkWidget
from .widgets import SkWindow as SkToplevel
