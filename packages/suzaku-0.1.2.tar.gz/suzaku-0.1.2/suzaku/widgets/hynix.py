RAM = """
------------------------------------------
#  ####  ####  ####    ####__####__####  #
#  ####  ####  ####    ##| SKHynix  |##  #
>  ####  ####  ####    ###=--====--=###  <
#                                        #
|||||||||||||||||^||||||||||||||||||||||||
"""


class SkHynix:
    def __init__(self):
        """
        Ester egg from the very beginning, by rgzz666.
        """
        print(RAM)
        raise RuntimeError(
            "Why you want a SKHynix here??? Out of RAM bro? Then go fxxk ur backend code."
        )


if __name__ == "__main__":
    ur_brand_new_ram_stick = SkHynix()
