import skia


def point(*args, **kwargs):
    return skia.Paint(*args, **kwargs)
