[![DOI](https://zenodo.org/badge/776090967.svg)](https://doi.org/10.5281/zenodo.15038194)

If npxpy contributes to your research, software, or project, we kindly request that you cite it in your
publications using the provided DOI above.