# npxpy.nodes.node.Node


####::: npxpy.nodes.node.Node