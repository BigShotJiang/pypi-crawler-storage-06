# npxpy.nodes.structures.Text


####::: npxpy.nodes.structures.Text