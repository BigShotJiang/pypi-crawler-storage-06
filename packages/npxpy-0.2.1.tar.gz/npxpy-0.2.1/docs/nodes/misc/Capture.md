# npxpy.nodes.misc.Capture


####::: npxpy.nodes.misc.Capture