# npxpy.nodes.aligners.CoarseAligner


####::: npxpy.nodes.aligners.CoarseAligner