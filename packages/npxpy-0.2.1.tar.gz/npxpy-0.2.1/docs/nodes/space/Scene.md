# npxpy.nodes.space.Scene


####::: npxpy.nodes.space.Scene