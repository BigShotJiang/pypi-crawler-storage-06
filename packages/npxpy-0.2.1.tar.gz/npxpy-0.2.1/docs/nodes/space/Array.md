# npxpy.nodes.space.Array


####::: npxpy.nodes.space.Array