# Resources Module


#### ::: npxpy.resources.Resource