# CollectionScope


## Enum

* `PRIVATE` (value: `'PRIVATE'`)

* `PUBLIC` (value: `'PUBLIC'`)

* `PROTECTED` (value: `'PROTECTED'`)

* `TEAM` (value: `'TEAM'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


