from .logs import HasLogs
from .metrics import HasMetrics

__all__ = ["HasLogs", "HasMetrics"]
