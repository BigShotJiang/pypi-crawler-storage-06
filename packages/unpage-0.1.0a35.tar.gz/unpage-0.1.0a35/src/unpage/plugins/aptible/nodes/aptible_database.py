from .base import AptibleNode


class AptibleDatabase(AptibleNode):
    """A node representing an Aptible database resource."""
