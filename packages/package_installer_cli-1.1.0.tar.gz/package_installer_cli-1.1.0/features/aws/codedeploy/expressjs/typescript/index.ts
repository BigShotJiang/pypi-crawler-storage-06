
import codeDeployRoutes from './routes/codeDeployRoutes';

app.use("/api/codedeploy",codeDeployRoutes)