
import awsCognitoRoutes from './routes/awsCognitoRoutes.js';

app.use("/api/cognito",awsCognitoRoutes)