
import codeCommitRoutes from './routes/codeCommitRoutes.js';

app.use("/api/codecommit",codeCommitRoutes)