import openRouterkRoutes from './routes/openRouterkRoutes';

app.use("/api/open-router", openRouterkRoutes);