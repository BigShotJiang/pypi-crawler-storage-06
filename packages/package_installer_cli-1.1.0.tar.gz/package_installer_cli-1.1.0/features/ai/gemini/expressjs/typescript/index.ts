import geminiRoutes from './routes/geminiRoutes';

app.use("/api/gemini", geminiRoutes);