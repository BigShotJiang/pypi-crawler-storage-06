from enum import Enum

class CloudProvider(Enum):
    """
    TODO
    """
    LOCAL = "local"
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
