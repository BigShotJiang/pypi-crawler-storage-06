"""Galaxy reports controllers."""
