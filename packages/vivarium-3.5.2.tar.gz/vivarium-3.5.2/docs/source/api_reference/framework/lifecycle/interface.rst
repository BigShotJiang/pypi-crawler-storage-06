.. automodule:: vivarium.framework.lifecycle.interface
