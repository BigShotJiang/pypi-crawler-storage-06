.. _configuration_concept:

========================
The Configuration System
========================

.. contents::
   :depth: 2
   :local:
   :backlinks: none

Outline
-------
 - Configuration is hierarchical
 - Configuration sources and priorities
 - Specifying defaults.
