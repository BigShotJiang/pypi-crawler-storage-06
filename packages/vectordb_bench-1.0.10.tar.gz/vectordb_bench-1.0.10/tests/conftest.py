import sys

from os.path import dirname, abspath
sys.path.append(dirname(dirname(abspath(__file__))))
