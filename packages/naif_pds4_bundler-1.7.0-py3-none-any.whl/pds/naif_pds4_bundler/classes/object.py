"""Dummy Class Implementation."""


class Object(object):
    """Dummy Class."""

    def __init__(self):
        """Constructor."""
        self.kernels_directory = None
        self.working_directory = None

    pass
