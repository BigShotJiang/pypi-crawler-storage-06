"""
Test package for OpenElectricity models.
"""
