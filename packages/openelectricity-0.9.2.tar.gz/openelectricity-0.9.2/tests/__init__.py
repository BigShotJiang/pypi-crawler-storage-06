"""
Test package for OpenElectricity.
"""
