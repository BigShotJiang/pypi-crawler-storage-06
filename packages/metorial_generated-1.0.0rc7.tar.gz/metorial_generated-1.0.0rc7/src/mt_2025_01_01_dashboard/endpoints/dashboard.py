from typing import Optional, Dict, Any, List, Union
from metorial_util_endpoint import (
  BaseMetorialEndpoint,
  MetorialEndpointManager,
  MetorialRequest,
)
from ..resources import (
  mapDashboardBootOutput,
  DashboardBootOutput,
  mapDashboardBootBody,
  DashboardBootBody,
)


class MetorialDashboardEndpoint(BaseMetorialEndpoint):
  """Boot user"""

  def __init__(self, config: MetorialEndpointManager):
    super().__init__(config)

  def boot(self) -> DashboardBootOutput:
    """
    Create organization
    Create a new organization


    :return: DashboardBootOutput
    """
    body = {}

    request = MetorialRequest(
      path=["dashboard", "boot"],
      body=body,
    )
    return self._post(request).transform(mapDashboardBootOutput.from_dict)
