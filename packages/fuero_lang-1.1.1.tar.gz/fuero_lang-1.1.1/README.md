<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/ogcae/fuero/main/.github/logo-dark.svg">
  <img alt="Fuero" src="https://raw.githubusercontent.com/ogcae/fuero/main/.github/logo-light.svg" width="300">
</picture>

<h3>Modern programming language with comprehensive utilities</h3>

[![Version](https://img.shields.io/badge/version-1.1.1-blue?style=flat-square)](https://github.com/ogcae/fuero/releases)
[![Python](https://img.shields.io/badge/python-3.8+-green?style=flat-square)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-orange?style=flat-square)](LICENSE)
[![Downloads](https://img.shields.io/github/downloads/ogcae/fuero/total?style=flat-square)](https://github.com/ogcae/fuero/releases)

[Get Started](#-getting-started) • [Documentation](docs/EN.md) • [Examples](#-examples) • [Community](#-community)

</div>

<br>

## ⚡ Getting Started

### Quick Install

```bash
# Linux & macOS
curl -sSL https://raw.githubusercontent.com/ogcae/fuero/main/install.sh | bash

# Windows
iwr -useb https://raw.githubusercontent.com/ogcae/fuero/main/install.ps1 | iex
```

### Your First Program

```fuero
# hello.fuero
let name = "World"
print("Hello, " + name + "!")

func fibonacci(n) {
    if (n <= 1) return n
    return fibonacci(n - 1) + fibonacci(n - 2)
}

print("Fibonacci(10):", fibonacci(10))
```

```bash
fuero run hello.fuero
```

<br>

## 🎯 Why Fuero?

<table>
<tr>
<td width="50%">

**🚀 Built for Speed**
```fuero
import http

let response = http.get("https://api.github.com")
print(response.json().message)
```

</td>
<td width="50%">

**🧮 Rich Standard Library**
```fuero
import math, string, crypto

let hash = crypto.sha256("secret")
let result = math.fibonacci(10)
let clean = string.title("hello world")
```

</td>
</tr>
<tr>
<td>

**🎨 Clean Syntax**
```fuero
class User {
    func constructor(name, email) {
        this.name = name
        this.email = email
    }
    
    func greet() {
        return "Hi, I'm " + this.name
    }
}
```

</td>
<td>

**🤖 AI Integration**
```fuero
import ai

ai.set_api_key("openai", "your-key")
let poem = ai.generate_text("Write a haiku about code")
print(poem.text)
```

</td>
</tr>
</table>

<br>

## 📦 Built-in Modules

<details>
<summary><strong>🧮 Math</strong> - Mathematical operations and utilities</summary>

```fuero
import math

print(math.sqrt(16))        # 4.0
print(math.random())        # Random 0-1
print(math.fibonacci(10))   # 55
print(math.is_prime(17))    # true
print(math.factorial(5))    # 120
```

</details>

<details>
<summary><strong>🔤 String</strong> - Text manipulation and processing</summary>

```fuero
import string

let text = "Hello World"
print(string.upper(text))           # "HELLO WORLD"
print(string.reverse(text))         # "dlroW olleH"
print(string.word_count(text))      # 2
print(string.is_palindrome("mom"))  # true
print(string.slug(text))            # "hello-world"
```

</details>

<details>
<summary><strong>📄 JSON</strong> - JSON parsing and serialization</summary>

```fuero
import json

let user = {name: "Alice", age: 30, active: true}
let json_str = json.stringify(user)
let parsed = json.parse(json_str)

json.save_file(user, "user.json")
let loaded = json.load_file("user.json")
```

</details>

<details>
<summary><strong>🌐 HTTP</strong> - Web requests and API integration</summary>

```fuero
import http

# GET request
let response = http.get("https://api.github.com/users/octocat")
if (response.is_success()) {
    let user = response.json()
    print("Name:", user.name)
    print("Followers:", user.followers)
}

# POST request
let data = {title: "Hello", body: "World"}
let post_response = http.post_json("https://httpbin.org/post", data)
```

</details>

<details>
<summary><strong>🗄️ Database</strong> - SQLite database operations</summary>

```fuero
import database

database.connect_sqlite("app.db")

database.create_table("users", {
    id: "INTEGER PRIMARY KEY",
    name: "TEXT NOT NULL",
    email: "TEXT UNIQUE"
})

let user_id = database.insert("users", {
    name: "John Doe", 
    email: "john@example.com"
})

let users = database.select("users", where: "name LIKE ?", where_params: ["%John%"])
```

</details>

<details>
<summary><strong>🔐 Crypto</strong> - Cryptography and security</summary>

```fuero
import crypto

# Hashing
let hash = crypto.sha256("secret message")
let md5 = crypto.md5("data")

# Encryption
let key = crypto.generate_key()
let encrypted = crypto.encrypt("confidential", key)
let decrypted = crypto.decrypt(encrypted, key)

# Password hashing
let password_hash = crypto.hash_password("mypassword")
let is_valid = crypto.verify_password("mypassword", password_hash)
```

</details>

<details>
<summary><strong>🤖 AI</strong> - Artificial intelligence integration</summary>

```fuero
import ai

ai.set_api_key("openai", "your-api-key")

# Text generation
let story = ai.generate_text("Write a short story about a robot")
print(story.text)

# Sentiment analysis
let sentiment = ai.analyze_sentiment("I love programming!")
print("Sentiment:", sentiment.sentiment)  # "positive"
print("Confidence:", sentiment.confidence)  # 0.95
```

</details>

<br>

## 🚀 Examples

### Web Scraper
```fuero
import http, json

func get_github_user(username) {
    let url = "https://api.github.com/users/" + username
    let response = http.get(url)
    
    if (response.is_success()) {
        return response.json()
    }
    return null
}

let user = get_github_user("octocat")
if (user != null) {
    print("👤 " + user.name)
    print("📍 " + user.location)
    print("👥 " + str(user.followers) + " followers")
    print("📊 " + str(user.public_repos) + " repositories")
}
```

### Password Generator
```fuero
import crypto, string, math

func generate_password(length) {
    let chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
    let password = ""
    
    for (i in range(length)) {
        let index = math.randint(0, len(chars) - 1)
        password = password + chars[index]
    }
    
    return password
}

let secure_password = generate_password(16)
let hash = crypto.sha256(secure_password)

print("Password:", secure_password)
print("SHA256:", hash)
```

### Simple Web Server
```fuero
import http, json

func handle_request(request) {
    if (request.path == "/") {
        return {
            status: 200,
            body: "Welcome to Fuero Web Server!",
            headers: {"Content-Type": "text/plain"}
        }
    }
    
    if (request.path == "/api/time") {
        return {
            status: 200,
            body: json.stringify({timestamp: time.now()}),
            headers: {"Content-Type": "application/json"}
        }
    }
    
    return {status: 404, body: "Not Found"}
}

http.serve("localhost", 8080, handle_request)
print("Server running on http://localhost:8080")
```

<br>

## 📚 Documentation

| Language | Link |
|----------|------|
| 🇺🇸 English | [docs/EN.md](docs/EN.md) |
| 🇪🇸 Español | [docs/ES.md](docs/ES.md) |

<br>

## 🛠️ Development

```bash
# Clone repository
git clone https://github.com/ogcae/fuero
cd fuero

# Install dependencies
pip install -r requirements.txt

# Run tests
python -m pytest

# Run examples
fuero run examples/hello.fuero
fuero run examples/math_demo.fuero
fuero run examples/string_demo.fuero
```

<br>

## 🤝 Community

- 💬 [Discussions](https://github.com/ogcae/fuero/discussions)
- 🐛 [Issues](https://github.com/ogcae/fuero/issues)
- 📧 [Contact](mailto:ogcae@example.com)

<br>

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

---

<div align="center">

**Made with ❤️ by [ogcae](https://github.com/ogcae)**

*Simple • Clean • Functional*

</div>
