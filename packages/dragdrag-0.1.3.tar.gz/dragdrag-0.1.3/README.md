# dragdrag

局域网文件拖拽上传/下载/删除的Web应用。

## 安装

```bash
pip install dragdrag
```

## 使用

```bash
dragdrag
```

默认在5000端口启动，浏览器访问 http://本机IP:5000

## 功能
- 拖拽或选择文件上传
- 文件桌面式缩略图展示
- 点击文件下载，支持删除
- 上传进度条 