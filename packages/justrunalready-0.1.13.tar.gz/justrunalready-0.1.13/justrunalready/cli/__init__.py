"""CLI module for JustRunAlready."""
