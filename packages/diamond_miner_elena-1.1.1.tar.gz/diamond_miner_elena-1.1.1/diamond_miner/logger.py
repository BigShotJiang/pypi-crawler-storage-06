import logging

logger = logging.getLogger("diamond-miner")
