def main():
    print("Hello from npcpy!")

if __name__ == "__main__":
    main()