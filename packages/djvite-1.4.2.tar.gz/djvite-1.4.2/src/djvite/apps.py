from django.apps import AppConfig


class DjviteConfig(AppConfig):
    name = "djvite"
    verbose_name = "DjVite"
    models_module = None
