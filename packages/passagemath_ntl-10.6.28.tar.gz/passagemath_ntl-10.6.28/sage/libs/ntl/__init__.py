# sage_setup: distribution = sagemath-ntl
from sage.libs.ntl.error import setup_NTL_error_callback

setup_NTL_error_callback()
