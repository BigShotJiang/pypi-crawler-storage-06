
class NoSchemaError(BaseException):
    pass


class CloudFileNotFoundError(Exception):
    pass