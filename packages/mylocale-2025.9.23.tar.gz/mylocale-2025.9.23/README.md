## MyLocale
A simple python library for simple localisation.
# TODO
- [x] support for variables
# About
[Documentation](https://mylocale.readthedocs.io "Documentation")