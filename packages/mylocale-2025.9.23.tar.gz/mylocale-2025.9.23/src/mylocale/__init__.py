from mylocale.TR import TR
