MACHINES = {
    "composter": "compost"
}
VALUES = {
    "compost": {
        "sapling": 1,
        "spore": 1,
        "mushroom": 2,
        "carrot": 1,
        "bluebell": 3, 
    }
}