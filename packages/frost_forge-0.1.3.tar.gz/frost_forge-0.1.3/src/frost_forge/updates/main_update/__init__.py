from .menu_updates import update_menu
from .game_updates import update_game
from .chunk_updates import update_tiles