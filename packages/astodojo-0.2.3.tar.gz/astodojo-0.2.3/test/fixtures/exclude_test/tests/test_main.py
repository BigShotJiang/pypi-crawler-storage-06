"""
Test file - should be excluded with **/tests/** pattern.
"""

def test_function():
    # TODO: This should NOT appear in results
    # BLAME: This should also be excluded
    pass
