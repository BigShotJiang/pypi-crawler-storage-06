__version__ = "0.1.0"

# frida-server-manager (fsm) - A tool to manage frida-server on Android devices