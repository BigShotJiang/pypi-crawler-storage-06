"""Packaged static assets for Arbiter."""
