# khatab Library

هذه مكتبة بسيطة بلغة بايثون تقوم بعرض رسالة ترحيب باسم خطاب العصري.

## الاستخدام
```python
import khatab
print(khatab.welcome_message())
