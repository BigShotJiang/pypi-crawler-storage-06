
from setuptools import setup

setup(
    name="khatab",
    version="1.0",
    py_modules=["khatab"],
    install_requires=[],
    description="مكتبة بسيطة لعرض رسالة ترحيب باسم خطاب العصري",
    author="خطاب العصري",
    author_email="example@email.com",
    url="https://github.com/yourusername/khatab",
)
