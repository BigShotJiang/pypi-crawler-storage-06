# Others 
The `aiod` top-level module also provides some functions.

::: aiod
    options:
        members:
            - counts
            - get