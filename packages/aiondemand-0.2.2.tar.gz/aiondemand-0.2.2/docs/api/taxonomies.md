# Taxonomies 

::: aiod.taxonomies
    options:
      filters:
        - '!^_'
        - '!^EndpointUndefinedError'