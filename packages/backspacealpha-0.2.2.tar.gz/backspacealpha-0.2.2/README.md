# backspaceAlpha

[![License](https://img.shields.io/badge/license-BackspaceAlpha-blue.svg)](./LICENSE)
[![PyPI](https://img.shields.io/pypi/v/backspaceAlpha.svg)](https://pypi.org/project/backspaceAlpha/)

A simple backtesting framework with example strategies.
## Attribution
This software is licensed under the **BackspaceAlpha License v1.0**.  
Use of this software requires attribution
Modifications must be submitted via the official GitHub repository.