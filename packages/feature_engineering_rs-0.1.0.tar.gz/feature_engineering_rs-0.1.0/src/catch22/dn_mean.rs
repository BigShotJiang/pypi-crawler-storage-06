use crate::helpers::common::mean_f;

pub fn dn_mean(y: &[f64]) -> f64 {
    mean_f(y)
}
