use num_complex::Complex64;

pub type Cplx = Complex64;
