# PySujanam

Use this Python package to say hello to Sujanam.

## Installation

You can install the package using pip:

```bash
pip install pysujanam
```

## Usage
Here's a simple example of how to use the package:

```python
import sujanam
sujanam.hello() 
sujanam.hello("Alice")
```
