def hello(who=None):
  if not who: 
    print("Hello, my name is Sujanam!")
  else:
    print("Hello "+who+", my name is Sujanam!")
