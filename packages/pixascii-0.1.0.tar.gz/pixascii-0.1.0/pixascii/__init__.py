"""
PixASCII: A tool to convert images to ASCII art.
"""

__version__ = "0.1.0"
