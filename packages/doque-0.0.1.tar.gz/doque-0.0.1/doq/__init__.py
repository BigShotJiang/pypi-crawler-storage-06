"""DOQ - Command line interface for various LLM providers."""

__version__ = "1.0.0"
__author__ = "Yuriy Sagitov"
__email__ = "home_r@mail.ru"
__license__ = "Apache-2.0"
