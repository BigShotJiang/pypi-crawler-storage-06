"""Schemas for curating the output data from recipes."""
