"""Premade recipes for various codes."""
