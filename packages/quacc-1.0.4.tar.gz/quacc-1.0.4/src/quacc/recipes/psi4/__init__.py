"""Recipes for Psi4."""
