"""Recipes for machine-learned interatomic potentials."""
