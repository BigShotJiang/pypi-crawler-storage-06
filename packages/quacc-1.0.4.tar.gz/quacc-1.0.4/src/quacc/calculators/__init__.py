"""Enhanced versions of select ASE calculators."""
