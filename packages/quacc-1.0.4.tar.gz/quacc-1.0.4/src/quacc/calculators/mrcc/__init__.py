"""Calculator for using MRCC."""
