from .local_encoder import VoxCPMLocEnc
