from .core import VoxCPM

__all__ = [
    "VoxCPM",
]
