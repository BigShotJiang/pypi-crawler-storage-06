from primp import Client  # type: ignore


class Response: ...


__all__ = ["Client", "Response"]
