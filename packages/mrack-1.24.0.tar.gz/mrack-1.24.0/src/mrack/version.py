"""mrack library version."""

VERSION = "1.24.0"
