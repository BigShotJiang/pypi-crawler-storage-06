Injectables
===========

See the tutorial for more information on dependency injection.

Injectable
----------

.. autoclass:: guiml.injectables.Injectable
    :members:
    :undoc-members:
