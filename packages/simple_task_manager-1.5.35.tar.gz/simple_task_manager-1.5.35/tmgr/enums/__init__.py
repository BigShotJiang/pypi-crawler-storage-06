"""application enumerations
"""
from .lit_enum import LitEnum
from .lit_enum import CFGOrderEnum
from .lit_enum import FilterTaskKeyEnum
