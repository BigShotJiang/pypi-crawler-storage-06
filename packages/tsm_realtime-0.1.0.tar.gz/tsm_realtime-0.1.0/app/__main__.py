"""
Entry point for running the app as a module: python -m app
"""

from . import main

if __name__ == "__main__":
    main()
