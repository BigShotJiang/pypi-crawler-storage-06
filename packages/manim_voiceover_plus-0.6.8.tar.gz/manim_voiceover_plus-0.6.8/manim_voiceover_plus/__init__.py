from manim_voiceover_plus.tracker import VoiceoverTracker
from manim_voiceover_plus.voiceover_scene import VoiceoverScene

import pkg_resources

__version__: str = pkg_resources.get_distribution(__name__).version
