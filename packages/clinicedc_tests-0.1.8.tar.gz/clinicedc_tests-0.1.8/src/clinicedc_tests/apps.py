from django.apps import AppConfig as DjangoAppConfig


class AppConfig(DjangoAppConfig):
    name = "clinicedc_tests"
    verbose_name = "clinicedc_tests"
    app_label = "clinicedc_tests"
