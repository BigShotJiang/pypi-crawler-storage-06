import asyncio

from cuery.actors import geo

asyncio.run(geo.main())
