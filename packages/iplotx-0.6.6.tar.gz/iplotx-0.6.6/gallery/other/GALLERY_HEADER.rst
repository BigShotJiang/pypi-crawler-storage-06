Other
+++++

The following examples cover other areas of application of ``iplotx``.
