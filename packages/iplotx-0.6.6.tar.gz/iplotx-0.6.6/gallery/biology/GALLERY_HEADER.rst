Biology and Ecology
+++++++++++++++++++
Examples showcasing how to use ``iplotx`` to visualise biolotgical and ecological networks.
Examples for **trees** specifically, including phylogenetic trees, are found in the tree
gallery section.
