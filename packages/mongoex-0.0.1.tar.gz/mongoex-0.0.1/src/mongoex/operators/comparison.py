"""MongoDB comparison operators for MongoEX."""

# Comparison operators will be extracted from field.py
