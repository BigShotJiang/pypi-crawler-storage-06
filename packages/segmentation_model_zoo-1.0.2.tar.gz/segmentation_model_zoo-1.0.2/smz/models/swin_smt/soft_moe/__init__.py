from .soft_moe import SoftMoE
from .soft_moe_with_dynamic_slots import DynamicSlotsSoftMoE