.. _install:

Installation
============

Requirements
------------

+ Python 3.10 or higher

  * https://www.python.org/

+ pip and setuptools

  * https://pypi.org/project/pip/
  * https://pypi.org/project/setuptools/

Install
-------

Should be easy as::

    python -m pip install --upgrade crc-ct
