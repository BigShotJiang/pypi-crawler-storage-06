crc documentation
=================

.. _readme:
.. include:: README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   install.rst
   userguide.rst
   CHANGES.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
