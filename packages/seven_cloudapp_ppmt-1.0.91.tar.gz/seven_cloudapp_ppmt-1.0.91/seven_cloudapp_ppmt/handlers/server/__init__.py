# -*- coding: utf-8 -*-
"""
:Author: HuangJingCan
:Date: 2020-04-16 14:38:22
@LastEditTime: 2022-07-13 14:10:31
@LastEditors: HuangJianYi
:description: 
"""
__all__ = ["act_s", "app_s", "machine_s", "order_s", "prize_s", "report_s", "throw_s", "user_s", "power_s", "theme_s","launch_s"]
