---
weight: 300
title: "Core Thinking"
description: "Core Thinking"
icon: "edit"
date: "2023-05-22T00:34:57+01:00"
lastmod: "2023-05-22T00:34:57+01:00"
draft: false
---