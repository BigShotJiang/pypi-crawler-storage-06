"""Initialization of boilerplates package."""

import typing as t

__all__: t.List[str] = []
