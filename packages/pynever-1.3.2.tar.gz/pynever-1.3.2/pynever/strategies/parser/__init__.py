import logging

PARSER_LOGGER = logging.getLogger("pynever.strategies.parser")
