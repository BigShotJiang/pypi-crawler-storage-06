import logging

LOGGER_EMPTY = logging.getLogger("pynever.strategies.abstraction.empty_times")
LOGGER_LP = logging.getLogger("pynever.strategies.abstraction.lp_times")
LOGGER_LB = logging.getLogger("pynever.strategies.abstraction.lb_times")
LOGGER_UB = logging.getLogger("pynever.strategies.abstraction.ub_times")
LOGGER_LAYER = logging.getLogger('pynever.strategies.abstraction.layers')

ABSTRACTION_PRECISION_GUARD = 10e-15
