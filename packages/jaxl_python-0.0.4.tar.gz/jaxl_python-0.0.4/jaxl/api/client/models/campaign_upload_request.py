"""
Copyright (c) 2010-present by Jaxl Innovations Private Limited.

All rights reserved.

Redistribution and use in source and binary forms,
with or without modification, is strictly prohibited.
"""

import datetime
import json
from io import BytesIO
from typing import TYPE_CHECKING, Any, Dict, List, Tuple, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..models.campaign_upload_type_enum import CampaignUploadTypeEnum
from ..models.content_type_enum import ContentTypeEnum
from ..types import UNSET, File, Unset


if TYPE_CHECKING:
    from ..models.campaign_upload_request_options import (
        CampaignUploadRequestOptions,
    )
    from ..models.campaign_window_request import CampaignWindowRequest


T = TypeVar("T", bound="CampaignUploadRequest")


@attr.s(auto_attribs=True)
class CampaignUploadRequest:
    """
    Attributes:
        specification (File):
        content_type (ContentTypeEnum):
        type (CampaignUploadTypeEnum):
        jaxl_id (str):
        run_at (Union[Unset, None, datetime.datetime]):
        recharge (Union[Unset, None, str]):
        currency (Union[Unset, None, int]):
        template (Union[Unset, str]):
        window (Union[Unset, None, CampaignWindowRequest]):
        auto_retry (Union[Unset, bool]):
        cc (Union[Unset, None, str]):
        options (Union[Unset, None, CampaignUploadRequestOptions]):
    """

    specification: File
    content_type: ContentTypeEnum
    type: CampaignUploadTypeEnum
    jaxl_id: str
    run_at: Union[Unset, None, datetime.datetime] = UNSET
    recharge: Union[Unset, None, str] = UNSET
    currency: Union[Unset, None, int] = UNSET
    template: Union[Unset, str] = UNSET
    window: Union[Unset, None, "CampaignWindowRequest"] = UNSET
    auto_retry: Union[Unset, bool] = False
    cc: Union[Unset, None, str] = UNSET
    options: Union[Unset, None, "CampaignUploadRequestOptions"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        specification = self.specification.to_tuple()

        content_type = self.content_type.value

        type = self.type.value

        jaxl_id = self.jaxl_id
        run_at: Union[Unset, None, str] = UNSET
        if not isinstance(self.run_at, Unset):
            run_at = self.run_at.isoformat() if self.run_at else None

        recharge = self.recharge
        currency = self.currency
        template = self.template
        window: Union[Unset, None, Dict[str, Any]] = UNSET
        if not isinstance(self.window, Unset):
            window = self.window.to_dict() if self.window else None

        auto_retry = self.auto_retry
        cc = self.cc
        options: Union[Unset, None, Dict[str, Any]] = UNSET
        if not isinstance(self.options, Unset):
            options = self.options.to_dict() if self.options else None

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "specification": specification,
                "content_type": content_type,
                "type": type,
                "jaxl_id": jaxl_id,
            }
        )
        if run_at is not UNSET:
            field_dict["run_at"] = run_at
        if recharge is not UNSET:
            field_dict["recharge"] = recharge
        if currency is not UNSET:
            field_dict["currency"] = currency
        if template is not UNSET:
            field_dict["template"] = template
        if window is not UNSET:
            field_dict["window"] = window
        if auto_retry is not UNSET:
            field_dict["auto_retry"] = auto_retry
        if cc is not UNSET:
            field_dict["cc"] = cc
        if options is not UNSET:
            field_dict["options"] = options

        return field_dict

    def to_multipart(self) -> Dict[str, Any]:
        specification = self.specification.to_tuple()

        content_type = (None, str(self.content_type.value).encode(), "text/plain")

        type = (None, str(self.type.value).encode(), "text/plain")

        jaxl_id = (
            self.jaxl_id
            if isinstance(self.jaxl_id, Unset)
            else (None, str(self.jaxl_id).encode(), "text/plain")
        )
        run_at: Union[Unset, None, bytes] = UNSET
        if not isinstance(self.run_at, Unset):
            run_at = self.run_at.isoformat().encode() if self.run_at else None

        recharge = (
            self.recharge
            if isinstance(self.recharge, Unset)
            else (None, str(self.recharge).encode(), "text/plain")
        )
        currency = (
            self.currency
            if isinstance(self.currency, Unset)
            else (None, str(self.currency).encode(), "text/plain")
        )
        template = (
            self.template
            if isinstance(self.template, Unset)
            else (None, str(self.template).encode(), "text/plain")
        )
        window: Union[Unset, Tuple[None, bytes, str]] = UNSET
        if not isinstance(self.window, Unset):
            window = (
                (None, json.dumps(self.window.to_dict()).encode(), "application/json")
                if self.window
                else UNSET
            )

        auto_retry = (
            self.auto_retry
            if isinstance(self.auto_retry, Unset)
            else (None, str(self.auto_retry).encode(), "text/plain")
        )
        cc = (
            self.cc
            if isinstance(self.cc, Unset)
            else (None, str(self.cc).encode(), "text/plain")
        )
        options: Union[Unset, Tuple[None, bytes, str]] = UNSET
        if not isinstance(self.options, Unset):
            options = (
                (None, json.dumps(self.options.to_dict()).encode(), "application/json")
                if self.options
                else UNSET
            )

        field_dict: Dict[str, Any] = {}
        field_dict.update(
            {
                key: (None, str(value).encode(), "text/plain")
                for key, value in self.additional_properties.items()
            }
        )
        field_dict.update(
            {
                "specification": specification,
                "content_type": content_type,
                "type": type,
                "jaxl_id": jaxl_id,
            }
        )
        if run_at is not UNSET:
            field_dict["run_at"] = run_at
        if recharge is not UNSET:
            field_dict["recharge"] = recharge
        if currency is not UNSET:
            field_dict["currency"] = currency
        if template is not UNSET:
            field_dict["template"] = template
        if window is not UNSET:
            field_dict["window"] = window
        if auto_retry is not UNSET:
            field_dict["auto_retry"] = auto_retry
        if cc is not UNSET:
            field_dict["cc"] = cc
        if options is not UNSET:
            field_dict["options"] = options

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.campaign_upload_request_options import (
            CampaignUploadRequestOptions,
        )
        from ..models.campaign_window_request import CampaignWindowRequest

        d = src_dict.copy()
        specification = File(payload=BytesIO(d.pop("specification")))

        content_type = ContentTypeEnum(d.pop("content_type"))

        type = CampaignUploadTypeEnum(d.pop("type"))

        jaxl_id = d.pop("jaxl_id")

        _run_at = d.pop("run_at", UNSET)
        run_at: Union[Unset, None, datetime.datetime]
        if _run_at is None:
            run_at = None
        elif isinstance(_run_at, Unset):
            run_at = UNSET
        else:
            run_at = isoparse(_run_at)

        recharge = d.pop("recharge", UNSET)

        currency = d.pop("currency", UNSET)

        template = d.pop("template", UNSET)

        _window = d.pop("window", UNSET)
        window: Union[Unset, None, CampaignWindowRequest]
        if _window is None:
            window = None
        elif isinstance(_window, Unset):
            window = UNSET
        else:
            window = CampaignWindowRequest.from_dict(_window)

        auto_retry = d.pop("auto_retry", UNSET)

        cc = d.pop("cc", UNSET)

        _options = d.pop("options", UNSET)
        options: Union[Unset, None, CampaignUploadRequestOptions]
        if _options is None:
            options = None
        elif isinstance(_options, Unset):
            options = UNSET
        else:
            options = CampaignUploadRequestOptions.from_dict(_options)

        campaign_upload_request = cls(
            specification=specification,
            content_type=content_type,
            type=type,
            jaxl_id=jaxl_id,
            run_at=run_at,
            recharge=recharge,
            currency=currency,
            template=template,
            window=window,
            auto_retry=auto_retry,
            cc=cc,
            options=options,
        )

        campaign_upload_request.additional_properties = d
        return campaign_upload_request

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
