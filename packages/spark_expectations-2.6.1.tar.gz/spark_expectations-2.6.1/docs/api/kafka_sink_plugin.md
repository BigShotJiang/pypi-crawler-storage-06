---
search:
  exclude: true
---

::: spark_expectations.sinks.plugins.kafka_writer
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"