---
search:
  exclude: true
---

::: spark_expectations.examples.base_setup
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"
        