---
search:
  exclude: true
---


::: spark_expectations.notifications.plugins.base_notification
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"