---
search:
  exclude: true
---

::: spark_expectations.core.exceptions
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"
        