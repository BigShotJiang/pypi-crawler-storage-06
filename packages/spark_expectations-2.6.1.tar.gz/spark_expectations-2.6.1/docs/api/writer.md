---
search:
  exclude: true
---

::: spark_expectations.sinks.utils.writer
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"
        