---
search:
  exclude: true
---

::: spark_expectations.sinks
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^__[^__]"