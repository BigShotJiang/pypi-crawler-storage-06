#!/bin/bash

# stop kafka cluster
$KAFKA_HOME/bin/kafka-server-stop.sh

# stop zookeeper instances
#$KAFKA_HOME/bin/zookeeper-server-stop.sh
