"""A lil' bud that helps you with stuff (it's a utility CLI)."""
