"""VeSync API Library."""

from pyvesync.vesync import VeSync

__all__ = ['VeSync']
