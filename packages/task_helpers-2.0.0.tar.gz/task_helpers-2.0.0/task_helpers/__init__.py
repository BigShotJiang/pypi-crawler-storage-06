__title__ = "Task helpers"
__version__ = "2.0.0"
__author__ = "Viacheslav Loievskyi"
__license__ = "BSD 3-Clause"
