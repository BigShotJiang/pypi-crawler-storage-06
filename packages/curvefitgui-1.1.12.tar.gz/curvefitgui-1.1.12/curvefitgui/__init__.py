

from ._settings import settings
from ._curvefitgui import curve_fit_gui
from ._curvefitgui import linear_fit_gui

from ._version import __version__
CFGversion = __version__