This section of the documentation focuses on guiding end-users through the
various aspects of Formulaic likely to be useful in day-to-day workflows. Feel
free to pick and choose which modules you peruse, but note that later modules
may assume knowledge of content described in earlier modules.

If you are a developer of another library looking to leverage Formulaic
internally to your code, or are looking to contribute directly to Formulaic, it is recommended to also review the [Developer Guides](/dev/).
