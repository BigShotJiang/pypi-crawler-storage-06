"""
GeneBot CLI Package
==================

Modular command-line interface for the GeneBot trading bot.
"""


__all__ = ['main', 'CLIContext', 'CommandResult']