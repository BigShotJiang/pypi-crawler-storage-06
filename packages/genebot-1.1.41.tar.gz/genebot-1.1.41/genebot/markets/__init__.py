"""
Markets module for genebot package.
"""


__all__ = ['MarketType', 'UnifiedSymbol']