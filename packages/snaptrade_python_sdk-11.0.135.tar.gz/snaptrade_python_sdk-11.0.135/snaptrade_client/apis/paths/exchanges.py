from snaptrade_client.paths.exchanges.get import ApiForget


class Exchanges(
    ApiForget,
):
    pass
