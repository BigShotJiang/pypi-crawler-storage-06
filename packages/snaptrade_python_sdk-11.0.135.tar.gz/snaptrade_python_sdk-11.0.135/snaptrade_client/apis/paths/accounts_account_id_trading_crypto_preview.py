from snaptrade_client.paths.accounts_account_id_trading_crypto_preview.post import ApiForpost


class AccountsAccountIdTradingCryptoPreview(
    ApiForpost,
):
    pass
