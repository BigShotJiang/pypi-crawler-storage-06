from snaptrade_client.paths.snap_trade_list_users.get import ApiForget


class SnapTradeListUsers(
    ApiForget,
):
    pass
