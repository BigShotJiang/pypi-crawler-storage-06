"""Data management modules for genebot."""

__all__ = []