# Q-CTRL MkDocs Theme

The Q-CTRL MkDocs Theme is a highly opinionated and very low configuration theme for making consistent Q-CTRL project documentation using [MkDocs](https://www.mkdocs.org).

## Installation and usage

See the [documentation](https://qctrl.github.io/mkdocs-theme) for detailed installation and usage instructions.
