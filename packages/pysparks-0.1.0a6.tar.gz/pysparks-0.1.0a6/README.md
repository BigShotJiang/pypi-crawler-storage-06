# SPARKS
### Software for Polymerization And Reaction Kinetic Simulations

## Quick Install

```bash
pip install pysparks
```