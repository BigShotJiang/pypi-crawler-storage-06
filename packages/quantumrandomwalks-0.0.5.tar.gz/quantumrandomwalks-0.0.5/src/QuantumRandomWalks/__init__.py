from .QRW import QuantumRandomWalk
from .QRW import perform_one_node_walk
from .QRW import perform_superpositioned_walk