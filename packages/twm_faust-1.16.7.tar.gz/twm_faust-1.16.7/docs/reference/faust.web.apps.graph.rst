=====================================================
 ``faust.web.apps.graph``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.apps.graph

.. automodule:: faust.web.apps.graph
    :members:
    :undoc-members:
