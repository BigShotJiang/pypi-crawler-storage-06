=====================================================
 ``faust.transport.consumer``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.transport.consumer

.. automodule:: faust.transport.consumer
    :members:
    :undoc-members:
