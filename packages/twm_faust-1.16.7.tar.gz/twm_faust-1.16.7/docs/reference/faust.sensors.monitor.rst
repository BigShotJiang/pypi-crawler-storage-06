=====================================================
 ``faust.sensors.monitor``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.sensors.monitor

.. automodule:: faust.sensors.monitor
    :members:
    :undoc-members:
