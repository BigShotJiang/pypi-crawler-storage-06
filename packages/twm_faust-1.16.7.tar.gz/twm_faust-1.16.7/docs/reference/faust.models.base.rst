=====================================================
 ``faust.models.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.models.base

.. automodule:: faust.models.base
    :members:
    :undoc-members:
