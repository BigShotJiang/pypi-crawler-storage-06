=====================================================
 ``faust.cli.worker``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.worker

.. automodule:: faust.cli.worker
    :members:
    :undoc-members:
