=====================================================
 ``faust.sensors.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.sensors.base

.. automodule:: faust.sensors.base
    :members:
    :undoc-members:
