=====================================================
 ``faust.web.cache``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.cache

.. automodule:: faust.web.cache
    :members:
    :undoc-members:
