=====================================================
 ``faust.web.cache.backends.redis``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.cache.backends.redis

.. automodule:: faust.web.cache.backends.redis
    :members:
    :undoc-members:
