=====================================================
 ``faust.types.core``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.core

.. automodule:: faust.types.core
    :members:
    :undoc-members:
