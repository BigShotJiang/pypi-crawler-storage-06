=====================================================
 ``faust.stores.memory``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.stores.memory

.. automodule:: faust.stores.memory
    :members:
    :undoc-members:
