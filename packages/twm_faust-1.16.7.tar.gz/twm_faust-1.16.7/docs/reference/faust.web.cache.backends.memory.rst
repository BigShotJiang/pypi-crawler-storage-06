=====================================================
 ``faust.web.cache.backends.memory``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.cache.backends.memory

.. automodule:: faust.web.cache.backends.memory
    :members:
    :undoc-members:
