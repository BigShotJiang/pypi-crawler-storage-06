=====================================================
 ``faust.tables.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.tables.base

.. automodule:: faust.tables.base
    :members:
    :undoc-members:
