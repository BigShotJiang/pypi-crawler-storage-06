=====================================================
 ``faust.types.channels``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.channels

.. automodule:: faust.types.channels
    :members:
    :undoc-members:
