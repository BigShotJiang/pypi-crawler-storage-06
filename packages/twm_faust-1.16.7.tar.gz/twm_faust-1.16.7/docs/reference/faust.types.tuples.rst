=====================================================
 ``faust.types.tuples``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.tuples

.. automodule:: faust.types.tuples
    :members:
    :undoc-members:
