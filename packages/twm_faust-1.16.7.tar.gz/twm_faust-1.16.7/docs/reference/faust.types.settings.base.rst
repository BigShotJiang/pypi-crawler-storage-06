=====================================================
 ``faust.types.settings.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.settings.base

.. automodule:: faust.types.settings.base
    :members:
    :undoc-members:
