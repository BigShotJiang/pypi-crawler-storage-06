=====================================================
 ``faust.livecheck.locals``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.livecheck.locals

.. automodule:: faust.livecheck.locals
    :members:
    :undoc-members:
