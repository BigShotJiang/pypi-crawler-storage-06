=====================================================
 ``faust.cli.faust``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.faust

.. automodule:: faust.cli.faust
    :members:
    :undoc-members:
