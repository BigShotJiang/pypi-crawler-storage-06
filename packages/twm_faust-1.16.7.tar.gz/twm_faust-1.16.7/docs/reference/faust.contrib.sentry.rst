=====================================================
 ``faust.contrib.sentry``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.contrib.sentry

.. automodule:: faust.contrib.sentry
    :members:
    :undoc-members:
