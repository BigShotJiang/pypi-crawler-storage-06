=====================================================
 ``faust.utils.platforms``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.utils.platforms

.. automodule:: faust.utils.platforms
    :members:
    :undoc-members:
