.. _installation:

=================================
 Installation
=================================

.. contents::
    :local:
    :depth: 1

.. include:: ../includes/installation.txt
