from proj324 import app


@app.command()
async def myprocesscommandi324():
    print('HELLO WORLD #324')
