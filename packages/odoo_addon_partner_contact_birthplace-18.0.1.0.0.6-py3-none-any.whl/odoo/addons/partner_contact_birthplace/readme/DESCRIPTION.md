This module extends the functionality of Odoo to support setting a
bithplace city and allows you to benefit of a clearer API and UI.
