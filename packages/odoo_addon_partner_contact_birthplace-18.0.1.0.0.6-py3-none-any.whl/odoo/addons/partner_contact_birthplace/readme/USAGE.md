To use this module, you need to:

-  Edit or create a partner.
-  Ensure it is **not** a company.
-  Go to the Personal Information sheet.
-  Set the birthplace there.

![partner_form](../static/description/partner_form.png)
