class UnknownConfigFormatError(Exception):
    pass
