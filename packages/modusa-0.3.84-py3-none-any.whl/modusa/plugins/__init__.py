#!/usr/bin/env python3

from .base import ModusaPlugin