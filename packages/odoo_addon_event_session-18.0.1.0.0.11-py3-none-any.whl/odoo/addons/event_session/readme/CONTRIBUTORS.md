- [Tecnativa](https://www.tecnativa.com):

  - Sergio Teruel
  - David Vidal
  - Carlos Roca
  - Stefan Ungureanu
  - Víctor Martínez

- Nikos Tsirintanis \<<ntsirintanis@therp.nl>\>

- David Alonso \<<david.alonso@solvos.es>\>

- [Moka Tourisme](https://www.mokatourisme.fr)

  > - Iván Todorovich \<<ivan.todorovich@gmail.com>\>
