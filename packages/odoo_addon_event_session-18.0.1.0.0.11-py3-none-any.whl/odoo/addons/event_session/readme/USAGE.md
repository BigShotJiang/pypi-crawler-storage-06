You can either:

- Go to Events \> Sessions and create some sessions associated with an
  event.
- Go to an event and use the sessions wizard to create all your event
  sessions according to a given schedule.
