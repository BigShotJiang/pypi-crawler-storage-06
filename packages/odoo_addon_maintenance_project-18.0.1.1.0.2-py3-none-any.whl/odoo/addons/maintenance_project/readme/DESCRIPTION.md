This module extends the functionality of Odoo Maintenance module adding
this features:

- Adds a project to an equipment. You can link an existing project or
  create a new one (with the Create project button) after creating the
  equipment.
- Adds project and task to a maintenance request. The default project
  for a request will be the equipment one, including the preventive
  requests periodically created.

This is is a technical addon to allow timesheet assignment to a
maintenance request.
