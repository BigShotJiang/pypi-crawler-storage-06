# Pumping base classes

Allows fetching external data via API and store it in database.
Supports full and partial modes.

See `pumpe/pumps/model_test.py` for example.