Node = tuple[int, int]
Edge = tuple[Node, Node]
