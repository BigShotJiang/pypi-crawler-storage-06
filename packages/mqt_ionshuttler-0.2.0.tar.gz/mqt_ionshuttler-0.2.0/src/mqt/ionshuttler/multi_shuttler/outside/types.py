Node = tuple[float, float]
Edge = tuple[Node, Node]
