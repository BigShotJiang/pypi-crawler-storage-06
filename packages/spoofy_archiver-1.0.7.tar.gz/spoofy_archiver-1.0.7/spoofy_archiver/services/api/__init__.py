"""Spoofy Archiver API Module."""

from .main import SpoofyAPISession

__all__ = ["SpoofyAPISession"]
