"""Spoofy API Cache Service."""

from .main import SpoofyAPICacheDB

__all__ = ["SpoofyAPICacheDB"]
