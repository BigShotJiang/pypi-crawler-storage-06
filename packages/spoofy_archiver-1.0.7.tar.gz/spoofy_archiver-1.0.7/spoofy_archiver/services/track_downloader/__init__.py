"""Spoofy Track Downloader Service."""

from .main import SpoofyTrackDownloader

__all__ = [
    "SpoofyTrackDownloader",
]
