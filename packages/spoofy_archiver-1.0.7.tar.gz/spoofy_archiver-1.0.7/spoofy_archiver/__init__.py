"""Python App spoofyarchiver."""

from spoofy_archiver.utils.logger import setup_logger

__version__ = "1.0.7"  # This is the version of the app, used in pyproject.toml, enforced in a test.

setup_logger()
