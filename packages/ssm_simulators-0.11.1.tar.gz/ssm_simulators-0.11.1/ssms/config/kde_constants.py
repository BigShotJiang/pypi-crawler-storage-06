KDE_NO_DISPLACE_T = [  # noqa: D100
    "full_ddm_rv",
    "full_ddm",
    "ddm_st",
    "ddm_truncnormt",
    "ddm_rayleight",
]
