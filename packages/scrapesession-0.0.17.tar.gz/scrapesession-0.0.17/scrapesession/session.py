"""Parameters for the requests session."""

DEFAULT_TIMEOUT = 16.0
