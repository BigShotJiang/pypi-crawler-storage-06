from typing import TypedDict


# Text content block
class TextContent(TypedDict):
    text: str
