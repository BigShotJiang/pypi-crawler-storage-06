# Decorators

::: fastdi.decorators