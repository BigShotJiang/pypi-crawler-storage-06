"""Module for Nue quirks implementations."""
