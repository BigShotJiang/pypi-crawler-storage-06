"""Quirks for Plaid Systems devices."""

PLAID_SYSTEMS = "PLAID SYSTEMS"
