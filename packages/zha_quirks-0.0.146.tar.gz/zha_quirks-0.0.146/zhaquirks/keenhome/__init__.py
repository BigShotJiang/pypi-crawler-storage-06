"""Module for keen home vents and sensors."""
