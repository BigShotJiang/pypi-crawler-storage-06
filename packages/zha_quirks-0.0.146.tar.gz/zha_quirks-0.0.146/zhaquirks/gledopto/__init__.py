"""Module for Gledopto quirks implementations."""

GLEDOPTO = "GLEDOPTO"
