"""Module for LiXee devices quirks."""

LIXEE = "LiXee"

ZLINKY_MANUFACTURER_CLUSTER_ID = 0xFF66
