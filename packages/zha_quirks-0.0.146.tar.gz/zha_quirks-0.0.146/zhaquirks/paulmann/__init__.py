"""Paulmann module."""

PAULMANN = "Paulmann LichtGmbH"
PAULMANN_VARIANT = "Paulmann Licht GmbH"
