"""Module for FeiBit quirk implementations."""

FEIBIT = "FeiBit"
