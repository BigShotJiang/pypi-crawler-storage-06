"""AWS Blogs MCP Server - Fetch and search AWS blog content."""

__version__ = "0.1.0"