=====
Usage
=====

To use the SEAMM Widgets in a project::

    import seamm_widgets
