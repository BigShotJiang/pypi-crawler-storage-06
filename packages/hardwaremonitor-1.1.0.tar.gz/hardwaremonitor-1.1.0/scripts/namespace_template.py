# Generated namespace __init__.py file for 'HardwareMonitor.{submodule_name}'

from {namespace_root}.{submodule_name} import *
