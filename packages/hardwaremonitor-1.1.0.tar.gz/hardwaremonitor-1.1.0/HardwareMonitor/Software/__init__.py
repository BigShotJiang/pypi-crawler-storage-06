# Generated namespace __init__.py file for 'HardwareMonitor.Software'

from LibreHardwareMonitor.Software import *
