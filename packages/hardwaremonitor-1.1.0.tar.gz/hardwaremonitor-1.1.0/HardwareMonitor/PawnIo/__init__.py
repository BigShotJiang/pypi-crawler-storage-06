# Generated namespace __init__.py file for 'HardwareMonitor.PawnIo'

from LibreHardwareMonitor.PawnIo import *
