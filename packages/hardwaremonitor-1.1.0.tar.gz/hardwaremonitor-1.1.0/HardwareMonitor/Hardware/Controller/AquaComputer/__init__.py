# Generated namespace __init__.py file for 'HardwareMonitor.Hardware.Controller.AquaComputer'

from LibreHardwareMonitor.Hardware.Controller.AquaComputer import *
