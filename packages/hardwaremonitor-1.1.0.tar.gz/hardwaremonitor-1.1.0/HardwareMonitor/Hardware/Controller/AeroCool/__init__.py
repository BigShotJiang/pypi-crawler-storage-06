# Generated namespace __init__.py file for 'HardwareMonitor.Hardware.Controller.AeroCool'

from LibreHardwareMonitor.Hardware.Controller.AeroCool import *
