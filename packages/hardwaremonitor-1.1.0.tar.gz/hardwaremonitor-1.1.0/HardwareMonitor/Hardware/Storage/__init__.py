# Generated namespace __init__.py file for 'HardwareMonitor.Hardware.Storage'

from LibreHardwareMonitor.Hardware.Storage import *
