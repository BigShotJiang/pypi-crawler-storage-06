# Generated namespace __init__.py file for 'HardwareMonitor.Hardware.Psu.Corsair'

from LibreHardwareMonitor.Hardware.Psu.Corsair import *
