# Generated namespace __init__.py file for 'HardwareMonitor.Hardware.Cpu'

from LibreHardwareMonitor.Hardware.Cpu import *
