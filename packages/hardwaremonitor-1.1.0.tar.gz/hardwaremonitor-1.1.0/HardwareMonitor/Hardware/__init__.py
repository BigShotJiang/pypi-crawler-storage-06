# Generated namespace __init__.py file for 'HardwareMonitor.Hardware'

from LibreHardwareMonitor.Hardware import *
