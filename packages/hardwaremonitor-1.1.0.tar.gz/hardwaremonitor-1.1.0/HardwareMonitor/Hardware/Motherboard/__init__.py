# Generated namespace __init__.py file for 'HardwareMonitor.Hardware.Motherboard'

from LibreHardwareMonitor.Hardware.Motherboard import *
