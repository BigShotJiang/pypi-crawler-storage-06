# Generated namespace __init__.py file for 'HardwareMonitor.Hardware.Motherboard.Lpc.EC'

from LibreHardwareMonitor.Hardware.Motherboard.Lpc.EC import *
