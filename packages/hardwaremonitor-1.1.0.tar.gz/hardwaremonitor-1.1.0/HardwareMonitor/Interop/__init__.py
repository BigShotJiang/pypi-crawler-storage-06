# Generated namespace __init__.py file for 'HardwareMonitor.Interop'

from LibreHardwareMonitor.Interop import *
