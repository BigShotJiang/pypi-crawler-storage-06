from xpublish_tiles.xpublish.wms.plugin import WMSPlugin

__all__ = ["WMSPlugin"]
