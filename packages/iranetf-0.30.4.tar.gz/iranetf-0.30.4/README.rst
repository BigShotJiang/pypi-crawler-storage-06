A library for fetching data from ETF websites active on the Tehran Stock Exchange.
