from wax.some_file import hello

__all__ = ["hello"]
