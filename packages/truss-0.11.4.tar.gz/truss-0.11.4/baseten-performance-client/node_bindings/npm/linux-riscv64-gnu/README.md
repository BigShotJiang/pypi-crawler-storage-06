# `@basetenlabs/performance-client-linux-riscv64-gnu`

This is the **riscv64gc-unknown-linux-gnu** binary for `@basetenlabs/performance-client`
