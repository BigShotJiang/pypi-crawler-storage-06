The base module used by sale_stock_picking_invoice_link and purchase_stock_picking_invoice_link 
to adds a link between pickings and invoices as well as on the lines.
