m = 1.
cm = 1e-2
um = 1e-6
mm = 1e-3
nm = 1e-9
W = 1
