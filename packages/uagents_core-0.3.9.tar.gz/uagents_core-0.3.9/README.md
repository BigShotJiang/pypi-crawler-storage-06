# uAgents-Core

Core definitions and functionalities to build agent which can interact and integrate with Fetch.ai ecosystem and agent marketplace.
