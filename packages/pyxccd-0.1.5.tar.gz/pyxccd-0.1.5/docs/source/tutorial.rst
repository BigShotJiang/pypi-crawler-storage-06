Python tutorial
=================

This document explains how to use pyxccd to facilitate scientific studies and enable land disturbance monitoring based upon multi-source time series. 
Some advanced topics are glossed over to be covered in more detail
elsewhere in pyxccd documentation. Only the CSV format is used here,
but the examples do apply to raster-based time series formats.