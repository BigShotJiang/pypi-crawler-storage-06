"""Server entry points for the Personal Document Library."""
