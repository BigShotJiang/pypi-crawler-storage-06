"""工具函数模块。"""

from .response import error_response

__all__ = ["error_response"]
