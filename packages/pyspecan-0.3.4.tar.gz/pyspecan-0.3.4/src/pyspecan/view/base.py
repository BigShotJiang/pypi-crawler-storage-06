"""Initialize View base class"""
class View:
    """Parent view class"""
    def mainloop(self):
        """Initialize the view"""

    def quit(self):
        """Gracefully exit"""
