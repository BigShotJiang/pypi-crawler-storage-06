# sage_setup: distribution = sagemath-planarity
# delvewheel: patch

from sage.all__sagemath_graphs import *
