# coding: UTF-8
import sys
bstack1l11l1_opy_ = sys.version_info [0] == 2
bstack11llll_opy_ = 2048
bstack1l111ll_opy_ = 7
def bstack1l11l11_opy_ (bstack1l11_opy_):
    global bstack1lll11_opy_
    bstack11l11ll_opy_ = ord (bstack1l11_opy_ [-1])
    bstack1ll11_opy_ = bstack1l11_opy_ [:-1]
    bstack1llllll_opy_ = bstack11l11ll_opy_ % len (bstack1ll11_opy_)
    bstack1l1l1l_opy_ = bstack1ll11_opy_ [:bstack1llllll_opy_] + bstack1ll11_opy_ [bstack1llllll_opy_:]
    if bstack1l11l1_opy_:
        bstack11ll_opy_ = unicode () .join ([unichr (ord (char) - bstack11llll_opy_ - (bstack11ll1l1_opy_ + bstack11l11ll_opy_) % bstack1l111ll_opy_) for bstack11ll1l1_opy_, char in enumerate (bstack1l1l1l_opy_)])
    else:
        bstack11ll_opy_ = str () .join ([chr (ord (char) - bstack11llll_opy_ - (bstack11ll1l1_opy_ + bstack11l11ll_opy_) % bstack1l111ll_opy_) for bstack11ll1l1_opy_, char in enumerate (bstack1l1l1l_opy_)])
    return eval (bstack11ll_opy_)
from browserstack_sdk.sdk_cli.bstack1lll11l11l1_opy_ import bstack1lll1l11l1l_opy_
from browserstack_sdk.sdk_cli.bstack1lllll11111_opy_ import (
    bstack1llll1lllll_opy_,
    bstack1llllll1lll_opy_,
    bstack1llll1llll1_opy_,
)
from browserstack_sdk.sdk_cli.bstack1lll1l11111_opy_ import bstack1lll111l11l_opy_
from typing import Tuple, Callable, Any
import grpc
from browserstack_sdk import sdk_pb2 as structs
from browserstack_sdk.sdk_cli.bstack1lll11l11l1_opy_ import bstack1lll1l11l1l_opy_
from bstack_utils.measure import measure
from bstack_utils.constants import *
import traceback
import os
import time
class bstack1ll1ll1111l_opy_(bstack1lll1l11l1l_opy_):
    bstack1ll1l11111l_opy_ = False
    def __init__(self):
        super().__init__()
        bstack1lll111l11l_opy_.bstack1ll111l11ll_opy_((bstack1llll1lllll_opy_.bstack1lllll1ll11_opy_, bstack1llllll1lll_opy_.PRE), self.bstack1ll11111l11_opy_)
    def is_enabled(self) -> bool:
        return True
    def bstack1ll11111l11_opy_(
        self,
        f: bstack1lll111l11l_opy_,
        driver: object,
        exec: Tuple[bstack1llll1llll1_opy_, str],
        bstack1lllllll1l1_opy_: Tuple[bstack1llll1lllll_opy_, bstack1llllll1lll_opy_],
        result: Any,
        *args,
        **kwargs,
    ):
        hub_url = f.hub_url(driver)
        if f.bstack1l1lllllll1_opy_(hub_url):
            if not bstack1ll1ll1111l_opy_.bstack1ll1l11111l_opy_:
                self.logger.warning(bstack1l11l11_opy_ (u"ࠣ࡮ࡲࡧࡦࡲࠠࡴࡧ࡯ࡪ࠲࡮ࡥࡢ࡮ࠣࡪࡱࡵࡷࠡࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠣࡪࡴࡸࠠࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠦࡩ࡯ࡨࡵࡥࠥࡹࡥࡴࡵ࡬ࡳࡳࡹࠠࡩࡷࡥࡣࡺࡸ࡬࠾ࠤሰ") + str(hub_url) + bstack1l11l11_opy_ (u"ࠤࠥሱ"))
                bstack1ll1ll1111l_opy_.bstack1ll1l11111l_opy_ = True
            return
        command_name = f.bstack1ll1l111111_opy_(*args)
        bstack1ll111111ll_opy_ = f.bstack1l1llllll1l_opy_(*args)
        if command_name and command_name.lower() == bstack1l11l11_opy_ (u"ࠥࡪ࡮ࡴࡤࡦ࡮ࡨࡱࡪࡴࡴࠣሲ") and bstack1ll111111ll_opy_:
            framework_session_id = f.session_id(driver)
            locator_type, locator_value = bstack1ll111111ll_opy_.get(bstack1l11l11_opy_ (u"ࠦࡺࡹࡩ࡯ࡩࠥሳ"), None), bstack1ll111111ll_opy_.get(bstack1l11l11_opy_ (u"ࠧࡼࡡ࡭ࡷࡨࠦሴ"), None)
            if not framework_session_id or not locator_type or not locator_value:
                self.logger.warning(bstack1l11l11_opy_ (u"ࠨࡻࡤࡱࡰࡱࡦࡴࡤࡠࡰࡤࡱࡪࢃ࠺ࠡ࡯࡬ࡷࡸ࡯࡮ࡨࠢࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡹࡥࡴࡵ࡬ࡳࡳࡥࡩࡥࠢࡲࡶࠥࡧࡲࡨࡵ࠱ࡹࡸ࡯࡮ࡨ࠿ࡾࡰࡴࡩࡡࡵࡱࡵࡣࡹࡿࡰࡦࡿࠣࡳࡷࠦࡡࡳࡩࡶ࠲ࡻࡧ࡬ࡶࡧࡀࠦስ") + str(locator_value) + bstack1l11l11_opy_ (u"ࠢࠣሶ"))
                return
            def bstack1llll1l1l11_opy_(driver, bstack1ll111111l1_opy_, *args, **kwargs):
                from selenium.common.exceptions import NoSuchElementException
                try:
                    result = bstack1ll111111l1_opy_(driver, *args, **kwargs)
                    response = self.bstack1l1llllllll_opy_(
                        framework_session_id=framework_session_id,
                        is_success=True,
                        locator_type=locator_type,
                        locator_value=locator_value,
                    )
                    if response and response.execute_script:
                        driver.execute_script(response.execute_script)
                        self.logger.info(bstack1l11l11_opy_ (u"ࠣࡵࡸࡧࡨ࡫ࡳࡴ࠯ࡶࡧࡷ࡯ࡰࡵ࠼ࠣࡰࡴࡩࡡࡵࡱࡵࡣࡹࡿࡰࡦ࠿ࡾࡰࡴࡩࡡࡵࡱࡵࡣࡹࡿࡰࡦࡿࠣࡰࡴࡩࡡࡵࡱࡵࡣࡻࡧ࡬ࡶࡧࡀࠦሷ") + str(locator_value) + bstack1l11l11_opy_ (u"ࠤࠥሸ"))
                    else:
                        self.logger.warning(bstack1l11l11_opy_ (u"ࠥࡷࡺࡩࡣࡦࡵࡶ࠱ࡳࡵ࠭ࡴࡥࡵ࡭ࡵࡺ࠺ࠡ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡷࡽࡵ࡫࠽ࡼ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡷࡽࡵ࡫ࡽࠡ࡮ࡲࡧࡦࡺ࡯ࡳࡡࡹࡥࡱࡻࡥ࠾ࡽ࡯ࡳࡨࡧࡴࡰࡴࡢࡺࡦࡲࡵࡦࡿࠣࡶࡪࡹࡰࡰࡰࡶࡩࡂࠨሹ") + str(response) + bstack1l11l11_opy_ (u"ࠦࠧሺ"))
                    return result
                except NoSuchElementException as e:
                    locator = (locator_type, locator_value)
                    return self.__1l1llllll11_opy_(
                        driver, bstack1ll111111l1_opy_, e, framework_session_id, locator, *args, **kwargs
                    )
            bstack1llll1l1l11_opy_.__name__ = command_name
            return bstack1llll1l1l11_opy_
    def __1l1llllll11_opy_(
        self,
        driver,
        bstack1ll111111l1_opy_: Callable,
        exception,
        framework_session_id: str,
        locator: Tuple[str, str],
        *args,
        **kwargs,
    ):
        try:
            locator_type, locator_value = locator
            response = self.bstack1l1llllllll_opy_(
                framework_session_id=framework_session_id,
                is_success=False,
                locator_type=locator_type,
                locator_value=locator_value,
            )
            if response and response.execute_script:
                driver.execute_script(response.execute_script)
                self.logger.info(bstack1l11l11_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡸࡶࡪ࠳ࡨࡦࡣ࡯࡭ࡳ࡭࠭ࡵࡴ࡬࡫࡬࡫ࡲࡦࡦ࠽ࠤࡱࡵࡣࡢࡶࡲࡶࡤࡺࡹࡱࡧࡀࡿࡱࡵࡣࡢࡶࡲࡶࡤࡺࡹࡱࡧࢀࠤࡱࡵࡣࡢࡶࡲࡶࡤࡼࡡ࡭ࡷࡨࡁࠧሻ") + str(locator_value) + bstack1l11l11_opy_ (u"ࠨࠢሼ"))
                bstack1ll11111111_opy_ = self.bstack1ll11111ll1_opy_(
                    framework_session_id=framework_session_id,
                    locator_type=locator_type,
                )
                self.logger.info(bstack1l11l11_opy_ (u"ࠢࡧࡣ࡬ࡰࡺࡸࡥ࠮ࡪࡨࡥࡱ࡯࡮ࡨ࠯ࡵࡩࡸࡻ࡬ࡵ࠼ࠣࡰࡴࡩࡡࡵࡱࡵࡣࡹࡿࡰࡦ࠿ࡾࡰࡴࡩࡡࡵࡱࡵࡣࡹࡿࡰࡦࡿࠣࡰࡴࡩࡡࡵࡱࡵࡣࡻࡧ࡬ࡶࡧࡀࡿࡱࡵࡣࡢࡶࡲࡶࡤࡼࡡ࡭ࡷࡨࢁࠥ࡮ࡥࡢ࡮࡬ࡲ࡬ࡥࡲࡦࡵࡸࡰࡹࡃࠢሽ") + str(bstack1ll11111111_opy_) + bstack1l11l11_opy_ (u"ࠣࠤሾ"))
                if bstack1ll11111111_opy_.success and args and len(args) > 1:
                    args[1].update(
                        {
                            bstack1l11l11_opy_ (u"ࠤࡸࡷ࡮ࡴࡧࠣሿ"): bstack1ll11111111_opy_.locator_type,
                            bstack1l11l11_opy_ (u"ࠥࡺࡦࡲࡵࡦࠤቀ"): bstack1ll11111111_opy_.locator_value,
                        }
                    )
                    return bstack1ll111111l1_opy_(driver, *args, **kwargs)
                elif os.environ.get(bstack1l11l11_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡅࡎࡥࡄࡆࡄࡘࡋࠧቁ"), False):
                    self.logger.info(bstack1ll1llll1ll_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡸࡶࡪ࠳ࡨࡦࡣ࡯࡭ࡳ࡭࠭ࡳࡧࡶࡹࡱࡺ࠭࡮࡫ࡶࡷ࡮ࡴࡧ࠻ࠢࡶࡰࡪ࡫ࡰࠩ࠵࠳࠭ࠥࡲࡥࡵࡶ࡬ࡲ࡬ࠦࡹࡰࡷࠣ࡭ࡳࡹࡰࡦࡥࡷࠤࡹ࡮ࡥࠡࡤࡵࡳࡼࡹࡥࡳࠢࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥࡲ࡯ࡨࡵࠥቂ"))
                    time.sleep(300)
            else:
                self.logger.warning(bstack1l11l11_opy_ (u"ࠨࡦࡢ࡫࡯ࡹࡷ࡫࠭࡯ࡱ࠰ࡷࡨࡸࡩࡱࡶ࠽ࠤࡱࡵࡣࡢࡶࡲࡶࡤࡺࡹࡱࡧࡀࡿࡱࡵࡣࡢࡶࡲࡶࡤࡺࡹࡱࡧࢀࠤࡱࡵࡣࡢࡶࡲࡶࡤࡼࡡ࡭ࡷࡨࡁࢀࡲ࡯ࡤࡣࡷࡳࡷࡥࡶࡢ࡮ࡸࡩࢂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠤቃ") + str(response) + bstack1l11l11_opy_ (u"ࠢࠣቄ"))
        except Exception as err:
            self.logger.warning(bstack1l11l11_opy_ (u"ࠣࡨࡤ࡭ࡱࡻࡲࡦ࠯࡫ࡩࡦࡲࡩ࡯ࡩ࠰ࡶࡪࡹࡵ࡭ࡶ࠽ࠤࡪࡸࡲࡰࡴ࠽ࠤࠧቅ") + str(err) + bstack1l11l11_opy_ (u"ࠤࠥቆ"))
        raise exception
    @measure(event_name=EVENTS.bstack1ll11111l1l_opy_, stage=STAGE.bstack1lll1111l_opy_)
    def bstack1l1llllllll_opy_(
        self,
        framework_session_id: str,
        is_success: bool,
        locator_type: str,
        locator_value: str,
        platform_index=bstack1l11l11_opy_ (u"ࠥ࠴ࠧቇ"),
    ):
        self.bstack1ll111l1111_opy_()
        req = structs.AISelfHealStepRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_session_id = framework_session_id
        req.is_success = is_success
        req.test_name = bstack1l11l11_opy_ (u"ࠦࠧቈ")
        req.locator_type = locator_type
        req.locator_value = locator_value
        try:
            r = self.bstack1ll1ll1ll1l_opy_.AISelfHealStep(req)
            self.logger.info(bstack1l11l11_opy_ (u"ࠧࡸࡥࡤࡧ࡬ࡺࡪࡪࠠࡧࡴࡲࡱࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࠢ቉") + str(r) + bstack1l11l11_opy_ (u"ࠨࠢቊ"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l11l11_opy_ (u"ࠢࡳࡲࡦ࠱ࡪࡸࡲࡰࡴ࠽ࠤࠧቋ") + str(e) + bstack1l11l11_opy_ (u"ࠣࠤቌ"))
            traceback.print_exc()
            raise e
    @measure(event_name=EVENTS.bstack1ll1111111l_opy_, stage=STAGE.bstack1lll1111l_opy_)
    def bstack1ll11111ll1_opy_(self, framework_session_id: str, locator_type: str, platform_index=bstack1l11l11_opy_ (u"ࠤ࠳ࠦቍ")):
        self.bstack1ll111l1111_opy_()
        req = structs.AISelfHealGetRequest()
        req.bin_session_id = self.bin_session_id
        req.platform_index = platform_index
        req.framework_session_id = framework_session_id
        req.locator_type = locator_type
        try:
            r = self.bstack1ll1ll1ll1l_opy_.AISelfHealGetResult(req)
            self.logger.info(bstack1l11l11_opy_ (u"ࠥࡶࡪࡩࡥࡪࡸࡨࡨࠥ࡬ࡲࡰ࡯ࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࠧ቎") + str(r) + bstack1l11l11_opy_ (u"ࠦࠧ቏"))
            return r
        except grpc.RpcError as e:
            self.logger.error(bstack1l11l11_opy_ (u"ࠧࡸࡰࡤ࠯ࡨࡶࡷࡵࡲ࠻ࠢࠥቐ") + str(e) + bstack1l11l11_opy_ (u"ࠨࠢቑ"))
            traceback.print_exc()
            raise e