"""Lander exception library.
"""


class DocuShareError(Exception):
    """Raised when an API request to DocuShare is unsuccessful."""
