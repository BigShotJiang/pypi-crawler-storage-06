"""TeX metadata extraction tools."""
