"""GitHub adapter."""
