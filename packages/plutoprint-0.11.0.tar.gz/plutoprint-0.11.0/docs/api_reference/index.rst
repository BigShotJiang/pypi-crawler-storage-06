API Reference
=============

.. currentmodule:: plutoprint

.. toctree::
    :maxdepth: 3

    constants
    pagesize
    pagemargins
    mediatype
    pdfmetadata
    imageformat
    error
    canvas
    imagecanvas
    pdfcanvas
    resourcedata
    resourcefetcher
    book
