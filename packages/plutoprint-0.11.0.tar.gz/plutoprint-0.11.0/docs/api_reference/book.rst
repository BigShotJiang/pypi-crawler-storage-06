Book
====

.. currentmodule:: plutoprint

.. autoclass:: Book
    :members:

    .. automethod:: __init__
