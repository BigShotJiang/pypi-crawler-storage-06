__version__ = "0.5.13"

if __name__ == "__main__":
    # The build script uses this to extract the current version
    print(__version__)
