# dev-toolbox

[![PyPI - Version](https://img.shields.io/pypi/v/dev-toolbox.svg)](https://pypi.org/project/dev-toolbox)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/dev-toolbox.svg)](https://pypi.org/project/dev-toolbox)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/FlavioAmurrioCS/dev-toolbox/main.svg)](https://results.pre-commit.ci/latest/github/FlavioAmurrioCS/dev-toolbox/main)

-----

**Table of Contents**

- [dev-toolbox](#dev-toolbox)
  - [Installation](#installation)
  - [License](#license)

## Installation

```console
pip install dev-toolbox
```

## License

`dev-toolbox` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
