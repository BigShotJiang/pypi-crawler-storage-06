# You can define pydantic models that mirror response shapes if you want stricter typing.
# For now, endpoints return Dict[str, Any] so the SDK remains thin and stable.
