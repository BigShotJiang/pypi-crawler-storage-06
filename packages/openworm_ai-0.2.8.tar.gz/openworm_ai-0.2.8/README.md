# openworm.ai

Scripts related to use of LLMs and other AI technology in OpenWorm
