#!/bin/sh
python3 -m codegen
ruff format

