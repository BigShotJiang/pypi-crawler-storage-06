from vkbottle_types.codegen.methods.likes import *  # noqa: F403,F401
