from vkbottle_types.codegen.methods.fave import *  # noqa: F403,F401
