def love(name):
    print("❤️😍"*20)
    print("\n")
    hearts = "❤️  " * 3
    return f"Dear {name}, I ❤️   you choo much..{hearts}!\n\n {"❤️😍"*20}"
def greet(names):
    print("#"*30)
    greetings=f"hello {names}...from yours mahesh.have a good day"
    return greetings






