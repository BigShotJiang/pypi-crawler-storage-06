from .base import Embedding
from .vocab import VocabEmbedding

__all__ = ["VocabEmbedding", "Embedding"]
