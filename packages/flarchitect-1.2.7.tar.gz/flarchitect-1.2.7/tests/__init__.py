"""Test package initialization for plugin imports.

Ensures `pytest_plugins = ["tests.test_authentication"]` works by making
`tests` an importable package when running the suite from the repository root.
"""

