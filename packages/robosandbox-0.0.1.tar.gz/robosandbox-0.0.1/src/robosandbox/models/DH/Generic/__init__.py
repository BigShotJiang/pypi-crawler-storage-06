from .Generic import Generic
from .GenericTwo import GenericTwo
from .GenericThree import GenericThree
from .GenericFour import GenericFour
from .GenericFive import GenericFive
from .GenericSix import GenericSix
from .GenericSeven import GenericSeven

__all__ = [
    "Generic",
    "GenericThree",
    "GenericFour",
    "GenericTwo",
    "GenericFive",
    "GenericSix",
    "GenericSeven",
]
