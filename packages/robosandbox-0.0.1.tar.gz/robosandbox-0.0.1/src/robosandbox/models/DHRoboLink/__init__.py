from . import Generic

__all__ = ["Generic"]
