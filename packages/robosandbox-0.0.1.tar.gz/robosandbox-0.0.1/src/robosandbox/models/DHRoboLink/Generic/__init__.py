from .GenericFour import GenericFour

__all__ = ["GenericFour"]
