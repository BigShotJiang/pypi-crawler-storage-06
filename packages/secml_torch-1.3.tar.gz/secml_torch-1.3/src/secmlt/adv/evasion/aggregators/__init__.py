"""Aggregator functions for multiple attacks or multiple attack runs."""
