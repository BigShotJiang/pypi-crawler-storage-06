"""Functionalities for handling data."""
