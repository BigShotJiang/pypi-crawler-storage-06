"""Metrics to evaluate machine learning models and attacks."""
