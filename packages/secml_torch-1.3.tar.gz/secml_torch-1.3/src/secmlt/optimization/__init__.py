"""Optimization functionalities."""
