"""Functionalities for applying manipulations to input data."""
