__all__ = [
    "ParamError",
    "InputError",
]


class ParamError(Exception):
    pass


class InputError(Exception):
    pass
