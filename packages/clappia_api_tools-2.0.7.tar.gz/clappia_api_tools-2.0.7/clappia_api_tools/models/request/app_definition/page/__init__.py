from .request import (
    AddPageBreakRequest,
    UpdatePageBreakRequest,
)

__all__ = [
    "AddPageBreakRequest",
    "UpdatePageBreakRequest",
]
