# -*- coding: UTF-8 -*-
from .braille import *
from .galactic import *
from .ipsum import *
from .leetspeak import *
from .morse import *
from .navajo import *
from .radio import *
from .southpark import *
from .tap import *
from .tomtom import *

