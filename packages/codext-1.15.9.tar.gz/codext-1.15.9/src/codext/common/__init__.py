# -*- coding: UTF-8 -*-
from .a1z26 import *
from .cases import *
from .dummy import *
from .octal import *
from .ordinal import *

