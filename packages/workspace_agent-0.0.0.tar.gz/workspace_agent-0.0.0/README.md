# workspace-agent
 Workspace management package for `out` folder shared between different packages.
