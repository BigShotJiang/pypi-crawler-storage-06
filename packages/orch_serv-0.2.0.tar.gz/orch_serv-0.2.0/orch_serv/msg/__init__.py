"""
import `msg` module content
"""

from .message import BaseOrchServMsg
