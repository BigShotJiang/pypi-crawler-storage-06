"""
Settings for work lib
"""

import logging

logging.basicConfig(level=logging.INFO)  # noqa

DEFAULT_LOGGER = logging.Logger(__name__)
