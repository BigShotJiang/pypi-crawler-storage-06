"""Version information automatically updated by bumpver."""

__version__ = "0.2.1"
