from .mas import MAS
import sys

sys.modules[__name__] = MAS
