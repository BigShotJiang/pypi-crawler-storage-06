# number of digits for rounding coordinates due to issue https://github.com/euro-cordex/py-cordex/issues/60
nround = 14
