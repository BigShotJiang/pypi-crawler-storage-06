.. typer:: completion:cli
    :show-nested:
    :preferred: text
    :width: 70
