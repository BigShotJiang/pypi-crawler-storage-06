Typer Role Test References
==========================


References
----------

Cross references:

    * Check 0: :typer:`imagepipe`.
    * Check 1: :typer:`imagepipe-blur`.
    * Check 2: :typer:`imagepipe-crop`.
    * Check 3: :typer:`imagepipe-display`.
    * Check 4: :typer:`imagepipe-emboss`.
    * Check 5: :typer:`imagepipe-open`.
    * Check 6: :typer:`imagepipe-paste`.
    * Check 7: :typer:`imagepipe-resize`.
    * Check 8: :typer:`imagepipe-save`.
    * Check 9: :typer:`imagepipe-smoothen`.
    * Check 10: :typer:`imagepipe-transpose`.
    * Check 11: :typer:`sharpen <imagepipe sharpen>`.


This one is bad: :typer:`bad-reference`
