.. typer:: complex.cli:cli
    :show-nested:
    :prog: complex
    :preferred: text
    :make-sections:
    :width: 65
