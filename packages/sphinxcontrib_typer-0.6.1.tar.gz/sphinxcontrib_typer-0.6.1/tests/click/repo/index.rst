.. typer:: repo.cli
    :preferred: html
    :show-nested:
    :width: 65
