.. typer:: composite.cli.app:repeat
    :prog: python -m cli.py repeat
    :width: 65
    :convert-png: latex
    :make-sections:
    :preferred: text
