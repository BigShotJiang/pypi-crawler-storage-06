.. typer:: composite.cli.app
    :prog: composite
    :preferred: text
    :width: 65
    :make-sections:
    :show-nested:


.. toctree::
   :maxdepth: 1
   :caption: Contents:

   composite
   repeat
   subgroup
   echo
   multiply
