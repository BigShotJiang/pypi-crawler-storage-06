"""The core module.

Contains fundamental utilities and physics functionality which is shared across the
code base. Submodules are the utilities and the hygro submodule.
"""
