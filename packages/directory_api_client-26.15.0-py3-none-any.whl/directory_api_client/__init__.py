from directory_api_client.client import api_client

__all__ = ['api_client']
