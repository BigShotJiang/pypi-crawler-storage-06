"""
BookForge - Beautiful EPUB generation service
"""

__version__ = "0.1.0"
__author__ = "BookForge Team"
__description__ = "Cloud-based EPUB generation service - the modern alternative to Vellum"