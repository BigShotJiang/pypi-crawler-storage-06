from cwl2nx.cwl2nx import CWLToNetworkxConnector, cwl_to_str
