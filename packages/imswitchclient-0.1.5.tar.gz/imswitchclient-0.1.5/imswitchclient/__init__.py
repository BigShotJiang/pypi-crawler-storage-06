"""Top-level package for ImSwitchClient."""
from imswitchclient import *

__author__ = """Benedict Diederich"""
__email__ = 'benedictdied@gmail.com'
__version__ = "v0.1.5"#'0.1.5'
