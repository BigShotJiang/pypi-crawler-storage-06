#!/usr/bin/env python

"""Tests for `imswitchclient` package."""


import unittest

from imswitchclient import imswitchclient


class TestImswitchclient(unittest.TestCase):
    """Tests for `imswitchclient` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
