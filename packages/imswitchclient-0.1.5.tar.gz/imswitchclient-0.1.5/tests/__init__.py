"""Unit test package for imswitchclient."""
