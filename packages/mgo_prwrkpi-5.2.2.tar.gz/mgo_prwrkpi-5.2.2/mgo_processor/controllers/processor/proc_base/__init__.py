from mgo_processor.controllers.processor.proc_base.processing_controller import ProcessingController
from .stat_map import StatMap

