from .matmul import matrix_multiply

__all__ = ["matrix_multiply"]
__version__ = "0.0.1"