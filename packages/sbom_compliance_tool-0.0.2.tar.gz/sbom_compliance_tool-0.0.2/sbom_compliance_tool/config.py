# SPDX-FileCopyrightText: 2025 Henrik Sandklef
#
# SPDX-License-Identifier: GPL-3.0-or-later

sbom_compliance_tool_version = '0.0.2'
description = 'Tool to assists complioance work with SBOMs'
module_name = 'sbom_compliance_tool'
