# -*- coding: utf-8 -*-
class CustomUIScreenProxy(object):
	def __init__(self, screenName, screenNode):
		pass

	def GetScreenNode(self):
		pass

	def GetScreenName(self):
		pass

	def OnCreate(self):
		pass

	def OnDestroy(self):
		pass

	def OnTick(self):
		pass
