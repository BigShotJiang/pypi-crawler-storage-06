# LandingAIADE

Types:

```python
from landingai_ade.types import ExtractResponse, ParseResponse
```

Methods:

- <code title="post /v1/ade/extract">client.<a href="./src/landingai_ade/_client.py">extract</a>(\*\*<a href="src/landingai_ade/types/client_extract_params.py">params</a>) -> <a href="./src/landingai_ade/types/extract_response.py">ExtractResponse</a></code>
- <code title="post /v1/ade/parse">client.<a href="./src/landingai_ade/_client.py">parse</a>(\*\*<a href="src/landingai_ade/types/client_parse_params.py">params</a>) -> <a href="./src/landingai_ade/types/parse_response.py">ParseResponse</a></code>
