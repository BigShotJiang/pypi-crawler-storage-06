# Changelog

## 0.9.0 (2025-09-24)

Full Changelog: [v0.8.1...v0.9.0](https://github.com/landing-ai/ade-python/compare/v0.8.1...v0.9.0)

### Features

* **api:** manual updates ([19e3c31](https://github.com/landing-ai/ade-python/commit/19e3c31cf6bd3f480cf6e6e928a53aa4ca259c3f))

## 0.8.1 (2025-09-24)

Full Changelog: [v0.8.0...v0.8.1](https://github.com/landing-ai/ade-python/compare/v0.8.0...v0.8.1)

## 0.8.0 (2025-09-24)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/landing-ai/ade-python/compare/v0.7.0...v0.8.0)

### Features

* **api:** manual updates ([7f32e5a](https://github.com/landing-ai/ade-python/commit/7f32e5a8fa173ff0119d988466cc2edd9a1bc195))

## 0.7.0 (2025-09-23)

Full Changelog: [v0.6.1...v0.7.0](https://github.com/landing-ai/ade-python/compare/v0.6.1...v0.7.0)

### Features

* **api:** manual updates ([d2bd4c7](https://github.com/landing-ai/ade-python/commit/d2bd4c7ab65d9fcd9b898f6af80862dbe9285021))

## 0.6.1 (2025-09-23)

Full Changelog: [v0.6.0...v0.6.1](https://github.com/landing-ai/ade-python/compare/v0.6.0...v0.6.1)

## 0.6.0 (2025-09-23)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/landing-ai/ade-python/compare/v0.5.0...v0.6.0)

### Features

* **api:** manual updates ([6f6ec00](https://github.com/landing-ai/ade-python/commit/6f6ec00e13f0600bf78fd909dd3154343e9ec78b))

## 0.5.0 (2025-09-22)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/landing-ai/ade-python/compare/v0.4.0...v0.5.0)

### Features

* **api:** manual updates ([3f1ecbb](https://github.com/landing-ai/ade-python/commit/3f1ecbbc0665214951e5373a657d0c71187d0314))

## 0.4.0 (2025-09-22)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/landing-ai/ade-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** manual updates ([c4546ae](https://github.com/landing-ai/ade-python/commit/c4546aef566721f812c4f1328ef516893039087a))

## 0.3.0 (2025-09-22)

Full Changelog: [v0.2.2...v0.3.0](https://github.com/landing-ai/ade-python/compare/v0.2.2...v0.3.0)

### Features

* **api:** manual updates ([bf088ab](https://github.com/landing-ai/ade-python/commit/bf088ab5e2731d64a271608a98b86c76171bef6a))

## 0.2.2 (2025-09-22)

Full Changelog: [v0.2.1...v0.2.2](https://github.com/landing-ai/ade-python/compare/v0.2.1...v0.2.2)

### Chores

* do not install brew dependencies in ./scripts/bootstrap by default ([5848b5d](https://github.com/landing-ai/ade-python/commit/5848b5d709c7067d601ca075373fadc5dc4c337c))
* update SDK settings ([b6fafa9](https://github.com/landing-ai/ade-python/commit/b6fafa97c01d825f58b7805e58bd670bbd7b3391))

## 0.2.1 (2025-09-19)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/landing-ai/ade-python/compare/v0.2.0...v0.2.1)

### Chores

* **types:** change optional parameter type from NotGiven to Omit ([29a0a2d](https://github.com/landing-ai/ade-python/commit/29a0a2de368b135025a8379e26634f4dc5d6a1e8))

## 0.2.0 (2025-09-18)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/landing-ai/ade-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** support environments ([e9b604e](https://github.com/landing-ai/ade-python/commit/e9b604e76d03a9e630c8567d3f014032ca186376))

## 0.1.0 (2025-09-18)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/landing-ai/ade-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([eb76a32](https://github.com/landing-ai/ade-python/commit/eb76a3275704d50396d00fd8ac79c2537ce251fc))


### Chores

* configure new SDK language ([9761e2b](https://github.com/landing-ai/ade-python/commit/9761e2bed207087deba958e693fd381eb5599a67))
* update SDK settings ([b46e740](https://github.com/landing-ai/ade-python/commit/b46e74012a27713aaa82f99bd11e527c92e912f4))
* update SDK settings ([982e228](https://github.com/landing-ai/ade-python/commit/982e2280ef59753578cfc5c4272fca2f90c2083a))
