./create_IAM_dataset.py
mkdir -p models log priors
python ../../../rnn.py config_demo
