This is a portfolio lab
the pyfolio has some problem on python > 3.9
I fix it
