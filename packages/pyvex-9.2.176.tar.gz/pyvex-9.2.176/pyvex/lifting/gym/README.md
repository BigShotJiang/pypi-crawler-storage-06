# The Gym

This is where we're putting non-libvex lifters that we feel should be included with the pyvex distribution.

These will probably be mostly "spotters", which correct for gaps in libvex's instruction support.


