from ..lego.lego import Lego

class Folder(Lego):

	def __init__(self, **kwargs):
		super().__init__(**kwargs)