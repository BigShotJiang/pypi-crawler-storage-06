OAUTH_CREDENTIALS = (
	'OAuth2Credentials',
	'AccessTokenCredentials',
	'GoogleCredentials'
)