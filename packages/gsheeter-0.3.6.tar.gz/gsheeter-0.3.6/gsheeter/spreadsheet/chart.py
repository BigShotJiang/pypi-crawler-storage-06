class Chart:

  def __init__(self) -> None:
    pass
