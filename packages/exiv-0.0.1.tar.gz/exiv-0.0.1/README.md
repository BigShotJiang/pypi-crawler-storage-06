# exiv
[WIP]
This is in active development and will be pusblished soon.

## Install
```bash
pip install exiv
```