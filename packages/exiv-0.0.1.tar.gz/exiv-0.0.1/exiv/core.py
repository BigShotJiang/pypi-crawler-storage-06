def hello():
    return "Hello from exiv!"

def add(a: int, b: int) -> int:
    """Return the sum of two numbers."""
    return a + b
