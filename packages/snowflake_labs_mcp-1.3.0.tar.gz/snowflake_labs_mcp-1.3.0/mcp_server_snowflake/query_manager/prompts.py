query_tool_prompt = """
Run a SQL query in Snowflake.
DML and DDL queries are supported.
Tool should only be used if other tools do not suffice."""
