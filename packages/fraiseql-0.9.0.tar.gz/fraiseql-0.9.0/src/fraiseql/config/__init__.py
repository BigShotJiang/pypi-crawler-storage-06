"""Configuration module for FraiseQL."""

from .schema_config import SchemaConfig

__all__ = ["SchemaConfig"]
