"""AI tutor for education"""

__version__ = '0.1.2'
