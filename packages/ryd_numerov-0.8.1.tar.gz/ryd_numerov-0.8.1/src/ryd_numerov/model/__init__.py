from ryd_numerov.model.model import Model

__all__ = ["Model"]
