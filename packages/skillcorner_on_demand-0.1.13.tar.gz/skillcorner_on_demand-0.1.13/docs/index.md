# SkillCorner On Demand

SDK to access the SkillCorner On Demand service

## Installation
```shell
uv pip install skillcorner-on-demand
```
