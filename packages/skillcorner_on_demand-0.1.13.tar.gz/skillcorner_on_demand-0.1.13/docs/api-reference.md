# Api Reference

::: skillcorner_on_demand.client.SkillcornerOnDemandClient
    handler: python
    options:
        members:
            - upload_match_video
            - get_all_requests
        show_source: false
        inherited_members: false
