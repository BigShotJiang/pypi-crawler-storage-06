from typing import Optional, Dict
from .client import Client


class Model:
    """
    Represents a model in the Bytez API
    """

    def __init__(self, model_id: str, bytez, client: Client, provider_key: str = None):
        """
        Initialize a model instance.

        Args:
            model_id (str): The model ID, e.g., `openai-community/gpt2`.
            bytez (Bytez): The Bytez API client instance.
            client (Client): The internal request client.
            provider_key (str, optional): closed source model provider key
        """
        self._client = client
        self.provider_key: str = provider_key
        self.id: str = model_id  # The modelId, for example `openai-community/gpt2`
        self.details: Dict = {}  # Details about the model
        self._is_generating_media: bool = (
            False  # Whether the model generates media output
        )
        self._bytez = bytez
        self._ready = False

    def _initialize(self):
        """Fetch model details and set up internal state."""
        output, _ = self._bytez.list.models({"modelId": self.id})
        media_generators = {
            "text-to-audio",
            "text-to-image",
            "text-to-video",
            "text-to-speech",
        }

        self.details = output[0] if output else {}
        self._is_generating_media = self.details.get("task") in media_generators
        self._ready = True

    def run(self, input=None, params: Optional[Dict] = None, stream: bool = False):
        """
        `Run` the model by passing an `input`, and optionally passing `params` and/or a `stream` flag.

        Execute this function in one of four ways:
        1. `run(input)` → Returns JSON `{ error, output }`
        2. `run(input, params={...})` → Returns JSON `{ error, output }`
        3. `run(input, stream=True)` → Streams output if applicable
        4. `run(input, params={...}, stream=True)` → Uses params and streams if applicable

        Args:
            input (any, optional): Input data (e.g., text, URL, base64).
            params (dict, optional): Model parameters.
            stream (bool, optional): Whether to stream the output.

        Returns:
            dict | iter: Model output (stream or JSON response).
        """
        if self._ready is False:
            self._initialize()

        post_body = {
            "params": params,
            "stream": stream,
            "json": False if self._is_generating_media and stream else None,
        }

        post_body["input"] = input

        return self._client.request(self.id, "POST", post_body, self.provider_key)
