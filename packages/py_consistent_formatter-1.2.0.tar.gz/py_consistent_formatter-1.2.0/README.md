![tests](https://github.com/kfazi/py-consistent-formatter/actions/workflows/tests.yml/badge.svg)
[![PyPI Package latest release](https://img.shields.io/pypi/v/py-consistent-formatter.svg?style=flat-square)](https://pypi.org/project/py-consistent-formatter/)

# Introduction

This package is a quick and dirty wrapper around yapf, isort and docformatter so that they don't fight each other.
