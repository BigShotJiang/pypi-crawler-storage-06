def main():
    print("Hello from create-browser-app!")


if __name__ == "__main__":
    main()
