def welcome_message():
    return "مرحباً! أنا خطاب وهذه مكتبتي الخاصة بلغة بايثون."



if __name__ == "__main__":
    print(welcome_message())
