.. _installing:

############
 Installing
############

To install the package, you can use the following command:

.. code:: bash

   pip install earthkit-workflows-anemoi

**************
 Contributing
**************

.. code:: bash

   git clone ...
   cd earthkit-workflows-anemoi
   pip install .[dev]
