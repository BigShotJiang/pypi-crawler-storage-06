


class GedcomError(Exception):
    """Generic error in GEDCOM processing."""
    pass

class GedcomInvalidSubStructure(Exception):
    pass