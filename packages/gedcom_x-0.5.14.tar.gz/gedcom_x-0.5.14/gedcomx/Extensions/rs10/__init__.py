#https://github.com/FamilySearch/gedcomx-rs/blob/master/specifications/rs-specification.md

from .rs10 import rsLink
from .rs10 import _rsLinks
from .rs10 import FamilyLinks