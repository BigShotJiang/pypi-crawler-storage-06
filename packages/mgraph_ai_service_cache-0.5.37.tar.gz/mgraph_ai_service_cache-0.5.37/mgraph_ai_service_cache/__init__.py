package_name = 'mgraph_ai_service_cache'
path         = __path__[0]