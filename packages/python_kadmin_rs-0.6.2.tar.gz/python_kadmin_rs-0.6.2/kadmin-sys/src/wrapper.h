#include <kadm5/admin.h>
const krb5_error_code KRB5_OK = 0;
