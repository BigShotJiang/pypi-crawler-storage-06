from obplanner.model.pattern import PatternData

def compensate_pattern(pattern: PatternData, settings: dict, sliced_model, layer: int):
    #Expandable to perform geometrical energy compensation
    return pattern