from bluer_ai import fullname


def test_fullname():
    assert fullname()
