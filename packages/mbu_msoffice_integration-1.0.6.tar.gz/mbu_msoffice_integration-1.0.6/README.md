Repo containing functionality related to MSOffice
