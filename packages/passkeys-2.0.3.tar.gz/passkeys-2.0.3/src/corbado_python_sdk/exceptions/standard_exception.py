class StandardException(Exception):
    """Custom exception class for standard exceptions."""

    pass
