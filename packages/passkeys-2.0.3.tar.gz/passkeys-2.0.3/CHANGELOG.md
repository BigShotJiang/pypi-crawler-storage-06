# Changelog
## [1.0.1] - 2024-06-14
### Added
- Minor bugfixes


# Changelog
## [1.0.0] - 2024-06-07
### Added
- Initial release.

## [1.0.0b1] - 2024-06-07
### Added
- Initial beta release.
