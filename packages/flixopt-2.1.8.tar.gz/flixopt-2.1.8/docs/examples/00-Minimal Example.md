# Minimal Example

```python
{! ../examples/00_Minmal/minimal_example.py !}
```
