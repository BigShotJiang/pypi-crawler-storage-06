# Calculation Mode comparison
**Note:** This example relies on time series data. You can find it in the `examples` folder of the FlixOpt repository.
```python
{! ../examples/03_Calculation_types/example_calculation_types.py !}
```
