# Simple example

```python
{! ../examples/01_Simple/simple_example.py !}
```
