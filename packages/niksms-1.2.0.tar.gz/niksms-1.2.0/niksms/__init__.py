"""
niksms
Python SDK for Kendez.NikSms SMS Web Service (REST & gRPC)
"""

from .rest import NiksmsRestClient
from .grpc import NiksmsGrpcClient
