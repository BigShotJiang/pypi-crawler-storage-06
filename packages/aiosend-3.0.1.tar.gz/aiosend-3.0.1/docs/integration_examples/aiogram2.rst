===========
aiogram 2.x
===========

Usage example with `aiogram 2.x <https://docs.aiogram.dev/en/v2.25.1/>`_
------------------------------------------------------------------------

.. literalinclude:: ../../examples/aiogram2.py

Preview
-------

.. image:: ../_static/payment_handle_example.png