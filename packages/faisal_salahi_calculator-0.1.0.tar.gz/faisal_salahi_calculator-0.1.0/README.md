# آلة حاسبة بسيطة - فيصل الصلاحي

[![PyPI version](https://badge.fury.io/py/faisal-salahi-calculator.svg)](https://badge.fury.io/py/faisal-salahi-calculator)
[![Python versions](https://img.shields.io/pypi/pyversions/faisal-salahi-calculator.svg)](https://pypi.org/project/faisal-salahi-calculator/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

حزمة بايثون بسيطة وفعالة لإجراء العمليات الحسابية الأساسية. تم تطويرها بواسطة **فيصل الصلاحي** لتوفير واجهة برمجية سهلة الاستخدام للعمليات الرياضية الأساسية.

## المميزات

- **بساطة في الاستخدام**: واجهة برمجية واضحة ومباشرة
- **موثوقية عالية**: معالجة صحيحة للأخطاء (مثل القسمة على صفر)
- **توثيق شامل**: جميع الوظائف موثقة باللغة العربية
- **متوافقة مع Python 3.6+**: تدعم جميع إصدارات بايثون الحديثة
- **خفيفة الوزن**: لا تتطلب أي تبعيات خارجية

## التثبيت

يمكنك تثبيت الحزمة بسهولة باستخدام pip:

```bash
pip install faisal_salahi_calculator
```

## الاستخدام

### الاستيراد

```python
from faisal_salahi_calculator import add, subtract, multiply, divide
```

### أمثلة على الاستخدام

#### الجمع
```python
result = add(5, 3)
print(f"5 + 3 = {result}")  # الناتج: 5 + 3 = 8
```

#### الطرح
```python
result = subtract(10, 4)
print(f"10 - 4 = {result}")  # الناتج: 10 - 4 = 6
```

#### الضرب
```python
result = multiply(2, 6)
print(f"2 × 6 = {result}")  # الناتج: 2 × 6 = 12
```

#### القسمة
```python
result = divide(15, 3)
print(f"15 ÷ 3 = {result}")  # الناتج: 15 ÷ 3 = 5.0

# معالجة القسمة على صفر
try:
    result = divide(10, 0)
except ValueError as e:
    print(f"خطأ: {e}")  # الناتج: خطأ: لا يمكن القسمة على صفر!
```

### مثال شامل

```python
from faisal_salahi_calculator import add, subtract, multiply, divide

# حساب معادلة رياضية: (10 + 5) × 3 ÷ 2 - 1
step1 = add(10, 5)        # 15
step2 = multiply(step1, 3) # 45
step3 = divide(step2, 2)   # 22.5
result = subtract(step3, 1) # 21.5

print(f"النتيجة النهائية: {result}")  # الناتج: النتيجة النهائية: 21.5
```

## واجهة برمجة التطبيقات (API)

### `add(a, b)`
**الوصف**: جمع رقمين  
**المعاملات**: 
- `a` (float): الرقم الأول
- `b` (float): الرقم الثاني

**القيمة المُرجعة**: `float` - ناتج الجمع

### `subtract(a, b)`
**الوصف**: طرح رقمين  
**المعاملات**: 
- `a` (float): الرقم الأول (المطروح منه)
- `b` (float): الرقم الثاني (المطروح)

**القيمة المُرجعة**: `float` - ناتج الطرح

### `multiply(a, b)`
**الوصف**: ضرب رقمين  
**المعاملات**: 
- `a` (float): الرقم الأول
- `b` (float): الرقم الثاني

**القيمة المُرجعة**: `float` - ناتج الضرب

### `divide(a, b)`
**الوصف**: قسمة رقمين  
**المعاملات**: 
- `a` (float): الرقم الأول (المقسوم)
- `b` (float): الرقم الثاني (المقسوم عليه)

**القيمة المُرجعة**: `float` - ناتج القسمة  
**الاستثناءات**: `ValueError` - إذا كان المقسوم عليه يساوي صفر

## المتطلبات

- Python 3.6 أو أحدث
- لا توجد تبعيات خارجية مطلوبة

## التطوير

إذا كنت تريد المساهمة في تطوير هذه الحزمة:

```bash
# استنساخ المستودع
git clone https://github.com/faisalsalahi/faisal-salahi-calculator.git
cd faisal-salahi-calculator

# تثبيت التبعيات التطويرية
pip install -e .[dev]

# تشغيل الاختبارات
pytest

# فحص جودة الكود
flake8 faisal_salahi_calculator/
black faisal_salahi_calculator/
```

## الترخيص

هذا المشروع مرخص تحت [رخصة MIT](LICENSE). يمكنك استخدامه وتعديله وتوزيعه بحرية.

## التواصل

- **المطور**: فيصل الصلاحي
- **البريد الإلكتروني**: contact@faisalsalahi.com
- **GitHub**: [faisalsalahi](https://github.com/faisalsalahi)

## الإصدارات

### الإصدار 0.1.0
- الإصدار الأولي
- العمليات الحسابية الأساسية: الجمع، الطرح، الضرب، القسمة
- معالجة أخطاء القسمة على صفر
- توثيق شامل باللغة العربية

---

**ملاحظة**: هذه الحزمة تم تطويرها لأغراض تعليمية وتوضيحية. إذا كنت بحاجة إلى عمليات رياضية معقدة، يُنصح باستخدام مكتبات متخصصة مثل NumPy أو SciPy.
