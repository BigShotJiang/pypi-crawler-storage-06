"""Module for glchat_plugin handler."""
