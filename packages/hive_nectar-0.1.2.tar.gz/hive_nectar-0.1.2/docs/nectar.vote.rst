nectar.vote module
==================

.. automodule:: nectar.vote
   :members:
   :show-inheritance:
   :undoc-members:
