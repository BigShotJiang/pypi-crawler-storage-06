"""This script lists package constants."""

AUTH_REFRESHING_SPAN=15