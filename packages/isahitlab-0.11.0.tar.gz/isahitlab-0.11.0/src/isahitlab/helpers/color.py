
def to_bgr(rgb):
    return (rgb[2],rgb[1],rgb[0])
