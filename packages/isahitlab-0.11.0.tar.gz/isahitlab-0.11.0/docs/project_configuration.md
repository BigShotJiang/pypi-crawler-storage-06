# Project configuration module

::: isahitlab.actions.project_configuration