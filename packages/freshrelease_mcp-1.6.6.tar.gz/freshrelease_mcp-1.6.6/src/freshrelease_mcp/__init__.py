from .server import main

__version__ = "1.6.6"
__all__ = ["main"]

