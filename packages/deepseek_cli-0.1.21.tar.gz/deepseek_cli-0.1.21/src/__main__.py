"""Main entry point for DeepSeek CLI"""

from .cli.deepseek_cli import main

if __name__ == "__main__":
    main()
