# __init__.py

from multimodal_sdk.tenant.main import Tenant