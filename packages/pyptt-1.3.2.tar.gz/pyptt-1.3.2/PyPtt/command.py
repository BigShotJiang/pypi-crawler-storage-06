# http://www.physics.udel.edu/~watson/scen103/ascii.html
enter = '\r'
tab = '\t'
ctrl_c = '\x03'
ctrl_d = '\x04'
ctrl_e = '\x05'
ctrl_f = '\x06'
ctrl_h = '\x08'
ctrl_l = '\x0C'
ctrl_p = '\x10'
ctrl_u = '\x15'
ctrl_x = '\x18'
ctrl_y = '\x19'
ctrl_z = '\x1A'
star = '\x2A'
up = '\x1b\x4fA'
down = '\x1b\x4fB'
right = '\x1b\x4fC'
left = '\x1b\x4fD'

space = ' '
query_post = 'Q'
comment = 'X'
go_main_menu = ' ' + left * 5
go_main_menu_type_q = 'q' * 5
refresh = ctrl_l
control_code = ctrl_u + star
backspace = ctrl_h

page_up = 'P'
page_down = 'N'