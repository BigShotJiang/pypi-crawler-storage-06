\# egonzalezlib



This is a simple Python package that provides a helper function `add\_one(number)` which returns the given number plus one.



\## Usage

```python

from egonzalez import mod



print(mod.add\_one(5))  # Output: 6



