SPACE_FORMAT_PATTERN = r"[a-zA-Z][a-zA-Z0-9_-]{0,41}[a-zA-Z0-9]?$"
FORBIDDEN_SPACES = frozenset(["space", "cdf", "dms", "pg3", "shared", "system", "node", "edge"])
