"""CLI package for PDF2Foundry."""

from pdf2foundry.cli.main import app

__all__ = ["app"]
