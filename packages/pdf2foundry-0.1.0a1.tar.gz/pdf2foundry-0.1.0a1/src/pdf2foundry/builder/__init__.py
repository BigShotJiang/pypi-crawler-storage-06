"""Build-time utilities for assembling intermediate representations."""
