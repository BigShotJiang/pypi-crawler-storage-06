"""Tests of the SCM module."""
