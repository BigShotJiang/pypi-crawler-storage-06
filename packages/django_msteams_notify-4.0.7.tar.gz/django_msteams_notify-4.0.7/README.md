# Python Boilerplate

![PyPI version](https://img.shields.io/pypi/v/django-msteams-notify.svg)
[![Documentation Status](https://readthedocs.org/projects/django-msteams-notify/badge/?version=latest)](https://django-msteams-notify.readthedocs.io/en/latest/?version=latest)

Python Boilerplate contains all the boilerplate you need to create a Python package.

* PyPI package: https://pypi.org/project/django-msteams-notify/
* Free software: MIT License
* Documentation: https://django-msteams-notify.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
