# Boulder Opal Client

The Boulder Opal Client package is a Python client for Q-CTRL's Boulder Opal product. Boulder Opal is a versatile Python toolset that provides everything a research team needs to automate and improve the performance of hardware for quantum computing and quantum sensing.

See how you can [get started with Boulder Opal](https://docs.q-ctrl.com/boulder-opal/get-started) today.
