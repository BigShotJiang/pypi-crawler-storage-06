# cred-modex
Credit Risk Modeling Library in Python
