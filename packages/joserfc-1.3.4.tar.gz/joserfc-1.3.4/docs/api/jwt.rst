.. _jwt_api:

JWT API
=======

This part of the documentation covers all the interfaces of ``joserfc.jwt``.

.. automodule:: joserfc.jwt
    :members:
