<!--
SPDX-FileCopyrightText: © 2025 open-nudge <https://github.com/open-nudge>
SPDX-FileContributor: szymonmaszke <github@maszke.co>

SPDX-License-Identifier: Apache-2.0
-->

# Tests of pynudger

- `test_smoke.py` - generic
    [smoke tests](https://grafana.com/blog/2024/01/30/smoke-testing/)
    to check if the package is importable

<!-- Describe your testing here -->
