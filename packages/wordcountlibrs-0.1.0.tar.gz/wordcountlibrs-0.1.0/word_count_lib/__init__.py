from .core import count_words
