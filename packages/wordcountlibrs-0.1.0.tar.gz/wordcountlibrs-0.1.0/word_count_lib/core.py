def count_words(text: str) -> int:
    """Return the number of words in the text"""
    return len(text.split()) 
