from enum import Enum


class FileOsType(Enum):
    DIRECTORY = "Directory"
    FILE = "File"


