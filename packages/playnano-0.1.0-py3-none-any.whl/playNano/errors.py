"""Error classes for playNano."""


class LoadError(Exception):
    """Raised when loading AFM data fails."""

    pass
