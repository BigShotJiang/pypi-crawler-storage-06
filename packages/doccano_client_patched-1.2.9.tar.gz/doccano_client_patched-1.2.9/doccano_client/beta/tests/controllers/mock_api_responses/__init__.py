# NOTE: The unit tests that use these mocks should not be testing the actual API/mocks
#       The purpose is to test functionality AROUND the API. That's why the mocks here are focused
#       on good responses, not bad ones.
