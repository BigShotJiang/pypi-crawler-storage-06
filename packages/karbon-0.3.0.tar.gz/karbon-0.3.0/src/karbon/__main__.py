from karbon.karbon import Karbon


def main() -> None:
    app = Karbon()
    app.run()


if __name__ == "__main__":
    main()
