userPluginFilt = {"plugin": "peek_core_user"}
userPluginTuplePrefix = "peek_core_user."

userPluginObservableName = "peekPluginUser"

userPluginActionProcessorName = "peekPluginUser"
