export let userFilt = { plugin: "peek_core_user" };
export let userTuplePrefix = "peek_core_user.";
export let userObservableName = "peekPluginUser";
export let userTupleOfflineServiceName = "peekPluginUser";
export let userActionProcessorName = "peekPluginUser";
export let userBaseUrl = "peek_core_user";
