class UserAuthTargetEnum:
    INTERNAL = "INTERNAL"
    LDAP = "LDAP"
