"""Core module for report compilation functionality."""
