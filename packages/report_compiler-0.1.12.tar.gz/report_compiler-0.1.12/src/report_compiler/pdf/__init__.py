"""PDF processing module for PDF manipulation and overlay operations."""
