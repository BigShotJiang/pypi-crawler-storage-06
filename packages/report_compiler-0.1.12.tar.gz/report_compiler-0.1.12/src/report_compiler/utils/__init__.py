"""Utility module for shared functionality."""
