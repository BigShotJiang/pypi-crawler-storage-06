[
    BlockStruClean(
        lines=[
            LineStruClean(
                spans=[SpanStruClean(text="Setting Up React and TypeScript")]
            ),
            LineStruClean(spans=[SpanStruClean(text="82")]),
        ]
    ),
    BlockStruClean(
        lines=[
            LineStruClean(spans=[SpanStruClean(text="4.\t")]),
            LineStruClean(
                spans=[
                    SpanStruClean(text="Similarly, install a Babel plugin called "),
                    SpanStruClean(text=" that enables TypeScript "),
                ]
            ),
            LineStruClean(
                spans=[SpanStruClean(text="code to be transformed into JavaScript:")]
            ),
        ]
    ),
]

[
    LineStruClean(spans=[SpanStruClean(text="4.\t")]),
    LineStruClean(
        spans=[
            SpanStruClean(text="Similarly, install a Babel plugin called "),
            SpanStruClean(text="@babel/preset-typescript"),
            SpanStruClean(text=" that enables TypeScript "),
        ]
    ),
    LineStruClean(
        spans=[SpanStruClean(text="code to be transformed into JavaScript:")]
    ),
]
