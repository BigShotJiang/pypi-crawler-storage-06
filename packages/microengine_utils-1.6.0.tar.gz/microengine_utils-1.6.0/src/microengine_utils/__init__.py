from .scanner import scanalytics, create_scanner_exec, each_match
from .filesystem import as_wine_path, ArtifactTempfile
from .config import EngineInfo

__version__ = '1.6.0'
