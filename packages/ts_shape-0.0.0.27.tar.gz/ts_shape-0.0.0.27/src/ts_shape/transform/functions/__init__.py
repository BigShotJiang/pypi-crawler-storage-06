"""Functions

Column-wise function application helpers.

Classes:
- LambdaProcessor: Apply vectorized callables to columns.
  - apply_function: Apply a Python callable over a column's values.
"""
