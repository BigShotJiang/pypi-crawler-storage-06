"""Context Loaders

Helpers for context loading under the loader namespace.

Classes:
- None yet: Placeholder module for future context loader utilities.
"""
