"""Test individual elements of the Cutesy package."""
