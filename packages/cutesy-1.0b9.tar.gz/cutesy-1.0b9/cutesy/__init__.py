"""Lint & format an HTML document in Python."""

from .linter import HTMLLinter

__all__ = ["HTMLLinter"]
