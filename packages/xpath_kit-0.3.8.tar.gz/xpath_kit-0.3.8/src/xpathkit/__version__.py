__title__ = "xpath-kit"
__description__ = (
    "A toolkit for convenient and expressive XPath operations based on lxml."
)
__url__ = "https://pypi.org/project/xpath-kit/"
__version__ = "0.3.8"
__author__ = "kabxx"
__author_email__ = "2201174299@qq.com"
__license__ = "MIT"
__copyright__ = "Copyright (c) 2025 Kabxx"
