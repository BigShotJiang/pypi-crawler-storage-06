"""
Extractors for parsing Django views and extracting documentation information.
"""
