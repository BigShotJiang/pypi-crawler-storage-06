from weave.type_handlers.Video.lazy_import import install_hook

__all__ = ["install_hook"]
