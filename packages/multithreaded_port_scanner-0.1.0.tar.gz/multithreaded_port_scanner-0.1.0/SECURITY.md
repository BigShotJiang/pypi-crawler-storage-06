# Security & Abuse

If you believe this project has been used inappropriately, or you need to report a security issue or abuse, contact:

- Email: mohdxyasir@gmail.com

Please include:
- A short description of the issue
- Date/time (UTC) and relevant logs or evidence
- Steps to reproduce (if applicable)
- Contact details so we can follow up

I will respond as soon as possible. Note: I will not help with or endorse malicious use.
