"""mypackage - A simple CLI tool."""
__version__ = "0.1.0"

from .main import output

__all__ = ["output"]