
def output():
    """输出硬编码的 zhangning"""
    print("zhangning")

