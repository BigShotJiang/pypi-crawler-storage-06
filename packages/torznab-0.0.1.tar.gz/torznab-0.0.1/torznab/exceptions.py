class TorznabException(Exception):
    pass
