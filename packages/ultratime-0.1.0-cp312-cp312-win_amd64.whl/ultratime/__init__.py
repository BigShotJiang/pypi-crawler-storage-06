from .ultratime import *

__doc__ = ultratime.__doc__
if hasattr(ultratime, "__all__"):
    __all__ = ultratime.__all__