"""Odoo Backup Tool Package"""
__version__ = "0.3.0"