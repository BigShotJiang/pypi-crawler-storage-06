"""
.. include:: ../README.md
"""

from mlox.logging_config import configure_logging

configure_logging()
