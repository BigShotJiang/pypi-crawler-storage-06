# __init__.py
__version__ = "0.0.9.7"
author={
    'name':"Cavanşir","surname":"Qurbanzadə","username":"cavanshirpro","email":"cavanshirpro@gmail.com"
}
from .function import *
from .search import *