"""Tests for tap-stackexchange."""
