"""Test Configuration."""

from __future__ import annotations
