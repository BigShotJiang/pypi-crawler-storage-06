"""Singer tap for StackExchange sites."""
