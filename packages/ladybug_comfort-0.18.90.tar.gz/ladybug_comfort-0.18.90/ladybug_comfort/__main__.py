from ladybug_comfort.cli import comfort

if __name__ == '__main__':
    comfort()
