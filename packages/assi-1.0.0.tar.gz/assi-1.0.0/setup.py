from setuptools import setup, find_packages

setup(
    name="assi",
    version="1.0.0",
    description="A Super assistant in Python! There a lot of thing, And 1.0.0 is expand to Everything be Usable !",
    packages=find_packages(),
    python_requires=">=3.8",
)