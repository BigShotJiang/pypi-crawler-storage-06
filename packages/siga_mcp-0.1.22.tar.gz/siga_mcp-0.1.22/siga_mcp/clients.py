from langfuse._client.get_client import get_client

langfuse = get_client()
