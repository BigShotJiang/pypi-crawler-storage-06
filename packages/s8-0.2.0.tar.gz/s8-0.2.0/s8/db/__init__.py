# s8/db/__init__.py
from .database import user_collection, booking_collection, template_collection

__all__ = ["user_collection", "booking_collection", "template_collection"]
