"""
MCP (Model Context Protocol) 服务器模块

提供代码搜索的MCP协议实现
"""

__version__ = "1.0.0"