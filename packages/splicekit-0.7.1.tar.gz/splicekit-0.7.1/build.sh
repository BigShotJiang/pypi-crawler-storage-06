rm dist/* >/dev/null 2>&1
python -m build
