#!/bin/bash
snakemake "$@"
