# finally, run splicekit on this dataset

splicekit process
