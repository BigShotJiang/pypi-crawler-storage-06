"""Allow running the package directly with python -m panqake."""

from panqake.cli import main

if __name__ == "__main__":
    main()
