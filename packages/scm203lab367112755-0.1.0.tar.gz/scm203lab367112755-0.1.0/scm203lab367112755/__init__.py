from .lab3mod167112755 import gcd, extended_gcd, sieve_steps

__all__ = ["gcd","extended_gcd","sieve_steps"]