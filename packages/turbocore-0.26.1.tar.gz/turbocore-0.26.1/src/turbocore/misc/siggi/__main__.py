from turbocore.misc.siggi import main


if __name__ == "__main__":
    main()
