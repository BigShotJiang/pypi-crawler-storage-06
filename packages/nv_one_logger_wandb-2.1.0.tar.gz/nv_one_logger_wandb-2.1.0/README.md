# One Logger Weights and Biases (WandB) extension

This project contains extensions to enable using Weights and Biases as a backend for One Logger library.

## Minimum Requirements

- `python` version `>=3.9`.
- `urllib3` version `>=2.5.0`.