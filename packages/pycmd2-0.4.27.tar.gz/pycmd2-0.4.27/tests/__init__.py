"""Unit test package for pycmd2."""
