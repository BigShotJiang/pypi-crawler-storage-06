#
# Copyright (c) 2021 Airbyte, Inc., all rights reserved.
#

from .reports import CampaignAnalyticsReport

__all__ = ["CampaignAnalyticsReport"]
