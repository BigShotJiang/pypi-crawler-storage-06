This module adds some information related to delivery in the eBill
Postfinance integration.
