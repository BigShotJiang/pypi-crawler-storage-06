# docstring-to-text

A simple pip package converting docstrings into clean text (proper paragraphs and indents)
