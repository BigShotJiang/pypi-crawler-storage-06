# encoding: utf-8

VERSION = "0.0.1"
