# encoding: utf-8
"""
"""

from .__package_meta import VERSION
from .__package_meta import VERSION as __version__
