from ._edge import EdgeTTS

__all__ = ["EdgeTTS"]
