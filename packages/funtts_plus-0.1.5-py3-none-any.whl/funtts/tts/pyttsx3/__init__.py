from ._pyttsx3 import Pyttsx3TTS

__all__ = ["Pyttsx3TTS"]
