from ._espeak import EspeakTTS

__all__ = ["EspeakTTS"]
