from ._azure import AzureTTS

__all__ = ["AzureTTS"]
