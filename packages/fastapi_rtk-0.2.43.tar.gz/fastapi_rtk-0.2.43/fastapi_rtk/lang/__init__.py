from .lazy_text import *

__all__ = ["lazy_text", "translate", "_"]
