To use this module, you need to:

1.  Go to *Inventory \> Operations \> Return Request* and place a new
    return.

To make a return to a customer:

To make a return to a supplier:

To make a return to an internal location:
