"""Utilities for django-tailwind-cli."""
