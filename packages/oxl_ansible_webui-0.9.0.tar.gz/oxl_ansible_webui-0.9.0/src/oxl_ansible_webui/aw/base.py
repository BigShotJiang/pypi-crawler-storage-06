from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group

USERS = get_user_model()
GROUPS = Group
