# Security

We take security seriously and appreciate your efforts to responsibly disclose vulnerabilities. If you discover a security issue, please follow these steps:

**Contact Us**: Send a detailed report to [security@chanzuckerberg.com](mailto:security@chanzuckerberg.com). Include the steps to reproduce the issue and any relevant details.