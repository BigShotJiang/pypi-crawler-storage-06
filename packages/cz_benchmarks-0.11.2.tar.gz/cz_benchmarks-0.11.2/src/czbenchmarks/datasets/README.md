# cz-benchmarks Datsets

For complete details on the datasets, please refer to the links below:

- [How to add a Dataset](../../../docs/source/how_to_guides/add_custom_dataset.md)
- [Developer Guide](../../../docs/source/developer_guides/datasets.md)