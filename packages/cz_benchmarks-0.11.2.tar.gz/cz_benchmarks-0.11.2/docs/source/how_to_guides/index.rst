How To Guides
==============

The How To Guides offer step-by-step instructions for common customizations and usage scenarios.

.. toctree::
   :maxdepth: 1

   add_custom_dataset
   add_new_task
   add_new_metric
   guide_to_perturbation_expression_prediction_benchmark
   visualize_results
   setup_guides