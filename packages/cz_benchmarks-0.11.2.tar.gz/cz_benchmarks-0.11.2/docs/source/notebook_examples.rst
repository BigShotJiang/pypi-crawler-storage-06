Notebook Examples
=================

Interactive example notebooks demonstrating usage of cz-benchmarks.

.. toctree::
    :maxdepth: 1

    examples/scvi_all_tasks_benchmark.ipynb
    examples/scvi_model_dev_workflow.ipynb
    examples/using_czbenchmarks.ipynb
    examples/vcp_mlflow_model_benchmark.ipynb