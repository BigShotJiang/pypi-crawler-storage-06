.. include:: ../../LICENSE.md
   :parser: myst