# -*- coding: utf-8 -*-

def test():
    print()


if __name__ == '__main__':
    None
