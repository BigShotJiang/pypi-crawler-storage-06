## [1.1.6](https://github.com/trustedshops-public/schema2pyarrow/compare/1.1.5...1.1.6) (2025-09-24)


### Bug Fixes

* default to float64 if no example is given ([#13](https://github.com/trustedshops-public/schema2pyarrow/issues/13)) ([295d862](https://github.com/trustedshops-public/schema2pyarrow/commit/295d8628c3c5eaa5da36662000b20736d3f56ee3))

## [1.1.5](https://github.com/trustedshops-public/schema2pyarrow/compare/1.1.4...1.1.5) (2025-09-02)


### Bug Fixes

* allow the definition of multiple channels that form one message schema ([#11](https://github.com/trustedshops-public/schema2pyarrow/issues/11)) ([7c15039](https://github.com/trustedshops-public/schema2pyarrow/commit/7c15039b2f1da5a229c9cff50ec3dd16bce736cd))

## [1.1.4](https://github.com/trustedshops-public/schema2pyarrow/compare/1.1.3...1.1.4) (2025-07-01)


### Bug Fixes

* add more timetamp precision ([#4](https://github.com/trustedshops-public/schema2pyarrow/issues/4)) ([5f756fe](https://github.com/trustedshops-public/schema2pyarrow/commit/5f756fe2b2aa7355528e7ce249c653c73da1c260))

## [1.1.3](https://github.com/trustedshops-public/schema2pyarrow/compare/1.1.2...1.1.3) (2025-05-05)


### Bug Fixes

* allow using additonalProperties to define schemas ([#3](https://github.com/trustedshops-public/schema2pyarrow/issues/3)) ([ddfb6a4](https://github.com/trustedshops-public/schema2pyarrow/commit/ddfb6a4d46c3704625980573b3cbeccea43e3529))

## [1.1.2](https://github.com/trustedshops-public/schema2pyarrow/compare/1.1.1...1.1.2) (2025-02-11)


### Bug Fixes

* include python 3.10 as valid python version ([e3e9127](https://github.com/trustedshops-public/schema2pyarrow/commit/e3e9127d93f01a6f7c5fcac6ace3f45e2fc44250))

## [1.1.1](https://github.com/trustedshops-public/schema2pyarrow/compare/1.1.0...1.1.1) (2025-02-06)


### Bug Fixes

* no dependency for pip-publish ([a86c280](https://github.com/trustedshops-public/schema2pyarrow/commit/a86c28074db84cabba5ec1503cbcb1c39f6d66e6))

## [1.1.0](https://github.com/trustedshops-public/schema2pyarrow/compare/1.0.0...1.1.0) (2025-02-06)


### Features

* publish to pypi ([f6ae18d](https://github.com/trustedshops-public/schema2pyarrow/commit/f6ae18d8d5a2840c5c68733868c3a2544655277d))
