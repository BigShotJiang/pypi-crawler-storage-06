from ordeq_ibis.io.parquet import IbisParquet

__all__ = ("IbisParquet",)
