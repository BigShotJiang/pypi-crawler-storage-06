wstd_psy=3

edupsyadmin -w DEBUG -c taetigkeitsbericht $wstd_psy \
    FOS543 BOS93 BfsSp37 BfsKp106 BfsEV34 Faks80
