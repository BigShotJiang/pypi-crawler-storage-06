A basic REST API client and command line client for [Anomalo][anomalo]


[anomalo]: https://anomalo.com
