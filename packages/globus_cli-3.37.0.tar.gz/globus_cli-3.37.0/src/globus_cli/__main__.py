from globus_cli import main

main()
