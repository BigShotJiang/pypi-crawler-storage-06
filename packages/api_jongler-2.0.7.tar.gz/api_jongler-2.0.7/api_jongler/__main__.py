"""
Allow running APIJongler as a module: python -m api_jongler
"""

from .cli import main

if __name__ == "__main__":
    main()
