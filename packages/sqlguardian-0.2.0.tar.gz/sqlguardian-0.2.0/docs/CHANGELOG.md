# CHANGELOG


## v0.2.0 (2025-09-19)

### Features

- Initial release
  ([`d6f256b`](https://github.com/MicaelJarniac/sqlguardian/commit/d6f256bec2be6dd59f3d788dbd6090bc1326c9bd))


## v0.1.0 (2025-09-18)

### Chores

- Cleanup
  ([`54e7cff`](https://github.com/MicaelJarniac/sqlguardian/commit/54e7cffd247fffdba58d13af8f9d332595b7869d))

### Features

- Initial release, still WIP
  ([`06055f4`](https://github.com/MicaelJarniac/sqlguardian/commit/06055f4b3a0ec925d44492d49748cc7fc9dc12a3))


## v0.0.0 (2025-09-17)
