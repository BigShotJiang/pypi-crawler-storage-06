# Data Connector | Python SDK

### tutorial

https://packaging.python.org/en/latest/tutorials/packaging-projects/

### deploy

https://packaging.python.org/en/latest/tutorials/packaging-projects/#generating-distribution-archives
