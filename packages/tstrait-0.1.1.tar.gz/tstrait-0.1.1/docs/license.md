(license)=

# License

```{eval-rst}
.. include:: ../../../LICENSE
   :literal:
```
