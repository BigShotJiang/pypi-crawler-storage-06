#   MEDCoupling example

This example shows how to make a dashboard arranging several 2D plots. 

-   **grid_stack_example.py**, displays several plots on a GridStack layout : https://panel.holoviz.org/reference/layouts/GridStack.html
-   **split_item_example.py**, displays several plots on a multi Split layout : https://split.js.org/
-   **plot_api.py**, plots two slice of a medcoupling field in matplotlib subplots.
