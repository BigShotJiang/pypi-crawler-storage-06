#!/usr/bin/env python3

"""Command line entry point for sacad program."""

import sacad

if __name__ == "__main__":
    sacad.cl_main()
