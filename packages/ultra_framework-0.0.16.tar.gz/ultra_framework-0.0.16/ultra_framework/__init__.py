"""ultra_framework module"""
from ultra_framework.version import __version__
