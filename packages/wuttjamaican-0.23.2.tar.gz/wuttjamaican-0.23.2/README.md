
# WuttJamaican

Base package for Wutta Framework

See docs at https://docs.wuttaproject.org/wuttjamaican/
