
``wuttjamaican.people``
=======================

.. automodule:: wuttjamaican.people
   :members:
