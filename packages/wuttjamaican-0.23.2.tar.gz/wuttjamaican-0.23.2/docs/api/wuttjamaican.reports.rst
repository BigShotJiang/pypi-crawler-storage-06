
``wuttjamaican.reports``
========================

.. automodule:: wuttjamaican.reports
   :members:
