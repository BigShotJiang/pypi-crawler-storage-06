
``wuttjamaican.cli.base``
=========================

.. automodule:: wuttjamaican.cli.base
   :members:
