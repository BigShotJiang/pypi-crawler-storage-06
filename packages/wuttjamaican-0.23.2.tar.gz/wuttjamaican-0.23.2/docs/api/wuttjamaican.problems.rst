
``wuttjamaican.problems``
=========================

.. automodule:: wuttjamaican.problems
   :members:
