
``wuttjamaican.db.model.batch``
===============================

.. automodule:: wuttjamaican.db.model.batch
   :members:
