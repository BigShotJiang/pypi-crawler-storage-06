
``wuttjamaican.cli``
====================

.. automodule:: wuttjamaican.cli
   :members:
