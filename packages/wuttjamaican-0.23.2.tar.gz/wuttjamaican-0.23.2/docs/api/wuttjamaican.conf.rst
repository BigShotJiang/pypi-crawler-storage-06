
``wuttjamaican.conf``
=====================

.. automodule:: wuttjamaican.conf
   :members:
