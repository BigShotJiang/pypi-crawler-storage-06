
``wuttjamaican.db.model.auth``
==============================

.. automodule:: wuttjamaican.db.model.auth
   :members:
