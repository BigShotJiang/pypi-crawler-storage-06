
``wuttjamaican.cli.problems``
=============================

.. automodule:: wuttjamaican.cli.problems
   :members:
