
Overview
========

The :term:`handler` concept is central to the :term:`app` architecture.

They are analogous to "plugins" but only *one* handler is used for a
given purpose.  See :doc:`arch`.

So far there is only one handler type defined; see :doc:`app`.
