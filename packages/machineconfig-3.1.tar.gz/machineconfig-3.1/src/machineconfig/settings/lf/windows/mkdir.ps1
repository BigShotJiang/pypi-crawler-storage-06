
$name = Read-Host "Enter Directory Name: "
mkdir $name
