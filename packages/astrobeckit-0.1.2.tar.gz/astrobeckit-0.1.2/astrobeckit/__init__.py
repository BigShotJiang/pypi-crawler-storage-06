from .papergirl import papergirl

__all__ = ["papergirl"]