search\_query.search\_file
==========================

.. automodule:: search_query.search_file







   .. rubric:: Functions

   .. autosummary::

      load_search_file





   .. rubric:: Classes

   .. autosummary::

      SearchFile
