search\_query.constants
=======================

.. automodule:: search_query.constants











   .. rubric:: Classes

   .. autosummary::

      Colors
      ExitCodes
      Fields
      ListToken
      ListTokenTypes
      OperatorNodeTokenTypes
      Operators
      PLATFORM
      QueryErrorCode
      SearchField
      Token
      TokenTypes
