search\_query.wos.v\_0.translator
=================================

.. automodule:: search_query.wos.v_0.translator







   .. rubric:: Functions

   .. autosummary::

      register





   .. rubric:: Classes

   .. autosummary::

      WOSTranslator_v0
