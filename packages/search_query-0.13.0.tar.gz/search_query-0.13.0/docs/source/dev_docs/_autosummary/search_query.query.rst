search\_query.query
===================

.. automodule:: search_query.query











   .. rubric:: Classes

   .. autosummary::

      Query
