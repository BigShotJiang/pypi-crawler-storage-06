search\_query.pre\_notation
===========================

.. automodule:: search_query.pre_notation
