search\_query.serializer\_base
==============================

.. automodule:: search_query.serializer_base











   .. rubric:: Classes

   .. autosummary::

      StringSerializer
