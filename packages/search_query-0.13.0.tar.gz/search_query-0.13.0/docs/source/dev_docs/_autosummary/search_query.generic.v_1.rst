search\_query.generic.v\_1
==========================

.. automodule:: search_query.generic.v_1



















.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   search_query.generic.v_1.serializer
