search\_query.database\_queries
===============================

.. automodule:: search_query.database_queries
