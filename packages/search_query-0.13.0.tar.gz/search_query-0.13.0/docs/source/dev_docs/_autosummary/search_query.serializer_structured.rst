search\_query.serializer\_structured
====================================

.. automodule:: search_query.serializer_structured







   .. rubric:: Functions

   .. autosummary::

      to_string_structured
      to_string_structured_2
