search\_query.cli
=================

.. automodule:: search_query.cli







   .. rubric:: Functions

   .. autosummary::

      main
