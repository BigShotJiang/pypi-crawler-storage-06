search\_query.generic.v\_1.serializer
=====================================

.. automodule:: search_query.generic.v_1.serializer







   .. rubric:: Functions

   .. autosummary::

      register





   .. rubric:: Classes

   .. autosummary::

      GenericSerializer_v1
