search\_query.wos.v\_0.serializer
=================================

.. automodule:: search_query.wos.v_0.serializer







   .. rubric:: Functions

   .. autosummary::

      register





   .. rubric:: Classes

   .. autosummary::

      WOSSerializer_v0
