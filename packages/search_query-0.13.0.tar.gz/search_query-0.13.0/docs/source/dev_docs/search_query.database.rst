﻿search\_query.database
======================

.. automodule:: search_query.database







   .. rubric:: Functions

   .. autosummary::

      list_queries
      list_queries_with_details
      load_query
