#!/usr/bin/env python3
"""WoS v0."""

__author__ = """Gerit Wagner"""
__email__ = "gerit.wagner@hec.ca"
