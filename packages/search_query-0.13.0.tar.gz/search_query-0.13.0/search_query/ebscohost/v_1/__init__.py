#!/usr/bin/env python3
"""EBSCOHost v1."""

__author__ = """Gerit Wagner"""
__email__ = "gerit.wagner@hec.ca"
