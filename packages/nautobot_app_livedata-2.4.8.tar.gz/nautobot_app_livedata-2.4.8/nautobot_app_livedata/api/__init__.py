"""REST API module for Nautobot App Livedata."""

# Filepath: nautobot_app_livedata/api/__init__.py
