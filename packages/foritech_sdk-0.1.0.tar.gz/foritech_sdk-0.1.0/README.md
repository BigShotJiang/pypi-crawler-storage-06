# Foritech SDK
Локален README за Python пакета. За пълна документация виж ../README.md.
# Foritech SDK

Python SDK for Foritech Secure System.
