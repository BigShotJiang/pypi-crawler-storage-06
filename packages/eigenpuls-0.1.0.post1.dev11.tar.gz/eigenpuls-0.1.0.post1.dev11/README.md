# eigenpuls
eigenpulsd: A decoupled health checker daemon. 

Actively probes the status of services (Redis, Postgres, etc.) via native commands and provides the aggregated status through a unified API. Designed for maximum autonomy in containerized and hybrid architectures. The characteristic pulse of your system.
