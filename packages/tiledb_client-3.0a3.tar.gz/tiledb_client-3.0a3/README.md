# tiledb-client

The next generation Python client for TileDB.

This project provides a `tiledb.client` module and a `tiledb.cloud` module. The
latter provides some backwards compatibility by re-exporting `tiledb.client`
names from the `tiledb.cloud` namespaces. Installing the tiledb-client package
installs both those modules.

tiledb-client is incompatible with tiledb-cloud versions < 1 (all versions on
PyPI). Avoid installing tiledb-cloud in Python environments where tiledb-client
wil be installed.

## Installation

`pip install tiledb-client`

## Quickstart

```python
import tiledb.client

tiledb.client.login(
    username="USERNAME",
    password="PASSWORD",
    workspace="WORKSPACE"
)
tiledb.client.teamspaces.list_teamspaces()
```
