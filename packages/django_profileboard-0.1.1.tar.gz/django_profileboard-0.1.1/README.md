# Django ProfileBoard

A production-ready Django performance profiler with live dashboard capabilities.

## Documentation

Full documentation is available at [django-profileboard.readthedocs.io](https://django-profileboard.readthedocs.io).
