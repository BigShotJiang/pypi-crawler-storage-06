"""Top-level package for termai."""

__version__ = "1.6.1"

__all__ = ["__version__"]
