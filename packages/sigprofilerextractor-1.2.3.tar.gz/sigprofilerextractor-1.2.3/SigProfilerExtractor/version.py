
# THIS FILE IS GENERATED FROM SIGPROFILEREXTRACTOR SETUP.PY
short_version = '1.2.3'
version = '1.2.3'
Update = 'v1.2.3: Add support for rn7 and mm39 genomes'
    
    