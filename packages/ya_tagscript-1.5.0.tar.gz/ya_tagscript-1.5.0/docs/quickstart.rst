==========
Quickstart
==========

.. literalinclude:: code_examples/quickstart_example.py
    :caption: An example setup
    :language: Python
