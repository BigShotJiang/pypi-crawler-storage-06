from typing import TypeAlias

Seconds: TypeAlias = int
