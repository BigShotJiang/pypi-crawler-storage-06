Getting started
===============

.. toctree::
    :numbered:

    tutorials/1 - Read data and get betas.ipynb
    tutorials/2 - QC.ipynb
    tutorials/3 - DMPs and DMRs.ipynb
    tutorials/4 - Copy Number Variation.ipynb
    tutorials/5 - Pathway analysis.ipynb
