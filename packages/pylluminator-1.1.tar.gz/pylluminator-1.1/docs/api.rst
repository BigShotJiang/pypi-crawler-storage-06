API
===

.. autosummary::
    :toctree: _autosummary 
    :template: custom-module-template.rst
    :recursive: 

    pylluminator.annotations
    pylluminator.cnv
    pylluminator.dm
    pylluminator.mask
    pylluminator.quality_control
    pylluminator.read_idat
    pylluminator.sample_sheet
    pylluminator.samples
    pylluminator.stats
    pylluminator.utils
    pylluminator.visualizations

