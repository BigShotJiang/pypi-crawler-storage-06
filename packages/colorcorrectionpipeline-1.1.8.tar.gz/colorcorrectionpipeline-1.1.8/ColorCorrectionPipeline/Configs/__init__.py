from .configs import Config

__all__ = ['Config']