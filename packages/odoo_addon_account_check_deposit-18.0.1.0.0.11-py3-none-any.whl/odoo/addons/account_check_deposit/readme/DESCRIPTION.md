This module allows you to easily manage check deposits: you can select
all the checks you received and create a global deposit for the selected
checks. This module supports multi-currency ; each deposit has a
currency and all the checks of the deposit must have the same currency
(so, if you have checks in EUR and checks in USD, you must create 2
deposits: one in EUR and one in USD).
