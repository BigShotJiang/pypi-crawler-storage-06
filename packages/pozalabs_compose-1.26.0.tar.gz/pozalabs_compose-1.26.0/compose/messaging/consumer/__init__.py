from .general import MessageConsumer

__all__ = ["MessageConsumer"]
