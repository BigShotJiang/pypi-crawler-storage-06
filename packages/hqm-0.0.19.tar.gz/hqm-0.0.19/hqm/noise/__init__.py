"""
   .. include:: ./noise.md
"""

from .gaussianlike import *