

class OnlineRequest(object):
    def __init__(self, values=None, json=None):
        self.values = values
        self.json = json
