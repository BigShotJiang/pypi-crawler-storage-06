"""
This module contains generic methods that operates on native python types and do
not depend on external libraries.
"""

from ._utils import *