"""
You-get core library integrated into MCP service
"""

__version__ = "1.0.0"
