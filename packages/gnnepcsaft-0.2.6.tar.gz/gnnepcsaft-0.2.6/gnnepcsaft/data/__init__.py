"""
Module for the dataset building part of the GNN-ePC-SAFT project.

"""
