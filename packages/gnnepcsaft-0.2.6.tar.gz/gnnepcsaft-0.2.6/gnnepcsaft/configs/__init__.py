"""
Module for the training run configs of the GNN-ePC-SAFT project.

"""
