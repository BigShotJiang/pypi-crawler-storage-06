"""
Module for GNN-ePC-SAFT project demonstration.

"""
