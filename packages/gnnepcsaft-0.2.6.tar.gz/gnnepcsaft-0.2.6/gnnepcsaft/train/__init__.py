"""
Module for the train part of the GNN-ePC-SAFT project.

"""
