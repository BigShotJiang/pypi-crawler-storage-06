# pylint: disable=invalid-name
"""
GNNePCSAFT.

"""
