import os
from setuptools import setup, find_packages

setup(
    name='postalert',
    version='0.1.0',
    packages=find_packages(),
    include_package_data=True,
    package_data={'postalert': ['config.yml']},
    install_requires=[
        'requests',
        'PyYAML',
        'tldextract',
        'whispers',
    ],
    entry_points={
        'console_scripts': [
            'postalert=postalert.__main__:main',
        ],
    },
    author='Muthu D.',
    author_email='talktomuthud@gmail.com',
    description='PostAlert: Bug bounty secret scanning tool with Discord alerts',
    long_description=open('README.md').read() if os.path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    url='https://github.com/muthud-anonysm/postalert',  # optional
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
    python_requires='>=3.7',
)
