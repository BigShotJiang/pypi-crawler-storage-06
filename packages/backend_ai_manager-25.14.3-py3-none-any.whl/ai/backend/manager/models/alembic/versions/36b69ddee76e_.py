"""empty message

Revision ID: 36b69ddee76e
# Revises: 3efd66393bd0, f108628f032b
Revises: f108628f032b
Create Date: 2023-02-22 06:46:02.379245

"""

# revision identifiers, used by Alembic.
revision = "36b69ddee76e"
down_revision = "f108628f032b"
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
