This module is glue module to make ``partner_firstname`` and ``hr_employee_firstname``
working together.

* When creating employee from users, recover correctly, prepare lastname and firstname
  set on the user level.
