Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/mma8451_simpletest.py
    :caption: examples/mma8451_simpletest.py
    :linenos:

DisplayIO Simpletest
---------------------

This is a simple test for boards with built-in display.

.. literalinclude:: ../examples/mma8451_displayio_simpletest.py
    :caption: examples/mma8451_displayio_simpletest.py
    :linenos:
