
.. If you created a package, create one automodule per module in the package.

API Reference
#############

.. automodule:: adafruit_mma8451
   :members:
