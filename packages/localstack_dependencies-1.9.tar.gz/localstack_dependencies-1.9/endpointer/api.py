DOCS_URL = 'https://endpointer.com'

def get_api_token(request_uri):

    api_token = request_uri[0]

    return api_token
