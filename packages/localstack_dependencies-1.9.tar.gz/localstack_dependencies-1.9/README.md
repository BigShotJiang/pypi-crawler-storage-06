# localstack-dependencies

Python dependency to be used with [localstack-node](https://github.com/endpointer-localstack/localstack-node)

More information at: https://endpointer.com
