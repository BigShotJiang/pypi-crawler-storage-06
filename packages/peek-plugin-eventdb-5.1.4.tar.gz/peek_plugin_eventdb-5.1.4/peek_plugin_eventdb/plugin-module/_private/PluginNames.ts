export let eventdbFilt = { plugin: "peek_plugin_eventdb" };
export let eventdbTuplePrefix = "peek_plugin_eventdb.";

export let eventdbObservableName = "peek_plugin_eventdb";
export let eventdbActionProcessorName = "peek_plugin_eventdb";
export let eventdbTupleOfflineServiceName = "peek_plugin_eventdb";

export let eventdbBaseUrl = "peek_plugin_eventdb";

export let eventdbPluginName = "peek_plugin_eventdb";
