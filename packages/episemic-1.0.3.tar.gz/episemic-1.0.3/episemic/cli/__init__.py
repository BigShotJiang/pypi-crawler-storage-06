"""CLI module for Episemic Core."""

from .main import app

__all__ = ["app"]
