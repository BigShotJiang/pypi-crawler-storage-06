"""Consolidation module - Memory consolidation and knowledge distillation."""

from .consolidation import ConsolidationEngine

__all__ = ["ConsolidationEngine"]
