import Alpine from 'alpinejs'

window.Alpine = Alpine

export default Alpine
