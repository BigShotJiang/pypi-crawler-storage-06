"""This bescli provides a command line interface to interact with besapi."""

# https://stackoverflow.com/questions/279237/import-a-module-from-a-relative-path/4397291

from . import bescli
