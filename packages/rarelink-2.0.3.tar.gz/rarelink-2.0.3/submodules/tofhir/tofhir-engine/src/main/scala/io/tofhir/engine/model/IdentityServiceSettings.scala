package io.tofhir.engine.model

/**
 * Interface for settings for identity service
 */
trait IdentityServiceSettings
