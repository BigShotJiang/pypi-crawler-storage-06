DROP TABLE patients;

DROP TABLE otherobservations;
