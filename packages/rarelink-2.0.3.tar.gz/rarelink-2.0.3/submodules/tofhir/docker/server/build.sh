# Execute one of the following commands from the project.root.directory (../../)

docker build -f docker/server/Dockerfile -t srdc/tofhir-server:latest .

