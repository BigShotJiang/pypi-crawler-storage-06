"""
Utility modules for prarabdha.
"""
