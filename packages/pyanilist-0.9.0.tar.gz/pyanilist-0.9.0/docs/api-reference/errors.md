::: pyanilist.AnilistError
::: pyanilist.MediaNotFoundError
::: pyanilist.InvalidMediaQueryError
::: pyanilist.RateLimitError
