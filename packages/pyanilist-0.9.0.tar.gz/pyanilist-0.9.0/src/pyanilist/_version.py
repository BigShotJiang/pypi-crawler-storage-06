from __future__ import annotations

from typing import Final

__version__: Final = "0.9.0"
