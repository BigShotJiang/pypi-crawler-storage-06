from stream4py.functional import NoItem
from stream4py.functional import Stream

__all__ = ["NoItem", "Stream"]
