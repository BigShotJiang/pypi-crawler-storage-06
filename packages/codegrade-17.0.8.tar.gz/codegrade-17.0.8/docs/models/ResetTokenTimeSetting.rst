ResetTokenTimeSetting
=====================

.. currentmodule:: codegrade.models.reset_token_time_setting

.. autoclass:: ResetTokenTimeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
