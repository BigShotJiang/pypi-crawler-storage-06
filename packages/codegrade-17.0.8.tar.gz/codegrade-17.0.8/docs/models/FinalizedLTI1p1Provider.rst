FinalizedLTI1p1Provider
=======================

.. currentmodule:: codegrade.models.finalized_lti1p1_provider

.. autoclass:: FinalizedLTI1p1Provider
   :members: finalized
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
