AutoTestRunProgramMessageSetting
================================

.. currentmodule:: codegrade.models.auto_test_run_program_message_setting

.. autoclass:: AutoTestRunProgramMessageSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
