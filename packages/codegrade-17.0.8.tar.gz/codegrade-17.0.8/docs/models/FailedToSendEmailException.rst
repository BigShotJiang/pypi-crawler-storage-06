FailedToSendEmailException
==========================

.. currentmodule:: codegrade.models.failed_to_send_email_exception

.. autoclass:: FailedToSendEmailException
   :members: all_users, failed_users
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
