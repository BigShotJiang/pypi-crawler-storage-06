IOTestOption
============

.. currentmodule:: codegrade.models.io_test_option

.. class:: IOTestOption

**Options**

* ``case``
* ``trailing_whitespace``
* ``substring``
* ``regex``
* ``all_whitespace``
