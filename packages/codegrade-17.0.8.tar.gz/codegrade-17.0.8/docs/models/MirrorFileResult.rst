MirrorFileResult
================

.. currentmodule:: codegrade.models.mirror_file_result

.. autoclass:: MirrorFileResult
   :members: url, name, output_name, mime
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
