RuleType
========

.. currentmodule:: codegrade.models.rule_type

.. class:: RuleType

**Options**

* ``allow``
* ``deny``
* ``require``
