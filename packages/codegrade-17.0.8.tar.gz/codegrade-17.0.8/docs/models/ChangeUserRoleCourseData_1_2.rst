ChangeUserRoleCourseData_1_2
============================

.. currentmodule:: codegrade.models.change_user_role_course_data

.. autoclass:: ChangeUserRoleCourseData_1_2
   :members: role_id, username, tenant_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
