DirectoryWithChildren
=====================

.. currentmodule:: codegrade.models.directory_with_children

.. autoclass:: DirectoryWithChildren
   :members: entries
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
