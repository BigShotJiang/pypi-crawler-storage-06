BulkEnrollCourseData
====================

.. currentmodule:: codegrade.models.bulk_enroll_course_data

.. autoclass:: BulkEnrollCourseData
   :members: users
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
