AccessPlanPurchaseSummary
=========================

.. currentmodule:: codegrade.models.access_plan_purchase_summary

.. autoclass:: AccessPlanPurchaseSummary
   :members: scope, id, success_at, purchased_item
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
