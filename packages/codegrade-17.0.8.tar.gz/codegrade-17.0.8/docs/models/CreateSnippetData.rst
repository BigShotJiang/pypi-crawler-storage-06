CreateSnippetData
=================

.. currentmodule:: codegrade.models.create_snippet_data

.. autoclass:: CreateSnippetData
   :members: key, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
