PatchNotificationSettingUserSettingData
=======================================

.. currentmodule:: codegrade.models.patch_notification_setting_user_setting_data

.. autoclass:: PatchNotificationSettingUserSettingData
   :members: reason, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
