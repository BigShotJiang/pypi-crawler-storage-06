JsonPatchSubmitTypesAssignment
==============================

.. currentmodule:: codegrade.models.json_patch_submit_types_assignment

.. autoclass:: JsonPatchSubmitTypesAssignment
   :members: files_upload_enabled, webhook_upload_enabled, webhook_configuration, editor_upload_enabled
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
