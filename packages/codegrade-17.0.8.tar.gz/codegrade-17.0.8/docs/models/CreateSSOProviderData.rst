CreateSSOProviderData
=====================

.. currentmodule:: codegrade.models.create_sso_provider_data

.. autoclass:: CreateSSOProviderData
   :members: metadata_url, description, tenant_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
