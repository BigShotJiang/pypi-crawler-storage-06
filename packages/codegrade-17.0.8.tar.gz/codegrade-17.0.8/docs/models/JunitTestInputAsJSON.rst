JunitTestInputAsJSON
====================

.. currentmodule:: codegrade.models.junit_test_input_as_json

.. autoclass:: JunitTestInputAsJSON
   :members: 
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
