AccessTokenToastWarningTimeSetting
==================================

.. currentmodule:: codegrade.models.access_token_toast_warning_time_setting

.. autoclass:: AccessTokenToastWarningTimeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
