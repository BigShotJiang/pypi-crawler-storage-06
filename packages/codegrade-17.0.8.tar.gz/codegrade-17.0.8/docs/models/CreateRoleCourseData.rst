CreateRoleCourseData
====================

.. currentmodule:: codegrade.models.create_role_course_data

.. autoclass:: CreateRoleCourseData
   :members: name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
