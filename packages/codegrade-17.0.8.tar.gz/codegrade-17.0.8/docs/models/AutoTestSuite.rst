AutoTestSuite
=============

.. currentmodule:: codegrade.models.auto_test_suite

.. autoclass:: AutoTestSuite
   :members: id, steps, rubric_row, network_disabled, submission_info, command_time_limit
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
