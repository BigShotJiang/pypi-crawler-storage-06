RegisterUserData
================

.. currentmodule:: codegrade.models.register_user_data

.. autoclass:: RegisterUserData
   :members: username, password, email, name, tenant_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
