ExportAssignmentCSVData
=======================

.. currentmodule:: codegrade.models.export_assignment_csv_data

.. autoclass:: ExportAssignmentCSVData
   :members: type, columns, user_ids
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
