Assignment
==========

.. currentmodule:: codegrade.models.assignment

.. autoclass:: Assignment
   :members: id, name, created_at, course_id, has_multiple_timeframes, is_lti, has_description, timeframe, grade_availability, kind
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
