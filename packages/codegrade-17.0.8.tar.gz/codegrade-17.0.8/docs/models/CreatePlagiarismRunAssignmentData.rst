CreatePlagiarismRunAssignmentData
=================================

.. currentmodule:: codegrade.models.create_plagiarism_run_assignment_data

.. autoclass:: CreatePlagiarismRunAssignmentData
   :members: json, base_code, old_submissions
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
