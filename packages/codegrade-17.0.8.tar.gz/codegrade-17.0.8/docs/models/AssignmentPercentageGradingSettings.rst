AssignmentPercentageGradingSettings
===================================

.. currentmodule:: codegrade.models.assignment_percentage_grading_settings

.. autoclass:: AssignmentPercentageGradingSettings
   :members: scale
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
