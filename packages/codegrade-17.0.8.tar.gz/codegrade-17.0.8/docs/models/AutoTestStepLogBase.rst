AutoTestStepLogBase
===================

.. currentmodule:: codegrade.models.auto_test_step_log_base

.. autoclass:: AutoTestStepLogBase
   :members: 
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
