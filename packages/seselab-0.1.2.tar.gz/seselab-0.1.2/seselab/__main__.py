from .bench import main
main()
