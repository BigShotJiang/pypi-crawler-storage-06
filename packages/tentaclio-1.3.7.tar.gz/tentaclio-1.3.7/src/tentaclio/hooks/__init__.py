"""Hooks that use tentaclio clients."""
# TODO maybe move this guy somewhere else out of this repo
from .slack_hook import *  # noqa
