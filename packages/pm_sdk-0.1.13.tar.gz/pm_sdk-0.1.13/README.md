This is the code for our pip package to use Photometrica from Python.

Currently a WIP as of March 12th 2025