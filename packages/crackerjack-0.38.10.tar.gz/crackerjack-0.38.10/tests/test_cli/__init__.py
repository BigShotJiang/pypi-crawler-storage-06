"""Test package for CLI integration tests."""
