"""phykit.__main__: executed when phykit is called as script"""
import sys

from .phykit import Phykit

Phykit()
