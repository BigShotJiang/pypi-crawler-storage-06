This module allows you to send branded quotations and sales orders to
your customers. It adds a brand field on the quotation and propagate the
value on the invoices.
