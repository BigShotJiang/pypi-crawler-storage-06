To use this module, you need to:

1.  Go to Sales \> Quotations
2.  Select or create a quotation
3.  Enter the information and the brand
4.  Confirm the quotation and generate an invoice, invoice will have brand details from sale order
