# `pyprik` v0.2.0 - Enhanced Agent Architecture! 🤖

PyPi LINK : https://pypi.org/project/pyprik/

**pyprik** is an intelligent data matching library that finds the best matching items based on your requirements. Now enhanced with Large Language Model (LLM) capabilities for natural language responses!

## 🚀 New in v0.2.0

- **🏗️ Enhanced Agent Architecture**: Cleaner import structure with `from pyprik.agent import serveragent`
- **🤖 LLM Integration**: Get natural language responses for your searches
- **💬 Conversational Search**: Search using natural language queries
- **📊 Smart Explanations**: Understand why certain results were matched
- **🌐 REST API Server**: FastAPI server with intelligent endpoints
- **🔧 Multi-LLM Support**: Works with OpenAI GPT and Google Gemini models

## Install the Package

```bash
pip install pyprik
```

## Quick Start

### New Agent Import Pattern (v0.2.0+)

```python
# Import server agent using new pattern
from pyprik.agent import serveragent

# Start server
serveragent.run_server(host="127.0.0.1", port=8000)

# Or create server instance
server = serveragent.create_server_agent()
```

### Traditional Usage (Still Works!)

```python
from pyprik import find_top_matching
import pandas as pd

# Your data
data = {
    'Product': ['Laptop', 'Smartphone', 'Tablet'],
    'Brand': ['Dell', 'Apple', 'Samsung'],
    'RAM': ['8GB', '4GB', '6GB'],
    'Price': [600, 999, 300]
}
products = pd.DataFrame(data)

# Find matches
requirements = {'Brand': 'Apple', 'RAM': '4GB'}
results = find_top_matching(products, requirements, top_n=2)
print(results)
```

### LLM-Enhanced Usage

```python
from pyprik import smart_product_search, setup_default_llm
import os

# Setup LLM (requires API key)
setup_default_llm('openai', 'gpt-3.5-turbo')  # or 'gemini', 'gemini-pro'

# Get natural language response
response = smart_product_search(
    dataset=products,
    requirements={'Brand': 'Apple'},
    top_n=3,
    natural_response=True
)
print(response)
# Output: "I found 2 Apple products that match your criteria. The iPhone stands out with..."
```

## 🌐 REST API Server

Start an intelligent search server using the new agent architecture:

```python
# New recommended way (v0.2.0+)
from pyprik.agent import serveragent

# Start server
serveragent.run_server(host="127.0.0.1", port=8000)

# Or create server instance
server = serveragent.create_server_agent()
```

Legacy import still works:
```python
from pyprik import run_server
run_server(host="127.0.0.1", port=8000)
```

### API Endpoints

- `POST /search` - Intelligent product search
- `POST /conversational-search` - Natural language search
- `POST /explain` - Explain search results
- `POST /configure-llm` - Configure LLM settings
- `POST /upload-dataset` - Upload your dataset
- `GET /dataset-info` - Get dataset information

## 🔧 Setup for LLM Features

1. **Get an API Key**:
   - OpenAI: https://platform.openai.com/api-keys
   - Google AI Studio: https://makersuite.google.com/app/apikey

2. **Set Environment Variable**:
   ```bash
   # For OpenAI
   export OPENAI_API_KEY="your-api-key-here"
   
   # For Gemini
   export GEMINI_API_KEY="your-api-key-here"
   ```

3. **Install Optional Dependencies** (if not auto-installed):
   ```bash
   pip install openai google-generativeai fastapi uvicorn
   ```

## 📚 Examples

Run the included examples:

```bash
# Basic LLM demo
python examples/llm_demo.py

# Interactive server demo
python examples/server_demo.py

# New agent architecture demo
python examples/agent_demo.py
```

## 🔄 Migration Guide

Your existing code will continue to work! The new agent architecture is additive:

```python
# v0.0.1 code still works
from pyprik import find_top_matching
results = find_top_matching(data, requirements, top_n)

# v0.1.0 added LLM capabilities
from pyprik import smart_product_search
enhanced_results = smart_product_search(data, requirements, natural_response=True)

# v0.2.0 adds cleaner agent imports
from pyprik.agent import serveragent
server = serveragent.create_server_agent()
```

## 📄 License

MIT License - see LICENSE.txt for details.