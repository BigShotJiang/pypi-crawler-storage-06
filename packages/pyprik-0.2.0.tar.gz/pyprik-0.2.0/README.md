# `pyprik` v0.2.0 - Enhanced Agent Architecture! 🤖

PyPi LINK : https://pypi.org/project/pyprik/

**pyprik** is an intelligent data matching library that finds the best matching items based on your requirements. Now enhanced with Large Language Model (LLM) capabilities for natural language responses!

## 🚀 New in v0.2.0

- **🏗️ Enhanced Agent Architecture**: Cleaner import structure with `from pyprik.agent import serveragent`
- **🤖 LLM Integration**: Get natural language responses for your searches
- **💬 Conversational Search**: Search using natural language queries
- **📊 Smart Explanations**: Understand why certain results were matched
- **🌐 REST API Server**: FastAPI server with intelligent endpoints
- **🔧 Multi-LLM Support**: Works with OpenAI GPT and Google Gemini models

## Install the Package

```bash
pip install pyprik
```

## Quick Start

### Traditional Usage (Still Works!)

```python
from pyprik import find_top_matching
import pandas as pd

# Your data
data = {
    'Product': ['Laptop', 'Smartphone', 'Tablet'],
    'Brand': ['Dell', 'Apple', 'Samsung'],
    'RAM': ['8GB', '4GB', '6GB'],
    'Price': [600, 999, 300]
}
products = pd.DataFrame(data)

# Find matches
requirements = {'Brand': 'Apple', 'RAM': '4GB'}
results = find_top_matching(products, requirements, top_n=2)
print(results)
```

### New LLM-Enhanced Usage

```python
from pyprik import smart_product_search, setup_default_llm
import os

# Setup LLM (requires API key)
setup_default_llm('openai', 'gpt-3.5-turbo')  # or 'gemini', 'gemini-pro'

# Get natural language response
response = smart_product_search(
    dataset=products,
    requirements={'Brand': 'Apple'},
    top_n=3,
    natural_response=True
)
print(response)
# Output: "I found 2 Apple products that match your criteria. The iPhone stands out with..."
```

### Conversational Search

```python
from pyprik import conversational_search

# Search with natural language
response = conversational_search(
    dataset=products,
    user_query="I want a powerful computer under $800"
)
print(response)
```

## 🌐 REST API Server

Start an intelligent search server using the new agent architecture:

```python
# New recommended way (v0.2.0+)
from pyprik.agent import serveragent

# Start server
serveragent.run_server(host="127.0.0.1", port=8000)

# Or create server instance
server = serveragent.create_server_agent()
```

Legacy import still works:
```python
from pyprik import run_server
run_server(host="127.0.0.1", port=8000)
```

### API Endpoints

- `POST /search` - Intelligent product search
- `POST /conversational-search` - Natural language search
- `POST /explain` - Explain search results
- `POST /configure-llm` - Configure LLM settings
- `POST /upload-dataset` - Upload your dataset
- `GET /dataset-info` - Get dataset information

### Example API Usage

```bash
# Upload dataset
curl -X POST "http://127.0.0.1:8000/upload-dataset" \
  -H "Content-Type: application/json" \
  -d '{"data": [{"Product": "Laptop", "Brand": "Dell", "Price": 600}]}'

# Search with natural language response
curl -X POST "http://127.0.0.1:8000/search" \
  -H "Content-Type: application/json" \
  -d '{"requirements": {"Brand": "Dell"}, "natural_response": true}'

# Conversational search
curl -X POST "http://127.0.0.1:8000/conversational-search" \
  -H "Content-Type: application/json" \
  -d '{"query": "Find me a good laptop for programming"}'
```

## 🔧 Setup for LLM Features

1. **Get an API Key**:
   - OpenAI: https://platform.openai.com/api-keys
   - Google AI Studio: https://makersuite.google.com/app/apikey

2. **Set Environment Variable**:
   ```bash
   # For OpenAI
   export OPENAI_API_KEY="your-api-key-here"
   
   # For Gemini
   export GEMINI_API_KEY="your-api-key-here"
   ```

3. **Install Optional Dependencies** (if not auto-installed):
   ```bash
   pip install openai google-generativeai fastapi uvicorn
   ```

## 📚 Examples

Run the included examples:

```bash
# Basic LLM demo
python examples/llm_demo.py

# Interactive server demo
python examples/server_demo.py
```

## 🔍 Core Functions

### Traditional Functions
- `find_top_matching(dataset, requirements, top_n)` - Find best matches
- `find_matching(dataset, requirements)` - Get all matches with scores

### New LLM Functions
- `smart_product_search()` - Enhanced search with LLM responses
- `conversational_search()` - Natural language search
- `explain_search_results()` - Detailed explanations
- `setup_default_llm()` - Configure LLM settings

### Server Functions
- `run_server()` - Start FastAPI server
- `create_server_agent()` - Create server instance

## 🎯 Use Cases

- **E-commerce**: "Find me wireless headphones under $100"
- **Real Estate**: "Show me 3-bedroom houses near downtown"
- **Job Matching**: "Find software engineer positions with remote work"
- **Product Catalogs**: "I need a gaming laptop with good graphics"
- **Data Analysis**: Get explanations for why certain matches were found

## 🔄 Migration Guide

Your existing code will continue to work! The new agent architecture is additive:

```python
# v0.0.1 code still works
from pyprik import find_top_matching
results = find_top_matching(data, requirements, top_n)

# v0.1.0 added LLM capabilities
from pyprik import smart_product_search
enhanced_results = smart_product_search(data, requirements, natural_response=True)

# v0.2.0 adds cleaner agent imports
from pyprik.agent import serveragent
server = serveragent.create_server_agent()
```

## 🤝 Contributing

We welcome contributions! The project structure:

```
pyprik/
├── src/
│   ├── pyprik.py          # Core matching logic
│   ├── llm_agent.py       # LLM integration
│   └── server_agent.py    # FastAPI server
└── examples/              # Demo scripts
```

## 📄 License

MIT License - see LICENSE.txt for details.




