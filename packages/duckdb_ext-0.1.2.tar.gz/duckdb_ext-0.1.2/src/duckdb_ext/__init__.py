from .duckdb_ext import get_extension_dir, init

__all__ = ["get_extension_dir", "init"]
