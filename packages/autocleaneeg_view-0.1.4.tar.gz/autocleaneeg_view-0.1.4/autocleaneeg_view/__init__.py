"""AutoCleanEEG-View: A lightweight tool for viewing EEG files (.set, .edf, .bdf) using MNE-QT Browser."""

__version__ = "0.1.4"
