PL_PAGE_SIZE = 8
ADMIN_PASSWORD_SHA256 = "5af6a5ef999f78265eb7da581ef0158ae75ef213e2a65540ce271f27e5be8801" 

# Locale/region tuning
YT_LANG = "vi-VN"
YT_GEO_BYPASS_COUNTRY = "VN"

# Optional outbound proxy (e.g., 'http://user:pass@vn-proxy:port')
OUTBOUND_PROXY = "" 

# FAQ & Troubleshooting URL
FAQ_URL = "https://github.com/DAN3002/Youtube-Colab-Proxy/blob/main/FAQ.md"
