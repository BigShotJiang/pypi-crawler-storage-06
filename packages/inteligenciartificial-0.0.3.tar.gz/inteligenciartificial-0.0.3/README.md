# Paquete Inteligencia Artificial

Paquete de algoritmos de Inteligencia Artificial.

## Instalación
```bash
pip install inteligenciartificial
```
