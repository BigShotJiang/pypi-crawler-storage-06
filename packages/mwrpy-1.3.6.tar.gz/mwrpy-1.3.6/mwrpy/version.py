MAJOR = 1
MINOR = 3
PATCH = 6
__version__ = f"{MAJOR}.{MINOR}.{PATCH}"
