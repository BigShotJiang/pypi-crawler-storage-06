from rigol_ds1054z.src.oscope import Oscilloscope as Oscilloscope
