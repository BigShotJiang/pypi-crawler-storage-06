from enum import Enum


class OrderSide(Enum):
    BUY = "buy"
    SELL = "sell"
