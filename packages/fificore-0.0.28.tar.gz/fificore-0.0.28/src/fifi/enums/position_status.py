from enum import Enum


class PositionStatus(Enum):
    OPEN = "open"
    CLOSE = "close"
    LIQUID = "liquid"
