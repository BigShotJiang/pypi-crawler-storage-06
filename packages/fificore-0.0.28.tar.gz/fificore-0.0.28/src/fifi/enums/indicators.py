from enum import Enum


class IndicatorType(Enum):
    RSI = "rsi"
    MACD = "macd"
    SMA = "sma"
