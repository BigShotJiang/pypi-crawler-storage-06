import { aq as f } from "./Index-CzQ497_5.js";
export {
  f as default
};
