"""MCP OpenStack Operations Server package.

This module provides OpenStack operations automation and monitoring functions.
"""

