## Polars Native Machine Learning Pipeline

::: polars_ds.sample_and_split