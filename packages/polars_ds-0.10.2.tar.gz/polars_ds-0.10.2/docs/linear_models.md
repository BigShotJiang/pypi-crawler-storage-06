## Linear Models

::: polars_ds.linear_models