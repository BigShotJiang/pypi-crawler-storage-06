## Standalone Kd-Tree Model

::: polars_ds.spatial