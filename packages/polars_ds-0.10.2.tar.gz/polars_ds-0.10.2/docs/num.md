## Extension for General Numerical Features/Metrics/Quantities

::: polars_ds.exprs.num