## K Nearest Neighbor Related Queries

::: polars_ds.exprs.expr_knn