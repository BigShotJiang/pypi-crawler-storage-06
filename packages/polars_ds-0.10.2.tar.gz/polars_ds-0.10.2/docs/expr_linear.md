## Linear Models Related Queries

::: polars_ds.exprs.expr_linear