from merlinpyspark.__main__ import main

main()
