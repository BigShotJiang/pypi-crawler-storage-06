#! /usr/bin/env bash

alias @arvan=bluer_sandbox_arvancloud
alias @arvancloud=bluer_sandbox_arvancloud

alias @assets=bluer_sandbox_assets

alias @docker=bluer_sandbox_docker

alias @interview=bluer_sandbox_interview

alias @notebooks=bluer_sandbox_notebooks

alias @parser=bluer_sandbox_parser

alias @offline_llm=bluer_sandbox_offline_llm
alias @ollm=bluer_sandbox_offline_llm
alias @llm=bluer_sandbox_offline_llm

alias @sandbox=bluer_sandbox

alias @speedtest=bluer_sandbox_speedtest

alias @tor=bluer_sandbox_tor

alias @village=bluer_sandbox_village
