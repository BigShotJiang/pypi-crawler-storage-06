import React;

export default function Blank(){

    return (<div>Text Node</div>);
}
