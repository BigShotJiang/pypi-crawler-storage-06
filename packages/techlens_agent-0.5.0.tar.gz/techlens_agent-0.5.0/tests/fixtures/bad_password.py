def test_function():
    password = "hardcoded_password"  # This should trigger a finding
    return password
