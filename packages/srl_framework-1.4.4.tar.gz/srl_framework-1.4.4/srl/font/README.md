# FiraCode-Regular.ttf

<https://github.com/tonsky/FiraCode>

LICENSE: SIL Open Font License 1.1
<https://github.com/tonsky/FiraCode/blob/master/LICENSE>
