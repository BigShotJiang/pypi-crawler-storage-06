"""
Analysis metrics and visualization tools.

This submodule contains analysis utilities and plotting tools for evaluating
and visualizing anomaly detection results.
"""