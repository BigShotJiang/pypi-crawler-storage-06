import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def plot_latency_all(df):
    pass