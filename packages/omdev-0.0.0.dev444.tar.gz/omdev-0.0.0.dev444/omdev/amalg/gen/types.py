import typing as ta

from ...tokens import all as tks


Tokens: ta.TypeAlias = tks.Tokens
