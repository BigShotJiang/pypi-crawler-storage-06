from .cmdline import main

main()
