=============
Writing Rules
=============

Details of how to write rules for ick to run.  Start with the
`Tutorial <../getting-started/tutorial.html>`_ if you haven't read it yet.

.. toctree::
   :hidden:

   overview
   norms
   how-rules-are-run
   testing
