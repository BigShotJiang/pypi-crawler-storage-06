.. mdinclude:: ../README.md

.. toctree::
   :hidden:

   getting-started/index
   concepts/index
   writing-rules/index
   reference/index
   contributing/index
