from __future__ import annotations


class ValidationError(Exception):
    """This class is used to raise an exception when a validation error
    occurs."""
