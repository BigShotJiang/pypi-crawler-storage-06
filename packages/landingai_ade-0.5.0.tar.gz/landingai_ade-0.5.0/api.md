# Landingai

Types:

```python
from LandingAIAde.types import ExtractResponse, ParseResponse
```

Methods:

- <code title="post /v1/ade/extract">client.<a href="./src/LandingAIAde/_client.py">extract</a>(\*\*<a href="src/LandingAIAde/types/client_extract_params.py">params</a>) -> <a href="./src/LandingAIAde/types/extract_response.py">ExtractResponse</a></code>
- <code title="post /v1/ade/parse">client.<a href="./src/LandingAIAde/_client.py">parse</a>(\*\*<a href="src/LandingAIAde/types/client_parse_params.py">params</a>) -> <a href="./src/LandingAIAde/types/parse_response.py">ParseResponse</a></code>
