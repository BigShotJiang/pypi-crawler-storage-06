"""Step 1 Tests - Project Structure & Basic Setup."""
