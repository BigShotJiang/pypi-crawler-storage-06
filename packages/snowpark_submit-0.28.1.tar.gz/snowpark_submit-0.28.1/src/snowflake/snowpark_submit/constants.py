#
# Copyright (c) 2012-2025 Snowflake Computing Inc. All rights reserved.
#

SHARED_VOLUME_NAME = "shared"
SHARED_VOLUME_MOUNT_PATH = "/opt/workload"
