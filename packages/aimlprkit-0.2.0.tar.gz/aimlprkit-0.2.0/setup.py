from setuptools import find_packages, setup

setup(name="aimlprkit", version="0.2.0", packages=find_packages())
