"""Core components for cx_Freeze."""

__version__ = "0.1.1"
