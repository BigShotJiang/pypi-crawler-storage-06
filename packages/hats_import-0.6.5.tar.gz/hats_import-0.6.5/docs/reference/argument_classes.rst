Pipeline Arguments
===========================

.. currentmodule:: hats_import

.. autosummary::
    :toctree: api/

    ImportArguments
    CollectionArguments
    IndexArguments
    MarginCacheArguments
    VerificationArguments
    ConversionArguments