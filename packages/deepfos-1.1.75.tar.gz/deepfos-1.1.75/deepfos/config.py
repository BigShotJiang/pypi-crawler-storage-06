"""
meta configuration for deepfos package
"""

#: 全局变量使用上下文变量
USE_CONTEXT_OPTION = True
