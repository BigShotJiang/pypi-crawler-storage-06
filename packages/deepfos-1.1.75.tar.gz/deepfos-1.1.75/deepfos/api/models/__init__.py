"""``JSON`` <-> ``Object`` 数据模型"""

from .base import *
