def test_hello_world():
    assert "hello".upper() == "HELLO"
