"""
Core I/O Tests

Tests atomic file operations, async operations, and file management.
Focuses on the main I/O functionality and real-world file operations.
"""
