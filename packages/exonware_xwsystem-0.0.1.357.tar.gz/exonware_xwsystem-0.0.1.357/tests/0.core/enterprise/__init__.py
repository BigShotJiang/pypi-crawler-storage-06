#exonware/xwsystem/tests/core/enterprise/__init__.py
"""
Enterprise Core Tests Package

Tests for XSystem enterprise functionality including authentication,
distributed tracing, and schema registry.
"""
