
NAME = "Syned Elettra Extension"

DESCRIPTION = "Widgets for Syned Elettra Extension"

BACKGROUND = "#ECCFAF"

ICON = "icons/LogoElettra_transparent.png"

PRIORITY = 10.6