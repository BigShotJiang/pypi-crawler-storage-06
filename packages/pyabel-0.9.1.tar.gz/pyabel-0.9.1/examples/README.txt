Some example scripts provided here require example data files in the "data"
subdirectory. If you wish to copy or run such scripts elsewhere, please make
sure that this path is available or modify it accordingly.

Note: PyAbel distribution packages do not include the "data" directory, please
download its contents from the PyAbel repository
https://github.com/PyAbel/PyAbel/tree/master/examples/data
