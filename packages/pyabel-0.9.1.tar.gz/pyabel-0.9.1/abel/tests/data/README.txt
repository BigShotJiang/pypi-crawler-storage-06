This directory is used by unit tests for temporary files.
