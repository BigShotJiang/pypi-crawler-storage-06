"""Cosmic Ray version info."""

__version__ = "8.4.3"
__version_info__ = tuple(__version__.split("."))
