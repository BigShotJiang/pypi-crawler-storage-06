"""Cosmic Ray is a mutation testing tool for Python."""
