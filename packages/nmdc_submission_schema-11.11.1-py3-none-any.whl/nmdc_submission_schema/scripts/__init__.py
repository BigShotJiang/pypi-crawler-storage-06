from importlib import resources

nmdc_schema_yaml_path = resources.files('nmdc_schema') / 'nmdc_materialized_patterns.yaml'
