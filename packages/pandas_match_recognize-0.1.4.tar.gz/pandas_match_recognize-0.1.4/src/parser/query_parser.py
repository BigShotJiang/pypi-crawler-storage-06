from src.parser.match_recognize_extractor import parse_full_query

def parse_query(query: str):
    return parse_full_query(query)
