MAX_PATH_LENGTH = 1024

__all__ = [
    "MAX_PATH_LENGTH",
]
