from nixi.dummy import dummy


def test_dummy():
    assert dummy() is None
