﻿pycbg.preprocessing.Particles
=============================

.. currentmodule:: pycbg.preprocessing

.. autoclass:: Particles
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Particles.__init__
      ~Particles.create_particles
      ~Particles.write_file
   
   

   
   
   