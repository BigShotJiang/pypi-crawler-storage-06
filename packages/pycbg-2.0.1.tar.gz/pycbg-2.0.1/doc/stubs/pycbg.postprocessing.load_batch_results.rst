﻿pycbg.postprocessing.load\_batch\_results
=========================================

.. currentmodule:: pycbg.postprocessing

.. autoclass:: load_batch_results
   :members:

   
   .. automethod:: __init__

   
   

   
   
   