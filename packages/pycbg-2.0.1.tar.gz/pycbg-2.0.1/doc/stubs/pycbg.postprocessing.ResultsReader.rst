﻿pycbg.postprocessing.ResultsReader
==================================

.. currentmodule:: pycbg.postprocessing

.. autoclass:: ResultsReader
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~ResultsReader.__init__
      ~ResultsReader.load_simulation
   
   

   
   
   