﻿pycbg.preprocessing.setup\_batch
================================

.. currentmodule:: pycbg.preprocessing

.. autoclass:: setup_batch
   :members:

   
   .. automethod:: __init__

   
   

   
   
   