﻿pycbg.preprocessing.EntitySets
==============================

.. currentmodule:: pycbg.preprocessing

.. autoclass:: EntitySets
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~EntitySets.__init__
      ~EntitySets.create_set
      ~EntitySets.write_file
   
   

   
   
   