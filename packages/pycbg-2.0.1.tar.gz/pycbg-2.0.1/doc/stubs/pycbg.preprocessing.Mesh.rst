﻿pycbg.preprocessing.Mesh
========================

.. currentmodule:: pycbg.preprocessing

.. autoclass:: Mesh
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Mesh.__init__
      ~Mesh.create_mesh
      ~Mesh.set_parameters
      ~Mesh.write_file
   
   

   
   
   