﻿pycbg.MPMxDEM.setup\_yade
=========================

.. currentmodule:: pycbg.MPMxDEM

.. autoclass:: setup_yade
   :members:

   
   .. automethod:: __init__

   
   

   
   
   