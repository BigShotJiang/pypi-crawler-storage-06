"""Package containing various utility functions for NOVA-Server

Author:
    Dominik Schiller <dominik.schiller@uni-a.de>
Date:
    18.8.2023
"""