"""This package contains code to execute NOVA-Server commands

Author:
    Dominik Schiller <dominik.schiller@uni-a.de>
Date:
    18.8.2023
"""