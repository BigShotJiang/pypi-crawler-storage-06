"""Utilities for the inventory tool."""
