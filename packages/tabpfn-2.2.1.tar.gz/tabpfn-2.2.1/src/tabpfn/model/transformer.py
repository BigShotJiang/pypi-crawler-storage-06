"""DEPRECATED: Please import tabpfn.architectures.base.transformer instead."""

from __future__ import annotations

from tabpfn.architectures.base.transformer import *  # noqa: F403
