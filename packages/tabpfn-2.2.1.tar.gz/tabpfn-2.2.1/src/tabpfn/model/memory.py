"""DEPRECATED: Please import tabpfn.architectures.base.memory instead."""

from __future__ import annotations

from tabpfn.architectures.base.memory import *  # noqa: F403
