"""DEPRECATED: Please import tabpfn.preprocessors instead."""

from __future__ import annotations

from tabpfn.preprocessors import *  # noqa: F403
