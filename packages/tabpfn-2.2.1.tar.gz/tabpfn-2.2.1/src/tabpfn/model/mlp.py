"""DEPRECATED: Please import tabpfn.architectures.base.mlp instead."""

from __future__ import annotations

from tabpfn.architectures.base.mlp import *  # noqa: F403
