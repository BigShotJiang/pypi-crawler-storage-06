"""DEPRECATED: Please import tabpfn.architectures.base.layer instead."""

from __future__ import annotations

from tabpfn.architectures.base.layer import *  # noqa: F403
