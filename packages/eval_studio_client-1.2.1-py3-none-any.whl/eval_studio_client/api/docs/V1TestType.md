# V1TestType

 - TEST_TYPE_UNSPECIFIED: Unspecified type.  - TEST_TYPE_STANDALONE: Standalone test.  - TEST_TYPE_WORKFLOW: Test is part of a dashboard.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


