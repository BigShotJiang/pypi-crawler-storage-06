# V1DashboardType

 - DASHBOARD_TYPE_UNSPECIFIED: Unspecified type.  - DASHBOARD_TYPE_STANDALONE: Standalone dashboard.  - DASHBOARD_TYPE_WORKFLOW: Dashboard is part of a dashboard group.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


