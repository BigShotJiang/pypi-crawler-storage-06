"""Create :mod:`patroni.scripts.barman`."""
