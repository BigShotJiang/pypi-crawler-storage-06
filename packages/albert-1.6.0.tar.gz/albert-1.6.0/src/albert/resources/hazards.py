from albert.core.shared.models.base import EntityLinkWithName


class HazardSymbol(EntityLinkWithName):
    """Model representing a hazard symbol."""

    pass


class HazardStatement(EntityLinkWithName):
    """Model representing a hazard statement."""

    pass
