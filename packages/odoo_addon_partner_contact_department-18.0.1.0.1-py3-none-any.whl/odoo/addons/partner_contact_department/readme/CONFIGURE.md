To configure departments, you need to:

- Go to *Contacts \> Configuration \> Departments*.

![](path/to/local/image.png)
