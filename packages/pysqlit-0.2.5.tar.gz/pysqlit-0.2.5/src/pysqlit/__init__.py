"""PySQLit - 一个具有ACID兼容性的Python SQLite实现。"""

from .version import __version__



