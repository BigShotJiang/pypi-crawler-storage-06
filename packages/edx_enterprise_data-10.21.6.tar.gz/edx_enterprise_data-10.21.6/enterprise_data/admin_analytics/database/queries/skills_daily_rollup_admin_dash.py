"""
Module containing queries for the skills_daily_rollup_admin_dash table.
"""
from ..query_filters import QueryFilters


class SkillsDailyRollupAdminDashQueries:
    """
    Queries related to the skills_daily_rollup_admin_dash table.
    """
    @staticmethod
    def get_top_skills(query_filters: QueryFilters):
        """
        Get the query to fetch the top skills for an enterprise customer.
        """
        return f"""
            SELECT
                skill_name,
                skill_type,
                SUM(enrolls) AS enrolls,
                SUM(completions) AS completions
            FROM
                skills_daily_rollup_admin_dash
            WHERE
                {query_filters.to_sql()}
            GROUP BY
                skill_name, skill_type
            ORDER BY
                enrolls DESC, completions DESC;
        """

    @staticmethod
    def get_top_skills_by_enrollment(query_filters: QueryFilters):
        """
        Get the query to fetch the top skills by enrollment for an enterprise customer.
        """
        return f"""
            WITH FilteredData AS (
                SELECT
                    skill_name,
                    primary_subject_name,
                    enrolls
                FROM
                    skills_daily_rollup_admin_dash
                WHERE
                    {query_filters.to_sql()}
            ),
            TopSkills AS (
                SELECT
                    skill_name,
                    SUM(enrolls) AS total_enrollment_count
                FROM
                    FilteredData
                GROUP BY
                    skill_name
                ORDER BY
                    total_enrollment_count DESC
                LIMIT 10
            )
            SELECT
                fd.skill_name,
                CASE
                    WHEN fd.primary_subject_name IN (
                        'business-management', 'computer-science',
                        'data-analysis-statistics', 'engineering', 'communication'
                    ) THEN fd.primary_subject_name
                    ELSE 'other'
                END AS subject_name,
                SUM(fd.enrolls) AS count
            FROM
                FilteredData fd
            JOIN
                TopSkills ts ON fd.skill_name = ts.skill_name
            GROUP BY
                fd.skill_name, subject_name
            ORDER BY
                ts.total_enrollment_count DESC;
        """

    @staticmethod
    def get_top_skills_by_completion(query_filters: QueryFilters):
        """
        Get the query to fetch the top skills by completion for an enterprise customer.
        """
        return f"""
            WITH FilteredData AS (
                SELECT
                    skill_name,
                    primary_subject_name,
                    completions
                FROM
                    skills_daily_rollup_admin_dash
                WHERE
                    {query_filters.to_sql()}
            ),
            TopSkills AS (
                -- Get top 10 skills by total completions
                SELECT
                    skill_name,
                    SUM(completions) AS total_completion_count
                FROM
                    FilteredData
                GROUP BY
                    skill_name
                ORDER BY
                    total_completion_count DESC
                LIMIT 10
            )
            SELECT
                fd.skill_name,
                CASE
                    WHEN fd.primary_subject_name IN (
                        'business-management', 'computer-science',
                        'data-analysis-statistics', 'engineering', 'communication'
                    ) THEN fd.primary_subject_name
                    ELSE 'other'
                END AS subject_name,
                SUM(fd.completions) AS count
            FROM
                FilteredData AS fd
            JOIN
                TopSkills AS ts ON fd.skill_name = ts.skill_name
            GROUP BY
                fd.skill_name, subject_name
            ORDER BY
                ts.total_completion_count DESC;
        """

    @staticmethod
    def get_skills_by_learning_hours(query_filters: QueryFilters, record_count: int = 25):
        """
        Get the query to fetch skills by learning hours for an enterprise customer.
        """
        return f"""
            WITH filtered_data AS (
                SELECT
                    skill_name,
                    total_learning_time_hours
                FROM
                    skills_daily_rollup_admin_dash
                WHERE
                    {query_filters.to_sql()}
            )

            SELECT
                skill_name,
                SUM(total_learning_time_hours) AS learning_hours
            FROM
                filtered_data
            GROUP BY
                skill_name
            ORDER BY
                learning_hours DESC
            LIMIT {record_count};
        """

    @staticmethod
    def get_unique_skills_gained(query_filters: QueryFilters) -> str:
        """
        Get the query to fetch the unique skills gained for an enterprise customer.
        """
        return f"""
            SELECT
                COUNT(DISTINCT skill_name)
            FROM
                skills_daily_rollup_admin_dash
            WHERE
                {query_filters.to_sql()};
        """

    @staticmethod
    def get_upskilled_learners_count(
        skills_query_filters: QueryFilters,
        enrollment_query_filters: QueryFilters
    ) -> str:
        """
        Get the query to fetch the count of upskilled learners for an enterprise customer.
        """
        return f"""
            WITH completed_skills AS (
                SELECT
                    course_key
                FROM
                    skills_daily_rollup_admin_dash
                WHERE
                    {skills_query_filters.to_sql()}
            ),
            passed_learners AS (
                SELECT
                    email, course_key
                FROM
                    fact_enrollment_admin_dash
                WHERE
                    {enrollment_query_filters.to_sql()}
            ),
            all_passed_learners_with_skills AS (
                SELECT
                    pl.email
                FROM
                    passed_learners pl
                INNER JOIN
                    completed_skills cs
                ON
                    pl.course_key = cs.course_key
            )
            SELECT
                COUNT(*)
            FROM (
                SELECT DISTINCT email
                FROM all_passed_learners_with_skills
            ) dedup;
        """

    @staticmethod
    def get_new_skills_learned_count(
        historical_skills_filters: QueryFilters,
        current_skills_filters: QueryFilters
    ) -> str:
        """
        Get the query to fetch the count of new skills learned for an enterprise customer.
        """
        return f"""
            WITH historical_skills AS (
                SELECT
                    skill_name
                FROM
                    skills_daily_rollup_admin_dash
                WHERE
                    {historical_skills_filters.to_sql()}
                GROUP BY skill_name
            ),
            current_period_skills AS (
                SELECT
                    skill_name
                FROM
                    skills_daily_rollup_admin_dash
                WHERE
                    {current_skills_filters.to_sql()}
                GROUP BY skill_name
            )
            SELECT
                COUNT(*)
            FROM
                current_period_skills c
            LEFT JOIN
                historical_skills h
                ON c.skill_name = h.skill_name
            WHERE
                h.skill_name IS NULL;
        """
