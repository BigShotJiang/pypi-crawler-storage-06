Changelog
=========

### 1.0.2 - 2025-09-22

* Uses pyproject.toml to publish the package

### 1.0.1 - 2025-09-22

* Fix setup.py's long decription 

## 1.0.0 - 2025-09-22

* Initial Release
