1.  Go to Documents / Auto Classification and select a template and a
    .zip file.
2.  Press the Analyze button
3.  As many lines will be set as the number of files contained in the
    .zip file and apply the filename pattern.
4.  The record to which they are related (res.partner for example) will
    be show on the lines.
5.  Press the Classify button
6.  The files (dms.file) will be created in the corresponding
    directories.
