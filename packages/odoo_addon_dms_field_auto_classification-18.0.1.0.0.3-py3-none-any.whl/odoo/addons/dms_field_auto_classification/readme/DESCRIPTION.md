Automatically classify files within a .zip file to the corresponding
directory(s) related to an embedded DMS.
