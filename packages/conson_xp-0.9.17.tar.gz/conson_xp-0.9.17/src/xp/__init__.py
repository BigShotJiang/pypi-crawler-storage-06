"""XP CLI tool for remote console bus operations"""
"""conson-xp"""

__version__ = "0.9.17"
__manufacturer__ = "ldvchosal"
__model__ = "xp.cli"
__serial__ = "2025.09.23.000"