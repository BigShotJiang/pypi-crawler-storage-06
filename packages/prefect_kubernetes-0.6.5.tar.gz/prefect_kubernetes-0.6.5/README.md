# prefect-kubernetes

<p align="center">
    <a href="https://pypi.python.org/pypi/prefect-kubernetes/" alt="PyPI version">
        <img alt="PyPI" src="https://img.shields.io/pypi/v/prefect-kubernetes?color=26272B&labelColor=090422"></a>
    <a href="https://pypistats.org/packages/prefect-kubernetes/" alt="Downloads">
        <img src="https://img.shields.io/pypi/dm/prefect-kubernetes?color=26272B&labelColor=090422" /></a>
</p>

See the docs at [https://docs.prefect.io/integrations/prefect-kubernetes](https://docs.prefect.io/integrations/prefect-kubernetes) for more information.
