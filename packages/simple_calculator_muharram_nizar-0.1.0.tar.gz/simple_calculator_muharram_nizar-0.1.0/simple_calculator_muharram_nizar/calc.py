def calculate_expression(expression):
    return eval(expression)


