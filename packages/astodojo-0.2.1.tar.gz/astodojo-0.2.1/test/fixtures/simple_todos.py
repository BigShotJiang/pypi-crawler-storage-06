"""
Simple test file with basic TODO patterns.
"""

def simple_function():
    # TODO: Implement this function
    # BLAME: This logic needs review
    # DEV-CRUFT: Remove debug code
    # PAY-ATTENTION: Critical security check here
    # BUG: This will crash on None input
    pass
