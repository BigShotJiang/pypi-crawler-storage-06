# IA Agent para Generación de Pruebas Unitarias .NET
# Utilidades comunes del sistema
