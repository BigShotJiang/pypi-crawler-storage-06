# IA Agent para Generación de Pruebas Unitarias .NET
# Interfaz CLI
