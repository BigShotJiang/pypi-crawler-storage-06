class TestModels:
    def test_one(self):
        x = "this"
        assert "h" in x
