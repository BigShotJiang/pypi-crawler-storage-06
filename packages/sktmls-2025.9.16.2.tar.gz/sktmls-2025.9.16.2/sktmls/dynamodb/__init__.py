from .dynamodb import DynamoDBClient

__all__ = ["DynamoDBClient"]
