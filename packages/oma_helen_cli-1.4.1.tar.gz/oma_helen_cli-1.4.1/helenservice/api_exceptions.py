class InvalidApiResponseException(Exception):
    pass

class HelenAuthenticationException(Exception):
    pass

class InvalidDeliverySiteException(Exception):
    pass