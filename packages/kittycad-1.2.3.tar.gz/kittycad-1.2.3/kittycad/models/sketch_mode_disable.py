from .base import KittyCadBaseModel


class SketchModeDisable(KittyCadBaseModel):
    """The response from the `SketchModeDisable` endpoint."""
