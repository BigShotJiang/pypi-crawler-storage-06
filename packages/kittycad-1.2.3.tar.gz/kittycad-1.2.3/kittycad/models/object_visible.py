from .base import KittyCadBaseModel


class ObjectVisible(KittyCadBaseModel):
    """The response from the `ObjectVisible` endpoint."""
