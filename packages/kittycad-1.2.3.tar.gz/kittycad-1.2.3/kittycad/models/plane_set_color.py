from .base import KittyCadBaseModel


class PlaneSetColor(KittyCadBaseModel):
    """The response from the `PlaneSetColor` endpoint."""
