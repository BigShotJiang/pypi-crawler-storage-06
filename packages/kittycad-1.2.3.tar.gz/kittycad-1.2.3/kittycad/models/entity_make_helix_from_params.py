from .base import KittyCadBaseModel


class EntityMakeHelixFromParams(KittyCadBaseModel):
    """The response from the `EntityMakeHelixFromParams` endpoint."""
