# TODO: Move to edc-constants (or somewhere effect-form-validators can access them)
ART_CONTINUED = "art_continued"
ART_STOPPED = "art_stopped"
UNABLE_TO_CONTACT = "unable_to_contact"
