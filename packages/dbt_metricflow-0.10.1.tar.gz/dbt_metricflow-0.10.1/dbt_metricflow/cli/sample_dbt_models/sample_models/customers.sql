select
    *
from {{ref('customers_seed')}}
