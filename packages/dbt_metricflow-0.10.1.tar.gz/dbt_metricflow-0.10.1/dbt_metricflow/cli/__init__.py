from __future__ import annotations

PACKAGE_NAME = "dbt-metricflow"
