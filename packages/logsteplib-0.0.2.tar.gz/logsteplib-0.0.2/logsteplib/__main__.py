from . import logstep

def main():
    print("Package containing a standard format for the logging module.")

if __name__ == "__main__":
    main()
