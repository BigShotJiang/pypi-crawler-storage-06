from zabbix_enums.z70.report import *
