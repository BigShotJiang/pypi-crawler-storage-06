from zabbix_enums.z70.authentication import *
