from zabbix_enums.z70.maintenance import *
