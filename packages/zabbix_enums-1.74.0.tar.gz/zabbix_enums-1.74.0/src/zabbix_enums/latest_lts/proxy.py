from zabbix_enums.z70.proxy import *
