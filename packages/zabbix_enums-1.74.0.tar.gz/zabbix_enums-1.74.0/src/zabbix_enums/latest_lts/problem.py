from zabbix_enums.z70.problem import *
