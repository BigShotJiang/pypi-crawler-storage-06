from zabbix_enums.z70.dhost import *
