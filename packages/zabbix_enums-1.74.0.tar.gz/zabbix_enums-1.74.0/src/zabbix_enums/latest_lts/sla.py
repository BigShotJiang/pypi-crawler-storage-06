from zabbix_enums.z70.sla import *
