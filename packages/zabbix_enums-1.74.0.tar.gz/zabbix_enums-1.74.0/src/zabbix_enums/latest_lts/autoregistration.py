from zabbix_enums.z70.autoregistration import *
