from zabbix_enums.z70.map import *
