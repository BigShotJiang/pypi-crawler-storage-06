from zabbix_enums.z70.dcheck import *
