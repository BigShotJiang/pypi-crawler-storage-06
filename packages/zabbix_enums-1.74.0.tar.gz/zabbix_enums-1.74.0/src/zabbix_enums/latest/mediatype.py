from zabbix_enums.z74.mediatype import *
