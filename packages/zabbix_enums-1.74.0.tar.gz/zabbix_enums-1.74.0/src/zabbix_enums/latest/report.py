from zabbix_enums.z74.report import *
