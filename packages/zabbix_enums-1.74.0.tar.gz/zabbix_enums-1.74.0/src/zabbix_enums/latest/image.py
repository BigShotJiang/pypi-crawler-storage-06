from zabbix_enums.z74.image import *
