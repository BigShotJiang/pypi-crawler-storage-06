from zabbix_enums.z74.mfa import *
