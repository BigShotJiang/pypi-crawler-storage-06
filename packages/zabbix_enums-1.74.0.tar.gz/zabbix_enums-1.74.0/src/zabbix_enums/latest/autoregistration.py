from zabbix_enums.z74.autoregistration import *
