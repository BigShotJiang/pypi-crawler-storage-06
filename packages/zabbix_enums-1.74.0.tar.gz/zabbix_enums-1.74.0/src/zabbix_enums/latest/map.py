from zabbix_enums.z74.map import *
