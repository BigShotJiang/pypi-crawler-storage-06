from zabbix_enums.z74.dashboard import *
