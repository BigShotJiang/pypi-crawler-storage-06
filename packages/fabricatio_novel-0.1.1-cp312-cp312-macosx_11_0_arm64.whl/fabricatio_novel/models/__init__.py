"""Models defined in fabricatio-novel."""
