from .static import plot
from .interactive import plot_interactive

__all__ = ["plot", "plot_interactive"]
