![](./.github/banner.png)
</br></br>

# sectools - The Offensive Security Python Toolbox 

[![PyPI - License](https://img.shields.io/pypi/l/sectools?color=gree)](../LICENSE.md)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/sectools)
![PyPI](https://img.shields.io/pypi/v/sectools)
[![Python pip build](https://github.com/p0dalirius/sectools/actions/workflows/python-pip-build.yml/badge.svg?branch=main)](https://github.com/p0dalirius/sectools/actions/workflows/python-pip-build.yml)

A Python native library containing lots of useful functions to write efficient scripts to hack stuff.

## Installation

```
python3 -m pip install sectools
```

## Contributing

Pull requests are welcome. Feel free to open an issue if you want to add other features.

## References
 - https://pypi.org/project/sectools/
