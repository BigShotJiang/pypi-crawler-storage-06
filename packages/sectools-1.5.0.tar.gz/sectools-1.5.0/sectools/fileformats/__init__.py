#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# File name          : __init__.py
# Author             : Podalirius (@podalirius_)
# Date created       : 6 Nov 2022

from .Markdown import Markdown

__all__ = ["Markdown"]
