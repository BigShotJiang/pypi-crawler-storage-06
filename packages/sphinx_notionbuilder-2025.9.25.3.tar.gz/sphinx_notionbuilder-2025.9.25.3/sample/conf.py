"""
Configuration for Sphinx.
"""

extensions = [
    "sphinxcontrib.video",
    "sphinxnotes.strike",
    "sphinx_notion",
    "sphinx_toolbox.collapse",
]
