"""
Version of vpc
"""

__version__ = '0.31.0'
