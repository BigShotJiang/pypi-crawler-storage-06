from .decorator import timeit

__all__ = ["timeit"]
__version__ = "0.1.0"
