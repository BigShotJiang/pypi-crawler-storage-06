The warning banner is displayed on the partner form view if another
partner: - has the same e-mail address (independantly from the case,
from starting spaces and ending spaces), - is not the parent nor the
child of the partner, - if the partner is attached to a specific
company: is in the same company or is not attached to a specific
company, - if the partner is not attached to a specific company: is in
any company or not attached to a specific company.
