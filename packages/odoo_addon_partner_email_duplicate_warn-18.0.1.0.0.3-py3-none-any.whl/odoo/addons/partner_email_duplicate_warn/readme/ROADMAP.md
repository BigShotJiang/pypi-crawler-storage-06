- Add a button "Merge partner" in the end of the warning message to save
  clicks to user.
- Set same_email_partner_id as Many2many and find a way to display all
  the duplicate in the warning banner with clickable links.
