# 青年优品mcp工具集

## 支持功能
1. markdown的table 转 excel `python util/md2excel.py xxx.md xxx.xlsx` 
