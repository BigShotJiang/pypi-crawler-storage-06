from .espeak_py import *

__doc__ = espeak_py.__doc__
if hasattr(espeak_py, "__all__"):
    __all__ = espeak_py.__all__