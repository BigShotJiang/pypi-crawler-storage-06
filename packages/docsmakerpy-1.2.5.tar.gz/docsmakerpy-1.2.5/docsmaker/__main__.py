"""Entry point for `python -m docsmaker`."""

from .cli import app

if __name__ == "__main__":
    app()