__all__ = [
	"__version__",
]

# Follow semantic versioning: https://semver.org/
__version__ = "0.2.0"
