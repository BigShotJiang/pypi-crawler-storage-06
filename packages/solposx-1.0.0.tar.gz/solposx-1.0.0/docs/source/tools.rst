.. currentmodule:: solposx


Tools
=====

.. autosummary::
   :toctree: generated/

   tools.calc_error
