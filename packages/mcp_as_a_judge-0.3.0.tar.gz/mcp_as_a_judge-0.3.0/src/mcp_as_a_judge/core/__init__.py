"""
Core utilities: logging and shared helpers.
"""
