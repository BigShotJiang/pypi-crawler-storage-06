"""Notion source settings and constants"""

API_URL = "https://api.notion.com/v1"
