#!/usr/bin/sh
pytest
coverage-badge > coverage.svg
