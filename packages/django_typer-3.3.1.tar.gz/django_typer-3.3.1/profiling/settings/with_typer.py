from .basic import *  # noqa: F403

INSTALLED_APPS.insert(0, "profiling.with_typer")  # noqa: F405
