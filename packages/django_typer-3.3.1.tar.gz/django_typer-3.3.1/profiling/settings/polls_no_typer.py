from .polls import *  # noqa: F403

INSTALLED_APPS.insert(0, "profiling.no_typer")  # noqa: F405
