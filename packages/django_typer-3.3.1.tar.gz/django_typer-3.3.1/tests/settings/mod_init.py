from .base import *

ROUTINES = {
    "routine1": ["initial", "destroy"],
    "routine2": ["deploy", "package", "upload"],
    "routine3": [],
}
