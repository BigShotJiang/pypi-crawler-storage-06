from .base import *

INSTALLED_APPS = ["tests.apps.bad", "django_typer"]
