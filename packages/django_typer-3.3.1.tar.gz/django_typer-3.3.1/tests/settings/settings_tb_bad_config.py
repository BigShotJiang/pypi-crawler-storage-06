from .base import *

DT_RICH_TRACEBACK_CONFIG = {
    "show_locals": False,
    "short": False,
    "unexpected_setting": True,
}
