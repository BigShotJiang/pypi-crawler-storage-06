from .base import *

INSTALLED_APPS = ["tests.apps.test_app2", *INSTALLED_APPS]
