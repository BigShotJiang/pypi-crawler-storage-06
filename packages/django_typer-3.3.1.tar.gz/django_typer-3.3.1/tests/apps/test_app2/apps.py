from django.apps import AppConfig


class TestApp2Config(AppConfig):
    name = "tests.apps.test_app2"
    label = "test_app2"
    verbose_name = "Test App2"
