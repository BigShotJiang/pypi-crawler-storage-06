from ..commands.bad import (
    Command as Bad,
)


@Bad.command()
def cmd3(self):
    pass
