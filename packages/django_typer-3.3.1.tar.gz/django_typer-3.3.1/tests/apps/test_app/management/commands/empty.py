from django_typer.management import TyperCommand


class Command(TyperCommand):
    pass
