
.. _Django: https://www.djangoproject.com
.. _GitHub: https://github.com/django-commons/django-typer
.. _PyPI: https://pypi.python.org/pypi/django-typer
.. _Typer: https://typer.tiangolo.com
.. _DRY: https://en.wikipedia.org/wiki/Don%27t_repeat_yourself
.. _django-typer: https://pypi.python.org/pypi/django-typer
.. _powershell: https://learn.microsoft.com/en-us/powershell/scripting/overview
.. _fish: https://fishshell.com
.. _zsh: https://www.zsh.org
.. _bash: https://www.gnu.org/software/bash
.. _Arguments: https://typer.tiangolo.com/tutorial/arguments
.. _Options: https://typer.tiangolo.com/tutorial/options
.. _sphinxcontrib-typer: https://pypi.org/project/sphinxcontrib-typer
.. _pluggy: https://pluggy.readthedocs.io
.. _CLI: https://en.wikipedia.org/wiki/Command-line_interface
