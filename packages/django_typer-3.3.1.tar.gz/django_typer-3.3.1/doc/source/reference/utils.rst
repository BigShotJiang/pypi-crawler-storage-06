.. include:: ../refs.rst

.. _utils:

=====
Utils
=====

.. automodule:: django_typer.utils
    :members: model_parser_completer, traceback_config, get_current_command, register_command_plugins, is_method, parse_iso_duration, duration_iso_string
