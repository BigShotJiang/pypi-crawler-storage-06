.. include:: ../refs.rst

.. _completers:

==========
Completers
==========

.. automodule:: django_typer.completers
    :members:

.. automodule:: django_typer.completers.apps
    :members:

.. automodule:: django_typer.completers.cmd
    :members:

.. automodule:: django_typer.completers.db
    :members:

.. automodule:: django_typer.completers.model
    :members:

.. automodule:: django_typer.completers.path
    :members:

.. automodule:: django_typer.completers.settings
    :members:
