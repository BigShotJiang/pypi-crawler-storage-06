.. include:: ../refs.rst

.. _reference:

=========
Reference
=========

.. automodule:: django_typer

|

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   management
   types
   completers
   parsers
   shell_completion
   shells
   utils
