.. include:: ../refs.rst

.. _types:

============
Option Types
============

.. automodule:: django_typer.types
    :members:

