.. include:: ../refs.rst

.. _parsers:

=======
Parsers
=======

.. automodule:: django_typer.parsers
    :members:

.. automodule:: django_typer.parsers.apps
    :members:

.. automodule:: django_typer.parsers.model
    :members:
