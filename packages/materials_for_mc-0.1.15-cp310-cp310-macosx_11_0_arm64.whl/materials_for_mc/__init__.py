from .materials_for_mc import *

__doc__ = materials_for_mc.__doc__
if hasattr(materials_for_mc, "__all__"):
    __all__ = materials_for_mc.__all__