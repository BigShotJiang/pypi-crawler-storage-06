"""
Sienge MCP Server Package
Model Context Protocol integration for Sienge API
"""

__version__ = "1.0.0"
__author__ = "Sienge MCP Contributors"
__email__ = "contributors@sienge-mcp.com"
__description__ = "Sienge MCP Server - Model Context Protocol integration for Sienge API"
