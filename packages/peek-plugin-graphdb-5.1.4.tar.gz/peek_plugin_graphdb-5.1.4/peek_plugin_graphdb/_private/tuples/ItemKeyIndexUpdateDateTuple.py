from typing import Dict

from peek_abstract_chunked_index.private.tuples.ACIUpdateDateTupleABC import (
    ACIUpdateDateTupleABC,
)
from peek_plugin_graphdb._private.PluginNames import graphDbTuplePrefix
from vortex.Tuple import addTupleType, TupleField, Tuple


@addTupleType
class ItemKeyIndexUpdateDateTuple(Tuple, ACIUpdateDateTupleABC):
    """ItemKeyIndex Object Update Date Tuple

    This tuple represents the state of the chunks in the cache.
    Each chunkKey has a lastUpdateDate as a string, this is used for offline caching
    all the chunks.
    """

    __tupleType__ = graphDbTuplePrefix + "ItemKeyIndexUpdateDateTuple"

    # Improve performance of the JSON serialisation
    __rawJonableFields__ = ("initialLoadComplete", "updateDateByChunkKey")

    initialLoadComplete: bool = TupleField()
    updateDateByChunkKey: Dict[str, str] = TupleField({})

    @property
    def ckiUpdateDateByChunkKey(self):
        return self.updateDateByChunkKey

    def ckiSetUpdateDateByChunkKey(self, value: Dict[str, str]) -> None:
        self.updateDateByChunkKey = value

    @property
    def ckiInitialLoadComplete(self) -> bool:
        return self.initialLoadComplete

    def ckiSetInitialLoadComplete(self, value: bool) -> None:
        self.initialLoadComplete = value
