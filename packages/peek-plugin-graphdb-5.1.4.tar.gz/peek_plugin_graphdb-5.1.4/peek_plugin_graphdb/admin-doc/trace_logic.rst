Trace Logic
-----------



Upstream / Downstream
`````````````````````

The trace will will stop if it wants upstream and it's going downstream and the reverse.

If it wants upstream, and it's going  into a "both" direction, it will continue. (and same for downstream)

If it wants upstream and the edge hasn't had its direction set, it will stop. (and same for downstream)