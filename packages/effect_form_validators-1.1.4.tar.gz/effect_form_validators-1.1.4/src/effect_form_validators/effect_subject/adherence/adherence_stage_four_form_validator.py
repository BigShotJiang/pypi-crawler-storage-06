from edc_crf.crf_form_validator import CrfFormValidator


class AdherenceStageFourFormValidator(CrfFormValidator):
    pass
