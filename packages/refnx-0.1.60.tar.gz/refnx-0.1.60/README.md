refnx
=====

[![Test](https://github.com/refnx/refnx/actions/workflows/pythonpackage.yml/badge.svg)](https://github.com/refnx/refnx/actions/workflows/pythonpackage.yml)
[![Documentation Status](https://readthedocs.org/projects/refnx/badge/?version=latest)](https://refnx.readthedocs.io/en/latest/?badge=latest)
[![DOI](https://zenodo.org/badge/23189/refnx/refnx.svg)](https://zenodo.org/badge/latestdoi/23189/refnx/refnx)
[![Binder](https://mybinder.org/badge.svg)](https://mybinder.org/v2/gh/refnx/refnx-binder.git/master)

Neutron and X-ray reflectometry analysis in Python. Documentation at https://refnx.readthedocs.io.