
# THIS FILE IS GENERATED FROM REFNX SETUP.PY
short_version = '0.1.60'
version = '0.1.60'
full_version = '0.1.60'
git_revision = '77d510f4adb29586443c1ff3545ed16735e35205'
release = True
if not release:
    version = full_version
