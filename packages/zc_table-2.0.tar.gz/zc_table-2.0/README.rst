This is a Zope 3 extension that helps with the construction of (HTML) tables.
Features include dynamic HTML table generation, batching and sorting.
