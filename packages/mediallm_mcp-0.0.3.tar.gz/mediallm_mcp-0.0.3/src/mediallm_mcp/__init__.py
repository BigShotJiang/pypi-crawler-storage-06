#!/usr/bin/env python3
# Author: Arun Brahma

from .__about__ import __version__

__all__ = ["__version__"]
