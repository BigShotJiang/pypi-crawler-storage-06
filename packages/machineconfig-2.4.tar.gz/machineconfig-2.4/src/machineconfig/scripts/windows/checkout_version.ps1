
. "$HOME\code\machineconfig\.venv\Scripts\activate.ps1"
python -m fire machineconfig.jobs.python.checkout_version main
deactivate
