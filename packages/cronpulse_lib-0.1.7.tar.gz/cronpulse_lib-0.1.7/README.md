# CronPulse Python Client

This is the Python package portion of the multi-language CronPulse client.

Refer to the root project README for full details. This file exists so that
PEP 621 `readme` metadata can be resolved without referencing parent paths
(which some build backends disallow for sdist isolation).
