"""Fetch FHIR data from your EHR easily and completely"""

__version__ = "0.5.1"
