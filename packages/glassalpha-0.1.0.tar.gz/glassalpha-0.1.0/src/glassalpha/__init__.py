"""GlassAlpha: Deterministic ML model audit generation."""

__version__ = "0.1.0"

# Phase 1 exports - audit generation
__all__ = [
    "__version__",
    # These will be implemented
    # "audit",
    # "explain",
    # "recourse",
]
