"""An example of a Python file following all recommendations."""


def some_function(argument: int) -> None:
    """An example of a function with proper types and docs."""
    print(argument)
