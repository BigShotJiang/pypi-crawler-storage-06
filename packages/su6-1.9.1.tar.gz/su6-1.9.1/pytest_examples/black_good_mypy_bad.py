def method(arg):
    print("This file is properly formatted (black) but not typed (mypy)")
