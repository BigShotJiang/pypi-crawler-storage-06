import this

def some_function(argument)\
    :
    print(argument)

    assert eval("0")
