API_BASE_URL = "https://api.steampowered.com"
API_APP_DETAILS_URL = "https://store.steampowered.com/api/appdetails"
API_APP_SEARCH_URL = "https://store.steampowered.com/search/suggest"
API_APP_WISHLIST = "https://api.steampowered.com/IWishlistService/GetWishlist/v1/"
