# -*- coding: utf-8 -*-
from .tag_added import FunctionRunner, task_function_type
