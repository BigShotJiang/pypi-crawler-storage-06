tennyson.py
===========

Collection of helpful functions by Tennyson T Bardwell

Development
-----------

This project has a `shell.nix` for development. A `Makefile` acts as the initial
interface for all commands, and uses the `shell.nix` under the hood.

### TODO ###

- graceful handling of email errors if no network

Links
------

- https://github.com/tennysontbardwell/tennyson.py
- https://pypi.org/project/tennyson/
