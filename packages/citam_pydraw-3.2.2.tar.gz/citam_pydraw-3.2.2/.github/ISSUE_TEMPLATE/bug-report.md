---
name: Bug report
about: バグ報告のテンプレート
title: "[BUG] "
labels: 'Problem: bug'
assignees: ''

---

# バグ報告
## 現象

## 再現
### 環境
- 

### 手順
1. 

### その他
- 

## 影響
-
