---
name: Release
about: リリース作業に関するテンプレート
title: "[Release] "
labels: Release
assignees: ''

---

# version x.x Release
## タスク
- [ ] 
- [ ] 

### その他
-
