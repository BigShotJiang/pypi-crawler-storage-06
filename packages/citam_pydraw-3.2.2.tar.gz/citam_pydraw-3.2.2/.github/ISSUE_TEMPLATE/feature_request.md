---
name: Feature request
about: 機能追加要望のテンプレート
title: ''
labels: 'Feedback: feature request'
assignees: ''

---

## 概要

## 要望の詳細
- 

## その他
-
