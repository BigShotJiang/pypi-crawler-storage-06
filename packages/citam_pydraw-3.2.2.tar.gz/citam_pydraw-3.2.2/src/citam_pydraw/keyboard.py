# key = ""
# code = ""
# char = ""
# isPressed = False
