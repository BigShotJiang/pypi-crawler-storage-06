__author__ = 'Robbert Harms'
__date__ = '2023-03-25'
__maintainer__ = 'Robbert Harms'
__email__ = 'robbert@xkls.nl'
__licence__ = 'GPL v3'


class MissingRootNodeError(Exception):
    ...
