# triton_kernels
A repository of the major Triton kernels for running various ML models
