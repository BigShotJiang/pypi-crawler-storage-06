This module adds Project in Helpdesk. We add to the project form view a
ticket counter that redirects you to the helpdesk
