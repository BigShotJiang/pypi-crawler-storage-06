from .tasteful_application import TastefulApp


__all__ = ["TastefulApp"]
