class BaseService:
    """Base service class."""

    def __init__(self) -> None:
        """Initialize the base service."""
