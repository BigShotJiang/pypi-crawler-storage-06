from tasteful.authn.oidc.middleware import OIDCAuthenticationMiddleware


## TODO: Destroy in next release (0.4.0 ?)
OIDCAuthenticationBackend = OIDCAuthenticationMiddleware
