# sage_setup: distribution = sagemath-gap-pkg-semigroups
