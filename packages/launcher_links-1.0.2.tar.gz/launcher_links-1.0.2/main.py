def main():
    print("Hello from launcher-links!")


if __name__ == "__main__":
    main()
