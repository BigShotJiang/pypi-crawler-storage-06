# Credits

## Main Developer

- The Galactipy Contributors <mpq.dev@pm.me>

## Contributors

We don't have contributors... yet. Why not be the first?
