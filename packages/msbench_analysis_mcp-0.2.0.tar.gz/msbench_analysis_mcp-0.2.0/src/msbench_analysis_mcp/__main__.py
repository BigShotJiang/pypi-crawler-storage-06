# __main__.py

from msbench_analysis_mcp import main

main()