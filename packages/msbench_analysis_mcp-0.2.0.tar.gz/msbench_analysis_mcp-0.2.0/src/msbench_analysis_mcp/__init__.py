from .analysis_server import runServer

def main() -> None:
    runServer()

if __name__ == "__main__":
    main()
