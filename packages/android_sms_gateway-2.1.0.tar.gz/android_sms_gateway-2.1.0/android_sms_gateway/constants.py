VERSION = "2.1.0"

DEFAULT_URL = "https://api.sms-gate.app/3rdparty/v1"
