from syncloudlib.application.connection import api_get, api_post


def test_import():
    assert True