# -*- coding: utf-8 -*-
"""
Created on Thu Mar  6 11:52:22 2025

@author: 2016570
"""

