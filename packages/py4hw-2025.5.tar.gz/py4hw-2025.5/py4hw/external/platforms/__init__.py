#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Sep 30 11:03:05 2023

@author: dcr
"""

from .terasic import *
