# -*- coding: utf-8 -*-
"""
Created on Fri Apr 21 17:40:06 2023

@author: dcr
"""

import py4hw.external.intel.BlockDesignFile
import py4hw.external.intel.VectorWaveformFile
import py4hw.external.intel.ip
from py4hw.external.intel.ip.alt import *
from py4hw.external.intel.ip.lpm import *