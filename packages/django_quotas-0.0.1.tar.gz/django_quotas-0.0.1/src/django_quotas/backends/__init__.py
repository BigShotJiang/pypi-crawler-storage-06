#
#  Copyright 2025 by Dmitry Berezovsky, MIT License
#
