#
#  Copyright 2025 by Dmitry Berezovsky, MIT License
#
"""Database-backed implementation subpackage for django_quotas.

@package django_quotas.backend.db
"""

__all__ = []

#
#  Copyright 2025 by Dmitry Berezovsky, MIT License
#
