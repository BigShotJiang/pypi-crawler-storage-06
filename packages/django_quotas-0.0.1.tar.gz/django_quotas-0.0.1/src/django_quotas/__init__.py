#
#  Copyright 2025 by Dmitry Berezovsky, MIT License
#
"""Django quotas management library package root.

@package django_quotas
"""

__all__ = []

#
#  Copyright 2025 by Dmitry Berezovsky, MIT License
#
