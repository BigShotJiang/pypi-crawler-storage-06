# New Alerts

Have a good idea for a new alert? Let us know what you are thinking by posting a [GitHub issue](https://github.com/PrincetonUniversity/job_defense_shield).
