# flake8: noqa
from .console import AppConsole, console
