# flake8: noqa
from wowool.document.document import Document
from wowool.document.document_interface import DocumentInterface
