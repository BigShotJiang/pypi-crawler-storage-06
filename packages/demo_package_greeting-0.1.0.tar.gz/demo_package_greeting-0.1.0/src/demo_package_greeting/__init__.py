def greet(name: str) -> str:
    print(f'Hello {name}')