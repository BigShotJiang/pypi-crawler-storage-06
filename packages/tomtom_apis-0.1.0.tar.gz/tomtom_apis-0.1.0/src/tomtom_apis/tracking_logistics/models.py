"""Models for the TomTom Tracking and Logistics API."""
