"""Automotive tests."""
