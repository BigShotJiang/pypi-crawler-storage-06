"""Places tests."""
