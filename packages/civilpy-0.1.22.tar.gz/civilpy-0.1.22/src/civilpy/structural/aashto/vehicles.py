class HL93Load:
    def __init__(self):
        self.axels = {
            'spacing': 6,
            1: {'load': 8, 'dist': 0},
            2: {'load': 32, 'dist': 14},
            3: {'load': 32, 'dist': [14, 30]}
        }

