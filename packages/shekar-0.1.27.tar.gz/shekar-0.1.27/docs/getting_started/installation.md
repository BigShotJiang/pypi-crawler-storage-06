# Installing shekar

## PyPI

To install `shekar` using pip, you can run the following command in your terminal:

<!-- termynal -->
```bash
$ pip install shekar
```