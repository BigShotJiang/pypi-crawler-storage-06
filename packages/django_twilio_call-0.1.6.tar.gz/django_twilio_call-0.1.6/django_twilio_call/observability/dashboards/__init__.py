"""Dashboard configurations package."""
