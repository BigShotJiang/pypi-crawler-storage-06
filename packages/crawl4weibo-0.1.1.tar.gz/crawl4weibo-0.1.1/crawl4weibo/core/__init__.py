#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Core module for crawl4weibo
"""