# pytest-multilog API
from pytest_multilog.helper import TestHelper

# Exported API
__all__ = ["TestHelper"]
