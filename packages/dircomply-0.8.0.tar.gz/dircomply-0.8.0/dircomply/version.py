"""
version.py

Author: Benevant Mathew
Date: 2025-09-21
"""
__version__ = "0.8.0"
__author__ = "Benevant Mathew"
__email__ = "benevantmathewv@gmail.com"
__release_date__="21-09-2025"

if __name__ == "__main__":
    print(__version__)