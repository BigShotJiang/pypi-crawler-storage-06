"""This package provides a cups printer driver."""

PLUGIN_VERSION = "1.1.1"
