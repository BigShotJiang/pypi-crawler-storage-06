# pylint: disable=C0114


class ConfigurationException(Exception):
    """for when there is a config file problem"""
