# patterns subpackage
__all__ = [
    "replace_phone",
    "replace_address",
    "replace_email",
    "replace_id"
]