# protools
Personal protein processing tool collections.

## Installment

Necessary requirement is listed in [requirements.txt](./requirements.txt).
Optional requirement is listed below:
```bash
conda install -c schrodinger pymol
conda install -c bioconda abnumber
```
Also, pypi release will be updated every github release, just install it by `pip`:
```bash
pip install protools4py
```
