[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.html)
[![DOI](https://zenodo.org/badge/366746474.svg)](https://zenodo.org/badge/latestdoi/366746474)

[![PyPI version](https://badge.fury.io/py/PyMPDATA-examples.svg)](https://pypi.org/project/PyMPDATA-examples)
[![API docs](https://img.shields.io/badge/API_docs-pdoc3-blue.svg)](https://open-atmos.github.io/PyMPDATA-examples/)

For a list of examples, see [PyMPDATA-examples documentation](https://open-atmos.github.io/PyMPDATA/PyMPDATA_examples.html).

For information on package development, see [PyMPDATA README](https://github.com/open-atmos/PyMPDATA/blob/main/README.md).
