# pylint: disable=missing-module-docstring,missing-function-docstring
import PyMPDATA_MPI


def test_version():
    print(PyMPDATA_MPI.__version__)
