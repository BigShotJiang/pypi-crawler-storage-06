# Dataset Downloader

一个支持断点续传和多线程功能的文件下载SDK。

## 功能特性

- 支持断点续传下载
- 多线程并发下载
- 进度条显示
- 自动重试机制
- 文件完整性校验

## 安装

### 从PyPI安装（推荐）

```bash
pip install dataset-down
```

### 开发模式安装

```bash
# 克隆仓库
git clone https://github.com/your-repo/dataset-down.git
cd dataset-down
# 构建分发包
python setup.py sdist bdist_wheel

# 安装构建好的包
pip install dist/dataset_down-0.1.0-py3-none-any.whl
# 以开发模式安装（代码修改即时生效）
pip install -e .
```

## 卸载与更新

```bash
# 卸载
pip uninstall dataset-down

# 更新到最新版本
pip install --upgrade dataset-down

# 更新到指定版本
pip install dataset-down==0.1.0
```

## 依赖包

本项目依赖以下Python包：

- `requests` - HTTP库，用于文件下载
- `tqdm` - 进度条显示
- `click` - 命令行界面构建
- `psutil` - 系统资源监控
- `filelock` - 文件锁机制
- `pytz` - 时区处理

### 安装依赖

```bash
pip install requests tqdm click psutil filelock pytz
```

## 认证配置

在使用SDK功能前，需要先进行认证：

```bash
dataset-down login --ak YOUR_ACCESS_KEY --sk YOUR_SECRET_KEY
```

## 支持的命令

### 登录

```bash
dataset-down login [OPTIONS]
```

**参数说明**：

| 参数 | 是否必需 | 描述 |
|------|----------|------|
| `--ak` | 是 | Access Key |
| `--sk` | 是 | Secret Key |

**示例**：

```bash
dataset-down login --ak YOUR_ACCESS_KEY --sk YOUR_SECRET_KEY
```

### 下载文件或文件夹

```bash
dataset-down download [OPTIONS]
```

**参数说明**：

| 参数 | 是否必需 | 默认值 | 描述 |
|------|----------|--------|------|
| `--dataset-id` | 是 | 无 | 数据集 ID |
| `--version` | 否 | `master` | 版本号 |
| `--source-path` | 是 | 无 | 源文件路径，如果是目录则下载整个目录 |
| `--target-path` | 否 | `.` (当前目录) | 目标保存路径 |

**示例**：

```bash
# 下载指定数据集的文件
dataset-down download --dataset-id my_dataset --source-path /path/to/file.txt --target-path /path/to/save --version master

# 下载整个目录到指定位置
dataset-down download --dataset-id my_dataset --source-path /data/dir --target-path ./local_dir --version master
```

### 停止正在运行的下载进程

```bash
dataset-down stop_running_downloading_process
```

### 断点续传

- 如果下载中断，只需重新执行相同的命令，程序会自动从断点处继续下载。