# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2025 The Linux Foundation

"""Dependamerge - Automatically merge automation PRs across GitHub organizations."""

from ._version import __version__

__all__ = ["__version__"]
