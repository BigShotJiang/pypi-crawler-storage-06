class BadRequest(Exception):
    pass


class RequestError(Exception):
    pass


class MissingScopeError(Exception):
    pass
