CONFIG = {
    "short_description": "The Cypher application produces a cypher script from the results of the entity graph.",
    "long_description": "The  Cypher application produces a cypher script from the results of the entity graph. These links represent relations between entities that have been found to exist in the document.",
    "aliases": ["cypher"],
}
