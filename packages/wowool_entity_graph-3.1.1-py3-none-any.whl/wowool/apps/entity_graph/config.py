CONFIG = {
    "short_description": "The Entity Graph application produces a list of links between entities.",
    "long_description": "The Entity Graph application produces a list of links between entities. These links represent relations between the entities that have been found to exist in the document.",
    "aliases": ["graph"],
}
