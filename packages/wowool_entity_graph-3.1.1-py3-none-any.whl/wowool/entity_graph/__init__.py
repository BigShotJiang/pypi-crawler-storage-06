from wowool.entity_graph.entity_graph import EntityGraph, CollectedResults
from wowool.cypher.cypher_stream import CypherStream
