"""
    KekLib.NodeTools.py
"""

def eq_(a, b):
    assert a == b