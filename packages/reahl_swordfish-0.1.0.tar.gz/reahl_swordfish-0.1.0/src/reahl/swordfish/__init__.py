"""
Swordfish - A classic Smalltalk IDE for GemStone/Smalltalk

This package provides a Python-based IDE that offers a classic Smalltalk development 
experience for GemStone/Smalltalk systems.
"""

__version__ = "1.0.0"