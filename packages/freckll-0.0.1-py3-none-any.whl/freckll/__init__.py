import importlib.metadata

__version__ = release = importlib.metadata.version("freckll")
