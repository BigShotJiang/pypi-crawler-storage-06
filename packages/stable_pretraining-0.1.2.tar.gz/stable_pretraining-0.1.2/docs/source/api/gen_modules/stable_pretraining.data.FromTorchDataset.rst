﻿FromTorchDataset
================

.. currentmodule:: stable_pretraining.data

.. autoclass:: FromTorchDataset
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.data.FromTorchDataset:

.. minigallery:: stable_pretraining.data.FromTorchDataset
    :add-heading: Examples using ``FromTorchDataset``:
