﻿SklearnCheckpoint
=================

.. currentmodule:: stable_pretraining.callbacks

.. autoclass:: SklearnCheckpoint
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.callbacks.SklearnCheckpoint:

.. minigallery:: stable_pretraining.callbacks.SklearnCheckpoint
    :add-heading: Examples using ``SklearnCheckpoint``:
