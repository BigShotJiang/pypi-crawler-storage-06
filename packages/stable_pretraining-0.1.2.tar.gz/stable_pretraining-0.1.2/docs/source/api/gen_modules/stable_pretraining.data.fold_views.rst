﻿fold\_views
===========

.. currentmodule:: stable_pretraining.data

.. autofunction:: fold_views

.. minigallery:: stable_pretraining.data.fold_views
    :add-heading: Examples using ``fold_views``:
