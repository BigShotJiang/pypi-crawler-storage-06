﻿from\_timm
==========

.. currentmodule:: stable_pretraining.backbone

.. autofunction:: from_timm

.. minigallery:: stable_pretraining.backbone.from_timm
    :add-heading: Examples using ``from_timm``:
