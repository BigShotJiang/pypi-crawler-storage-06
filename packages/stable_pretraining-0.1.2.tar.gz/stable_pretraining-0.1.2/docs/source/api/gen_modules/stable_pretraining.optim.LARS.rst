﻿LARS
====

.. currentmodule:: stable_pretraining.optim

.. autoclass:: LARS
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.optim.LARS:

.. minigallery:: stable_pretraining.optim.LARS
    :add-heading: Examples using ``LARS``:
