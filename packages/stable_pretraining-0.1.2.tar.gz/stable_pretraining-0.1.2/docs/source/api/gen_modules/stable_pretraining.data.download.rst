﻿download
========

.. currentmodule:: stable_pretraining.data

.. autofunction:: download

.. minigallery:: stable_pretraining.data.download
    :add-heading: Examples using ``download``:
