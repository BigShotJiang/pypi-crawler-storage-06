﻿random\_split
=============

.. currentmodule:: stable_pretraining.data

.. autofunction:: random_split

.. minigallery:: stable_pretraining.data.random_split
    :add-heading: Examples using ``random_split``:
