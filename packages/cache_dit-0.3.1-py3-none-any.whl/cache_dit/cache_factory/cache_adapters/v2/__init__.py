from cache_dit.cache_factory.cache_adapters.v2.cache_adapter_v2 import (
    CachedAdapterV2,
)
