from common.service.base import Service, ServiceType


class LogService(Service):
    name = ServiceType.LOG_SERVICE
