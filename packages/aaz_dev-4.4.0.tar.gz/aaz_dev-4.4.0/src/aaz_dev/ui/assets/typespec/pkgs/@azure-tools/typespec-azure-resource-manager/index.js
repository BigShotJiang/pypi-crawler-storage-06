var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/typespec/node_modules/.pnpm/pluralize@8.0.0/node_modules/pluralize/pluralize.js
var require_pluralize = __commonJS({
  "src/typespec/node_modules/.pnpm/pluralize@8.0.0/node_modules/pluralize/pluralize.js"(exports, module) {
    (function(root, pluralize2) {
      if (typeof __require === "function" && typeof exports === "object" && typeof module === "object") {
        module.exports = pluralize2();
      } else if (typeof define === "function" && define.amd) {
        define(function() {
          return pluralize2();
        });
      } else {
        root.pluralize = pluralize2();
      }
    })(exports, function() {
      var pluralRules = [];
      var singularRules = [];
      var uncountables = {};
      var irregularPlurals = {};
      var irregularSingles = {};
      function sanitizeRule(rule) {
        if (typeof rule === "string") {
          return new RegExp("^" + rule + "$", "i");
        }
        return rule;
      }
      function restoreCase(word, token) {
        if (word === token) return token;
        if (word === word.toLowerCase()) return token.toLowerCase();
        if (word === word.toUpperCase()) return token.toUpperCase();
        if (word[0] === word[0].toUpperCase()) {
          return token.charAt(0).toUpperCase() + token.substr(1).toLowerCase();
        }
        return token.toLowerCase();
      }
      function interpolate(str, args) {
        return str.replace(/\$(\d{1,2})/g, function(match, index) {
          return args[index] || "";
        });
      }
      function replace(word, rule) {
        return word.replace(rule[0], function(match, index) {
          var result = interpolate(rule[1], arguments);
          if (match === "") {
            return restoreCase(word[index - 1], result);
          }
          return restoreCase(match, result);
        });
      }
      function sanitizeWord(token, word, rules2) {
        if (!token.length || uncountables.hasOwnProperty(token)) {
          return word;
        }
        var len = rules2.length;
        while (len--) {
          var rule = rules2[len];
          if (rule[0].test(word)) return replace(word, rule);
        }
        return word;
      }
      function replaceWord(replaceMap, keepMap, rules2) {
        return function(word) {
          var token = word.toLowerCase();
          if (keepMap.hasOwnProperty(token)) {
            return restoreCase(word, token);
          }
          if (replaceMap.hasOwnProperty(token)) {
            return restoreCase(word, replaceMap[token]);
          }
          return sanitizeWord(token, word, rules2);
        };
      }
      function checkWord(replaceMap, keepMap, rules2, bool) {
        return function(word) {
          var token = word.toLowerCase();
          if (keepMap.hasOwnProperty(token)) return true;
          if (replaceMap.hasOwnProperty(token)) return false;
          return sanitizeWord(token, token, rules2) === token;
        };
      }
      function pluralize2(word, count, inclusive) {
        var pluralized = count === 1 ? pluralize2.singular(word) : pluralize2.plural(word);
        return (inclusive ? count + " " : "") + pluralized;
      }
      pluralize2.plural = replaceWord(
        irregularSingles,
        irregularPlurals,
        pluralRules
      );
      pluralize2.isPlural = checkWord(
        irregularSingles,
        irregularPlurals,
        pluralRules
      );
      pluralize2.singular = replaceWord(
        irregularPlurals,
        irregularSingles,
        singularRules
      );
      pluralize2.isSingular = checkWord(
        irregularPlurals,
        irregularSingles,
        singularRules
      );
      pluralize2.addPluralRule = function(rule, replacement) {
        pluralRules.push([sanitizeRule(rule), replacement]);
      };
      pluralize2.addSingularRule = function(rule, replacement) {
        singularRules.push([sanitizeRule(rule), replacement]);
      };
      pluralize2.addUncountableRule = function(word) {
        if (typeof word === "string") {
          uncountables[word.toLowerCase()] = true;
          return;
        }
        pluralize2.addPluralRule(word, "$0");
        pluralize2.addSingularRule(word, "$0");
      };
      pluralize2.addIrregularRule = function(single, plural) {
        plural = plural.toLowerCase();
        single = single.toLowerCase();
        irregularSingles[single] = plural;
        irregularPlurals[plural] = single;
      };
      [
        // Pronouns.
        ["I", "we"],
        ["me", "us"],
        ["he", "they"],
        ["she", "they"],
        ["them", "them"],
        ["myself", "ourselves"],
        ["yourself", "yourselves"],
        ["itself", "themselves"],
        ["herself", "themselves"],
        ["himself", "themselves"],
        ["themself", "themselves"],
        ["is", "are"],
        ["was", "were"],
        ["has", "have"],
        ["this", "these"],
        ["that", "those"],
        // Words ending in with a consonant and `o`.
        ["echo", "echoes"],
        ["dingo", "dingoes"],
        ["volcano", "volcanoes"],
        ["tornado", "tornadoes"],
        ["torpedo", "torpedoes"],
        // Ends with `us`.
        ["genus", "genera"],
        ["viscus", "viscera"],
        // Ends with `ma`.
        ["stigma", "stigmata"],
        ["stoma", "stomata"],
        ["dogma", "dogmata"],
        ["lemma", "lemmata"],
        ["schema", "schemata"],
        ["anathema", "anathemata"],
        // Other irregular rules.
        ["ox", "oxen"],
        ["axe", "axes"],
        ["die", "dice"],
        ["yes", "yeses"],
        ["foot", "feet"],
        ["eave", "eaves"],
        ["goose", "geese"],
        ["tooth", "teeth"],
        ["quiz", "quizzes"],
        ["human", "humans"],
        ["proof", "proofs"],
        ["carve", "carves"],
        ["valve", "valves"],
        ["looey", "looies"],
        ["thief", "thieves"],
        ["groove", "grooves"],
        ["pickaxe", "pickaxes"],
        ["passerby", "passersby"]
      ].forEach(function(rule) {
        return pluralize2.addIrregularRule(rule[0], rule[1]);
      });
      [
        [/s?$/i, "s"],
        [/[^\u0000-\u007F]$/i, "$0"],
        [/([^aeiou]ese)$/i, "$1"],
        [/(ax|test)is$/i, "$1es"],
        [/(alias|[^aou]us|t[lm]as|gas|ris)$/i, "$1es"],
        [/(e[mn]u)s?$/i, "$1s"],
        [/([^l]ias|[aeiou]las|[ejzr]as|[iu]am)$/i, "$1"],
        [/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i, "$1i"],
        [/(alumn|alg|vertebr)(?:a|ae)$/i, "$1ae"],
        [/(seraph|cherub)(?:im)?$/i, "$1im"],
        [/(her|at|gr)o$/i, "$1oes"],
        [/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|automat|quor)(?:a|um)$/i, "$1a"],
        [/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)(?:a|on)$/i, "$1a"],
        [/sis$/i, "ses"],
        [/(?:(kni|wi|li)fe|(ar|l|ea|eo|oa|hoo)f)$/i, "$1$2ves"],
        [/([^aeiouy]|qu)y$/i, "$1ies"],
        [/([^ch][ieo][ln])ey$/i, "$1ies"],
        [/(x|ch|ss|sh|zz)$/i, "$1es"],
        [/(matr|cod|mur|sil|vert|ind|append)(?:ix|ex)$/i, "$1ices"],
        [/\b((?:tit)?m|l)(?:ice|ouse)$/i, "$1ice"],
        [/(pe)(?:rson|ople)$/i, "$1ople"],
        [/(child)(?:ren)?$/i, "$1ren"],
        [/eaux$/i, "$0"],
        [/m[ae]n$/i, "men"],
        ["thou", "you"]
      ].forEach(function(rule) {
        return pluralize2.addPluralRule(rule[0], rule[1]);
      });
      [
        [/s$/i, ""],
        [/(ss)$/i, "$1"],
        [/(wi|kni|(?:after|half|high|low|mid|non|night|[^\w]|^)li)ves$/i, "$1fe"],
        [/(ar|(?:wo|[ae])l|[eo][ao])ves$/i, "$1f"],
        [/ies$/i, "y"],
        [/\b([pl]|zomb|(?:neck|cross)?t|coll|faer|food|gen|goon|group|lass|talk|goal|cut)ies$/i, "$1ie"],
        [/\b(mon|smil)ies$/i, "$1ey"],
        [/\b((?:tit)?m|l)ice$/i, "$1ouse"],
        [/(seraph|cherub)im$/i, "$1"],
        [/(x|ch|ss|sh|zz|tto|go|cho|alias|[^aou]us|t[lm]as|gas|(?:her|at|gr)o|[aeiou]ris)(?:es)?$/i, "$1"],
        [/(analy|diagno|parenthe|progno|synop|the|empha|cri|ne)(?:sis|ses)$/i, "$1sis"],
        [/(movie|twelve|abuse|e[mn]u)s$/i, "$1"],
        [/(test)(?:is|es)$/i, "$1is"],
        [/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i, "$1us"],
        [/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|quor)a$/i, "$1um"],
        [/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)a$/i, "$1on"],
        [/(alumn|alg|vertebr)ae$/i, "$1a"],
        [/(cod|mur|sil|vert|ind)ices$/i, "$1ex"],
        [/(matr|append)ices$/i, "$1ix"],
        [/(pe)(rson|ople)$/i, "$1rson"],
        [/(child)ren$/i, "$1"],
        [/(eau)x?$/i, "$1"],
        [/men$/i, "man"]
      ].forEach(function(rule) {
        return pluralize2.addSingularRule(rule[0], rule[1]);
      });
      [
        // Singular words with no plurals.
        "adulthood",
        "advice",
        "agenda",
        "aid",
        "aircraft",
        "alcohol",
        "ammo",
        "analytics",
        "anime",
        "athletics",
        "audio",
        "bison",
        "blood",
        "bream",
        "buffalo",
        "butter",
        "carp",
        "cash",
        "chassis",
        "chess",
        "clothing",
        "cod",
        "commerce",
        "cooperation",
        "corps",
        "debris",
        "diabetes",
        "digestion",
        "elk",
        "energy",
        "equipment",
        "excretion",
        "expertise",
        "firmware",
        "flounder",
        "fun",
        "gallows",
        "garbage",
        "graffiti",
        "hardware",
        "headquarters",
        "health",
        "herpes",
        "highjinks",
        "homework",
        "housework",
        "information",
        "jeans",
        "justice",
        "kudos",
        "labour",
        "literature",
        "machinery",
        "mackerel",
        "mail",
        "media",
        "mews",
        "moose",
        "music",
        "mud",
        "manga",
        "news",
        "only",
        "personnel",
        "pike",
        "plankton",
        "pliers",
        "police",
        "pollution",
        "premises",
        "rain",
        "research",
        "rice",
        "salmon",
        "scissors",
        "series",
        "sewage",
        "shambles",
        "shrimp",
        "software",
        "species",
        "staff",
        "swine",
        "tennis",
        "traffic",
        "transportation",
        "trout",
        "tuna",
        "wealth",
        "welfare",
        "whiting",
        "wildebeest",
        "wildlife",
        "you",
        /pok[eé]mon$/i,
        // Regexes.
        /[^aeiou]ese$/i,
        // "chinese", "japanese"
        /deer$/i,
        // "deer", "reindeer"
        /fish$/i,
        // "fish", "blowfish", "angelfish"
        /measles$/i,
        /o[iu]s$/i,
        // "carnivorous"
        /pox$/i,
        // "chickpox", "smallpox"
        /sheep$/i
      ].forEach(pluralize2.addUncountableRule);
      return pluralize2;
    });
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/index.js
var src_exports = {};
__export(src_exports, {
  $armCommonTypesVersion: () => $armCommonTypesVersion,
  $armLibraryNamespace: () => $armLibraryNamespace,
  $armProviderNameValue: () => $armProviderNameValue,
  $armProviderNamespace: () => $armProviderNamespace,
  $armResourceAction: () => $armResourceAction,
  $armResourceCollectionAction: () => $armResourceCollectionAction,
  $armResourceCreateOrUpdate: () => $armResourceCreateOrUpdate,
  $armResourceDelete: () => $armResourceDelete,
  $armResourceList: () => $armResourceList,
  $armResourceOperations: () => $armResourceOperations,
  $armResourceRead: () => $armResourceRead,
  $armResourceUpdate: () => $armResourceUpdate,
  $armVirtualResource: () => $armVirtualResource,
  $customAzureResource: () => $customAzureResource,
  $decorators: () => $decorators2,
  $extensionResource: () => $extensionResource,
  $identifiers: () => $identifiers,
  $lib: () => $lib,
  $linter: () => $linter,
  $locationResource: () => $locationResource,
  $resourceBaseType: () => $resourceBaseType,
  $resourceGroupResource: () => $resourceGroupResource,
  $singleton: () => $singleton,
  $subscriptionResource: () => $subscriptionResource,
  $tenantResource: () => $tenantResource,
  $useLibraryNamespace: () => $useLibraryNamespace,
  ResourceBaseType: () => ResourceBaseType,
  armRenameListByOperationInternal: () => armRenameListByOperationInternal,
  getArmCommonTypeOpenAPIRef: () => getArmCommonTypeOpenAPIRef,
  getArmCommonTypesVersion: () => getArmCommonTypesVersion,
  getArmCommonTypesVersions: () => getArmCommonTypesVersions,
  getArmIdentifiers: () => getArmIdentifiers,
  getArmKeyIdentifiers: () => getArmKeyIdentifiers,
  getArmProviderNamespace: () => getArmProviderNamespace,
  getArmResource: () => getArmResource,
  getArmResourceInfo: () => getArmResourceInfo,
  getArmResourceKind: () => getArmResourceKind,
  getArmResources: () => getArmResources,
  getExternalTypeRef: () => getExternalTypeRef,
  getResourceBaseType: () => getResourceBaseType,
  getSingletonResourceKey: () => getSingletonResourceKey,
  getUsedLibraryNamespaces: () => getUsedLibraryNamespaces,
  isArmCollectionAction: () => isArmCollectionAction,
  isArmCommonType: () => isArmCommonType,
  isArmLibraryNamespace: () => isArmLibraryNamespace,
  isArmProviderNamespace: () => isArmProviderNamespace,
  isArmVirtualResource: () => isArmVirtualResource,
  isAzureResource: () => isAzureResource,
  isConditionallyFlattened: () => isConditionallyFlattened,
  isCustomAzureResource: () => isCustomAzureResource,
  isSingletonResource: () => isSingletonResource,
  namespace: () => namespace3,
  resolveResourceBaseType: () => resolveResourceBaseType,
  resolveResourceOperations: () => resolveResourceOperations
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/common-types.js
import { isTypeSpecValueTypeOf } from "@typespec/compiler";
import { $useDependency, getVersion } from "@typespec/versioning";

// src/typespec/packages/typespec-azure-resource-manager/dist/src/commontypes.private.decorators.js
var commontypes_private_decorators_exports = {};
__export(commontypes_private_decorators_exports, {
  $armCommonDefinition: () => $armCommonDefinition,
  $armCommonParameter: () => $armCommonParameter,
  $armCommonTypesVersions: () => $armCommonTypesVersions,
  ArmCommonTypesDefaultVersion: () => ArmCommonTypesDefaultVersion,
  getCommonTypeRecords: () => getCommonTypeRecords,
  namespace: () => namespace
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/state.js
function azureResourceManagerCreateStateSymbol(name) {
  return Symbol.for(`@azure-tools/typespec-azure-resource-manager.${name}`);
}
var ArmStateKeys = {
  armProviderNamespaces: azureResourceManagerCreateStateSymbol("armProviderNamespaces"),
  armResourceOperations: azureResourceManagerCreateStateSymbol("armResourceOperations"),
  armResourceCollectionAction: azureResourceManagerCreateStateSymbol("armResourceCollectionAction"),
  armResourceCollection: azureResourceManagerCreateStateSymbol("parameterBaseTypes"),
  armResources: azureResourceManagerCreateStateSymbol("armResources"),
  armLibraryNamespaces: azureResourceManagerCreateStateSymbol("armLibraryNamespaces"),
  usesArmLibraryNamespaces: azureResourceManagerCreateStateSymbol("usesArmLibraryNamespaces"),
  armCommonTypesVersion: azureResourceManagerCreateStateSymbol("armCommonTypesVersion"),
  armIdentifiers: azureResourceManagerCreateStateSymbol("armIdentifiers"),
  externalTypeRef: azureResourceManagerCreateStateSymbol("externalTypeRef"),
  // resource.ts
  armResourcesCached: azureResourceManagerCreateStateSymbol("armResourcesCached"),
  armSingletonResources: azureResourceManagerCreateStateSymbol("armSingletonResources"),
  resourceBaseType: azureResourceManagerCreateStateSymbol("resourceBaseTypeKey"),
  armBuiltInResource: azureResourceManagerCreateStateSymbol("armExternalResource"),
  customAzureResource: azureResourceManagerCreateStateSymbol("azureCustomResource"),
  // private.decorator.ts
  azureResourceBase: azureResourceManagerCreateStateSymbol("azureResourceBase"),
  armConditionalClientFlatten: azureResourceManagerCreateStateSymbol("armConditionalClientFlatten"),
  // commontypes.private.decorators.ts
  armCommonDefinitions: azureResourceManagerCreateStateSymbol("armCommonDefinitions"),
  armCommonParameters: azureResourceManagerCreateStateSymbol("armCommonParameters"),
  armCommonTypesVersions: azureResourceManagerCreateStateSymbol("armCommonTypesVersions")
};

// src/typespec/packages/typespec-azure-resource-manager/dist/src/commontypes.private.decorators.js
var namespace = "Azure.ResourceManager.CommonTypes.Private";
var ArmCommonTypesDefaultVersion = "v3";
function getArmTypesPath(program) {
  return "{arm-types-dir}";
}
function storeCommonTypeRecord(context, entity, kind, name, version, referenceFile) {
  const basePath = getArmTypesPath(context.program).trim();
  let isDefault = false;
  if (version && typeof version !== "string" && !("valueKind" in version)) {
    isDefault = !!version.isDefault;
    version = version.version;
  }
  if ((version || referenceFile) && basePath.endsWith(".json"))
    return;
  if (!version)
    version = ArmCommonTypesDefaultVersion;
  if (!referenceFile)
    referenceFile = "types.json";
  const versionStr = typeof version === "string" ? version : version.value.name;
  const records = getCommonTypeRecords(context.program, entity);
  records.records[versionStr] = {
    name,
    kind,
    version: versionStr,
    basePath,
    referenceFile
  };
  if (isDefault) {
    records.defaultKey = versionStr;
  }
  context.program.stateMap(ArmStateKeys.armCommonDefinitions).set(entity, records);
}
function getCommonTypeRecords(program, entity) {
  return program.stateMap(ArmStateKeys.armCommonDefinitions).get(entity) ?? { records: {} };
}
var $armCommonParameter = (context, entity, parameterName, version, referenceFile) => {
  if (!parameterName) {
    parameterName = entity.name;
  }
  storeCommonTypeRecord(context, entity, "parameters", parameterName, version, referenceFile);
};
var $armCommonDefinition = (context, entity, definitionName, version, referenceFile) => {
  if (!definitionName) {
    definitionName = entity.name;
  }
  storeCommonTypeRecord(context, entity, "definitions", definitionName, version, referenceFile);
};
var $armCommonTypesVersions = (context, enumType) => {
  context.program.stateMap(ArmStateKeys.armCommonTypesVersions).set(enumType, {
    type: enumType,
    allVersions: Array.from(enumType.members.values()).reverse()
  });
};

// src/typespec/packages/typespec-azure-resource-manager/dist/src/lib.js
import { createTypeSpecLibrary, paramMessage } from "@typespec/compiler";
var $lib = createTypeSpecLibrary({
  name: "@azure-tools/typespec-azure-resource-manager",
  diagnostics: {
    "single-arm-provider": {
      severity: "error",
      messages: {
        default: "Only one @armProviderNamespace can be declared in a typespec spec at once."
      }
    },
    "decorator-param-wrong-type": {
      severity: "error",
      messages: {
        armUpdateProviderNamespace: "The parameter to @armUpdateProviderNamespace must be an operation with a 'provider' parameter.",
        armIdentifiersIncorrectEntity: "The @identifiers decorator must be applied to a property that is an array of objects",
        armIdentifiersProperties: "The @identifiers decorator expects a parameter that is an array of strings or an empty array."
      }
    },
    "arm-resource-circular-ancestry": {
      severity: "warning",
      messages: {
        default: "There is a loop in the ancestry of this resource.  Please ensure that the `@parentResource` decorator contains the correct parent resource, and that parentage contains no cycles."
      }
    },
    "arm-resource-duplicate-base-parameter": {
      severity: "warning",
      messages: {
        default: "Only one base parameter type is allowed per resource.  Each resource may have only one of `@parentResource`, `@resourceGroupResource`, `@tenantResource`, `@locationResource`, or `@subscriptionResource` decorators."
      }
    },
    "arm-resource-missing-name-property": {
      severity: "error",
      messages: {
        default: "Resource types must include a string property called 'name'."
      }
    },
    "arm-resource-missing-name-key-decorator": {
      severity: "error",
      messages: {
        default: "Resource type 'name' property must have a @key decorator which defines its key name."
      }
    },
    "arm-resource-missing-name-segment-decorator": {
      severity: "error",
      messages: {
        default: "Resource type 'name' property must have a @segment decorator which defines its path fragment."
      }
    },
    "arm-resource-missing-arm-namespace": {
      severity: "error",
      messages: {
        default: "The @armProviderNamespace decorator must be used to define the ARM namespace of the service.  This is best applied to the file-level namespace."
      }
    },
    "arm-resource-invalid-base-type": {
      severity: "error",
      messages: {
        default: "The @armResourceInternal decorator can only be used on a type that ultimately extends TrackedResource, ProxyResource, or ExtensionResource."
      }
    },
    "arm-resource-missing": {
      severity: "error",
      messages: {
        default: paramMessage`No @armResource registration found for type ${"type"}`
      }
    },
    "arm-common-types-incompatible-version": {
      severity: "warning",
      messages: {
        default: paramMessage`No ARM common-types version for this type satisfies the expected version ${"selectedVersion"}.  This type only supports the following version(s): ${"supportedVersions"}`
      }
    },
    "arm-common-types-invalid-version": {
      severity: "error",
      messages: {
        default: paramMessage`No ARM common-types version matches the version string ${"versionString"}.  The following versions are supported: ${"supportedVersions"}`
      }
    },
    "decorator-in-namespace": {
      severity: "error",
      messages: {
        default: paramMessage`The @${"decoratorName"} decorator can only be applied to an operation that is defined inside of a namespace.`
      }
    },
    "parent-type": {
      severity: "error",
      messages: {
        notResourceType: paramMessage`Parent type ${"parent"} of ${"type"} is not registered as an ARM resource type.`
      }
    },
    "resource-without-path-and-segment": {
      severity: "error",
      messages: {
        default: "Resource types must have a property with '@path` and '@segment' decorators."
      }
    },
    "template-type-constraint-no-met": {
      severity: "error",
      messages: {
        default: paramMessage`The template parameter "${"sourceType"}" for "${"entity"}" does not extend the constraint type "${"constraintType"}". ${"actionMessage"}`
      }
    }
  }
});
var { reportDiagnostic, createDiagnostic } = $lib;

// src/typespec/packages/typespec-azure-resource-manager/dist/src/common-types.js
function getArmCommonTypesVersions(program) {
  const map = program.stateMap(ArmStateKeys.armCommonTypesVersions);
  return map?.values().next().value;
}
function getArmCommonTypesVersionFromString(program, entity, versionStr) {
  const commonTypeVersionEnum = program.resolveTypeReference(`Azure.ResourceManager.CommonTypes.Versions.${versionStr}`)[0];
  if (commonTypeVersionEnum === void 0) {
    return [
      void 0,
      [
        createDiagnostic({
          code: "arm-common-types-invalid-version",
          target: entity,
          format: {
            versionString: versionStr,
            supportedVersions: [...getArmCommonTypesVersions(program).type.members.keys()].join(", ")
          }
        })
      ]
    ];
  } else {
    return [commonTypeVersionEnum, []];
  }
}
function isArmCommonType(entity) {
  const commonDecorators = ["$armCommonDefinition", "$armCommonParameter"];
  if (isTypeSpecValueTypeOf(entity, ["Model", "ModelProperty", "Enum", "Union"])) {
    return commonDecorators.some((commonDecorator) => entity.decorators.some((d) => d.decorator.name === commonDecorator));
  }
  return false;
}
var $armCommonTypesVersion = (context, entity, version) => {
  let versionEnum;
  if (typeof version === "string") {
    const [foundEnumMember, diagnostics] = getArmCommonTypesVersionFromString(context.program, entity, version);
    if (!foundEnumMember) {
      context.program.reportDiagnostics(diagnostics);
      return;
    }
    versionEnum = foundEnumMember;
  } else {
    versionEnum = version.value;
  }
  context.program.stateMap(ArmStateKeys.armCommonTypesVersion).set(entity, versionEnum.name);
  if (entity.kind === "Namespace") {
    const versioned = entity.decorators.find((x) => x.definition?.name === "@versioned");
    if (versioned) {
      return;
    }
  }
  context.call($useDependency, entity, versionEnum);
};
function getArmCommonTypesVersion(program, entity) {
  return program.stateMap(ArmStateKeys.armCommonTypesVersion).get(entity);
}
function getArmCommonTypeOpenAPIRef(program, entity, params) {
  const [record, diagnostics] = findArmCommonTypeRecord(program, entity, params);
  if (record) {
    return record.basePath.endsWith(".json") ? `${record.basePath}#/${record.kind}/${record.name}` : `${record.basePath}/${record.version}/${record.referenceFile}#/${record.kind}/${record.name}`;
  } else {
    program.reportDiagnostics(diagnostics);
    return void 0;
  }
}
function findArmCommonTypeRecord(program, entity, params) {
  const { records, defaultKey } = getCommonTypeRecords(program, entity);
  const commonTypes = resolveCommonTypesVersion(program, params);
  const selectedVersion = commonTypes.selectedVersion;
  let record;
  if (selectedVersion) {
    let foundSelectedVersion = false;
    for (const version of commonTypes.allVersions) {
      if (!foundSelectedVersion) {
        if (selectedVersion !== version.name) {
          continue;
        }
        foundSelectedVersion = true;
      }
      const maybeRecord = records[version.name];
      if (maybeRecord) {
        record = maybeRecord;
        break;
      }
    }
  }
  if (record === void 0) {
    record = records[defaultKey ?? ArmCommonTypesDefaultVersion];
  }
  if (record === void 0) {
    return [
      void 0,
      [
        createDiagnostic({
          code: "arm-common-types-incompatible-version",
          target: entity,
          format: {
            selectedVersion: selectedVersion ?? ArmCommonTypesDefaultVersion,
            supportedVersions: Object.keys(records).join(", ")
          }
        })
      ]
    ];
  } else {
    return [record, []];
  }
}
function resolveCommonTypesVersion(program, params) {
  let selectedVersion;
  const { allVersions } = getArmCommonTypesVersions(program) ?? {};
  const versionMap = getVersion(program, params.service.type);
  if (params.version && versionMap) {
    const versionEnumMember = versionMap.getVersions().find((x) => x.value === params.version)?.enumMember;
    if (versionEnumMember) {
      selectedVersion = getArmCommonTypesVersion(program, versionEnumMember);
    }
  }
  if (selectedVersion === void 0) {
    selectedVersion = getArmCommonTypesVersion(program, params.service.type);
  }
  return {
    selectedVersion,
    allVersions: allVersions ?? []
  };
}
var $externalTypeRef = (context, entity, jsonRef) => {
  context.program.stateMap(ArmStateKeys.externalTypeRef).set(entity, jsonRef);
};
function getExternalTypeRef(program, entity) {
  return program.stateMap(ArmStateKeys.externalTypeRef).get(entity);
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/namespace.js
import { addService, getNamespaceFullName } from "@typespec/compiler";
import { unsafe_Realm } from "@typespec/compiler/experimental";
import * as http from "@typespec/http";
import { getAuthentication, setAuthentication } from "@typespec/http";
import { unsafe_setRouteOptionsForNamespace as setRouteOptionsForNamespace } from "@typespec/http/experimental";
import { getResourceTypeForKeyParam } from "@typespec/rest";

// src/typespec/packages/typespec-azure-resource-manager/dist/src/resource.js
import { getAllProperties } from "@azure-tools/typespec-azure-core";
import { $tag, getProperty as compilerGetProperty, getKeyName as getKeyName2, getTags, isArrayModelType, isGlobalNamespace, isNeverType, isTemplateDeclaration } from "@typespec/compiler";
import { isPathParam } from "@typespec/http";
import { $autoRoute, getParentResource as getParentResource2, getSegment as getSegment3 } from "@typespec/rest";

// src/typespec/packages/typespec-azure-resource-manager/dist/src/operations.js
import { $doc, getFriendlyName, ignoreDiagnostics } from "@typespec/compiler";
import { getHttpOperation } from "@typespec/http";
import { $actionSegment, $createsOrReplacesResource, $deletesResource, $readsResource, $updatesResource, getActionSegment, getParentResource, getSegment } from "@typespec/rest";
function getArmResourceOperations(program, resourceType) {
  let operations = program.stateMap(ArmStateKeys.armResourceOperations).get(resourceType);
  if (!operations) {
    operations = { lifecycle: {}, lists: {}, actions: {} };
    program.stateMap(ArmStateKeys.armResourceOperations).set(resourceType, operations);
  }
  return operations;
}
function resolveHttpOperations(program, data) {
  const result = {};
  for (const [key, item] of Object.entries(data)) {
    const httpOperation = ignoreDiagnostics(getHttpOperation(program, item.operation));
    result[key] = {
      ...item,
      path: httpOperation.path,
      httpOperation
    };
  }
  return result;
}
function resolveResourceOperations(program, resourceType) {
  const operations = getArmResourceOperations(program, resourceType);
  return {
    lifecycle: resolveHttpOperations(program, operations.lifecycle),
    actions: resolveHttpOperations(program, operations.actions),
    lists: resolveHttpOperations(program, operations.lists)
  };
}
function setResourceLifecycleOperation(context, target, resourceType, kind, decoratorName) {
  if (target.interface === void 0 || target.interface.node === void 0 || target.interface.node.templateParameters.length > 0) {
    return;
  }
  const operations = getArmResourceOperations(context.program, resourceType);
  const operation = {
    name: target.name,
    kind,
    operation: target,
    operationGroup: target.interface.name
  };
  operations.lifecycle[kind] = operation;
}
var $armResourceRead = (context, target, resourceType) => {
  context.call($readsResource, target, resourceType);
  setResourceLifecycleOperation(context, target, resourceType, "read", "@armResourceRead");
};
var $armResourceCreateOrUpdate = (context, target, resourceType) => {
  context.call($createsOrReplacesResource, target, resourceType);
  setResourceLifecycleOperation(context, target, resourceType, "createOrUpdate", "@armResourceCreateOrUpdate");
};
var $armResourceUpdate = (context, target, resourceType) => {
  context.call($updatesResource, target, resourceType);
  setResourceLifecycleOperation(context, target, resourceType, "update", "@armResourceUpdate");
};
var $armResourceDelete = (context, target, resourceType) => {
  context.call($deletesResource, target, resourceType);
  setResourceLifecycleOperation(context, target, resourceType, "delete", "@armResourceDelete");
};
var $armResourceList = (context, target, resourceType) => {
  if (target.interface === void 0 || target.interface.node === void 0 || target.interface.node.templateParameters.length > 0) {
    return;
  }
  const operations = getArmResourceOperations(context.program, resourceType);
  const operation = {
    name: target.name,
    kind: "list",
    operation: target,
    operationGroup: target.interface.name
  };
  operations.lists[target.name] = operation;
};
function armRenameListByOperationInternal(context, entity, resourceType, parentTypeName, parentFriendlyTypeName, applyOperationRename) {
  const { program } = context;
  if (parentTypeName === void 0 || parentTypeName === "" || parentFriendlyTypeName === void 0 || parentFriendlyTypeName === "") {
    [parentTypeName, parentFriendlyTypeName] = getArmParentName(context.program, resourceType);
  }
  const parentType = getParentResource(program, resourceType);
  if (parentType && !isArmVirtualResource(program, parentType) && !isCustomAzureResource(program, parentType)) {
    const parentResourceInfo = getArmResourceInfo(program, parentType);
    if (!parentResourceInfo && resourceType.namespace !== void 0 && isArmLibraryNamespace(program, resourceType.namespace))
      return;
    if (!parentResourceInfo) {
      reportDiagnostic(program, {
        code: "parent-type",
        messageId: "notResourceType",
        target: resourceType,
        format: { type: resourceType.name, parent: parentType.name }
      });
      return;
    }
    parentTypeName = parentType.name[0].toUpperCase() + parentType.name.substring(1);
  }
  context.call($doc, entity, `List ${resourceType.name} resources by ${parentType ? parentTypeName : parentFriendlyTypeName}`, void 0);
  if (applyOperationRename === void 0 || applyOperationRename === true) {
    entity.name = parentTypeName === "Extension" || parentTypeName === void 0 || parentTypeName.length < 1 ? "list" : `listBy${parentTypeName}`;
  }
}
function getArmParentName(program, resource) {
  const parent = getParentResource(program, resource);
  if (parent && (isArmVirtualResource(program, parent) || isCustomAzureResource(program, parent))) {
    const parentName = getFriendlyName(program, parent) ?? parent.name;
    if (parentName === void 0 || parentName.length < 2) {
      return ["", ""];
    }
    return [
      parentName,
      parentName.length > 1 ? parentName.charAt(0).toLowerCase() + parentName.substring(1) : ""
    ];
  }
  switch (getResourceBaseType(program, resource)) {
    case ResourceBaseType.Extension:
      return ["Extension", "parent"];
    case ResourceBaseType.Location:
      return ["Location", "location"];
    case ResourceBaseType.Subscription:
      return ["Subscription", "subscription"];
    case ResourceBaseType.Tenant:
      return ["Tenant", "tenant"];
    case ResourceBaseType.ResourceGroup:
    default:
      return ["ResourceGroup", "resource group"];
  }
}
var $armResourceAction = (context, target, resourceType) => {
  const { program } = context;
  if (target.interface === void 0 || target.interface.node === void 0 || target.interface.node.templateParameters.length > 0) {
    return;
  }
  const operations = getArmResourceOperations(program, resourceType);
  const operation = {
    name: target.name,
    kind: "action",
    operation: target,
    operationGroup: target.interface.name
  };
  operations.actions[target.name] = operation;
  const segment = getSegment(program, target) ?? getActionSegment(program, target);
  if (!segment) {
    context.call($actionSegment, target, uncapitalize(target.name));
  }
};
function uncapitalize(name) {
  if (name === "") {
    return name;
  }
  return name[0].toLowerCase() + name.substring(1);
}
var $armResourceCollectionAction = (context, target) => {
  context.program.stateMap(ArmStateKeys.armResourceCollectionAction).set(target, true);
};
function isArmCollectionAction(program, target) {
  return program.stateMap(ArmStateKeys.armResourceCollectionAction).get(target) === true;
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/private.decorators.js
var private_decorators_exports = {};
__export(private_decorators_exports, {
  $decorators: () => $decorators,
  getArmResource: () => getArmResource,
  getResourceParameterBases: () => getResourceParameterBases,
  isArmOperationsListInterface: () => isArmOperationsListInterface,
  isAzureResource: () => isAzureResource,
  isConditionallyFlattened: () => isConditionallyFlattened,
  isResourceParameterBaseFor: () => isResourceParameterBaseFor,
  listArmResources: () => listArmResources,
  namespace: () => namespace2
});
import { $key, addVisibilityModifiers, clearVisibilityModifiersForClass, getKeyName, getLifecycleVisibilityEnum, getTypeName, sealVisibilityModifiers } from "@typespec/compiler";
import { $segment, getSegment as getSegment2 } from "@typespec/rest";

// src/typespec/node_modules/.pnpm/change-case@5.4.4/node_modules/change-case/dist/index.js
var SPLIT_LOWER_UPPER_RE = /([\p{Ll}\d])(\p{Lu})/gu;
var SPLIT_UPPER_UPPER_RE = /(\p{Lu})([\p{Lu}][\p{Ll}])/gu;
var SPLIT_SEPARATE_NUMBER_RE = /(\d)\p{Ll}|(\p{L})\d/u;
var DEFAULT_STRIP_REGEXP = /[^\p{L}\d]+/giu;
var SPLIT_REPLACE_VALUE = "$1\0$2";
var DEFAULT_PREFIX_SUFFIX_CHARACTERS = "";
function split(value) {
  let result = value.trim();
  result = result.replace(SPLIT_LOWER_UPPER_RE, SPLIT_REPLACE_VALUE).replace(SPLIT_UPPER_UPPER_RE, SPLIT_REPLACE_VALUE);
  result = result.replace(DEFAULT_STRIP_REGEXP, "\0");
  let start = 0;
  let end = result.length;
  while (result.charAt(start) === "\0")
    start++;
  if (start === end)
    return [];
  while (result.charAt(end - 1) === "\0")
    end--;
  return result.slice(start, end).split(/\0/g);
}
function splitSeparateNumbers(value) {
  const words = split(value);
  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const match = SPLIT_SEPARATE_NUMBER_RE.exec(word);
    if (match) {
      const offset = match.index + (match[1] ?? match[2]).length;
      words.splice(i, 1, word.slice(0, offset), word.slice(offset));
    }
  }
  return words;
}
function camelCase(input, options) {
  const [prefix, words, suffix] = splitPrefixSuffix(input, options);
  const lower = lowerFactory(options?.locale);
  const upper = upperFactory(options?.locale);
  const transform = options?.mergeAmbiguousCharacters ? capitalCaseTransformFactory(lower, upper) : pascalCaseTransformFactory(lower, upper);
  return prefix + words.map((word, index) => {
    if (index === 0)
      return lower(word);
    return transform(word, index);
  }).join(options?.delimiter ?? "") + suffix;
}
function lowerFactory(locale) {
  return locale === false ? (input) => input.toLowerCase() : (input) => input.toLocaleLowerCase(locale);
}
function upperFactory(locale) {
  return locale === false ? (input) => input.toUpperCase() : (input) => input.toLocaleUpperCase(locale);
}
function capitalCaseTransformFactory(lower, upper) {
  return (word) => `${upper(word[0])}${lower(word.slice(1))}`;
}
function pascalCaseTransformFactory(lower, upper) {
  return (word, index) => {
    const char0 = word[0];
    const initial = index > 0 && char0 >= "0" && char0 <= "9" ? "_" + char0 : upper(char0);
    return initial + lower(word.slice(1));
  };
}
function splitPrefixSuffix(input, options = {}) {
  const splitFn = options.split ?? (options.separateNumbers ? splitSeparateNumbers : split);
  const prefixCharacters = options.prefixCharacters ?? DEFAULT_PREFIX_SUFFIX_CHARACTERS;
  const suffixCharacters = options.suffixCharacters ?? DEFAULT_PREFIX_SUFFIX_CHARACTERS;
  let prefixIndex = 0;
  let suffixIndex = input.length;
  while (prefixIndex < input.length) {
    const char = input.charAt(prefixIndex);
    if (!prefixCharacters.includes(char))
      break;
    prefixIndex++;
  }
  while (suffixIndex > prefixIndex) {
    const index = suffixIndex - 1;
    const char = input.charAt(index);
    if (!suffixCharacters.includes(char))
      break;
    suffixIndex = index;
  }
  return [
    input.slice(0, prefixIndex),
    splitFn(input.slice(prefixIndex, suffixIndex)),
    input.slice(suffixIndex)
  ];
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/private.decorators.js
var import_pluralize = __toESM(require_pluralize(), 1);
var namespace2 = "Azure.ResourceManager.Private";
var $omitIfEmpty = (context, entity, propertyName) => {
  const modelProp = getProperty(entity, propertyName);
  if (modelProp && modelProp.type.kind === "Model" && !hasProperty(context.program, modelProp.type)) {
    entity.properties.delete(propertyName);
  }
};
var $enforceConstraint = (context, entity, sourceType, constraintType) => {
  if (sourceType !== void 0 && constraintType !== void 0) {
    let baseType = sourceType;
    do {
      if (baseType === constraintType || isCustomAzureResource(context.program, baseType))
        return;
    } while ((baseType = baseType.baseModel) !== void 0);
    reportDiagnostic(context.program, {
      code: "template-type-constraint-no-met",
      target: entity,
      format: {
        entity: entity.name,
        sourceType: sourceType.name,
        constraintType: constraintType.name,
        actionMessage: `Please use the "TrackedResource", "ProxyResource", or "ExtensionResource" template to define the resource.`
      }
    });
  }
};
var $resourceBaseParametersOf = (context, entity, resourceType) => {
  const targetResourceBaseType = getResourceBaseType(context.program, resourceType);
  const removedProperties = [];
  for (const [propertyName, property] of entity.properties) {
    if (!isResourceParameterBaseForInternal(context.program, property, targetResourceBaseType))
      removedProperties.push(propertyName);
  }
  for (const removedProperty of removedProperties) {
    entity.properties.delete(removedProperty);
  }
};
var $resourceParameterBaseFor = (context, entity, values) => {
  const resolvedValues = [];
  for (const value of values.values) {
    if (value.kind !== "EnumMember") {
      return;
    }
    resolvedValues.push(value.name);
  }
  context.program.stateMap(ArmStateKeys.armResourceCollection).set(entity, resolvedValues);
};
var $defaultResourceKeySegmentName = (context, entity, resource, keyName, segment) => {
  const modelName = camelCase(resource.name);
  const pluralName = (0, import_pluralize.default)(modelName);
  if (keyName.length > 0) {
    context.call($key, entity, keyName);
  } else {
    context.call($key, entity, `${modelName}Name`);
  }
  if (segment.length > 0) {
    context.call($segment, entity, segment);
  } else {
    context.call($segment, entity, pluralName);
  }
};
function getResourceParameterBases(program, property) {
  return program.stateMap(ArmStateKeys.armResourceCollection).get(property);
}
function isResourceParameterBaseFor(program, property, resourceBaseType) {
  return isResourceParameterBaseForInternal(program, property, resolveResourceBaseType(resourceBaseType));
}
function isResourceParameterBaseForInternal(program, property, resolvedBaseType) {
  const resourceBases = getResourceParameterBases(program, property);
  if (resourceBases !== void 0) {
    for (const rawType of resourceBases) {
      if (resolveResourceBaseType(rawType) === resolvedBaseType)
        return true;
    }
  }
  return false;
}
var $assignProviderNameValue = (context, target, resourceType) => {
  const { program } = context;
  const armProviderNamespace = getArmProviderNamespace(program, resourceType);
  if (armProviderNamespace) {
    target.type.value = armProviderNamespace;
  }
};
var $armUpdateProviderNamespace = (context, entity) => {
  const { program } = context;
  const operation = entity;
  const opInterface = operation.interface;
  if (opInterface && opInterface.namespace) {
    const armProviderNamespace = getArmProviderNamespace(program, opInterface.namespace);
    if (armProviderNamespace) {
      const providerParam = operation.parameters.properties.get("provider");
      if (providerParam) {
        if (providerParam.type.kind !== "String") {
          reportDiagnostic(program, {
            code: "decorator-param-wrong-type",
            messageId: "armUpdateProviderNamespace",
            target: providerParam
          });
          return;
        }
        providerParam.type.value = armProviderNamespace;
      }
    }
  }
};
function isArmOperationsListInterface(program, type) {
  if (type.name !== "Operations") {
    return false;
  }
  const listOperation = type.operations.get("list");
  if (listOperation) {
    if (getSegment2(program, listOperation) === "operations") {
      return true;
    }
  }
  return false;
}
var $armResourceInternal = (context, resourceType, propertiesType) => {
  const { program } = context;
  if (resourceType.namespace && getTypeName(resourceType.namespace) === "Azure.ResourceManager") {
    return;
  }
  if (!resourceType.namespace || resourceType.namespace.name === "") {
    reportDiagnostic(program, {
      code: "decorator-in-namespace",
      format: { decoratorName: "armResource" },
      target: resourceType
    });
    return;
  }
  const armProviderNamespace = getArmProviderNamespace(program, resourceType.namespace);
  const armLibraryNamespace = isArmLibraryNamespace(program, resourceType.namespace);
  if (!armProviderNamespace && !armLibraryNamespace) {
    reportDiagnostic(program, { code: "arm-resource-missing-arm-namespace", target: resourceType });
    return;
  }
  const nameProperty = resourceType.properties.get("name");
  if (!nameProperty) {
    reportDiagnostic(program, { code: "arm-resource-missing-name-property", target: resourceType });
    return;
  }
  const Lifecycle = getLifecycleVisibilityEnum(program);
  clearVisibilityModifiersForClass(program, nameProperty, Lifecycle, context);
  addVisibilityModifiers(program, nameProperty, [Lifecycle.members.get("Read")], context);
  sealVisibilityModifiers(program, nameProperty, Lifecycle);
  const keyName = getKeyName(program, nameProperty);
  if (!keyName) {
    reportDiagnostic(program, {
      code: "arm-resource-missing-name-key-decorator",
      target: resourceType
    });
    return;
  }
  const collectionName = getSegment2(program, nameProperty);
  if (!collectionName) {
    reportDiagnostic(program, {
      code: "arm-resource-missing-name-segment-decorator",
      target: resourceType
    });
    return;
  }
  let kind = getArmResourceKind(resourceType);
  if (isArmVirtualResource(program, resourceType))
    kind = "Virtual";
  if (isCustomAzureResource(program, resourceType))
    kind = "Custom";
  if (!kind) {
    reportDiagnostic(program, {
      code: "arm-resource-invalid-base-type",
      target: resourceType
    });
    return;
  }
  const armResourceDetails = {
    name: resourceType.name,
    kind,
    typespecType: resourceType,
    collectionName,
    keyName,
    armProviderNamespace: armProviderNamespace ?? "",
    operations: {
      lifecycle: {},
      lists: {},
      actions: {}
    }
  };
  program.stateMap(ArmStateKeys.armResources).set(resourceType, armResourceDetails);
};
function listArmResources(program) {
  return [...program.stateMap(ArmStateKeys.armResources).values()];
}
function getArmResource(program, resourceType) {
  return program.stateMap(ArmStateKeys.armResources).get(resourceType);
}
function getProperty(model, propertyName) {
  let returnProperty = model.properties?.get(propertyName);
  if (!returnProperty && model.baseModel) {
    returnProperty = getProperty(model.baseModel, propertyName);
  }
  return returnProperty;
}
function hasProperty(program, model) {
  if (model.properties.size > 0)
    return true;
  if (model.baseModel)
    return hasProperty(program, model.baseModel);
  return false;
}
var $azureResourceBase = (context, resourceType) => {
  context.program.stateMap(ArmStateKeys.azureResourceBase).set(resourceType, true);
};
function isAzureResource(program, resourceType) {
  const isResourceBase = program.stateMap(ArmStateKeys.azureResourceBase).get(resourceType);
  return isResourceBase ?? false;
}
var $conditionalClientFlatten = (context, entity) => {
  context.program.stateMap(ArmStateKeys.armConditionalClientFlatten).set(entity, true);
};
function isConditionallyFlattened(program, entity) {
  const flatten = program.stateMap(ArmStateKeys.armConditionalClientFlatten).get(entity);
  return flatten ?? false;
}
var $armRenameListByOperation = (context, entity, resourceType, parentTypeName, parentFriendlyTypeName, applyOperationRename) => {
  armRenameListByOperationInternal(context, entity, resourceType, parentTypeName, parentFriendlyTypeName, applyOperationRename);
};
var $armResourcePropertiesOptionality = (context, target, isOptional) => {
  if (target.name === "properties") {
    target.optional = isOptional;
  }
};
var $decorators = {
  "Azure.ResourceManager.Private": {
    resourceBaseParametersOf: $resourceBaseParametersOf,
    resourceParameterBaseFor: $resourceParameterBaseFor,
    azureResourceBase: $azureResourceBase,
    omitIfEmpty: $omitIfEmpty,
    conditionalClientFlatten: $conditionalClientFlatten,
    assignProviderNameValue: $assignProviderNameValue,
    armUpdateProviderNamespace: $armUpdateProviderNamespace,
    armResourceInternal: $armResourceInternal,
    defaultResourceKeySegmentName: $defaultResourceKeySegmentName,
    enforceConstraint: $enforceConstraint,
    armRenameListByOperation: $armRenameListByOperation,
    armResourcePropertiesOptionality: $armResourcePropertiesOptionality
  }
};

// src/typespec/packages/typespec-azure-resource-manager/dist/src/resource.js
var $armVirtualResource = (context, entity) => {
  const { program } = context;
  if (isTemplateDeclaration(entity))
    return;
  program.stateMap(ArmStateKeys.armBuiltInResource).set(entity, "Virtual");
  const pathProperty = getProperty2(entity, (p) => isPathParam(program, p) && getSegment3(program, p) !== void 0);
  if (pathProperty === void 0) {
    reportDiagnostic(program, {
      code: "resource-without-path-and-segment",
      target: entity
    });
    return;
  }
  const collectionName = getSegment3(program, pathProperty);
  const keyName = getKeyName2(program, pathProperty);
  if (collectionName === void 0 || keyName === void 0) {
    reportDiagnostic(program, {
      code: "resource-without-path-and-segment",
      target: entity
    });
    return;
  }
};
var $customAzureResource = (context, entity) => {
  const { program } = context;
  if (isTemplateDeclaration(entity))
    return;
  program.stateMap(ArmStateKeys.customAzureResource).set(entity, "Custom");
};
function getProperty2(target, predicate) {
  for (const prop of getAllProperties(target).values()) {
    if (predicate(prop))
      return prop;
  }
  return void 0;
}
function isArmVirtualResource(program, target) {
  if (program.stateMap(ArmStateKeys.armBuiltInResource).has(target) === true)
    return true;
  if (target.baseModel)
    return isArmVirtualResource(program, target.baseModel);
  return false;
}
function isCustomAzureResource(program, target) {
  if (program.stateMap(ArmStateKeys.customAzureResource).has(target))
    return true;
  if (target.baseModel)
    return isCustomAzureResource(program, target.baseModel);
  return false;
}
function resolveArmResourceDetails(program, resource) {
  const operations = resolveResourceOperations(program, resource.typespecType);
  const itemPath = (operations.lifecycle.read || operations.lifecycle.createOrUpdate)?.path;
  const baseType = getResourceBaseType(program, resource.typespecType);
  const resourceTypePath = getResourceTypePath(resource, itemPath, baseType);
  return {
    ...resource,
    operations,
    resourceTypePath
  };
}
function getResourceTypePath(resource, itemPath, baseType) {
  if (!itemPath) {
    return void 0;
  }
  if (baseType === ResourceBaseType.Tenant || baseType === ResourceBaseType.Extension) {
    return void 0;
  }
  let temporaryPath;
  const index = itemPath.indexOf(resource.collectionName);
  if (index !== -1) {
    const truncatedPath = itemPath.slice(0, index + resource.collectionName.length);
    temporaryPath = truncatedPath;
  } else {
    temporaryPath = itemPath;
  }
  const pattern = /\/resourceGroups\/{[^}]+}/;
  temporaryPath = temporaryPath.replace(pattern, "");
  const pattern1 = /\/{(?!subscriptionId)[^}]+}/;
  return temporaryPath.replace(pattern1, "");
}
function getArmResources(program) {
  const cachedResources = program.stateMap(ArmStateKeys.armResourcesCached);
  if (cachedResources.size > 0) {
    return Array.from(program.stateMap(ArmStateKeys.armResourcesCached).values());
  }
  const resources = [];
  for (const resource of listArmResources(program)) {
    const fullResource = resolveArmResourceDetails(program, resource);
    cachedResources.set(resource.typespecType, fullResource);
    resources.push(fullResource);
  }
  return resources;
}
function getArmResourceInfo(program, resourceType) {
  const resourceInfo = getArmResource(program, resourceType);
  if (!resourceInfo && resourceType.namespace !== void 0 && !isArmLibraryNamespace(program, resourceType.namespace)) {
    reportDiagnostic(program, {
      code: "arm-resource-missing",
      format: { type: resourceType.name },
      target: resourceType
    });
  }
  return resourceInfo;
}
function getArmResourceKind(resourceType) {
  if (resourceType.baseModel) {
    const coreType = resourceType.baseModel;
    if (coreType.name.startsWith("TrackedResource")) {
      return "Tracked";
    } else if (coreType.name.startsWith("ProxyResource")) {
      return "Proxy";
    } else if (coreType.name.startsWith("ExtensionResource")) {
      return "Extension";
    }
  }
  return void 0;
}
var $armResourceOperations = (context, interfaceType) => {
  const { program } = context;
  context.call($autoRoute, interfaceType);
  if (getTags(program, interfaceType).length === 0) {
    context.call($tag, interfaceType, interfaceType.name);
  }
};
var $singleton = (context, resourceType, keyValue = "default") => {
  context.program.stateMap(ArmStateKeys.armSingletonResources).set(resourceType, keyValue);
};
function isSingletonResource(program, resourceType) {
  return program.stateMap(ArmStateKeys.armSingletonResources).has(resourceType);
}
function getSingletonResourceKey(program, resourceType) {
  return program.stateMap(ArmStateKeys.armSingletonResources).get(resourceType);
}
var ResourceBaseType;
(function(ResourceBaseType2) {
  ResourceBaseType2["Tenant"] = "Tenant";
  ResourceBaseType2["Subscription"] = "Subscription";
  ResourceBaseType2["Location"] = "Location";
  ResourceBaseType2["ResourceGroup"] = "ResourceGroup";
  ResourceBaseType2["Extension"] = "Extension";
})(ResourceBaseType || (ResourceBaseType = {}));
var $resourceBaseType = (context, entity, baseType) => {
  let baseTypeString = "";
  if (isNeverType(baseType))
    return;
  if (baseType?.kind === "String")
    baseTypeString = baseType.value;
  setResourceBaseType(context.program, entity, baseTypeString);
};
var $tenantResource = (context, entity) => {
  setResourceBaseType(context.program, entity, "Tenant");
};
var $subscriptionResource = (context, entity) => {
  setResourceBaseType(context.program, entity, "Subscription");
};
var $locationResource = (context, entity) => {
  setResourceBaseType(context.program, entity, "Location");
};
var $resourceGroupResource = (context, entity) => {
  setResourceBaseType(context.program, entity, "ResourceGroup");
};
var $extensionResource = (context, entity) => {
  setResourceBaseType(context.program, entity, "Extension");
};
var $armProviderNameValue = (context, entity) => {
  const armProvider = getServiceNamespace(context.program, entity);
  if (armProvider === void 0)
    return;
  for (const [_, property] of entity.parameters.properties) {
    const segment = getSegment3(context.program, property);
    if (segment === "providers" && property.type.kind === "String")
      property.type.value = armProvider;
  }
};
var $identifiers = (context, entity, properties) => {
  const { program } = context;
  const { type } = entity;
  if (type.kind !== "Model" || !isArrayModelType(program, type) || type.indexer.value.kind !== "Model") {
    reportDiagnostic(program, {
      code: "decorator-param-wrong-type",
      messageId: "armIdentifiersIncorrectEntity",
      target: entity
    });
    return;
  }
  context.program.stateMap(ArmStateKeys.armIdentifiers).set(entity, properties);
};
function getArmIdentifiers(program, entity) {
  return program.stateMap(ArmStateKeys.armIdentifiers).get(entity);
}
function getArmKeyIdentifiers(program, entity) {
  const value = entity.indexer.value;
  const result = [];
  if (value.kind === "Model") {
    for (const property of value.properties.values()) {
      const pathToKey = getPathToKey(program, property);
      if (pathToKey !== void 0) {
        result.push(property.name + pathToKey);
      } else if (getKeyName2(program, property)) {
        result.push(property.name);
      }
    }
    if (!result.includes("id") && compilerGetProperty(value, "id") !== void 0) {
      result.push("id");
    }
  }
  return result.length > 0 ? result : void 0;
}
function getPathToKey(program, entity, visited = /* @__PURE__ */ new Set()) {
  if (entity.type.kind !== "Model") {
    return void 0;
  }
  if (visited.has(entity)) {
    return void 0;
  }
  visited.add(entity);
  for (const property of entity.type.properties.values()) {
    if (property.type.kind !== "Model" && getKeyName2(program, property)) {
      return "/" + property.name;
    }
    if (property.type.kind === "Model") {
      const path = getPathToKey(program, property, visited);
      if (path !== void 0) {
        return "/" + property.name + path;
      }
    }
  }
  return void 0;
}
function getServiceNamespace(program, type) {
  if (type === void 0)
    return void 0;
  switch (type.kind) {
    case "Operation":
      return getServiceNamespace(program, type.namespace) ?? getServiceNamespace(program, type.interface);
    case "Interface":
      return getServiceNamespace(program, type.namespace);
    case "Namespace":
      return getArmProviderNamespace(program, type) ?? (isGlobalNamespace(program, type) ? void 0 : getServiceNamespace(program, type.namespace));
    default:
      return void 0;
  }
}
function setResourceBaseType(program, resource, type) {
  if (program.stateMap(ArmStateKeys.resourceBaseType).has(resource)) {
    reportDiagnostic(program, {
      code: "arm-resource-duplicate-base-parameter",
      target: resource
    });
  }
  program.stateMap(ArmStateKeys.resourceBaseType).set(resource, type);
}
function getResourceBaseType(program, resource) {
  const parentTracker = /* @__PURE__ */ new Set();
  let parent = getParentResource2(program, resource);
  while (parent !== void 0) {
    if (parentTracker.has(parent))
      reportDiagnostic(program, { code: "arm-resource-circular-ancestry", target: resource });
    parentTracker.add(parent);
    resource = parent;
    parent = getParentResource2(program, resource);
  }
  const keyValue = program.stateMap(ArmStateKeys.resourceBaseType).get(resource);
  return resolveResourceBaseType(keyValue);
}
function resolveResourceBaseType(type) {
  let resolvedType = ResourceBaseType.ResourceGroup;
  if (type !== void 0) {
    switch (type) {
      case "Tenant":
        resolvedType = ResourceBaseType.Tenant;
        break;
      case "Subscription":
        resolvedType = ResourceBaseType.Subscription;
        break;
      case "Location":
        resolvedType = ResourceBaseType.Location;
        break;
      case "ResourceGroup":
        resolvedType = ResourceBaseType.ResourceGroup;
        break;
      case "Extension":
        resolvedType = ResourceBaseType.Extension;
        break;
    }
  }
  return resolvedType;
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/namespace.js
function getArmCommonTypesVersion2(context, entity) {
  return entity.decorators.find((x) => x.definition?.name === "@armCommonTypesVersion")?.args[0].jsValue;
}
function setArmCommonTypesVersionIfDoesnotExist(context, entity, commonTypeVersion) {
  const armCommonTypesVersion = entity.decorators.find((x) => x.definition?.name === "@armCommonTypesVersion");
  if (!armCommonTypesVersion) {
    context.call($armCommonTypesVersion, entity, commonTypeVersion);
  }
}
var $armLibraryNamespace = (context, entity) => {
  const { program } = context;
  program.stateMap(ArmStateKeys.armLibraryNamespaces).set(entity, true);
  setArmCommonTypesVersionIfDoesnotExist(context, entity, "v3");
};
function isArmLibraryNamespace(program, namespace4) {
  return program.stateMap(ArmStateKeys.armLibraryNamespaces).get(namespace4) === true;
}
function isArmProviderNamespace(program, namespace4) {
  return namespace4 !== void 0 && program.stateMap(ArmStateKeys.armProviderNamespaces).has(namespace4);
}
function isArmNamespaceOverride(program, entity) {
  return program.stateMap(ArmStateKeys.armProviderNamespaces).size === 1 && program.stateMap(ArmStateKeys.armProviderNamespaces).has(entity);
}
var $useLibraryNamespace = (context, entity, ...namespaces) => {
  const { program } = context;
  const provider = program.stateMap(ArmStateKeys.armProviderNamespaces).get(entity);
  if (provider) {
    setLibraryNamespaceProvider(program, provider, namespaces);
  }
  program.stateMap(ArmStateKeys.usesArmLibraryNamespaces).set(entity, namespaces);
};
function getUsedLibraryNamespaces(program, namespace4) {
  return program.stateMap(ArmStateKeys.usesArmLibraryNamespaces).get(namespace4);
}
function setLibraryNamespaceProvider(program, provider, namespaces) {
  for (const namespace4 of namespaces) {
    program.stateMap(ArmStateKeys.armProviderNamespaces).set(namespace4, provider);
  }
}
var $armProviderNamespace = (context, entity, armProviderNamespace) => {
  const { program } = context;
  const inRealm = unsafe_Realm.realmForType.has(entity);
  const override = isArmNamespaceOverride(program, entity);
  const namespaceCount = program.stateMap(ArmStateKeys.armProviderNamespaces).size;
  if (namespaceCount > 0 && !override && !inRealm) {
    reportDiagnostic(program, {
      code: "single-arm-provider",
      target: context.decoratorTarget
    });
    return;
  }
  if (!override || inRealm) {
    addService(program, entity);
    if (!http.getServers(program, entity)) {
      context.call(http.$server, entity, "https://management.azure.com", "Azure Resource Manager url.");
    }
  }
  const armCommonTypesVersion = getArmCommonTypesVersion2(context, entity);
  const versioned = entity.decorators.find((x) => x.definition?.name === "@versioned");
  if (versioned) {
    const versionEnum = versioned.args[0].value;
    versionEnum.members.forEach((v) => {
      if (!getArmCommonTypesVersion2(context, v)) {
        context.call($armCommonTypesVersion, v, armCommonTypesVersion ?? "v3");
      }
    });
  } else {
    if (!armCommonTypesVersion) {
      context.call($armCommonTypesVersion, entity, "v3");
    }
  }
  const typespecNamespace = getNamespaceFullName(entity);
  if (!armProviderNamespace) {
    armProviderNamespace = typespecNamespace;
  }
  program.stateMap(ArmStateKeys.armProviderNamespaces).set(entity, armProviderNamespace);
  const libraryNamespace = getUsedLibraryNamespaces(program, entity);
  if (libraryNamespace) {
    setLibraryNamespaceProvider(program, armProviderNamespace, libraryNamespace);
  }
  if (!override) {
    if (getAuthentication(program, entity) === void 0) {
      setAuthentication(program, entity, {
        options: [
          {
            schemes: [
              {
                id: "azure_auth",
                description: "Azure Active Directory OAuth2 Flow.",
                type: "oauth2",
                model: null,
                flows: [
                  {
                    type: "implicit",
                    authorizationUrl: "https://login.microsoftonline.com/common/oauth2/authorize",
                    scopes: [
                      { value: "user_impersonation", description: "impersonate your user account" }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      });
    }
    setRouteOptionsForNamespace(program, entity, {
      autoRouteOptions: {
        // Filter key parameters for singleton resource types to insert the
        // singleton key value
        routeParamFilter: (operation, param) => {
          const paramResourceType = getResourceTypeForKeyParam(program, param);
          if (paramResourceType) {
            const singletonKey = getSingletonResourceKey(program, paramResourceType);
            if (singletonKey) {
              return {
                routeParamString: singletonKey,
                excludeFromOperationParams: true
              };
            }
          }
          return void 0;
        }
      }
    });
  }
};
function getArmProviderNamespace(program, entity) {
  let currentNamespace = entity.kind === "Namespace" ? entity : entity.namespace;
  let armProviderNamespace;
  while (currentNamespace) {
    armProviderNamespace = program.stateMap(ArmStateKeys.armProviderNamespaces).get(currentNamespace);
    if (armProviderNamespace) {
      return armProviderNamespace;
    }
    currentNamespace = currentNamespace.namespace;
  }
  return void 0;
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/linter.js
import { defineLinter } from "@typespec/compiler";

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-common-types-version.js
import { createRule } from "@typespec/compiler";
import { getAllHttpServices } from "@typespec/http";
import { getVersion as getVersion2 } from "@typespec/versioning";
var armCommonTypesVersionRule = createRule({
  name: "arm-common-types-version",
  severity: "warning",
  description: "Specify the ARM common-types version using @armCommonTypesVersion.",
  messages: {
    default: "Specify the ARM common-types version using the @armCommonTypesVersion decorator on the service namespace or on each version of the service version enum."
  },
  create(context) {
    return {
      root: (program) => {
        const [services, _] = getAllHttpServices(program);
        for (const service of services) {
          if (!getArmProviderNamespace(program, service.namespace)) {
            continue;
          }
          const versionMap = getVersion2(program, service.namespace);
          if (!(versionMap && versionMap.getVersions().every((version) => !!version.enumMember.decorators.find((x) => x.definition?.name === "@armCommonTypesVersion"))) && !service.namespace.decorators.find((x) => x.definition?.name === "@armCommonTypesVersion")) {
            context.reportDiagnostic({
              target: service.namespace
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-custom-resource-usage-discourage.js
import { createRule as createRule2 } from "@typespec/compiler";
var armCustomResourceUsageDiscourage = createRule2({
  name: "arm-custom-resource-usage-discourage",
  severity: "warning",
  description: "Verify the usage of @customAzureResource decorator.",
  messages: {
    default: `Avoid using the @customAzureResource decorator. It doesn't provide validation for ARM resources, and its usage should be limited to brownfield services migration.`
  },
  create(context) {
    return {
      model: (model) => {
        if (isCustomAzureResource(context.program, model)) {
          context.reportDiagnostic({
            code: "arm-custom-resource-usage-discourage",
            target: model
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-delete-response-codes.js
import { createRule as createRule3 } from "@typespec/compiler";
import { getLroMetadata } from "@azure-tools/typespec-azure-core";
var armDeleteResponseCodesRule = createRule3({
  name: "arm-delete-operation-response-codes",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/delete-operation-response-codes",
  description: "Ensure delete operations have the appropriate status codes.",
  messages: {
    sync: `Synchronous delete operations must have 200, 204 and default responses. They must not have any other responses. Consider using the 'ArmResourceDeleteSync' template.`,
    async: `Long-running delete operations must have 202, 204 and default responses. They must not have any other responses. Consider using the 'ArmResourceDeleteWithoutOkAsync' template.`
  },
  create(context) {
    return {
      root: (program) => {
        const resources = getArmResources(program);
        for (const resource of resources) {
          if (resource.operations.lifecycle.delete) {
            const deleteOperation = resource.operations.lifecycle.delete;
            const isAsync = getLroMetadata(context.program, deleteOperation.operation) !== void 0;
            const httpOp = deleteOperation.httpOperation;
            const statusCodes = /* @__PURE__ */ new Set([...httpOp.responses.map((r) => r.statusCodes.toString())]);
            const expected = /* @__PURE__ */ new Set(["204", "*"]);
            expected.add(isAsync ? "202" : "200");
            if (statusCodes.size !== expected.size || ![...statusCodes].every((v) => expected.has(v))) {
              context.reportDiagnostic({
                target: deleteOperation.operation,
                messageId: isAsync ? "async" : "sync"
              });
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-no-record.js
import { createRule as createRule4 } from "@typespec/compiler";
var armNoRecordRule = createRule4({
  name: "arm-no-record",
  severity: "warning",
  description: "Don't use Record types for ARM resources.",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/arm-no-record",
  messages: {
    default: "Model properties or operation parameters should not be of type Record. ARM requires Resource provider teams to define types explicitly.",
    extends: "Models should not extend type Record. ARM requires Resource provider teams to define types explicitly.",
    is: "Models should not equate to type Record. ARM requires Resource provider teams to define types explicitly."
  },
  create(context) {
    function checkModel(model) {
      if (model.baseModel !== void 0) {
        checkNoRecord(model.baseModel, model, "extends");
      } else if (model.sourceModel !== void 0) {
        checkNoRecord(model.sourceModel, model, "is");
      }
    }
    function checkNoRecord(type, target, kind) {
      if (type.kind === "Model" && type.name === "Record") {
        context.reportDiagnostic({
          code: "arm-no-record",
          target,
          messageId: kind || "default"
        });
      }
    }
    return {
      operation: (op) => checkNoRecord(op.returnType, op),
      model: (type) => checkModel(type),
      modelProperty: (prop) => checkNoRecord(prop.type, prop),
      unionVariant: (variant) => checkNoRecord(variant.type, variant)
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-post-response-codes.js
import { createRule as createRule5 } from "@typespec/compiler";
import { getLroMetadata as getLroMetadata2 } from "@azure-tools/typespec-azure-core";
var armPostResponseCodesRule = createRule5({
  name: "arm-post-operation-response-codes",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/post-operation-response-codes",
  description: "Ensure post operations have the appropriate status codes.",
  messages: {
    sync: `Synchronous post operations must have a 200 or 204 response and a default response. They must not have any other responses.`,
    async: `Long-running post operations must have 202 and default responses. They must also have a 200 response if the final response has a schema. They must not have any other responses.`
  },
  create(context) {
    function getResponseBody(response) {
      if (response === void 0)
        return void 0;
      if (response.responses.length > 1) {
        throw new Error("Multiple responses are not supported.");
      }
      if (response.responses[0].body !== void 0) {
        return response.responses[0].body;
      }
      return void 0;
    }
    function validateAsyncPost(op) {
      const statusCodes = /* @__PURE__ */ new Set([
        ...op.httpOperation.responses.map((r) => r.statusCodes.toString())
      ]);
      const expected = statusCodes.size === 2 ? /* @__PURE__ */ new Set(["202", "*"]) : /* @__PURE__ */ new Set(["202", "200", "*"]);
      if (statusCodes.size !== expected.size || ![...statusCodes].every((v) => expected.has(v))) {
        context.reportDiagnostic({
          target: op.operation,
          messageId: "async"
        });
      }
      const response202 = op.httpOperation.responses.find((r) => r.statusCodes === 202);
      const body202 = getResponseBody(response202);
      if (body202 !== void 0) {
        context.reportDiagnostic({
          target: op.operation.returnType,
          messageId: "async"
        });
      }
      const response200 = op.httpOperation.responses.find((r) => r.statusCodes === 200);
      const body200 = getResponseBody(response200);
      if (response200 && body200 === void 0) {
        context.reportDiagnostic({
          target: op.operation.returnType,
          messageId: "async"
        });
      }
    }
    function validateSyncPost(op) {
      const allowed = [/* @__PURE__ */ new Set(["200", "*"]), /* @__PURE__ */ new Set(["204", "*"])];
      const statusCodes = /* @__PURE__ */ new Set([
        ...op.httpOperation.responses.map((r) => r.statusCodes.toString())
      ]);
      if (!allowed.some((expected) => statusCodes.size === expected.size && [...statusCodes].every((v) => expected.has(v)))) {
        context.reportDiagnostic({
          target: op.operation,
          messageId: "sync"
        });
      }
    }
    return {
      root: (program) => {
        const resources = getArmResources(program);
        for (const resource of resources) {
          const operations = [
            resource.operations.lifecycle.createOrUpdate,
            resource.operations.lifecycle.update,
            ...Object.values(resource.operations.actions)
          ];
          for (const op of operations) {
            if (op === void 0 || op.httpOperation.verb !== "post") {
              continue;
            }
            const isAsync = getLroMetadata2(context.program, op.operation) !== void 0;
            if (isAsync) {
              validateAsyncPost(op);
            } else {
              validateSyncPost(op);
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-put-response-codes.js
import { createRule as createRule6 } from "@typespec/compiler";
var armPutResponseCodesRule = createRule6({
  name: "arm-put-operation-response-codes",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/put-operation-response-codes",
  description: "Ensure put operations have the appropriate status codes.",
  messages: {
    default: `Put operations must have 200, 201 and default responses. They must not have any other responses.`
  },
  create(context) {
    return {
      root: (program) => {
        const resources = getArmResources(program);
        const expected = /* @__PURE__ */ new Set(["200", "201", "*"]);
        for (const resource of resources) {
          const operations = [
            resource.operations.lifecycle.createOrUpdate,
            resource.operations.lifecycle.update,
            ...Object.values(resource.operations.actions)
          ];
          for (const op of operations) {
            if (op === void 0) {
              continue;
            }
            if (op.httpOperation.verb === "put") {
              const statusCodes = /* @__PURE__ */ new Set([
                ...op.httpOperation.responses.map((r) => r.statusCodes.toString())
              ]);
              if (statusCodes.size !== expected.size || ![...statusCodes].every((v) => expected.has(v))) {
                context.reportDiagnostic({
                  target: op.operation
                });
              }
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-action-no-segment.js
import { createRule as createRule7 } from "@typespec/compiler";

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/utils.js
import { getNamespaceFullName as getNamespaceFullName2, isTemplateDeclaration as isTemplateDeclaration2 } from "@typespec/compiler";
import { SyntaxKind } from "@typespec/compiler/ast";
import { getResourceOperation } from "@typespec/rest";
function isTemplatedInterfaceOperation(target) {
  return target.node?.kind === SyntaxKind.OperationStatement && target.interface && isTemplateDeclaration2(target.interface);
}
function isTrackedResource(resourceType) {
  const resultKind = getArmResourceKind(resourceType);
  return resultKind === "Tracked";
}
function isResource(resourceType) {
  const resultKind = getArmResourceKind(resourceType);
  return !!resultKind;
}
function getProperties(model) {
  let properties = Array.from(model.properties.values());
  while (model.baseModel) {
    properties = properties.concat(Array.from(model.baseModel.properties.values()));
    model = model.baseModel;
  }
  return properties;
}
function getInterface(res) {
  if (res.operations.lifecycle) {
    for (const op of Object.values(res.operations.lifecycle)) {
      const armOperation = op;
      if (armOperation && armOperation.operation.interface) {
        return armOperation.operation.interface;
      }
    }
  }
  return void 0;
}
function getSourceModel(property) {
  let currProperty = property;
  while (currProperty.sourceProperty !== void 0) {
    currProperty = currProperty.sourceProperty;
  }
  return currProperty?.model;
}
function getSourceProperty(property) {
  let currProperty = property;
  while (currProperty.sourceProperty !== void 0) {
    currProperty = currProperty.sourceProperty;
  }
  return currProperty ?? property;
}
function isInternalTypeSpec(program, type) {
  const namespace4 = getNamespaceName(program, type);
  return namespace4.startsWith("TypeSpec") || namespace4.startsWith("Azure.ResourceManager") || namespace4.startsWith("Azure.Core");
}
function isSourceOperationResourceManagerInternal(operation) {
  if (!operation?.sourceOperation?.namespace) {
    return false;
  }
  const namespace4 = getNamespaceFullName2(operation.sourceOperation.namespace);
  return namespace4.startsWith("Azure.ResourceManager");
}
function getNamespaceName(program, type) {
  if (type === void 0)
    return "";
  if (type.kind === "ModelProperty")
    return type.model ? getNamespaceName(program, type.model) : "";
  if (type.kind !== "Namespace")
    type = type.namespace;
  if (type === void 0)
    return "";
  return getNamespaceFullName2(type);
}
function isValidKey(key) {
  const match = key.match(/^[a-z][a-zA-Z0-9-]+$/);
  return match !== void 0 && match !== null && match.length === 1;
}
function getDecorator(type, name) {
  const decorator = type.decorators.filter((d) => `$${"name"}` === d.decorator.name);
  if (decorator && decorator.length === 1)
    return decorator[0];
  return void 0;
}
function getDecoratorParam(type, name) {
  const call = getDecorator(type, name);
  if (call === void 0)
    return void 0;
  if (call.args && call.args.length > 2)
    return call.args[2];
  return void 0;
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-action-no-segment.js
var armResourceActionNoSegmentRule = createRule7({
  name: "arm-resource-action-no-segment",
  severity: "warning",
  description: "`@armResourceAction` should not be used with `@segment`.",
  messages: {
    default: "`@armResourceAction` should not be used with `@segment`. Instead, use `@action(...)` if you need to rename the action, or omit."
  },
  create(context) {
    return {
      operation: (operation) => {
        if (isInternalTypeSpec(context.program, operation)) {
          return;
        }
        const armResourceActionDec = getDecorator2(operation, "armResourceAction");
        const segmentDec = getDecorator2(operation, "segment");
        if (armResourceActionDec && segmentDec) {
          context.reportDiagnostic({
            target: segmentDec.node ?? operation
          });
        }
      }
    };
  }
});
function getDecorator2(type, name) {
  const decorator = type.decorators.filter((d) => `$${name}` === d.decorator.name);
  if (decorator && decorator.length === 1)
    return decorator[0];
  return void 0;
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-duplicate-property.js
import { createRule as createRule8, getProperty as getProperty3, paramMessage as paramMessage2 } from "@typespec/compiler";
var armResourceDuplicatePropertiesRule = createRule8({
  name: "arm-resource-duplicate-property",
  severity: "warning",
  description: "Warn about duplicate properties in resources.",
  messages: {
    default: paramMessage2`Duplicate property "${"propertyName"}" found in the resource envelope and resource properties.  Please do not duplicate envelope properties in resource properties.`
  },
  create(context) {
    return {
      model: (model) => {
        const resourceModel = getArmResource(context.program, model);
        const reportedDup = /* @__PURE__ */ new Set();
        if (resourceModel !== void 0) {
          const resourceProperties = getProperty3(model, "properties")?.type;
          for (const property of getProperties2(model)) {
            if (resourceProperties !== void 0 && resourceProperties.kind === "Model") {
              const targetProperty = getProperty3(resourceProperties, property.name);
              if (targetProperty !== void 0 && !reportedDup.has(property.name)) {
                context.reportDiagnostic({
                  format: { propertyName: property.name },
                  target: targetProperty
                });
                reportedDup.add(property.name);
              }
            }
          }
        }
      }
    };
    function getProperties2(model) {
      const result = [];
      let current = model;
      while (current !== void 0) {
        if (current.properties.size > 0)
          result.push(...current.properties.values());
        current = current.baseModel;
      }
      return result;
    }
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-interfaces.js
import { createRule as createRule9 } from "@typespec/compiler";
var interfacesRule = createRule9({
  name: "arm-resource-interface-requires-decorator",
  severity: "warning",
  description: "Each resource interface must have an @armResourceOperations decorator.",
  messages: {
    default: "Each resource interface must have an @armResourceOperations decorator."
  },
  create(context) {
    return {
      interface: (interfaceContext) => {
        if (!isInternalTypeSpec(context.program, interfaceContext) && !isArmOperationsListInterface(context.program, interfaceContext)) {
          if (!interfaceContext.decorators.some((d) => d.decorator.name === "$armResourceOperations")) {
            context.reportDiagnostic({
              target: interfaceContext
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-invalid-action-verb.js
import { createRule as createRule10 } from "@typespec/compiler";
import { getOperationVerb } from "@typespec/http";
import { getActionDetails } from "@typespec/rest";
var armResourceInvalidActionVerbRule = createRule10({
  name: "arm-resource-invalid-action-verb",
  severity: "warning",
  description: "Actions must be HTTP Post or Get operations.",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/arm-resource-invalid-action-verb",
  messages: {
    default: "Actions must be HTTP Post or Get operations."
  },
  create(context) {
    return {
      operation: (operation) => {
        if (!isSourceOperationResourceManagerInternal(operation)) {
          const actionType = getActionDetails(context.program, operation);
          const verb = getOperationVerb(context.program, operation);
          if (actionType !== void 0 && verb !== "post" && verb !== "get") {
            context.reportDiagnostic({
              target: operation
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-invalid-envelope-property.js
import { createRule as createRule11, paramMessage as paramMessage3 } from "@typespec/compiler";
var armResourceEnvelopeProperties = createRule11({
  name: "arm-resource-invalid-envelope-property",
  severity: "warning",
  description: "Check for invalid resource envelope properties.",
  messages: {
    default: paramMessage3`Property "${"propertyName"}" is not valid in the resource envelope.  Please remove this property, or add it to the resource-specific property bag.`
  },
  create(context) {
    return {
      model: (model) => {
        const resourceModel = getArmResource(context.program, model);
        if (resourceModel !== void 0) {
          for (const property of getProperties2(model)) {
            if (property.name !== "name") {
              const sourceModel = getSourceModel(property);
              const sourceNamespace = getNamespaceName(context.program, sourceModel);
              if (sourceModel === void 0 || sourceNamespace === void 0 || !sourceNamespace.startsWith("Azure.ResourceManager")) {
                context.reportDiagnostic({
                  format: { propertyName: property.name },
                  target: property
                });
              }
            }
          }
        }
      }
    };
    function getProperties2(model) {
      const result = [];
      let current = model;
      while (current !== void 0) {
        if (current.properties.size > 0)
          result.push(...current.properties.values());
        current = current.baseModel;
      }
      return result;
    }
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-invalid-version-format.js
import { createRule as createRule12, paramMessage as paramMessage4 } from "@typespec/compiler";
import { getVersion as getVersion3 } from "@typespec/versioning";
var armResourceInvalidVersionFormatRule = createRule12({
  name: "arm-resource-invalid-version-format",
  severity: "warning",
  description: "Check for valid versions.",
  messages: {
    default: paramMessage4`The version '${"version"}' is invalid. Versions for arm resources must be of the form "YYYY-MM-DD" and may have a suffix, like "-preview" or a versioned suffix,  "-alpha.1".`,
    invalidType: paramMessage4`The versions for Azure Resource Manager Services must use strings of the form "YYYY-MM-DD[-suffix]."`
  },
  create(context) {
    return {
      namespace: (namespace4) => {
        if (isInternalTypeSpec(context.program, namespace4)) {
          return;
        }
        const map = getVersion3(context.program, namespace4);
        if (map !== void 0) {
          for (const version of map.getVersions()) {
            const versionValue = version.enumMember.value ?? version.enumMember.name;
            switch (typeof versionValue) {
              case "number":
              case "undefined":
                context.reportDiagnostic({
                  messageId: "invalidType",
                  format: { version: versionValue },
                  target: version.enumMember
                });
                break;
              case "string":
                const versionMatch = versionValue.match(/^[\d]{4}-[\d]{2}-[\d]{2}(-[\w]+(\.\d+)?)?$/);
                if (versionMatch === void 0 || versionMatch === null || versionMatch.length < 1) {
                  context.reportDiagnostic({
                    format: { version: versionValue },
                    target: version.enumMember
                  });
                }
                break;
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-key-invalid-chars.js
import { createRule as createRule13, getKeyName as getKeyName3, paramMessage as paramMessage5 } from "@typespec/compiler";
var armResourceKeyInvalidCharsRule = createRule13({
  name: "arm-resource-key-invalid-chars",
  severity: "warning",
  description: "Arm resource key must contain only alphanumeric characters.",
  messages: {
    default: paramMessage5`'${"key"}' is an invalid path parameter name. Parameters must consist of alphanumeric characters starting with a lower case letter.`
  },
  create(context) {
    return {
      model: (model) => {
        if (!isInternalTypeSpec(context.program, model) && isResource(model) && model.properties.has("name")) {
          const nameProperty = model.properties.get("name");
          const key = getKeyName3(context.program, nameProperty);
          if (key !== void 0 && !isValidKey(key)) {
            context.reportDiagnostic({
              format: { key },
              target: getDecoratorParam(nameProperty, "key")?.node ?? nameProperty
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-name-pattern.js
import { createRule as createRule14, defineCodeFix, getPattern, getSourceLocation } from "@typespec/compiler";
function createPatternCodeFix(diagnosticTarget) {
  return defineCodeFix({
    id: "add-pattern-decorator",
    label: "Add `@pattern` decorator to the resource name property with the default ARM pattern.",
    fix: (context) => {
      const location = getSourceLocation(diagnosticTarget);
      const { lineStart, indent } = findLineStartAndIndent(location);
      const updatedLocation = { ...location, pos: lineStart };
      return context.prependText(updatedLocation, `${indent}@pattern("^[a-zA-Z0-9-]{3,24}$")
`);
    }
  });
}
function findLineStartAndIndent(location) {
  const text = location.file.text;
  let pos = location.pos;
  let indent = 0;
  while (pos > 0 && text[pos - 1] !== "\n") {
    if ([" ", "	", "\n"].includes(text[pos - 1])) {
      indent++;
    } else {
      indent = 0;
    }
    pos--;
  }
  return { lineStart: pos, indent: location.file.text.slice(pos, pos + indent) };
}
var armResourceNamePatternRule = createRule14({
  name: "arm-resource-name-pattern",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/resource-name-pattern",
  description: "The resource name parameter should be defined with a 'pattern' restriction.",
  messages: {
    default: `The resource name parameter should be defined with a 'pattern' restriction.  Please use 'ResourceNameParameter' to specify the name parameter with options to override default pattern RegEx expression.`
  },
  create(context) {
    return {
      root: (program) => {
        const resources = getArmResources(program);
        for (const resource of resources) {
          const nameProperty = resource.typespecType.properties.get("name");
          if (nameProperty !== void 0) {
            if (!hasPattern(program, nameProperty)) {
              context.reportDiagnostic({
                target: nameProperty,
                codefixes: [createPatternCodeFix(nameProperty)]
              });
            }
          }
        }
      }
    };
  }
});
function hasPattern(program, property) {
  const pattern = getPattern(program, property);
  if (pattern !== void 0) {
    return true;
  }
  if (property.type.kind === "Scalar") {
    const pattern2 = getPattern(program, property.type);
    if (pattern2 !== void 0) {
      return true;
    }
  }
  return false;
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-operation-response.js
import { createRule as createRule15, getEffectiveModelType, isErrorType, isType } from "@typespec/compiler";
var armResourceOperationsRule = createRule15({
  name: "arm-resource-operation-response",
  severity: "warning",
  description: "[RPC 008]: PUT, GET, PATCH & LIST must return the same resource schema.",
  messages: {
    default: "[RPC 008]: PUT, GET, PATCH & LIST must return the same resource schema."
  },
  create(context) {
    return {
      model: (model) => {
        if (!isInternalTypeSpec(context.program, model)) {
          const armResource = getArmResource(context.program, model);
          if (armResource) {
            const resourceOperations = resolveResourceOperations(context.program, model);
            const kinds = ["read", "createOrUpdate", "update"];
            kinds.map((k) => resourceOperations.lifecycle[k]).forEach((op) => op && checkArmResourceOperationReturnType(context, model, op.operation));
            const lists = resourceOperations.lists;
            for (const key in lists) {
              checkArmResourceOperationReturnType(context, model, lists[key].operation);
            }
          }
        }
      }
    };
  }
});
function checkArmResourceOperationReturnType(context, model, operation) {
  if (!isInternalTypeSpec(context.program, operation)) {
    const returnType = operation.returnType;
    if (returnType.kind === "Model") {
      checkIfArmModel(context, operation, model, returnType);
    } else if (returnType.kind === "Union") {
      for (const variant of returnType.variants.values()) {
        if (!isErrorType(variant.type) && variant.type.kind === "Model") {
          const modelCandidate = getEffectiveModelType(context.program, variant.type);
          checkIfArmModel(context, operation, model, modelCandidate);
          if (modelCandidate.templateMapper !== void 0) {
            for (const arg of modelCandidate.templateMapper.args) {
              if (isType(arg) && arg.kind === "Model") {
                checkIfArmModel(context, operation, model, arg);
                if (arg.templateMapper !== void 0) {
                  for (const type of arg.templateMapper.args) {
                    if (isType(type) && type.kind === "Model") {
                      checkIfArmModel(context, operation, model, type);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
function checkIfArmModel(context, operation, model, modelCandidate) {
  if (getArmResource(context.program, modelCandidate) && modelCandidate !== model) {
    context.reportDiagnostic({
      target: operation
    });
  }
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-patch.js
import { createRule as createRule16, getEffectiveModelType as getEffectiveModelType2, getProperty as getProperty4, isErrorType as isErrorType2, isType as isType2, paramMessage as paramMessage6 } from "@typespec/compiler";
import { getOperationVerb as getOperationVerb2, isBody, isBodyRoot, isHeader, isPathParam as isPathParam2, isQueryParam } from "@typespec/http";
var patchOperationsRule = createRule16({
  name: "arm-resource-patch",
  severity: "warning",
  description: "Validate ARM PATCH operations.",
  messages: {
    default: "The request body of a PATCH must be a model with a subset of resource properties",
    missingTags: "Resource PATCH must contain the 'tags' property.",
    modelSuperset: paramMessage6`Resource PATCH models must be a subset of the resource type. The following properties: [${"name"}] do not exist in resource Model '${"resourceModel"}'.`
  },
  create(context) {
    return {
      operation: (operation) => {
        if (!isInternalTypeSpec(context.program, operation)) {
          const verb = getOperationVerb2(context.program, operation);
          if (verb === "patch") {
            const resourceType = getResourceModel(context.program, operation);
            if (resourceType) {
              checkPatchModel(context, operation, resourceType);
            }
          }
        }
      }
    };
  }
});
function checkPatchModel(context, operation, resourceType) {
  const patchModel = getPatchModel(context.program, operation);
  if (patchModel === void 0) {
    context.reportDiagnostic({
      target: operation
    });
  } else if (resourceType.properties.has("tags") && !patchModel.some((p) => p.name === "tags" && p.type.kind === "Model")) {
    context.reportDiagnostic({
      messageId: "missingTags",
      target: operation
    });
  } else {
    const resourceProperties = resourceType.properties.get("properties");
    const badProperties = [];
    for (const property of patchModel) {
      const sourceModel = getSourceModel(property);
      if (sourceModel === void 0 || !getArmResource(context.program, sourceModel)) {
        if (!getProperty4(resourceType, property.name) && (resourceProperties === void 0 || resourceProperties.type.kind !== "Model" || !getProperty4(resourceProperties.type, property.name))) {
          badProperties.push(property);
        }
      }
    }
    if (badProperties.length > 0)
      context.reportDiagnostic({
        messageId: "modelSuperset",
        format: {
          name: badProperties.flatMap((t) => t.name).join(", "),
          resourceModel: resourceType.name
        },
        target: operation
      });
  }
}
function getResourceModel(program, operation) {
  const returnType = operation.returnType;
  if (returnType.kind === "Union") {
    for (const variant of returnType.variants.values()) {
      if (!isErrorType2(variant.type) && variant.type.kind === "Model") {
        const modelCandidate = getEffectiveModelType2(program, variant.type);
        if (getArmResource(program, modelCandidate)) {
          return modelCandidate;
        }
        if (modelCandidate.templateMapper !== void 0) {
          for (const arg of modelCandidate.templateMapper.args) {
            if (isType2(arg) && arg.kind === "Model" && getArmResource(program, arg)) {
              return arg;
            }
          }
        }
      }
    }
  }
  return void 0;
}
function getPatchModel(program, operation) {
  const bodyProperties = [];
  const patchModel = getEffectiveModelType2(program, operation.parameters);
  for (const [_, property] of patchModel.properties) {
    if (isHeader(program, property) || isQueryParam(program, property) || isPathParam2(program, property))
      continue;
    if ((isBody(program, property) || isBodyRoot(program, property)) && property.type.kind === "Scalar")
      return void 0;
    bodyProperties.push(property);
  }
  if (bodyProperties.length === 0)
    return void 0;
  if (bodyProperties.length === 1 && bodyProperties[0].type.kind === "Model")
    return [...bodyProperties[0].type.properties.values()];
  return bodyProperties;
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-path-invalid-chars.js
import { createRule as createRule17, paramMessage as paramMessage7 } from "@typespec/compiler";
import { getSegment as getSegment4 } from "@typespec/rest";
var armResourcePathInvalidCharsRule = createRule17({
  name: "arm-resource-path-segment-invalid-chars",
  severity: "warning",
  description: "Arm resource name must contain only alphanumeric characters.",
  messages: {
    default: paramMessage7`'${"segment"}' is an invalid path segment. Segments may start with a separator must consist of alphanumeric characters or dashes, starting with a lower case letter.`
  },
  create(context) {
    return {
      model: (model) => {
        if (!isInternalTypeSpec(context.program, model) && isResource(model) && model.properties.has("name")) {
          const nameProperty = model.properties.get("name");
          const separator = "/";
          const segment = getSegment4(context.program, nameProperty);
          if (segment !== void 0 && !isValidPathSegment(segment, separator)) {
            context.reportDiagnostic({
              format: { segment },
              target: getDecoratorParam(nameProperty, "segment")?.node ?? nameProperty
            });
          }
        }
      }
    };
  }
});
function isValidPathSegment(path, separator) {
  if (path.startsWith(separator))
    path = path.replace(separator, "");
  return isValidKey(path);
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/arm-resource-provisioning-state-rule.js
import { createRule as createRule18, getProperty as getProperty5, paramMessage as paramMessage8 } from "@typespec/compiler";
import { getUnionAsEnum } from "@azure-tools/typespec-azure-core";
import { isReadonlyProperty } from "@typespec/openapi";
var armResourceProvisioningStateRule = createRule18({
  name: "arm-resource-provisioning-state",
  severity: "warning",
  description: "Check for properly configured provisioningState property.",
  messages: {
    default: "The RP-specific property model in the 'properties' property of this resource must contain a 'provisioningState property.  The property type should be an enum or a union of string values, and it must specify known state values 'Succeeded', 'Failed', and 'Canceled'.",
    missingValues: paramMessage8`provisioningState, must reference an enum with 'Succeeded', 'Failed', 'Canceled' values. The enum is missing the values: [${"missingValues"}].`,
    missingReadOnlyVisibility: "The provisioningState property must have a single read visibility.",
    mustBeOptional: "The provisioningState property must be optional."
  },
  create(context) {
    return {
      model: (model) => {
        const resourceModel = getArmResource(context.program, model);
        if (resourceModel === void 0) {
          return;
        }
        const resourceProperties = getProperty5(model, "properties")?.type;
        if (resourceProperties === void 0 || resourceProperties.kind !== "Model") {
          return;
        }
        let provisioning = getProperty5(resourceProperties, "provisioningState");
        if (provisioning === void 0) {
          context.reportDiagnostic({
            target: resourceProperties
          });
        } else {
          provisioning = getSourceProperty(provisioning);
          const provisioningType = provisioning.type;
          switch (provisioningType.kind) {
            case "Enum": {
              const enumType = provisioningType;
              const missing = [];
              if (!enumType.members.get("Succeeded")) {
                missing.push("Succeeded");
              }
              if (!enumType.members.get("Canceled")) {
                missing.push("Canceled");
              }
              if (!enumType.members.get("Failed")) {
                missing.push("Failed");
              }
              if (missing.length > 0) {
                context.reportDiagnostic({
                  messageId: "missingValues",
                  format: { missingValues: missing.join(", ") },
                  target: enumType
                });
              }
              break;
            }
            case "Union": {
              const [unionAsEnum] = getUnionAsEnum(provisioningType);
              if (unionAsEnum === void 0) {
                context.reportDiagnostic({
                  target: resourceProperties
                });
                break;
              }
              const missing = [];
              if (!unionAsEnum.flattenedMembers.get("Succeeded")) {
                missing.push("Succeeded");
              }
              if (!unionAsEnum.flattenedMembers.get("Canceled")) {
                missing.push("Canceled");
              }
              if (!unionAsEnum.flattenedMembers.get("Failed")) {
                missing.push("Failed");
              }
              if (missing.length > 0) {
                context.reportDiagnostic({
                  messageId: "missingValues",
                  format: { missingValues: missing.join(", ") },
                  target: provisioningType
                });
              }
              break;
            }
            default:
              context.reportDiagnostic({
                target: provisioning
              });
          }
          if (provisioning.optional !== true) {
            context.reportDiagnostic({
              messageId: "mustBeOptional",
              target: provisioning
            });
          }
          if (!isReadonlyProperty(context.program, provisioning)) {
            context.reportDiagnostic({
              messageId: "missingReadOnlyVisibility",
              target: provisioning
            });
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/beyond-nesting-levels.js
import { createRule as createRule19 } from "@typespec/compiler";
import { getParentResource as getParentResource3 } from "@typespec/rest";
var beyondNestingRule = createRule19({
  name: "beyond-nesting-levels",
  severity: "warning",
  description: "Tracked Resources must use 3 or fewer levels of nesting.",
  messages: {
    default: "Tracked Resources must use 3 or fewer levels of nesting."
  },
  create(context) {
    return {
      model: (model) => {
        let levels = 1;
        if (!isTrackedResource(model)) {
          return;
        }
        let parent = model;
        while (levels < 4) {
          parent = getParentResource3(context.program, parent);
          if (parent) {
            levels++;
          } else {
            break;
          }
        }
        if (levels === 4) {
          context.reportDiagnostic({
            target: model
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/core-operations.js
import { createRule as createRule20, paramMessage as paramMessage9 } from "@typespec/compiler";
import { SyntaxKind as SyntaxKind2 } from "@typespec/compiler/ast";
import { getOperationVerb as getOperationVerb3 } from "@typespec/http";
var coreOperationsRule = createRule20({
  name: "arm-resource-operation",
  severity: "warning",
  description: "Validate ARM Resource operations.",
  messages: {
    default: "All Resource operations must use an api-version parameter. Please include Azure.ResourceManager.ApiVersionParameter in the operation parameter list using the spread (...ApiVersionParameter) operator, or using one of the common resource parameter models.",
    opOutsideInterface: "All operations must be inside an interface declaration.",
    opMissingDecorator: paramMessage9`Resource ${"verb"} operation must be decorated with ${"decorator"}.`
  },
  create(context) {
    return {
      operation: (operation) => {
        if (!isInternalTypeSpec(context.program, operation) && !isSourceOperationResourceManagerInternal(operation)) {
          const verb = getOperationVerb3(context.program, operation);
          if (!isTemplatedInterfaceOperation(operation) && (!operation.node?.parent || operation.node.parent.kind !== SyntaxKind2.InterfaceStatement)) {
            context.reportDiagnostic({
              messageId: "opOutsideInterface",
              target: operation
            });
          }
          const parameters = operation.parameters;
          if (parameters === void 0 || parameters === null || !hasApiParameter(context.program, parameters)) {
            context.reportDiagnostic({
              target: operation
            });
          }
          if (verb) {
            const requiredDecorators = resourceOperationDecorators[verb];
            if (requiredDecorators?.length > 0) {
              const decorator = operation.decorators.find((d) => requiredDecorators.indexOf(d.decorator.name) >= 0);
              if (!decorator) {
                context.reportDiagnostic({
                  messageId: "opMissingDecorator",
                  target: operation,
                  format: {
                    verb: verb.toUpperCase(),
                    decorator: requiredDecorators.map((d) => `@${d.substring(1)}`).join(" or ")
                  }
                });
              }
            }
          }
        }
      }
    };
  }
});
var resourceOperationDecorators = {
  put: ["$armResourceCreateOrUpdate"],
  get: ["$armResourceRead", "$armResourceList"],
  patch: ["$armResourceUpdate"],
  delete: ["$armResourceDelete"],
  post: ["$armResourceAction", "$armResourceCollectionAction"],
  head: []
};
function isApiParameter(program, property) {
  if (property.type.kind !== "Scalar")
    return false;
  if (!property.sourceProperty)
    return false;
  const sourceModel = getSourceModel(property.sourceProperty);
  if (sourceModel === void 0)
    return false;
  return sourceModel.name === "ApiVersionParameter" && getNamespaceName(program, sourceModel) === "Azure.ResourceManager.CommonTypes";
}
function hasApiParameter(program, model) {
  if (model.properties === void 0 || model.properties.size === 0)
    return false;
  const apiVersionParams = [...model.properties.values()].filter((i) => isApiParameter(program, i));
  return apiVersionParams !== null && apiVersionParams.length === 1;
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/delete-operation.js
import { createRule as createRule21 } from "@typespec/compiler";
var deleteOperationMissingRule = createRule21({
  name: "no-resource-delete-operation",
  severity: "warning",
  description: "Check for resources that must have a delete operation.",
  messages: {
    default: `The resource must have a delete operation.`
  },
  create(context) {
    return {
      model: (model) => {
        const resources = getArmResources(context.program);
        const armResource = resources.find((re) => re.typespecType === model);
        if (armResource && armResource.operations.lifecycle.createOrUpdate && !armResource.operations.lifecycle.delete) {
          const resourceInterface = getInterface(armResource);
          context.reportDiagnostic({
            target: resourceInterface || model
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/envelope-properties.js
import { createRule as createRule22, getProperty as getProperty6 } from "@typespec/compiler";
var envelopePropertiesRules = createRule22({
  name: "empty-updateable-properties",
  severity: "warning",
  description: "Should have updateable properties.",
  messages: {
    default: `The RP-specific properties of the Resource (as defined in the 'properties' property) should have at least one updateable property.  Properties are updateable if they do not have a '@visibility' decorator, or if they include 'update' in the '@visibility' decorator arguments.`
  },
  create(context) {
    return {
      model: (model) => {
        const resources = getArmResources(context.program);
        const armResource = resources.find((re) => re.typespecType === model);
        if (armResource && armResource.operations.lifecycle.update && armResource.operations.lifecycle.createOrUpdate) {
          const updateOperationProperties = armResource.operations.lifecycle.update.httpOperation.parameters.body?.type;
          if (updateOperationProperties?.kind === "Model") {
            if (getProperties(updateOperationProperties).length < 1) {
              context.reportDiagnostic({
                target: model
              });
            }
            const updateablePropertiesBag = getProperty6(updateOperationProperties, "properties");
            if (updateablePropertiesBag?.type.kind === "Model" && getProperties(updateablePropertiesBag.type).length === 0) {
              context.reportDiagnostic({
                target: model.properties.get("properties")?.type ?? model
              });
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/list-operation.js
import { createRule as createRule23 } from "@typespec/compiler";
var listBySubscriptionRule = createRule23({
  name: "improper-subscription-list-operation",
  severity: "warning",
  description: `Tenant and Extension resources should not define a list by subscription operation.`,
  messages: {
    default: `Tenant and Extension resources should not define a list by subscription operation.`
  },
  create(context) {
    return {
      root: (program) => {
        const resources = getArmResources(program);
        for (const armResource of resources) {
          if (armResource && armResource.operations.lists) {
            const baseType = getResourceBaseType(context.program, armResource.typespecType);
            if (baseType === ResourceBaseType.Extension || baseType === ResourceBaseType.Tenant) {
              for (const listOperationName of Object.keys(armResource.operations.lists)) {
                const listOperation = armResource.operations.lists[listOperationName];
                if (listOperation.path.includes("{subscriptionId}")) {
                  const resourceInterface = getInterface(armResource);
                  context.reportDiagnostic({
                    target: resourceInterface ?? armResource.typespecType
                  });
                }
              }
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/lro-location-header.js
import { createRule as createRule24 } from "@typespec/compiler";
import { getHttpOperation as getHttpOperation2 } from "@typespec/http";
function getCaseInsensitiveHeader(headers, key) {
  if (!headers) {
    return void 0;
  }
  for (const header of Object.keys(headers)) {
    if (header.toLowerCase() === key.toLowerCase()) {
      return header;
    }
  }
  return void 0;
}
var lroLocationHeaderRule = createRule24({
  name: "lro-location-header",
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/lro-location-header",
  description: "A 202 response should include a Location response header.",
  messages: {
    default: `A 202 response should include a Location response header.`
  },
  create(context) {
    return {
      operation: (op) => {
        const [httpOperation, _] = getHttpOperation2(context.program, op);
        const responses = httpOperation.responses;
        for (const response of responses) {
          if (response.statusCodes !== 202) {
            continue;
          }
          for (const resp of response.responses) {
            if (getCaseInsensitiveHeader(resp.headers, "Location") === void 0) {
              context.reportDiagnostic({
                target: op
              });
              return;
            }
          }
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/missing-x-ms-identifiers.js
import { createRule as createRule25, getProperty as getProperty7, isArrayModelType as isArrayModelType2, paramMessage as paramMessage10 } from "@typespec/compiler";
import { getExtensions } from "@typespec/openapi";
var missingXmsIdentifiersRule = createRule25({
  name: "missing-x-ms-identifiers",
  description: `Array properties should describe their identifying properties with x-ms-identifiers. Decorate the property with @OpenAPI.extension("x-ms-identifiers", #[id-prop])  where "id-prop" is a list of the names of identifying properties in the item type.`,
  severity: "warning",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/missing-x-ms-identifiers",
  messages: {
    default: `Missing identifying properties of objects in the array item, please add @OpenAPI.extension("x-ms-identifiers", #[<prop>]) to specify it. If there are no appropriate identifying properties, please add @OpenAPI.extension("x-ms-identifiers", #[]).`,
    notArray: paramMessage10`Value passed to @OpenAPI.extension("x-ms-identifiers",...) was a "${"valueType"}". Pass an array of property name.`,
    missingProperty: paramMessage10`Property "${"propertyName"}" is not found in "${"targetModelName"}". Make sure value of x-ms-identifiers extension are valid property name of the array element.`
  },
  create(context) {
    return {
      modelProperty: (property) => {
        const type = property.type;
        if (type.kind === "Model" && isArrayModelType2(context.program, type)) {
          if (isArrayMissingIdentifier(context.program, type, property)) {
            context.reportDiagnostic({
              target: property
            });
          }
        }
      }
    };
    function isArrayMissingIdentifier(program, array, property) {
      const elementType = array.indexer.value;
      if (elementType.kind !== "Model") {
        return false;
      }
      if (isArmCommonType(elementType)) {
        return false;
      }
      if (getProperty7(elementType, "id") || getProperty7(elementType, "name")) {
        return false;
      }
      const xmsIdentifiers = getExtensions(program, property ?? array).get("x-ms-identifiers");
      const armIdentifiers = getArmIdentifiers(program, property);
      const armKeyIdentifiers = getArmKeyIdentifiers(program, array);
      const identifiers = armIdentifiers ?? armKeyIdentifiers ?? xmsIdentifiers;
      if (identifiers === void 0) {
        return true;
      }
      if (Array.isArray(identifiers)) {
        for (const propIdentifier of identifiers) {
          if (typeof propIdentifier === "string") {
            const props = propIdentifier.replace(/^\//, "").split("/");
            let element = elementType;
            for (const prop of props) {
              if (element === void 0 || element.kind !== "Model") {
                context.reportDiagnostic({
                  messageId: "missingProperty",
                  format: { propertyName: prop, targetModelName: element?.name },
                  target: property
                });
                return false;
              }
              const propertyValue = getProperty7(element, prop);
              if (propertyValue === void 0) {
                context.reportDiagnostic({
                  messageId: "missingProperty",
                  format: { propertyName: prop, targetModelName: elementType.name },
                  target: property
                });
              }
              element = propertyValue?.type;
            }
          } else {
            context.reportDiagnostic({
              messageId: "notArray",
              format: { valueType: typeof propIdentifier },
              target: property
            });
          }
        }
      } else {
        context.reportDiagnostic({
          messageId: "notArray",
          format: { valueType: typeof xmsIdentifiers },
          target: property
        });
      }
      return false;
    }
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/no-empty-model.js
import { createRule as createRule26, isRecordModelType } from "@typespec/compiler";
var noEmptyModel = createRule26({
  name: "no-empty-model",
  severity: "warning",
  description: "ARM Properties with type:object that don't reference a model definition are not allowed. ARM doesn't allow generic type definitions as this leads to bad customer experience.",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/no-empty-model",
  messages: {
    default: "Properties with type:object must have definition of a reference model.",
    extends: "The `type:object` model is not defined in the payload. Define the reference model of the object or change the `type` to a primitive data type like string, int, etc"
  },
  create(context) {
    return {
      model: (model) => {
        if (model.properties.size === 0 && !isRecordModelType(context.program, model)) {
          context.reportDiagnostic({
            code: "no-empty-model",
            target: model
          });
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/no-response-body.js
import { createRule as createRule27, isTemplateInstance } from "@typespec/compiler";
import { getHttpOperation as getHttpOperation3, getResponsesForOperation } from "@typespec/http";
var noResponseBodyRule = createRule27({
  name: "no-response-body",
  description: "Check that the body is empty for 202 and 204 responses, and not empty for other success (2xx) responses.",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/no-response-body",
  severity: "warning",
  messages: {
    default: `The body of responses with success (2xx) status codes other than 202 and 204 should not be empty.`,
    shouldBeEmpty202: `The body of 202 response should be empty.`,
    shouldBeEmpty204: `The body of 204 response should be empty.`
  },
  create(context) {
    return {
      operation: (op) => {
        const [httpOperation] = getHttpOperation3(context.program, op);
        if (isTemplateInstance(op) || isTemplatedInterfaceOperation(op) || httpOperation.verb === "head")
          return;
        const responses = getResponsesForOperation(context.program, op)[0].find((v) => v.statusCodes !== 204 && v.statusCodes !== 202);
        if (responses && !responses.responses.every((v) => v.body)) {
          if (["delete", "post"].includes(httpOperation.verb) && responses.statusCodes === 200) {
            return;
          }
          context.reportDiagnostic({
            target: op
          });
        }
        if (hasResponseBodyForCode(202, getResponsesForOperation(context.program, op)[0])) {
          context.reportDiagnostic({
            target: op,
            messageId: "shouldBeEmpty202"
          });
        }
        if (hasResponseBodyForCode(204, getResponsesForOperation(context.program, op)[0])) {
          context.reportDiagnostic({
            target: op,
            messageId: "shouldBeEmpty204"
          });
        }
      }
    };
  }
});
function hasResponseBodyForCode(statusCode, operations) {
  const response = operations.find((v) => v.statusCodes === statusCode);
  return !!(response && response.responses.some((v) => v.body));
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/operations-interface-missing.js
import { createRule as createRule28, isService, paramMessage as paramMessage11 } from "@typespec/compiler";
var operationsInterfaceMissingRule = createRule28({
  name: "missing-operations-endpoint",
  severity: "warning",
  description: "Check for missing Operations interface.",
  messages: {
    default: paramMessage11`Arm namespace ${"namespace"} is missing the Operations interface. Add "interface Operations extends Azure.ResourceManager.Operations {}".`
  },
  create(context) {
    return {
      namespace: (namespace4) => {
        if (!isService(context.program, namespace4)) {
          return;
        }
        const providerName = getArmProviderNamespace(context.program, namespace4);
        if (!providerName) {
          return;
        }
        for (const item of namespace4.interfaces.values()) {
          if (isArmOperationsListInterface(context.program, item)) {
            return;
          }
        }
        context.reportDiagnostic({
          format: {
            namespace: namespace4.name
          },
          target: namespace4
        });
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/patch-envelope-properties.js
import { createRule as createRule29, getProperty as getProperty8, paramMessage as paramMessage12 } from "@typespec/compiler";
var patchEnvelopePropertiesRules = createRule29({
  name: "patch-envelope",
  severity: "warning",
  description: "Patch envelope properties should match the resource properties.",
  messages: {
    default: paramMessage12`The Resource PATCH request for resource '${"resourceName"}' is missing envelope properties:  [${"propertyName"}]. Since these properties are supported in the resource, they must also be updatable via PATCH.`
  },
  create(context) {
    const patchEnvelopeProperties = ["identity", "managedBy", "plan", "sku", "tags"];
    return {
      model: (model) => {
        const resources = getArmResources(context.program);
        const armResource = resources.find((re) => re.typespecType === model);
        if (armResource && armResource.operations.lifecycle.update && armResource.operations.lifecycle.createOrUpdate) {
          const updateOperationProperties = armResource.operations.lifecycle.update.httpOperation.parameters.body?.type;
          const missingProperties = [];
          for (const property of patchEnvelopeProperties) {
            if (!checkForPatchProperty(property, model, updateOperationProperties)) {
              missingProperties.push(property);
            }
          }
          if (missingProperties.length > 0) {
            context.reportDiagnostic({
              format: { resourceName: model.name, propertyName: missingProperties.join(", ") },
              target: updateOperationProperties?.kind === "Model" ? updateOperationProperties : armResource.operations.lifecycle.update.operation
            });
          }
        }
      }
    };
  }
});
function checkForPatchProperty(propertyName, resourceModel, patchModel) {
  return getProperty8(resourceModel, propertyName) === void 0 || patchModel?.kind === "Model" && getProperty8(patchModel, propertyName) !== void 0;
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/resource-name.js
import { createRule as createRule30, getProperty as getProperty9 } from "@typespec/compiler";
import * as http2 from "@typespec/http";
import { isReadonlyProperty as isReadonlyProperty2 } from "@typespec/openapi";
var resourceNameRule = createRule30({
  name: "resource-name",
  severity: "warning",
  description: "Check the resource name.",
  messages: {
    default: `The resource 'name' field should be marked with 'read' visibility and an @path decorator.`,
    nameInvalid: "Arm resource name must contain only alphanumeric characters."
  },
  create(context) {
    return {
      model: (model) => {
        const resources = getArmResources(context.program);
        const armResource = resources.find((re) => re.typespecType === model);
        if (armResource) {
          if (!checkResourceModelName(model.name)) {
            context.reportDiagnostic({
              messageId: "nameInvalid",
              target: model
            });
          }
          const name = getProperty9(model, "name");
          if (name && checkResourceName(name)) {
            context.reportDiagnostic({
              target: name
            });
          }
        }
        function checkResourceName(nameProp) {
          return !(http2.isPathParam(context.program, nameProp) && isReadonlyProperty2(context.program, nameProp));
        }
        function checkResourceModelName(name) {
          const matches = name.match(/^[A-Z][0-9A-Za-z]+$/);
          return matches !== null && matches.length === 1;
        }
      }
    };
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/retry-after.js
import { createRule as createRule31 } from "@typespec/compiler";
import { getResponsesForOperation as getResponsesForOperation2 } from "@typespec/http";
import { getExtensions as getExtensions2 } from "@typespec/openapi";
var retryAfterRule = createRule31({
  name: "retry-after",
  severity: "warning",
  description: "Check if retry-after header appears in response body.",
  messages: {
    default: `For long-running operations, the Retry-After header indicates how long the client should wait before polling the operation status, please add this header to the 201 or 202 response for this operation.`
  },
  create(context) {
    return {
      operation: (op) => {
        if (isTemplatedInterfaceOperation(op)) {
          return;
        }
        const isLRO = getExtensions2(context.program, op).has("x-ms-long-running-operation");
        if (isLRO && !hasRetryAfterHeader(context.program, op)) {
          context.reportDiagnostic({
            target: op
          });
        }
      }
    };
  }
});
function hasRetryAfterHeader(program, op) {
  return !!getResponsesForOperation2(program, op)[0].find((re) => re.responses.find((res) => res.headers?.["Retry-After"]));
}

// src/typespec/packages/typespec-azure-resource-manager/dist/src/rules/unsupported-type.js
import { createRule as createRule32, isType as isType3, paramMessage as paramMessage13 } from "@typespec/compiler";
var UnsupportedIntrinsicModel = /* @__PURE__ */ new Set(["int8", "int16", "uint8", "uint16", "uint32", "uint64"]);
var unsupportedTypeRule = createRule32({
  name: "unsupported-type",
  severity: "warning",
  description: "Check for unsupported ARM types.",
  url: "https://azure.github.io/typespec-azure/docs/libraries/azure-resource-manager/rules/unsupported-type",
  messages: {
    default: paramMessage13`Model type '${"typeName"}' is not supported in Azure resource manager APIs.`
  },
  create(context) {
    return {
      modelProperty: (property) => {
        checkUnsupportedType(property.type, property);
      },
      operation: (op) => {
        checkUnsupportedType(op.returnType, op);
      }
    };
    function checkUnsupportedType(type, target) {
      if (type.kind !== "Scalar" && type.kind !== "Model") {
        return;
      }
      if (type.kind === "Scalar") {
        if (UnsupportedIntrinsicModel.has(type.name)) {
          context.reportDiagnostic({
            format: { typeName: type.name },
            target
          });
        }
      }
      if (type.templateMapper) {
        for (const templateArg of type.templateMapper.args) {
          if (isType3(templateArg)) {
            checkUnsupportedType(templateArg, target);
          }
        }
      }
    }
  }
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/linter.js
var rules = [
  armNoRecordRule,
  armCommonTypesVersionRule,
  armDeleteResponseCodesRule,
  armPutResponseCodesRule,
  armPostResponseCodesRule,
  armResourceActionNoSegmentRule,
  armResourceDuplicatePropertiesRule,
  armResourceEnvelopeProperties,
  armResourceInvalidVersionFormatRule,
  armResourceKeyInvalidCharsRule,
  armResourceNamePatternRule,
  armResourceOperationsRule,
  armResourcePathInvalidCharsRule,
  armResourceProvisioningStateRule,
  armCustomResourceUsageDiscourage,
  beyondNestingRule,
  coreOperationsRule,
  deleteOperationMissingRule,
  envelopePropertiesRules,
  interfacesRule,
  armResourceInvalidActionVerbRule,
  listBySubscriptionRule,
  lroLocationHeaderRule,
  missingXmsIdentifiersRule,
  noResponseBodyRule,
  operationsInterfaceMissingRule,
  patchEnvelopePropertiesRules,
  patchOperationsRule,
  resourceNameRule,
  retryAfterRule,
  unsupportedTypeRule,
  noEmptyModel
];
var $linter = defineLinter({
  rules
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/tsp-index.js
var tsp_index_exports = {};
__export(tsp_index_exports, {
  $decorators: () => $decorators2,
  $flags: () => $flags,
  $lib: () => $lib
});
import { definePackageFlags } from "@typespec/compiler";
var $decorators2 = {
  "Azure.ResourceManager": {
    armResourceCollectionAction: $armResourceCollectionAction,
    armProviderNameValue: $armProviderNameValue,
    armProviderNamespace: $armProviderNamespace,
    useLibraryNamespace: $useLibraryNamespace,
    armLibraryNamespace: $armLibraryNamespace,
    singleton: $singleton,
    tenantResource: $tenantResource,
    subscriptionResource: $subscriptionResource,
    locationResource: $locationResource,
    resourceGroupResource: $resourceGroupResource,
    extensionResource: $extensionResource,
    armResourceAction: $armResourceAction,
    armResourceCreateOrUpdate: $armResourceCreateOrUpdate,
    armResourceRead: $armResourceRead,
    armResourceUpdate: $armResourceUpdate,
    armResourceDelete: $armResourceDelete,
    armResourceList: $armResourceList,
    armResourceOperations: $armResourceOperations,
    armCommonTypesVersion: $armCommonTypesVersion,
    armVirtualResource: $armVirtualResource,
    resourceBaseType: $resourceBaseType,
    identifiers: $identifiers
  },
  "Azure.ResourceManager.Legacy": {
    customAzureResource: $customAzureResource,
    externalTypeRef: $externalTypeRef
  }
};
var $flags = definePackageFlags({
  decoratorArgMarshalling: "new"
});

// src/typespec/packages/typespec-azure-resource-manager/dist/src/index.js
var namespace3 = "Azure.ResourceManager";

// virtual:virtual:entry.js
var TypeSpecJSSources = {
  "dist/src/index.js": src_exports,
  "dist/src/tsp-index.js": tsp_index_exports,
  "dist/src/private.decorators.js": private_decorators_exports,
  "dist/src/commontypes.private.decorators.js": commontypes_private_decorators_exports
};
var TypeSpecSources = {
  "package.json": '{"name":"@azure-tools/typespec-azure-resource-manager","version":"0.56.0","author":"Microsoft Corporation","description":"TypeSpec Azure Resource Manager library","homepage":"https://azure.github.io/typespec-azure","docusaurusWebsite":"https://azure.github.io/typespec-azure/docs","readme":"https://github.com/Azure/typespec-azure/blob/main/packages/typespec-azure-resource-manager/README.md","license":"MIT","repository":{"type":"git","url":"git+https://github.com/Azure/typespec-azure.git"},"bugs":{"url":"https://github.com/Azure/typespec-azure/issues"},"keywords":["typespec"],"main":"dist/src/index.js","tspMain":"lib/arm.tsp","exports":{".":{"typespec":"./lib/arm.tsp","types":"./dist/src/index.d.ts","default":"./dist/src/index.js"},"./testing":{"types":"./dist/src/testing/index.d.ts","default":"./dist/src/testing/index.js"}},"type":"module","engines":{"node":">=20.0.0"},"scripts":{"clean":"rimraf ./dist ./temp","build":"npm run gen-extern-signature && tsc -p . && npm run lint-typespec-library","watch":"tsc -p . --watch","gen-extern-signature":"tspd --enable-experimental gen-extern-signature .","lint-typespec-library":"tsp compile . --warn-as-error --import @typespec/library-linter --no-emit","test":"vitest run","test:watch":"vitest -w","test:ui":"vitest --ui","test:ci":"vitest run --coverage  --reporter=junit --reporter=default","lint":"eslint .  --max-warnings=0","lint:fix":"eslint . --fix ","regen-docs":"tspd doc .  --enable-experimental  --output-dir ../../website/src/content/docs/docs/libraries/azure-resource-manager/reference"},"files":["lib/**/*.tsp","dist/**","!dist/test/**"],"dependencies":{"change-case":"~5.4.4","pluralize":"^8.0.0"},"peerDependencies":{"@azure-tools/typespec-azure-core":"workspace:^","@typespec/compiler":"workspace:^","@typespec/http":"workspace:^","@typespec/openapi":"workspace:^","@typespec/rest":"workspace:^","@typespec/versioning":"workspace:^"},"devDependencies":{"@azure-tools/typespec-azure-core":"workspace:^","@types/node":"~22.13.11","@types/pluralize":"^0.0.33","@typespec/compiler":"workspace:^","@typespec/http":"workspace:^","@typespec/library-linter":"workspace:^","@typespec/openapi":"workspace:^","@typespec/rest":"workspace:^","@typespec/tspd":"workspace:^","@typespec/versioning":"workspace:^","@vitest/coverage-v8":"^3.1.2","@vitest/ui":"^3.1.2","c8":"^10.1.3","rimraf":"~6.0.1","typescript":"~5.8.2","vitest":"^3.1.2"}}',
  "../../core/packages/compiler/lib/intrinsics.tsp": 'import "../dist/src/lib/intrinsic/tsp-index.js";\nimport "./prototypes.tsp";\n\n// This file contains all the intrinsic types of typespec. Everything here will always be loaded\nnamespace TypeSpec;\n\n/**\n * Represent a byte array\n */\nscalar bytes;\n\n/**\n * A numeric type\n */\nscalar numeric;\n\n/**\n * A whole number. This represent any `integer` value possible.\n * It is commonly represented as `BigInteger` in some languages.\n */\nscalar integer extends numeric;\n\n/**\n * A number with decimal value\n */\nscalar float extends numeric;\n\n/**\n * A 64-bit integer. (`-9,223,372,036,854,775,808` to `9,223,372,036,854,775,807`)\n */\nscalar int64 extends integer;\n\n/**\n * A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)\n */\nscalar int32 extends int64;\n\n/**\n * A 16-bit integer. (`-32,768` to `32,767`)\n */\nscalar int16 extends int32;\n\n/**\n * A 8-bit integer. (`-128` to `127`)\n */\nscalar int8 extends int16;\n\n/**\n * A 64-bit unsigned integer (`0` to `18,446,744,073,709,551,615`)\n */\nscalar uint64 extends integer;\n\n/**\n * A 32-bit unsigned integer (`0` to `4,294,967,295`)\n */\nscalar uint32 extends uint64;\n\n/**\n * A 16-bit unsigned integer (`0` to `65,535`)\n */\nscalar uint16 extends uint32;\n\n/**\n * A 8-bit unsigned integer (`0` to `255`)\n */\nscalar uint8 extends uint16;\n\n/**\n * An integer that can be serialized to JSON (`\u22129007199254740991 (\u2212(2^53 \u2212 1))` to `9007199254740991 (2^53 \u2212 1)` )\n */\nscalar safeint extends int64;\n\n/**\n * A 64 bit floating point number. (`\xB15.0 \xD7 10^\u2212324` to `\xB11.7 \xD7 10^308`)\n */\nscalar float64 extends float;\n\n/**\n * A 32 bit floating point number. (`\xB11.5 x 10^\u221245` to `\xB13.4 x 10^38`)\n */\nscalar float32 extends float64;\n\n/**\n * A decimal number with any length and precision. This represent any `decimal` value possible.\n * It is commonly represented as `BigDecimal` in some languages.\n */\nscalar decimal extends numeric;\n\n/**\n * A 128-bit decimal number.\n */\nscalar decimal128 extends decimal;\n\n/**\n * A sequence of textual characters.\n */\nscalar string;\n\n/**\n * A date on a calendar without a time zone, e.g. "April 10th"\n */\nscalar plainDate {\n  /**\n   * Create a plain date from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = plainTime.fromISO("2024-05-06");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * A time on a clock without a time zone, e.g. "3:00 am"\n */\nscalar plainTime {\n  /**\n   * Create a plain time from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = plainTime.fromISO("12:34");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * An instant in coordinated universal time (UTC)"\n */\nscalar utcDateTime {\n  /**\n   * Create a date from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = utcDateTime.fromISO("2024-05-06T12:20-12Z");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * A date and time in a particular time zone, e.g. "April 10th at 3:00am in PST"\n */\nscalar offsetDateTime {\n  /**\n   * Create a date from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = offsetDateTime.fromISO("2024-05-06T12:20-12-0700");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * A duration/time period. e.g 5s, 10h\n */\nscalar duration {\n  /**\n   * Create a duration from an ISO 8601 string.\n   * @example\n   *\n   * ```tsp\n   * const time = duration.fromISO("P1Y1D");\n   * ```\n   */\n  init fromISO(value: string);\n}\n\n/**\n * Boolean with `true` and `false` values.\n */\nscalar boolean;\n\n/**\n * @dev Array model type, equivalent to `Element[]`\n * @template Element The type of the array elements\n */\n@indexer(integer, Element)\nmodel Array<Element> {}\n\n/**\n * @dev Model with string properties where all the properties have type `Property`\n * @template Element The type of the properties\n */\n@indexer(string, Element)\nmodel Record<Element> {}\n',
  "../../core/packages/compiler/lib/prototypes.tsp": "namespace TypeSpec.Prototypes;\n\nextern dec getter(target: unknown);\n\nnamespace Types {\n  interface ModelProperty {\n    @getter type(): unknown;\n  }\n\n  interface Operation {\n    @getter returnType(): unknown;\n    @getter parameters(): unknown;\n  }\n\n  interface Array<TElementType> {\n    @getter elementType(): TElementType;\n  }\n}\n",
  "../../core/packages/compiler/lib/std/main.tsp": '// TypeSpec standard library. Everything in here can be omitted by using `--nostdlib` cli flag or `nostdlib` in the config.\nimport "./types.tsp";\nimport "./decorators.tsp";\nimport "./reflection.tsp";\nimport "./visibility.tsp";\n',
  "../../core/packages/compiler/lib/std/types.tsp": 'namespace TypeSpec;\n\n/**\n * Represent a 32-bit unix timestamp datetime with 1s of granularity.\n * It measures time by the number of seconds that have elapsed since 00:00:00 UTC on 1 January 1970.\n */\n@encode("unixTimestamp", int32)\nscalar unixTimestamp32 extends utcDateTime;\n\n/**\n * Represent a URL string as described by https://url.spec.whatwg.org/\n */\nscalar url extends string;\n\n/**\n * Represents a collection of optional properties.\n *\n * @template Source An object whose spread properties are all optional.\n */\n@doc("The template for adding optional properties.")\n@withOptionalProperties\nmodel OptionalProperties<Source> {\n  ...Source;\n}\n\n/**\n * Represents a collection of updateable properties.\n *\n * @template Source An object whose spread properties are all updateable.\n */\n@doc("The template for adding updateable properties.")\n@withUpdateableProperties\nmodel UpdateableProperties<Source> {\n  ...Source;\n}\n\n/**\n * Represents a collection of omitted properties.\n *\n * @template Source An object whose properties are spread.\n * @template Keys The property keys to omit.\n */\n@doc("The template for omitting properties.")\n@withoutOmittedProperties(Keys)\nmodel OmitProperties<Source, Keys extends string> {\n  ...Source;\n}\n\n/**\n * Represents a collection of properties with only the specified keys included.\n *\n * @template Source An object whose properties are spread.\n * @template Keys The property keys to include.\n */\n@doc("The template for picking properties.")\n@withPickedProperties(Keys)\nmodel PickProperties<Source, Keys extends string> {\n  ...Source;\n}\n\n/**\n * Represents a collection of properties with default values omitted.\n *\n * @template Source An object whose spread property defaults are all omitted.\n */\n@withoutDefaultValues\nmodel OmitDefaults<Source> {\n  ...Source;\n}\n\n/**\n * Applies a visibility setting to a collection of properties.\n *\n * @template Source An object whose properties are spread.\n * @template Visibility The visibility to apply to all properties.\n */\n@doc("The template for setting the default visibility of key properties.")\n@withDefaultKeyVisibility(Visibility)\nmodel DefaultKeyVisibility<Source, Visibility extends valueof Reflection.EnumMember> {\n  ...Source;\n}\n',
  "../../core/packages/compiler/lib/std/decorators.tsp": 'import "../../dist/src/lib/tsp-index.js";\n\nusing TypeSpec.Reflection;\n\nnamespace TypeSpec;\n\n/**\n * Typically a short, single-line description.\n * @param summary Summary string.\n *\n * @example\n * ```typespec\n * @summary("This is a pet")\n * model Pet {}\n * ```\n */\nextern dec summary(target: unknown, summary: valueof string);\n\n/**\n * Attach a documentation string. Content support CommonMark markdown formatting.\n * @param doc Documentation string\n * @param formatArgs Record with key value pair that can be interpolated in the doc.\n *\n * @example\n * ```typespec\n * @doc("Represent a Pet available in the PetStore")\n * model Pet {}\n * ```\n */\nextern dec doc(target: unknown, doc: valueof string, formatArgs?: {});\n\n/**\n * Attach a documentation string to describe the successful return types of an operation.\n * If an operation returns a union of success and errors it only describes the success. See `@errorsDoc` for error documentation.\n * @param doc Documentation string\n *\n * @example\n * ```typespec\n * @returnsDoc("Returns doc")\n * op get(): Pet | NotFound;\n * ```\n */\nextern dec returnsDoc(target: Operation, doc: valueof string);\n\n/**\n * Attach a documentation string to describe the error return types of an operation.\n * If an operation returns a union of success and errors it only describes the errors. See `@returnsDoc` for success documentation.\n * @param doc Documentation string\n *\n * @example\n * ```typespec\n * @errorsDoc("Errors doc")\n * op get(): Pet | NotFound;\n * ```\n */\nextern dec errorsDoc(target: Operation, doc: valueof string);\n\n/**\n * Service options.\n */\nmodel ServiceOptions {\n  /**\n   * Title of the service.\n   */\n  title?: string;\n}\n\n/**\n * Mark this namespace as describing a service and configure service properties.\n * @param options Optional configuration for the service.\n *\n * @example\n * ```typespec\n * @service\n * namespace PetStore;\n * ```\n *\n * @example Setting service title\n * ```typespec\n * @service(#{title: "Pet store"})\n * namespace PetStore;\n * ```\n *\n * @example Setting service version\n * ```typespec\n * @service(#{version: "1.0"})\n * namespace PetStore;\n * ```\n */\nextern dec service(target: Namespace, options?: valueof ServiceOptions);\n\n/**\n * Specify that this model is an error type. Operations return error types when the operation has failed.\n *\n * @example\n * ```typespec\n * @error\n * model PetStoreError {\n *   code: string;\n *   message: string;\n * }\n * ```\n */\nextern dec error(target: Model);\n\n/**\n * Applies a media type hint to a TypeSpec type. Emitters and libraries may choose to use this hint to determine how a\n * type should be serialized. For example, the `@typespec/http` library will use the media type hint of the response\n * body type as a default `Content-Type` if one is not explicitly specified in the operation.\n *\n * Media types (also known as MIME types) are defined by RFC 6838. The media type hint should be a valid media type\n * string as defined by the RFC, but the decorator does not enforce or validate this constraint.\n *\n * Notes: the applied media type is _only_ a hint. It may be overridden or not used at all. Media type hints are\n * inherited by subtypes. If a media type hint is applied to a model, it will be inherited by all other models that\n * `extend` it unless they delcare their own media type hint.\n *\n * @param mediaType The media type hint to apply to the target type.\n *\n * @example create a model that serializes as XML by default\n *\n * ```tsp\n * @mediaTypeHint("application/xml")\n * model Example {\n *   @visibility(Lifecycle.Read)\n *   id: string;\n *\n *   name: string;\n * }\n * ```\n */\nextern dec mediaTypeHint(target: Model | Scalar | Enum | Union, mediaType: valueof string);\n\n// Cannot apply this to the scalar itself. Needs to be applied here so that we don\'t crash nostdlib scenarios\n@@mediaTypeHint(TypeSpec.bytes, "application/octet-stream");\n\n// @@mediaTypeHint(TypeSpec.string "text/plain") -- This is hardcoded in the compiler to avoid circularity\n// between the initialization of the string scalar and the `valueof string` required to call the\n// `mediaTypeHint` decorator.\n\n/**\n * Specify a known data format hint for this string type. For example `uuid`, `uri`, etc.\n * This differs from the `@pattern` decorator which is meant to specify a regular expression while `@format` accepts a known format name.\n * The format names are open ended and are left to emitter to interpret.\n *\n * @param format format name.\n *\n * @example\n * ```typespec\n * @format("uuid")\n * scalar uuid extends string;\n * ```\n */\nextern dec format(target: string | ModelProperty, format: valueof string);\n\n/**\n * Specify the the pattern this string should respect using simple regular expression syntax.\n * The following syntax is allowed: alternations (`|`), quantifiers (`?`, `*`, `+`, and `{ }`), wildcard (`.`), and grouping parentheses.\n * Advanced features like look-around, capture groups, and references are not supported.\n *\n * This decorator may optionally provide a custom validation _message_. Emitters may choose to use the message to provide\n * context when pattern validation fails. For the sake of consistency, the message should be a phrase that describes in\n * plain language what sort of content the pattern attempts to validate. For example, a complex regular expression that\n * validates a GUID string might have a message like "Must be a valid GUID."\n *\n * @param pattern Regular expression.\n * @param validationMessage Optional validation message that may provide context when validation fails.\n *\n * @example\n * ```typespec\n * @pattern("[a-z]+", "Must be a string consisting of only lower case letters and of at least one character.")\n * scalar LowerAlpha extends string;\n * ```\n */\nextern dec pattern(\n  target: string | bytes | ModelProperty,\n  pattern: valueof string,\n  validationMessage?: valueof string\n);\n\n/**\n * Specify the minimum length this string type should be.\n * @param value Minimum length\n *\n * @example\n * ```typespec\n * @minLength(2)\n * scalar Username extends string;\n * ```\n */\nextern dec minLength(target: string | ModelProperty, value: valueof integer);\n\n/**\n * Specify the maximum length this string type should be.\n * @param value Maximum length\n *\n * @example\n * ```typespec\n * @maxLength(20)\n * scalar Username extends string;\n * ```\n */\nextern dec maxLength(target: string | ModelProperty, value: valueof integer);\n\n/**\n * Specify the minimum number of items this array should have.\n * @param value Minimum number\n *\n * @example\n * ```typespec\n * @minItems(1)\n * model Endpoints is string[];\n * ```\n */\nextern dec minItems(target: unknown[] | ModelProperty, value: valueof integer);\n\n/**\n * Specify the maximum number of items this array should have.\n * @param value Maximum number\n *\n * @example\n * ```typespec\n * @maxItems(5)\n * model Endpoints is string[];\n * ```\n */\nextern dec maxItems(target: unknown[] | ModelProperty, value: valueof integer);\n\n/**\n * Specify the minimum value this numeric type should be.\n * @param value Minimum value\n *\n * @example\n * ```typespec\n * @minValue(18)\n * scalar Age is int32;\n * ```\n */\nextern dec minValue(target: numeric | ModelProperty, value: valueof numeric);\n\n/**\n * Specify the maximum value this numeric type should be.\n * @param value Maximum value\n *\n * @example\n * ```typespec\n * @maxValue(200)\n * scalar Age is int32;\n * ```\n */\nextern dec maxValue(target: numeric | ModelProperty, value: valueof numeric);\n\n/**\n * Specify the minimum value this numeric type should be, exclusive of the given\n * value.\n * @param value Minimum value\n *\n * @example\n * ```typespec\n * @minValueExclusive(0)\n * scalar distance is float64;\n * ```\n */\nextern dec minValueExclusive(target: numeric | ModelProperty, value: valueof numeric);\n\n/**\n * Specify the maximum value this numeric type should be, exclusive of the given\n * value.\n * @param value Maximum value\n *\n * @example\n * ```typespec\n * @maxValueExclusive(50)\n * scalar distance is float64;\n * ```\n */\nextern dec maxValueExclusive(target: numeric | ModelProperty, value: valueof numeric);\n\n/**\n * Mark this string as a secret value that should be treated carefully to avoid exposure\n *\n * @example\n * ```typespec\n * @secret\n * scalar Password is string;\n * ```\n */\nextern dec secret(target: string | ModelProperty);\n\n/**\n * Attaches a tag to an operation, interface, or namespace. Multiple `@tag` decorators can be specified to attach multiple tags to a TypeSpec element.\n * @param tag Tag value\n */\nextern dec tag(target: Namespace | Interface | Operation, tag: valueof string);\n\n/**\n * Specifies how a templated type should name their instances.\n * @param name name the template instance should take\n * @param formatArgs Model with key value used to interpolate the name\n *\n * @example\n * ```typespec\n * @friendlyName("{name}List", T)\n * model List<Item> {\n *   value: Item[];\n *   nextLink: string;\n * }\n * ```\n */\nextern dec friendlyName(target: unknown, name: valueof string, formatArgs?: unknown);\n\n/**\n * Mark a model property as the key to identify instances of that type\n * @param altName Name of the property. If not specified, the decorated property name is used.\n *\n * @example\n * ```typespec\n * model Pet {\n *   @key id: string;\n * }\n * ```\n */\nextern dec key(target: ModelProperty, altName?: valueof string);\n\n/**\n * Specify this operation is an overload of the given operation.\n * @param overloadbase Base operation that should be a union of all overloads\n *\n * @example\n * ```typespec\n * op upload(data: string | bytes, @header contentType: "text/plain" | "application/octet-stream"): void;\n * @overload(upload)\n * op uploadString(data: string, @header contentType: "text/plain" ): void;\n * @overload(upload)\n * op uploadBytes(data: bytes, @header contentType: "application/octet-stream"): void;\n * ```\n */\nextern dec overload(target: Operation, overloadbase: Operation);\n\n/**\n * Provide an alternative name for this type when serialized to the given mime type.\n * @param mimeType Mime type this should apply to. The mime type should be a known mime type as described here https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types without any suffix (e.g. `+json`)\n * @param name Alternative name\n *\n * @example\n *\n * ```typespec\n * model Certificate {\n *   @encodedName("application/json", "exp")\n *   @encodedName("application/xml", "expiry")\n *   expireAt: int32;\n * }\n * ```\n *\n * @example Invalid values\n *\n * ```typespec\n * @encodedName("application/merge-patch+json", "exp")\n *              ^ error cannot use subtype\n * ```\n */\nextern dec encodedName(target: unknown, mimeType: valueof string, name: valueof string);\n\n/**\n * Options for `@discriminated` decorator.\n */\nmodel DiscriminatedOptions {\n  /**\n   * How is the discriminated union serialized.\n   * @default object\n   */\n  envelope?: "object" | "none";\n\n  /** Name of the discriminator property */\n  discriminatorPropertyName?: string;\n\n  /** Name of the property envelopping the data */\n  envelopePropertyName?: string;\n}\n\n/**\n * Specify that this union is discriminated.\n * @param options Options to configure the serialization of the discriminated union.\n *\n * @example\n *\n * ```typespec\n * @discriminated\n * union Pet{ cat: Cat, dog: Dog }\n *\n * model Cat { name: string, meow: boolean }\n * model Dog { name: string, bark: boolean }\n * ```\n * Serialized as:\n * ```json\n * {\n *   "kind": "cat",\n *   "value": {\n *     "name": "Whiskers",\n *     "meow": true\n *   }\n * },\n * {\n *   "kind": "dog",\n *   "value": {\n *     "name": "Rex",\n *     "bark": false\n *   }\n * }\n * ```\n *\n * @example Custom property names\n *\n * ```typespec\n * @discriminated(#{discriminatorPropertyName: "dataKind", envelopePropertyName: "data"})\n * union Pet{ cat: Cat, dog: Dog }\n *\n * model Cat { name: string, meow: boolean }\n * model Dog { name: string, bark: boolean }\n * ```\n * Serialized as:\n * ```json\n * {\n *   "dataKind": "cat",\n *   "data": {\n *     "name": "Whiskers",\n *     "meow": true\n *   }\n * },\n * {\n *   "dataKind": "dog",\n *   "data": {\n *     "name": "Rex",\n *     "bark": false\n *   }\n * }\n * ```\n */\nextern dec discriminated(target: Union, options?: valueof DiscriminatedOptions);\n\n/**\n * Specify the property to be used to discriminate this type.\n * @param propertyName The property name to use for discrimination\n *\n * @example\n *\n * ```typespec\n * @discriminator("kind")\n * model Pet{ kind: string }\n *\n * model Cat extends Pet {kind: "cat", meow: boolean}\n * model Dog extends Pet  {kind: "dog", bark: boolean}\n * ```\n */\nextern dec discriminator(target: Model, propertyName: valueof string);\n\n/**\n * Known encoding to use on utcDateTime or offsetDateTime\n */\nenum DateTimeKnownEncoding {\n  /**\n   * RFC 3339 standard. https://www.ietf.org/rfc/rfc3339.txt\n   * Encode to string.\n   */\n  rfc3339: "rfc3339",\n\n  /**\n   * RFC 7231 standard. https://www.ietf.org/rfc/rfc7231.txt\n   * Encode to string.\n   */\n  rfc7231: "rfc7231",\n\n  /**\n   * Encode a datetime to a unix timestamp.\n   * Unix timestamps are represented as an integer number of seconds since the Unix epoch and usually encoded as an int32.\n   */\n  unixTimestamp: "unixTimestamp",\n}\n\n/**\n * Known encoding to use on duration\n */\nenum DurationKnownEncoding {\n  /**\n   * ISO8601 duration\n   */\n  ISO8601: "ISO8601",\n\n  /**\n   * Encode to integer or float\n   */\n  seconds: "seconds",\n}\n\n/**\n * Known encoding to use on bytes\n */\nenum BytesKnownEncoding {\n  /**\n   * Encode to Base64\n   */\n  base64: "base64",\n\n  /**\n   * Encode to Base64 Url\n   */\n  base64url: "base64url",\n}\n\n/**\n * Encoding for serializing arrays\n */\nenum ArrayEncoding {\n  /** Each values of the array is separated by a | */\n  pipeDelimited,\n\n  /** Each values of the array is separated by a <space> */\n  spaceDelimited,\n}\n\n/**\n * Specify how to encode the target type.\n * @param encodingOrEncodeAs Known name of an encoding or a scalar type to encode as(Only for numeric types to encode as string).\n * @param encodedAs What target type is this being encoded as. Default to string.\n *\n * @example offsetDateTime encoded with rfc7231\n *\n * ```tsp\n * @encode("rfc7231")\n * scalar myDateTime extends offsetDateTime;\n * ```\n *\n * @example utcDateTime encoded with unixTimestamp\n *\n * ```tsp\n * @encode("unixTimestamp", int32)\n * scalar myDateTime extends unixTimestamp;\n * ```\n *\n * @example encode numeric type to string\n *\n * ```tsp\n * model Pet {\n *   @encode(string) id: int64;\n * }\n * ```\n */\nextern dec encode(\n  target: Scalar | ModelProperty,\n  encodingOrEncodeAs: (valueof string | EnumMember) | Scalar,\n  encodedAs?: Scalar\n);\n\n/** Options for example decorators */\nmodel ExampleOptions {\n  /** The title of the example */\n  title?: string;\n\n  /** Description of the example */\n  description?: string;\n}\n\n/**\n * Provide an example value for a data type.\n *\n * @param example Example value.\n * @param options Optional metadata for the example.\n *\n * @example\n *\n * ```tsp\n * @example(#{name: "Fluffy", age: 2})\n * model Pet {\n *  name: string;\n *  age: int32;\n * }\n * ```\n */\nextern dec example(\n  target: Model | Enum | Scalar | Union | ModelProperty | UnionVariant,\n  example: valueof unknown,\n  options?: valueof ExampleOptions\n);\n\n/**\n * Operation example configuration.\n */\nmodel OperationExample {\n  /** Example request body. */\n  parameters?: unknown;\n\n  /** Example response body. */\n  returnType?: unknown;\n}\n\n/**\n * Provide example values for an operation\'s parameters and corresponding return type.\n *\n * @param example Example value.\n * @param options Optional metadata for the example.\n *\n * @example\n *\n * ```tsp\n * @opExample(#{parameters: #{name: "Fluffy", age: 2}, returnType: #{name: "Fluffy", age: 2, id: "abc"})\n * op createPet(pet: Pet): Pet;\n * ```\n */\nextern dec opExample(\n  target: Operation,\n  example: valueof OperationExample,\n  options?: valueof ExampleOptions\n);\n\n/**\n * Returns the model with required properties removed.\n */\nextern dec withOptionalProperties(target: Model);\n\n/**\n * Returns the model with any default values removed.\n */\nextern dec withoutDefaultValues(target: Model);\n\n/**\n * Returns the model with the given properties omitted.\n * @param omit List of properties to omit\n */\nextern dec withoutOmittedProperties(target: Model, omit: string | Union);\n\n/**\n * Returns the model with only the given properties included.\n * @param pick List of properties to include\n */\nextern dec withPickedProperties(target: Model, pick: string | Union);\n\n//---------------------------------------------------------------------------\n// Paging\n//---------------------------------------------------------------------------\n\n/**\n * Mark this operation as a `list` operation that returns a paginated list of items.\n */\nextern dec list(target: Operation);\n\n/**\n * Pagination property defining the number of items to skip.\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n * }\n * @list op listPets(@offset skip: int32, @pageSize pageSize: int8): Page<Pet>;\n * ```\n */\nextern dec offset(target: ModelProperty);\n\n/**\n * Pagination property defining the page index.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n * }\n * @list op listPets(@pageIndex page: int32, @pageSize pageSize: int8): Page<Pet>;\n * ```\n */\nextern dec pageIndex(target: ModelProperty);\n\n/**\n * Specify the pagination parameter that controls the maximum number of items to include in a page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n * }\n * @list op listPets(@pageIndex page: int32, @pageSize pageSize: int8): Page<Pet>;\n * ```\n */\nextern dec pageSize(target: ModelProperty);\n\n/**\n * Specify the the property that contains the array of page items.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n * }\n * @list op listPets(@pageIndex page: int32, @pageSize pageSize: int8): Page<Pet>;\n * ```\n */\nextern dec pageItems(target: ModelProperty);\n\n/**\n * Pagination property defining the token to get to the next page.\n * It MUST be specified both on the request parameter and the response.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @continuationToken continuationToken: string;\n * }\n * @list op listPets(@continuationToken continuationToken: string): Page<Pet>;\n * ```\n */\nextern dec continuationToken(target: ModelProperty);\n\n/**\n * Pagination property defining a link to the next page.\n *\n * It is expected that navigating to the link will return the same set of responses as the operation that returned the current page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @nextLink next: url;\n *   @prevLink prev: url;\n *   @firstLink first: url;\n *   @lastLink last: url;\n * }\n * @list op listPets(): Page<Pet>;\n * ```\n */\nextern dec nextLink(target: ModelProperty);\n\n/**\n * Pagination property defining a link to the previous page.\n *\n * It is expected that navigating to the link will return the same set of responses as the operation that returned the current page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @nextLink next: url;\n *   @prevLink prev: url;\n *   @firstLink first: url;\n *   @lastLink last: url;\n * }\n * @list op listPets(): Page<Pet>;\n * ```\n */\nextern dec prevLink(target: ModelProperty);\n\n/**\n * Pagination property defining a link to the first page.\n *\n * It is expected that navigating to the link will return the same set of responses as the operation that returned the current page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @nextLink next: url;\n *   @prevLink prev: url;\n *   @firstLink first: url;\n *   @lastLink last: url;\n * }\n * @list op listPets(): Page<Pet>;\n * ```\n */\nextern dec firstLink(target: ModelProperty);\n\n/**\n * Pagination property defining a link to the last page.\n *\n * It is expected that navigating to the link will return the same set of responses as the operation that returned the current page.\n *\n * @example\n * ```tsp\n * model Page<T> {\n *   @pageItems items: T[];\n *   @nextLink next: url;\n *   @prevLink prev: url;\n *   @firstLink first: url;\n *   @lastLink last: url;\n * }\n * @list op listPets(): Page<Pet>;\n * ```\n */\nextern dec lastLink(target: ModelProperty);\n\n//---------------------------------------------------------------------------\n// Debugging\n//---------------------------------------------------------------------------\n\n/**\n * A debugging decorator used to inspect a type.\n * @param text Custom text to log\n */\nextern dec inspectType(target: unknown, text: valueof string);\n\n/**\n * A debugging decorator used to inspect a type name.\n * @param text Custom text to log\n */\nextern dec inspectTypeName(target: unknown, text: valueof string);\n',
  "../../core/packages/compiler/lib/std/reflection.tsp": "namespace TypeSpec.Reflection;\n\nmodel Enum {}\nmodel EnumMember {}\nmodel Interface {}\nmodel Model {}\nmodel ModelProperty {}\nmodel Namespace {}\nmodel Operation {}\nmodel Scalar {}\nmodel Union {}\nmodel UnionVariant {}\nmodel StringTemplate {}\n",
  "../../core/packages/compiler/lib/std/visibility.tsp": '// Copyright (c) Microsoft Corporation\n// Licensed under the MIT license.\n\nimport "../../dist/src/lib/tsp-index.js";\n\nusing TypeSpec.Reflection;\n\nnamespace TypeSpec;\n\n/**\n * Sets the visibility modifiers that are active on a property, indicating that it is only considered to be present\n * (or "visible") in contexts that select for the given modifiers.\n *\n * A property without any visibility settings applied for any visibility class (e.g. `Lifecycle`) is considered to have\n * the default visibility settings for that class.\n *\n * If visibility for the property has already been set for a visibility class (for example, using `@invisible` or\n * `@removeVisibility`), this decorator will **add** the specified visibility modifiers to the property.\n *\n * See: [Visibility](https://typespec.io/docs/language-basics/visibility)\n *\n * The `@typespec/http` library uses `Lifecycle` visibility to determine which properties are included in the request or\n * response bodies of HTTP operations. By default, it uses the following visibility settings:\n *\n * - For the return type of operations, properties are included if they have `Lifecycle.Read` visibility.\n * - For POST operation parameters, properties are included if they have `Lifecycle.Create` visibility.\n * - For PUT operation parameters, properties are included if they have `Lifecycle.Create` or `Lifecycle.Update` visibility.\n * - For PATCH operation parameters, properties are included if they have `Lifecycle.Update` visibility.\n * - For DELETE operation parameters, properties are included if they have `Lifecycle.Delete` visibility.\n * - For GET or HEAD operation parameters, properties are included if they have `Lifecycle.Query` visibility.\n *\n * By default, properties have all five Lifecycle visibility modifiers enabled, so a property is visible in all contexts\n * by default.\n *\n * The default settings may be overridden using the `@returnTypeVisibility` and `@parameterVisibility` decorators.\n *\n * See also: [Automatic visibility](https://typespec.io/docs/libraries/http/operations#automatic-visibility)\n *\n * @param visibilities List of visibilities which apply to this property.\n *\n * @example\n *\n * ```typespec\n * model Dog {\n *   // The service will generate an ID, so you don\'t need to send it.\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   // The service will store this secret name, but won\'t ever return it.\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   // The regular name has all vi\n *   name: string;\n * }\n * ```\n */\nextern dec visibility(target: ModelProperty, ...visibilities: valueof EnumMember[]);\n\n/**\n * Indicates that a property is not visible in the given visibility class.\n *\n * This decorator removes all active visibility modifiers from the property within\n * the given visibility class, making it invisible to any context that selects for\n * visibility modifiers within that class.\n *\n * @param visibilityClass The visibility class to make the property invisible within.\n *\n * @example\n * ```typespec\n * model Example {\n *   @invisible(Lifecycle)\n *   hidden_property: string;\n * }\n * ```\n */\nextern dec invisible(target: ModelProperty, visibilityClass: Enum);\n\n/**\n * Removes visibility modifiers from a property.\n *\n * If the visibility modifiers for a visibility class have not been initialized,\n * this decorator will use the default visibility modifiers for the visibility\n * class as the default modifier set.\n *\n * @param target The property to remove visibility from.\n * @param visibilities The visibility modifiers to remove from the target property.\n *\n * @example\n * ```typespec\n * model Example {\n *   // This property will have all Lifecycle visibilities except the Read\n *   // visibility, since it is removed.\n *   @removeVisibility(Lifecycle.Read)\n *   secret_property: string;\n * }\n * ```\n */\nextern dec removeVisibility(target: ModelProperty, ...visibilities: valueof EnumMember[]);\n\n/**\n * Removes properties that do not have at least one of the given visibility modifiers\n * active.\n *\n * If no visibility modifiers are supplied, this decorator has no effect.\n *\n * See also: [Automatic visibility](https://typespec.io/docs/libraries/http/operations#automatic-visibility)\n *\n * When using an emitter that applies visibility automatically, it is generally\n * not necessary to use this decorator.\n *\n * @param visibilities List of visibilities that apply to this property.\n *\n * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * // The spread operator will copy all the properties of Dog into DogRead,\n * // and @withVisibility will then remove those that are not visible with\n * // create or update visibility.\n * //\n * // In this case, the id property is removed, and the name and secretName\n * // properties are kept.\n * @withVisibility(Lifecycle.Create, Lifecycle.Update)\n * model DogCreateOrUpdate {\n *   ...Dog;\n * }\n *\n * // In this case the id and name properties are kept and the secretName property\n * // is removed.\n * @withVisibility(Lifecycle.Read)\n * model DogRead {\n *   ...Dog;\n * }\n * ```\n */\nextern dec withVisibility(target: Model, ...visibilities: valueof EnumMember[]);\n\n/**\n * Set the visibility of key properties in a model if not already set.\n *\n * This will set the visibility modifiers of all key properties in the model if the visibility is not already _explicitly_ set,\n * but will not change the visibility of any properties that have visibility set _explicitly_, even if the visibility\n * is the same as the default visibility.\n *\n * Visibility may be set explicitly using any of the following decorators:\n *\n * - `@visibility`\n * - `@removeVisibility`\n * - `@invisible`\n *\n * @param visibility The desired default visibility value. If a key property already has visibility set, it will not be changed.\n */\nextern dec withDefaultKeyVisibility(target: Model, visibility: valueof EnumMember);\n\n/**\n * Declares the visibility constraint of the parameters of a given operation.\n *\n * A parameter or property nested within a parameter will be visible if it has _any_ of the visibilities\n * in the list.\n *\n * It is invalid to call this decorator with no visibility modifiers.\n *\n * @param visibilities List of visibility modifiers that apply to the parameters of this operation.\n */\nextern dec parameterVisibility(target: Operation, ...visibilities: valueof EnumMember[]);\n\n/**\n * Declares the visibility constraint of the return type of a given operation.\n *\n * A property within the return type of the operation will be visible if it has _any_ of the visibilities\n * in the list.\n *\n * It is invalid to call this decorator with no visibility modifiers.\n *\n * @param visibilities List of visibility modifiers that apply to the return type of this operation.\n */\nextern dec returnTypeVisibility(target: Operation, ...visibilities: valueof EnumMember[]);\n\n/**\n * Returns the model with non-updateable properties removed.\n */\nextern dec withUpdateableProperties(target: Model);\n\n/**\n * Declares the default visibility modifiers for a visibility class.\n *\n * The default modifiers are used when a property does not have any visibility decorators\n * applied to it.\n *\n * The modifiers passed to this decorator _MUST_ be members of the target Enum.\n *\n * @param visibilities the list of modifiers to use as the default visibility modifiers.\n */\nextern dec defaultVisibility(target: Enum, ...visibilities: valueof EnumMember[]);\n\n/**\n * A visibility class for resource lifecycle phases.\n *\n * These visibilities control whether a property is visible during the various phases of a resource\'s lifecycle.\n *\n * @example\n * ```typespec\n * model Dog {\n *  @visibility(Lifecycle.Read)\n *  id: int32;\n *\n *  @visibility(Lifecycle.Create, Lifecycle.Update)\n *  secretName: string;\n *\n *  name: string;\n * }\n * ```\n *\n * In this example, the `id` property is only visible during the read phase, and the `secretName` property is only visible\n * during the create and update phases. This means that the server will return the `id` property when returning a `Dog`,\n * but the client will not be able to set or update it. In contrast, the `secretName` property can be set when creating\n * or updating a `Dog`, but the server will never return it. The `name` property has no visibility modifiers and is\n * therefore visible in all phases.\n */\nenum Lifecycle {\n  /**\n   * The property is visible when a resource is being created.\n   */\n  Create,\n\n  /**\n   * The property is visible when a resource is being read.\n   */\n  Read,\n\n  /**\n   * The property is visible when a resource is being updated.\n   */\n  Update,\n\n  /**\n   * The property is visible when a resource is being deleted.\n   */\n  Delete,\n\n  /**\n   * The property is visible when a resource is being queried.\n   *\n   * In HTTP APIs, this visibility applies to parameters of GET or HEAD operations.\n   */\n  Query,\n}\n\n/**\n * A visibility filter, used to specify which properties should be included when\n * using the `withVisibilityFilter` decorator.\n *\n * The filter matches any property with ALL of the following:\n * - If the `any` key is present, the property must have at least one of the specified visibilities.\n * - If the `all` key is present, the property must have all of the specified visibilities.\n * - If the `none` key is present, the property must have none of the specified visibilities.\n */\nmodel VisibilityFilter {\n  any?: EnumMember[];\n  all?: EnumMember[];\n  none?: EnumMember[];\n}\n\n/**\n * Applies the given visibility filter to the properties of the target model.\n *\n * This transformation is recursive, so it will also apply the filter to any nested\n * or referenced models that are the types of any properties in the `target`.\n *\n * If a `nameTemplate` is provided, newly-created type instances will be named according\n * to the template. See the `@friendlyName` decorator for more information on the template\n * syntax. The transformed type is provided as the argument to the template.\n *\n * @param target The model to apply the visibility filter to.\n * @param filter The visibility filter to apply to the properties of the target model.\n * @param nameTemplate The name template to use when renaming new model instances.\n *\n * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   name: string;\n * }\n *\n * @withVisibilityFilter(#{ all: #[Lifecycle.Read] })\n * model DogRead {\n *  ...Dog\n * }\n * ```\n */\nextern dec withVisibilityFilter(\n  target: Model,\n  filter: valueof VisibilityFilter,\n  nameTemplate?: valueof string\n);\n\n/**\n * Transforms the `target` model to include only properties that are visible during the\n * "Update" lifecycle phase.\n *\n * Any nested models of optional properties will be transformed into the "CreateOrUpdate"\n * lifecycle phase instead of the "Update" lifecycle phase, so that nested models may be\n * fully updated.\n *\n * If a `nameTemplate` is provided, newly-created type instances will be named according\n * to the template. See the `@friendlyName` decorator for more information on the template\n * syntax. The transformed type is provided as the argument to the template.\n *\n * @param target The model to apply the transformation to.\n * @param nameTemplate The name template to use when renaming new model instances.\n *\n * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * @withLifecycleUpdate\n * model DogUpdate {\n *   ...Dog\n * }\n * ```\n */\nextern dec withLifecycleUpdate(target: Model, nameTemplate?: valueof string);\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Create" resource lifecycle phase.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Create` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   name: string;\n * }\n *\n * // This model has only the `name` field.\n * model CreateDog is Create<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ all: #[Lifecycle.Create] }, NameTemplate)\nmodel Create<T extends Reflection.Model, NameTemplate extends valueof string = "Create{name}"> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Read" resource lifecycle phase.\n *\n * The "Read" lifecycle phase is used for properties returned by operations that read data, like\n * HTTP GET operations.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Read` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * // This model has the `id` and `name` fields, but not `secretName`.\n * model ReadDog is Read<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ all: #[Lifecycle.Read] }, NameTemplate)\nmodel Read<T extends Reflection.Model, NameTemplate extends valueof string = "Read{name}"> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Update" resource lifecycle phase.\n *\n * The "Update" lifecycle phase is used for properties passed as parameters to operations\n * that update data, like HTTP PATCH operations.\n *\n * This transformation will include only the properties that have the `Lifecycle.Update`\n * visibility modifier, and the types of all properties will be replaced with the\n * equivalent `CreateOrUpdate` transformation.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * // This model will have the `secretName` and `name` fields, but not the `id` field.\n * model UpdateDog is Update<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withLifecycleUpdate(NameTemplate)\nmodel Update<T extends Reflection.Model, NameTemplate extends valueof string = "Update{name}"> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Create" or "Update" resource lifecycle phases.\n *\n * The "CreateOrUpdate" lifecycle phase is used by default for properties passed as parameters to operations\n * that can create _or_ update data, like HTTP PUT operations.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Create` or `Lifecycle.Update` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   @visibility(Lifecycle.Create)\n *   immutableSecret: string;\n *\n *   @visibility(Lifecycle.Create, Lifecycle.Update)\n *   secretName: string;\n *\n *   name: string;\n * }\n *\n * // This model will have the `immutableSecret`, `secretName`, and `name` fields, but not the `id` field.\n * model CreateOrUpdateDog is CreateOrUpdate<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ any: #[Lifecycle.Create, Lifecycle.Update] }, NameTemplate)\nmodel CreateOrUpdate<\n  T extends Reflection.Model,\n  NameTemplate extends valueof string = "CreateOrUpdate{name}"\n> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Delete" resource lifecycle phase.\n *\n * The "Delete" lifecycle phase is used for properties passed as parameters to operations\n * that delete data, like HTTP DELETE operations.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Delete` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   // Set when the Dog is removed from our data store. This happens when the\n *   // Dog is re-homed to a new owner.\n *   @visibility(Lifecycle.Delete)\n *   nextOwner: string;\n *\n *   name: string;\n * }\n *\n * // This model will have the `nextOwner` and `name` fields, but not the `id` field.\n * model DeleteDog is Delete<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ all: #[Lifecycle.Delete] }, NameTemplate)\nmodel Delete<T extends Reflection.Model, NameTemplate extends valueof string = "Delete{name}"> {\n  ...T;\n}\n\n/**\n * A copy of the input model `T` with only the properties that are visible during the\n * "Query" resource lifecycle phase.\n *\n * The "Query" lifecycle phase is used for properties passed as parameters to operations\n * that read data, like HTTP GET or HEAD operations. This should not be confused for\n * the `@query` decorator, which specifies that the property is transmitted in the\n * query string of an HTTP request.\n *\n * This transformation is recursive, and will include only properties that have the\n * `Lifecycle.Query` visibility modifier.\n *\n * If a `NameTemplate` is provided, the new model will be named according to the template.\n * The template uses the same syntax as the `@friendlyName` decorator.\n *\n * @template T The model to transform.\n * @template NameTemplate The name template to use for the new model.\n *\n *  * @example\n * ```typespec\n * model Dog {\n *   @visibility(Lifecycle.Read)\n *   id: int32;\n *\n *   // When getting information for a Dog, you can set this field to true to include\n *   // some extra information about the Dog\'s pedigree that is normally not returned.\n *   // Alternatively, you could just use a separate option parameter to get this\n *   // information.\n *   @visibility(Lifecycle.Query)\n *   includePedigree?: boolean;\n *\n *   name: string;\n *\n *   // Only included if `includePedigree` is set to true in the request.\n *   @visibility(Lifecycle.Read)\n *   pedigree?: string;\n * }\n *\n * // This model will have the `includePedigree` and `name` fields, but not `id` or `pedigree`.\n * model QueryDog is Query<Dog>;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@withVisibilityFilter(#{ all: #[Lifecycle.Query] }, NameTemplate)\nmodel Query<T extends Reflection.Model, NameTemplate extends valueof string = "Query{name}"> {\n  ...T;\n}\n',
  "lib/arm.tsp": 'import "../dist/src/tsp-index.js";\nimport "@typespec/openapi";\nimport "@typespec/http";\nimport "@typespec/rest";\nimport "@typespec/versioning";\nimport "@azure-tools/typespec-azure-core";\n\nimport "./foundations/arm.foundations.tsp";\nimport "./Legacy/arm.legacy.tsp";\nimport "./common-types/common-types.tsp";\nimport "./backcompat.tsp";\nimport "./private.decorators.tsp";\nimport "./models.tsp";\nimport "./operations.tsp";\nimport "./decorators.tsp";\nimport "./interfaces.tsp";\nimport "./responses.tsp";\nimport "./parameters.tsp";\n\nusing Http;\nusing Rest;\nusing Versioning;\nusing OpenAPI;\nusing Azure.ResourceManager.Foundations;\n\n@versioned(Azure.ResourceManager.Versions)\nnamespace Azure.ResourceManager;\n\n/**\n * Supported versions of Azure.ResourceManager building blocks.\n */\n@doc("Supported versions of Azure.ResourceManager building blocks.")\nenum Versions {\n  @doc("Version 1.0-preview.1")\n  @useDependency(Azure.Core.Versions.v1_0_Preview_2)\n  v1_0_Preview_1: "1.0-preview.1",\n}\n',
  "../../core/packages/openapi/lib/main.tsp": 'import "../dist/src/tsp-index.js";\nimport "./decorators.tsp";\n',
  "../../core/packages/openapi/lib/decorators.tsp": 'using TypeSpec.Reflection;\n\nnamespace TypeSpec.OpenAPI;\n\n/**\n * Specify the OpenAPI `operationId` property for this operation.\n *\n * @param operationId Operation id value.\n *\n * @example\n *\n * ```typespec\n * @operationId("download")\n * op read(): string;\n * ```\n */\nextern dec operationId(target: Operation, operationId: valueof string);\n\n/**\n * Attach some custom data to the OpenAPI element generated from this type.\n *\n * @param key Extension key.\n * @param value Extension value.\n *\n * @example\n *\n * ```typespec\n * @extension("x-custom", "My value")\n * @extension("x-pageable", #{nextLink: "x-next-link"})\n * op read(): string;\n * ```\n */\nextern dec extension(target: unknown, key: valueof string, value: valueof unknown);\n\n/**\n * Specify that this model is to be treated as the OpenAPI `default` response.\n * This differs from the compiler built-in `@error` decorator as this does not necessarily represent an error.\n *\n * @example\n *\n * ```typespec\n * @defaultResponse\n * model PetStoreResponse is object;\n *\n * op listPets(): Pet[] | PetStoreResponse;\n * ```\n */\nextern dec defaultResponse(target: Model);\n\n/**\n * Specify the OpenAPI `externalDocs` property for this type.\n *\n * @param url Url to the docs\n * @param description Description of the docs\n *\n * @example\n * ```typespec\n * @externalDocs("https://example.com/detailed.md", "Detailed information on how to use this operation")\n * op listPets(): Pet[];\n * ```\n */\nextern dec externalDocs(target: unknown, url: valueof string, description?: valueof string);\n\n/** Additional information for the OpenAPI document. */\nmodel AdditionalInfo {\n  /** The title of the API. Overrides the `@service` title. */\n  title?: string;\n\n  /** A short summary of the API. Overrides the `@summary` provided on the service namespace. */\n  summary?: string;\n\n  /** The version of the OpenAPI document (which is distinct from the OpenAPI Specification version or the API implementation version). */\n  version?: string;\n\n  /** A URL to the Terms of Service for the API. MUST be in the format of a URL. */\n  termsOfService?: url;\n\n  /** The contact information for the exposed API. */\n  contact?: Contact;\n\n  /** The license information for the exposed API. */\n  license?: License;\n\n  ...Record<unknown>;\n}\n\n/** Contact information for the exposed API. */\nmodel Contact {\n  /** The identifying name of the contact person/organization. */\n  name?: string;\n\n  /** The URL pointing to the contact information. MUST be in the format of a URL. */\n  url?: url;\n\n  /** The email address of the contact person/organization. MUST be in the format of an email address. */\n  email?: string;\n\n  ...Record<unknown>;\n}\n\n/** License information for the exposed API. */\nmodel License {\n  /** The license name used for the API. */\n  name: string;\n\n  /** A URL to the license used for the API. MUST be in the format of a URL. */\n  url?: url;\n\n  ...Record<unknown>;\n}\n\n/**\n * Specify OpenAPI additional information.\n * The service `title` and `version` are already specified using `@service`.\n * @param additionalInfo Additional information\n */\nextern dec info(target: Namespace, additionalInfo: valueof AdditionalInfo);\n\n/** Metadata to a single tag that is used by operations. */\nmodel TagMetadata {\n  /** A description of the API. */\n  description?: string;\n\n  /** An external Docs information of the API. */\n  externalDocs?: ExternalDocs;\n\n  /** Attach some custom data, The extension key must start with `x-`. */\n  ...Record<unknown>;\n}\n\n/** External Docs information. */\nmodel ExternalDocs {\n  /** Documentation url */\n  url: string;\n\n  /** Optional description */\n  description?: string;\n\n  /** Attach some custom data, The extension key must start with `x-`. */\n  ...Record<unknown>;\n}\n\n/**\n * Specify OpenAPI additional information.\n * @param name tag name\n * @param tagMetadata Additional information\n *\n * @example\n * ```typespec\n * @service()\n * @tagMetadata("Tag Name", #{description: "Tag description", externalDocs: #{url: "https://example.com", description: "More info.", `x-custom`: "string"}, `x-custom`: "string"})\n * namespace PetStore {}\n * ```\n */\nextern dec tagMetadata(target: Namespace, name: valueof string, tagMetadata: valueof TagMetadata);\n',
  "../../core/packages/http/lib/main.tsp": 'import "../dist/src/tsp-index.js";\nimport "./decorators.tsp";\nimport "./private.decorators.tsp";\nimport "./auth.tsp";\n\nnamespace TypeSpec.Http;\n\nusing Private;\n\n/**\n * Describes an HTTP response.\n *\n * @template Status The status code of the response.\n */\n@doc("")\nmodel Response<Status> {\n  @doc("The status code.")\n  @statusCode\n  statusCode: Status;\n}\n\n/**\n * Defines a model with a single property of the given type, marked with `@body`.\n *\n * This can be useful in situations where you cannot use a bare type as the body\n * and it is awkward to add a property.\n *\n * @template Type The type of the model\'s `body` property.\n */\n@doc("")\nmodel Body<Type> {\n  @body\n  @doc("The body type of the operation request or response.")\n  body: Type;\n}\n\n/**\n * The Location header contains the URL where the status of the long running operation can be checked.\n */\nmodel LocationHeader {\n  @doc("The Location header contains the URL where the status of the long running operation can be checked.")\n  @header\n  location: string;\n}\n\n// Don\'t put @doc on these, change `getStatusCodeDescription` implementation\n// to update the default descriptions for these status codes. This ensures\n// that we get consistent emit between different ways to spell the same\n// responses in TypeSpec.\n\n/**\n * The request has succeeded.\n */\nmodel OkResponse is Response<200>;\n/**\n * The request has succeeded and a new resource has been created as a result.\n */\nmodel CreatedResponse is Response<201>;\n/**\n * The request has been accepted for processing, but processing has not yet completed.\n */\nmodel AcceptedResponse is Response<202>;\n/**\n * There is no content to send for this request, but the headers may be useful.\n */\nmodel NoContentResponse is Response<204>;\n/**\n * The URL of the requested resource has been changed permanently. The new URL is given in the response.\n */\nmodel MovedResponse is Response<301> {\n  ...LocationHeader;\n}\n/**\n * The client has made a conditional request and the resource has not been modified.\n */\nmodel NotModifiedResponse is Response<304>;\n/**\n * The server could not understand the request due to invalid syntax.\n */\nmodel BadRequestResponse is Response<400>;\n/**\n * Access is unauthorized.\n */\nmodel UnauthorizedResponse is Response<401>;\n/**\n * Access is forbidden.\n */\nmodel ForbiddenResponse is Response<403>;\n/**\n * The server cannot find the requested resource.\n */\nmodel NotFoundResponse is Response<404>;\n/**\n * The request conflicts with the current state of the server.\n */\nmodel ConflictResponse is Response<409>;\n\n/**\n * Produces a new model with the same properties as T, but with `@query`,\n * `@header`, `@body`, and `@path` decorators removed from all properties.\n *\n * @template Data The model to spread as the plain data.\n */\n@plainData\nmodel PlainData<Data> {\n  ...Data;\n}\n\n/**\n * A file in an HTTP request, response, or multipart payload.\n *\n * Files have a special meaning that the HTTP library understands. When the body of an HTTP request, response,\n * or multipart payload is _effectively_ an instance of `TypeSpec.Http.File` or any type that extends it, the\n * operation is treated as a file upload or download.\n *\n * When using file bodies, the fields of the file model are defined to come from particular locations by default:\n *\n * - `contentType`: The `Content-Type` header of the request, response, or multipart payload (CANNOT be overridden or changed).\n * - `contents`: The body of the request, response, or multipart payload (CANNOT be overridden or changed).\n * - `filename`: The `filename` parameter value of the `Content-Disposition` header of the response or multipart payload\n *   (MAY be overridden or changed).\n *\n * A File may be used as a normal structured JSON object in a request or response, if the request specifies an explicit\n * `Content-Type` header. In this case, the entire File model is serialized as if it were any other model. In a JSON payload,\n * it will have a structure like:\n *\n * ```\n * {\n *   "contentType": <string?>,\n *   "filename": <string?>,\n *   "contents": <string, base64>\n * }\n * ```\n *\n * The `contentType` _within_ the file defines what media types the data inside the file can be, but if the specification\n * defines a `Content-Type` for the payload as HTTP metadata, that `Content-Type` metadata defines _how the file is\n * serialized_. See the examples below for more information.\n *\n * NOTE: The `filename` and `contentType` fields are optional. Furthermore, the default location of `filename`\n * (`Content-Disposition: <disposition>; filename=<filename>`) is only valid in HTTP responses and multipart payloads. If\n * you wish to send the `filename` in a request, you must use HTTP metadata decorators to describe the location of the\n * `filename` field. You can combine the metadata decorators with `@visibility` to control when the `filename` location\n * is overridden, as shown in the examples below.\n *\n * @template ContentType The allowed media (MIME) types of the file contents.\n * @template Contents The type of the file contents. This can be `string`, `bytes`, or any scalar that extends them.\n *\n * @example\n * ```tsp\n * // Download a file\n * @get op download(): File;\n *\n * // Upload a file\n * @post op upload(@bodyRoot file: File): void;\n * ```\n *\n * @example\n * ```tsp\n * // Upload and download files in a multipart payload\n * op multipartFormDataUpload(\n *   @multipartBody fields: {\n *     files: HttpPart<File>[];\n *   },\n * ): void;\n *\n * op multipartFormDataDownload(): {\n *   @multipartBody formFields: {\n *     files: HttpPart<File>[];\n *   }\n * };\n * ```\n *\n * @example\n * ```tsp\n * // Declare a custom type of text file, where the filename goes in the path\n * // in requests.\n * model SpecFile extends File<"application/json" | "application/yaml", string> {\n *   // Provide a header that contains the name of the file when created or updated\n *   @header("x-filename")\n *   @path filename: string;\n * }\n *\n * @get op downloadSpec(@path name: string): SpecFile;\n *\n * @post op uploadSpec(@bodyRoot spec: SpecFile): void;\n * ```\n *\n * @example\n * ```tsp\n * // Declare a custom type of binary file\n * model ImageFile extends File {\n *   contentType: "image/png" | "image/jpeg";\n *   @path filename: string;\n * }\n *\n * @get op downloadImage(@path name: string): ImageFile;\n *\n * @post op uploadImage(@bodyRoot image: ImageFile): void;\n * ```\n *\n * @example\n * ```tsp\n * // Use a File as a structured JSON object. The HTTP library will warn you that the File will be serialized as JSON,\n * // so you should suppress the warning if it\'s really what you want instead of a binary file upload/download.\n *\n * // The response body is a JSON object like `{"contentType":<string?>,"filename":<string?>,"contents":<string>}`\n * @get op downloadTextFileJson(): {\n *   @header contentType: "application/json",\n *   @body file: File<"text/plain", string>,\n * };\n *\n * // The request body is a JSON object like `{"contentType":<string?>,"filename":<string?>,"contents":<base64>}`\n * @post op uploadBinaryFileJson(\n *   @header contentType: "application/json",\n *   @body file: File<"image/png", bytes>,\n * ): void;\n *\n */\n@summary("A file in an HTTP request, response, or multipart payload.")\n@Private.httpFile\nmodel File<ContentType extends string = string, Contents extends bytes | string = bytes> {\n  /**\n   * The allowed media (MIME) types of the file contents.\n   *\n   * In file bodies, this value comes from the `Content-Type` header of the request or response. In JSON bodies,\n   * this value is serialized as a field in the response.\n   *\n   * NOTE: this is not _necessarily_ the same as the `Content-Type` header of the request or response, but\n   * it will be for file bodies. It may be different if the file is serialized as a JSON object. It always refers to the\n   * _contents_ of the file, and not necessarily the way the file itself is transmitted or serialized.\n   */\n  @summary("The allowed media (MIME) types of the file contents.")\n  contentType?: ContentType;\n\n  /**\n   * The name of the file, if any.\n   *\n   * In file bodies, this value comes from the `filename` parameter of the `Content-Disposition` header of the response\n   * or multipart payload. In JSON bodies, this value is serialized as a field in the response.\n   *\n   * NOTE: By default, `filename` cannot be sent in request payloads and can only be sent in responses and multipart\n   * payloads, as the `Content-Disposition` header is not valid in requests. If you want to send the `filename` in a request,\n   * you must extend the `File` model and override the `filename` property with a different location defined by HTTP metadata\n   * decorators.\n   */\n  @summary("The name of the file, if any.")\n  filename?: string;\n\n  /**\n   * The contents of the file.\n   *\n   * In file bodies, this value comes from the body of the request, response, or multipart payload. In JSON bodies,\n   * this value is serialized as a field in the response.\n   */\n  @summary("The contents of the file.")\n  contents: Contents;\n}\n\nmodel HttpPartOptions {\n  /** Name of the part when using the array form. */\n  name?: string;\n}\n\n@Private.httpPart(Type, Options)\nmodel HttpPart<Type, Options extends valueof HttpPartOptions = #{}> {}\n\nmodel Link {\n  target: url;\n  rel: string;\n  attributes?: Record<unknown>;\n}\n\nscalar LinkHeader<T extends Record<url> | Link[]> extends string;\n\n/**\n * Create a MergePatch Request body for updating the given resource Model.\n * The MergePatch request created by this template provides a TypeSpec description of a\n * JSON MergePatch request that can successfully update the given resource.\n * The transformation follows the definition of JSON MergePatch requests in\n * rfc 7396: https://www.rfc-editor.org/rfc/rfc7396,\n * applying the merge-patch transform recursively to keyed types in the resource Model.\n *\n * Using this template in a PATCH request body overrides the `implicitOptionality`\n * setting for PATCH operations and sets `application/merge-patch+json` as the request\n * content-type.\n *\n * @template T The type of the resource to create a MergePatch update request body for.\n * @template NameTemplate A StringTemplate used to name any models created by applying\n * the merge-patch transform to the resource. The default name template is `{name}MergePatchUpdate`,\n * for example, the merge patch transform of model `Widget` is named `WidgetMergePatchUpdate`.\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(@body request: MergePatchUpdate<Widget>): Widget;\n * ```\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(@bodyRoot request: MergePatchUpdate<Widget>): Widget;\n * ```\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(...MergePatchUpdate<Widget>): Widget;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@mediaTypeHint("application/merge-patch+json")\n@applyMergePatch(T, NameTemplate, #{ visibilityMode: Private.MergePatchVisibilityMode.Update })\nmodel MergePatchUpdate<\n  T extends Reflection.Model,\n  NameTemplate extends valueof string = "{name}MergePatchUpdate"\n> {}\n\n/**\n * Create a MergePatch Request body for creating or updating the given resource Model.\n * The MergePatch request created by this template provides a TypeSpec description of a\n * JSON MergePatch request that can successfully create or update the given resource.\n * The transformation follows the definition of JSON MergePatch requests in\n * rfc 7396: https://www.rfc-editor.org/rfc/rfc7396,\n * applying the merge-patch transform recursively to keyed types in the resource Model.\n *\n * Using this template in a PATCH request body overrides the `implicitOptionality`\n * setting for PATCH operations and sets `application/merge-patch+json` as the request\n * content-type.\n *\n * @template T The type of the resource to create a MergePatch update request body for.\n * @template NameTemplate A StringTemplate used to name any models created by applying\n * the merge-patch transform to the resource. The default name template is `{name}MergePatchCreateOrUpdate`,\n * for example, the merge patch transform of model `Widget` is named `WidgetMergePatchCreateOrUpdate`.\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(@body request: MergePatchCreateOrUpdate<Widget>): Widget;\n * ```\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(@bodyRoot request: MergePatchCreateOrUpdate<Widget>): Widget;\n * ```\n *\n * @example\n * ```tsp\n * // An operation updating a \'Widget\' using merge-patch\n * @patch op update(...MergePatchCreateOrUpdate<Widget>): Widget;\n * ```\n */\n@doc("")\n@friendlyName(NameTemplate, T)\n@mediaTypeHint("application/merge-patch+json")\n@applyMergePatch(\n  T,\n  NameTemplate,\n  #{ visibilityMode: Private.MergePatchVisibilityMode.CreateOrUpdate }\n)\nmodel MergePatchCreateOrUpdate<\n  T extends Reflection.Model,\n  NameTemplate extends valueof string = "{name}MergePatchCreateOrUpdate"\n> {}\n',
  "../../core/packages/http/lib/decorators.tsp": 'namespace TypeSpec.Http;\n\nusing TypeSpec.Reflection;\n\n/**\n * Header options.\n */\nmodel HeaderOptions {\n  /**\n   * Name of the header when sent over HTTP.\n   */\n  name?: string;\n\n  /**\n   * Equivalent of adding `*` in the path parameter as per [RFC-6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n   *\n   *  | Style  | Explode | Primitive value = 5 | Array = [3, 4, 5] | Object = {"role": "admin", "firstName": "Alex"} |\n   *  | ------ | ------- | ------------------- | ----------------- | ----------------------------------------------- |\n   *  | simple | false   | `5   `              | `3,4,5`           | `role,admin,firstName,Alex`                     |\n   *  | simple | true    | `5`                 | `3,4,5`           | `role=admin,firstName=Alex`                     |\n   *\n   */\n  explode?: boolean;\n}\n\n/**\n * Specify this property is to be sent or received as an HTTP header.\n *\n * @param headerNameOrOptions Optional name of the header when sent over HTTP or header options.\n *  By default the header name will be the property name converted from camelCase to kebab-case. (e.g. `contentType` -> `content-type`)\n *\n * @example\n *\n * ```typespec\n * op read(@header accept: string): {@header("ETag") eTag: string};\n * op create(@header({name: "X-Color", format: "csv"}) colors: string[]): void;\n * ```\n *\n * @example Implicit header name\n *\n * ```typespec\n * op read(): {@header contentType: string}; // headerName: content-type\n * op update(@header ifMatch: string): void; // headerName: if-match\n * ```\n */\nextern dec header(target: ModelProperty, headerNameOrOptions?: valueof string | HeaderOptions);\n\n/**\n * Cookie Options.\n */\nmodel CookieOptions {\n  /**\n   * Name in the cookie.\n   */\n  name?: string;\n}\n\n/**\n * Specify this property is to be sent or received in the cookie.\n *\n * @param cookieNameOrOptions Optional name of the cookie in the cookie or cookie options.\n *  By default the cookie name will be the property name converted from camelCase to snake_case. (e.g. `authToken` -> `auth_token`)\n *\n * @example\n *\n * ```typespec\n * op read(@cookie token: string): {data: string[]};\n * op create(@cookie({name: "auth_token"}) data: string[]): void;\n * ```\n *\n * @example Implicit header name\n *\n * ```typespec\n * op read(): {@cookie authToken: string}; // headerName: auth_token\n * op update(@cookie AuthToken: string): void; // headerName: auth_token\n * ```\n */\nextern dec cookie(target: ModelProperty, cookieNameOrOptions?: valueof string | CookieOptions);\n\n/**\n * Query parameter options.\n */\nmodel QueryOptions {\n  /**\n   * Name of the query when included in the url.\n   */\n  name?: string;\n\n  /**\n   * If true send each value in the array/object as a separate query parameter.\n   * Equivalent of adding `*` in the path parameter as per [RFC-6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n   *\n   *  | Style  | Explode | Uri Template   | Primitive value id = 5 | Array id = [3, 4, 5]    | Object id = {"role": "admin", "firstName": "Alex"} |\n   *  | ------ | ------- | -------------- | ---------------------- | ----------------------- | -------------------------------------------------- |\n   *  | simple | false   | `/users{?id}`  | `/users?id=5`          | `/users?id=3,4,5`       | `/users?id=role,admin,firstName,Alex`              |\n   *  | simple | true    | `/users{?id*}` | `/users?id=5`          | `/users?id=3&id=4&id=5` | `/users?role=admin&firstName=Alex`                 |\n   *\n   */\n  explode?: boolean;\n}\n\n/**\n * Specify this property is to be sent as a query parameter.\n *\n * @param queryNameOrOptions Optional name of the query when included in the url or query parameter options.\n *\n * @example\n *\n * ```typespec\n * op read(@query select: string, @query("order-by") orderBy: string): void;\n * op list(@query(#{name: "id", explode: true}) ids: string[]): void;\n * ```\n */\nextern dec query(target: ModelProperty, queryNameOrOptions?: valueof string | QueryOptions);\n\nmodel PathOptions {\n  /** Name of the parameter in the uri template. */\n  name?: string;\n\n  /**\n   * When interpolating this parameter in the case of array or object expand each value using the given style.\n   * Equivalent of adding `*` in the path parameter as per [RFC-6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n   */\n  explode?: boolean;\n\n  /**\n   * Different interpolating styles for the path parameter.\n   * - `simple`: No special encoding.\n   * - `label`: Using `.` separator.\n   * - `matrix`: `;` as separator.\n   * - `fragment`: `#` as separator.\n   * - `path`: `/` as separator.\n   */\n  style?: "simple" | "label" | "matrix" | "fragment" | "path";\n\n  /**\n   * When interpolating this parameter do not encode reserved characters.\n   * Equivalent of adding `+` in the path parameter as per [RFC-6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n   */\n  allowReserved?: boolean;\n}\n\n/**\n * Explicitly specify that this property is to be interpolated as a path parameter.\n *\n * @param paramNameOrOptions Optional name of the parameter in the uri template or options.\n *\n * @example\n *\n * ```typespec\n * @route("/read/{explicit}/things/{implicit}")\n * op read(@path explicit: string, implicit: string): void;\n * ```\n */\nextern dec path(target: ModelProperty, paramNameOrOptions?: valueof string | PathOptions);\n\n/**\n * Explicitly specify that this property type will be exactly the HTTP body.\n *\n * This means that any properties under `@body` cannot be marked as headers, query parameters, or path parameters.\n * If wanting to change the resolution of the body but still mix parameters, use `@bodyRoot`.\n *\n * @example\n *\n * ```typespec\n * op upload(@body image: bytes): void;\n * op download(): {@body image: bytes};\n * ```\n */\nextern dec body(target: ModelProperty);\n\n/**\n * Specify that the body resolution should be resolved from that property.\n * By default the body is resolved by including all properties in the operation request/response that are not metadata.\n * This allows to nest the body in a property while still allowing to use headers, query parameters, and path parameters in the same model.\n *\n * @example\n *\n * ```typespec\n * op upload(@bodyRoot user: {name: string, @header id: string}): void;\n * op download(): {@bodyRoot user: {name: string, @header id: string}};\n * ```\n */\nextern dec bodyRoot(target: ModelProperty);\n/**\n * Specify that this property shouldn\'t be included in the HTTP body.\n * This can be useful when bundling metadata together that would result in an empty property to be included in the body.\n *\n * @example\n *\n * ```typespec\n * op upload(name: string, @bodyIgnore headers: {@header id: string}): void;\n * ```\n */\nextern dec bodyIgnore(target: ModelProperty);\n\n/**\n * @example\n *\n * ```tsp\n * op upload(\n *   @header `content-type`: "multipart/form-data",\n *   @multipartBody body: {\n *     fullName: HttpPart<string>,\n *     headShots: HttpPart<Image>[]\n *   }\n * ): void;\n * ```\n */\nextern dec multipartBody(target: ModelProperty);\n\n/**\n * Specify the status code for this response. Property type must be a status code integer or a union of status code integer.\n *\n * @example\n *\n * ```typespec\n * op read(): {\n *   @statusCode _: 200;\n *   @body pet: Pet;\n * };\n * op create(): {\n *   @statusCode _: 201 | 202;\n * };\n * ```\n */\nextern dec statusCode(target: ModelProperty);\n\n/**\n * Specify the HTTP verb for the target operation to be `GET`.\n *\n * @example\n *\n * ```typespec\n * @get op read(): string\n * ```\n */\nextern dec get(target: Operation);\n\n/**\n * Specify the HTTP verb for the target operation to be `PUT`.\n *\n * @example\n *\n * ```typespec\n * @put op set(pet: Pet): void\n * ```\n */\nextern dec put(target: Operation);\n\n/**\n * Specify the HTTP verb for the target operation to be `POST`.\n *\n * @example\n *\n * ```typespec\n * @post op create(pet: Pet): void\n * ```\n */\nextern dec post(target: Operation);\n\n/**\n * Options for PATCH operations.\n */\nmodel PatchOptions {\n  /**\n   * If set to `false`, disables the implicit transform that makes the body of a\n   * PATCH operation deeply optional.\n   */\n  implicitOptionality?: boolean;\n}\n\n/**\n * Specify the HTTP verb for the target operation to be `PATCH`.\n *\n * @param options Options for the PATCH operation.\n *\n * @example\n *\n * ```typespec\n * @patch op update(pet: Pet): void;\n * ```\n *\n * @example\n * ```typespec\n * // Disable implicit optionality, making the body of the PATCH operation use the\n * // optionality as defined in the `Pet` model.\n * @patch(#{ implicitOptionality: false })\n * op update(pet: Pet): void;\n * ```\n */\nextern dec patch(target: Operation, options?: valueof PatchOptions);\n\n/**\n * Specify the HTTP verb for the target operation to be `DELETE`.\n *\n * @example\n *\n * ```typespec\n * @delete op set(petId: string): void\n * ```\n */\nextern dec delete(target: Operation);\n\n/**\n * Specify the HTTP verb for the target operation to be `HEAD`.\n * @example\n *\n * ```typespec\n * @head op ping(petId: string): void\n * ```\n */\nextern dec head(target: Operation);\n\n/**\n * Specify an endpoint for this service. Multiple `@server` decorators can be used to specify multiple endpoints.\n *\n *  @param url Server endpoint\n *  @param description Description of the endpoint\n *  @param parameters Optional set of parameters used to interpolate the url.\n *\n * @example\n *\n * ```typespec\n * @service\n * @server("https://example.com")\n * namespace PetStore;\n * ```\n *\n * @example With a description\n *\n * ```typespec\n * @service\n * @server("https://example.com", "Single server endpoint")\n * namespace PetStore;\n * ```\n *\n * @example Parameterized\n *\n * ```typespec\n * @server("https://{region}.foo.com", "Regional endpoint", {\n *   @doc("Region name")\n *   region?: string = "westus",\n * })\n * ```\n *\n * @example Multiple\n * ```typespec\n * @service\n * @server("https://example.com", "Standard endpoint")\n * @server("https://{project}.private.example.com", "Private project endpoint", {\n *   project: string;\n * })\n * namespace PetStore;\n * ```\n *\n */\nextern dec server(\n  target: Namespace,\n  url: valueof string,\n  description?: valueof string,\n  parameters?: Record<unknown>\n);\n\n/**\n * Specify authentication for a whole service or specific methods. See the [documentation in the Http library](https://typespec.io/docs/libraries/http/authentication) for full details.\n *\n * @param auth Authentication configuration. Can be a single security scheme, a union(either option is valid authentication) or a tuple (must use all authentication together)\n * @example\n *\n * ```typespec\n * @service\n * @useAuth(BasicAuth)\n * namespace PetStore;\n * ```\n */\nextern dec useAuth(target: Namespace | Interface | Operation, auth: {} | Union | {}[]);\n\n/**\n * Defines the relative route URI template for the target operation as defined by [RFC 6570](https://datatracker.ietf.org/doc/html/rfc6570#section-3.2.3)\n *\n * `@route` can only be applied to operations, namespaces, and interfaces.\n *\n * @param uriTemplate Uri template for this operation.\n *\n * @example Simple path parameter\n *\n * ```typespec\n * @route("/widgets/{id}") op getWidget(@path id: string): Widget;\n * ```\n *\n * @example Reserved characters\n * ```typespec\n * @route("/files{+path}") op getFile(@path path: string): bytes;\n * ```\n *\n * @example Query parameter\n * ```typespec\n * @route("/files") op list(select?: string, filter?: string): Files[];\n * @route("/files{?select,filter}") op listFullUriTemplate(select?: string, filter?: string): Files[];\n * ```\n */\nextern dec route(target: Namespace | Interface | Operation, path: valueof string);\n\n/**\n * `@sharedRoute` marks the operation as sharing a route path with other operations.\n *\n * When an operation is marked with `@sharedRoute`, it enables other operations to share the same\n * route path as long as those operations are also marked with `@sharedRoute`.\n *\n * `@sharedRoute` can only be applied directly to operations.\n *\n * ```typespec\n * @sharedRoute\n * @route("/widgets")\n * op getWidget(@path id: string): Widget;\n * ```\n */\nextern dec sharedRoute(target: Operation);\n',
  "../../core/packages/http/lib/private.decorators.tsp": "/**\n * Private decorators. Those are meant for internal use inside Http types only.\n */\nnamespace TypeSpec.Http.Private;\n\nextern dec plainData(target: TypeSpec.Reflection.Model);\nextern dec httpFile(target: TypeSpec.Reflection.Model);\nextern dec httpPart(\n  target: TypeSpec.Reflection.Model,\n  type: unknown,\n  options: valueof HttpPartOptions\n);\n\n/**\n * Specify if inapplicable metadata should be included in the payload for the given entity.\n * @param value If true, inapplicable metadata will be included in the payload.\n */\nextern dec includeInapplicableMetadataInPayload(target: unknown, value: valueof boolean);\n\n/**\n * The visibility mode for the merge patch transform.\n */\nenum MergePatchVisibilityMode {\n  /**\n   * The Update mode. This is used when a resource can be updated but must already exist.\n   */\n  Update,\n\n  /**\n   * The Create or Update mode. This is used when a resource can be created OR updated in a single operation.\n   */\n  CreateOrUpdate,\n}\n\n/**\n * Options for the `@applyMergePatch` decorator.\n */\nmodel ApplyMergePatchOptions {\n  /**\n   * The visibility mode to use.\n   */\n  visibilityMode: MergePatchVisibilityMode;\n}\n\n/**\n * Performs the canonical merge-patch transformation on the given model and injects its\n * transformed properties into the target.\n */\nextern dec applyMergePatch(\n  target: Reflection.Model,\n  source: Reflection.Model,\n  nameTemplate: valueof string,\n  options: valueof ApplyMergePatchOptions\n);\n\n/**\n * Marks a model that was generated by applying the MergePatch\n * transform and links to its source model\n */\nextern dec mergePatchModel(target: Reflection.Model, source: Reflection.Model);\n\n/**\n * Links a modelProperty mutated as part of a mergePatch transform to\n * its source property;\n */\nextern dec mergePatchProperty(target: Reflection.ModelProperty, source: Reflection.ModelProperty);\n",
  "../../core/packages/http/lib/auth.tsp": 'namespace TypeSpec.Http;\n\n@doc("Authentication type")\nenum AuthType {\n  @doc("HTTP")\n  http,\n\n  @doc("API key")\n  apiKey,\n\n  @doc("OAuth2")\n  oauth2,\n\n  @doc("OpenID connect")\n  openIdConnect,\n\n  @doc("Empty auth")\n  noAuth,\n}\n\n/**\n * Basic authentication is a simple authentication scheme built into the HTTP protocol.\n * The client sends HTTP requests with the Authorization header that contains the word Basic word followed by a space and a base64-encoded string username:password.\n * For example, to authorize as demo / `p@55w0rd` the client would send\n * ```\n * Authorization: Basic ZGVtbzpwQDU1dzByZA==\n * ```\n */\n@doc("")\nmodel BasicAuth {\n  @doc("Http authentication")\n  type: AuthType.http;\n\n  @doc("basic auth scheme")\n  scheme: "Basic";\n}\n\n/**\n * Bearer authentication (also called token authentication) is an HTTP authentication scheme that involves security tokens called bearer tokens.\n * The name \u201CBearer authentication\u201D can be understood as \u201Cgive access to the bearer of this token.\u201D The bearer token is a cryptic string, usually generated by the server in response to a login request.\n * The client must send this token in the Authorization header when making requests to protected resources:\n * ```\n * Authorization: Bearer <token>\n * ```\n */\n@doc("")\nmodel BearerAuth {\n  @doc("Http authentication")\n  type: AuthType.http;\n\n  @doc("bearer auth scheme")\n  scheme: "Bearer";\n}\n\n@doc("Describes the location of the API key")\nenum ApiKeyLocation {\n  @doc("API key is a header value")\n  header,\n\n  @doc("API key is a query parameter")\n  query,\n\n  @doc("API key is found in a cookie")\n  cookie,\n}\n\n/**\n * An API key is a token that a client provides when making API calls. The key can be sent in the query string:\n *\n * ```\n * GET /something?api_key=abcdef12345\n * ```\n *\n * or as a request header\n *\n * ```\n * GET /something HTTP/1.1\n * X-API-Key: abcdef12345\n * ```\n *\n * or as a cookie\n *\n * ```\n * GET /something HTTP/1.1\n * Cookie: X-API-KEY=abcdef12345\n * ```\n *\n * @template Location The location of the API key\n * @template Name The name of the API key\n */\n@doc("")\nmodel ApiKeyAuth<Location extends ApiKeyLocation, Name extends string> {\n  @doc("API key authentication")\n  type: AuthType.apiKey;\n\n  @doc("location of the API key")\n  in: Location;\n\n  @doc("name of the API key")\n  name: Name;\n}\n\n/**\n * OAuth 2.0 is an authorization protocol that gives an API client limited access to user data on a web server.\n *\n * OAuth relies on authentication scenarios called flows, which allow the resource owner (user) to share the protected content from the resource server without sharing their credentials.\n * For that purpose, an OAuth 2.0 server issues access tokens that the client applications can use to access protected resources on behalf of the resource owner.\n * For more information about OAuth 2.0, see oauth.net and RFC 6749.\n *\n * @template Flows The list of supported OAuth2 flows\n * @template Scopes The list of OAuth2 scopes, which are common for every flow from `Flows`. This list is combined with the scopes defined in specific OAuth2 flows.\n */\n@doc("")\nmodel OAuth2Auth<Flows extends OAuth2Flow[], Scopes extends string[] = []> {\n  @doc("OAuth2 authentication")\n  type: AuthType.oauth2;\n\n  @doc("Supported OAuth2 flows")\n  flows: Flows;\n\n  @doc("Oauth2 scopes of every flow. Overridden by scope definitions in specific flows")\n  defaultScopes: Scopes;\n}\n\n@doc("Describes the OAuth2 flow type")\nenum OAuth2FlowType {\n  @doc("authorization code flow")\n  authorizationCode,\n\n  @doc("implicit flow")\n  implicit,\n\n  @doc("password flow")\n  password,\n\n  @doc("client credential flow")\n  clientCredentials,\n}\n\nalias OAuth2Flow = AuthorizationCodeFlow | ImplicitFlow | PasswordFlow | ClientCredentialsFlow;\n\n@doc("Authorization Code flow")\nmodel AuthorizationCodeFlow {\n  @doc("authorization code flow")\n  type: OAuth2FlowType.authorizationCode;\n\n  @doc("the authorization URL")\n  authorizationUrl: string;\n\n  @doc("the token URL")\n  tokenUrl: string;\n\n  @doc("the refresh URL")\n  refreshUrl?: string;\n\n  @doc("list of scopes for the credential")\n  scopes?: string[];\n}\n\n@doc("Implicit flow")\nmodel ImplicitFlow {\n  @doc("implicit flow")\n  type: OAuth2FlowType.implicit;\n\n  @doc("the authorization URL")\n  authorizationUrl: string;\n\n  @doc("the refresh URL")\n  refreshUrl?: string;\n\n  @doc("list of scopes for the credential")\n  scopes?: string[];\n}\n\n@doc("Resource Owner Password flow")\nmodel PasswordFlow {\n  @doc("password flow")\n  type: OAuth2FlowType.password;\n\n  @doc("the token URL")\n  tokenUrl: string;\n\n  @doc("the refresh URL")\n  refreshUrl?: string;\n\n  @doc("list of scopes for the credential")\n  scopes?: string[];\n}\n\n@doc("Client credentials flow")\nmodel ClientCredentialsFlow {\n  @doc("client credential flow")\n  type: OAuth2FlowType.clientCredentials;\n\n  @doc("the token URL")\n  tokenUrl: string;\n\n  @doc("the refresh URL")\n  refreshUrl?: string;\n\n  @doc("list of scopes for the credential")\n  scopes?: string[];\n}\n\n/**\n * OpenID Connect (OIDC) is an identity layer built on top of the OAuth 2.0 protocol and supported by some OAuth 2.0 providers, such as Google and Azure Active Directory.\n * It defines a sign-in flow that enables a client application to authenticate a user, and to obtain information (or "claims") about that user, such as the user name, email, and so on.\n * User identity information is encoded in a secure JSON Web Token (JWT), called ID token.\n * OpenID Connect defines a discovery mechanism, called OpenID Connect Discovery, where an OpenID server publishes its metadata at a well-known URL, typically\n *\n * ```http\n * https://server.com/.well-known/openid-configuration\n * ```\n */\nmodel OpenIdConnectAuth<ConnectUrl extends string> {\n  /** Auth type */\n  type: AuthType.openIdConnect;\n\n  /** Connect url. It can be specified relative to the server URL */\n  openIdConnectUrl: ConnectUrl;\n}\n\n/**\n * This authentication option signifies that API is not secured at all.\n * It might be useful when overriding authentication on interface of operation level.\n */\n@doc("")\nmodel NoAuth {\n  type: AuthType.noAuth;\n}\n',
  "../../core/packages/rest/lib/rest.tsp": 'import "@typespec/http";\nimport "./rest-decorators.tsp";\nimport "./resource.tsp";\nimport "../dist/src/tsp-index.js";\n\nnamespace TypeSpec.Rest;\n\n/**\n * A URL that points to a resource.\n * @template Resource The type of resource that the URL points to.\n */\n@doc("The location of an instance of {name}", Resource)\n@Private.resourceLocation(Resource)\nscalar ResourceLocation<Resource extends {}> extends url;\n',
  "../../core/packages/rest/lib/rest-decorators.tsp": 'namespace TypeSpec.Rest;\n\nusing TypeSpec.Reflection;\n\n/**\n * This interface or operation should resolve its route automatically. To be used with resource types where the route segments area defined on the models.\n *\n * @example\n *\n * ```typespec\n * @autoRoute\n * interface Pets {\n *   get(@segment("pets") @path id: string): void; //-> route: /pets/{id}\n * }\n * ```\n */\nextern dec autoRoute(target: Interface | Operation);\n\n/**\n * Defines the preceding path segment for a @path parameter in auto-generated routes.\n *\n * @param name Segment that will be inserted into the operation route before the path parameter\'s name field.\n *\n * @example\n * @autoRoute\n * interface Pets {\n *   get(@segment("pets") @path id: string): void; //-> route: /pets/{id}\n * }\n */\nextern dec segment(target: Model | ModelProperty | Operation, name: valueof string);\n\n/**\n * Returns the URL segment of a given model if it has `@segment` and `@key` decorator.\n * @param type Target model\n */\nextern dec segmentOf(target: Operation, type: Model);\n\n/**\n * Defines the separator string that is inserted before the action name in auto-generated routes for actions.\n *\n * @param seperator Seperator seperating the action segment from the rest of the url\n */\nextern dec actionSeparator(\n  target: Model | ModelProperty | Operation,\n  seperator: valueof "/" | ":" | "/:"\n);\n\n/**\n * Mark this model as a resource type with a name.\n *\n * @param collectionName type\'s collection name\n */\nextern dec resource(target: Model, collectionName: valueof string);\n\n/**\n * Mark model as a child of the given parent resource.\n * @param parent Parent model.\n */\nextern dec parentResource(target: Model, parent: Model);\n\n/**\n * Specify that this is a Read operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec readsResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a Create operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec createsResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a CreateOrReplace operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec createsOrReplacesResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a CreatesOrUpdate operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec createsOrUpdatesResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a Update operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec updatesResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a Delete operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec deletesResource(target: Operation, resourceType: Model);\n\n/**\n * Specify that this is a List operation for a given resource.\n *\n * @param resourceType Resource marked with @resource\n */\nextern dec listsResource(target: Operation, resourceType: Model);\n\n/**\n * Specify this operation is an action. (Scoped to a resource item /pets/{petId}/my-action)\n * @param name Name of the action. If not specified, the name of the operation will be used.\n */\nextern dec action(target: Operation, name?: valueof string);\n\n/**\n * Specify this operation is a collection action. (Scopped to a resource, /pets/my-action)\n * @param resourceType Resource marked with @resource\n * @param name Name of the action. If not specified, the name of the operation will be used.\n */\nextern dec collectionAction(target: Operation, resourceType: Model, name?: valueof string);\n\n/**\n * Copy the resource key parameters on the model\n * @param filter Filter to exclude certain properties.\n */\nextern dec copyResourceKeyParameters(target: Model, filter?: valueof string);\n\nnamespace Private {\n  extern dec resourceLocation(target: string, resourceType: Model);\n  extern dec validateHasKey(target: unknown, value: unknown);\n  extern dec validateIsError(target: unknown, value: unknown);\n  extern dec actionSegment(target: Operation, value: valueof string);\n  extern dec resourceTypeForKeyParam(entity: ModelProperty, resourceType: Model);\n}\n',
  "../../core/packages/rest/lib/resource.tsp": 'import "@typespec/http";\nimport "../dist/src/internal-decorators.js";\n\nnamespace TypeSpec.Rest.Resource;\n\nusing Http;\n\n@doc("The default error response for resource operations.")\nmodel ResourceError {\n  @doc("The error code.")\n  code: int32;\n\n  @doc("The error message.")\n  message: string;\n}\n\n/**\n * Dynamically gathers keys of the model type `Resource`.\n *\n * @template Resource The target resource model.\n */\n@doc("Dynamically gathers keys of the model type Resource.")\n@copyResourceKeyParameters\n@friendlyName("{name}Key", Resource)\nmodel KeysOf<Resource> {}\n\n/**\n * Dynamically gathers parent keys of the model type `Resource`.\n *\n * @template Resource The target resource model.\n */\n@doc("Dynamically gathers parent keys of the model type Resource.")\n@copyResourceKeyParameters("parent")\n@friendlyName("{name}ParentKey", Resource)\nmodel ParentKeysOf<Resource> {}\n\n/**\n * Represents operation parameters for the resource of type `Resource`.\n *\n * @template Resource The resource model.\n */\n@doc("Represents operation parameters for resource Resource.")\nmodel ResourceParameters<Resource extends {}> {\n  ...KeysOf<Resource>;\n}\n\n/**\n * Represents collection operation parameters for the resource of type `Resource`.\n *\n * @template Resource The resource model.\n */\n@doc("Represents collection operation parameters for resource Resource.")\nmodel ResourceCollectionParameters<Resource extends {}> {\n  ...ParentKeysOf<Resource>;\n}\n\n/**\n * Represents the resource GET operation.\n *\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceRead<Resource extends {}, Error> {\n  /**\n   * Gets an instance of the resource.\n   *\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Gets an instance of the resource.")\n  @readsResource(Resource)\n  get(...ResourceParameters<Resource>): Resource | Error;\n}\n\n/**\n * Resource create operation completed successfully.\n *\n * @template Resource The resource model that was created.\n */\n@doc("Resource create operation completed successfully.")\nmodel ResourceCreatedResponse<Resource> {\n  ...CreatedResponse;\n  @bodyRoot body: Resource;\n}\n\n/**\n * Resource create or replace operation template.\n *\n * @template Resource The resource model to create or replace.\n * @template Error The error response.\n */\ninterface ResourceCreateOrReplace<Resource extends {}, Error> {\n  /**\n   * Creates or replaces a instance of the resource.\n   *\n   * @template Resource The resource model to create or replace.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Creates or replaces an instance of the resource.")\n  @createsOrReplacesResource(Resource)\n  createOrReplace(\n    ...ResourceParameters<Resource>,\n    @bodyRoot resource: ResourceCreateModel<Resource>,\n  ): Resource | ResourceCreatedResponse<Resource> | Error;\n}\n\n/**\n * Resource create or update operation model.\n *\n * @template Resource The resource model to create or update.\n */\n@friendlyName("{name}Update", Resource)\nmodel ResourceCreateOrUpdateModel<Resource extends {}>\n  is OptionalProperties<UpdateableProperties<DefaultKeyVisibility<Resource, Lifecycle.Read>>>;\n\n/**\n * Resource create or update operation template.\n *\n * @template Resource The resource model to create or update.\n * @template Error The error response.\n */\ninterface ResourceCreateOrUpdate<Resource extends {}, Error> {\n  /**\n   * Creates or update an instance of the resource.\n   *\n   * @template Resource The resource model to create or update.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Creates or update an instance of the resource.")\n  @createsOrUpdatesResource(Resource)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  createOrUpdate(\n    ...ResourceParameters<Resource>,\n    @bodyRoot resource: ResourceCreateOrUpdateModel<Resource>,\n  ): Resource | ResourceCreatedResponse<Resource> | Error;\n}\n\n/**\n * Resource create operation model.\n *\n * @template Resource The resource model to create.\n */\n@friendlyName("{name}Create", Resource)\n@withVisibility(Lifecycle.Create)\nmodel ResourceCreateModel<Resource extends {}> is DefaultKeyVisibility<Resource, Lifecycle.Read>;\n\n/**\n * Resource create operation template.\n *\n * @template Resource The resource model to create.\n * @template Error The error response.\n */\ninterface ResourceCreate<Resource extends {}, Error> {\n  /**\n   * Creates a new instance of the resource.\n   *\n   * @template Resource The resource model to create.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Creates a new instance of the resource.")\n  @createsResource(Resource)\n  create(\n    ...ResourceCollectionParameters<Resource>,\n    @bodyRoot resource: ResourceCreateModel<Resource>,\n  ): Resource | ResourceCreatedResponse<Resource> | Error;\n}\n\n/**\n * Resource update operation template.\n *\n * @template Resource The resource model to update.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceUpdate<Resource extends {}, Error> {\n  /**\n   * Updates an existing instance of the resource.\n   *\n   * @template Resource The resource model to update.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Updates an existing instance of the resource.")\n  @updatesResource(Resource)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  update(\n    ...ResourceParameters<Resource>,\n    @bodyRoot properties: ResourceCreateOrUpdateModel<Resource>,\n  ): Resource | Error;\n}\n\n@doc("Resource deleted successfully.")\nmodel ResourceDeletedResponse {\n  @doc("The status code.")\n  @statusCode\n  _: 200;\n}\n\n/**\n * Resource delete operation template.\n *\n * @template Resource The resource model to delete.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceDelete<Resource extends {}, Error> {\n  /**\n   * Deletes an existing instance of the resource.\n   *\n   * @template Resource The resource model to delete.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Deletes an existing instance of the resource.")\n  @deletesResource(Resource)\n  delete(...ResourceParameters<Resource>): ResourceDeletedResponse | Error;\n}\n\n/**\n * Structure for a paging response using `value` and `nextLink` to represent pagination.\n *\n * @template Resource The resource type of the collection.\n */\n@doc("Paged response of {name} items", Resource)\n@friendlyName("{name}CollectionWithNextLink", Resource)\nmodel CollectionWithNextLink<Resource extends {}> {\n  @doc("The items on this page")\n  @pageItems\n  value: Resource[];\n\n  @doc("The link to the next page of items")\n  @nextLink\n  nextLink?: ResourceLocation<Resource>;\n}\n\n/**\n * Resource list operation template.\n *\n * @template Resource The resource model to list.\n * @template Error The error response.\n */\ninterface ResourceList<Resource extends {}, Error> {\n  /**\n   * Lists all instances of the resource.\n   *\n   * @template Resource The resource model to list.\n   * @template Error The error response.\n   */\n  @autoRoute\n  @doc("Lists all instances of the resource.")\n  @listsResource(Resource)\n  list(...ResourceCollectionParameters<Resource>): CollectionWithNextLink<Resource> | Error;\n}\n\n/**\n * Resource operation templates for resource instances.\n *\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceInstanceOperations<Resource extends {}, Error>\n  extends ResourceRead<Resource, Error>,\n    ResourceUpdate<Resource, Error>,\n    ResourceDelete<Resource, Error> {}\n\n/**\n * Resource operation templates for resource collections.\n *\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceCollectionOperations<Resource extends {}, Error>\n  extends ResourceCreate<Resource, Error>,\n    ResourceList<Resource, Error> {}\n\n/**\n * Resource operation templates for resources.\n *\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ResourceOperations<Resource extends {}, Error>\n  extends ResourceInstanceOperations<Resource, Error>,\n    ResourceCollectionOperations<Resource, Error> {}\n\n/**\n * Singleton resource read operation template.\n *\n * @template Singleton The singleton resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface SingletonResourceRead<Singleton extends {}, Resource extends {}, Error> {\n  /**\n   * Gets the singleton resource.\n   *\n   * @template Singleton The singleton resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Gets the singleton resource.")\n  @segmentOf(Singleton)\n  @readsResource(Singleton)\n  get(...ResourceParameters<Resource>): Singleton | Error;\n}\n\n/**\n * Singleton resource update operation template.\n *\n * @template Singleton The singleton resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface SingletonResourceUpdate<Singleton extends {}, Resource extends {}, Error> {\n  /**\n   * Updates the singleton resource.\n   *\n   * @template Singleton The singleton resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Updates the singleton resource.")\n  @segmentOf(Singleton)\n  @updatesResource(Singleton)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  update(\n    ...ResourceParameters<Resource>,\n\n    @body\n    properties: ResourceCreateOrUpdateModel<Singleton>,\n  ): Singleton | Error;\n}\n\n/**\n * Singleton resource operation templates for singleton resource instances.\n *\n * @template Singleton The singleton resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface SingletonResourceOperations<Singleton extends {}, Resource extends {}, Error>\n  extends SingletonResourceRead<Singleton, Resource, Error>,\n    SingletonResourceUpdate<Singleton, Resource, Error> {}\n\n/**\n * Extension resource read operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\n@Private.validateHasKey(Resource)\n@Private.validateIsError(Error)\ninterface ExtensionResourceRead<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Gets an instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Gets an instance of the extension resource.")\n  @readsResource(Extension)\n  get(...ResourceParameters<Resource>, ...ResourceParameters<Extension>): Extension | Error;\n}\n\n/**\n * Extension resource create or update operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceCreateOrUpdate<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Creates or update an instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Creates or update an instance of the extension resource.")\n  @createsOrUpdatesResource(Extension)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  createOrUpdate(\n    ...ResourceParameters<Resource>,\n    ...ResourceParameters<Extension>,\n    @bodyRoot resource: ResourceCreateOrUpdateModel<Extension>,\n  ): Extension | ResourceCreatedResponse<Extension> | Error;\n}\n\n/**\n * Extension resource create operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceCreate<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Creates a new instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Creates a new instance of the extension resource.")\n  @createsResource(Extension)\n  create(\n    ...ResourceParameters<Resource>,\n    @bodyRoot resource: ResourceCreateModel<Extension>,\n  ): Extension | ResourceCreatedResponse<Extension> | Error;\n}\n\n/**\n * Extension resource update operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceUpdate<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Updates an existing instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Updates an existing instance of the extension resource.")\n  @updatesResource(Extension)\n  @patch(#{ implicitOptionality: true }) // for legacy behavior\n  update(\n    ...ResourceParameters<Resource>,\n    ...ResourceParameters<Extension>,\n\n    @body\n    properties: ResourceCreateOrUpdateModel<Extension>,\n  ): Extension | Error;\n}\n\n/**\n * Extension resource delete operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceDelete<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Deletes an existing instance of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Deletes an existing instance of the extension resource.")\n  @deletesResource(Extension)\n  delete(\n    ...ResourceParameters<Resource>,\n    ...ResourceParameters<Extension>,\n  ): ResourceDeletedResponse | Error;\n}\n\n/**\n * Extension resource list operation template.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceList<Extension extends {}, Resource extends {}, Error> {\n  /**\n   * Lists all instances of the extension resource.\n   *\n   * @template Extension The extension resource model.\n   * @template Resource The resource model.\n   */\n  @autoRoute\n  @doc("Lists all instances of the extension resource.")\n  @listsResource(Extension)\n  list(\n    ...ResourceParameters<Resource>,\n    ...ResourceCollectionParameters<Extension>,\n  ): CollectionWithNextLink<Extension> | Error;\n}\n\n/**\n * Extension resource operation templates for extension resource instances.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceInstanceOperations<Extension extends {}, Resource extends {}, Error>\n  extends ExtensionResourceRead<Extension, Resource, Error>,\n    ExtensionResourceUpdate<Extension, Resource, Error>,\n    ExtensionResourceDelete<Extension, Resource, Error> {}\n\n/**\n * Extension resource operation templates for extension resource collections.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceCollectionOperations<Extension extends {}, Resource extends {}, Error>\n  extends ExtensionResourceCreate<Extension, Resource, Error>,\n    ExtensionResourceList<Extension, Resource, Error> {}\n\n/**\n * Extension resource operation templates for extension resource instances and collections.\n *\n * @template Extension The extension resource model.\n * @template Resource The resource model.\n * @template Error The error response.\n */\ninterface ExtensionResourceOperations<Extension extends {}, Resource extends {}, Error>\n  extends ExtensionResourceInstanceOperations<Extension, Resource, Error>,\n    ExtensionResourceCollectionOperations<Extension, Resource, Error> {}\n',
  "../../core/packages/versioning/lib/main.tsp": 'import "./decorators.tsp";\nimport "../dist/src/validate.js";\n',
  "../../core/packages/versioning/lib/decorators.tsp": 'import "../dist/src/decorators.js";\n\nusing TypeSpec.Reflection;\n\nnamespace TypeSpec.Versioning;\n\n/**\n * Identifies that the decorated namespace is versioned by the provided enum.\n * @param versions The enum that describes the supported versions.\n *\n * @example\n *\n * ```tsp\n * @versioned(Versions)\n * namespace MyService;\n * enum Versions {\n *   v1,\n *   v2,\n *   v3,\n * }\n * ```\n */\nextern dec versioned(target: Namespace, versions: Enum);\n\n/**\n * Identifies that a namespace or a given versioning enum member relies upon a versioned package.\n * @param versionRecords The dependent library version(s) for the target namespace or version.\n *\n * @example Select a single version of `MyLib` to use\n *\n * ```tsp\n * @useDependency(MyLib.Versions.v1_1)\n * namespace NonVersionedService;\n * ```\n *\n * @example Select which version of the library match to which version of the service.\n *\n * ```tsp\n * @versioned(Versions)\n * namespace MyService1;\n * enum Version {\n *   @useDependency(MyLib.Versions.v1_1) // V1 use lib v1_1\n *   v1,\n *   @useDependency(MyLib.Versions.v1_1) // V2 use lib v1_1\n *   v2,\n *   @useDependency(MyLib.Versions.v2) // V3 use lib v2\n *   v3,\n * }\n * ```\n */\nextern dec useDependency(target: EnumMember | Namespace, ...versionRecords: EnumMember[]);\n\n/**\n * Identifies when the target was added.\n * @param version The version that the target was added in.\n *\n * @example\n *\n * ```tsp\n * @added(Versions.v2)\n * op addedInV2(): void;\n *\n * @added(Versions.v2)\n * model AlsoAddedInV2 {}\n *\n * model Foo {\n *   name: string;\n *\n *   @added(Versions.v3)\n *   addedInV3: string;\n * }\n * ```\n */\nextern dec added(\n  target:\n    | Model\n    | ModelProperty\n    | Operation\n    | Enum\n    | EnumMember\n    | Union\n    | UnionVariant\n    | Scalar\n    | Interface,\n  version: EnumMember\n);\n\n/**\n * Identifies when the target was removed.\n * @param version The version that the target was removed in.\n *\n * @example\n * ```tsp\n * @removed(Versions.v2)\n * op removedInV2(): void;\n *\n * @removed(Versions.v2)\n * model AlsoRemovedInV2 {}\n *\n * model Foo {\n *   name: string;\n *\n *   @removed(Versions.v3)\n *   removedInV3: string;\n * }\n * ```\n */\nextern dec removed(\n  target:\n    | Model\n    | ModelProperty\n    | Operation\n    | Enum\n    | EnumMember\n    | Union\n    | UnionVariant\n    | Scalar\n    | Interface,\n  version: EnumMember\n);\n\n/**\n * Identifies when the target has been renamed.\n * @param version The version that the target was renamed in.\n * @param oldName The previous name of the target.\n *\n * @example\n * ```tsp\n * @renamedFrom(Versions.v2, "oldName")\n * op newName(): void;\n * ```\n */\nextern dec renamedFrom(\n  target:\n    | Model\n    | ModelProperty\n    | Operation\n    | Enum\n    | EnumMember\n    | Union\n    | UnionVariant\n    | Scalar\n    | Interface,\n  version: EnumMember,\n  oldName: valueof string\n);\n\n/**\n * Identifies when a target was made optional.\n * @param version The version that the target was made optional in.\n *\n * @example\n *\n * ```tsp\n * model Foo {\n *   name: string;\n *   @madeOptional(Versions.v2)\n *   nickname?: string;\n * }\n * ```\n */\nextern dec madeOptional(target: ModelProperty, version: EnumMember);\n\n/**\n * Identifies when a target was made required.\n * @param version The version that the target was made required in.\n *\n * @example\n *\n * ```tsp\n * model Foo {\n *   name: string;\n *   @madeRequired(Versions.v2)\n *   nickname: string;\n * }\n * ```\n */\nextern dec madeRequired(target: ModelProperty, version: EnumMember);\n\n/**\n * Identifies when the target type changed.\n * @param version The version that the target type changed in.\n * @param oldType The previous type of the target.\n */\nextern dec typeChangedFrom(target: ModelProperty, version: EnumMember, oldType: unknown);\n\n/**\n * Identifies when the target type changed.\n * @param version The version that the target type changed in.\n * @param oldType The previous type of the target.\n */\nextern dec returnTypeChangedFrom(target: Operation, version: EnumMember, oldType: unknown);\n',
  "../typespec-azure-core/lib/azure-core.tsp": 'import "@typespec/http";\nimport "@typespec/rest";\nimport "@typespec/versioning";\n\nimport "./auth.tsp";\nimport "./traits.tsp";\nimport "./foundations.tsp";\nimport "./models.tsp";\nimport "./operations.tsp";\nimport "./obsolete.tsp";\nimport "./decorators.tsp";\nimport "./legacy.tsp";\nimport "../dist/src/tsp-index.js";\n\nusing Versioning;\n\n@versioned(Versions)\nnamespace Azure.Core;\n\n/**\n * Supported versions of Azure.Core TypeSpec building blocks.\n */\nenum Versions {\n  @doc("Version 1.0-preview.1")\n  v1_0_Preview_1: "1.0-preview.1",\n\n  @doc("Version 1.0-preview.2")\n  v1_0_Preview_2: "1.0-preview.2",\n}\n',
  "../typespec-azure-core/lib/auth.tsp": 'import "@typespec/http";\nimport "@typespec/rest";\nimport "@typespec/versioning";\nimport "./traits.tsp";\n\nusing Http;\nusing Rest;\nusing Versioning;\nusing Azure.Core.Traits;\nusing Azure.Core.Traits.Private;\n\nnamespace Azure.Core;\n\n/**\n * Azure Active Directory (AAD) Token Authentication Flow\n * @template AuthUrl The authorization URL.\n * @template TokenUrl The token URL.\n * @template Scopes A list of scopes the token applies to.\n */\nmodel AadTokenAuthFlow<Scopes extends string[], AuthUrl extends string, TokenUrl extends string>\n  extends TypeSpec.Http.AuthorizationCodeFlow {\n  type: OAuth2FlowType.authorizationCode;\n  authorizationUrl: AuthUrl;\n  tokenUrl: TokenUrl;\n  scopes: Scopes;\n}\n\n/**\n * Azure Active Directory OAuth2 Flow\n * @template AuthUrl The authorization URL.\n * @template TokenUrl The token URL.\n * @template Scopes A list of scopes the token applies to.\n */\n@doc("The Azure Active Directory OAuth2 Flow")\nmodel AadOauth2Auth<\n  Scopes extends string[],\n  AuthUrl extends string = "https://login.microsoftonline.com/common/oauth2/authorize",\n  TokenUrl extends string = "https://login.microsoftonline.com/common/oauth2/token"\n> is OAuth2Auth<[AadTokenAuthFlow<Scopes, AuthUrl, TokenUrl>]>;\n\n/**\n * Azure API Key Authentication using the "Ocp-Apim-Subscription-Key" hea\n */\n@doc("Azure API Key Authentication")\nmodel AzureApiKeyAuthentication\n  is TypeSpec.Http.ApiKeyAuth<ApiKeyLocation.header, "Ocp-Apim-Subscription-Key">;\n',
  "../typespec-azure-core/lib/traits.tsp": 'import "@typespec/versioning";\n\nnamespace Azure.Core.Traits;\n\nusing Reflection;\nusing Versioning;\n\n/**\n * Enumerates the standard trait locations for Azure.Core operations.\n */\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@doc("Enumerates the standard trait locations for Azure.Core operations.")\nenum TraitLocation {\n  @doc("Identifies operation parameters as the trait target.")\n  Parameters,\n\n  @doc("Identifies operation response as the trait target.")\n  Response,\n\n  @doc("Identifies the API version parameter as the trait target.")\n  ApiVersionParameter,\n}\n\n/**\n * Enumerates the standard trait contexts for Azure.Core operations.\n */\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@doc("")\nenum TraitContext {\n  @doc("Trait is applicable for resource \'read\' operations.")\n  Read,\n\n  @doc("Trait is applicable for resource \'create\' operations.")\n  Create,\n\n  @doc("Trait is applicable for resource \'update\' operations.")\n  Update,\n\n  @doc("Trait is applicable for resource \'delete\' operations.")\n  Delete,\n\n  @doc("Trait is applicable for resource \'list\' operations.")\n  List,\n\n  @doc("Trait is applicable for resource actions.")\n  Action,\n\n  @doc("Only traits that did not specify a trait context (and therefore always apply) will be exposed.")\n  Undefined,\n}\n\n/**\n * Used to override a trait.\n * @template Trait The trait to override.\n */\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@Private.applyTraitOverride(Trait)\nmodel TraitOverride<Trait extends Model> {}\n\n/**\n * Declares a trait that is applied as a query parameter.\n * @template Parameters The name of the query parameter.\n * @template Contexts The contexts in which the trait is applicable.\n */\n@trait\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@Private.ensureAllQueryParams(Parameters)\nmodel QueryParametersTrait<Parameters extends Model, Contexts = unknown> {\n  @traitContext(Contexts)\n  queryParams: {\n    @traitLocation(TraitLocation.Parameters)\n    parameters: Parameters;\n  };\n}\n\n/**\n * Declares a trait that is applied as a query parameter for list operations.\n * @template Parameters Object describing the query parameters.\n */\n@trait\n@added(Azure.Core.Versions.v1_0_Preview_2)\nmodel ListQueryParametersTrait<Parameters extends Model>\n  is QueryParametersTrait<Parameters, TraitContext.List>;\n\n/**\n * Declares a trait that is applied as a request header parameter.\n * @template Headers Object describing the request header parameters.\n * @template Contexts The contexts in which the trait is applicable.\n */\n@trait\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@Private.ensureAllHeaderParams(Headers)\nmodel RequestHeadersTrait<Headers extends Model, Contexts = unknown> {\n  @traitContext(Contexts)\n  requestHeaders: {\n    @traitLocation(TraitLocation.Parameters)\n    parameters: Headers;\n  };\n}\n\n/**\n * Declares a trait that is applied as a response header parameter.\n * @template Headers Object describing the response header parameters.\n * @template Contexts The contexts in which the trait is applicable.\n */\n@trait\n@added(Azure.Core.Versions.v1_0_Preview_2)\n@Private.ensureAllHeaderParams(Headers)\nmodel ResponseHeadersTrait<Headers extends Model, Contexts = unknown> {\n  @traitContext(Contexts)\n  responseHeaders: {\n    @traitLocation(TraitLocation.Response)\n    parameters: Headers;\n  };\n}\n\n/**\n * Declares a version parameter trait.\n * @template VersionParameter The type of the version parameter.\n */\n@trait("VersionParameter")\n@added(Azure.Core.Versions.v1_0_Preview_2)\nmodel VersionParameterTrait<VersionParameter> {\n  versionParameter: {\n    @traitLocation(TraitLocation.ApiVersionParameter)\n    apiVersionParam: VersionParameter;\n  };\n}\n\n/**\n * Provides clientRequestId headers for requests and responses.\n * @template VersionAdded The version when the trait was added to the specification.\n *           Leave this empty if the trait is always supported.\n */\n@trait("ClientRequestId")\n@traitAdded(VersionAdded)\nmodel SupportsClientRequestId<VersionAdded extends EnumMember | null = null> {\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This inline model is never used directly in operations."\n  clientRequestId: {\n    @traitLocation(TraitLocation.Parameters)\n    parameters: ClientRequestIdHeader;\n\n    @traitLocation(TraitLocation.Response)\n    response: ClientRequestIdHeader;\n  };\n}\n\n/**\n * Indicates that the service or operation does not support clientRequestId headers.\n */\n@trait("ClientRequestId")\nmodel NoClientRequestId {\n  clientRequestId: {};\n}\n\n/**\n * Provides conditional request headers for requests and ETag headers for responses.\n * @template VersionAdded The version when the trait was added to the specification.\n *           Leave this empty if the trait is always supported.\n */\n@trait("ConditionalRequests")\n@traitAdded(VersionAdded)\nmodel SupportsConditionalRequests<VersionAdded extends EnumMember | null = null> {\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This inline model is never used directly in operations."\n  conditionalRequests: {\n    @traitContext(\n      TraitContext.Read | TraitContext.Update | TraitContext.Delete | TraitContext.Create\n    )\n    @traitLocation(TraitLocation.Parameters)\n    parameters: ConditionalRequestHeaders;\n\n    @traitContext(TraitContext.Read | TraitContext.Create | TraitContext.Update)\n    @traitLocation(TraitLocation.Response)\n    response: EtagResponseEnvelope;\n  };\n}\n\n/**\n * Indicates that the service or operation does not support conditional requests.\n */\n@trait("ConditionalRequests")\nmodel NoConditionalRequests {\n  conditionalRequests: {};\n}\n\n/**\n * Provides repeatable request headers for requests and responses.\n * @template VersionAdded The version when the trait was added to the specification.\n *           Leave this empty if the trait is always supported.\n */\n@trait("RepeatableRequests")\n@traitAdded(VersionAdded)\nmodel SupportsRepeatableRequests<VersionAdded extends EnumMember | null = null> {\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This inline model is never used directly in operations."\n  @traitContext(\n    TraitContext.Create | TraitContext.Update | TraitContext.Delete | TraitContext.Action\n  )\n  repeatableRequests: {\n    @traitLocation(TraitLocation.Parameters)\n    parameters: RepeatabilityRequestHeaders;\n\n    @traitLocation(TraitLocation.Response)\n    response: RepeatabilityResponseHeaders;\n  };\n}\n\n/**\n * Indicates that the service or operation does not support repeatable requests.\n */\n@trait("RepeatableRequests")\nmodel NoRepeatableRequests {\n  repeatableRequests: {};\n}\n\n/**\n * `@trait` marks a model type as representing a \'trait\' and performs basic validation\n * checks.\n *\n * @param target The model type to mark as a trait.\n * @param traitName An optional name to uniquely identify the trait.  If unspecified,\n *        the model type name is used.\n */\nextern dec `trait`(target: Model, traitName?: valueof string);\n\n/**\n * `@traitContext` sets the applicable context for a trait on its envelope property.\n *\n * @param target The trait envelope property where the context will be applied.\n * @param contexts An enum member or union of enum members representing the trait\'s\n *        applicable contexts.\n */\nextern dec traitContext(target: ModelProperty, contexts: EnumMember | Union | unknown);\n\n/**\n * `@traitLocation` sets the applicable location for a trait on its envelope property.\n *\n * @param target The trait envelope property where the context will be applied.\n * @param contexts An enum member or union of enum members representing the trait\'s\n *        applicable contexts.\n */\nextern dec traitLocation(target: ModelProperty, contexts: EnumMember);\n\n/**\n * Sets the version for when the trait was added to the specification.  Can be applied\n * to either a trait model type or its envelope property.\n * @param addedVersion The enum member representing the service version.\n */\nextern dec traitAdded(target: Model | ModelProperty, addedVersion: EnumMember | null);\n\nnamespace Private {\n  @added(Azure.Core.Versions.v1_0_Preview_2)\n  @Private.addTraitProperties(Traits, Location, Contexts)\n  model TraitProperties<\n    Traits extends Model,\n    Location extends TypeSpec.Reflection.EnumMember,\n    Contexts = unknown\n  > {}\n\n  @doc("Contains the details of a specific trait expected by an interface or operation.")\n  model ExpectedTrait {\n    @doc("The name of the expected trait.")\n    trait: string;\n\n    @doc("The diagnostic to be raised when the trait is not present.")\n    diagnostic: string;\n  }\n\n  /**\n   * `@traitSource` stores the `traitName` of its original trait on the envelope property.\n   *\n   * @param target The trait envelope property where `traitName` will be stored.\n   * @param traitName The name of the original trait to which this property belongs.\n   */\n  extern dec traitSource(target: ModelProperty, traitName: valueof string);\n\n  /**\n   * Copies trait properties from `traitModel` into `target` which conform to the\n   * specified location and contexts.\n   * @param traitModel The trait model type to be applied.\n   * @param traitLocation The trait location to use for selecting trait properties.\n   * @param traitContexts The trait contexts to use for selecting trait properties.\n   */\n  extern dec addTraitProperties(\n    target: Model,\n    traitModel: Model,\n    traitLocation: EnumMember,\n    traitContexts: EnumMember | Union | unknown\n  );\n\n  /**\n   * `@applyTraitOverride` copies the `traitModel` into `target` and renames its envelope\n   * property to enable the trait to override another trait sharing the same name.\n   *\n   * @param target The model into which the trait will be copied.\n   * @param traitModel The trait model type to be overridden.\n   */\n  extern dec applyTraitOverride(target: Model, traitModel: Model);\n\n  /**\n   * `@ensureTraitsPresent` checks the envelope properties of `traitModel` to ensure all\n   * of the `expectedTraits` are present as envelope properties.\n   *\n   * @param target The interface or operation where the `traitModel` should be checked.\n   * @param traitModel The trait model type to check.\n   * @param expectedTraits The array of `ExpectedTrait` models which describe each expected trait.\n   */\n  extern dec ensureTraitsPresent(\n    target: Interface | TypeSpec.Reflection.Operation,\n    traitModel: Model,\n    expectedTraits: ExpectedTrait[]\n  );\n\n  /**\n   * `@ensureAllQueryParams` checks the properties of `paramModel` to ensure they all are marked\n   * with the `@query` decorator.\n   *\n   * @param target The model type where this check will be established.\n   * @param paramModel The actual model type to check for query parameters.\n   */\n  extern dec ensureAllQueryParams(target: Model, paramModel: Model);\n\n  /**\n   * `@ensureAllHeaderParams` checks the properties of `paramModel` to ensure they all are marked\n   * with the `@header` decorator.\n   *\n   * @param target The model type where this check will be established.\n   * @param paramModel The actual model type to check for header properties.\n   */\n  extern dec ensureAllHeaderParams(target: Model, paramModel: Model);\n}\n',
  "../typespec-azure-core/lib/foundations.tsp": `import "@typespec/http";
import "@typespec/rest";
import "@typespec/versioning";
import "./traits.tsp";

using Http;
using Rest;
using Versioning;
using Azure.Core.Traits;
using Azure.Core.Traits.Private;

namespace Azure.Core.Foundations;

/**
 * Enum describing allowed operation states.
 */
@lroStatus
union OperationState {
  @doc("The operation has not started.")
  NotStarted: "NotStarted",

  @doc("The operation is in progress.")
  Running: "Running",

  @doc("The operation has completed successfully.")
  Succeeded: "Succeeded",

  @doc("The operation has failed.")
  Failed: "Failed",

  @doc("The operation has been canceled by the user.")
  Canceled: "Canceled",

  string,
}

/**
 * Provides status details for long running operations.
 * @template StatusResult The type of the operation status result.
 * @template StatusError The type of the operation status error. If not provided, the default error is used.
 */
@doc("Provides status details for long running operations.")
model OperationStatus<StatusResult = never, StatusError = Foundations.Error> {
  @key("operationId")
  @doc("The unique ID of the operation.")
  id: string;

  @doc("The status of the operation")
  status: OperationState;

  @doc("Error object that describes the error when status is \\"Failed\\".")
  error?: StatusError;

  @doc("The result of the operation.")
  result?: StatusResult;
}

/**
 * Conveys the resource instance to an operation as a request body.
 * @template Resource The type of the resource instance.
 */
@added(Azure.Core.Versions.v1_0_Preview_2)
@doc("Conveys the resource instance to an operation as a request body.")
model ResourceBody<Resource> {
  @doc("The resource instance.")
  @body
  resource: Resource;
}

// TODO: There is a ARM linter rule that verifies that
// there is no response body. However, long running
// operations are allowed to have it.
alias ResourceCreatedResponse<Resource extends TypeSpec.Reflection.Model> = TypeSpec.Http.Response<201> &
  Resource;

alias ResourceOkResponse<Resource> = TypeSpec.Http.Response<200> & Resource;

alias ResourceCreatedOrOkResponse<Resource extends TypeSpec.Reflection.Model> = ResourceCreatedResponse<Resource> | ResourceOkResponse<Resource>;

/**
 * Response describing the location of a created resource.
 * @template T The type of the created resource.
 */
model LocationOfCreatedResourceResponse<Resource extends TypeSpec.Reflection.Model>
  is TypeSpec.Http.CreatedResponse {
  @finalLocation
  @TypeSpec.Http.header("Location")
  location: ResourceLocation<Resource>;
}

/**
 * Response describing the location of a resource created with a service-provided name.
 * @template T The type of the created resource.
 */
model LocationOfCreatedResourceWithServiceProvidedNameResponse<Resource extends TypeSpec.Reflection.Model>
  is TypeSpec.Http.AcceptedResponse {
  @finalLocation
  @TypeSpec.Http.header("Location")
  location: ResourceLocation<Resource>;
}

/**
 * Metadata for long running operation status monitor locations.
 * @template StatusResult The type of the operation status result.
 */
@doc("Metadata for long running operation status monitor locations")
model LongRunningStatusLocation<StatusResult = never> {
  @pollingLocation
  @doc("The location for monitoring the operation state.")
  @TypeSpec.Http.header("Operation-Location")
  operationLocation: ResourceLocation<OperationStatus<StatusResult>>;
}

alias AcceptedResponse<Resource = {}> = TypeSpec.Http.AcceptedResponse & Resource;

/**
 * A response containing error details.
 * @template Error The type of the error object.
 */
@error
@doc("A response containing error details.")
model ErrorResponseBase<Error> {
  @doc("The error object.")
  error: Error;

  @header("x-ms-error-code")
  @doc("String error code indicating what went wrong.")
  errorCode?: string;
}

model ErrorResponse is ErrorResponseBase<Error>;

@doc("The ApiVersion query parameter.")
model ApiVersionParameter {
  @query("api-version")
  @minLength(1)
  @doc("The API version to use for this operation.")
  apiVersion: string;
}

@doc("The retry-after envelope.")
model RetryAfterHeader {
  @doc("The Retry-After header can indicate how long the client should wait before polling the operation status.")
  @header("Retry-After")
  retryAfter?: int32;
}

@doc("The error object.")
model Error {
  @doc("One of a server-defined set of error codes.")
  code: string;

  @doc("A human-readable representation of the error.")
  message: string;

  @doc("The target of the error.")
  target?: string;

  #suppress "@azure-tools/typespec-providerhub/no-identifier-property-in-array-item" "Error items have no unique identifier."
  @doc("An array of details about specific errors that led to this reported error.")
  details?: Error[];

  @doc("An object containing more specific information than the current object about the error.")
  innererror?: InnerError;
}

@doc("An object containing more specific information about the error. As per Microsoft One API guidelines - https://github.com/microsoft/api-guidelines/blob/vNext/azure/Guidelines.md#handling-errors.")
model InnerError {
  @doc("One of a server-defined set of error codes.")
  code?: string;

  @doc("Inner error.")
  innererror?: InnerError;
}

/**
 * Version of a model for a create or replace operation which only includes updateable properties.
 * @template Resource The type of the resource.
 */
@omitKeyProperties
model ResourceCreateOrReplaceModel<Resource extends TypeSpec.Reflection.Model>
  is UpdateableProperties<DefaultKeyVisibility<Resource, Lifecycle.Read>>;

/**
 * Collection of properties from a resource that are visible to create or update scopes.
 * @template Resource The type of the resource.
 */
@withVisibility(Lifecycle.Create, Lifecycle.Update)
model CreateableAndUpdateableProperties<Resource> {
  ...Resource;
}

/**
 * Version of a model for a create or update operation which only includes updateable properties.
 * @template Resource The type of the resource.
 */
@omitKeyProperties
model ResourceCreateOrUpdateModel<Resource>
  is OptionalProperties<CreateableAndUpdateableProperties<DefaultKeyVisibility<
    Resource,
    Lifecycle.Read
  >>>;

/**
 * Version of a model for an update operation which only includes updateable properties.
 * @template Resource The type of the resource.
 */
@omitKeyProperties
model ResourceUpdateModel<Resource>
  is OptionalProperties<UpdateableProperties<DefaultKeyVisibility<Resource, Lifecycle.Read>>>;

/**
 * A model containing the keys of the provided resource.
 * @template Resource The type of the resource.
 */
@copyResourceKeyParameters
model ItemKeysOf<Resource> {}

/**
 * A model containing the collection keys of the provided resource's parent resource.
 * @template Resource The type of the resource.
 */
@copyResourceKeyParameters("parent")
model CollectionKeysOf<Resource> {}

/**
 * A model describing a set of custom request parameters.
 * @template Custom An object describing custom request parameters.
 */
@Private.spreadCustomParameters(Custom)
model CustomParameters<Custom extends TypeSpec.Reflection.Model> {}

/**
 * A model describing a set of custom response properties.
 * @template Custom An object describing custom response properties.
 */
@Private.spreadCustomResponseProperties(Custom)
model CustomResponseFields<Custom extends TypeSpec.Reflection.Model> {}

/**
 * A model describing a customized page of resources.
 * @template Resource The type of the resource.
 * @template Traits Traits which apply to the page.
 */
@pagedResult
@friendlyName("Paged{name}", Resource)
@doc("Paged collection of {name} items", Resource)
model CustomPage<
  Resource extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {}
> {
  @doc("The {name} items on this page", Resource)
  @items
  value: Resource[];

  @doc("The link to the next page of items")
  @nextLink
  nextLink?: ResourceLocation<Resource>;

  // Include custom response fields
  ...TraitProperties<Traits, TraitLocation.Response, TraitContext.List>;
}

/**
 * The expected shape of model types passed to the Custom parameter of operation signatures.
 */
@doc("The expected shape of model types passed to the Custom parameter of operation signatures.")
model CustomizationFields {
  @doc("An object containing custom parameters that will be included in the operation.")
  parameters?: {};

  @doc("An object containing custom properties that will be included in the response.")
  response?: {};
}

// Basic Operation Shapes

/**
 * The most basic operation.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
op Operation<
  Parameters extends TypeSpec.Reflection.Model,
  Response,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
>(
  ...TraitProperties<
    Traits & VersionParameterTrait<ApiVersionParameter>,
    TraitLocation.ApiVersionParameter
  >,
  ...Parameters,
): Response | ErrorResponse;

/**
 * Long-running operation.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation. If not provided, the AcceptedResponse type will be used.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
#suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"
op LongRunningOperation<
  Parameters extends TypeSpec.Reflection.Model,
  Response = AcceptedResponse,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Operation<Parameters, Response & Foundations.LongRunningStatusLocation, Traits, ErrorResponse>;

/**
 * Operation that returns the status of another operation.
 * @template Parameters Object describing the request parameters of the operation.
 * @template StatusResult The type of the operation status result.
 * @template StatusError The type of the operation status error.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
op GetOperationStatus<
  Parameters = {},
  StatusResult = never,
  StatusError = Error,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Foundations.Operation<
  Parameters & {
    @doc("The unique ID of the operation.")
    @path
    operationId: string;
  },
  OperationStatus<StatusResult, StatusError>,
  Traits,
  ErrorResponse
>;

// Fundamental Resource Operation Shapes

/**
 * The most basic operation that applies to a resource.
 * @template Resource The type of the resource.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
#suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "This operation must return a status monitor in its response."
@autoRoute
@Private.ensureResourceType(Resource)
op ResourceOperation<
  Resource extends TypeSpec.Reflection.Model,
  Parameters extends TypeSpec.Reflection.Model,
  Response,  // No constraint here on purpose, some responses are unions
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Operation<Foundations.ItemKeysOf<Resource> & Parameters, Response, Traits, ErrorResponse>;

/**
 * Operation that applies to a collection of resources.
 * @template Resource The type of the resource.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
#suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "This operation must return a status monitor in its response."
@autoRoute
@Private.ensureResourceType(Resource)
op ResourceCollectionOperation<
  Resource extends TypeSpec.Reflection.Model,
  Parameters extends TypeSpec.Reflection.Model,
  Response extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Operation<
  Foundations.CollectionKeysOf<Resource> & Parameters,
  Response,
  Traits,
  ErrorResponse
>;

/**
 * Operation that lists resources in a paginated way.
 * @template Resource The type of the resource.
 * @template Parameters Object describing the request parameters of the operation.
 * @template Response Object describing the response properties of the operation.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
@listsResource(Resource)
@Private.ensureResourceType(Resource)
op ResourceList<
  Resource extends TypeSpec.Reflection.Model,
  Parameters extends TypeSpec.Reflection.Model,
  Response extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is ResourceCollectionOperation<Resource, Parameters, Response, Traits, ErrorResponse>;

/**
 * Operation that lists resources in a non-paginated way.
 * @template Resource The type of the resource.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
#suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"
@autoRoute
op NonPagedResourceList<
  Resource extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Foundations.ResourceList<
  Resource,
  TraitProperties<Traits, TraitLocation.Parameters, TraitContext.List>,
  Body<Resource[]> & TraitProperties<Traits, TraitLocation.Response, TraitContext.List>,
  Traits,
  ErrorResponse
>;

/**
 * Long-running operation that updates a resource.
 * @template Resource The type of the resource.
 * @template Traits Traits which apply to the operation.
 * @template ErrorResponse The type of the error response. If not provided, the default error response type will be used.
 */
@updatesResource(Resource)
op LongRunningResourceUpdate<
  Resource extends TypeSpec.Reflection.Model,
  Traits extends TypeSpec.Reflection.Model = {},
  ErrorResponse = Azure.Core.Foundations.ErrorResponse
> is Foundations.ResourceOperation<
  Resource,
  {
    @doc("This request has a JSON Merge Patch body.")
    @TypeSpec.Http.header("Content-Type")
    contentType: "application/merge-patch+json";

    ...Foundations.ResourceBody<Resource>;
    ...TraitProperties<Traits, TraitLocation.Parameters, TraitContext.Update>;
  },
  Foundations.ResourceOkResponse<Resource &
    TraitProperties<Traits, TraitLocation.Response, TraitContext.Update> &
    Foundations.LongRunningStatusLocation<Resource>>,
  Traits,
  ErrorResponse
>;
`,
  "../typespec-azure-core/lib/models.tsp": 'import "@typespec/http";\nimport "@typespec/rest";\nimport "./traits.tsp";\n\nusing Http;\nusing Rest;\n\nnamespace Azure.Core;\n\n/**\n * Describes a page of resource object.\n * @template Resource The resource type.\n */\n@pagedResult\n@friendlyName("Paged{name}", Resource)\n@doc("Paged collection of {name} items", Resource)\nmodel Page<Resource extends TypeSpec.Reflection.Model> {\n  @doc("The {name} items on this page", Resource)\n  @items\n  value: Resource[];\n\n  @doc("The link to the next page of items")\n  @nextLink\n  nextLink?: ResourceLocation<Resource>;\n}\n\n/**\n * Defines a property as a request parameter.\n * @template Name The parameter name.\n */\n@Foundations.requestParameter(Name)\nmodel RequestParameter<Name extends valueof string> {}\n\n/**\n * Defines a property as a response header.\n * @template Name The header name.\n */\n@Foundations.responseProperty(Name)\nmodel ResponseProperty<Name extends valueof string> {}\n\n/**\n * @dev Provides the status of a resource operation.\n * @template Resource The resource type.\n * @template StatusResult Model describing the status result object. If not specified, the default is the resource type.\n * @template StatusError Model describing the status error object. If not specified, the default is the Foundations.Error.\n */\n@resource("operations")\n@parentResource(Resource)\nmodel ResourceOperationStatus<\n  Resource extends TypeSpec.Reflection.Model,\n  StatusResult = Resource,\n  StatusError = Foundations.Error\n> is Azure.Core.Foundations.OperationStatus<StatusResult, StatusError>;\n\n#suppress "@azure-tools/typespec-providerhub/no-inline-model" "This is acceptable in Azure.Core."\nalias ResourceOperationStatusResponse<\n  Resource extends TypeSpec.Reflection.Model,\n  StatusResult,\n  StatusError\n> = ResourceOperationStatus<Resource, StatusResult, StatusError>;\n\n@doc("Provides the standard \'top\' query parameter for list operations.")\nmodel TopQueryParameter {\n  @query\n  @doc("The number of result items to return.")\n  top?: int32;\n}\n\n@doc("Provides the standard \'skip\' query parameter for list operations.")\nmodel SkipQueryParameter {\n  @query\n  @doc("The number of result items to skip.")\n  skip?: int32 = 0;\n}\n\n@doc("Provides the standard \'maxpagesize\' query parameter for list operations.")\nmodel MaxPageSizeQueryParameter {\n  @query\n  @doc("The maximum number of result items per page.")\n  maxpagesize?: int32;\n}\n\n@doc("Provides the standard \'filter\' query parameter for list operations")\nmodel FilterParameter {\n  @query\n  @doc("The maximum number of result items per page.")\n  filter?: string;\n}\n\n@doc("Provides the standard \'orderby\' query parameter for list operations.")\nmodel OrderByQueryParameter {\n  @query(#{ explode: true })\n  @doc("Expressions that specify the order of returned results.")\n  orderby?: string[];\n}\n\n@doc("Provides the standard \'filter\' query parameter for list operations.")\nmodel FilterQueryParameter {\n  @query\n  @doc("Filter the result list using the given expression.")\n  filter?: string;\n}\n\n@doc("Provides the standard \'select\' query parameter for list operations.")\nmodel SelectQueryParameter {\n  @query(#{ explode: true })\n  @doc("Select the specified fields to be included in the response.")\n  select?: string[];\n}\n\n@doc("Provides the standard \'expand\' query parameter for list operations.")\nmodel ExpandQueryParameter {\n  @query(#{ explode: true })\n  @doc("Expand the indicated resources into the response.")\n  expand?: string[];\n}\n\n@doc("Provides the most common query parameters for list operations.")\nmodel StandardListQueryParameters {\n  ...TopQueryParameter;\n  ...SkipQueryParameter;\n  ...MaxPageSizeQueryParameter;\n}\n\n// https://github.com/microsoft/api-guidelines/blob/vNext/azure/Guidelines.md#conditional-requests\n\n@doc("Provides the \'If-*\' headers to enable conditional (cached) responses")\nmodel ConditionalRequestHeaders {\n  @visibility(Lifecycle.Read, Lifecycle.Query, Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("If-Match")\n  @doc("The request should only proceed if an entity matches this string.")\n  ifMatch?: string;\n\n  @visibility(Lifecycle.Read, Lifecycle.Query, Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("If-None-Match")\n  @doc("The request should only proceed if no entity matches this string.")\n  ifNoneMatch?: string;\n\n  @visibility(Lifecycle.Read, Lifecycle.Query, Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("If-Unmodified-Since")\n  @doc("The request should only proceed if the entity was not modified after this time.")\n  ifUnmodifiedSince?: utcDateTime;\n\n  @visibility(Lifecycle.Read, Lifecycle.Query, Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("If-Modified-Since")\n  @doc("The request should only proceed if the entity was modified after this time.")\n  ifModifiedSince?: utcDateTime;\n}\n\n@doc("""\n  Provides the \'ETag\' field to enable conditional (cached) requests.  This model can be spread\n  into responses and item models to convey the ETag when it cannot simply conveyed in a header.\n  """)\nmodel EtagProperty {\n  @visibility(Lifecycle.Read)\n  @doc("The entity tag for this resource.")\n  etag: eTag;\n}\n\n@doc("Provides the \'ETag\' header to enable conditional (cached) requests")\nmodel EtagResponseEnvelope {\n  @header("ETag")\n  @visibility(Lifecycle.Read)\n  @doc("The entity tag for the response.")\n  etagHeader?: string;\n}\n\n// https://github.com/microsoft/api-guidelines/blob/vNext/azure/Guidelines.md#repeatability-of-requests\n\n@doc("Provides the \'Repeatability-*\' headers to enable repeatable requests.")\nmodel RepeatabilityRequestHeaders {\n  @visibility(Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @header("Repeatability-Request-ID")\n  @doc("An opaque, globally-unique, client-generated string identifier for the request.")\n  repeatabilityRequestId?: string;\n\n  @visibility(Lifecycle.Create, Lifecycle.Update, Lifecycle.Delete)\n  @doc("Specifies the date and time at which the request was first created.")\n  @header("Repeatability-First-Sent")\n  repeatabilityFirstSent?: utcDateTime;\n}\n\n@doc("Provides the \'Repeatability-*\' headers to enable repeatable requests.")\nmodel RepeatabilityResponseHeaders {\n  @visibility(Lifecycle.Read)\n  @header("Repeatability-Result")\n  @doc("Indicates whether the repeatable request was accepted or rejected.")\n  repeatabilityResult?: RepeatabilityResult;\n}\n\n/** Repeatability Result header options */\nunion RepeatabilityResult {\n  /** If the request was accepted and the server guarantees that the server state reflects a single execution of the operation. */\n  "accepted",\n\n  /**\n   * If the request was rejected because the combination of Repeatability-First-Sent and Repeatability-Request-ID were invalid\n   *  or because the Repeatability-First-Sent value was outside the range of values held by the server.\n   */\n  "rejected",\n}\n\n// https://github.com/microsoft/api-guidelines/blob/vNext/azure/Guidelines.md#distributed-tracing--telemetry\n\n@doc("Provides the \'x-ms-client-request-id\' header to enable request correlation in requests and responses.")\nmodel ClientRequestIdHeader {\n  @header("x-ms-client-request-id")\n  @doc("An opaque, globally-unique, client-generated string identifier for the request.")\n  clientRequestId?: uuid;\n}\n\n@doc("Provides the \'x-ms-request-id\' header to enable request correlation in responses.")\nmodel RequestIdResponseHeader {\n  @visibility(Lifecycle.Read)\n  @header("x-ms-request-id")\n  @doc("An opaque, globally-unique, server-generated string identifier for the request.")\n  requestId?: uuid;\n}\n\n/**\n * A vector embedding frequently used in similarity search.\n * @template Element The element type of the embedding vector.\n */\n@Foundations.Private.embeddingVector(Element)\nmodel EmbeddingVector<Element extends numeric = float32> is Array<Element>;\n\n/**\n * Options for overriding a polling endpoint that uses a StatusMonitor\n * @template PollingModel The model that is returned when polling should continue.\n * @template FinalResult The model that is returned when polling terminates successfully.\n * @template FinalProperty The property of the status monitor that contains results.\n */\nmodel StatusMonitorPollingOptions<\n  PollingModel extends TypeSpec.Reflection.Model | void = never,\n  FinalResult extends TypeSpec.Reflection.Model | void = never,\n  FinalProperty extends TypeSpec.Reflection.ModelProperty | string = never\n> extends StatusMonitorOptions {\n  /** The kind of polling options */\n  kind: PollingOptionKind.statusMonitor;\n\n  /** The model that is returned when polling should continue */\n  pollingModel: PollingModel;\n\n  /** The model that is returned when polling terminates successfully */\n  finalResult: FinalResult;\n\n  /** The property of the status monitor that contains results */\n  finalProperty: FinalProperty;\n}\n\n/** Options for Lro status monitors. */\nmodel StatusMonitorOptions extends PollingOptions {\n  /** The kind of polling options */\n  kind: PollingOptionKind.statusMonitor;\n\n  /** A reference to or name of the property of the status monitor that contains the response */\n  finalProperty?: TypeSpec.Reflection.ModelProperty | string;\n}\n\n/** Generic polling options for LRO operations. */\nmodel PollingOptions {\n  /** The kind of polling options */\n  kind: PollingOptionKind;\n\n  /** The model that is returned when polling should continue. */\n  pollingModel?: TypeSpec.Reflection.Model | void;\n\n  /** The type that is returned when polling terminates successfully. */\n  finalResult?: TypeSpec.Reflection.Model | void;\n}\n\n/** The available kinds of polling options */\nunion PollingOptionKind {\n  /** Polling options for a status monitor */\n  statusMonitor: "statusMonitor",\n\n  string,\n}\n\n/**\n * Universally Unique Identifier\n *\n * @example\n *\n * ```\n * 123e4567-e89b-12d3-a456-426614174000\n * ```\n */\n@format("uuid")\nscalar uuid extends string;\n\n/**\n * Represent an IP V4 address serialized as a string.\n *\n * It is formatted as four 8-bit fields separated by periods.\n *\n * @example\n *\n * ```\n * 129.144.50.56\n * ```\n */\n#suppress "@azure-tools/typespec-autorest/invalid-format" "Foundation."\n@format("ipV4Address")\nscalar ipV4Address extends string;\n\n/**\n * Represent an IP V6 address serialized as a string.\n *\n * It is formatted as eight hex decimal values(16-bit) between 0 and FFFF separated by colon. (i.e. `y:y:y:y:y:y:y:y`)\n *\n * @example\n *\n * ```\n * 2001:db8:3333:4444:CCCC:DDDD:EEEE:FFFF\n * ```\n */\n#suppress "@azure-tools/typespec-autorest/invalid-format" "Foundation."\n@format("ipV6Address")\nscalar ipV6Address extends string;\n\n/**\n * The ETag (or entity tag) HTTP response header is an identifier for a specific version of a resource.\n * It lets caches be more efficient and save bandwidth, as a web server does not need to resend a full response if the content was not changed.\n *\n * It is a string of ASCII characters placed between double quotes, like "675af34563dc-tr34".\n *\n * @example In `ETag` header\n *\n * ```\n * ETag: "675af34563dc-tr34"\n * ```\n */\n#suppress "@azure-tools/typespec-autorest/invalid-format" "Foundation."\n@format("eTag")\nscalar eTag extends string;\n\n/**\n * Represents an Azure geography region where supported resource providers live.\n *\n * @example\n *\n * ```\n * WestUS\n * ```\n */\nscalar azureLocation extends string;\n\n/**\n * Represents an Azure Resource Type.\n *\n * @example\n *\n * ```\n * Microsoft.Network/virtualNetworks/subnets\n * ```\n */\nscalar armResourceType extends string;\n\n/**\n * A type definition that refers the id to an Azure Resource Manager resource.\n *\n * @template AllowedResourceTypes An array of allowed resource types for the resource reference\n *\n * @example\n *\n * ```tsp\n * model MyModel {\n *   otherArmId: armResourceIdentifier;\n *   networkId: armResourceIdentifier<[{type:"Microsoft.Network/vnet"}]>\n *   vmIds: armResourceIdentifier<[{type:"Microsoft.Compute/vm", scopes: ["*"]}]>\n *   scoped: armResourceIdentifier<[{type:"Microsoft.Compute/vm", scopes: ["tenant", "resourceGroup"]}]>\n * }\n * ```\n */\n@doc("A type definition that refers the id to an Azure Resource Manager resource.")\n@format("arm-id")\n@Azure.Core.Foundations.Private.armResourceIdentifierConfig({\n  allowedResources: AllowedResourceTypes,\n})\nscalar armResourceIdentifier<AllowedResourceTypes extends ArmResourceIdentifierAllowedResource[] = never>\n  extends string;\n\n// Consider replacing `*`\nunion ArmResourceDeploymentScope {\n  "tenant",\n  "subscription",\n  "resourceGroup",\n  "managementGroup",\n  "extension",\n}\n\nalias AllArmResourceDeploymentScopes = [\n  "tenant",\n  "subscription",\n  "resourceGroup",\n  "managementGroup",\n  "extension"\n];\n\nmodel ArmResourceIdentifierAllowedResource {\n  /** The type of resource that is being referred to. For example Microsoft.Network/virtualNetworks or Microsoft.Network/virtualNetworks/subnets. See Example Types for more examples. */\n  type: armResourceType;\n\n  /**\n   * An array of scopes. If not specified, the default scope is ["ResourceGroup"].\n   * See [Allowed Scopes](https://github.com/Azure/autorest/tree/main/docs/extensions#allowed-scopes).\n   */\n  scopes?: ArmResourceDeploymentScope[];\n}\n',
  "../typespec-azure-core/lib/operations.tsp": 'import "@typespec/http";\nimport "@typespec/rest";\nimport "@typespec/versioning";\nimport "./models.tsp";\nimport "./traits.tsp";\n\nnamespace Azure.Core;\n\nusing Http;\nusing Rest;\nusing Versioning;\nusing Azure.Core.Traits;\nusing Azure.Core.Traits.Private;\n\n// RPC Operations\n\n/**\n * A remote procedure call (RPC) operation.\n * @template Parameters Object describing the parameters of the operation.\n * @template Response Object describing the response of the operation.\n * @template Traits Object describing the traits of the operation.\n * @template ErrorResponse Error response of the operation. If not specified, the default error response is used.\n * @template TraitContexts Trait contexts applicable to the operation. Defaults to `TraitContext.Undefined` which means that only traits that always apply will appear. Can specify multiple using the | operator.\n */\n@Foundations.Private.needsRoute\nop RpcOperation<\n  Parameters extends TypeSpec.Reflection.Model,\n  Response extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {},\n  ErrorResponse = Azure.Core.Foundations.ErrorResponse,\n  TraitContexts extends TraitContext = TraitContext.Undefined\n> is Foundations.Operation<\n  Parameters & TraitProperties<Traits, TraitLocation.Parameters>,\n  Response & TraitProperties<Traits, TraitLocation.Response, TraitContexts>,\n  Traits,\n  ErrorResponse\n>;\n\n/**\n * A long-running remote procedure call (RPC) operation.\n * @template Parameters Object describing the parameters of the operation.\n * @template Response Object describing the response of the operation.\n * @template StatusResult Object describing the status result of the operation.\n * @template StatusError Error response of the status operation. If not specified, the default error response is used.\n * @template Traits Object describing the traits of the operation.\n * @template ErrorResponse Error response of the operation. If not specified, the default error response is used.\n * @template TraitContexts Trait contexts applicable to the operation. Defaults to `TraitContext.Undefined` which means that only traits that always apply will appear. Can specify multiple using the | operator.\n */\n@Foundations.Private.needsRoute\n@post\nop LongRunningRpcOperation<\n  Parameters extends TypeSpec.Reflection.Model,\n  Response extends TypeSpec.Reflection.Model,\n  StatusResult extends TypeSpec.Reflection.Model,\n  StatusError = Foundations.Error,\n  Traits extends TypeSpec.Reflection.Model = {},\n  ErrorResponse = Azure.Core.Foundations.ErrorResponse,\n  TraitContexts extends TraitContext = TraitContext.Undefined\n> is Foundations.Operation<\n  Parameters & TraitProperties<Traits, TraitLocation.Parameters>,\n  AcceptedResponse &\n    ResourceOperationStatus<Response, StatusResult, StatusError> &\n    Foundations.LongRunningStatusLocation<StatusResult> &\n    TraitProperties<Traits, TraitLocation.Response, TraitContexts>,\n  Traits,\n  ErrorResponse\n>;\n\n// Standard Resource Lifecycle Operations\n\nalias ExpectedResourceOperationTraits = [\n  {\n    trait: "ConditionalRequests";\n    diagnostic: "conditional-requests-trait-missing";\n  },\n  {\n    trait: "RepeatableRequests";\n    diagnostic: "repeatable-requests-trait-missing";\n  },\n  {\n    trait: "ClientRequestId";\n    diagnostic: "client-request-id-trait-missing";\n  }\n];\n\n/**\n * Interface containing common resource operations.\n * @template InterfaceTraits Traits applicable to the operations.\n * @template ErrorResponse Error response of the operations. If not specified, the default error response is used.\n */\n@ensureTraitsPresent(InterfaceTraits, ExpectedResourceOperationTraits)\ninterface ResourceOperations<\n  InterfaceTraits extends TypeSpec.Reflection.Model,\n  ErrorResponse = Azure.Core.Foundations.ErrorResponse\n> {\n  /**\n   * Create or replace operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceCreateOrReplace", "PUT")\n  @createsOrReplacesResource(Resource)\n  ResourceCreateOrReplace<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    Foundations.ResourceBody<Resource> &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Parameters,\n        TraitContext.Create | TraitContext.Update\n      >,\n    Foundations.ResourceCreatedOrOkResponse<Resource &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Response,\n        TraitContext.Create | TraitContext.Update\n      >>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource create or replace operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("LongRunningResourceCreateOrReplace", "PUT")\n  @createsOrReplacesResource(Resource)\n  LongRunningResourceCreateOrReplace<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    Foundations.ResourceBody<Resource> &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Parameters,\n        TraitContext.Create | TraitContext.Update\n      >,\n    Foundations.ResourceCreatedOrOkResponse<Resource &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Response,\n        TraitContext.Create | TraitContext.Update\n      > &\n      Foundations.LongRunningStatusLocation>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Create or update operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceCreateOrUpdate", "PATCH")\n  @createsOrUpdatesResource(Resource)\n  @parameterVisibility(Lifecycle.Create, Lifecycle.Update)\n  @patch(#{ implicitOptionality: true }) // For legacy reasons\n  ResourceCreateOrUpdate<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    {\n      @doc("This request has a JSON Merge Patch body.")\n      @TypeSpec.Http.header("Content-Type")\n      contentType: "application/merge-patch+json";\n\n      ...Foundations.ResourceBody<Resource>;\n      ...TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Parameters,\n        TraitContext.Create | TraitContext.Update\n      >;\n    },\n    Foundations.ResourceCreatedOrOkResponse<Resource &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Response,\n        TraitContext.Create | TraitContext.Update\n      >>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource create or update operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("LongRunningResourceCreateOrUpdate", "PATCH")\n  @createsOrUpdatesResource(Resource)\n  @parameterVisibility(Lifecycle.Create, Lifecycle.Update)\n  @patch(#{ implicitOptionality: true }) // For legacy reasons\n  LongRunningResourceCreateOrUpdate<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    {\n      @doc("This request has a JSON Merge Patch body.")\n      @TypeSpec.Http.header("Content-Type")\n      contentType: "application/merge-patch+json";\n\n      ...Foundations.ResourceBody<Resource>;\n      ...TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Parameters,\n        TraitContext.Create | TraitContext.Update\n      >;\n    },\n    Foundations.ResourceCreatedOrOkResponse<Resource &\n      TraitProperties<\n        Traits & InterfaceTraits,\n        TraitLocation.Response,\n        TraitContext.Create | TraitContext.Update\n      > &\n      Foundations.LongRunningStatusLocation<Resource>>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource update operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceUpdate", "PATCH")\n  @updatesResource(Resource)\n  @patch(#{ implicitOptionality: true }) // For legacy reasons\n  ResourceUpdate<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    {\n      @doc("This request has a JSON Merge Patch body.")\n      @TypeSpec.Http.header("Content-Type")\n      contentType: "application/merge-patch+json";\n\n      ...Foundations.ResourceBody<Resource>;\n      ...TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Update>;\n    },\n    Foundations.ResourceOkResponse<Resource &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Update>>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource create with service-provided name operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  @Foundations.Private.ensureVerb("ResourceCreateWithServiceProvidedName", "POST")\n  @createsResource(Resource)\n  ResourceCreateWithServiceProvidedName<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceCollectionOperation<\n    Resource,\n    Foundations.ResourceBody<Resource> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Create>,\n    Foundations.LocationOfCreatedResourceResponse<Resource> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Create>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource create with service-provided name operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  @Foundations.Private.ensureVerb("LongRunningResourceCreateWithServiceProvidedName", "POST")\n  @createsResource(Resource)\n  LongRunningResourceCreateWithServiceProvidedName<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceCollectionOperation<\n    Resource,\n    Foundations.ResourceBody<Resource> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Create>,\n    Foundations.LocationOfCreatedResourceWithServiceProvidedNameResponse<Resource> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Create>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource read operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceRead", "GET")\n  @readsResource(Resource)\n  ResourceRead<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Read>,\n    Resource &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Read>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource delete operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  @Foundations.Private.ensureVerb("ResourceDelete", "DELETE")\n  @deletesResource(Resource)\n  ResourceDelete<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Delete>,\n    TypeSpec.Http.NoContentResponse &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Delete>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource delete operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "We do support bodies in data plane service APIs..."\n  @Foundations.Private.ensureVerb("LongRunningResourceDelete", "DELETE")\n  @deletesResource(Resource)\n  LongRunningResourceDelete<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Delete>,\n    Foundations.AcceptedResponse<Foundations.OperationStatus &\n      Foundations.LongRunningStatusLocation &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Delete>>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource list operation template.\n   * @template Resource Resource type.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceList", "GET")\n  ResourceList<\n    Resource extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceList<\n    Resource,\n    TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.List>,\n    Foundations.CustomPage<Resource, Traits & InterfaceTraits>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource action operation template.\n   * @template Resource Resource type.\n   * @template Parameters Object describing the parameters of the operation.\n   * @template Response Object describing the response of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceAction", "POST")\n  @action\n  @actionSeparator(":")\n  ResourceAction<\n    Resource extends TypeSpec.Reflection.Model,\n    Parameters extends TypeSpec.Reflection.Model,\n    Response extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    Parameters &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Action>,\n    Response &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Action>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource collection action operation template.\n   * @template Resource Resource type.\n   * @template Parameters Object describing the parameters of the operation.\n   * @template Response Object describing the response of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("ResourceCollectionAction", "POST")\n  @collectionAction(Resource)\n  @actionSeparator(":")\n  ResourceCollectionAction<\n    Resource extends TypeSpec.Reflection.Model,\n    Parameters extends TypeSpec.Reflection.Model,\n    Response extends TypeSpec.Reflection.Model,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceCollectionOperation<\n    Resource,\n    Parameters &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Action>,\n    Response &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Action>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource action operation template.\n   * @template Resource Resource type.\n   * @template Parameters Object describing the parameters of the operation.\n   * @template StatusResult Object describing the status result of the operation.\n   * @template StatusError Object describing the status error of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  #suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "This operation must return a status monitor in its response."\n  @Foundations.Private.ensureVerb("LongRunningResourceAction", "POST")\n  @action\n  @actionSeparator(":")\n  LongRunningResourceAction<\n    Resource extends TypeSpec.Reflection.Model,\n    Parameters extends TypeSpec.Reflection.Model,\n    StatusResult extends TypeSpec.Reflection.Model,\n    StatusError = Foundations.Error,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    Resource,\n    Parameters &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Action>,\n    AcceptedResponse &\n      ResourceOperationStatus<Resource, StatusResult, StatusError> &\n      Foundations.LongRunningStatusLocation<StatusResult> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Action>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Long-running resource collection action operation template.\n   * @template Resource Resource type.\n   * @template Parameters Object describing the parameters of the operation.\n   * @template StatusResult Object describing the status result of the operation.\n   * @template StatusError Object describing the status error of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  #suppress "@azure-tools/typespec-providerhub/no-inline-model" "This operation signature is not used in Azure Resource Manager operations (yet)"\n  #suppress "@azure-tools/typespec-azure-resource-manager/no-response-body" "This operation must return a status monitor in its response."\n  @Foundations.Private.ensureVerb("LongRunningResourceCollectionAction", "POST")\n  @autoRoute\n  @collectionAction(Resource)\n  @actionSeparator(":")\n  LongRunningResourceCollectionAction<\n    Resource extends TypeSpec.Reflection.Model,\n    Parameters extends TypeSpec.Reflection.Model,\n    StatusResult extends TypeSpec.Reflection.Model,\n    StatusError = Foundations.Error,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceCollectionOperation<\n    Resource,\n    Parameters &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Parameters, TraitContext.Action>,\n    AcceptedResponse &\n      ResourceOperationStatus<Resource, StatusResult, StatusError> &\n      Foundations.LongRunningStatusLocation<StatusResult> &\n      TraitProperties<Traits & InterfaceTraits, TraitLocation.Response, TraitContext.Action>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n\n  /**\n   * Resource operation status operation template.\n   * @template Resource Resource type.\n   * @template StatusResult Object describing the status result of the operation.\n   * @template StatusError Object describing the status error of the operation.\n   * @template Traits Object describing the traits of the operation.\n   */\n  @Foundations.Private.ensureVerb("GetResourceOperationStatus", "GET")\n  @readsResource(ResourceOperationStatus<Resource>)\n  @Foundations.Private.ensureResourceType(Resource)\n  GetResourceOperationStatus<\n    Resource extends TypeSpec.Reflection.Model,\n    StatusResult = Resource,\n    StatusError = Foundations.Error,\n    Traits extends TypeSpec.Reflection.Model = {}\n  > is Foundations.ResourceOperation<\n    ResourceOperationStatus<Resource, StatusResult, StatusError>,\n    {},\n    ResourceOperationStatusResponse<Resource, StatusResult, StatusError>,\n    Traits & InterfaceTraits,\n    ErrorResponse\n  >;\n}\n\n// Resource Status Monitoring\n\n/**\n * Operation signature to retrieve a resource operation status.\n * @template Resource The type of the resource.\n * @template StatusResult Object describing the result of the status operation.\n * @template StatusError Object describing the error of the status operation. If not provided, the default error type is used.\n * @template Traits Traits to apply to the operation.\n */\n@readsResource(ResourceOperationStatus<Resource>)\n@Foundations.Private.ensureResourceType(Resource)\nop GetResourceOperationStatus<\n  Resource extends TypeSpec.Reflection.Model,\n  StatusResult = Resource,\n  StatusError = Foundations.Error,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is Foundations.ResourceOperation<\n  ResourceOperationStatus<Resource, StatusResult, StatusError>,\n  {},\n  ResourceOperationStatusResponse<Resource, StatusResult, StatusError>,\n  Traits\n>;\n',
  "../typespec-azure-core/lib/obsolete.tsp": '// This file contains operation template that are deprecated and shouldn\'t be used.\nimport "@typespec/http";\nimport "@typespec/rest";\nimport "@typespec/versioning";\nimport "./models.tsp";\nimport "./traits.tsp";\nimport "./operations.tsp";\n\nnamespace Azure.Core;\n\nusing Http;\nusing Rest;\nusing Versioning;\nusing Azure.Core.Traits;\nusing Azure.Core.Traits.Private;\n\nalias StandardResourceOperations = ResourceOperations<NoConditionalRequests &\n  NoRepeatableRequests &\n  NoClientRequestId>;\n\n/**\n * DEPRECATED: Use `ResourceCreateOrReplace` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to create or replace a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `ResourceCreateOrReplace` from a `ResourceOperations` interface instance."\nop ResourceCreateOrReplace<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceCreateOrReplace<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceCreateOrReplace` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature to create or replace a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `LongRunningResourceCreateOrReplace` from a `ResourceOperations` interface instance."\nop LongRunningResourceCreateOrReplace<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceCreateOrReplace<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceCreateOrUpdate` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to create or update a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `LongRunningResourceCreateOrReplace` from a `ResourceOperations` interface instance."\nop ResourceCreateOrUpdate<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceCreateOrUpdate<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceCreateOrUpdate` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature to create or update a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `LongRunningResourceCreateOrUpdate` from a `ResourceOperations` interface instance."\nop LongRunningResourceCreateOrUpdate<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceCreateOrUpdate<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceUpdate` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n * Operation signature to update a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `ResourceUpdate` from a `ResourceOperations` interface instance."\nop ResourceUpdate<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceUpdate<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceCreateWithServiceProvidedName` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to synchronously create a resource with a service-provided name.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `ResourceCreateWithServiceProvidedName` from a `ResourceOperations` interface instance."\nop ResourceCreateWithServiceProvidedName<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceCreateWithServiceProvidedName<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceCreateWithServiceProvidedName` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature to create a resource with a service-provided name.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\n#deprecated "Use `LongRunningResourceCreateWithServiceProvidedName` from a `ResourceOperations` interface instance."\nop LongRunningResourceCreateWithServiceProvidedName<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceCreateWithServiceProvidedName<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceRead` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to retrieve a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceRead<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceRead<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceDelete` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to delete a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceDelete<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceDelete<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceDelete` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature to delete a resource.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\nop LongRunningResourceDelete<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceDelete<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceList` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature to list resources in a paginated way.\n * @template Resource The type of the resource.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceList<\n  Resource extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceList<Resource, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceAction` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature for a resource action.\n * @template Resource The type of the resource.\n * @template Parameters Object describing the request parameters.\n * @template Response Object describing the response parameters.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceAction<\n  Resource extends TypeSpec.Reflection.Model,\n  Parameters extends TypeSpec.Reflection.Model,\n  Response extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceAction<Resource, Parameters, Response, Traits>;\n\n/**\n * DEPRECATED: Use `ResourceCollectionAction` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Operation signature for an action that applies to a collection of resources.\n * @template Resource The type of the resource.\n * @template Parameters Object describing the request parameters.\n * @template Response Object describing the response parameters.\n * @template Traits Traits to apply to the operation.\n */\nop ResourceCollectionAction<\n  Resource extends TypeSpec.Reflection.Model,\n  Parameters extends TypeSpec.Reflection.Model,\n  Response extends TypeSpec.Reflection.Model,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.ResourceCollectionAction<Resource, Parameters, Response, Traits>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceAction` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature for a resource action.\n * @template Resource The type of the resource.\n * @template Parameters Object describing the request parameters.\n * @template StatusResult Object describing the result of the status operation.\n * @template StatusError Object describing the error of the status operation. If not provided, the default error type is used.\n * @template Traits Traits to apply to the operation.\n */\nop LongRunningResourceAction<\n  Resource extends TypeSpec.Reflection.Model,\n  Parameters extends TypeSpec.Reflection.Model,\n  StatusResult extends TypeSpec.Reflection.Model,\n  StatusError = Foundations.Error,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceAction<\n  Resource,\n  Parameters,\n  StatusResult,\n  StatusError,\n  Traits\n>;\n\n/**\n * DEPRECATED: Use `LongRunningResourceCollectionAction` from a `ResourceOperations` interface instance.\n * This can be done by instantiating your own version with the traits you want `alias Operations = Azure.Core.ResourceOperations<ServiceTraits>;`.\n * See https://azure.github.io/typespec-azure/docs/getstarted/azure-core/step05#defining-the-operation-interface for details on how to use.\n *\n * Long-running operation signature for an action that applies to a collection of resources.\n * @template Resource The type of the resource.\n * @template Parameters Object describing the request parameters.\n * @template StatusResult Object describing the result of the status operation.\n * @template StatusError Object describing the error of the status operation. If not provided, the default error type is used.\n * @template Traits Traits to apply to the operation.\n */\nop LongRunningResourceCollectionAction<\n  Resource extends TypeSpec.Reflection.Model,\n  Parameters extends TypeSpec.Reflection.Model,\n  StatusResult extends TypeSpec.Reflection.Model,\n  StatusError = Foundations.Error,\n  Traits extends TypeSpec.Reflection.Model = {}\n> is StandardResourceOperations.LongRunningResourceCollectionAction<\n  Resource,\n  Parameters,\n  StatusResult,\n  StatusError,\n  Traits\n>;\n',
  "../typespec-azure-core/lib/decorators.tsp": 'using Reflection;\n\nnamespace Azure.Core {\n  /**\n   * Marks an Enum as being fixed since enums in Azure are\n   * assumed to be extensible.\n   */\n  extern dec fixed(target: Enum);\n\n  /**\n   * Marks a Model as a paged collection.\n   */\n  extern dec pagedResult(entity: Model);\n\n  /**\n   * Identifies the ModelProperty that contains the paged items. Can only be used on a Model marked with `@pagedResult`.\n   */\n  extern dec items(entity: ModelProperty);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies an Enum or ModelProperty as containing long-running operation\n   * status.\n   */\n  extern dec lroStatus(entity: Enum | Union | ModelProperty);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies an EnumMember as a long-running "Succeeded" terminal state.\n   */\n  extern dec lroSucceeded(entity: EnumMember | UnionVariant);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies an EnumMember as a long-running "Canceled" terminal state.\n   */\n  extern dec lroCanceled(entity: EnumMember | UnionVariant);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies an enum member as a long-running "Failed" terminal state.\n   */\n  extern dec lroFailed(entity: EnumMember | UnionVariant);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies a model property of a StatusMonitor as containing the result\n   * of a long-running operation that terminates successfully (Succeeded).\n   */\n  extern dec lroResult(entity: ModelProperty);\n\n  /**\n   * Used for custom StatusMonitor implementation.\n   * Identifies a model property of a StatusMonitor as containing the result\n   * of a long-running operation that terminates unsuccessfully (Failed).\n   */\n  extern dec lroErrorResult(entity: ModelProperty);\n\n  /**\n   * Identifies a model property as containing the location to poll for operation state.\n   * @param options PollingOptions for the poller pointed to by this link.  Overrides\n   * settings derived from property value it is decorating, if the value of the\n   * property is ResourceLocation<Resource>\n   */\n  extern dec pollingLocation(entity: ModelProperty, options?: PollingOptions);\n\n  /**\n   * Identifies a ModelProperty as containing the final location for the operation result.\n   * @param finalResult Sets the expected return value for the final result.  Overrides\n   * any value provided in the decorated property, if the property uses ResourceLocation<Resource>.\n   */\n  extern dec finalLocation(entity: ModelProperty, finalResult?: Model | void);\n\n  /**\n   * Identifies an operation that is linked to the target operation.\n   * @param linkedOperation The linked Operation\n   * @param linkType A string indicating the role of the linked operation\n   * @param parameters Map of `RequestParameter<Name>` and/or `ResponseProperty<Name>` that will\n   * be passed to the linked operation request.\n   */\n  extern dec operationLink(\n    entity: Operation,\n    linkedOperation: Operation,\n    linkType: valueof string,\n    parameters?: {}\n  );\n\n  /**\n   * Used to define how to call custom polling operations for long-running operations.\n   *\n   * @param targetParameter A reference to the polling operation parameter this parameter\n   * provides a value for, or the name of that parameter. The default value is the name of\n   * the decorated parameter or property.\n   */\n  extern dec pollingOperationParameter(\n    entity: ModelProperty,\n    targetParameter?: ModelProperty | string\n  );\n\n  /**\n   * Identifies that an operation is a polling operation for an LRO.\n   * @param linkedOperation The linked Operation\n   * @param parameters Map of `RequestParameter<Name>` and/or `ResponseProperty<Name>` that will\n   * be passed to the linked operation request.\n   */\n  extern dec pollingOperation(entity: Operation, linkedOperation: Operation, parameters?: {});\n\n  /**\n   * Identifies that an operation is the final operation for an LRO.\n   * @param linkedOperation The linked Operation\n   * @param parameters Map of `RequestParameter<Name>` and/or `ResponseProperty<Name>` that will\n   * be passed to the linked operation request.\n   */\n  extern dec finalOperation(entity: Operation, linkedOperation: Operation, parameters?: {});\n\n  /**\n   * Overrides the final state value for an operation\n   * @param finalState The desired final state value\n   */\n  extern dec useFinalStateVia(\n    entity: Operation,\n    finalState: valueof "original-uri" | "operation-location" | "location" | "azure-async-operation"\n  );\n\n  /**\n   * Identifies that an operation is used to retrieve the next page for paged operations.\n   * @param linkedOperation The linked Operation\n   * @param parameters Map of `RequestParameter<Name>` and/or `ResponseProperty<Name>` that will\n   * be passed to the linked operation request.\n   */\n  extern dec nextPageOperation(entity: Operation, linkedOperation: Operation, parameters?: {});\n}\n\nnamespace Azure.Core.Foundations {\n  /**\n   * Deletes any key properties from the model.\n   */\n  extern dec omitKeyProperties(entity: Model);\n\n  /**\n   * Identifies a property on a request model that serves as a linked operation parameter.\n   * @param name Property name on the target\n   */\n  extern dec requestParameter(entity: Model, name: valueof string);\n\n  /**\n   * Identifies a property on *all* non-error response models that serve as a linked operation parameter.\n   * @param name Property name on the target\n   */\n  extern dec responseProperty(entity: Model, name: valueof string);\n}\n\nnamespace Azure.Core.Foundations.Private {\n  /**\n   * Provides a Model describing parameter customizations to spread into the target.\n   * @param customizations Model describing the customization to spread\n   */\n  extern dec spreadCustomParameters(entity: Model, customizations: Model);\n\n  /**\n   * Provides a Model describing response property customizations to spread into the target.\n   * @param customizations Model describing the customization to spread\n   */\n  extern dec spreadCustomResponseProperties(entity: Model, customizations: Model);\n\n  /**\n   * Checks the Resource parameter of an operation signature to ensure it\'s a valid resource type.\n   * Also marks the operation as a resource operation.\n   * @param resourceType The possible resource Type to validate.\n   */\n  extern dec ensureResourceType(entity: TypeSpec.Reflection.Operation, resourceType: unknown);\n\n  /**\n   * Checks the Resource parameter of an operation signature to ensure it\'s a valid resource type.\n   */\n  extern dec needsRoute(entity: TypeSpec.Reflection.Operation);\n\n  /**\n   * Issues a warning if an operation which derives from an operation templated marked with `@ensureVerb`\n   * differs from the verb specified.\n   * @param templateName: Name of the template operation.\n   * @param verb The intended HTTP verb.\n   */\n  extern dec ensureVerb(\n    entity: TypeSpec.Reflection.Operation,\n    templateName: valueof string,\n    verb: valueof string\n  );\n\n  /**\n   * Identifies that a model should be treated as an embedding vector.\n   */\n  extern dec embeddingVector(entity: TypeSpec.Reflection.Model, type: TypeSpec.Reflection.Scalar);\n\n  model ArmResourceIdentifierConfigOptions {\n    allowedResources: ArmResourceIdentifierAllowedResource[];\n  }\n\n  /** Configuration for the armResourceIdentifier scalar */\n  extern dec armResourceIdentifierConfig(\n    target: Scalar,\n    options: ArmResourceIdentifierConfigOptions\n  );\n\n  /**\n   * Sets the priority order of default final-state-via options for an operation\n   * @param states: list of final-state-via options in priority order\n   */\n  extern dec defaultFinalStateVia(\n    target: TypeSpec.Reflection.Operation,\n    states: valueof ("operation-location" | "location" | "azure-async-operation")[]\n  );\n\n  /**\n   * Internal decorator marking a scalar as a next link that requires parameterization before use.\n   *\n   * You most likely don\'t need to use this decorator since next links that require parameterization are against\n   * guidelines.\n   */\n  extern dec parameterizedNextLinkConfig(target: Scalar, parameters: ModelProperty[]);\n}\n',
  "../typespec-azure-core/lib/legacy.tsp": "using TypeSpec.Reflection;\n\nnamespace Azure.Core.Legacy;\n\n/**\n * A scalar type representing a next link that requires formatting with parameters to be used.\n *\n * @example\n * ```typespec\n * model ListCertificateOptions {\n *   includePending?: string;\n * }\n * model Certificate {\n *   name: string;\n * }\n * model Page {\n *   @items items: Certificate[];\n *   @nextLink nextLink: Azure.Core.Legacy.parameterizedNextLink<[ListCertificateOptions.includePending]>;\n * }\n * ```\n */\n@Azure.Core.Foundations.Private.parameterizedNextLinkConfig(TypeSpec.Reflection.ModelProperty[])\nscalar parameterizedNextLink<ParameterizedParams extends TypeSpec.Reflection.ModelProperty[]>\n  extends url;\n",
  "lib/foundations/arm.foundations.tsp": 'import "@typespec/openapi";\nimport "@typespec/http";\nimport "@typespec/rest";\n\nimport "./backcompat.tsp";\nimport "./deprecation.tsp";\nimport "../common-types/common-types.tsp";\nimport "../decorators.tsp";\nimport "../responses.tsp";\nimport "../private.decorators.tsp";\nimport "../parameters.tsp";\n\nusing Http;\nusing OpenAPI;\nusing Azure.ResourceManager.Private;\n\nnamespace Azure.ResourceManager.Foundations;\n\n/**\n * Base parameters for a resource.\n *\n * @template Resource The type of the resource.\n */\nalias BaseParameters<Resource extends {}> = DefaultBaseParameters<Resource>;\n\n/**\n * Base parameters for a resource.\n * @template Resource The type of the resource.\n */\n@resourceBaseParametersOf(Resource)\nmodel DefaultBaseParameters<Resource extends {}> {\n  ...ApiVersionParameter;\n\n  // unless tenant or extension\n  ...SubscriptionIdParameter;\n\n  // deprecated, should not be used\n  ...LocationParameter;\n\n  // unless tenant, subscription, location, or extension\n  ...ResourceGroupParameter;\n\n  // unless tenant, subscription, location, or resourceGroup\n  ...ResourceUriParameter;\n}\n\n/**\n * Standard type definition for Azure Resource Manager Tags property.\n *\n * It is included in the TrackedResource template definition.\n */\n/** The Azure Resource Manager Resource tags. */\nmodel ArmTagsProperty {\n  /** Resource tags. */\n  tags?: Record<string>;\n}\n\n/**\n * The static parameters for a tenant-based resource\n */\nmodel TenantBaseParameters {\n  ...ApiVersionParameter;\n}\n\n/**\n * The static parameters for a subscription based resource\n */\nmodel SubscriptionBaseParameters is TenantBaseParameters {\n  ...SubscriptionIdParameter;\n}\n\n/**\n * The static parameters for a location-based resource\n */\nmodel LocationBaseParameters is SubscriptionBaseParameters {\n  ...LocationParameter;\n}\n\n/**\n * The static parameters for a resource-group based resource\n */\nmodel ResourceGroupBaseParameters is SubscriptionBaseParameters {\n  ...ResourceGroupParameter;\n}\n\n/**\n * The static parameters for an extension resource\n */\nmodel ExtensionBaseParameters is TenantBaseParameters {\n  ...ResourceUriParameter;\n}\n\n/**\n * Defines a properties type used to create named resource update models.\n * This type is not used directly, it is referenced by ResourceUpdateModel.\n * @template Resource The type of the resource.\n * @template Properties The type of the properties.\n */\n@doc("The updatable properties of the {name}.", Resource)\n@friendlyName("{name}UpdateProperties", Resource)\nmodel ResourceUpdateModelProperties<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model\n> is OptionalProperties<UpdateableProperties<Properties>>;\n\n/**\n * Defines a model type used to create named resource update models\n * e.g. `model MyResourceUpdate is ResourceUpdate<MyResourceProperties> {}`\n * @template Resource The type of the resource.\n * @template Properties The type of the properties.\n */\n@doc("The type used for update operations of the {name}.", Resource)\n@friendlyName("{name}Update", Resource)\n@omitIfEmpty("properties")\nmodel ResourceUpdateModel<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model\n>\n  is OptionalProperties<UpdateableProperties<OmitProperties<\n    Resource,\n    "Name" | "name" | "properties"\n  >>> {\n  /** The resource-specific properties for this resource. */\n  @conditionalClientFlatten\n  properties?: ResourceUpdateModelProperties<Resource, Properties>;\n}\n\n/**\n * The type used for updating tags in resources.\n * @template Resource The type of the resource.\n */\n@doc("The type used for updating tags in {name} resources.", Resource)\n@friendlyName("{name}TagsUpdate", Resource)\nmodel TagsUpdateModel<Resource extends Foundations.Resource> {\n  ...ArmTagsProperty;\n}\n\n// Tenant resource operation definitions\n\nalias TenantParentScope<Resource extends Foundations.Resource> = TenantScope<Resource>;\n\n/**\n * Parameter model for listing a resource at the tenant scope\n * @template Resource The type of the resource.\n */\nmodel TenantScope<Resource extends Foundations.Resource>\n  is ResourceParentParameters<Resource, TenantBaseParameters>;\n\n/**\n * Parameter model for listing a resource at the subscription scope\n * @template Resource The type of the resource.\n */\nmodel SubscriptionScope<Resource extends Foundations.Resource>\n  is ResourceParentParameters<Resource, SubscriptionBaseParameters>;\n\n/**\n * Parameter model for listing a resource at the location scope\n * @template Resource The type of the resource.\n */\nmodel LocationScope<Resource extends Foundations.Resource>\n  is ResourceParentParameters<Resource, LocationBaseParameters>;\n\n/**\n * Parameter model for listing an extension resource\n * @template Resource The type of the resource.\n */\nmodel ExtensionScope<Resource extends Foundations.Resource>\n  is ResourceParentParameters<Resource, ExtensionBaseParameters>;\n\n/**\n * Parameter model for listing a resource at the resource group scope\n * @template Resource The type of the resource.\n */\nmodel ResourceGroupScope<Resource extends Foundations.Resource>\n  is ResourceParentParameters<Resource>;\n\n/**\n * The type used for update operations of the resource.\n * @template Resource The type of the resource.\n * @template Properties The type of the properties.\n */\n@doc("The type used for update operations of the {name}.", Resource)\n@friendlyName("{name}Update", Resource)\nmodel ProxyResourceUpdateModel<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model\n> {\n  @conditionalClientFlatten\n  properties?: ResourceUpdateModelProperties<Resource, Properties>;\n}\n\nalias DefaultProviderNamespace = {\n  @path\n  @TypeSpec.Rest.segment("providers")\n  @doc("The provider namespace for the resource.")\n  provider: "Microsoft.ThisWillBeReplaced";\n};\n\n/**\n * Adds check name availability operation, normally used if\n * a resource name must be globally unique (for example, if the resource\n * exposes an endpoint that uses the resource name in the url)\n * @template ScopeParameters A parameter model with properties representing the scope of the resource\n * @template Request The operation request body\n * @template Response The operation response\n * @template AdditionalParams A parameter model with properties representing non-path parameters\n */\n@TypeSpec.Rest.autoRoute\n@armResourceCollectionAction\n@armProviderNameValue\n@doc("Implements global CheckNameAvailability operations")\n@TypeSpec.Rest.action("checkNameAvailability")\n@post\nop checkNameAvailability<\n  ScopeParameters extends TypeSpec.Reflection.Model,\n  Request extends TypeSpec.Reflection.Model = Azure.ResourceManager.Foundations.CheckNameAvailabilityRequest,\n  Response extends TypeSpec.Reflection.Model = CheckNameAvailabilityResponse,\n  AdditionalParams extends TypeSpec.Reflection.Model = {}\n>(\n  ...ApiVersionParameter,\n  ...ScopeParameters,\n  ...AdditionalParams,\n\n  @doc("The CheckAvailability request")\n  @body\n  body: Request,\n): Response | ErrorResponse;\n\n/**\n * @dev The base template for Azure Resource Manager GET and HEAD Operations.\n * @param Parameters The parameter object for the operation.\n * @param Response The response or union of responses for success.\n * @param ErrorResponse The error response.\n */\nop ArmReadOperation<Parameters extends {}, Response extends {}, ErrorResponse extends {}>(\n  ...Parameters,\n): Response | ErrorResponse;\n\n/**\n * @dev The base template for Azure Resource Manager PUT Operations.\n * @param HttpParameters The parameter object for the operation.\n * @param BodyParameter The body parameter\n * @param Response The response or union of responses for success.\n * @param ErrorResponse The error response.\n */\nop ArmCreateOperation<\n  HttpParameters extends {},\n  BodyParameter extends {},\n  Response extends {},\n  ErrorResponse extends {}\n>(\n  ...HttpParameters,\n  @doc("Resource create parameters.") @bodyRoot resource: BodyParameter,\n): Response | ErrorResponse;\n\n/**\n * @dev The base template for Azure Resource Manager PATCH Operations.\n * @param HttpParameters The parameter object for the operation.\n * @param BodyParameter The body parameter\n * @param Response The response or union of responses for success.\n * @param ErrorResponse The error response.\n */\nop ArmUpdateOperation<\n  HttpParameters extends {},\n  BodyParameter extends {},\n  Response extends {},\n  ErrorResponse extends {}\n>(\n  ...HttpParameters,\n  @doc("The resource properties to be updated.") @bodyRoot properties: BodyParameter,\n): Response | ErrorResponse;\n',
  "lib/foundations/backcompat.tsp": 'namespace Azure.ResourceManager.Foundations {\n  // extended-location\n  alias ExtendedLocation = CommonTypes.ExtendedLocation;\n  alias ExtendedLocationType = CommonTypes.ExtendedLocationType;\n\n  // managed-identities\n  alias ManagedServiceIdentity = CommonTypes.ManagedServiceIdentity;\n  #suppress "deprecated" "Need for back compatibility in common-types"\n  alias UserAssignedIdentities = CommonTypes.UserAssignedIdentities;\n  alias SystemAssignedServiceIdentity = CommonTypes.SystemAssignedServiceIdentity;\n  alias UserAssignedIdentity = CommonTypes.UserAssignedIdentity;\n  alias ManagedServiceIdentityType = CommonTypes.ManagedServiceIdentityType;\n  alias SystemAssignedServiceIdentityType = CommonTypes.SystemAssignedServiceIdentityType;\n  alias ManagedSystemIdentityType = SystemAssignedServiceIdentityType;\n\n  // types\n  alias Resource = CommonTypes.Resource;\n  alias AzureEntityResource = CommonTypes.AzureEntityResource;\n  alias TrackedResource = CommonTypes.TrackedResource;\n  alias ProxyResource = CommonTypes.ProxyResource;\n  alias ExtensionResource = CommonTypes.ExtensionResource;\n  alias Sku = CommonTypes.Sku;\n  alias SkuTier = CommonTypes.SkuTier;\n  alias OperationListResult = CommonTypes.OperationListResult;\n  alias Operation = CommonTypes.Operation;\n  alias OperationDisplay = CommonTypes.OperationDisplay;\n  alias OperationStatusResult = CommonTypes.OperationStatusResult;\n  alias OperationIdParameter = CommonTypes.OperationIdParameter;\n  alias ActionType = CommonTypes.ActionType;\n  alias Origin = CommonTypes.Origin;\n  alias ErrorDetail = CommonTypes.ErrorDetail;\n  alias ErrorAdditionalInfo = CommonTypes.ErrorAdditionalInfo;\n  alias SystemData = CommonTypes.SystemData;\n  alias createdByType = CommonTypes.createdByType;\n  alias Plan = CommonTypes.Plan;\n  alias CheckNameAvailabilityRequest = CommonTypes.CheckNameAvailabilityRequest;\n  alias CheckNameAvailabilityResponse = CommonTypes.CheckNameAvailabilityResponse;\n  alias CheckNameAvailabilityReason = CommonTypes.CheckNameAvailabilityReason;\n}\n',
  "lib/foundations/deprecation.tsp": 'namespace Azure.ResourceManager.Foundations;\n\n#deprecated "Please use Foundations.Resource instead of Foundations.ArmResource"\nalias ArmResource = Resource;\n\n#deprecated "Please use Foundations.TrackedResource instead of Foundations.TrackedResourceBase"\nalias TrackedResourceBase = TrackedResource;\n\n#deprecated "Please use Foundations.ProxyResource instead of Foundations.ProxyResourceBase"\nalias ProxyResourceBase = ProxyResource;\n\n#deprecated "Please use Foundations.ProxyResource instead of Foundations.ExtensionResourceBase"\nalias ExtensionResourceBase = ExtensionResource;\n\n#deprecated "Please use Foundations.Sku instead of Foundations.ResourceSkuType"\nalias ResourceSkuType = Sku;\n\n#deprecated "Please use Foundations.Plan instead of Foundations.ResourcePlanType"\nalias ResourcePlanType = Plan;\n\n// managed-identity\n#deprecated "Please change ManagedIdentityProperties to ManagedServiceIdentity."\nalias ManagedIdentityProperties = ManagedServiceIdentity;\n\n#deprecated "Please change ManagedSystemIdentityProperties to SystemAssignedServiceIdentity."\nalias ManagedSystemIdentityProperties = SystemAssignedServiceIdentity;\n\n/** Alias of ManagedServiceIdentityType for back compatability. Please change to ManagedServiceIdentityType. */\n#deprecated "Please change to ManagedServiceIdentityType."\nalias ManagedIdentityType = ManagedServiceIdentityType;\n',
  "lib/common-types/common-types.tsp": 'import "@typespec/versioning";\nimport "@azure-tools/typespec-azure-core";\nimport "./common-types.tsp";\nimport "./types-ref.tsp";\nimport "./managed-identity-ref.tsp";\nimport "./managed-identity-with-delegation-ref.tsp";\nimport "./private-links-ref.tsp";\nimport "./customer-managed-keys-ref.tsp";\nimport "./extended-location-ref.tsp";\nimport "./internal.tsp";\nimport "./commontypes.private.decorators.tsp";\nimport "./versions.tsp";\nimport "./mobo-ref.tsp";\nimport "./network-security-perimeter-ref.tsp";\n\nnamespace Azure.ResourceManager.CommonTypes;\n',
  "lib/common-types/types-ref.tsp": 'import "../private.decorators.tsp";\nimport "./common-types.tsp";\nimport "./types.tsp";\n\nusing Azure.ResourceManager.Private;\nusing Azure.ResourceManager.CommonTypes.Private;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n@@azureResourceBase(Resource);\n@@azureResourceBase(ResourceModelWithAllowedPropertySet);\n\n/** Common resource fields that are returned in the response for all Azure Resource Manager resources. */\n@@armCommonDefinition(Resource, "Resource", Azure.ResourceManager.CommonTypes.Versions.v3);\n@@armCommonDefinition(Resource, "Resource", Azure.ResourceManager.CommonTypes.Versions.v4);\n@@armCommonDefinition(Resource, "Resource", Azure.ResourceManager.CommonTypes.Versions.v5);\n@@armCommonDefinition(Resource, "Resource", Azure.ResourceManager.CommonTypes.Versions.v6);\n\n/** The resource model definition for an Azure Resource Manager resource with an etag. */\n@@armCommonDefinition(AzureEntityResource,\n  "TrackedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(AzureEntityResource,\n  "TrackedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(AzureEntityResource,\n  "TrackedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(AzureEntityResource,\n  "TrackedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * The base tracked resource.\n */\n@@armCommonDefinition(TrackedResource,\n  "TrackedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(TrackedResource,\n  "TrackedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(TrackedResource,\n  "TrackedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(TrackedResource,\n  "TrackedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * The base proxy resource.\n */\n@@armCommonDefinition(ProxyResource,\n  "ProxyResource",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(ProxyResource,\n  "ProxyResource",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(ProxyResource,\n  "ProxyResource",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(ProxyResource,\n  "ProxyResource",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * The base extension resource.\n */\n@@armCommonDefinition(ExtensionResource,\n  "ProxyResource",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(ExtensionResource,\n  "ProxyResource",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(ExtensionResource,\n  "ProxyResource",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(ExtensionResource,\n  "ProxyResource",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * The SKU (Stock Keeping Unit) assigned to this resource.\n */\n@@armCommonDefinition(Sku, "Sku", Azure.ResourceManager.CommonTypes.Versions.v3);\n@@armCommonDefinition(Sku, "Sku", Azure.ResourceManager.CommonTypes.Versions.v4);\n@@armCommonDefinition(Sku, "Sku", Azure.ResourceManager.CommonTypes.Versions.v5);\n@@armCommonDefinition(Sku, "Sku", Azure.ResourceManager.CommonTypes.Versions.v6);\n\n/**\n * A list of REST API operations supported by an Azure Resource Provider. It contains an URL link to get the next set of results.\n */\n@@armCommonDefinition(OperationListResult,\n  "OperationListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(OperationListResult,\n  "OperationListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(OperationListResult,\n  "OperationListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(OperationListResult,\n  "OperationListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * Details of a REST API operation, returned from the Resource Provider Operations API\n */\n@@armCommonDefinition(Operation, "Operation", Azure.ResourceManager.CommonTypes.Versions.v3);\n@@armCommonDefinition(Operation, "Operation", Azure.ResourceManager.CommonTypes.Versions.v4);\n@@armCommonDefinition(Operation, "Operation", Azure.ResourceManager.CommonTypes.Versions.v5);\n@@armCommonDefinition(Operation, "Operation", Azure.ResourceManager.CommonTypes.Versions.v6);\n\n/**\n * Localized display information for and operation.\n */\n@@armCommonDefinition(OperationDisplay,\n  "OperationDisplay",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(OperationDisplay,\n  "OperationDisplay",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(OperationDisplay,\n  "OperationDisplay",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(OperationDisplay,\n  "OperationDisplay",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * The current status of an async operation.\n */\n@@armCommonDefinition(OperationStatusResult,\n  "OperationStatusResult",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(OperationStatusResult,\n  "OperationStatusResult",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(OperationStatusResult,\n  "OperationStatusResult",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(OperationStatusResult,\n  "OperationStatusResult",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * locationData\n */\n@@armCommonDefinition(LocationData, "locationData", Azure.ResourceManager.CommonTypes.Versions.v3);\n@@armCommonDefinition(LocationData, "locationData", Azure.ResourceManager.CommonTypes.Versions.v4);\n@@armCommonDefinition(LocationData, "locationData", Azure.ResourceManager.CommonTypes.Versions.v5);\n@@armCommonDefinition(LocationData, "locationData", Azure.ResourceManager.CommonTypes.Versions.v6);\n\n/**\n * The error detail.\n */\n@@armCommonDefinition(ErrorDetail, "ErrorDetail", Azure.ResourceManager.CommonTypes.Versions.v3);\n@@armCommonDefinition(ErrorDetail, "ErrorDetail", Azure.ResourceManager.CommonTypes.Versions.v4);\n@@armCommonDefinition(ErrorDetail, "ErrorDetail", Azure.ResourceManager.CommonTypes.Versions.v5);\n@@armCommonDefinition(ErrorDetail, "ErrorDetail", Azure.ResourceManager.CommonTypes.Versions.v6);\n\n/**\n * The resource management error additional info.\n */\n@@armCommonDefinition(ErrorAdditionalInfo,\n  "ErrorAdditionalInfo",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(ErrorAdditionalInfo,\n  "ErrorAdditionalInfo",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(ErrorAdditionalInfo,\n  "ErrorAdditionalInfo",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(ErrorAdditionalInfo,\n  "ErrorAdditionalInfo",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * Identity\n */\n@@armCommonDefinition(Identity, "Identity", Azure.ResourceManager.CommonTypes.Versions.v3);\n@@armCommonDefinition(Identity, "Identity", Azure.ResourceManager.CommonTypes.Versions.v4);\n@@armCommonDefinition(Identity, "Identity", Azure.ResourceManager.CommonTypes.Versions.v5);\n\n/**\n * Metadata pertaining to creation and last modification of the resource.\n */\n@@armCommonDefinition(SystemData, "systemData", Azure.ResourceManager.CommonTypes.Versions.v3);\n@@armCommonDefinition(SystemData, "systemData", Azure.ResourceManager.CommonTypes.Versions.v4);\n@@armCommonDefinition(SystemData, "systemData", Azure.ResourceManager.CommonTypes.Versions.v5);\n@@armCommonDefinition(SystemData, "systemData", Azure.ResourceManager.CommonTypes.Versions.v6);\n\n/**\n * Details of the resource plan.\n */\n@@armCommonDefinition(Plan, "Plan", Azure.ResourceManager.CommonTypes.Versions.v3);\n@@armCommonDefinition(Plan, "Plan", Azure.ResourceManager.CommonTypes.Versions.v4);\n@@armCommonDefinition(Plan, "Plan", Azure.ResourceManager.CommonTypes.Versions.v5);\n@@armCommonDefinition(Plan, "Plan", Azure.ResourceManager.CommonTypes.Versions.v6);\n\n/**\n * encryptionProperties\n */\n@@armCommonDefinition(EncryptionProperties,\n  "encryptionProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(EncryptionProperties,\n  "encryptionProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(EncryptionProperties,\n  "encryptionProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(EncryptionProperties,\n  "encryptionProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * KeyVaultProperties\n */\n@@armCommonDefinition(KeyVaultProperties,\n  "KeyVaultProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(KeyVaultProperties,\n  "KeyVaultProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(KeyVaultProperties,\n  "KeyVaultProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(KeyVaultProperties,\n  "KeyVaultProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * ResourceModelWithAllowedPropertySet\n */\n@@armCommonDefinition(ResourceModelWithAllowedPropertySet,\n  "ResourceModelWithAllowedPropertySet",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(ResourceModelWithAllowedPropertySet,\n  "ResourceModelWithAllowedPropertySet",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(ResourceModelWithAllowedPropertySet,\n  "ResourceModelWithAllowedPropertySet",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(ResourceModelWithAllowedPropertySet,\n  "ResourceModelWithAllowedPropertySet",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * The check availability request body.\n */\n@@armCommonDefinition(CheckNameAvailabilityRequest,\n  "CheckNameAvailabilityRequest",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(CheckNameAvailabilityRequest,\n  "CheckNameAvailabilityRequest",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(CheckNameAvailabilityRequest,\n  "CheckNameAvailabilityRequest",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(CheckNameAvailabilityRequest,\n  "CheckNameAvailabilityRequest",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * The check availability result.\n */\n@@armCommonDefinition(CheckNameAvailabilityResponse,\n  "CheckNameAvailabilityResponse",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(CheckNameAvailabilityResponse,\n  "CheckNameAvailabilityResponse",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(CheckNameAvailabilityResponse,\n  "CheckNameAvailabilityResponse",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(CheckNameAvailabilityResponse,\n  "CheckNameAvailabilityResponse",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n@@armCommonDefinition(ErrorResponse,\n  "ErrorResponse",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonDefinition(ErrorResponse,\n  "ErrorResponse",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(ErrorResponse,\n  "ErrorResponse",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(ErrorResponse,\n  "ErrorResponse",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n@@armCommonDefinition(SkuTier, "SkuTier", Azure.ResourceManager.CommonTypes.Versions.v3);\n@@armCommonDefinition(SkuTier, "SkuTier", Azure.ResourceManager.CommonTypes.Versions.v4);\n@@armCommonDefinition(SkuTier, "SkuTier", Azure.ResourceManager.CommonTypes.Versions.v5);\n@@armCommonDefinition(SkuTier, "SkuTier", Azure.ResourceManager.CommonTypes.Versions.v6);\n\n// -- Parameters\n/** ApiVersionParameter */\n@@armCommonParameter(ApiVersionParameter.apiVersion,\n  "ApiVersionParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonParameter(ApiVersionParameter.apiVersion,\n  "ApiVersionParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonParameter(ApiVersionParameter.apiVersion,\n  "ApiVersionParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonParameter(ApiVersionParameter.apiVersion,\n  "ApiVersionParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n@@resourceParameterBaseFor(ApiVersionParameter.apiVersion,\n  [\n    ResourceHome.ResourceGroup,\n    ResourceHome.Subscription,\n    ResourceHome.Location,\n    ResourceHome.Tenant,\n    ResourceHome.Extension\n  ]\n);\n\n/** SubscriptionIdParameter */\n@@armCommonParameter(SubscriptionIdParameter.subscriptionId,\n  "SubscriptionIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonParameter(SubscriptionIdParameter.subscriptionId,\n  "SubscriptionIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonParameter(SubscriptionIdParameter.subscriptionId,\n  "SubscriptionIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonParameter(SubscriptionIdParameter.subscriptionId,\n  "SubscriptionIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n@@resourceParameterBaseFor(SubscriptionIdParameter.subscriptionId,\n  [ResourceHome.ResourceGroup, ResourceHome.Subscription, ResourceHome.Location]\n);\n\n/** ResourceGroupNameParameter */\n@@armCommonParameter(ResourceGroupNameParameter.resourceGroupName,\n  "ResourceGroupNameParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonParameter(ResourceGroupNameParameter.resourceGroupName,\n  "ResourceGroupNameParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonParameter(ResourceGroupNameParameter.resourceGroupName,\n  "ResourceGroupNameParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonParameter(ResourceGroupNameParameter.resourceGroupName,\n  "ResourceGroupNameParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n@@resourceParameterBaseFor(ResourceGroupNameParameter.resourceGroupName,\n  [ResourceHome.ResourceGroup]\n);\n\n/** ManagementGroupNameParameter */\n@@armCommonParameter(ManagementGroupNameParameter.managementGroupName,\n  "ManagementGroupNameParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonParameter(ManagementGroupNameParameter.managementGroupName,\n  "ManagementGroupNameParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonParameter(ManagementGroupNameParameter.managementGroupName,\n  "ManagementGroupNameParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonParameter(ManagementGroupNameParameter.managementGroupName,\n  "ManagementGroupNameParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/** ScopeParameter */\n@@armCommonParameter(ScopeParameter.scope,\n  "ScopeParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonParameter(ScopeParameter.scope,\n  "ScopeParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonParameter(ScopeParameter.scope,\n  "ScopeParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonParameter(ScopeParameter.scope,\n  "ScopeParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/** LocationResourceParameter */\n@@armCommonParameter(LocationResourceParameter.location,\n  "LocationParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonParameter(LocationResourceParameter.location,\n  "LocationParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonParameter(LocationResourceParameter.location,\n  "LocationParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonParameter(LocationResourceParameter.location,\n  "LocationParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * The default operationId parameter type.\n */\n@@armCommonParameter(OperationIdParameter.operationId,\n  "OperationIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonParameter(OperationIdParameter.operationId,\n  "OperationIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonParameter(OperationIdParameter.operationId,\n  "OperationIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonParameter(OperationIdParameter.operationId,\n  "OperationIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/**\n * TenantIdParameter\n */\n@@armCommonParameter(TenantIdParameter.tenantId,\n  "TenantIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v3\n);\n@@armCommonParameter(TenantIdParameter.tenantId,\n  "TenantIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonParameter(TenantIdParameter.tenantId,\n  "TenantIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonParameter(TenantIdParameter.tenantId,\n  "TenantIdParameter",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n',
  "lib/private.decorators.tsp": 'import "../dist/src/private.decorators.js";\n\nnamespace Azure.ResourceManager.Private;\n\nusing Reflection;\n\n/**\n * Update the Azure Resource Manager provider namespace for a given entity.\n */\nextern dec armUpdateProviderNamespace(target: Reflection.Operation);\n\n/**\n * @param resource Resource model\n */\nextern dec assignProviderNameValue(target: ModelProperty, resource: Model);\n\n/**\n * This decorator is used to identify Azure Resource Manager resource types and extract their\n * metadata.  It is *not* meant to be used directly by a spec author, it instead\n * gets implicitly applied when the spec author defines a model type in this form:\n *\n *   `model Server is TrackedResource<ServerProperties>;`\n *\n * The `TrackedResource<Resource>` type (and other associated base types) use the\n * `@armResource` decorator, so it also gets applied to the type which absorbs the\n * `TrackedResource<Resource>` definition by using the `is` keyword.\n *\n * @param properties Azure Resource Manager resource properties\n */\nextern dec armResourceInternal(target: Model, properties: Model);\n\n/**\n * Omit a property in the target model.\n * @internal\n * @param propertyName Name of the property to omit\n */\nextern dec omitIfEmpty(target: Model, propertyName: valueof string);\n\n/**\n * @param propertyName Name of the property to omit\n */\nextern dec resourceBaseParametersOf(target: Model, propertyName: Model);\n/**\n * @param values Values\n */\nextern dec resourceParameterBaseFor(target: ModelProperty, values: unknown[]);\n\n/**\n * Provides default name decoration on resource name property with\n * camelcased and pluralized key and segment name\n */\nextern dec defaultResourceKeySegmentName(\n  target: ModelProperty,\n  armResource: Model,\n  keyName: valueof string,\n  segment: valueof string\n);\n\n/**\n * Provides strict contraint type check.\n *\n * Due to TypeSpec language and all optional properties of `Foundations.Resource`,\n * the `Resource extends Foundations.Resource` on many of the standard ARM templates is\n * essentially equal to `Resource extends {}` and does not enforce the containt.\n *\n * Note, this is intended for internal use only for now.\n */\nextern dec enforceConstraint(target: Operation | Model, sourceType: Model, constraintType: Model);\n\n/**\n * This decorator is used to identify Azure Resource Manager resource. In generated\n * swagger definition, it will be marked with `x-ms-azure-resource`.\n *\n * It is *not* meant to be used directly by a spec author,\n */\nextern dec azureResourceBase(target: Model);\n\n/**\n * Please DO NOT USE in RestAPI specs.\n * Internal decorator that deprecated direct usage of `x-ms-client-flatten` OpenAPI extension.\n * It will programatically enabled/disable client flattening with @flattenProperty with autorest\n * emitter flags to maintain compatibility in swagger.\n */\nextern dec conditionalClientFlatten(target: ModelProperty);\n\n/**\n * Marks the operation as being a collection action\n * @param resourceType Resource\n * @param parentTypeName: Parent type name.\n * @param parentFriendlyTypeName Friendly name for parent.\n * @param applyOperationRename If true, apply both doc and operation name update\n */\nextern dec armRenameListByOperation(\n  target: Operation,\n  resourceType: Model,\n  parentTypeName?: valueof string,\n  parentFriendlyTypeName?: valueof string,\n  applyOperationRename?: valueof boolean\n);\n\n/**\n * Please DO NOT USE in RestAPI specs.\n * This decorator is used to adjust optionality on ARM Resource\'s `properties` field for brownfield service conversion.\n */\nextern dec armResourcePropertiesOptionality(target: ModelProperty, isOptional: valueof boolean);\n',
  "lib/common-types/types.tsp": `using Http;
using Rest;
using OpenAPI;
using Versioning;
using Azure.Core;

namespace Azure.ResourceManager.CommonTypes;

/** Common fields that are returned in the response for all Azure Resource Manager resources */
@summary("Resource")
model Resource {
  /** Fully qualified resource ID for the resource. Ex - /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/{resourceProviderNamespace}/{resourceType}/{resourceName} */
  @typeChangedFrom(Versions.v4, string)
  @visibility(Lifecycle.Read)
  id?: armResourceIdentifier;

  /** The name of the resource */
  @visibility(Lifecycle.Read)
  name?: string;

  /** The type of the resource. E.g. "Microsoft.Compute/virtualMachines" or "Microsoft.Storage/storageAccounts" */
  @visibility(Lifecycle.Read)
  type?: armResourceType;

  /** Azure Resource Manager metadata containing createdBy and modifiedBy information. */
  @visibility(Lifecycle.Read)
  systemData?: SystemData;
}

/** The resource model definition for an Azure Resource Manager resource with an etag. */
@summary("Entity Resource")
model AzureEntityResource extends Resource {
  /** Resource Etag. */
  @visibility(Lifecycle.Read)
  etag?: string;
}

/**
 * The resource model definition for an Azure Resource Manager tracked top level resource which has 'tags' and a 'location'
 */
@summary("Tracked Resource")
model TrackedResource extends Resource {
  /** Resource tags. */
  tags?: Record<string>;

  /** The geo-location where the resource lives */
  @visibility(Lifecycle.Read, Lifecycle.Create)
  location: string;
}

/**
 * The resource model definition for a Azure Resource Manager proxy resource. It will not have tags and a location
 */
@summary("Proxy Resource")
model ProxyResource extends Resource {}

/**
 * The base extension resource.
 */
// Note that ProxyResource is the base definition for both kinds of resources
model ExtensionResource extends Resource {}

/**
 * The resource model definition containing the full set of allowed properties for a resource. Except properties bag, there cannot be a top level property outside of this set.
 */
model ResourceModelWithAllowedPropertySet extends TrackedResource {
  /** The fully qualified resource ID of the resource that manages this resource. Indicates if this resource is managed by another Azure resource.
   * If this is present, complete mode deployment will not delete the resource if it is removed from the template since it is managed by another resource. */
  managedBy?: string;

  /** Metadata used by portal/tooling/etc to render different UX experiences for resources of the same type; e.g. ApiApps are a kind of Microsoft.Web/sites type.
   * If supported, the resource provider must validate and persist this value. */
  @pattern("^[-\\\\w\\\\._,\\\\(\\\\)]+$")
  @visibility(Lifecycle.Read, Lifecycle.Create)
  kind?: string;

  /** The etag field is *not* required. If it is provided in the response body, it must also be provided as a header per the normal etag convention.
   * Entity tags are used for comparing two or more entities from the same requested resource. HTTP/1.1 uses entity tags in the etag (section 14.19),
   * If-Match (section 14.24), If-None-Match (section 14.26), and If-Range (section 14.27) header fields. */
  @visibility(Lifecycle.Read)
  etag?: string;

  @typeChangedFrom(Versions.v6, Identity)
  identity?: ManagedServiceIdentity;

  sku?: Sku;
  plan?: Plan;
}

/**
 * The resource model definition representing SKU
 */
model Sku {
  /** The name of the SKU. Ex - P3. It is typically a letter+number code */
  name: string;

  /** This field is required to be implemented by the Resource Provider if the service has more than one tier, but is not required on a PUT. */
  tier?: SkuTier;

  /** The SKU size. When the name field is the combination of tier and some other value, this would be the standalone code. */
  size?: string;

  /** If the service has different generations of hardware, for the same SKU, then that can be captured here. */
  family?: string;

  /** If the SKU supports scale out/in then the capacity integer should be included. If scale out/in is not possible for the resource this may be omitted. */
  capacity?: int32;
}

/**
 * This field is required to be implemented by the Resource Provider if the service has more than one tier, but is not required on a PUT.
 */
union SkuTier {
  /** The Free service tier. */
  Free: "Free",

  /** The Basic service tier. */
  Basic: "Basic",

  /** The Standard service tier. */
  Standard: "Standard",

  /** The Premium service tier. */
  Premium: "Premium",
}

/**
 * A list of REST API operations supported by an Azure Resource Provider. It contains an URL link to get the next set of results.
 */
@friendlyName("OperationListResult")
model OperationListResult is Azure.Core.Page<Operation>;

/**
 * Details of a REST API operation, returned from the Resource Provider Operations API
 */
@summary("REST API Operation")
model Operation {
  /** 
    The name of the operation, as per Resource-Based Access Control (RBAC). Examples: "Microsoft.Compute/virtualMachines/write", "Microsoft.Compute/virtualMachines/capture/action"
     */
  @visibility(Lifecycle.Read)
  name?: string;

  /** 
    Whether the operation applies to data-plane. This is "true" for data-plane operations and "false" for Azure Resource Manager/control-plane operations.
     */
  @visibility(Lifecycle.Read)
  isDataAction?: boolean;

  /** Localized display information for this particular operation. */
  display?: OperationDisplay;

  /** 
    The intended executor of the operation; as in Resource Based Access Control (RBAC) and audit logs UX. Default value is "user,system"
     */
  @visibility(Lifecycle.Read)
  origin?: Origin;

  /** 
    Extensible enum. Indicates the action type. "Internal" refers to actions that are for internal only APIs.
     */
  @visibility(Lifecycle.Read)
  actionType?: ActionType;
}

/**
 * Localized display information for and operation.
 */
model OperationDisplay {
  /** 
  The localized friendly form of the resource provider name, e.g. "Microsoft Monitoring Insights" or "Microsoft Compute".
   */
  @visibility(Lifecycle.Read)
  provider?: string;

  /** 
    The localized friendly name of the resource type related to this operation. E.g. "Virtual Machines" or "Job Schedule Collections".
     */
  @visibility(Lifecycle.Read)
  resource?: string;

  /** 
    The concise, localized friendly name for the operation; suitable for dropdowns. E.g. "Create or Update Virtual Machine", "Restart Virtual Machine".
     */
  @visibility(Lifecycle.Read)
  operation?: string;

  /** The short, localized friendly description of the operation; suitable for tool tips and detailed views. */
  @visibility(Lifecycle.Read)
  description?: string;
}

/**
 * The current status of an async operation.
 */
model OperationStatusResult {
  /** Fully qualified ID for the async operation. */
  @typeChangedFrom(Versions.v5, string)
  id?: armResourceIdentifier;

  /** Name of the async operation. */
  name?: string;

  /** Operation status. */
  status: string;

  /** Percent of the operation that is complete. */
  @minValue(0)
  @maxValue(100)
  percentComplete?: float64;

  /** The start time of the operation. */
  startTime?: utcDateTime;

  /** The end time of the operation. */
  endTime?: utcDateTime;

  /** The operations list. */
  operations?: OperationStatusResult[];

  /** If present, details of the operation error. */
  error?: ErrorDetail;

  /** Fully qualified ID of the resource against which the original async operation was started. */
  @visibility(Lifecycle.Read)
  @added(Versions.v5)
  resourceId?: armResourceIdentifier;
}

/**
 * Extensible enum. Indicates the action type. "Internal" refers to actions that are for internal only APIs.
 */
union ActionType {
  /** Actions are for internal-only APIs. */
  Internal: "Internal",

  string,
}

/**
 * The intended executor of the operation; as in Resource Based Access Control (RBAC) and audit logs UX. Default value is "user,system"
 */
union Origin {
  /** Indicates the operation is initiated by a user. */
  user: "user",

  /** Indicates the operation is initiated by a system. */
  system: "system",

  /** Indicates the operation is initiated by a user or system. */
  \`user,system\`: "user,system",

  string,
}

/**
 * The error detail.
 */
model ErrorDetail {
  /** The error code. */
  @visibility(Lifecycle.Read)
  code?: string;

  /** The error message. */
  @visibility(Lifecycle.Read)
  message?: string;

  /** The error target. */
  @visibility(Lifecycle.Read)
  target?: string;

  /** The error details. */
  @visibility(Lifecycle.Read)
  details?: ErrorDetail[];

  /** The error additional info. */
  @visibility(Lifecycle.Read)
  additionalInfo?: ErrorAdditionalInfo[];
}

/**
 * Common error response for all Azure Resource Manager APIs to return error details for failed operations.
 */
@summary("Error response")
@error
model ErrorResponse {
  /** The error object. */
  error?: ErrorDetail;
}

/**
 * The resource management error additional info.
 */
model ErrorAdditionalInfo {
  /** The additional info type. */
  @visibility(Lifecycle.Read)
  type?: string;

  /** The additional info. */
  @visibility(Lifecycle.Read)
  info?: {};
}

/**
 * Metadata pertaining to creation and last modification of the resource.
 */
model SystemData {
  /** The identity that created the resource. */
  createdBy?: string;

  /** The type of identity that created the resource. */
  createdByType?: createdByType;

  /** The timestamp of resource creation (UTC). */
  createdAt?: utcDateTime;

  /** The identity that last modified the resource. */
  lastModifiedBy?: string;

  /** The type of identity that last modified the resource. */
  lastModifiedByType?: createdByType;

  /** The timestamp of resource last modification (UTC) */
  lastModifiedAt?: utcDateTime;
}

/**
 * The kind of entity that created the resource.
 */
// NOTE: This is how the extensible enum is named in types.json
union createdByType {
  /** The entity was created by a user. */
  User: "User",

  /** The entity was created by an application. */
  Application: "Application",

  /** The entity was created by a managed identity. */
  ManagedIdentity: "ManagedIdentity",

  /** The entity was created by a key. */
  Key: "Key",

  string,
}

union ResourceIdentityType {
  SystemAssigned: "SystemAssigned",
}

/** Identity for the resource. */
@removed(Versions.v6)
model Identity {
  /** The principal ID of resource identity. The value must be an UUID. */
  @removed(Versions.v6)
  @typeChangedFrom(Versions.v4, string)
  @visibility(Lifecycle.Read)
  principalId?: uuid;

  /** The tenant ID of resource. The value must be an UUID. */
  @removed(Versions.v6)
  @typeChangedFrom(Versions.v4, string)
  @visibility(Lifecycle.Read)
  tenantId?: uuid;

  /** The identity type. */
  type?: ResourceIdentityType;
}

model KeyVaultProperties {
  /** Key vault uri to access the encryption key. */
  keyIdentifier?: string;

  /** The client ID of the identity which will be used to access key vault. */
  identity?: string;
}
/**
 * Plan for the resource.
 */
model Plan {
  /** A user defined name of the 3rd Party Artifact that is being procured. */
  name: string;

  /** The publisher of the 3rd Party Artifact that is being bought. E.g. NewRelic */
  publisher: string;

  /** The 3rd Party artifact that is being procured. E.g. NewRelic. Product maps to the OfferID specified for the artifact at the time of Data Market onboarding. */
  product: string;

  /** A publisher provided promotion code as provisioned in Data Market for the said product/artifact. */
  promotionCode?: string;

  /** The version of the desired product/artifact. */
  version?: string;
}

/**
 * The check availability request body.
 */
model CheckNameAvailabilityRequest {
  /** The name of the resource for which availability needs to be checked. */
  name?: string;

  /** The resource type. */
  type?: string;
}

/**
 * The check availability result.
 */
model CheckNameAvailabilityResponse {
  /** Indicates if the resource name is available. */
  nameAvailable?: boolean;

  /** The reason why the given name is not available. */
  reason?: CheckNameAvailabilityReason;

  /** Detailed reason why the given name is not available. */
  message?: string;
}

/**
 * Possible reasons for a name not being available.
 */
union CheckNameAvailabilityReason {
  /** Name is invalid. */
  Invalid: "Invalid",

  /** Name already exists. */
  AlreadyExists: "AlreadyExists",

  string,
}

/** Indicates whether or not the encryption is enabled for container registry. */
union EncryptionStatus {
  /** Encryption is enabled. */
  enabled: "enabled",

  /** Encryption is disabled. */
  disabled: "disabled",

  string,
}
/**
 * Configuration of key for data encryption
 */
model EncryptionProperties {
  /** Indicates whether or not the encryption is enabled for container registry. */
  status?: EncryptionStatus;

  /** Key vault properties. */
  keyVaultProperties?: KeyVaultProperties;
}

/**
 * Metadata pertaining to the geographic location of the resource.
 */
model LocationData {
  /** A canonical name for the geographic or physical location. */
  @maxLength(256)
  name: string;

  /** The city or locality where the resource is located. */
  city?: string;

  /** The district, state, or province where the resource is located. */
  district?: string;

  /** The country or region where the resource is located */
  countryOrRegion?: string;
}

/**
 * The default api-version parameter type.
 */
model ApiVersionParameter {
  /** The API version to use for this operation. */
  @query("api-version")
  @minLength(1)
  apiVersion: string;
}

/**
 * The default operationId parameter type.
 */
model OperationIdParameter {
  /** The ID of an ongoing async operation. */
  @path
  @minLength(1)
  operationId: string;
}

/**
 * The default location parameter type.
 */
model LocationParameter {
  /** The name of Azure region. */
  @path
  @minLength(1)
  @segment("locations")
  location: string;
}

/**
 * The default resource group parameter type.
 */
model ResourceGroupNameParameter {
  /** The name of the resource group. The name is case insensitive. */
  @path
  @minLength(1)
  @maxLength(90)
  @segment("resourceGroups")
  @pattern("^[-\\\\w\\\\._\\\\(\\\\)]+$")
  resourceGroupName: string;
}

/**
 * The default subscriptionId parameter type.
 */
model SubscriptionIdParameter {
  /** The ID of the target subscription. The value must be an UUID. */
  @typeChangedFrom(Versions.v4, string)
  @path
  @segment("subscriptions")
  @minLength(1)
  subscriptionId: uuid;
}

/**
 * The default ManagementGroupName parameter type.
 */
@added(Versions.v4)
model ManagementGroupNameParameter {
  /** The name of the management group. The name is case insensitive. */
  @path
  @minLength(1)
  @maxLength(90)
  @segment("managementGroups")
  managementGroupName: string;
}

/**
 * The default Scope parameter type.
 */
@added(Versions.v4)
model ScopeParameter {
  /** The scope at which the operation is performed. */
  @path(#{ allowReserved: true })
  @segment("scope")
  @minLength(1)
  scope: string;
}

/**
 * The default TenantIdParameter type.
 */
@added(Versions.v4)
model TenantIdParameter {
  /** The Azure tenant ID. This is a GUID-formatted string (e.g. 00000000-0000-0000-0000-000000000000) */
  @path
  @segment("tenant")
  tenantId: uuid;
}

/**
 * The default ARM If-Match header type.
 */
@added(Versions.v4)
@friendlyName("If-Match")
model IfMatchHeader {
  /** The If-Match header that makes a request conditional. */
  @header("If-Match")
  ifMatch: string;
}

/**
 * The default ARM If-None-Match header type.
 */
@added(Versions.v4)
@friendlyName("If-None-Match")
model IfNoneMatchHeader {
  /** The If-None-Match header that makes a request conditional. */
  @header("If-None-Match")
  ifNoneMatch: string;
}
`,
  "lib/common-types/managed-identity-ref.tsp": `import "./managed-identity.tsp";

using Azure.ResourceManager.CommonTypes.Private;

namespace Azure.ResourceManager.CommonTypes;

/**
 * The properties of the managed service identities assigned to this resource.
 */
@@armCommonDefinition(ManagedServiceIdentity,
  "ManagedServiceIdentity",
  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },
  "managedidentity.json"
);
@@armCommonDefinition(ManagedServiceIdentity,
  "ManagedServiceIdentity",
  Azure.ResourceManager.CommonTypes.Versions.v4,
  "managedidentity.json"
);
@@armCommonDefinition(ManagedServiceIdentity,
  "ManagedServiceIdentity",
  Azure.ResourceManager.CommonTypes.Versions.v5,
  "managedidentity.json"
);
@@armCommonDefinition(ManagedServiceIdentity,
  "ManagedServiceIdentity",
  Azure.ResourceManager.CommonTypes.Versions.v6,
  "managedidentity.json"
);

/** The set of user assigned identities associated with the resource. The userAssignedIdentities dictionary keys will be ARM resource ids in the form: '/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/{identityName}. The dictionary values can be empty objects ({}) in requests.", */
@@armCommonDefinition(UserAssignedIdentities,
  "UserAssignedIdentities",
  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },
  "managedidentity.json"
);
@@armCommonDefinition(UserAssignedIdentities,
  "UserAssignedIdentities",
  Azure.ResourceManager.CommonTypes.Versions.v4,
  "managedidentity.json"
);
@@armCommonDefinition(UserAssignedIdentities,
  "UserAssignedIdentities",
  Azure.ResourceManager.CommonTypes.Versions.v5,
  "managedidentity.json"
);

/**
 * The properties of the service-assigned identity associated with this resource.
 */
@@armCommonDefinition(SystemAssignedServiceIdentity,
  "SystemAssignedServiceIdentity",
  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },
  "managedidentity.json"
);
@@armCommonDefinition(SystemAssignedServiceIdentity,
  "SystemAssignedServiceIdentity",
  Azure.ResourceManager.CommonTypes.Versions.v4,
  "managedidentity.json"
);
@@armCommonDefinition(SystemAssignedServiceIdentity,
  "SystemAssignedServiceIdentity",
  Azure.ResourceManager.CommonTypes.Versions.v5,
  "managedidentity.json"
);
@@armCommonDefinition(SystemAssignedServiceIdentity,
  "SystemAssignedServiceIdentity",
  Azure.ResourceManager.CommonTypes.Versions.v6,
  "managedidentity.json"
);

/**
 * A managed identity assigned by the user.
 */
@@armCommonDefinition(UserAssignedIdentity,
  "UserAssignedIdentity",
  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },
  "managedidentity.json"
);
@@armCommonDefinition(UserAssignedIdentity,
  "UserAssignedIdentity",
  Azure.ResourceManager.CommonTypes.Versions.v4,
  "managedidentity.json"
);
@@armCommonDefinition(UserAssignedIdentity,
  "UserAssignedIdentity",
  Azure.ResourceManager.CommonTypes.Versions.v5,
  "managedidentity.json"
);
@@armCommonDefinition(UserAssignedIdentity,
  "UserAssignedIdentity",
  Azure.ResourceManager.CommonTypes.Versions.v6,
  "managedidentity.json"
);

@@armCommonDefinition(ManagedServiceIdentityType,
  "ManagedServiceIdentityType",
  Azure.ResourceManager.CommonTypes.Versions.v3,
  "managedidentity.json"
);
@@armCommonDefinition(ManagedServiceIdentityType,
  "ManagedServiceIdentityType",
  Azure.ResourceManager.CommonTypes.Versions.v4,
  "managedidentity.json"
);
@@armCommonDefinition(ManagedServiceIdentityType,
  "ManagedServiceIdentityType",
  Azure.ResourceManager.CommonTypes.Versions.v5,
  "managedidentity.json"
);
@@armCommonDefinition(ManagedServiceIdentityType,
  "ManagedServiceIdentityType",
  Azure.ResourceManager.CommonTypes.Versions.v6,
  "managedidentity.json"
);

@@armCommonDefinition(SystemAssignedServiceIdentityType,
  "SystemAssignedServiceIdentityType",
  Azure.ResourceManager.CommonTypes.Versions.v3,
  "managedidentity.json"
);
@@armCommonDefinition(SystemAssignedServiceIdentityType,
  "SystemAssignedServiceIdentityType",
  Azure.ResourceManager.CommonTypes.Versions.v4,
  "managedidentity.json"
);
@@armCommonDefinition(SystemAssignedServiceIdentityType,
  "SystemAssignedServiceIdentityType",
  Azure.ResourceManager.CommonTypes.Versions.v5,
  "managedidentity.json"
);
@@armCommonDefinition(SystemAssignedServiceIdentityType,
  "SystemAssignedServiceIdentityType",
  Azure.ResourceManager.CommonTypes.Versions.v6,
  "managedidentity.json"
);
`,
  "lib/common-types/managed-identity.tsp": `using Azure.Core;
using Versioning;

namespace Azure.ResourceManager.CommonTypes;

/** The set of user assigned identities associated with the resource. The userAssignedIdentities dictionary keys will be ARM resource ids in the form: '/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/{identityName}. The dictionary values can be empty objects ({}) in requests. */
#deprecated "Do not use this model. Instead, use Record<UserAssignedIdentity | null> directly. Using this model will result in a different client SDK when generated from TypeSpec compared to the Swagger."
@summary("User-Assigned Identities")
@removed(Versions.v6)
model UserAssignedIdentities is Record<UserAssignedIdentity | null>;

/**
 * Managed service identity (system assigned and/or user assigned identities)
 */
model ManagedServiceIdentity {
  /** The service principal ID of the system assigned identity. This property will only be provided for a system assigned identity. */
  @visibility(Lifecycle.Read)
  principalId?: uuid;

  /** The tenant ID of the system assigned identity. This property will only be provided for a system assigned identity. */
  @visibility(Lifecycle.Read)
  tenantId?: uuid;

  /** The type of managed identity assigned to this resource. */
  type: ManagedServiceIdentityType;

  /** The identities assigned to this resource by the user. */
  @typeChangedFrom(Versions.v5, Record<UserAssignedIdentity>)
  userAssignedIdentities?: Record<UserAssignedIdentity | null>;
}

/**
 * Managed service identity (either system assigned, or none)
 */
model SystemAssignedServiceIdentity {
  /** The service principal ID of the system assigned identity. This property will only be provided for a system assigned identity. */
  @visibility(Lifecycle.Read)
  principalId?: uuid;

  /** The tenant ID of the system assigned identity. This property will only be provided for a system assigned identity. */
  @visibility(Lifecycle.Read)
  tenantId?: uuid;

  /** The type of managed identity assigned to this resource. */
  type: SystemAssignedServiceIdentityType;
}

/**
 * User assigned identity properties
 */
model UserAssignedIdentity {
  /** The principal ID of the assigned identity. */
  @visibility(Lifecycle.Read)
  principalId?: uuid;

  /** The client ID of the assigned identity. */
  @visibility(Lifecycle.Read)
  clientId?: uuid;
}

/**
 * Type of managed service identity (where both SystemAssigned and UserAssigned types are allowed).
 */
union ManagedServiceIdentityType {
  /** No managed identity. */
  "None",

  /** System assigned managed identity. */
  "SystemAssigned",

  /** User assigned managed identity. */
  "UserAssigned",

  /** System and user assigned managed identity. */
  @added(Versions.v3)
  @removed(Versions.v4)
  @added(Versions.v5)
  "SystemAssigned,UserAssigned",

  /** System and user assigned managed identity. */
  @added(Versions.v4)
  @removed(Versions.v5)
  "SystemAssigned, UserAssigned",

  string,
}

/**
 * Type of managed service identity (either system assigned, or none).
 */
union SystemAssignedServiceIdentityType {
  /** No managed system identity. */
  None: "None",

  /** System assigned managed system identity. */
  SystemAssigned: "SystemAssigned",

  string,
}
`,
  "lib/common-types/managed-identity-with-delegation-ref.tsp": 'import "./managed-identity-with-delegation.tsp";\nusing Azure.ResourceManager.CommonTypes.Private;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n/** Managed service identity (system assigned and/or user assigned identities and/or delegated identities) - internal use only. */\n@@armCommonDefinition(ManagedServiceIdentityWithDelegation,\n  "ManagedServiceIdentityWithDelegation",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "managedidentitywithdelegation.json"\n);\n@@armCommonDefinition(ManagedServiceIdentityWithDelegation,\n  "ManagedServiceIdentityWithDelegation",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "managedidentitywithdelegation.json"\n);\n@@armCommonDefinition(ManagedServiceIdentityWithDelegation,\n  "ManagedServiceIdentityWithDelegation",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "managedidentitywithdelegation.json"\n);\n\n/** Delegated resource properties - internal use only. */\n@@armCommonDefinition(DelegatedResource,\n  "DelegatedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "managedidentitywithdelegation.json"\n);\n@@armCommonDefinition(DelegatedResource,\n  "DelegatedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "managedidentitywithdelegation.json"\n);\n@@armCommonDefinition(DelegatedResource,\n  "DelegatedResource",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "managedidentitywithdelegation.json"\n);\n',
  "lib/common-types/managed-identity-with-delegation.tsp": "using Azure.Core;\nusing Versioning;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n/** Managed service identity (system assigned and/or user assigned identities and/or delegated identities) - internal use only. */\n@added(Versions.v4)\nmodel ManagedServiceIdentityWithDelegation extends ManagedServiceIdentity {\n  delegatedResources?: DelegatedResources;\n}\n\n/** The set of delegated resources. The delegated resources dictionary keys will be source resource internal ids - internal use only. */\n@added(Versions.v4)\nmodel DelegatedResources {\n  ...Record<DelegatedResource>;\n}\n\n/** Delegated resource properties - internal use only. */\n@added(Versions.v4)\nmodel DelegatedResource {\n  /** The ARM resource id of the delegated resource - internal use only. */\n  resourceId?: string;\n\n  /** The tenant id of the delegated resource - internal use only. */\n  tenantId?: uuid;\n\n  /** The delegation id of the referral delegation (optional) - internal use only. */\n  referralResource?: string;\n\n  /** The source resource location - internal use only. */\n  location?: string;\n}\n",
  "lib/common-types/private-links-ref.tsp": 'import "./private-links.tsp";\n\nusing Azure.ResourceManager.CommonTypes.Private;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n@@Azure.ResourceManager.Private.conditionalClientFlatten(PrivateLinkResource.properties);\n@@Azure.ResourceManager.Private.conditionalClientFlatten(PrivateEndpointConnection.properties);\n\n/** The private endpoint */\n@@armCommonDefinition(PrivateEndpoint,\n  "PrivateEndpoint",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpoint,\n  "PrivateEndpoint",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpoint,\n  "PrivateEndpoint",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpoint,\n  "PrivateEndpoint",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "privatelinks.json"\n);\n\n/** The private endpoint resource */\n@@armCommonDefinition(PrivateLinkResource,\n  "PrivateLinkResource",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkResource,\n  "PrivateLinkResource",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkResource,\n  "PrivateLinkResource",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkResource,\n  "PrivateLinkResource",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "privatelinks.json"\n);\n\n/** PrivateEndpointConnection */\n@@armCommonDefinition(PrivateEndpointConnection,\n  "PrivateEndpointConnection",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnection,\n  "PrivateEndpointConnection",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnection,\n  "PrivateEndpointConnection",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnection,\n  "PrivateEndpointConnection",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "privatelinks.json"\n);\n\n/** Properties of he private endpoint connection resource */\n@@armCommonDefinition(PrivateEndpointConnectionProperties,\n  "PrivateEndpointConnectionProperties",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnectionProperties,\n  "PrivateEndpointConnectionProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnectionProperties,\n  "PrivateEndpointConnectionProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnectionProperties,\n  "PrivateEndpointConnectionProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "privatelinks.json"\n);\n\n/** A collection of information about the state of the connection between service consumer and provider. */\n@@armCommonDefinition(PrivateLinkServiceConnectionState,\n  "PrivateLinkServiceConnectionState",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkServiceConnectionState,\n  "PrivateLinkServiceConnectionState",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkServiceConnectionState,\n  "PrivateLinkServiceConnectionState",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkServiceConnectionState,\n  "PrivateLinkServiceConnectionState",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "privatelinks.json"\n);\n\n/** Properties of a private link resource. */\n#suppress "@azure-tools/typespec-azure-resource-manager/arm-resource-provisioning-state" "Matches current common code"\n@@armCommonDefinition(PrivateLinkResourceProperties,\n  "PrivateLinkResourceProperties",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkResourceProperties,\n  "PrivateLinkResourceProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkResourceProperties,\n  "PrivateLinkResourceProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkResourceProperties,\n  "PrivateLinkResourceProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "privatelinks.json"\n);\n\n/** PrivateEndpointConnectionListResult */\n@@armCommonDefinition(PrivateEndpointConnectionListResultV5,\n  "PrivateEndpointConnectionListResult",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnectionListResultV5,\n  "PrivateEndpointConnectionListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnectionListResultV5,\n  "PrivateEndpointConnectionListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnectionListResult,\n  "PrivateEndpointConnectionListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "privatelinks.json"\n);\n\n/** PrivateLinkResourceListResult */\n@@armCommonDefinition(PrivateEndpointConnectionListResultV5,\n  "PrivateLinkResourceListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v3,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnectionListResultV5,\n  "PrivateLinkResourceListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnectionListResultV5,\n  "PrivateLinkResourceListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateLinkResourceListResult,\n  "PrivateLinkResourceListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "privatelinks.json"\n);\n\n// PrivateEndpointServiceConnectionStatus\n@@armCommonDefinition(PrivateEndpointServiceConnectionStatus,\n  "PrivateEndpointServiceConnectionStatus",\n  Azure.ResourceManager.CommonTypes.Versions.v3,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointServiceConnectionStatus,\n  "PrivateEndpointServiceConnectionStatus",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(PrivateEndpointServiceConnectionStatus,\n  "PrivateEndpointServiceConnectionStatus",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(PrivateEndpointServiceConnectionStatus,\n  "PrivateEndpointServiceConnectionStatus",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n// PrivateEndpointServiceConnectionStatus\n@@armCommonDefinition(PrivateEndpointConnectionProvisioningState,\n  "PrivateEndpointConnectionProvisioningState",\n  Azure.ResourceManager.CommonTypes.Versions.v3,\n  "privatelinks.json"\n);\n@@armCommonDefinition(PrivateEndpointConnectionProvisioningState,\n  "PrivateEndpointConnectionProvisioningState",\n  Azure.ResourceManager.CommonTypes.Versions.v4\n);\n@@armCommonDefinition(PrivateEndpointConnectionProvisioningState,\n  "PrivateEndpointConnectionProvisioningState",\n  Azure.ResourceManager.CommonTypes.Versions.v5\n);\n@@armCommonDefinition(PrivateEndpointConnectionProvisioningState,\n  "PrivateEndpointConnectionProvisioningState",\n  Azure.ResourceManager.CommonTypes.Versions.v6\n);\n\n/** PrivateEndpointConnectionParameter */\n@@CommonTypes.Private.armCommonParameter(PrivateEndpointConnectionParameter.name,\n  "PrivateEndpointConnectionName",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v3, isDefault: true },\n  "privatelinks.json"\n);\n@@CommonTypes.Private.armCommonParameter(PrivateEndpointConnectionParameter.name,\n  "PrivateEndpointConnectionName",\n  Azure.ResourceManager.CommonTypes.Versions.v4,\n  "privatelinks.json"\n);\n@@CommonTypes.Private.armCommonParameter(PrivateEndpointConnectionParameter.name,\n  "PrivateEndpointConnectionName",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "privatelinks.json"\n);\n@@CommonTypes.Private.armCommonParameter(PrivateEndpointConnectionParameter.name,\n  "PrivateEndpointConnectionName",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "privatelinks.json"\n);\n',
  "lib/common-types/private-links.tsp": 'using Http;\nusing Versioning;\nusing OpenAPI;\n\nusing Azure.Core;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n/** The private endpoint resource. */\nmodel PrivateEndpoint {\n  /** The resource identifier of the private endpoint */\n  @visibility(Lifecycle.Read)\n  @typeChangedFrom(CommonTypes.Versions.v4, string)\n  id?: Azure.Core.armResourceIdentifier;\n}\n\n/** A private link resource. */\nmodel PrivateLinkResource extends Resource {\n  /** Resource properties. */\n  properties?: PrivateLinkResourceProperties;\n}\n\n/** Properties of a private link resource. */\nmodel PrivateLinkResourceProperties {\n  /** The private link resource group id. */\n  @visibility(Lifecycle.Read)\n  groupId?: string;\n\n  /** The private link resource required member names. */\n  @visibility(Lifecycle.Read)\n  requiredMembers?: string[];\n\n  /** The private link resource private link DNS zone name. */\n  requiredZoneNames?: string[];\n}\n\n/** A list of private link resources. */\n@added(Versions.v6)\n@pagedResult\nmodel PrivateLinkResourceListResult {\n  /** Array of private link resources */\n  @OpenAPI.extension("x-ms-identifiers", #["id"])\n  value?: PrivateLinkResource[];\n\n  /** URL to get the next set of operation list results (if there are any). */\n  @visibility(Lifecycle.Read)\n  nextLink?: url;\n}\n//#region\n/** The private endpoint connection resource */\nmodel PrivateEndpointConnection extends Resource {\n  /** The private endpoint connection properties */\n  properties?: PrivateEndpointConnectionProperties;\n}\n\n/** List of private endpoint connections associated with the specified resource. */\n@added(Versions.v6)\n@pagedResult\nmodel PrivateEndpointConnectionListResult {\n  /** Array of private endpoint connections. */\n  @OpenAPI.extension("x-ms-identifiers", #["id"])\n  value?: PrivateEndpointConnection[];\n\n  /** URL to get the next set of operation list results (if there are any). */\n  @visibility(Lifecycle.Read)\n  nextLink?: url;\n}\n\n/** Properties of the private endpoint connection. */\nmodel PrivateEndpointConnectionProperties {\n  /** The group ids for the private endpoint resource. */\n  @visibility(Lifecycle.Read)\n  @added(Versions.v4)\n  groupIds?: string[];\n\n  /** The private endpoint resource. */\n  privateEndpoint?: PrivateEndpoint;\n\n  /** A collection of information about the state of the connection between service consumer and provider. */\n  privateLinkServiceConnectionState: PrivateLinkServiceConnectionState;\n\n  /** The provisioning state of the private endpoint connection resource. */\n  @visibility(Lifecycle.Read)\n  provisioningState?: PrivateEndpointConnectionProvisioningState;\n}\n\n/** A collection of information about the state of the connection between service consumer and provider. */\nmodel PrivateLinkServiceConnectionState {\n  /** Indicates whether the connection has been Approved/Rejected/Removed by the owner of the service. */\n  status?: PrivateEndpointServiceConnectionStatus;\n\n  /** The reason for approval/rejection of the connection. */\n  description?: string;\n\n  /** A message indicating if changes on the service provider require any updates on the consumer. */\n  actionsRequired?: string;\n}\n\n/** The current provisioning state. */\nunion PrivateEndpointConnectionProvisioningState {\n  string,\n\n  /** Connection has been provisioned */\n  Succeeded: "Succeeded",\n\n  /** Connection is being created */\n  Creating: "Creating",\n\n  /** Connection is being deleted */\n  Deleting: "Deleting",\n\n  /** Connection provisioning has failed */\n  Failed: "Failed",\n}\n\n/** The private endpoint connection status. */\nunion PrivateEndpointServiceConnectionStatus {\n  /** Connection waiting for approval or rejection */\n  Pending: "Pending",\n\n  /** Connection approved */\n  Approved: "Approved",\n\n  /** Connection Rejected */\n  Rejected: "Rejected",\n\n  string,\n}\n\n/**\n * The name of the private endpoint connection associated with the Azure resource.\n */\nmodel PrivateEndpointConnectionParameter {\n  /** The name of the private endpoint connection associated with the Azure resource. */\n  @path\n  @key("privateEndpointConnectionName")\n  @TypeSpec.Rest.segment("privateEndpointConnections")\n  name: string;\n}\n\n/**\n * The name of the private link associated with the Azure resource.\n * @template Segment The resource type name for private links (default is privateLinkResources)\n */\nmodel PrivateLinkResourceParameter<Segment extends valueof string = "privateLinkResources"> {\n  /** The name of the private link associated with the Azure resource. */\n  @path\n  @TypeSpec.Rest.segment(Segment)\n  @key("privateLinkResourceName")\n  name: string;\n}\n\n/**\n * A list of private link resources for versions before v6.\n *\n * This model represents the standard `PrivateLinkResourceListResult` envelope for versions v3, v4, and v5. It has been deprecated for v6 and beyond.\n *\n * Note: This is only intended for use with versions before v6. Do not use this if you are already on CommonTypes.Version.v6 or beyond.\n *\n * If you are migrating to v6 or above, use `PrivateLinkResourceListResult` directly.\n *\n *  @example\n *  Version: v3,v4,v5\n * ```typespec\n * @armResourceOperations\n * interface Employees {\n *   listConnections is ArmResourceActionAsync<Employee, {}, PrivateLinkResourceListResultV5>;\n * }\n * ```\n *\n * Version: v6\n * ```typespec\n * @armResourceOperations\n * interface Employees {\n *   listConnections is ArmResourceActionAsync<Employee, {}, PrivateLinkResourceListResult>;\n * }\n * ```\n */\n#deprecated "Avoid using this model. Instead, use PrivateLinkResourceListResult available in CommonTypes.Version.v6 or beyond."\n@friendlyName("PrivateLinkResourceListResult")\n@removed(Versions.v6)\nmodel PrivateLinkResourceListResultV5 {\n  /** Array of private link resources */\n  @OpenAPI.extension("x-ms-identifiers", #["id"])\n  value?: CommonTypes.PrivateLinkResource[];\n}\n\n/**\n * List of private endpoint connections associated with the specified resource before version v6.\n *\n * This model represents the standard `PrivateEndpointConnectionResourceListResult` envelope for versions v3, v4, and v5. It has been deprecated for v6 and beyond.\n *\n * Note: This is only intended for use with versions before v6. Do not use this if you are already on CommonTypes.Version.v6 or beyond.\n *\n * If you are migrating to v6 or above, use `PrivateEndpointConnectionResourceListResult` directly.\n *\n * @example\n * Version: v3,v4,v5\n * ```typespec\n * @armResourceOperations\n * interface Employees {\n *   createConnection is ArmResourceActionAsync<\n *     Employee,\n *     PrivateEndpointConnection,\n *     PrivateEndpointConnectionResourceListResultV5\n *   >;\n * }\n * ```\n *\n * Version: v6\n * ```typespec\n * @armResourceOperations\n * interface Employees {\n *   createConnection is ArmResourceActionAsync<\n *     Employee,\n *     PrivateEndpointConnection,\n *     PrivateEndpointConnectionResourceListResult\n *   >;\n * }\n * ```\n */\n#deprecated "Avoid using this model. Instead, use PrivateEndpointConnectionResourceListResult available in CommonTypes.Version.v6 or beyond."\n@friendlyName("PrivateEndpointConnectionListResult")\n@removed(Versions.v6)\nmodel PrivateEndpointConnectionListResultV5 {\n  /** Array of private endpoint connections. */\n  @OpenAPI.extension("x-ms-identifiers", #["id"])\n  value?: CommonTypes.PrivateEndpointConnection[];\n}\n',
  "lib/common-types/customer-managed-keys-ref.tsp": 'import "./customer-managed-keys.tsp";\n\nusing Azure.ResourceManager.CommonTypes.Private;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n@@armCommonDefinition(Encryption,\n  "encryption",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v4, isDefault: true },\n  "customermanagedkeys.json"\n);\n@@armCommonDefinition(Encryption,\n  "encryption",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "customermanagedkeys.json"\n);\n@@armCommonDefinition(Encryption,\n  "encryption",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "customermanagedkeys.json"\n);\n\n@@armCommonDefinition(CustomerManagedKeyEncryption,\n  "customerManagedKeyEncryption",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v4, isDefault: true },\n  "customermanagedkeys.json"\n);\n@@armCommonDefinition(CustomerManagedKeyEncryption,\n  "customerManagedKeyEncryption",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "customermanagedkeys.json"\n);\n@@armCommonDefinition(CustomerManagedKeyEncryption,\n  "customerManagedKeyEncryption",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "customermanagedkeys.json"\n);\n',
  "lib/common-types/customer-managed-keys.tsp": 'using Azure.Core;\nusing Versioning;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n/** (Optional) Discouraged to include in resource definition. Only needed where it is possible to disable platform (AKA infrastructure) encryption. Azure SQL TDE is an example of this. Values are enabled and disabled. */\n@added(Versions.v4)\nunion InfrastructureEncryption {\n  /** Encryption is enabled */\n  Enabled: "enabled",\n\n  /** Encryption is disabled */\n  Disabled: "disabled",\n\n  string,\n}\n\n/** The type of identity to use. */\n@added(Versions.v4)\nunion KeyEncryptionKeyIdentityType {\n  /** System assigned identity */\n  SystemAssignedIdentity: "systemAssignedIdentity",\n\n  /** User assigned identity */\n  UserAssignedIdentity: "userAssignedIdentity",\n\n  /** Delegated identity */\n  DelegatedResourceIdentity: "delegatedResourceIdentity",\n\n  string,\n}\n\n/** All identity configuration for Customer-managed key settings defining which identity should be used to auth to Key Vault. */\n@added(Versions.v4)\nmodel KeyEncryptionKeyIdentity {\n  /** The type of identity to use. Values can be systemAssignedIdentity, userAssignedIdentity, or delegatedResourceIdentity. */\n  identityType?: KeyEncryptionKeyIdentityType;\n\n  /** User assigned identity to use for accessing key encryption key Url. Ex: /subscriptions/fa5fc227-a624-475e-b696-cdd604c735bc/resourceGroups/<resource group>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/myId. Mutually exclusive with identityType systemAssignedIdentity. */\n  userAssignedIdentityResourceId?: Azure.Core.armResourceIdentifier;\n\n  /** application client identity to use for accessing key encryption key Url in a different tenant. Ex: f83c6b1b-4d34-47e4-bb34-9d83df58b540 */\n  @added(Versions.v5)\n  federatedClientId?: uuid;\n\n  /** delegated identity to use for accessing key encryption key Url. Ex: /subscriptions/fa5fc227-a624-475e-b696-cdd604c735bc/resourceGroups/<resource group>/providers/Microsoft.ManagedIdentity/userAssignedIdentities/myId. Mutually exclusive with identityType systemAssignedIdentity and userAssignedIdentity - internal use only. */\n  delegatedIdentityClientId?: uuid;\n}\n\n/** Customer-managed key encryption properties for the resource. */\n@added(Versions.v4)\nmodel CustomerManagedKeyEncryption {\n  /** All identity configuration for Customer-managed key settings defining which identity should be used to auth to Key Vault. */\n  keyEncryptionKeyIdentity?: KeyEncryptionKeyIdentity;\n\n  /** key encryption key Url, versioned or non-versioned. Ex: https://contosovault.vault.azure.net/keys/contosokek/562a4bb76b524a1493a6afe8e536ee78 or https://contosovault.vault.azure.net/keys/contosokek. */\n  keyEncryptionKeyUrl?: string;\n}\n\n/** (Optional) Discouraged to include in resource definition. Only needed where it is possible to disable platform (AKA infrastructure) encryption. Azure SQL TDE is an example of this. Values are enabled and disabled. */\n@added(Versions.v4)\n@encodedName("application/json", "encryption")\nmodel Encryption {\n  /** Values are enabled and disabled. */\n  infrastructureEncryption?: InfrastructureEncryption;\n\n  /** All Customer-managed key encryption properties for the resource. */\n  @added(Versions.v4)\n  customerManagedKeyEncryption?: CustomerManagedKeyEncryption;\n}\n',
  "lib/common-types/extended-location-ref.tsp": 'import "./extended-location.tsp";\n',
  "lib/common-types/extended-location.tsp": 'namespace Azure.ResourceManager.CommonTypes;\n/** The complex type of the extended location. */\nmodel ExtendedLocation {\n  /** The name of the extended location. */\n  name: string;\n\n  /** The type of the extended location. */\n  type: ExtendedLocationType;\n}\n\n/** The supported ExtendedLocation types. */\nunion ExtendedLocationType {\n  /** Azure Edge Zones location type */\n  EdgeZone: "EdgeZone",\n\n  /** Azure Custom Locations type */\n  CustomLocation: "CustomLocation",\n\n  string,\n}\n',
  "lib/common-types/internal.tsp": 'namespace Azure.ResourceManager.CommonTypes;\n\n/**\n * An internal enum to indicate the resource support for various path types\n */\nenum ResourceHome {\n  @doc("The resource is bound to a tenant")\n  Tenant,\n\n  @doc("The resource is bound to a subscription")\n  Subscription,\n\n  @doc("The resource is bound to a location")\n  Location,\n\n  @doc("The resource is bound to a resource group")\n  ResourceGroup,\n\n  @doc("The resource is bound to an extension")\n  Extension,\n}\n\n/** Alias of keyEncryptionKeyIdentity for back compatibility. Please change to keyEncryptionKeyIdentity. */\nalias KeyEncryptionIdentity = KeyEncryptionKeyIdentity;\n',
  "lib/common-types/commontypes.private.decorators.tsp": 'import "../../dist/src/commontypes.private.decorators.js";\n\nnamespace Azure.ResourceManager.CommonTypes.Private;\n\nusing Reflection;\n\n/**\n * Describes the shape of model literals accepted by the `version` parameter of\n * the `armCommonDefinition` and `armCommonParameter` decorators.\n */\nalias ArmCommonTypeVersionSpec = {\n  version: string | EnumMember;\n  isDefault: boolean;\n};\n\n/**\n * @param definitionName Definition name\n * @param version Azure Resource Manager Version\n * @param referenceFile Reference file\n */\nextern dec armCommonDefinition(\n  target: Model | Enum | Union,\n  definitionName?: valueof string,\n  version?: valueof EnumMember | ArmCommonTypeVersionSpec | string,\n  referenceFile?: valueof string\n);\n\n/**\n * @param definitionName Definition name\n * @param version Azure Resource Manager Version\n * @param referenceFile Reference file\n */\nextern dec armCommonParameter(\n  target: ModelProperty,\n  definitionName?: valueof string,\n  version?: valueof EnumMember | ArmCommonTypeVersionSpec | string,\n  referenceFile?: valueof string\n);\n\n/**\n * Marks an enum as representing the valid `common-types` versions.\n */\nextern dec armCommonTypesVersions(target: Enum);\n',
  "lib/common-types/versions.tsp": 'import "./commontypes.private.decorators.tsp";\n\nusing Versioning;\n\n@versioned(Versions)\nnamespace Azure.ResourceManager.CommonTypes;\n\n@Azure.ResourceManager.CommonTypes.Private.armCommonTypesVersions\n@doc("The Azure Resource Manager common-types versions.")\nenum Versions {\n  @doc("The Azure Resource Manager v3 common types.")\n  v3,\n\n  @doc("The Azure Resource Manager v4 common types.")\n  v4,\n\n  @doc("The Azure Resource Manager v5 common types.")\n  v5,\n\n  @doc("The Azure Resource Manager v6 common types.")\n  v6,\n}\n',
  "lib/common-types/mobo-ref.tsp": 'import "./mobo.tsp";\nusing Azure.ResourceManager.CommonTypes.Private;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n/** This configuration exists for the resources where a resource provider manages those resources on behalf of the resource owner. */\n@@armCommonDefinition(ManagedOnBehalfOfConfiguration,\n  "ManagedOnBehalfOfConfiguration",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "mobo.json"\n);\n@@armCommonDefinition(ManagedOnBehalfOfConfiguration,\n  "ManagedOnBehalfOfConfiguration",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "mobo.json"\n);\n\n/** This resource is created by the Resource Provider to manage some resources on behalf of the user. */\n@@armCommonDefinition(MoboBrokerResource,\n  "MoboBrokerResource",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "mobo.json"\n);\n@@armCommonDefinition(MoboBrokerResource,\n  "MoboBrokerResource",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "mobo.json"\n);\n',
  "lib/common-types/mobo.tsp": "using Azure.Core;\nusing Versioning;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n/** Managed-On-Behalf-Of configuration properties. This configuration exists for the resources where a resource provider manages those resources on behalf of the resource owner. */\n@added(Versions.v5)\nmodel ManagedOnBehalfOfConfiguration {\n  /** Managed-On-Behalf-Of broker resources */\n  @visibility(Lifecycle.Read)\n  moboBrokerResources?: MoboBrokerResource[];\n}\n\n/** Managed-On-Behalf-Of broker resource. This resource is created by the Resource Provider to manage some resources on behalf of the user. */\n@added(Versions.v5)\nmodel MoboBrokerResource {\n  /** Resource identifier of a Managed-On-Behalf-Of broker resource */\n  id?: Azure.Core.armResourceIdentifier;\n}\n",
  "lib/common-types/network-security-perimeter-ref.tsp": 'import "./network-security-perimeter.tsp";\n\nusing Azure.ResourceManager.CommonTypes.Private;\n\nnamespace Azure.ResourceManager.CommonTypes;\n\n/** Direction of Access Rule */\n@@armCommonDefinition(AccessRuleDirection,\n  "AccessRuleDirection",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(AccessRuleDirection,\n  "AccessRuleDirection",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Provisioning state of a network security perimeter configuration that is being created or updated. */\n@@armCommonDefinition(NetworkSecurityPerimeterConfigurationProvisioningState,\n  "NetworkSecurityPerimeterConfigurationProvisioningState",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(NetworkSecurityPerimeterConfigurationProvisioningState,\n  "NetworkSecurityPerimeterConfigurationProvisioningState",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Type of issue */\n@@armCommonDefinition(IssueType,\n  "IssueType",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(IssueType,\n  "IssueType",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Severity of the issue. */\n@@armCommonDefinition(Severity,\n  "Severity",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(Severity,\n  "Severity",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Access mode of the resource association */\n@@armCommonDefinition(ResourceAssociationAccessMode,\n  "ResourceAssociationAccessMode",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(ResourceAssociationAccessMode,\n  "ResourceAssociationAccessMode",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Allow, disallow, or let network security perimeter configuration control public network access to the protected resource. */\n@@armCommonDefinition(PublicNetworkAccess,\n  "PublicNetworkAccess",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(PublicNetworkAccess,\n  "PublicNetworkAccess",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Access rule in a network security perimeter configuration profile */\n@@armCommonDefinition(AccessRule,\n  "AccessRule",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(AccessRule,\n  "AccessRule",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Properties of Access Rule */\n@@armCommonDefinition(AccessRuleDirection,\n  "AccessRuleDirection",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(AccessRuleDirection,\n  "AccessRuleDirection",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Information about a network security perimeter */\n@@armCommonDefinition(NetworkSecurityPerimeter,\n  "NetworkSecurityPerimeter",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(NetworkSecurityPerimeter,\n  "NetworkSecurityPerimeter",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Network security perimeter configuration resource */\n@@armCommonDefinition(NetworkSecurityPerimeterConfiguration,\n  "NetworkSecurityPerimeterConfiguration",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(NetworkSecurityPerimeterConfiguration,\n  "NetworkSecurityPerimeterConfiguration",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Network security configuration properties. */\n@@armCommonDefinition(NetworkSecurityPerimeterConfigurationProperties,\n  "NetworkSecurityPerimeterConfigurationProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(NetworkSecurityPerimeterConfigurationProperties,\n  "NetworkSecurityPerimeterConfigurationProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Describes a provisioning issue for a network security perimeter configuration */\n@@armCommonDefinition(ProvisioningIssue,\n  "ProvisioningIssue",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(ProvisioningIssue,\n  "ProvisioningIssue",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Details of a provisioning issue for a network security perimeter configuration. */\n@@armCommonDefinition(ProvisioningIssueProperties,\n  "ProvisioningIssueProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(ProvisioningIssueProperties,\n  "ProvisioningIssueProperties",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Information about resource association */\n@@armCommonDefinition(ResourceAssociation,\n  "ResourceAssociation",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(ResourceAssociation,\n  "ResourceAssociation",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Network security perimeter configuration profile */\n@@armCommonDefinition(NetworkSecurityProfile,\n  "NetworkSecurityProfile",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(NetworkSecurityProfile,\n  "NetworkSecurityProfile",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n\n/** Result of a list NSP (network security perimeter) configurations request. */\n@@armCommonDefinition(NetworkSecurityPerimeterConfigurationListResult,\n  "NetworkSecurityPerimeterConfigurationListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v5,\n  "networksecurityperimeter.json"\n);\n@@armCommonDefinition(NetworkSecurityPerimeterConfigurationListResult,\n  "NetworkSecurityPerimeterConfigurationListResult",\n  Azure.ResourceManager.CommonTypes.Versions.v6,\n  "networksecurityperimeter.json"\n);\n',
  "lib/common-types/network-security-perimeter.tsp": `using Http;
using Versioning;
using Azure.Core;

@server(
  "https://management.azure.com",
  "The endpoint for network security perimeter common type definitions"
)
namespace Azure.ResourceManager.CommonTypes;

/** Direction of Access Rule */
@added(Versions.v5)
union AccessRuleDirection {
  string,

  /** Applies to inbound network traffic to the secured resources. */
  Inbound: "Inbound",

  /** Applies to outbound network traffic from the secured resources */
  Outbound: "Outbound",
}

/** Provisioning state of a network security perimeter configuration that is being created or updated. */
@added(Versions.v5)
union NetworkSecurityPerimeterConfigurationProvisioningState {
  string,
  Succeeded: "Succeeded",
  Creating: "Creating",
  Updating: "Updating",
  Deleting: "Deleting",
  Accepted: "Accepted",
  Failed: "Failed",
  Canceled: "Canceled",
}

/** Type of issue */
@added(Versions.v5)
union IssueType {
  string,

  /** Unknown issue type */
  Unknown: "Unknown",

  /** An error occurred while applying the network security perimeter (NSP) configuration. */
  ConfigurationPropagationFailure: "ConfigurationPropagationFailure",

  /** A network connectivity issue is happening on the resource which could be addressed either by adding new resources to the network security perimeter (NSP) or by modifying access rules. */
  MissingPerimeterConfiguration: "MissingPerimeterConfiguration",

  /** An managed identity hasn't been associated with the resource. The resource will still be able to validate inbound traffic from the network security perimeter (NSP) or matching inbound access rules, but it won't be able to perform outbound access as a member of the NSP. */
  MissingIdentityConfiguration: "MissingIdentityConfiguration",
}

/** Severity of the issue. */
@added(Versions.v5)
union Severity {
  string,
  Warning: "Warning",
  Error: "Error",
}

/** Access mode of the resource association */
@added(Versions.v5)
union ResourceAssociationAccessMode {
  string,

  /** Enforced access mode - traffic to the resource that failed access checks is blocked */
  Enforced: "Enforced",

  /** Learning access mode - traffic to the resource is enabled for analysis but not blocked */
  Learning: "Learning",

  /** Audit access mode - traffic to the resource that fails access checks is logged but not blocked */
  Audit: "Audit",
}

/** Allow, disallow, or let network security perimeter configuration control public network access to the protected resource. Value is optional but if passed in, it must be 'Enabled', 'Disabled' or 'SecuredByPerimeter'. */
@added(Versions.v5)
union PublicNetworkAccess {
  string,

  /** Allows public network access to the resource */
  Enabled: "Enabled",

  /** Disallows public network access to the resource */
  Disabled: "Disabled",

  /** The network security perimeter configuration rules allow or disallow public network access to the resource. Requires an associated network security perimeter. */
  SecuredByPerimeter: "SecuredByPerimeter",
}

/** Access rule in a network security perimeter configuration profile */
@added(Versions.v5)
model AccessRule {
  /** Name of the access rule */
  name?: string;

  properties?: AccessRuleProperties;
}

/** Properties of Access Rule */
@added(Versions.v5)
model AccessRuleProperties {
  direction?: AccessRuleDirection;

  /** Address prefixes in the CIDR format for inbound rules */
  addressPrefixes?: string[];

  /** Subscriptions for inbound rules */
  subscriptions?: {
    /** The fully qualified Azure resource ID of the subscription e.g. ('/subscriptions/00000000-0000-0000-0000-000000000000') */
    id?: Azure.Core.armResourceIdentifier;
  }[];

  /** Network security perimeters for inbound rules */
  networkSecurityPerimeters?: NetworkSecurityPerimeter[];

  /** Fully qualified domain names (FQDN) for outbound rules */
  fullyQualifiedDomainNames?: string[];

  /** Email addresses for outbound rules */
  emailAddresses?: string[];

  /** Phone numbers for outbound rules */
  phoneNumbers?: string[];
}

/** Information about a network security perimeter (NSP) */
@added(Versions.v5)
model NetworkSecurityPerimeter {
  /** Fully qualified Azure resource ID of the NSP resource */
  id?: Azure.Core.armResourceIdentifier<[
    {
      type: "Microsoft.Network/networkSecurityPerimeters";
    }
  ]>;

  /** Universal unique ID (UUID) of the network security perimeter */
  perimeterGuid?: uuid;

  /** Location of the network security perimeter */
  @visibility(Lifecycle.Read, Lifecycle.Create)
  location?: string;
}

/** Network security perimeter (NSP) configuration resource */
@added(Versions.v5)
model NetworkSecurityPerimeterConfiguration extends ProxyResource {
  properties?: NetworkSecurityPerimeterConfigurationProperties;
}

/** Network security configuration properties. */
@added(Versions.v5)
model NetworkSecurityPerimeterConfigurationProperties {
  @visibility(Lifecycle.Read)
  provisioningState?: NetworkSecurityPerimeterConfigurationProvisioningState;

  /** List of provisioning issues, if any */
  @visibility(Lifecycle.Read)
  @OpenAPI.extension("x-ms-identifiers", #[])
  provisioningIssues?: ProvisioningIssue[];

  networkSecurityPerimeter?: NetworkSecurityPerimeter;
  resourceAssociation?: ResourceAssociation;
  profile?: NetworkSecurityProfile;
}

/** Describes a provisioning issue for a network security perimeter configuration */
@added(Versions.v5)
model ProvisioningIssue {
  /** Name of the issue */
  @visibility(Lifecycle.Read)
  name?: string;

  @visibility(Lifecycle.Read)
  properties?: ProvisioningIssueProperties;
}

/** Details of a provisioning issue for a network security perimeter (NSP) configuration. Resource providers should generate separate provisioning issue elements for each separate issue detected, and include a meaningful and distinctive description, as well as any appropriate suggestedResourceIds and suggestedAccessRules */
@added(Versions.v5)
model ProvisioningIssueProperties {
  /** Type of issue */
  @visibility(Lifecycle.Read)
  issueType?: IssueType;

  /** Severity of the issue. */
  @visibility(Lifecycle.Read)
  severity?: Severity;

  /** Description of the issue */
  @visibility(Lifecycle.Read)
  description?: string;

  /** Fully qualified resource IDs of suggested resources that can be associated to the network security perimeter (NSP) to remediate the issue. */
  @visibility(Lifecycle.Read)
  suggestedResourceIds?: Azure.Core.armResourceIdentifier[];

  /** Access rules that can be added to the network security profile (NSP) to remediate the issue. */
  @visibility(Lifecycle.Read)
  @OpenAPI.extension("x-ms-identifiers", #[])
  suggestedAccessRules?: AccessRule[];
}

/** Information about resource association */
@added(Versions.v5)
model ResourceAssociation {
  /** Name of the resource association */
  name?: string;

  accessMode?: ResourceAssociationAccessMode;
}

/** Network security perimeter configuration profile */
@added(Versions.v5)
model NetworkSecurityProfile {
  /** Name of the profile */
  name?: string;

  /** Current access rules version */
  accessRulesVersion?: int32;

  /** List of Access Rules */
  @OpenAPI.extension("x-ms-identifiers", #["name"])
  accessRules?: AccessRule[];

  /** Current diagnostic settings version */
  diagnosticSettingsVersion?: int32;

  /** List of log categories that are enabled */
  enabledLogCategories?: string[];
}

/** Result of a list NSP (network security perimeter) configurations request. */
@added(Versions.v5)
model NetworkSecurityPerimeterConfigurationListResult {
  /** Array of network security perimeter results. */
  value?: NetworkSecurityPerimeterConfiguration[];

  /** The link used to get the next page of results. */
  nextLink?: url;
}

/**
 * The name for a network security perimeter configuration
 * @template Segment The resource type name for network security perimeter configuration (default is networkSecurityPerimeterConfigurations)
 */
@added(Versions.v5)
model NetworkSecurityPerimeterConfigurationNameParameter {
  /** The name for a network security perimeter configuration */
  @path
  @minLength(1)
  @maxLength(512)
  @TypeSpec.Rest.segment("networkSecurityPerimeterConfigurations")
  @key("networkSecurityPerimeterConfigurationName")
  networkSecurityPerimeterConfigurationName: string;
}
`,
  "lib/decorators.tsp": 'using Reflection;\n\nnamespace Azure.ResourceManager;\n\n/**\n * `@armProviderNamespace` sets the Azure Resource Manager provider name. It will default to use the\n * Namespace element value unless an override value is specified.\n *\n * @example\n *\n * ```typespec\n * @armProviderNamespace\n *  namespace Microsoft.Contoso;\n * ```\n *\n * ```typespec\n * @armProviderNamespace("Microsoft.Contoso")\n *  namespace Microsoft.ContosoService;\n * ```\n *\n * @param providerNamespace Provider namespace\n * @param libraryNamespaces a library namespace containing types for this namespace\n *\n */\nextern dec armProviderNamespace(target: Namespace, providerNamespace?: valueof string);\n\n/**\n * Declare the Azure Resource Manager library namespaces used in this provider.\n * This allows sharing Azure Resource Manager resource types across specifications\n * @param namespaces The namespaces of Azure Resource Manager libraries used in this provider\n */\nextern dec useLibraryNamespace(target: Namespace, ...namespaces: Namespace[]);\n\n/**\n * `@armLibraryNamespace` designates a namespace as containign Azure Resource Manager Provider information.\n *\n * @example\n *\n * ```typespec\n * @armLibraryNamespace\n *  namespace Microsoft.Contoso;\n * ```\n *\n */\nextern dec armLibraryNamespace(target: Namespace);\n\n/**\n * `@singleton` marks an Azure Resource Manager resource model as a singleton resource.\n *\n * Singleton resources only have a single instance with a fixed key name.\n *  `.../providers/Microsoft.Contoso/monthlyReports/default`\n *\n * See more details on [different Azure Resource Manager resource type here.](https://azure.github.io/typespec-azure/docs/howtos/ARM/resource-type)\n *\n * @param keyValue The name of the singleton resource. Default name is "default".\n */\nextern dec singleton(target: Model, keyValue?: valueof string | "default");\n\n/**\n * `@tenantResource` marks an Azure Resource Manager resource model as a Tenant resource/Root resource/Top-Level resource.\n *\n * Tenant resources have REST API paths like:\n *   `/provider/Microsoft.Contoso/FooResources`\n *\n * See more details on [different Azure Resource Manager resource type here.](https://azure.github.io/typespec-azure/docs/howtos/ARM/resource-type)\n */\nextern dec tenantResource(target: Model);\n\n/**\n * `@subscriptionResource` marks an Azure Resource Manager resource model as a subscription resource.\n *\n * Subscription resources have REST API paths like:\n *  `/subscription/{id}/providers/Microsoft.Contoso/employees`\n *\n * See more details on [different Azure Resource Manager resource type here.](https://azure.github.io/typespec-azure/docs/howtos/ARM/resource-type)\n */\nextern dec subscriptionResource(target: Model);\n\n/**\n * `@locationResource` marks an Azure Resource Manager resource model as a location based resource.\n *\n * Location based resources have REST API paths like\n *   `/subscriptions/{subscriptionId}/locations/{location}/providers/Microsoft.Contoso/employees`\n *\n * See more details on [different Azure Resource Manager resource type here.](https://azure.github.io/typespec-azure/docs/howtos/ARM/resource-type)\n */\nextern dec locationResource(target: Model);\n\n/**\n * `@resourceGroupResource` marks an Azure Resource Manager resource model as a resource group level resource.\n * This is the default option for Azure Resource Manager resources. It is provided for symmetry and clarity, and\n * you typically do not need to specify it.\n *\n *   `/subscription/{id}/resourcegroups/{rg}/providers/Microsoft.Contoso/employees`\n *\n * See more details on [different Azure Resource Manager resource type here.](https://azure.github.io/typespec-azure/docs/howtos/ARM/resource-type)\n */\nextern dec resourceGroupResource(target: Model);\n\n/**\n * `@extensionResource` marks an Azure Resource Manager resource model as an Extension resource.\n * Extension resource extends other resource types. URL path is appended\n * to another segment {scope} which refers to another Resource URL.\n *\n *   `{resourceUri}/providers/Microsoft.Contoso/accessPermissions`\n *\n * See more details on [different Azure Resource Manager resource type here.](https://azure.github.io/typespec-azure/docs/howtos/ARM/resource-type)\n */\nextern dec extensionResource(target: Model);\n\n/**\n * `@armResourceType` sets the value fo the decorated string\n * property to the type of the Azure Resource Manager resource.\n * @param resource The resource to get the type of\n */\nextern dec armProviderNameValue(target: Operation);\n\n/**\n * Marks the operation as being a collection action\n */\nextern dec armResourceCollectionAction(target: Operation);\n\n/**\n * @param resourceType Resource model\n */\nextern dec armResourceAction(target: Operation, resourceType: Model);\n\n/**\n * @param resourceType Resource model\n */\nextern dec armResourceCreateOrUpdate(target: Operation, resourceType: Model);\n\n/**\n * @param resourceType Resource model\n */\nextern dec armResourceRead(target: Operation, resourceType: Model);\n\n/**\n * @param resourceType Resource model\n */\nextern dec armResourceUpdate(target: Operation, resourceType: Model);\n\n/**\n * @param resourceType Resource model\n */\nextern dec armResourceDelete(target: Operation, resourceType: Model);\n\n/**\n * @param resourceType Resource model\n */\nextern dec armResourceList(target: Operation, resourceType: Model);\n\n/**\n * This decorator is used to identify interfaces containing resource operations.\n * When applied, it marks the interface with the `@autoRoute` decorator so that\n * all of its contained operations will have their routes generated\n * automatically.\n *\n * It also adds a `@tag` decorator bearing the name of the interface so that all\n * of the operations will be grouped based on the interface name in generated\n * clients.\n * @param _ DEPRECATED\n */\nextern dec armResourceOperations(target: Interface, _?: unknown);\n\n/**\n * This decorator is used either on a namespace or a version enum value to indicate\n * the version of the Azure Resource Manager common-types to use for refs in emitted Swagger files.\n *\n * @param version The Azure.ResourceManager.CommonTypes.Versions for the desired common-types version or an equivalent string value like "v5".\n */\nextern dec armCommonTypesVersion(\n  target: Namespace | EnumMember,\n  version: valueof string | EnumMember\n);\n\n/**\n * This decorator is used on Azure Resource Manager resources that are not based on\n * Azure.ResourceManager common types.\n *\n * @param propertiesType: The type of the resource properties.\n */\nextern dec armVirtualResource(target: Model);\n\n/**\n * This decorator sets the base type of the given resource.\n *\n * @param baseType The built-in parent of the resource, this can be "Tenant", "Subscription", "ResourceGroup", "Location", or "Extension"\n */\nextern dec resourceBaseType(\n  target: Model,\n  baseType: "Tenant" | "Subscription" | "ResourceGroup" | "Location" | "Extension"\n);\n\n/**\n * This decorator is used to indicate the identifying properties of objects in the array, e.g. size\n * The properties that are used as identifiers for the object needs to be provided as a list of strings.\n *\n * @param properties The list of properties that are used as identifiers for the object. This needs to be provided as a list of strings.\n *\n * @example\n * ```typespec\n * model Pet {\n *  @identifiers(#["size"])\n *  dog: Dog;\n * }\n * ```\n */\nextern dec identifiers(entity: ModelProperty, properties: valueof string[]);\n',
  "lib/responses.tsp": 'using Http;\nusing Rest;\nusing OpenAPI;\nusing Azure.ResourceManager.Foundations;\nusing Azure.ResourceManager.Private;\nusing Azure.ResourceManager.CommonTypes.Private;\n\nnamespace Azure.ResourceManager;\n\n/**\n * The Azure Resource Manager synchronous OK response\n * @template ResponseBody The contents of the response body\n */\n@doc("Azure operation completed successfully.")\nmodel ArmResponse<ResponseBody> {\n  ...OkResponse;\n\n  @doc("The body type of the operation request or response.")\n  @bodyRoot\n  body: ResponseBody;\n}\n\n/**\n * The Azure Resource Manager 201 response for a resource\n * @template ResponseBody The contents of the response body\n * @template ExtraHeaders Additional headers in the response. Default includes Retry-After header\n */\n@doc("Azure create operation completed successfully.")\nmodel ArmCreatedResponse<\n  ResponseBody,\n  ExtraHeaders extends TypeSpec.Reflection.Model = Azure.Core.Foundations.RetryAfterHeader\n> {\n  ...CreatedResponse;\n  ...ExtraHeaders;\n  ...Body<ResponseBody>;\n}\n\n/**\n * The response for synchronous delete of a resource\n */\n@doc("Resource deleted successfully.")\nmodel ArmDeletedResponse {\n  ...OkResponse;\n}\n\n/**\n * @dev The response for asynchronous Azure Resource Manager delete ACCEPTED\n * @template LroHeaders Optional.  Allows overriding the Lro headers returned in the response.\n */\nmodel ArmDeleteAcceptedLroResponse<LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader &\n  Azure.Core.Foundations.RetryAfterHeader>\n  is ArmAcceptedLroResponse<"Resource deletion accepted.", LroHeaders>;\n\n/**\n * @dev The response for synchronous Azure Resource Manager delete ACCEPTED\n */\nmodel ArmDeleteAcceptedResponse is ArmAcceptedResponse<"Resource deletion accepted.">;\n\n/**\n * @dev The standard ACCEPTED response\n * @template Message The description of the response status (defaults to `Resource operation accepted`)\n * @template ExtraHeaders Additional headers in the response. Default includes Retry-After header\n */\n@doc(Message)\nmodel ArmAcceptedResponse<\n  Message extends valueof string = "Resource operation accepted.",\n  ExtraHeaders extends TypeSpec.Reflection.Model = Azure.Core.Foundations.RetryAfterHeader\n> {\n  ...AcceptedResponse;\n  ...ExtraHeaders;\n}\n\n/**\n * @dev The standard Azure Resource Manager response for asynchronous PATCH, POST, and DELETE operations\n * @template Description The description of the response status (defaults to `Resource operation accepted`)\n * @template LroHeaders Optional.  The lro headers that appear in the Accepted response\n */\n@doc(Description)\nmodel ArmAcceptedLroResponse<\n  Description extends valueof string = "Resource operation accepted.",\n  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader &\n    Azure.Core.Foundations.RetryAfterHeader\n> {\n  ...AcceptedResponse;\n  ...LroHeaders;\n}\n\n/**\n * Standard Azure Resource Manager operation status response\n * @template Properties Optional resource-specific properties\n * @template StatusValues The set of allowed values for operation status\n */\nmodel ArmOperationStatus<\n  Properties extends {} = never,\n  StatusValues extends TypeSpec.Reflection.Union = ResourceProvisioningState\n> {\n  /** RP-specific properties for the operationStatus resource, only appears when operation ended with Succeeded status */\n  @visibility(Lifecycle.Read)\n  properties?: Properties;\n\n  /** The operation status */\n  @Azure.Core.lroStatus\n  status: StatusValues;\n\n  /** The unique identifier for the operationStatus resource */\n  @key\n  @path\n  @segment("operationStatuses")\n  id: string;\n\n  /** The name of the  operationStatus resource */\n  @visibility(Lifecycle.Read)\n  name?: string;\n\n  /** Operation start time */\n  @visibility(Lifecycle.Read)\n  startTime?: utcDateTime;\n\n  /** Operation complete time */\n  @visibility(Lifecycle.Read)\n  endTime?: utcDateTime;\n\n  /** The progress made toward completing the operation */\n  @visibility(Lifecycle.Read)\n  percentComplete?: float64;\n\n  /** Errors that occurred if the operation ended with Canceled or Failed status */\n  @visibility(Lifecycle.Read)\n  error?: ErrorDetail;\n}\n\n/**\n * The standard header for asynchronous operation polling\n *  @template StatusMonitor The status monitor type for lro polling\n *  @template UrlValue The value type of the Azure-AsyncOperation header\n *  @template FinalResult The logical final result of the operation\n */\nmodel ArmAsyncOperationHeader<\n  StatusMonitor extends {} = ArmOperationStatus,\n  UrlValue extends string = string,\n  FinalResult extends {} | void = never\n> {\n  /** A link to the status monitor */\n  @header("Azure-AsyncOperation")\n  @Azure.Core.pollingLocation(Azure.Core.StatusMonitorPollingOptions<PollingModel = StatusMonitor>)\n  @Azure.Core.finalLocation(FinalResult)\n  azureAsyncOperation?: UrlValue;\n}\n\n/**\n * The default header for lro PUT and DELETE polling\n * @template LroPollingOptions The polling options when polling the url in the location header\n * @template FinalResult The ultimate final result of the logical operation\n * @template UrlValue The value type for the location header\n */\nmodel ArmLroLocationHeader<\n  LroPollingOptions extends Azure.Core.PollingOptions = Azure.Core.StatusMonitorPollingOptions<PollingModel = ArmOperationStatus>,\n  FinalResult extends {} | void = void,\n  UrlValue extends string = string\n> {\n  /** The Location header contains the URL where the status of the long running operation can be checked. */\n  @header("Location")\n  @Azure.Core.pollingLocation(LroPollingOptions)\n  @Azure.Core.finalLocation(FinalResult)\n  location?: UrlValue;\n}\n\n/**\n * Provide Both Azure-AsyncOperation and Location headers\n * @template StatusMonitor The type of the polling StatusMonitor when following the Azure-AsyncOperation url\n * @template FinalResult The type of the logical result when following the location header\n * @template PollingUrlValue The value type of the link to the status monitor\n * @template FinalUrlValue The value type fo the link to the final result\n */\nmodel ArmCombinedLroHeaders<\n  StatusMonitor extends {} = ArmOperationStatus,\n  FinalResult extends {} | void = void,\n  PollingUrlValue extends string = ResourceLocation<StatusMonitor>,\n  FinalUrlValue extends string = string\n> {\n  /** A link to the status monitor */\n  @Azure.Core.pollingLocation(Azure.Core.StatusMonitorPollingOptions<StatusMonitor>)\n  @header("Azure-AsyncOperation")\n  azureAsyncOperation?: PollingUrlValue;\n\n  /** The Location header contains the URL where the status of the long running operation can be checked. */\n  @header("Location")\n  @Azure.Core.finalLocation(FinalResult)\n  location?: FinalUrlValue;\n}\n\n/**\n * @dev Azure Resource Manager response for a properly formed delete request, with no resource found\n */\nmodel ArmDeletedNoContentResponse is ArmNoContentResponse<"Resource does not exist.">;\n\n/**\n * Standard Azure Resource Manager NoContent (204) response\n * @template Message The description of the response status (defaults to `Operation completed successfully`)\n */\n@doc(Message)\nmodel ArmNoContentResponse<Message extends valueof string = "Operation completed successfully."> {\n  ...NoContentResponse;\n}\n\n/**\n * @dev Resource update operation succeeded\n * @template Resource The resource being updated\n */\n@doc("Resource \'{name}\' update operation succeeded", Resource)\nmodel ArmResourceUpdatedResponse<Resource extends Azure.ResourceManager.Foundations.Resource>\n  is ArmResponse<Resource>;\n\n/**\n * @dev Resource create operation succeeded\n * @template Resource The resource being updated\n * @template LroHeaders Optional. The lro headers returned with a Created response\n */\n@doc("Resource \'{name}\' create operation succeeded", Resource)\nmodel ArmResourceCreatedResponse<\n  Resource extends Azure.ResourceManager.Foundations.Resource,\n  LroHeaders extends TypeSpec.Reflection.Model = Azure.Core.Foundations.RetryAfterHeader\n> {\n  ...CreatedResponse;\n  ...LroHeaders;\n\n  @Azure.Core.pollingLocation(Azure.Core.StatusMonitorPollingOptions<Resource>)\n  @doc("The resource body")\n  @bodyRoot\n  body: Resource;\n}\n\n/**\n * @dev Resource synchronous create operation succeeded\n * @template Resource The resource being updated\n */\n@doc("Resource \'{name}\' create operation succeeded", Resource)\nmodel ArmResourceCreatedSyncResponse<Resource extends Azure.ResourceManager.Foundations.Resource> {\n  ...CreatedResponse;\n\n  @doc("The body type of the operation request or response.")\n  @bodyRoot\n  body: Resource;\n}\n\n/**\n * @dev Resource exists response\n */\n@doc("The Azure resource exists")\nmodel ArmResourceExistsResponse {\n  ...NoContentResponse;\n}\n\n/**\n * @dev Resource is not found response\n */\n@doc("The Azure resource is not found")\nmodel ArmResourceNotFoundResponse {\n  ...NotFoundResponse;\n}\n',
  "lib/parameters.tsp": 'using Http;\nusing Rest;\nusing OpenAPI;\nusing Azure.ResourceManager.Foundations;\nusing Azure.ResourceManager.Private;\nusing Azure.ResourceManager.CommonTypes;\nusing Azure.ResourceManager.CommonTypes.Private;\n\nnamespace Azure.ResourceManager;\n\n/**\n * The default api-version parameter type.\n */\nalias ApiVersionParameter = CommonTypes.ApiVersionParameter;\n\n/**\n * The default subscriptionId parameter type.\n */\nalias SubscriptionIdParameter = CommonTypes.SubscriptionIdParameter;\n\n/**\n * The default ResourceGroup parameter type.\n */\nalias ResourceGroupParameter = CommonTypes.ResourceGroupNameParameter;\n\n/**\n * DEPRECATED - DO NOT USE\n * The default location parameter type.\n */\n@doc("The default location parameter type.")\nmodel LocationParameter {\n  @path\n  @minLength(1)\n  @segment("locations")\n  @doc("The location name.")\n  @armCommonParameter("LocationParameter", Azure.ResourceManager.CommonTypes.Versions.v3)\n  @armCommonParameter("LocationParameter", Azure.ResourceManager.CommonTypes.Versions.v4)\n  @armCommonParameter("LocationParameter", Azure.ResourceManager.CommonTypes.Versions.v5)\n  @resourceParameterBaseFor([ResourceHome.Location])\n  location: string;\n}\n\n/** The default location parameter type. */\nmodel LocationResourceParameter {\n  /** The name of the Azure region. */\n  @path\n  @minLength(1)\n  @segment("locations")\n  @key\n  location: Azure.Core.azureLocation;\n}\n\n/**\n * The location resource for tenant-based locations.  This can be used as a parent\n * resource for resource types that are homed in a tenant-based location.\n */\nmodel TenantLocationResource is ArmLocationResource<"Tenant">;\n\n/**\n * The location resource for subscription-based locations.  This can be used as a parent\n * resource for resource types that are homed in a subscription-based location.\n */\nmodel SubscriptionLocationResource is ArmLocationResource<"Subscription">;\n\n/**\n * The location resource for resourceGroup-based locations.  This can be used as a parent\n * resource for resource types that are homed in a resourceGroup-based location.\n */\nmodel ResourceGroupLocationResource is ArmLocationResource<"ResourceGroup">;\n\n/**\n * Template for ARM location resources.  Use the parameter to specify\n */\n@friendlyName("Location")\n@armVirtualResource\n@resourceBaseType(BaseType)\nmodel ArmLocationResource<BaseType extends\n  | "Tenant"\n  | "Subscription"\n  | "ResourceGroup"\n  | "Location"\n  | "Extension" = never> {\n  ...LocationResourceParameter;\n}\n\n/**\n * The default resourceUri parameter type.\n */\n@doc("The default resourceUri parameter type.")\nmodel ResourceUriParameter {\n  @path(#{ allowReserved: true })\n  @doc("The fully qualified Azure Resource manager identifier of the resource.")\n  @resourceParameterBaseFor([ResourceHome.Extension])\n  resourceUri: string;\n}\n\n/**\n * The dynamic parameters of a resource instance - pass in the proper base type to indicate\n * where the resource is based.  The default is in a resource group\n * @template Resource The resource to get parameters for\n * @template BaseParameters The parameters representing the base Uri of the resource\n */\nmodel ResourceInstanceParameters<\n  Resource extends {},\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  ...BaseParameters;\n  ...ProviderNamespace<Resource>;\n  ...KeysOf<Resource>;\n}\n\n/**\n * The dynamic parameters of a list call for a resource instance - pass in the proper base type to indicate\n * where the list should take place.  The default is in a resource group\n * @template Resource The resource to get parameters for\n * @template BaseParameters The parameters representing the base Uri of the resource\n */\nmodel ResourceParentParameters<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  ...BaseParameters;\n  ...ProviderNamespace<Resource>;\n  ...ParentKeysOf<Resource>;\n}\n\n/**\n * The dynamic parameters of a list call for an extension resource instance.\n * @template Resource The extension resource\n */\nalias ExtensionResourceInstanceParameters<Resource extends Foundations.Resource> = ResourceInstanceParameters<\n  Resource,\n  ExtensionBaseParameters\n>;\n\n/**\n * The dynamic parameters of a list call for a tenant resource instance.\n * @template Resource the tenant resource\n */\nalias TenantInstanceParameters<Resource extends Foundations.Resource> = ResourceInstanceParameters<\n  Resource,\n  TenantBaseParameters\n>;\n\n/**\n * Template used by ArmProviderAction templates.\n */\n@armVirtualResource\n@subscriptionResource\nmodel SubscriptionActionScope {\n  @doc("Symbolic name of scope")\n  @path\n  @visibility(Lifecycle.Read)\n  @key\n  @segment("subscription")\n  name: string;\n}\n\n/**\n * Template used by ArmTenantAction templates.\n */\n@armVirtualResource\n@tenantResource\nmodel TenantActionScope {\n  @doc("Symbolic name of scope")\n  @path\n  @visibility(Lifecycle.Read)\n  @key\n  @segment("tenant")\n  name: string;\n}\n',
  "lib/Legacy/arm.legacy.tsp": 'import "./managed-identity.tsp";\nimport "./decorator.tsp";\n',
  "lib/Legacy/managed-identity.tsp": 'import "@azure-tools/typespec-azure-core";\nimport "../common-types/common-types.tsp";\n\nusing Azure.Core;\nusing Azure.ResourceManager.CommonTypes.Private;\n\nnamespace Azure.ResourceManager.Legacy;\n\n/**\n * Model representing the standard `ManagedServiceIdentity` envelope property from V4 of common type.\n *\n * Please note that this is only included for legacy specs with mixed v3 and v4 types, which would cause\n * breaking changes due to the ManagedServiceIdentityType.SystemAndUserAssigned value changes.\n *\n * Do not use this if you are already on CommonTypes.Version.v4 or beyond.\n *\n * @example\n *\n * ```typespec\n * model Foo is TrackedResource<FooProperties> {\n *   ...ResourceNameParameter<Foo>;\n *   ...Legacy.ManagedServiceIdentityV4Property;\n * }\n * ```\n */\n@doc("The managed service identities envelope.")\nmodel ManagedServiceIdentityV4Property {\n  @doc("The managed service identities assigned to this resource.")\n  identity?: ManagedServiceIdentityV4;\n}\n\n/**\n * Managed service identity (system assigned and/or user assigned identities)\n */\n#suppress "@azure-tools/typespec-azure-resource-manager/arm-common-types-incompatible-version" "intended only for v3/v4 mix backcompat cases"\n@armCommonDefinition(\n  "ManagedServiceIdentity",\n  #{ version: Azure.ResourceManager.CommonTypes.Versions.v4, isDefault: true },\n  "managedidentity.json"\n)\nmodel ManagedServiceIdentityV4 {\n  /** The service principal ID of the system assigned identity. This property will only be provided for a system assigned identity. */\n  @visibility(Lifecycle.Read)\n  principalId?: uuid;\n\n  /** The tenant ID of the system assigned identity. This property will only be provided for a system assigned identity. */\n  @visibility(Lifecycle.Read)\n  tenantId?: uuid;\n\n  /** The type of managed identity assigned to this resource. */\n  type: ManagedServiceIdentityType;\n\n  /** The identities assigned to this resource by the user. */\n  userAssignedIdentities?: Record<Azure.ResourceManager.CommonTypes.UserAssignedIdentity>;\n}\n\n/**\n * Type of managed service identity (where both SystemAssigned and UserAssigned types are allowed).\n */\nunion ManagedServiceIdentityType {\n  /** No managed identity. */\n  None: "None",\n\n  /** System assigned managed identity. */\n  SystemAssigned: "SystemAssigned",\n\n  /** User assigned managed identity. */\n  UserAssigned: "UserAssigned",\n\n  /** System and user assigned managed identity. */\n  SystemAndUserAssigned: "SystemAssigned, UserAssigned",\n\n  string,\n}\n',
  "lib/Legacy/decorator.tsp": 'using Reflection;\n\nnamespace Azure.ResourceManager.Legacy;\n\n/**\n * This decorator is used on resources that do not satisfy the definition of a resource\n * but need to be identified as such.\n */\nextern dec customAzureResource(target: Model);\n\n/**\n * Specify an external reference that should be used when emitting this type.\n * @param jsonRef - External reference(e.g. "../../common.json#/definitions/Foo")\n */\nextern dec externalTypeRef(entity: Model | ModelProperty, jsonRef: valueof string);\n',
  "lib/backcompat.tsp": 'using Azure.ResourceManager.CommonTypes;\n\nnamespace Azure.ResourceManager;\n\n// customer-managed-keys\nalias InfrastructureEncryption = CommonTypes.InfrastructureEncryption;\nalias KeyEncryptionIdentity = CommonTypes.KeyEncryptionKeyIdentity;\nalias KeyEncryptionKeyIdentity = CommonTypes.KeyEncryptionKeyIdentity;\nalias CustomerManagedKeyEncryption = CommonTypes.CustomerManagedKeyEncryption;\nalias EncryptionConfiguration = CommonTypes.Encryption;\n\n// private-links\nalias PrivateEndpoint = CommonTypes.PrivateEndpoint;\nalias PrivateEndpointConnection = CommonTypes.PrivateEndpointConnection;\nalias PrivateEndpointConnectionProperties = CommonTypes.PrivateEndpointConnectionProperties;\nalias PrivateLinkServiceConnectionState = CommonTypes.PrivateLinkServiceConnectionState;\nalias PrivateEndpointConnectionProvisioningState = CommonTypes.PrivateEndpointConnectionProvisioningState;\nalias PrivateEndpointServiceConnectionStatus = CommonTypes.PrivateEndpointServiceConnectionStatus;\nalias PrivateEndpointConnectionParameter = CommonTypes.PrivateEndpointConnectionParameter;\nalias PrivateLinkResource = CommonTypes.PrivateLinkResource;\nalias PrivateLinkResourceProperties = CommonTypes.PrivateLinkResourceProperties;\nalias PrivateLinkResourceParameter = CommonTypes.PrivateLinkResourceParameter;\nalias PrivateEndpointConnectionResourceListResult = CommonTypes.PrivateEndpointConnectionListResult;\n#suppress "deprecated" "Need for back compatibility in common-types"\nalias PrivateEndpointConnectionResourceListResultV5 = CommonTypes.PrivateEndpointConnectionListResultV5;\nalias PrivateLinkResourceListResult = CommonTypes.PrivateLinkResourceListResult;\n#suppress "deprecated" "Need for back compatibility in common-types"\nalias PrivateLinkResourceListResultV5 = CommonTypes.PrivateLinkResourceListResultV5;\n\n// types\nalias ErrorResponse = CommonTypes.ErrorResponse;\n',
  "lib/models.tsp": 'using Http;\nusing Rest;\nusing OpenAPI;\nusing Azure.Core;\nusing Azure.ResourceManager.Foundations;\nusing Azure.ResourceManager.Private;\n\nnamespace Azure.ResourceManager;\n\n/**\n * Spread this model into ARM resource models to specify resource name parameter for its operations. If `Resource` parameter\n * is specified, the resource name will be properly camel cased and pluralized for `@key` and `@segment`\n * automatically. You can also apply explicit override with `KeyName` and `SegmentName` template parameters.\n *\n * For additional decorators such as @minLength, you can use either augment decorator on `[Resource].name` or passing in a scalar string type with decorators.\n *\n * @template Resource The ARM resource this name parameter is applying to.\n * @template KeyName Override default key name of the resource.\n * @template SegmentName Override default segment name of the resource.\n * @template NamePattern The RegEx pattern of the name. Default is `^[a-zA-Z0-9-]{3,24}$`.\n * @template Type The type of the name property. Default type is string. However you can pass an union with string values.\n */\nmodel ResourceNameParameter<\n  Resource extends Foundations.Resource,\n  KeyName extends valueof string = "",\n  SegmentName extends valueof string = "",\n  NamePattern extends valueof string = "^[a-zA-Z0-9-]{3,24}$",\n  Type extends string = string\n> {\n  @doc("The name of the {name}", Resource)\n  @pattern(NamePattern)\n  @defaultResourceKeySegmentName(Resource, KeyName, SegmentName)\n  @path\n  name: Type;\n}\n\n//#region Standard Resource Operation Interfaces\n/**\n * Concrete tracked resource types can be created by aliasing this type using a specific property type.\n *\n * See more details on [different Azure Resource Manager resource type here.](https://azure.github.io/typespec-azure/docs/howtos/ARM/resource-type)\n * @template Properties A model containing the provider-specific properties for this resource\n * @template PropertiesOptional A boolean flag indicating whether the resource `Properties` field is marked as optional or required. Default true is optional and recommended.\n */\n@doc("Concrete tracked resource types can be created by aliasing this type using a specific property type.")\n@armResourceInternal(Properties)\n@Http.Private.includeInapplicableMetadataInPayload(false)\nmodel TrackedResource<Properties extends {}, PropertiesOptional extends valueof boolean = true>\n  extends Foundations.TrackedResource {\n  @doc("The resource-specific properties for this resource.")\n  @conditionalClientFlatten\n  @armResourcePropertiesOptionality(PropertiesOptional)\n  properties?: Properties;\n}\n\n/**\n * Concrete proxy resource types can be created by aliasing this type using a specific property type.\n *\n * See more details on [different Azure Resource Manager resource type here.](https://azure.github.io/typespec-azure/docs/howtos/ARM/resource-type)\n * @template Properties A model containing the provider-specific properties for this resource\n * @template PropertiesOptional A boolean flag indicating whether the resource `Properties` field is marked as optional or required. Default true is optional and recommended.\n */\n@doc("Concrete proxy resource types can be created by aliasing this type using a specific property type.")\n@armResourceInternal(Properties)\n@Http.Private.includeInapplicableMetadataInPayload(false)\nmodel ProxyResource<Properties extends {}, PropertiesOptional extends valueof boolean = true>\n  extends Foundations.ProxyResource {\n  @doc("The resource-specific properties for this resource.")\n  @conditionalClientFlatten\n  @armResourcePropertiesOptionality(PropertiesOptional)\n  properties?: Properties;\n}\n\n/**\n * Concrete extension resource types can be created by aliasing this type using a specific property type.\n *\n * See more details on [different Azure Resource Manager resource type here.](https://azure.github.io/typespec-azure/docs/howtos/ARM/resource-type)\n * @template Properties A model containing the provider-specific properties for this resource\n * @template PropertiesOptional A boolean flag indicating whether the resource `Properties` field is marked as optional or required. Default true is optional and recommended.\n */\n@extensionResource\n@doc("Concrete extension resource types can be created by aliasing this type using a specific property type.")\n@armResourceInternal(Properties)\n@Http.Private.includeInapplicableMetadataInPayload(false)\nmodel ExtensionResource<Properties extends {}, PropertiesOptional extends valueof boolean = true>\n  extends Foundations.ExtensionResource {\n  @doc("The resource-specific properties for this resource.")\n  @conditionalClientFlatten\n  @armResourcePropertiesOptionality(PropertiesOptional)\n  properties?: Properties;\n}\n//#region\n\n//#region Standard extraction models\n\n/**\n * Extracts the key (path) parameters from a resource and its parents\n * @template Resource The resource to extract properties from\n */\n@copyResourceKeyParameters\nmodel KeysOf<Resource> {}\n\n/**\n * Extracts the key (path) parameters from the parent(s) of the given resource\n * @template Resource The resource to extract properties from\n */\n@copyResourceKeyParameters("parent")\nmodel ParentKeysOf<Resource> {}\n\n/**\n * Model describing the provider namespace.\n * @template Resource The resource provided by the namespace.\n */\nmodel ProviderNamespace<Resource extends {}> {\n  @path\n  @segment("providers")\n  @assignProviderNameValue(Resource)\n  @doc("The provider namespace for the resource.")\n  provider: "Microsoft.ThisWillBeReplaced";\n}\n//#endregion\n\n//#region Common Azure Resource Manager type definitions\n\n/**\n * Use Azure.Core.armResourceIdentifier<AllowedResourceTypes>\n */\n#deprecated "Use Azure.Core.armResourceIdentifier<AllowedResourceTypes> instead."\nalias ResourceIdentifier<AllowedResourceTypes extends ArmResourceIdentifierAllowedResource[] = never> = Azure.Core.armResourceIdentifier<AllowedResourceTypes>;\n\n#deprecated "Use ArmResourceIdentifierAllowedResource instead."\nalias ResourceIdentifierAllowedResource = ArmResourceIdentifierAllowedResource;\n\n/**\n * Standard terminal provisioning state of resource type. You can include in your\n * custom provision state to avoid duplication and ensure consistency\n *\n * @example\n *\n * ```typespec\n * union FooProvisioningState {\n *   ResourceProvisioningState,  // include standard provisioning states\n *   starting: "starting",\n *   started: "started",\n *   stopping: "stopping",\n *   stopped: "stopped",\n * }\n * ```\n */\n@doc("The provisioning state of a resource type.")\n@Azure.Core.lroStatus\nunion ResourceProvisioningState {\n  @doc("Resource has been created.")\n  Succeeded: "Succeeded",\n\n  @doc("Resource creation failed.")\n  Failed: "Failed",\n\n  @doc("Resource creation was canceled.")\n  Canceled: "Canceled",\n\n  string,\n}\n\n/**\n * Standard resource provisioning state model. If you do not have any custom provisioning state,\n * you can spread this model directly into your resource property model.\n *\n * @example\n *\n * ```typespec\n * model FooProperties {\n *   // Only have standard Succeeded, Failed, Cancelled states\n *   ...DefaultProvisioningStateProperty,\n * }\n * ```\n */\n@doc("Contains a default provisioningState property to be spread into resource property types")\nmodel DefaultProvisioningStateProperty {\n  @doc("The provisioning state of the resource.")\n  @visibility(Lifecycle.Read)\n  provisioningState?: ResourceProvisioningState;\n}\n\n/**\n * Model representing the standard `extendedLocation` envelope property for a resource.\n * Spread this model into a Resource Model, if the resource supports extended locations\n *\n * @example\n * ```typespec\n * model Employee is TrackedResource<EmployeeProperties> {\n * ...ResourceNameParameter<Employee>;\n * ...ExtendedLocationProperty;\n * }\n * ```\n */\nmodel ExtendedLocationProperty {\n  @visibility(Lifecycle.Read, Lifecycle.Create)\n  extendedLocation?: Foundations.ExtendedLocation;\n}\n\n#deprecated "Please change ManagedServiceIdentity to ManagedServiceIdentityProperty."\nalias ManagedServiceIdentity = ManagedServiceIdentityProperty;\n\n/**\n * Model representing the standard `ManagedServiceIdentity` envelope property for a resource.\n * Spread this model into a resource model if the resource supports both system-assigned and user-assigned managed identities.\n *\n * @example\n *\n * ```typespec\n * model Foo is TrackedResource<FooProperties> {\n *   ...ResourceNameParameter<Foo>;\n *   ...ManagedServiceIdentityProperty;\n * }\n * ```\n */\n@doc("The managed service identities envelope.")\nmodel ManagedServiceIdentityProperty {\n  @doc("The managed service identities assigned to this resource.")\n  identity?: Foundations.ManagedServiceIdentity;\n}\n\n#deprecated "Please change ManagedSystemAssignedIdentity to ManagedSystemAssignedIdentityProperty."\nalias ManagedSystemAssignedIdentity = ManagedSystemAssignedIdentityProperty;\n/**\n * Model representing the standard `SystemAssignedServiceIdentity` envelope property for a resource.\n * Spread this model into a resource model if the resource supports system-assigned managed identities\n * but does not support user-assigned managed identities.\n *\n * @example\n *\n * ```typespec\n * model Foo is TrackedResource<FooProperties> {\n *   ...ResourceNameParameter<Foo>;\n *   ...ManagedSystemAssignedIdentityProperty;\n * }\n * ```\n */\n@doc("Managed identity for services that are constrained to system-assigned managed identities.")\nmodel ManagedSystemAssignedIdentityProperty {\n  @doc("The managed service identities assigned to this resource.")\n  identity?: Foundations.SystemAssignedServiceIdentity;\n}\n\n#deprecated "`EntityTag` will be deprecated. Please use `EntityTagProperty` instead."\nalias EntityTag = EntityTagProperty;\n/**\n * Model used only to spread in the standard `eTag` envelope property for a resource\n *\n * @example\n *\n * ```typespec\n * model Foo is TrackedResource<FooProperties> {\n *   // Only have standard Succeeded, Failed, Cancelled states\n *   ...EntityTagProperty;\n * }\n * ```\n */\n@doc("The eTag property envelope.")\nmodel EntityTagProperty {\n  @doc("If eTag is provided in the response body, it may also be provided as a header per the normal etag convention.  Entity tags are used for comparing two or more entities from the same requested resource. HTTP/1.1 uses entity tags in the etag (section 14.19), If-Match (section 14.24), If-None-Match (section 14.26), and If-Range (section 14.27) header fields.")\n  @visibility(Lifecycle.Read)\n  eTag?: string;\n}\n\n#deprecated "`ResourceKind` will be deprecated. Please use `ResourceKindProperty` instead."\nalias ResourceKind = ResourceKindProperty;\n/**\n * Model representing the standard `kind` envelope property for a resource.\n * Spread this model into a resource model if the resource support ARM `kind`.\n *\n * @example\n *\n * ```typespec\n * model Foo is TrackedResource<FooProperties> {\n *   // Only have standard Succeeded, Failed, Cancelled states\n *   ...ResourceKindProperty;\n * }\n * ```\n */\n@doc("The resource kind property envelope.")\nmodel ResourceKindProperty {\n  @doc("Metadata used by portal/tooling/etc to render different UX experiences for resources of the same type; e.g. ApiApps are a kind of Microsoft.Web/sites type.  If supported, the resource provider must validate and persist this value.")\n  @pattern("^[-\\\\w\\\\._,\\\\(\\\\\\\\\\\\)]+$")\n  @visibility(Lifecycle.Read, Lifecycle.Create)\n  kind?: string;\n}\n\n/**\n * Paged response containing resources\n * @template Resource The type of the values returned in the paged response (must be a resource)\n */\n@doc("The response of a {name} list operation.", Resource)\n@friendlyName("{name}ListResult", Resource)\nmodel ResourceListResult<Resource extends Foundations.Resource> is Azure.Core.Page<Resource>;\n\n/**\n * Paged response containing results\n * @template Result The type of the values returned in the paged response\n */\n@doc("The custom response of a list operation.")\n@friendlyName("{name}ListResult", Result)\n@pagedResult\nmodel ResourceListCustomResult<Result> {\n  /** The items on this page */\n  @items\n  value: Result[];\n\n  /** The link to the next page of items */\n  @nextLink\n  nextLink?: string;\n}\n\n#deprecated "`ResourcePlan` will be deprecated. Please use `ResourcePlanProperty` instead."\nalias ResourcePlan = ResourcePlanProperty;\n/**\n * Model representing the standard `plan` envelope property for a resource.\n * Spread this model into a resource Model if the resource supports ARM `plan`.\n *\n * @example\n *\n * ```typespec\n * model Foo is TrackedResource<FooProperties> {\n *   // Only have standard Succeeded, Failed, Cancelled states\n *   ...ResourcePlanProperty;\n * }\n * ```\n */\n@doc("The resource plan property envelope.")\nmodel ResourcePlanProperty {\n  @doc("Details of the resource plan.")\n  plan?: Plan;\n}\n\n#deprecated "`ResourceSku` will be deprecated. Please use `ResourceSkuProperty` instead."\nalias ResourceSku = ResourceSkuProperty;\n/**\n * Model representing the standard `sku` envelope property for a resource.\n * Spread this model into a resource model if the resource supports standard ARM `sku`.\n *\n * @example\n *\n * ```typespec\n * model Foo is TrackedResource<FooProperties> {\n *   // Only have standard Succeeded, Failed, Cancelled states\n *   ...ResourceSkuProperty;\n * }\n * ```\n */\n@doc("The SKU (Stock Keeping Unit) assigned to this resource.")\nmodel ResourceSkuProperty {\n  @doc("The SKU (Stock Keeping Unit) assigned to this resource.")\n  sku?: Sku;\n}\n\n#deprecated "`ManagedBy` will be deprecated. Please use `ManagedByProperty` instead."\nalias ManagedBy = ManagedByProperty;\n/**\n * Model representing the standard `managedBy` envelope property for a resource.\n * Spread this model into a resource model if the resource is managed by another entity.\n *\n * @example\n *\n * ```typespec\n * model Foo is TrackedResource<FooProperties> {\n *   // Only have standard Succeeded, Failed, Cancelled states\n *   ...ManagedByProperty;\n * }\n * ```\n */\n@doc("The managedBy property envelope.")\nmodel ManagedByProperty {\n  @doc("The fully qualified resource ID of the resource that manages this resource. Indicates if this resource is managed by another Azure resource. If this is present, complete mode deployment will not delete the resource if it is removed from the template since it is managed by another resource.")\n  managedBy?: string;\n}\n\n/** Please use the spread model EncryptionProperty */\nalias Encryption = EncryptionProperty;\n/**\n * Model used only to spread in the `encryption` envelope property for a resource.\n * @example\n *\n * ```typespec\n * model Foo is TrackedResource<FooProperties> {\n *   ...Encryption;\n * }\n * ```\n */\n/** All encryption configuration for a resource. */\nmodel EncryptionProperty {\n  /** All encryption configuration for a resource. */\n  encryption: EncryptionConfiguration;\n}\n\n/**\n * Model representing the standard `zones` envelope property for a resource.\n * Spread this model into a resource Model if the resource supports ARM `zones`.\n * @example\n * ```typescript\n * model Foo is TrackedResource<FooProperties> {\n *   ...AvailabilityZonesProperty;\n * }\n * ```\n */\nmodel AvailabilityZonesProperty {\n  /** The availability zones. */\n  zones?: string[];\n}\n\n//#endregion\n',
  "lib/operations.tsp": `using Http;
using Rest;
using Azure.ResourceManager.Foundations;

namespace Azure.ResourceManager;

// OPERATION TEMPLATES

/**
 * A resource list operation, at the subscription scope
 * @template Resource the resource being patched
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the list operation
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@doc("List {name} resources by subscription ID", Resource)
@listsResource(Resource)
@segmentOf(Resource)
@armResourceList(Resource)
@get
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmListBySubscription<
  Resource extends Foundations.Resource,
  Parameters extends {} = {},
  Response extends {} = ArmResponse<ResourceListResult<Resource>>,
  Error extends {} = ErrorResponse
> is ArmReadOperation<SubscriptionScope<Resource> & Parameters, Response, Error>;

/**
 * A resource list operation, at the scope of the resource's parent
 * @template Resource the resource being patched
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template ParentName Optional. The name of the parent resource
 * @template ParentFriendlyName Optional. The friendly name of the parent resource
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the list operation
 * @template Error Optional. The error response, if non-standard.
 */
@get
@autoRoute
@listsResource(Resource)
@segmentOf(Resource)
@Private.armRenameListByOperation(Resource, ParentName, ParentFriendlyName, false) // This must come before @armResourceList!
@armResourceList(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourceListByParent<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  ParentName extends valueof string = "",
  ParentFriendlyName extends valueof string = "",
  Parameters extends {} = {},
  Response extends {} = ArmResponse<ResourceListResult<Resource>>,
  Error extends {} = ErrorResponse
> is ArmReadOperation<
  ResourceParentParameters<Resource, BaseParameters> & Parameters,
  Response,
  Error
>;

/**
 * A resource list operation, with scope determined by BaseParameters
 * @template Resource the resource being patched
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the list operation
 * @template Error Optional. The error response, if non-standard.
 */
@get
@autoRoute
@listsResource(Resource)
@segmentOf(Resource)
@Private.armRenameListByOperation(Resource) // This must come before @armResourceList!
@armResourceList(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourceListAtScope<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Response extends {} = ArmResponse<ResourceListResult<Resource>>,
  Error extends {} = ErrorResponse
> is ArmReadOperation<
  ResourceParentParameters<Resource, BaseParameters> & Parameters,
  Response,
  Error
>;

/**
 * A resource GET operation
 * @template Resource the resource being read
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the read operation
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@doc("Get a {name}", Resource)
@get
@armResourceRead(Resource)
op ArmResourceRead<
  Resource extends {},
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Response extends {} = ArmResponse<Resource>,
  Error extends {} = ErrorResponse
> is ArmReadOperation<
  ResourceInstanceParameters<Resource, BaseParameters> & Parameters,
  Response,
  Error
>;

/**
 * Check a resource's existence via HEAD operation
 * @template Resource the resource being checked
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the read operation
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@doc("Check for the existence of a {name}", Resource)
@head
op ArmResourceCheckExistence<
  Resource extends {},
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Response extends {} = ArmResourceExistsResponse | ArmResourceNotFoundResponse,
  Error extends {} = ErrorResponse
> is ArmReadOperation<
  ResourceInstanceParameters<Resource, BaseParameters> & Parameters,
  Response,
  Error
>;

/**
 * A long-running resource CreateOrUpdate (PUT)
 * @template Resource the resource being created or updated
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template LroHeaders Optional.  Allows overriding the lro headers returned on resource create
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the createOrUpdate operation
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@doc("Create a {name}", Resource)
@armResourceCreateOrUpdate(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@Azure.Core.Foundations.Private.defaultFinalStateVia(#["location", "azure-async-operation"])
@put
op ArmResourceCreateOrUpdateAsync<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmAsyncOperationHeader<FinalResult = Resource> &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {},
  Response extends {} = ArmResourceUpdatedResponse<Resource> | ArmResourceCreatedResponse<
    Resource,
    LroHeaders
  >,
  Error extends {} = ErrorResponse
> is ArmCreateOperation<
  ResourceInstanceParameters<Resource, BaseParameters> & Parameters,
  Resource,
  Response,
  Error
>;

/**
 * DEPRECATED: Please use ArmResourceCreateOrReplaceSync instead
 * @template Resource the resource being created or updated
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the createOrUpdate operation
 * @template Error Optional. The error response, if non-standard.
 */
#deprecated "Please use ArmResourceCreateOrReplaceSync instead"
@autoRoute
@doc("Create a {name}", Resource)
@armResourceCreateOrUpdate(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@put
op ArmResourceCreateOrUpdateSync<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Response extends {} = ArmResponse<Resource>,
  Error extends {} = ErrorResponse
> is ArmCreateOperation<
  ResourceInstanceParameters<Resource, BaseParameters> & Parameters,
  Resource,
  Response,
  Error
>;

/**
 * Synchronous PUT operation for Azure Resource Manager resources
 * @template Resource the resource being created or replaced
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the createOrUpdate operation
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@doc("Create a {name}", Resource)
@armResourceCreateOrUpdate(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@put
op ArmResourceCreateOrReplaceSync<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Response extends {} = ArmResourceUpdatedResponse<Resource> | ArmResourceCreatedSyncResponse<Resource>,
  Error extends {} = ErrorResponse
> is ArmCreateOperation<
  ResourceInstanceParameters<Resource, BaseParameters> & Parameters,
  Resource,
  Response,
  Error
>;

/**
 * @dev A long-running resource CreateOrUpdate (PUT)
 * @template Resource the resource being created or replaced
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template LroHeaders Optional.  Allows overriding the lro headers returned on resource create
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the createOrReplace operation
 * @template Error Optional. The error response, if non-standard.
 */
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourceCreateOrReplaceAsync<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmAsyncOperationHeader<FinalResult = Resource> &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {},
  Response extends {} = ArmResourceUpdatedResponse<Resource> | ArmResourceCreatedResponse<
    Resource,
    LroHeaders
  >,
  Error extends {} = ErrorResponse
> is ArmResourceCreateOrUpdateAsync<
  Resource,
  BaseParameters,
  LroHeaders,
  Parameters,
  Response,
  Error
>;

/**
 * @dev A long-running resource update that only allows updating resource tags (the minimum)
 * @template Resource the resource being patched
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template LroHeaders Optional.  Allows overriding the lro headers that appear in the Accepted response
 * @template Parameters Optional. Additional parameters after the path parameters
 */
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmTagsPatchAsync<
  Resource extends Foundations.Resource,
  Properties extends {} = TagsUpdateModel<Resource>,
  BaseParameters = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader<
    Azure.Core.StatusMonitorPollingOptions<ArmOperationStatus>,
    Resource,
    string
  > &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {}
> is ArmCustomPatchAsync<
  Resource,
  TagsUpdateModel<Resource>,
  BaseParameters,
  LroHeaders,
  Parameters
>;

/**
 * @dev A long-running resource update using the items from the resource marked with Lifecycle.Update visibility
 * @template Resource the resource being patched
 * @template Properties The model type of the resource properties
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template LroHeaders Optional.  Allows overriding the lro headers returned in the Accepted response
 * @template Parameters Optional. Additional parameters after the path parameters
 */
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourcePatchAsync<
  Resource extends Foundations.Resource,
  Properties extends TypeSpec.Reflection.Model,
  BaseParameters = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader<
    Azure.Core.StatusMonitorPollingOptions<ArmOperationStatus>,
    Resource,
    string
  > &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {}
> is ArmCustomPatchAsync<Resource, Resource, BaseParameters, LroHeaders, Parameters>;

/**
 * A long-running resource update using a custom PATCH payload (Asynchronous)
 * @template Resource the resource being patched
 * @template PatchModel The input model for the PATCH request
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template LroHeaders Optional.  Allows overriding the lro headers returned in the Accepted response
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the patch operation
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@doc("Update a {name}", Resource)
@armResourceUpdate(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@patch(#{ implicitOptionality: true })
op ArmCustomPatchAsync<
  Resource extends Foundations.Resource,
  PatchModel extends TypeSpec.Reflection.Model = TagsUpdateModel<Resource>,
  BaseParameters = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader<
    Azure.Core.StatusMonitorPollingOptions<ArmOperationStatus>,
    Resource,
    string
  > &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {},
  Response extends {} = ArmResponse<Resource> | ArmAcceptedLroResponse<
    "Resource update request accepted.",
    LroHeaders
  >,
  Error extends {} = ErrorResponse
> is ArmUpdateOperation<
  ResourceInstanceParameters<Resource, BaseParameters> & Parameters,
  PatchModel,
  Response,
  Error
>;

/**
 * @dev A resource update that only allows updating resource tags (the minimum)
 * @template Resource the resource being patched
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template Parameters Optional. Additional parameters after the path parameters
 */
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmTagsPatchSync<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {}
> is ArmCustomPatchSync<Resource, TagsUpdateModel<Resource>, BaseParameters, Parameters>;

/**
 * @dev A resource update using the items from the resource marked with Lifecycle.Update visibility
 * @template Resource the resource being patched
 * @template Properties The model type of the resource properties
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template Parameters Optional. Additional parameters after the path parameters
 */
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourcePatchSync<
  Resource extends Foundations.Resource,
  Properties extends TypeSpec.Reflection.Model,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {}
> is ArmCustomPatchSync<Resource, Resource, BaseParameters, Parameters>;

/**
 * A resource update using a custom PATCH payload (synchronous)
 * @template Resource the resource being patched
 * @template PatchModel The input model for the PATCH request
 * @template BaseParameters Optional. Allows overriding the operation parameters
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response for the patch operation
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@doc("Update a {name}", Resource)
@armResourceUpdate(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@patch(#{ implicitOptionality: true })
op ArmCustomPatchSync<
  Resource extends Foundations.Resource,
  PatchModel extends TypeSpec.Reflection.Model = TagsUpdateModel<Resource>,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Response extends {} = ArmResponse<Resource>,
  Error extends {} = ErrorResponse
> is ArmUpdateOperation<
  ResourceInstanceParameters<Resource, BaseParameters> & Parameters,
  PatchModel,
  Response,
  Error
>;

/**
 * @dev Delete a resource asynchronously
 * @template Resource The resource being deleted
 * @template Response The response type for the operation
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@doc("Delete a {name}", Resource)
@armResourceDelete(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@delete
op ArmResourceDeleteAsyncBase<
  Resource extends Foundations.Resource,
  Response,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Error extends {} = ErrorResponse
>(...ResourceInstanceParameters<Resource, BaseParameters>, ...Parameters): Response | Error;

/**
 * @dev Delete a resource asynchronously.  DEPRECATED: Use ArmResourceDeleteWithoutOkAsync instead
 * @template Resource The resource being deleted
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template LroHeaders Optional. Allows overriding the headers in the Accepted response
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response(s) for the delete operation
 * @template Error Optional. The error response, if non-standard.
 */
#deprecated "Use 'ArmResourceDeleteWithoutOkAsync' instead"
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourceDeleteAsync<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {},
  Response extends {} = ArmDeletedResponse | ArmDeleteAcceptedLroResponse<LroHeaders> | ArmDeletedNoContentResponse,
  Error extends {} = ErrorResponse
> is ArmResourceDeleteAsyncBase<Resource, Response, BaseParameters, Parameters, Error>;

/**
 * @dev Delete a resource asynchronously
 * @template Resource The resource being deleted
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template LroHeaders Optional. Allows overriding the headers returned in the Accepted response
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response(s) for the delete operation
 * @template Error Optional. The error response, if non-standard.
 */
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourceDeleteWithoutOkAsync<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {},
  Response extends {} = ArmDeleteAcceptedLroResponse<LroHeaders> | ArmDeletedNoContentResponse,
  Error extends {} = ErrorResponse
> is ArmResourceDeleteAsyncBase<Resource, Response, BaseParameters, Parameters, Error>;

/**
 * Delete a resource synchronously
 * @template Resource The resource being deleted
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Response Optional. The success response(s) for the delete operation
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@doc("Delete a {name}", Resource)
@armResourceDelete(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@delete
op ArmResourceDeleteSync<
  Resource extends Foundations.Resource,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Response extends {} = ArmDeletedResponse | ArmDeletedNoContentResponse,
  Error = ErrorResponse
>(...ResourceInstanceParameters<Resource, BaseParameters>, ...Parameters): Response | Error;

/**
 * A long-running resource action.
 * @template Resource The resource being acted upon
 * @template Request The request model for the action
 * @template Response The response type for the action
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@armResourceAction(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@post
op ArmResourceActionAsyncBase<
  Resource extends Foundations.Resource,
  Request extends TypeSpec.Reflection.Model | void,
  Response extends TypeSpec.Reflection.Model | void,
  BaseParameters extends TypeSpec.Reflection.Model,
  Parameters extends {} = {},
  Error extends {} = ErrorResponse
>(
  ...ResourceInstanceParameters<Resource, BaseParameters>,
  ...Parameters,

  @doc("The content of the action request")
  @bodyRoot
  body: Request,
): Response | Error;

/**
 * @dev A long-running resource action.
 * @template Resource The resource being acted upon
 * @template Request The request model for the action
 * @template Response The response model for the action
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template LroHeaders Optional. Allows overriding the headers returned in the Accepted response
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Error Optional. The error response, if non-standard.
 */
@returnsDoc("Azure operation completed successfully.")
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourceActionAsync<
  Resource extends Foundations.Resource,
  Request extends TypeSpec.Reflection.Model | void,
  Response extends TypeSpec.Reflection.Model | void,
  BaseParameters extends TypeSpec.Reflection.Model = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader<
    Azure.Core.StatusMonitorPollingOptions<ArmOperationStatus>,
    Response,
    string
  > &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {},
  Error extends {} = ErrorResponse
> is ArmResourceActionAsyncBase<
  Resource,
  Request,
  ArmAcceptedLroResponse<"Resource operation accepted.", LroHeaders> | Response,
  BaseParameters,
  Parameters,
  Error
>;

/**
 * A synchronous resource action.
 * @template Resource The resource being acted upon
 * @template Request The request model for the action
 * @template Response The response model for the action
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@armResourceAction(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@post
@returnsDoc("Azure operation completed successfully.")
op ArmResourceActionSync<
  Resource extends Foundations.Resource,
  Request extends TypeSpec.Reflection.Model | void,
  Response extends TypeSpec.Reflection.Model | void,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Error extends {} = ErrorResponse
>(
  ...ResourceInstanceParameters<Resource, BaseParameters>,
  ...Parameters,

  @doc("The content of the action request")
  @bodyRoot
  body: Request,
): Response | Error;

/**
 * @dev A long-running resource action that returns no content. DEPRECATED: Use 'ArmResourceActionNoResponseContentAsync' instead
 * @template Resource The resource being acted upon
 * @template Request The request model for the action
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template LroHeaders Optional. Allows overriding the headers returned in the Accepted response
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Error Optional. The error response, if non-standard.
 */
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourceActionNoContentAsync<
  Resource extends Foundations.Resource,
  Request extends TypeSpec.Reflection.Model | void,
  BaseParameters extends TypeSpec.Reflection.Model = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {},
  Error extends {} = ErrorResponse
> is ArmResourceActionAsyncBase<
  Resource,
  Request,
  ArmAcceptedLroResponse<
    "Resource operation accepted.",
    LroHeaders
  > | ArmNoContentResponse<"Action completed successfully.">,
  BaseParameters,
  Parameters,
  Error
>;

/**
 * @dev A long-running resource action that returns no content.
 * @template Resource The resource being acted upon
 * @template Request The request model for the action
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template Headers Optional. Allows overriding the headers returned in the Accepted response
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Error Optional. The error response, if non-standard.
 */
@Private.enforceConstraint(Resource, Foundations.Resource)
op ArmResourceActionNoResponseContentAsync<
  Resource extends Foundations.Resource,
  Request extends TypeSpec.Reflection.Model | void,
  BaseParameters extends TypeSpec.Reflection.Model = DefaultBaseParameters<Resource>,
  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader<
    Azure.Core.StatusMonitorPollingOptions<ArmOperationStatus>,
    void,
    string
  > &
    Azure.Core.Foundations.RetryAfterHeader,
  Parameters extends {} = {},
  Error extends {} = ErrorResponse
> is ArmResourceActionAsyncBase<
  Resource,
  Request,
  ArmAcceptedLroResponse<"Resource operation accepted.", LroHeaders>,
  BaseParameters,
  Parameters,
  Error
>;

/**
 * A synchronous resource action that returns no content.
 * @template Resource The resource being acted upon
 * @template Request The request model for the action
 * @template BaseParameters Optional. Allows overriding the parameters for the operation
 * @template Parameters Optional. Additional parameters after the path parameters
 * @template Error Optional. The error response, if non-standard.
 */
@autoRoute
@armResourceAction(Resource)
@Private.enforceConstraint(Resource, Foundations.Resource)
@post
op ArmResourceActionNoContentSync<
  Resource extends Foundations.Resource,
  Request extends TypeSpec.Reflection.Model | void,
  BaseParameters = DefaultBaseParameters<Resource>,
  Parameters extends {} = {},
  Error extends {} = ErrorResponse
>(
  ...ResourceInstanceParameters<Resource, BaseParameters>,
  ...Parameters,

  @doc("The content of the action request")
  @bodyRoot
  body: Request,
): ArmNoContentResponse<"Action completed successfully."> | Error;

/**
 * @dev Adds check global name availability operation, normally used if
 * a resource name must be globally unique (for example, if the resource
 * exposes and endpoint that uses the resource name in the url)
 * @template Request the availability request, defaults to the standard request, containing name and resource type
 * @template Response the availability response, default to the standard response
 * @template AdditionalParams A model specifying additional non-path parameters to the availability request
 */
@doc("Implements global CheckNameAvailability operations")
op checkGlobalNameAvailability<
  Request extends TypeSpec.Reflection.Model = Azure.ResourceManager.Foundations.CheckNameAvailabilityRequest,
  Response extends TypeSpec.Reflection.Model = CheckNameAvailabilityResponse,
  AdditionalParams extends TypeSpec.Reflection.Model = {}
> is checkNameAvailability<
  SubscriptionIdParameter & DefaultProviderNamespace,
  Request,
  Response,
  AdditionalParams
>;

/**
 * @dev Adds check location-specific name availability operation, normally used if
 * a resource name must be globally unique (for example, if the resource
 * exposes and endpoint that uses the resource name in the url)
 * @template Request the availability request, defaults to the standard request, containing name and resource type
 * @template Response the availability response, default to the standard response
 * @template AdditionalParams A model specifying additional non-path parameters to the availability request
 */
@doc("Implements local CheckNameAvailability operations")
op checkLocalNameAvailability<
  Request extends TypeSpec.Reflection.Model = Azure.ResourceManager.Foundations.CheckNameAvailabilityRequest,
  Response extends TypeSpec.Reflection.Model = CheckNameAvailabilityResponse,
  AdditionalParams extends TypeSpec.Reflection.Model = {}
> is checkNameAvailability<
  SubscriptionIdParameter & DefaultProviderNamespace & LocationResourceParameter,
  Request,
  Response,
  AdditionalParams
>;

/**
 * @dev A provider action performed over a tenant
 * @template Request The request model for the action
 * @template Response The response type for the action
 * @template Scope The scope of the action (SubscriptionActionScope or TenantActionScope)
 * @template Parameters Optional. Additional parameters after the path parameters (e.g. Location)
 * @template Error Optional. The error response, if non-standard.
 */
@post
@action
@armResourceCollectionAction
@Private.armUpdateProviderNamespace
op ArmProviderActionSync<
  Request extends {} | void = void,
  Response extends {} | void = void,
  Scope extends {} = TenantActionScope,
  Parameters extends {} = {},
  Error extends {} = ErrorResponse
>(
  ...Azure.ResourceManager.Foundations.DefaultBaseParameters<Scope>,
  ...ProviderNamespace<Scope>,
  ...Parameters,

  /** The request body */
  @bodyRoot body: Request,
): Response | Error;

/**
 * @dev A long-running provider action.
 * @template Request The request model for the action
 * @template Response The response type for the action
 * @template Scope The scope of the action (SubscriptionActionScope or TenantActionScope)
 * @template Parameters Optional. Additional parameters after the path parameters (e.g. Location)
 * @template LroHeaders Optional.  Allows overriding the lro headers returned in the Accepted response
 * @template Error Optional. The error response, if non-standard.
 */
@post
@action
@armResourceCollectionAction
@Private.armUpdateProviderNamespace
op ArmProviderActionAsync<
  Request extends {} | void = void,
  Response extends {} | void = void,
  Scope extends {} = TenantActionScope,
  Parameters extends {} = {},
  LroHeaders extends TypeSpec.Reflection.Model = ArmLroLocationHeader<
    Azure.Core.StatusMonitorPollingOptions<ArmOperationStatus>,
    Response,
    string
  > &
    Azure.Core.Foundations.RetryAfterHeader,
  Error extends {} = ErrorResponse
>(
  ...Azure.ResourceManager.Foundations.DefaultBaseParameters<Scope>,
  ...ProviderNamespace<Scope>,
  ...Parameters,

  /** The request body */
  @bodyRoot body: Request,
): ArmAcceptedLroResponse<"Resource operation accepted.", LroHeaders> | Response | Error;
`,
  "lib/interfaces.tsp": 'using Http;\nusing Rest;\nusing OpenAPI;\nusing Azure.ResourceManager.Foundations;\nusing Azure.ResourceManager.Private;\n\nnamespace Azure.ResourceManager;\n\n/**\n * This is the interface that implements the standard Azure Resource Manager operation that returns\n * all supported RP operations. You should have exactly one declaration for each\n * Azure Resource Manager service. It implements\n *   GET "/providers/Microsoft.ContosoProviderHub/operations"\n */\ninterface Operations {\n  @tag("Operations")\n  @autoRoute\n  @armUpdateProviderNamespace\n  @doc("List the operations for the provider")\n  @segment("operations")\n  @get\n  list(\n    ...ApiVersionParameter,\n\n    @path\n    @segment("providers")\n    @doc("The provider namespace (this parameter will not show up in operations).")\n    provider: "Microsoft.ThisWillBeReplaced",\n  ): ArmResponse<OperationListResult> | ErrorResponse;\n}\n\n/**\n * @deprecated Use Azure.ResourceManager.TrackedResourceOperations instead\n * A composite interface for resources that include `ResourceInstanceOperations<Resource, Properties>`\n * and `ResourceCollectionOperations<Resource>`. It includes: `GET`, `PUT`, `PATCH`, `DELETE`, ListByParent,\n * ListBySubscription operations. The actual route depends on the resource model.\n * This is the most common API pattern for Tracked Resources to use.\n * @template Resource the ArmResource that provides these operations\n * @template Properties RP-specific property bag for the resource\n * @template BaseParameters The http parameters that are part of the request\n *\n */\n#deprecated "Use Azure.ResourceManager.TrackedResourceOperations instead"\ninterface ResourceOperations<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model,\n  BaseParameters = DefaultBaseParameters<Resource>\n> extends TrackedResourceOperations<Resource, Properties, BaseParameters> {}\n\n/**\n * A composite interface for resources that include `ResourceInstanceOperations<Resource, Properties>`\n * and `ResourceCollectionOperations<Resource>`. It includes: `GET`, `PUT`, `PATCH`, `DELETE`, ListByParent,\n * ListBySubscription operations. The actual route depends on the resource model.\n * This is the most common API pattern for Tracked Resources to use.\n * @template Resource the ArmResource that provides these operations\n * @template Properties RP-specific property bag for the resource\n * @template BaseParameters The http parameters that are part of the request\n *\n */\ninterface TrackedResourceOperations<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model,\n  BaseParameters = DefaultBaseParameters<Resource>\n>\n  extends ResourceInstanceOperations<Resource, Properties, BaseParameters>,\n    ResourceCollectionOperations<Resource, BaseParameters> {}\n\n/**\n * A composite interface for Proxy resources that include `ResourceInstanceOperations<Resource, Properties>`\n * and `ResourceListByParent<Resource>`. It includes: `GET`, `PUT`, `PATCH`, `DELETE`, ListByParent operations.\n *\n * The actual route depends on the resource model but would have started with\n *   `/subscriptions/{id}/resourcegroups/{rg}/providers/Microsoft.XXX/...`\n *\n * This is the most common API pattern for Proxy Resources to use.\n * @template Resource the ArmResource that provides these operations\n * @template BaseParameters The http parameters that are part of the request\n */\n#suppress "deprecated" "This should be deprecated in a future release"\ninterface ProxyResourceOperations<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n>\n  extends ResourceRead<Resource, BaseParameters>,\n    ResourceCreate<Resource, BaseParameters>,\n    ResourceDelete<Resource, BaseParameters>,\n    ResourceListByParent<Resource, BaseParameters> {}\n\n/**\n * A composite interface for Tenant resources that include `ResourceInstanceOperations<Resource, Properties>`\n * and `ResourceListByParent<Resource>`. It includes: `GET`, `PUT`, `PATCH`, `DELETE`, ListByParent operations.\n *\n * The routes are always start at root level:\n *   `/providers/Microsoft.XXX/...`\n *\n * This is the most common API pattern for Tenant Resources to use.\n * @template Resource the ArmResource that provides these operations\n * @template Properties RP-specific property bag for the resource\n */\n#suppress "deprecated" "This should be deprecated in a future release"\ninterface TenantResourceOperations<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model\n>\n  extends TenantResourceRead<Resource>,\n    TenantResourceCreate<Resource>,\n    TenantResourceUpdate<Resource, Properties>,\n    TenantResourceDelete<Resource>,\n    TenantResourceListByParent<Resource> {}\n\n/**\n * A composite interface for resources that have CRUD operations.\n * @template Resource The ArmResource that provides these operations\n * @template Properties RP-specific property bag for the resource\n * @template BaseParameters The http parameters that are part of the request\n * @template PatchModel The model used for PATCH operations\n */\n#suppress "deprecated" "This should be deprecated in a future release"\ninterface ResourceInstanceOperations<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model,\n  BaseParameters = DefaultBaseParameters<Resource>,\n  PatchModel = ResourceUpdateModel<Resource, Properties>\n>\n  extends ResourceRead<Resource, BaseParameters>,\n    ResourceCreate<Resource, BaseParameters>,\n    ResourceUpdate<Resource, Properties, BaseParameters>,\n    ResourceDelete<Resource, BaseParameters> {}\n\n/**\n * A composite interface for resource collections.\n * @template Resource The ArmResource that provides these operations\n * @template BaseParameters The http parameters that are part of the request\n */\ninterface ResourceCollectionOperations<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> extends ResourceListByParent<Resource, BaseParameters>, ResourceListBySubscription<Resource> {}\n\n/**\n * An interface for resources with can be listed by subscription.\n * @template Resource The ArmResource that provides these operations\n */\ninterface ResourceListBySubscription<Resource extends Foundations.Resource> {\n  /**\n   * @dev List resources by subscription.\n   * @template Resource The ArmResource to list.\n   */\n  listBySubscription is ArmListBySubscription<Resource>;\n}\n\n/**\n * An interface for resources which can be listed by parent.\n * @template Resource The ArmResource that provides these operations\n * @template BaseParameters The http parameters that are part of the request\n * @template ParentName The name of the parent resource\n * @template ParentFriendlyName The friendly name of the parent resource\n */\ninterface ResourceListByParent<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>,\n  ParentName extends valueof string = "",\n  ParentFriendlyName extends valueof string = ""\n> {\n  /**\n   * @dev List resources by parent.\n   * @template Resource The ArmResource to list.\n   * @template BaseParameters The http parameters that are part of the request\n   * @template ParentName The name of the parent resource\n   * @template ParentFriendlyName The friendly name of the parent resource\n   */\n  @Private.armRenameListByOperation(Resource, ParentName, ParentFriendlyName, true) // This must come before @armResourceList!\n  listByParent is ArmResourceListByParent<Resource, BaseParameters, ParentName, ParentFriendlyName>;\n}\n\n/**\n * A composite interface for resources that include a GET operation.\n * @template Resource The ArmResource that provides these operations\n * @template BaseParameters The http parameters that are part of the request\n */\ninterface ResourceRead<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  /**\n   * @dev Retrieve a resource.\n   * @template Resource The ArmResource to retrieve.\n   * @template BaseParameters The http parameters that are part of the request\n   */\n  get is ArmResourceRead<Resource, BaseParameters>;\n}\n\n/**\n * A composite interface for resources that include a synchronous create or update operation.\n * @template Resource The ArmResource that provides these operations\n * @template BaseParameters The http parameters that are part of the request\n */\ninterface ResourceCreateSync<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  /**\n   * @dev Create or update a resource using the synchronous call pattern.\n   * @template Resource The ArmResource to create or update.\n   * @template BaseParameters The http parameters that are part of the request\n   */\n  createOrUpdate is ArmResourceCreateOrReplaceSync<Resource, BaseParameters>;\n}\n\n/**\n * A composite interface for resources that include a long-running create or update operation.\n * @template Resource The ArmResource that provides these operations\n * @template BaseParameters The http parameters that are part of the request\n */\ninterface ResourceCreateAsync<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  /**\n   * @dev Create or update a resource using the asynchronous call pattern.\n   * @template Resource The ArmResource to create or update.\n   * @template BaseParameters The http parameters that are part of the request\n   */\n  createOrUpdate is ArmResourceCreateOrUpdateAsync<Resource, BaseParameters>;\n}\n\n/**\n * @dev A composite interface for resources that include a long-running delete operation.\n *      DEPRECATED: Use ResourceDeleteWithoutOkAsync instead\n * @template Resource The ArmResource that provides these operations\n * @template BaseParameters The http parameters that are part of the request\n */\n#deprecated "This should be deprecated in a future release"\n@doc("Delete a resource using the asynchronous call pattern")\ninterface ResourceDeleteAsync<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  /**\n   * @dev Delete a resource using the asynchronous call pattern.\n   * @template Resource The ArmResource to delete.\n   * @template BaseParameters The http parameters that are part of the request\n   */\n  delete is ArmResourceDeleteAsync<Resource, BaseParameters>;\n}\n\n/**\n * @dev A composite interface for resources that include a synchronous delete operation.\n * @template Resource The ArmResource that provides these operations\n * @template BaseParameters The http parameters that are part of the request\n */\n@doc("Delete a resource using the asynchronous call pattern")\ninterface ResourceDeleteWithoutOkAsync<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  /**\n   * @dev Delete a resource using the asynchronous call pattern.\n   * @template Resource The ArmResource to delete.\n   * @template BaseParameters The http parameters that are part of the request\n   */\n  delete is ArmResourceDeleteWithoutOkAsync<Resource, BaseParameters>;\n}\n\n/**\n * A composite interface for resources that include a synchronous delete operation.\n * @template Resource The ArmResource that provides these operations\n * @template BaseParameters The http parameters that are part of the request\n */\n@doc("Delete a resource")\ninterface ResourceDeleteSync<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  /**\n   * @dev Delete a resource using the synchronous call pattern.\n   * @template Resource The ArmResource to delete.\n   * @template BaseParameters The http parameters that are part of the request\n   */\n  delete is ArmResourceDeleteSync<Resource, BaseParameters>;\n}\n\n/**\n * @dev A composite interface for resources that include a long-running update operation.\n * @template Resource The ArmResource that provides these operations\n * @template Properties RP-specific property bag for the resource\n * @template BaseParameters The http parameters that are part of the request\n */\n@doc("Asynchronous resource update")\ninterface ResourceUpdateAsync<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model,\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  /**\n   * @dev Update a resource using the asynchronous call pattern.\n   * @template Resource The ArmResource to update.\n   * @template Properties RP-specific property bag for the resource\n   * @template BaseParameters The http parameters that are part of the request\n   */\n  update is ArmCustomPatchAsync<\n    Resource,\n    ResourceUpdateModel<Resource, Properties>,\n    BaseParameters\n  >;\n}\n\n/**\n * A composite interface for resources that include a synchronous update operation.\n * @template Resource The ArmResource that provides these operations\n * @template Properties RP-specific property bag for the resource\n * @template BaseParameters The http parameters that are part of the request\n */\n@doc("Synchronous resource update")\ninterface ResourceUpdateSync<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model,\n  BaseParameters = DefaultBaseParameters<Resource>\n> {\n  /**\n   * @dev Update a resource using the synchronous call pattern.\n   * @template Resource The ArmResource to update.\n   * @template Properties RP-specific property bag for the resource\n   * @template BaseParameters The http parameters that are part of the request\n   */\n  update is ArmCustomPatchSync<Resource, ResourceUpdateModel<Resource, Properties>, BaseParameters>;\n}\n\n/**\n * A composite interface for resources that includes CRUD operations.\n * @template Resource The ArmResource that provides these operations\n * @template Properties RP-specific property bag for the resource\n */\n#suppress "deprecated" "This should be deprecated in a future release"\ninterface ExtensionResourceInstanceOperations<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model\n>\n  extends ExtensionResourceRead<Resource>,\n    ExtensionResourceCreate<Resource>,\n    ExtensionResourceUpdate<Resource, Properties>,\n    ExtensionResourceDelete<Resource> {}\n\n/**\n * A composite interface for resource collections that include a paginated list operation.\n * @template Resource The ArmResource that provides these operations\n */\ninterface ExtensionResourceCollectionOperations<Resource extends Foundations.Resource>\n  extends ExtensionResourceList<Resource> {}\n\n/**\n * A composite interface for resources that include CRUD and list operations.\n * @template Resource The ArmResource that provides these operations\n * @template Properties RP-specific property bag for the resource\n */\ninterface ExtensionResourceOperations<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model\n>\n  extends ExtensionResourceInstanceOperations<Resource, Properties>,\n    ExtensionResourceCollectionOperations<Resource> {}\n\nalias ResourceCreate<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> = ResourceCreateAsync<Resource, BaseParameters>;\n\nalias ResourceUpdate<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model,\n  BaseParameters = DefaultBaseParameters<Resource>\n> = ResourceUpdateSync<Resource, Properties, BaseParameters>;\n\n#suppress "deprecated" "This should be deprecated in a future release"\nalias ResourceDelete<\n  Resource extends Foundations.Resource,\n  BaseParameters = DefaultBaseParameters<Resource>\n> = ResourceDeleteAsync<Resource, BaseParameters>;\n\nalias ProxyResourceUpdate<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model\n> = ResourceUpdate<Resource, Properties>;\n\nalias ExtensionResourceRead<Resource extends Foundations.Resource> = ResourceRead<\n  Resource,\n  ExtensionBaseParameters\n>;\n\nalias ExtensionResourceCreate<Resource extends Foundations.Resource> = ResourceCreate<\n  Resource,\n  ExtensionBaseParameters\n>;\n\nalias ExtensionResourceUpdate<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model\n> = ResourceUpdate<Resource, Properties, ExtensionBaseParameters>;\n\n#suppress "deprecated" "This should be deprecated in a future release"\nalias ExtensionResourceDelete<Resource extends Foundations.Resource> = ResourceDelete<\n  Resource,\n  ExtensionBaseParameters\n>;\n\nalias ExtensionResourceList<Resource extends Foundations.Resource> = ResourceListByParent<\n  Resource,\n  ExtensionBaseParameters,\n  "Extension",\n  "parent"\n>;\n\nalias TenantResourceRead<Resource extends Foundations.Resource> = ResourceRead<\n  Resource,\n  TenantBaseParameters\n>;\n\nalias TenantResourceCreate<Resource extends Foundations.Resource> = ResourceCreateAsync<\n  Resource,\n  TenantBaseParameters\n>;\n\n#suppress "deprecated" "This should be deprecated in a future release"\nalias TenantResourceDelete<Resource extends Foundations.Resource> = ResourceDelete<\n  Resource,\n  TenantBaseParameters\n>;\n\nalias TenantResourceUpdate<\n  Resource extends Foundations.Resource,\n  Properties extends TypeSpec.Reflection.Model\n> = ResourceUpdate<Resource, Properties, TenantBaseParameters>;\n\nalias TenantResourceListByParent<Resource extends Foundations.Resource> = ResourceListByParent<\n  Resource,\n  TenantBaseParameters,\n  "Tenant",\n  "tenant"\n>;\n'
};
var _TypeSpecLibrary_ = {
  jsSourceFiles: TypeSpecJSSources,
  typespecSourceFiles: TypeSpecSources
};
export {
  $armCommonTypesVersion,
  $armLibraryNamespace,
  $armProviderNameValue,
  $armProviderNamespace,
  $armResourceAction,
  $armResourceCollectionAction,
  $armResourceCreateOrUpdate,
  $armResourceDelete,
  $armResourceList,
  $armResourceOperations,
  $armResourceRead,
  $armResourceUpdate,
  $armVirtualResource,
  $customAzureResource,
  $decorators2 as $decorators,
  $extensionResource,
  $identifiers,
  $lib,
  $linter,
  $locationResource,
  $resourceBaseType,
  $resourceGroupResource,
  $singleton,
  $subscriptionResource,
  $tenantResource,
  $useLibraryNamespace,
  ResourceBaseType,
  _TypeSpecLibrary_,
  armRenameListByOperationInternal,
  getArmCommonTypeOpenAPIRef,
  getArmCommonTypesVersion,
  getArmCommonTypesVersions,
  getArmIdentifiers,
  getArmKeyIdentifiers,
  getArmProviderNamespace,
  getArmResource,
  getArmResourceInfo,
  getArmResourceKind,
  getArmResources,
  getExternalTypeRef,
  getResourceBaseType,
  getSingletonResourceKey,
  getUsedLibraryNamespaces,
  isArmCollectionAction,
  isArmCommonType,
  isArmLibraryNamespace,
  isArmProviderNamespace,
  isArmVirtualResource,
  isAzureResource,
  isConditionallyFlattened,
  isCustomAzureResource,
  isSingletonResource,
  namespace3 as namespace,
  resolveResourceBaseType,
  resolveResourceOperations
};
