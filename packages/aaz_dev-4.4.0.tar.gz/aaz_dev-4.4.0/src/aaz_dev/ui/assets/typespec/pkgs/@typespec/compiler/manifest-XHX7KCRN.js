import "./chunk-QRPWKJ4C.js";

// src/typespec/core/packages/compiler/dist/manifest.js
var manifest_default = {
  "version": "1.0.0",
  "commit": "8321f0d7390366e09c2bb99321a7794f3ab9c16c"
};
export {
  manifest_default as default
};
