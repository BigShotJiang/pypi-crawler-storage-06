import {
  getEventDefinitions
} from "./chunk-JGUT6FVU.js";
export {
  getEventDefinitions as unsafe_getEventDefinitions
};
