from xksqlite.sqlite import 数据库操作



def test_BaoCuoXingxi():
    数据库 = 数据库操作('1.db')
    数据库.连接()