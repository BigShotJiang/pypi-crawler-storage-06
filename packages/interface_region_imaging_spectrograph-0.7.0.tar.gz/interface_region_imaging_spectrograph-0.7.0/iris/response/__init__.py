"""
The IRIS instrument response files.
"""

from ._response import files

__all__ = [
    "files",
]
