import mbridge


def test_import():
    assert mbridge is not None
