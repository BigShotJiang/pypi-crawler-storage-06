To use this module, you need to:

1.  Go to *Invoicing \> Customers \> Invoices* and create a new Invoice
    or open an existing draft invoice. Make sure that the customer has
    'Enable Voxel' field checkbox (See configuration section).
2.  Validate the invoice and it will be send to Voxel immediately or
    later, depending on the Voxel 'Send mode' chosen in the company
    configuration.
3.  A new tab will be visible on the invoice form with the label 'Voxel'
    to show the information regarding sending the invoice to Voxel.
4.  When the report is sent, you will be able to see the XML report in
    another tab next to the jobs tab.
