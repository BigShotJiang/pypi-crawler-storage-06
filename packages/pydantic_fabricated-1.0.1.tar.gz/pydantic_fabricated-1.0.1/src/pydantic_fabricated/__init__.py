from .metaclass import PydanticFabricated


__all__ = ['PydanticFabricated']
