# -*- coding: utf-8 -*-
"""h5.dev ~ Under construction!"""

from __future__ import annotations


def _main() -> None: ...


if __name__ == "__main__":
    _main()
