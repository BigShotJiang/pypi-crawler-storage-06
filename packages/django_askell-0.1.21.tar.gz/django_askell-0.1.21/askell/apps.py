from django.apps import AppConfig


class AskellConfig(AppConfig):
    name = 'askell'
