from django.apps import AppConfig


class AskellWagtailConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'askell.wagtail'
    label = 'askellwagtail'
