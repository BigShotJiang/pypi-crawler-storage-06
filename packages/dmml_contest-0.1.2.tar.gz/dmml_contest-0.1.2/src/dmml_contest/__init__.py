def main() -> None:
    print("Hello from dmml-contest!")
