## Version 0.0.4

- [x] Add `pandas` styling compability with pandas v2.2 (PR #4)
- [x] moved `get_lr_multiplicative_decomposition` function to package [78b0c2](https://github.com/RasmussenLab/njab/commit/78b0c27c3ab11489fb81ca320e03485cdc0b1344)

## Version 0.0.3

- [x] Add pandas styling 
- [x] improve rendering of tutorials on READTHEDOCS

## Version 0.0.2

- [x] move src.pandas from cirrhosis_project to njab.pandas
- [x] Add tutorial with example data and add it to the documentation
