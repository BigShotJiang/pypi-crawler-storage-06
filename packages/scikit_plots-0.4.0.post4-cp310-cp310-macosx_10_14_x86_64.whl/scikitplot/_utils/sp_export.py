"""Tensorflow like exporter."""

SKPLT_API_NAME = "scikitplot"

# class ExportType(Protocol):

#   def __call__(
#       self,
#       *v2: str,
#       v1: Optional[Sequence[str]] = None,
#   ) -> api_export:
#     ...


# sp_export: ExportType = functools.partial(
#     api_export, api_name=SKPLT_API_NAME
# )
