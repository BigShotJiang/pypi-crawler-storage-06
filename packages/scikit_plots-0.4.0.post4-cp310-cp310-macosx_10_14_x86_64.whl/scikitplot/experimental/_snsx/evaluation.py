"""
Predictive Model diagnostics.

Visualize predictive performance like ROC, PR, confusion matrix, calibration, Brier curve.
"""
