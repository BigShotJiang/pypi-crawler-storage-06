from .MPP import Lumping
from . import kernel
from . import utils
from . import plot

__version__ = "0.9.0"
__docformat__ = "numpy"
