# The Most Probable Path (MPP) Algorithm Package

MPP is a package, which allows to reduce the number of states of a state trajectory based on the most probable path (MPP) algorithm.

## Installation

## Features
