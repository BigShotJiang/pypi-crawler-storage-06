
# rattail-tempmon

Rattail is a retail software framework, released under the GNU General Public
License.

This is the ``rattail-tempmon`` package, which provides a database schema, and
client/server daemons for recording and processing temperature data.

Please see Rattail's [home page](https://rattailproject.org/) for more
information.
