"""
    Allow MC6809 to be executable
    through `python -m MC6809`.
"""


from MC6809.cli_app import main


if __name__ == '__main__':
    main()
