"""
    MC6809 CPU emulator written in Python
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.8.0'
__author__ = 'Jens Diemer <git@jensdiemer.de>'
