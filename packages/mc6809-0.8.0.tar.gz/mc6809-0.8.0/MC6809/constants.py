from pathlib import Path

import MC6809


CLI_EPILOG = 'Project Homepage: https://github.com/6809/MC6809'

BASE_PATH = Path(MC6809.__file__).parent
