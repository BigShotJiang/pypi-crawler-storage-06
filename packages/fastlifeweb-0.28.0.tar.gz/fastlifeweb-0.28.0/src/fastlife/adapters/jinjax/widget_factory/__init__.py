"""Factory for widgets in order to edit pydantic model."""
