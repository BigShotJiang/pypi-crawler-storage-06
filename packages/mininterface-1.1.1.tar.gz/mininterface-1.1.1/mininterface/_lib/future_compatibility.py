
from typing import Literal


def literal(c):
    return Literal[*c]