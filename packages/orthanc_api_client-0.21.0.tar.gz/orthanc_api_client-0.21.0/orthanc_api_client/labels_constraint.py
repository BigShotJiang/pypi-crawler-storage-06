from strenum import StrEnum

class LabelsConstraint(StrEnum):

    ANY = 'Any'
    ALL = 'All'
    NONE = 'None'
