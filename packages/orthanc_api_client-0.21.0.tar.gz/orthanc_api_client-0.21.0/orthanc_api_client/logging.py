from strenum import StrEnum


class LogLevel(StrEnum):

    DEFAULT = 'default'
    VERBOSE = 'verbose'
    TRACE = 'trace'
