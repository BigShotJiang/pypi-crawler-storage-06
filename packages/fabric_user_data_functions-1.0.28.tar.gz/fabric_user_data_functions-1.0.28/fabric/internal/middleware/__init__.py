"""You can ignore this module and any files within it. It is used to help set up your User Data Functions.
"""

# flake8: noqa: F401
from ._invocationIdMiddleware import *