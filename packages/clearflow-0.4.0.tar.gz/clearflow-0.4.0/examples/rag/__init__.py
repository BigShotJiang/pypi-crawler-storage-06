"""Message-driven RAG example using observable flows."""
