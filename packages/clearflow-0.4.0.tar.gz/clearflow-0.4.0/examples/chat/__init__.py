"""Message-driven chat example using observable flows."""
