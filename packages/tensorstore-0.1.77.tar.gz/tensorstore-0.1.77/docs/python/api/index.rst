.. _python-api:

API reference
=============

Core
----

.. python-apigen-group:: core

Indexing
--------

.. python-apigen-group:: indexing

Spec
----

.. python-apigen-group:: spec

Views
-----

.. python-apigen-group:: views

Virtual views
^^^^^^^^^^^^^

.. python-apigen-group:: virtual-views

Data types
----------

.. python-apigen-group:: data-types

Asynchronous support
---------------------

.. python-apigen-group:: asynchronous-support

OCDBT
-----

.. python-apigen-group:: ocdbt


Experimental
---------------------

.. python-apigen-group:: experimental
