def test_patterns_pii():
    pass
