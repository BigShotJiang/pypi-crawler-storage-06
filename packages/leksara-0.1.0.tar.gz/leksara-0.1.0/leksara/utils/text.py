"""General text helpers: html stripper, whitespace, etc."""
