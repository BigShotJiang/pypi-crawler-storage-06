

from constant_sorrow.constants import NO_BLOCKCHAIN_CONNECTION

NO_BLOCKCHAIN_CONNECTION.bool_value(False)
