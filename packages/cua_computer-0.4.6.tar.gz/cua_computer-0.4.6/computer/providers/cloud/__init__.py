"""CloudProvider module for interacting with cloud-based virtual machines."""

from .provider import CloudProvider

__all__ = ["CloudProvider"]
