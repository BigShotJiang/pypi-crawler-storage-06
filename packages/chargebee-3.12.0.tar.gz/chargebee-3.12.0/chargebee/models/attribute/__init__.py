from .operations import Attribute
from .responses import AttributeResponse
