# The B-value calculator: map expected diversity under background selection

See documentation for details: https://JohriLab.github.io/Bvalcalc/

Jacob Marsh and Parul Johri
UNC Chapel Hill, NC
