from .fw_file_rs import *

__doc__ = fw_file_rs.__doc__
if hasattr(fw_file_rs, "__all__"):
    __all__ = fw_file_rs.__all__