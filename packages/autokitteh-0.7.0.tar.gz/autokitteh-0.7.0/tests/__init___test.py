# Smoke test, fill with content


def test_smoke():
    from autokitteh import __init__  # noqa: F401
