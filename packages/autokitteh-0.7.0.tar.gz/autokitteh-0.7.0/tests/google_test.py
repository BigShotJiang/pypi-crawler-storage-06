# Smoke test, fill with content


def test_smoke():
    from autokitteh import google  # noqa: F401
