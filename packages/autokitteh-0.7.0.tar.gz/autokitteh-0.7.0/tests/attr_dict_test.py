# Smoke test, fill with content


def test_smoke():
    from autokitteh import attr_dict  # noqa: F401
