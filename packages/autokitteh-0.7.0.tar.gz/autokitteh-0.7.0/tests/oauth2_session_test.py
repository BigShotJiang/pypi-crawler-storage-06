# Smoke test, fill with content


def test_smoke():
    from autokitteh import oauth2_session  # noqa: F401
