## cdf 

### Improved

- When deploying an extractor pipeline config, Toolkit now gives an
improved error message if the config property is not YAML and no longer
gives an incorrect warning if a `!keyvalut` token is used with multiple
preceding spaces.

## templates

No changes.