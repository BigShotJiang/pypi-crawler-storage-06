This module adds a Documents tab to sales orders, linking them with the OCA Document Management System DMS).
