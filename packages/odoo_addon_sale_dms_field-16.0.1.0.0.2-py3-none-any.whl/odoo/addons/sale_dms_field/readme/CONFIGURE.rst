To configure file templates for sales documents:

#. *Go to Documents > Configuration > File templates* and create a new record.
#. Set a storage, a model (sale) and the access groups you want.
#. Click on the "Documents" tab icon and a folder hierarchy will be created.
#. You can set here the hierarchy of directories, subdirectories and files you need, this hierarchy will be used as a base when creating a new record (res.partner for example).
