"""PR Prompt - Generate pull request review prompts for LLMs."""

from .generator import PrPromptGenerator

__version__ = "1.0.0"
__all__ = ["PrPromptGenerator"]
