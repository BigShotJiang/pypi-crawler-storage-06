from .description_instructions import DESCRIPTION_INSTRUCTIONS
from .review_instructions import REVIEW_INSTRUCTIONS

__all__ = [
    "DESCRIPTION_INSTRUCTIONS",
    "REVIEW_INSTRUCTIONS",
]
