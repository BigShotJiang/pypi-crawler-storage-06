"""Empty sky template, used for dark measurements."""
from ..calibration import empty_sky as darkness

__all__ = [darkness]
