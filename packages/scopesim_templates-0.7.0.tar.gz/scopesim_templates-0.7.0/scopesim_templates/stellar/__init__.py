# -*- coding: utf-8 -*-
"""Templates to simulate stellar sources."""

from .clusters import *
from .stellar import *
