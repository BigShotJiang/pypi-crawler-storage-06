"""
Test package for computer-talk.
"""
