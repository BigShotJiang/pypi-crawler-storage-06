from typing import Optional, List, Iterable, Dict, Any


class RickText:
    @classmethod
    def list(cls):
        pass

    @classmethod
    def preformatted(cls):
        pass

    @classmethod
    def quote(cls):
        pass

    @classmethod
    def strike(cls):
        pass