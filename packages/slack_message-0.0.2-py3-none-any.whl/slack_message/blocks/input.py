class Input:
    pass