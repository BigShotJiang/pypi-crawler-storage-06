"""
Test utilities
"""


class RequestStub:
    """
    Request Stub
    """

    def __init__(self, user) -> None:
        self.user = user
