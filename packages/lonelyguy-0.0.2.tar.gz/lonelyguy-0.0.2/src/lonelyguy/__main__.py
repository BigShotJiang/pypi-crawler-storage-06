# src/lonelyguy/__main__.py

from . import main

main()