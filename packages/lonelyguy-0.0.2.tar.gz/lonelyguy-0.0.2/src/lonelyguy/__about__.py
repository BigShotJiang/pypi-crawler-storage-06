# SPDX-FileCopyrightText: 2025-present Lonely Guy <phoenex659@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"
