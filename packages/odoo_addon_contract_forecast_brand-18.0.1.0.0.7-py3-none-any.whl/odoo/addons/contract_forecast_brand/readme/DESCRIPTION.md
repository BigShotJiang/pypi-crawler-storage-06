This addon add brand field for contract forecast.
