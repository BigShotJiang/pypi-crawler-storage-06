#!/usr/bin/env bash
#MISE description="Stage and amend the whole working dir"
git add . && git commit --amend --no-edit
