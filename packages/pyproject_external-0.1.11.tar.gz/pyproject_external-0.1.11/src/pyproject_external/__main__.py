# SPDX-License-Identifier: MIT
# SPDX-FileCopyrightText: 2025 Quansight Labs

if __name__ == "__main__":
    import sys

    from ._cli import app

    sys.exit(app())
