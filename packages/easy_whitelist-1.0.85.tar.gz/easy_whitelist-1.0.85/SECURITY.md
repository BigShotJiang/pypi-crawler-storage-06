# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

## Reporting a Vulnerability

Please use <https://github.com/qiqilelebaobao> to report security vulnerabilities.

The Security Team will process your report within a week, and respond within a month (although it will depend on the severity of your report).
