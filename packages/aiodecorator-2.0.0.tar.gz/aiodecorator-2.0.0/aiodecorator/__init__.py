__version__ = '2.0.0'


from .throttle import (
    throttle,
    ThrottleType
)
