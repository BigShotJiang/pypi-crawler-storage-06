"""
vncx - 轻量级 Python VNC 客户端库
"""

from .client import VNCClient

__version__ = "0.1.0"
__all__ = ["VNCClient"]