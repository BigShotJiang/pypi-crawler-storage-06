__version__ = "0.1.0"
__author__ = "Takuro Iizuka"
__email__ = "t_iizuka@fixstars.com"
