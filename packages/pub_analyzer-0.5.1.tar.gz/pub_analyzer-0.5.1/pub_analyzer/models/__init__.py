"""Scholarly entities models definitions from OpenAlex."""
