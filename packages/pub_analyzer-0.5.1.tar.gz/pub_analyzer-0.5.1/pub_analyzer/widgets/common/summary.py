"""Common Summary format Widget."""

from textual.containers import VerticalScroll


class SummaryWidget(VerticalScroll):
    """Common format summary container."""
