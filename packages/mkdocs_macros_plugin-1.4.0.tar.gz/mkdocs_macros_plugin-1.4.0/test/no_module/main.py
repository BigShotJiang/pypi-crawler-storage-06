# there is no standard function here
# the build will fail and spit the list of possible functions that must be here

def foo(x):
    return x + 5