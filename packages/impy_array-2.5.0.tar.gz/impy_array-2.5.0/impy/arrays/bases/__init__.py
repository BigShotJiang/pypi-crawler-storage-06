from .metaarray import MetaArray

# overload numpy functions to MetaArray
from . import overload