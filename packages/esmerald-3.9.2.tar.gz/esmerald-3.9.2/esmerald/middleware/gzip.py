from lilya.middleware.compression import GZipMiddleware  # noqa

__all__ = ["GZipMiddleware"]
