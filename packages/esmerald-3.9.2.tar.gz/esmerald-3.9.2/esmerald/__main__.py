from esmerald.core.directives.cli import esmerald_cli


def run_cli() -> None:
    esmerald_cli()


if __name__ == "__main__":  # pragma: no cover
    esmerald_cli()
