from .ModelFakerConfig import ModelFakerConfig

__all__ = ["ModelFakerConfig"]
