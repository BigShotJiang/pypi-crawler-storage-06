# SarthakFraction

A human-friendly Python package for handling fractions.

## Installation

```bash
pip install SarthakFraction