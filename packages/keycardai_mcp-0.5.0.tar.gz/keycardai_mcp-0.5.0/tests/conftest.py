"""Pytest configuration and shared fixtures for mcp tests."""
# Import all fixtures to make them available to test files
from .fixtures.auth_provider import *  # noqa: F403, F401
