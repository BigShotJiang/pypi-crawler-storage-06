"""Shared test fixtures for mcp package."""
