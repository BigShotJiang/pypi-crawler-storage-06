__version__ = "0.12.0"
__version_tuple__ = (0, 12, 0)
