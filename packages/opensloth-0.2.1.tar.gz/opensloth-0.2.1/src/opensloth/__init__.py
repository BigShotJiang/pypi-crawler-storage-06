import pathlib


OPENSLOTH_DATA_DIR = pathlib.Path("~/.cache/opensloth").expanduser().resolve()
