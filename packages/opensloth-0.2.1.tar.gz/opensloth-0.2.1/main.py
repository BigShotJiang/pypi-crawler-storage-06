def main():
    print("Hello from opensloth!")


if __name__ == "__main__":
    main()
