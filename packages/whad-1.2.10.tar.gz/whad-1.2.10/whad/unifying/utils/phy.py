from whad.esb.utils.phy import PHYS as ESB_PHYS

PHYS = {
    'UNIFYING' : ESB_PHYS['ESB-2M']
}
