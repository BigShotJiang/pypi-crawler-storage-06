"""
WHAD ESB stack constants.
"""
from enum import IntEnum

class ESBRole(IntEnum):
    """ESB role
    """
    PTX = 0
    PRX = 1
