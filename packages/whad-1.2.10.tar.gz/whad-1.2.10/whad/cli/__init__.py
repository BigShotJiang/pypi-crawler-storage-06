"""WHAD command-line interface module

"""

from .app import CommandLineApp, command

__all__ = [
    'CommandLineApp',
    'command'
]
