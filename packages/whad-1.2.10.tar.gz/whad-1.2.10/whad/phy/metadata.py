from whad.hub.phy import PhyMetadata, generate_phy_metadata
