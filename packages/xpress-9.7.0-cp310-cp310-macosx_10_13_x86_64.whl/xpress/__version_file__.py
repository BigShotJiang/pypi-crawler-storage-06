# Version of the Python interface (must match that of the Xpress Optimizer Library)
__version_library__ = '45.01.02'
__version__ = '9.7.0'
