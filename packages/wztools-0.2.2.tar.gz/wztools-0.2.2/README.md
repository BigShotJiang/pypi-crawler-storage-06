
```bash
uv run python -m build   

```