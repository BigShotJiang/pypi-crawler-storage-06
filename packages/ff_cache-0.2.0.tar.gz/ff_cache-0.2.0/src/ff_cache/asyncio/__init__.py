from .cache import AsyncCache as Cache
from .decorator import cache

__all__ = [
    "Cache",
    "cache"
]