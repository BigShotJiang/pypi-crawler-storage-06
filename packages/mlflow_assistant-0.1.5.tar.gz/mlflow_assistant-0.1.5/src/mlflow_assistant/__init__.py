"""MLflow Assistant: Interact with MLflow using LLMs."""

__version__ = "0.1.0"

from .cli.commands import cli

__all__ = ["cli"]
