"""Core functionality for MLflow Assistant.

This subpackage contains the core modules for managing connections, workflows, and
interactions with the MLflow Tracking Server.
"""
