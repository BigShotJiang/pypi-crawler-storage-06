"""Main entry point for executing the MLflow Assistant package directly."""

from mlflow_assistant.cli.commands import cli

if __name__ == "__main__":
    cli()
