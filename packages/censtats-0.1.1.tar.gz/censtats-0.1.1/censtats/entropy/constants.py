DEF_WINDOW_SIZE = 100_000
DEF_BED9_COLS = (
    "chrom",
    "chromStart",
    "chromEnd",
    "name",
    "score",
    "strand",
    "thickStart",
    "thickEnd",
    "itemRgb",
)
DEF_FILTER_RP = {"SAR", "Simple_repeat"}
