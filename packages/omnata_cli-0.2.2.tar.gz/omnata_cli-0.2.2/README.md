# omnata-cli

A command line interface for Omnata