from len_sentence import count_sentence

print(count_sentence("Hello world!", "Latn"))
print(count_sentence("你好世界", "Hans"))
print(count_sentence("こんにちは", "Jpan"))
print(count_sentence("བཀྲ་ཤིས་བདེ་ལེགས", "Tibt"))
print(count_sentence("مرحبا بالعالم", "Arab"))
print(count_sentence("Привет мир", "Cyrl"))
