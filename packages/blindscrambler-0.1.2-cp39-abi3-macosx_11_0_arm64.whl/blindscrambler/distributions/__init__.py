from .cvdistributions import uniform
__all__ = ["uniform"]