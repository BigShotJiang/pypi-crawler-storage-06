"""Top-level package for ai-marketplace-monitor."""

__author__ = """Bo Peng"""
__email__ = "ben.bob@gmail.com"
__version__ = "0.9.11"
