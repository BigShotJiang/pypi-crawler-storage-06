---
name: 🐛 Bug report
about: Create a report to help us improve
title: "[Bug] Your title here"
labels: bug
assignees: ""
---

## Expected Behavior

---

## Actual Behavior

---

## Steps to Reproduce the Problem

1.
1.
1.

---

## Specifications

- Version:
- Platform:
- Subsystem:
