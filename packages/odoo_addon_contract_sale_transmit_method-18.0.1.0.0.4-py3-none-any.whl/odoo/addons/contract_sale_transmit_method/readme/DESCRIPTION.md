Propagate transmit method (email, post, portal, ...) from sale orders to
contracts.
