from .base_models import QueryParams

DEFAULT_QUERY_PARAMS = QueryParams(per=50, page=1)
