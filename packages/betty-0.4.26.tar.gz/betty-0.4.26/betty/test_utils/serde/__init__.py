"""
Test utilities for :py:mod:`betty.serde`.
"""
