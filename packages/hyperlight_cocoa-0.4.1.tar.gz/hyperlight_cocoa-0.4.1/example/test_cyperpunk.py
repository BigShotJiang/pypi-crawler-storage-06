from cocoa.ui.components.header.letters.word import Word

word = Word("0123456789", font="bubbles")

print(word.to_ascii().ascii)
