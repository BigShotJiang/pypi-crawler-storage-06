class Empty:
    def __init__(
        self,
        name: str,
    ):
        self.name = name

    async def update(self):
        pass
