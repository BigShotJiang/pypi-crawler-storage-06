from .text import Text as Text
from .text_config import TextConfig as TextConfig
