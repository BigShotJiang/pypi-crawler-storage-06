from enum import Enum


class TotalRateStatus(Enum):
    READY = "READY"
    RUNNING = "RUNNING"
    STOPPED = "STOPPED"
