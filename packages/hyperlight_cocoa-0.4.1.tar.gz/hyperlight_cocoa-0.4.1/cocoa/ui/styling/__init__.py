from .stylize import stylize as stylize
from .stylizer import get_style as get_style
