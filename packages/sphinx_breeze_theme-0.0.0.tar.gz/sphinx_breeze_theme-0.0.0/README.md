# Breeze - A Modern Sphinx Theme

A modern Sphinx theme built with TypeScript and Vite.
