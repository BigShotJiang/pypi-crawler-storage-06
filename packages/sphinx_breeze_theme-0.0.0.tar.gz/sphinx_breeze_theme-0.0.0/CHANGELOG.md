# CHANGELOG

<!-- version list -->

## v0.0.0 (2025-09-21)

- Initial Release
