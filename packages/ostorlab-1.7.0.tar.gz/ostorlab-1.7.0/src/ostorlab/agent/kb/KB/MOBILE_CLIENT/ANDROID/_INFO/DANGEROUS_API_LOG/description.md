This entry describes all the logging API calls used to write log entries.
In Android, a logging mechanism called `Logcat` is introduced to view and filter series of circular buffers that contain logs from various applications and portions of the system.
Log information in `Logcat` can be read out from other applications in the same device. Thus, the output of sensitive information to `Logcat` is considered that it has a vulnerability of the information leakage. 


