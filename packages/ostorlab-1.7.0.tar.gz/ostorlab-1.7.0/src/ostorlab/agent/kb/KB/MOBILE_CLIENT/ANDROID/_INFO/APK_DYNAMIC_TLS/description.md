List of all TLS methods used in the application.
