The `hasFragileUserData` flag can be added to the application `AndroidManifest.xml` file. 

=== "XML"
	```xml
	<application android:icon="@drawable/icon" android:hasFragileUserData="true">
	```

