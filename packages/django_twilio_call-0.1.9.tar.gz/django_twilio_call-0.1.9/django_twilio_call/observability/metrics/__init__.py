"""Metrics collection package."""
