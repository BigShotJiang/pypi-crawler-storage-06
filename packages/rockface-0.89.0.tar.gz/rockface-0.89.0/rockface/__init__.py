__all__ = ["Rig", "__version__"]
__version__ = "dev"

from .rig import Rig
