To configure this module, you need to:

1.  Allow SLA for a Helpdesk's Team
2.  Set a resource calendar

## Configure SLA

1.  Go to Helpdesk \> Configuration \> SLA.
2.  Edit or create a new SLA.
3.  Select a days or hours for that SLA.
