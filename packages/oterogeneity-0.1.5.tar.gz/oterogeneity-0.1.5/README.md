# ot-heterogeneity

A project to compute optimal transport based heterogeneity indexes.