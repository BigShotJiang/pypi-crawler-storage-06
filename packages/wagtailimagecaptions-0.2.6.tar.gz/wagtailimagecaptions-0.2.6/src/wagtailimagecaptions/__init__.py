"""
A Django app for extending the Wagtail Image model to add captions and alt fields as
well as the extraction of IPTC image meta data.
"""

__version__ = "0.2.6"
