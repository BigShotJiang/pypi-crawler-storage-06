
# PosNegLib
مكتبة بسيطة لتحديد ما إذا كان العدد موجب أو سالب أو صفر.

## التثبيت
```bash
py -m pip install PosNegLib


الاستخدام من Python

from pos_neg import check_number

print(check_number(10)) # Positive
print(check_number(-3)) # Negative
print(check_number(0)) # Zero
