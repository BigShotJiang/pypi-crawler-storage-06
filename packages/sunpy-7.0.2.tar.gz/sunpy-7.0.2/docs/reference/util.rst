Utilities (`sunpy.util`)
************************

.. automodapi:: sunpy.util

.. automodapi:: sunpy.util.config

.. automodapi:: sunpy.util.datatype_factory_base

.. automodapi:: sunpy.util.net

.. automodapi:: sunpy.util.xml

.. automodapi:: sunpy.util.sphinx

.. automodapi:: sunpy.util.sphinx.generate
   :headings: ^"

.. automodapi:: sunpy.util.functools
