Physics (`sunpy.physics`)
*************************

``sunpy.physics`` contains routines to calculate various physical parameters
and models for the Sun.

.. automodapi:: sunpy.physics

.. automodapi:: sunpy.physics.differential_rotation
