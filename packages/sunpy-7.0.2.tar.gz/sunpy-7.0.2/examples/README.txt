***************
Example Gallery
***************

The gallery contains examples of how to use sunpy.
Each example is a short and self contained how-to guide for performing a specific task.

Sample data
===========
Some of these examples require the SunPy sample data, which are downloaded as needed via the module `sunpy.data.sample`.
If you want to download all of the sample data files in advance, call :func:`sunpy.data.sample.download_all`.
