Showcase
========

Examples that use an advanced combination of capabilities in sunpy
