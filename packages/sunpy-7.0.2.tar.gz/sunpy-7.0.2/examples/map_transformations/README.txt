Combining, Co-aligning, and Reprojecting Images
===============================================

Examples of combining, aligning, and reprojecting sunpy maps
