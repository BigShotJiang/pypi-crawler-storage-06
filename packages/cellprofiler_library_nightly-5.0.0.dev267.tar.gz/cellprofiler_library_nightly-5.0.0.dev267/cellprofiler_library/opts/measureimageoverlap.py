from enum import Enum

# Decimation Method for Earh Mover's Distance
class DM(Enum):
    KMEANS = "K Means"
    SKELETON = "Skeleton"
