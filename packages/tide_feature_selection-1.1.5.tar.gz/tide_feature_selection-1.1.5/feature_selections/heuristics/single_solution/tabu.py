import os
import random
import time
import numpy as np

from feature_selections.heuristics.heuristic import Heuristic
from datetime import timedelta
from queue import Queue
from utility.utility import createDirectory, add, create_population, fitness, diversification


class Tabu(Heuristic):
    """
    Class that implements the tabu search heuristic.

    Args:
        size (int): Size of the tabu list
        nb (int)  : Maximal neighbors distance from the current solution
    """
    def __init__(self, name, target, pipeline, train, test=None, drops=None, scoring=None, Tmax=None, ratio=None, N=None,
                 Gmax=None, size=None, nb=None, suffix=None, cv=None, verbose=None, output=None):
        super().__init__(name, target, pipeline, train, test, cv, drops, scoring, N, Gmax, Tmax, ratio, suffix, verbose,
                         output)
        self.size = size if size is not None else self.N
        self.nb = nb if nb is not None else -1
        self.path = os.path.join(self.path, 'tabu' + self.suffix)
        createDirectory(path=self.path)

    @staticmethod
    def is_in_tabu(individual, tabuList):
        for tabu in list(tabuList.queue):
            if np.all(individual == tabu):
                return True
        return False

    @staticmethod
    def insert_tabu(tabuList, individual):
        if not tabuList.full():
            tabuList.put(individual)
        else:
            tabuList.get()
            tabuList.put(individual)
        return tabuList

    def specifics(self, bestInd, bestTime, g, t, last, out):
        string = "Tabu List Size: " + str(self.size) + os.linesep + \
                 "Disruption Rate: " + str(self.nb) + os.linesep
        self.save("Tabu Search", bestInd, bestTime, g, t, last, string, out)

    def start(self, pid):
        code = "TABU"
        debut = time.time()
        self.path = os.path.join(self.path)
        createDirectory(path=self.path)
        print_out = ""
        np.random.seed(None)
        # Measuring the execution time
        instant = time.time()
        # Generation (G) and Tabu List initialisation
        G, tabuList, same1, same2, stop = 0, Queue(maxsize=self.size), 0, 0, False
        # Population P initialisation
        P = create_population(inds=self.N, size=self.D)
        # Evaluates population
        scores = [fitness(train=self.train, test=self.test, columns=self.cols, ind=ind, target=self.target,
                          pipeline=self.pipeline, scoring=self.scoring, ratio=self.ratio, cv=self.cv)[0] for ind in P]
        bestScore, bestSubset, bestInd = add(scores=scores, inds=np.asarray(P), cols=self.cols)
        scoreMax, subsetMax, indMax, timeMax = bestScore, bestSubset, bestInd, debut
        mean_scores = float(np.mean(scores))
        time_instant = timedelta(seconds=(time.time() - instant))
        time_debut = timedelta(seconds=(time.time() - debut))
        # Pretty print the results
        print_out = self.sprint_(print_out=print_out, name=code, pid=pid, maxi=scoreMax, best=bestScore,
                                 mean=mean_scores, feats=len(subsetMax), time_exe=time_instant,
                                 time_total=time_debut, g=G, cpt=0, verbose=self.verbose) + "\n"
        tabuList = self.insert_tabu(tabuList=tabuList, individual=bestInd)
        # Main process iteration (generation iteration)
        while G < self.Gmax:
            instant = time.time()
            # Neighborhood exploration and evaluation
            neighborhood = []
            for i in range(self.N):
                # Neighbor calculation
                neighbor = diversification(individual=bestInd, distance=self.nb)
                if not self.is_in_tabu(neighbor, tabuList):
                    neighborhood.append(neighbor)
            # Evaluate the neighborhood
            if neighborhood:
                scores = [fitness(train=self.train, test=self.test, columns=self.cols, ind=ind, target=self.target,
                                  pipeline=self.pipeline, scoring=self.scoring, ratio=self.ratio, cv=self.cv)[0]
                          for ind in neighborhood]
                bestScore, bestSubset, bestInd = add(scores=scores, inds=np.asarray(neighborhood), cols=self.cols)
                tabuList = self.insert_tabu(tabuList=tabuList, individual=bestInd)
            G = G + 1
            same1, same2 = same1 + 1, same2 + 1
            mean_scores = float(np.mean(scores))
            time_instant = timedelta(seconds=(time.time() - instant))
            time_debut = timedelta(seconds=(time.time() - debut))
            # Update which individual is the best
            if bestScore > scoreMax:
                same1, same2 = 0, 0
                scoreMax, subsetMax, indMax, timeMax = bestScore, bestSubset, bestInd, time_debut
            print_out = self.sprint_(print_out=print_out, name=code, pid=pid, maxi=scoreMax, best=bestScore,
                                     mean=mean_scores, feats=len(subsetMax), time_exe=time_instant,
                                     time_total=time_debut, g=G, cpt=same2, verbose=self.verbose) + "\n"
            # If the time limit is exceeded, we stop
            if time.time() - debut >= self.Tmax:
                stop = True
            # Write important information to file
            if G % 10 == 0 or G == self.Gmax or stop:
                self.specifics(bestInd=indMax, bestTime=timeMax, g=G, t=timedelta(seconds=(time.time() - debut)),
                               last=G - same2, out=print_out)
                print_out = ""
                if stop:
                    break
        return scoreMax, indMax, subsetMax, timeMax, self.pipeline, pid, code, G - same2, G
