from importlib.metadata import version as get_version

from . import evals

__version__ = get_version("astabench")
