2025-09-22 Version: 1.1.0
- Support API GetDocTranslateTask.
- Support API SubmitDocTranslateTask.


2025-09-11 Version: 1.0.0
- Generated python 2025-07-07 for AnyTrans.

