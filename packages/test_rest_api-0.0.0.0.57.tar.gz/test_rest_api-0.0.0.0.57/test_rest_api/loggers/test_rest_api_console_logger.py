import logging

# Create custom logger for test rest api console logging
test_rest_api_console_logger: logging.Logger = logging.getLogger(name="test_rest_api_console")
