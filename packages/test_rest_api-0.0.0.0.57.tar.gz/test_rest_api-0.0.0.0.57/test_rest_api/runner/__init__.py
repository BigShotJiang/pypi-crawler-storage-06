from ..logging.setup import setup_root_logger

setup_root_logger()
