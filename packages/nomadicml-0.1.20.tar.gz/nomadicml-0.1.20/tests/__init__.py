"""Tests for the NomadicML SDK."""
