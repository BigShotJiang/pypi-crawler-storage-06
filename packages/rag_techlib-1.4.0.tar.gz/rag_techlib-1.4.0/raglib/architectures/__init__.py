# architectures package for system-level orchestrators
__all__ = [
    "fid",
]

from .fid import FusionInDecoderPipeline  # noqa: F401
