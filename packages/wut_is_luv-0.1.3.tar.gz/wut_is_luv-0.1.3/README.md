## [wut-is-luv](https://en.wikipedia.org/wiki/What_Is_Love)

## Usage
1. `pipx install wut-is-luv` 
2. `wut is luv`


## Impetus
It is an all too common question with an easy answer. 
