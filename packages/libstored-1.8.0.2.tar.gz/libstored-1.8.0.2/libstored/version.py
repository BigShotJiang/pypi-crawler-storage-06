# SPDX-FileCopyrightText: 2020-2023 Jochem Rutgers
#
# SPDX-License-Identifier: MPL-2.0

__version__ = '1.8.0.2'
libstored_version = '1.8.0+2'

