"""
DataSkipper Boat - IoT Modbus monitoring and data collection system
"""

__version__ = "1.0.4"
__author__ = "Ayush"
__email__ = "ayush@datasailors.io"