ID_COL_NAME = "id"
MOL_COL_NAME = "mol"
CHARGE_COL_NAME = "formal_charge"
ENERGY_PROPERTY_NAME = "single_point_energy"
