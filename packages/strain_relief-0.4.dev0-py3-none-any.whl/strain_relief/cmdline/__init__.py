from ._strain_relief import main as strain_relief

__all__ = ["strain_relief"]
