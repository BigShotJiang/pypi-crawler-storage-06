from django.apps import AppConfig

class LacreiModelsAddressConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "lacrei_models.address"
    label = "lacrei_models_address"
