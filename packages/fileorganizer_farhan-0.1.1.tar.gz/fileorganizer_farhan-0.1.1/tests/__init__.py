"""
Test package for FileOrganizer.
"""