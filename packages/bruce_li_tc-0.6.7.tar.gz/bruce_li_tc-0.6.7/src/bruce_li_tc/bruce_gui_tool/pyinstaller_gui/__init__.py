"""
PyInstaller GUI 工具
"""

from .gui import run

__all__ = ['run']