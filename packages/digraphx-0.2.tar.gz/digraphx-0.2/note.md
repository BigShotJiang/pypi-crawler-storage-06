# cvx + network flow
