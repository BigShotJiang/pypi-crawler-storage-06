"""Test package for AWS Black Belt MCP server."""
