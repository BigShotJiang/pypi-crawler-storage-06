"""Integration testing package for AWS Black Belt MCP server."""
