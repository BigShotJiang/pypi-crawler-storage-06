"""Helper functionality for AWS Black Belt MCP server."""
