"""
Command-line interface for MCP Code Scanner.
"""

from .main import cli, main

__all__ = ["cli", "main"]