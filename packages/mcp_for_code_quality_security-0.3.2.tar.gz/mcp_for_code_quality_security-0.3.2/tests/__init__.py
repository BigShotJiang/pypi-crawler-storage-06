"""
Test suite for MCP Code Scanner.
"""