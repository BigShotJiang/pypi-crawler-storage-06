To use this module, you need to:

1.  Go to *Customers \> Financial Risk*
2.  Set limits and choose options to compute in credit limit.
3.  Go to *Sales -\> Orders -\> Orders* and create a new Sales Orders.
