# snake_in_terminal_bashar

لعبة ثعبان نصية تعمل في الطرفية باستخدام مكتبة curses.

التشغيل محلياً:
- في لينكس/ماك: python -m snake_in_terminal_bashar
- في ويندوز: يفضل تشغيل داخل WSL أو تثبيت الحزمة windows-curses ثم تشغيل نفس الأمر.

بعد التثبيت:
- snake-bashar

المؤلف: بشار نشوان
