from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from byteplussdkapig20221112.api.apig20221112_api import APIG20221112Api
