2025-03-19 Version: 1.1.0
- Support API CreateDefaultRole.
- Update API GetInstanceDetail: update response param.
- Update API ListInstances: add param Tag.
- Update API ListInstances: update response param.


2024-12-24 Version: 1.0.7
- Update API GetInstanceDetail: update response param.
- Update API ListInstances: update response param.


2024-12-02 Version: 1.0.6
- Update API GetInstanceDetail: update response param.


2024-08-28 Version: 1.0.5
- Update API GetInstanceDetail: update response param.
- Update API ListInstances: add param ResourceGroupId.
- Update API ListInstances: update response param.


2024-08-03 Version: 1.0.4
- Update API UpdatePublicNetworkStatus: update param Cidr.
- Update API UpdatePublicNetworkStatus: update param PublicNetworkEnabled.


2024-07-30 Version: 1.0.3
- Update API UpdatePublicNetworkStatus: update param Cidr.
- Update API UpdatePublicNetworkStatus: update param PublicNetworkEnabled.


2024-07-12 Version: 1.0.2
- Update API UpdatePublicNetworkStatus: add param Cidr.


2024-06-25 Version: 1.0.1
- Update API GetInstanceDetail: update response param.
- Update API ListInstances: update response param.


2024-06-20 Version: 1.0.0
- Generated python 2023-10-12 for milvus.

