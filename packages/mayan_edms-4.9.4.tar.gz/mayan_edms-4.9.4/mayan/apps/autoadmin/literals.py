COMMAND_NAME_AUTOADMIN_CREATE = 'autoadmin_create'
COMMAND_NAME_CREATESUPERUSER = 'createsuperuser'

DEFAULT_EMAIL = 'autoadmin@example.com'
DEFAULT_PASSWORD = None
DEFAULT_USERNAME = 'admin'
