class DependenciesException(Exception):
    """
    Base exception for the dependencies app
    """
