This module creates a new view to manage invoice lines information.
