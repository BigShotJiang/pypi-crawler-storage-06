__version__ = "74.20250917"
GIT_REF = "ef08e60"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/ef08e60"