# cmd2-table

Backport of cmd2.table_creator module from cmd2 2.7.0 to ease migration to cmd2 3.x
