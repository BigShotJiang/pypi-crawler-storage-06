Changelog
=========

Version 0.1
^^^^^^^^^^^

* Initial release
* Development and testing are performed on:

    - TEM Glacios
    - TEM Titan Krios G1, G2, G3i, G4
    - Health Monitor 1.12.0
