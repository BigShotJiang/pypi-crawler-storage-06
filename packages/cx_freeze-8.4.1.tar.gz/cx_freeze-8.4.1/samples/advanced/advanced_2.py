print("Hello from cx_Freeze Advanced #2")

module = __import__("testfreeze_2")
