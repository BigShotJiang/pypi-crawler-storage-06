print("importing pkg1")

from . import pkg2, sub1  # noqa: E402,F401
