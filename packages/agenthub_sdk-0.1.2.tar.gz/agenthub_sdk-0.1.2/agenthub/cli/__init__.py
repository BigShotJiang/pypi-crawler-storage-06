"""CLI Module - Command-line interface for AgentHub."""

from agenthub.cli.main import main

__all__ = ["main"]
