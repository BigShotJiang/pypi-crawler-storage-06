"""Core module tests."""
