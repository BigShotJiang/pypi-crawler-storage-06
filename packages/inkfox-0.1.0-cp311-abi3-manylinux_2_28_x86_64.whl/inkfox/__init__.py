from .inkfox import *

__doc__ = inkfox.__doc__
if hasattr(inkfox, "__all__"):
    __all__ = inkfox.__all__