name: Pyonir Demo app
theme_name: pencil
enabled_plugins:- 
===
Default site configurations