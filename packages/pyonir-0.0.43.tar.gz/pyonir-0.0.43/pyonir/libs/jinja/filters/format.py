def format(input, **context):
    return input.format(**context)