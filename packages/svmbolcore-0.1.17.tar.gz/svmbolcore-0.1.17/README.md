math library that symbolically solve algebra
expressions are immutable and always sorted

# to do:
solve quadratic
calculus
tensor class. cpu arithmitic operations
linear algebra basics
cuda codegen
