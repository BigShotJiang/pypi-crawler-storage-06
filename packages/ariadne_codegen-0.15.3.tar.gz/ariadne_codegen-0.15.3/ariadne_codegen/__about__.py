__version__ = "0.15.3"  # This is overwritten by Hatch in CI/CD, don't change it.
