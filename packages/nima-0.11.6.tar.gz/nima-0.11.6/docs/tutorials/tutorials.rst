.. _tutorials:

Tutorials
=========

This part of the documentation guides you through all of the library's
usage patterns.

.. toctree::
   :numbered:

   usage.ipynb
   ratioing.ipynb
   flat_bg_dask.ipynb
   dev_xr_hvplot_holoviews.ipynb
