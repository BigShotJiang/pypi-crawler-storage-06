|pypi| |actions| |codecov| |downloads|


edc-microscopy
--------------
Microscopy model mixins in clinicedc/edc projects


.. |pypi| image:: https://img.shields.io/pypi/v/edc-microscopy.svg
    :target: https://pypi.python.org/pypi/edc-microscopy

.. |actions| image:: https://github.com/clinicedc/edc-microscopy/actions/workflows/build.yml/badge.svg
  :target: https://github.com/clinicedc/edc-microscopy/actions/workflows/build.yml

.. |codecov| image:: https://codecov.io/gh/clinicedc/edc-microscopy/branch/develop/graph/badge.svg
  :target: https://codecov.io/gh/clinicedc/edc-microscopy

.. |downloads| image:: https://pepy.tech/badge/edc-microscopy
   :target: https://pepy.tech/project/edc-microscopy
