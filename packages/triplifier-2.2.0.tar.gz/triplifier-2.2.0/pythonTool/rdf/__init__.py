"""RDF utilities for Python Triplifier."""
