"""AI prompts package."""

from .research_instructions_prompt import full_research_instructions_prompt

__all__ = [
    "full_research_instructions_prompt",
]
