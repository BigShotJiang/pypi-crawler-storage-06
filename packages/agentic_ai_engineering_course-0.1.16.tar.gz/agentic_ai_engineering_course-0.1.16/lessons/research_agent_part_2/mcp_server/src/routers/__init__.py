"""MCP routers for endpoint registration."""
