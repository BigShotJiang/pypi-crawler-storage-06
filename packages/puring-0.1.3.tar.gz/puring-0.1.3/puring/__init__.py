"""

Turing machine emulator.
"""

from .index import *