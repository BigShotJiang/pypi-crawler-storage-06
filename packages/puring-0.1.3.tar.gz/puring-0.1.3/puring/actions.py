"""Turing machine actions."""

L = "LEFT"
R = "RIGHT"
N = "NONE"
S = "STOP"