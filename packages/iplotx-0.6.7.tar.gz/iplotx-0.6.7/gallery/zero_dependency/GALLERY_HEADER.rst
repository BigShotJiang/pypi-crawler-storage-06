Zero-dependency
+++++++++++++++
``iplotx`` provides simple network and tree data structures to visualise networks and trees without
external dependencies beyond ``matplotlib`` and ``pandas``.
