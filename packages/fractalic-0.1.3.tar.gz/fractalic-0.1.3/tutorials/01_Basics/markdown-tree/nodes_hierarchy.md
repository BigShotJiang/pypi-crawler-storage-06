# Tree root node
Tree root node content

## Nested block 1
Sun is ...

### Sub-block 1
Earth is ...

### Sub-block 2
Moon is ...

# Nested block 2
Lorem ipsumi :)

@llm
prompt: |
  Replace "..." in every block with
  proper object type, one word/
  Do not change headings
block: nested-block-1/*
use-header: none
mode: replace
to: nested-block-1/*