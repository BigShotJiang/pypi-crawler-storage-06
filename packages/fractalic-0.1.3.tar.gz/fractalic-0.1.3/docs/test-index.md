# Welcome to Fractalic Documentation

This is a test page to verify VitePress is working correctly.

## Quick Navigation

- [Introduction](./introduction.md)
- [Quick Start](./quick-start.md)
- [Core Concepts](./core-concepts.md)

## Test

If you can see this page, VitePress is working correctly.
