# RTE API
This project is intended to be an unofficial and barebones implementation of a python client for the [RTE API](https://data.rte-france.com/). Not
all endpoints have been implemented and pull requests are welcome. Please see the [license](License.txt) for more information.