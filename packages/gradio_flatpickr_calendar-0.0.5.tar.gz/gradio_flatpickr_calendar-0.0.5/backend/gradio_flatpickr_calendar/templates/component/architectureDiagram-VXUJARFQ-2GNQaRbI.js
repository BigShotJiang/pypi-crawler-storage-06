import { _ as dt, H as ke, V as Ze, l as Re, b as qe, a as Qe, p as Je, q as Ke, g as je, s as _e, y as tr, D as er, E as rr, F as ir, c as ye, ak as Ee, aI as ve, i as ar, d as nr, x as or, aJ as sr, aK as hr } from "./mermaid.core-C8Sj0WRA.js";
import { p as lr } from "./chunk-4BX2VUAB-BmTMa99_.js";
import { p as fr } from "./treemap-75Q7IDZK-D3aGan3q.js";
import { c as Se } from "./cytoscape.esm-ZmItrg9y.js";
import { c as me, g as cr } from "./Index-Dxzk1Xy0.js";
var Fe = { exports: {} }, ue = { exports: {} }, de = { exports: {} }, we;
function gr() {
  return we || (we = 1, function(I, D) {
    (function(P, N) {
      I.exports = N();
    })(me, function() {
      return (
        /******/
        function(A) {
          var P = {};
          function N(u) {
            if (P[u])
              return P[u].exports;
            var h = P[u] = {
              /******/
              i: u,
              /******/
              l: !1,
              /******/
              exports: {}
              /******/
            };
            return A[u].call(h.exports, h, h.exports, N), h.l = !0, h.exports;
          }
          return N.m = A, N.c = P, N.i = function(u) {
            return u;
          }, N.d = function(u, h, a) {
            N.o(u, h) || Object.defineProperty(u, h, {
              /******/
              configurable: !1,
              /******/
              enumerable: !0,
              /******/
              get: a
              /******/
            });
          }, N.n = function(u) {
            var h = u && u.__esModule ? (
              /******/
              function() {
                return u.default;
              }
            ) : (
              /******/
              function() {
                return u;
              }
            );
            return N.d(h, "a", h), h;
          }, N.o = function(u, h) {
            return Object.prototype.hasOwnProperty.call(u, h);
          }, N.p = "", N(N.s = 28);
        }([
          /* 0 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.QUALITY = 1, u.DEFAULT_CREATE_BENDS_AS_NEEDED = !1, u.DEFAULT_INCREMENTAL = !1, u.DEFAULT_ANIMATION_ON_LAYOUT = !0, u.DEFAULT_ANIMATION_DURING_LAYOUT = !1, u.DEFAULT_ANIMATION_PERIOD = 50, u.DEFAULT_UNIFORM_LEAF_NODE_SIZES = !1, u.DEFAULT_GRAPH_MARGIN = 15, u.NODE_DIMENSIONS_INCLUDE_LABELS = !1, u.SIMPLE_NODE_SIZE = 40, u.SIMPLE_NODE_HALF_SIZE = u.SIMPLE_NODE_SIZE / 2, u.EMPTY_COMPOUND_NODE_SIZE = 40, u.MIN_EDGE_LENGTH = 1, u.WORLD_BOUNDARY = 1e6, u.INITIAL_WORLD_BOUNDARY = u.WORLD_BOUNDARY / 1e3, u.WORLD_CENTER_X = 1200, u.WORLD_CENTER_Y = 900, A.exports = u;
          },
          /* 1 */
          /***/
          function(A, P, N) {
            var u = N(2), h = N(8), a = N(9);
            function r(f, i, g) {
              u.call(this, g), this.isOverlapingSourceAndTarget = !1, this.vGraphObject = g, this.bendpoints = [], this.source = f, this.target = i;
            }
            r.prototype = Object.create(u.prototype);
            for (var e in u)
              r[e] = u[e];
            r.prototype.getSource = function() {
              return this.source;
            }, r.prototype.getTarget = function() {
              return this.target;
            }, r.prototype.isInterGraph = function() {
              return this.isInterGraph;
            }, r.prototype.getLength = function() {
              return this.length;
            }, r.prototype.isOverlapingSourceAndTarget = function() {
              return this.isOverlapingSourceAndTarget;
            }, r.prototype.getBendpoints = function() {
              return this.bendpoints;
            }, r.prototype.getLca = function() {
              return this.lca;
            }, r.prototype.getSourceInLca = function() {
              return this.sourceInLca;
            }, r.prototype.getTargetInLca = function() {
              return this.targetInLca;
            }, r.prototype.getOtherEnd = function(f) {
              if (this.source === f)
                return this.target;
              if (this.target === f)
                return this.source;
              throw "Node is not incident with this edge";
            }, r.prototype.getOtherEndInGraph = function(f, i) {
              for (var g = this.getOtherEnd(f), t = i.getGraphManager().getRoot(); ; ) {
                if (g.getOwner() == i)
                  return g;
                if (g.getOwner() == t)
                  break;
                g = g.getOwner().getParent();
              }
              return null;
            }, r.prototype.updateLength = function() {
              var f = new Array(4);
              this.isOverlapingSourceAndTarget = h.getIntersection(this.target.getRect(), this.source.getRect(), f), this.isOverlapingSourceAndTarget || (this.lengthX = f[0] - f[2], this.lengthY = f[1] - f[3], Math.abs(this.lengthX) < 1 && (this.lengthX = a.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = a.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY));
            }, r.prototype.updateLengthSimple = function() {
              this.lengthX = this.target.getCenterX() - this.source.getCenterX(), this.lengthY = this.target.getCenterY() - this.source.getCenterY(), Math.abs(this.lengthX) < 1 && (this.lengthX = a.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = a.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY);
            }, A.exports = r;
          },
          /* 2 */
          /***/
          function(A, P, N) {
            function u(h) {
              this.vGraphObject = h;
            }
            A.exports = u;
          },
          /* 3 */
          /***/
          function(A, P, N) {
            var u = N(2), h = N(10), a = N(13), r = N(0), e = N(16), f = N(5);
            function i(t, o, s, c) {
              s == null && c == null && (c = o), u.call(this, c), t.graphManager != null && (t = t.graphManager), this.estimatedSize = h.MIN_VALUE, this.inclusionTreeDepth = h.MAX_VALUE, this.vGraphObject = c, this.edges = [], this.graphManager = t, s != null && o != null ? this.rect = new a(o.x, o.y, s.width, s.height) : this.rect = new a();
            }
            i.prototype = Object.create(u.prototype);
            for (var g in u)
              i[g] = u[g];
            i.prototype.getEdges = function() {
              return this.edges;
            }, i.prototype.getChild = function() {
              return this.child;
            }, i.prototype.getOwner = function() {
              return this.owner;
            }, i.prototype.getWidth = function() {
              return this.rect.width;
            }, i.prototype.setWidth = function(t) {
              this.rect.width = t;
            }, i.prototype.getHeight = function() {
              return this.rect.height;
            }, i.prototype.setHeight = function(t) {
              this.rect.height = t;
            }, i.prototype.getCenterX = function() {
              return this.rect.x + this.rect.width / 2;
            }, i.prototype.getCenterY = function() {
              return this.rect.y + this.rect.height / 2;
            }, i.prototype.getCenter = function() {
              return new f(this.rect.x + this.rect.width / 2, this.rect.y + this.rect.height / 2);
            }, i.prototype.getLocation = function() {
              return new f(this.rect.x, this.rect.y);
            }, i.prototype.getRect = function() {
              return this.rect;
            }, i.prototype.getDiagonal = function() {
              return Math.sqrt(this.rect.width * this.rect.width + this.rect.height * this.rect.height);
            }, i.prototype.getHalfTheDiagonal = function() {
              return Math.sqrt(this.rect.height * this.rect.height + this.rect.width * this.rect.width) / 2;
            }, i.prototype.setRect = function(t, o) {
              this.rect.x = t.x, this.rect.y = t.y, this.rect.width = o.width, this.rect.height = o.height;
            }, i.prototype.setCenter = function(t, o) {
              this.rect.x = t - this.rect.width / 2, this.rect.y = o - this.rect.height / 2;
            }, i.prototype.setLocation = function(t, o) {
              this.rect.x = t, this.rect.y = o;
            }, i.prototype.moveBy = function(t, o) {
              this.rect.x += t, this.rect.y += o;
            }, i.prototype.getEdgeListToNode = function(t) {
              var o = [], s = this;
              return s.edges.forEach(function(c) {
                if (c.target == t) {
                  if (c.source != s) throw "Incorrect edge source!";
                  o.push(c);
                }
              }), o;
            }, i.prototype.getEdgesBetween = function(t) {
              var o = [], s = this;
              return s.edges.forEach(function(c) {
                if (!(c.source == s || c.target == s)) throw "Incorrect edge source and/or target";
                (c.target == t || c.source == t) && o.push(c);
              }), o;
            }, i.prototype.getNeighborsList = function() {
              var t = /* @__PURE__ */ new Set(), o = this;
              return o.edges.forEach(function(s) {
                if (s.source == o)
                  t.add(s.target);
                else {
                  if (s.target != o)
                    throw "Incorrect incidency!";
                  t.add(s.source);
                }
              }), t;
            }, i.prototype.withChildren = function() {
              var t = /* @__PURE__ */ new Set(), o, s;
              if (t.add(this), this.child != null)
                for (var c = this.child.getNodes(), l = 0; l < c.length; l++)
                  o = c[l], s = o.withChildren(), s.forEach(function(T) {
                    t.add(T);
                  });
              return t;
            }, i.prototype.getNoOfChildren = function() {
              var t = 0, o;
              if (this.child == null)
                t = 1;
              else
                for (var s = this.child.getNodes(), c = 0; c < s.length; c++)
                  o = s[c], t += o.getNoOfChildren();
              return t == 0 && (t = 1), t;
            }, i.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == h.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, i.prototype.calcEstimatedSize = function() {
              return this.child == null ? this.estimatedSize = (this.rect.width + this.rect.height) / 2 : (this.estimatedSize = this.child.calcEstimatedSize(), this.rect.width = this.estimatedSize, this.rect.height = this.estimatedSize, this.estimatedSize);
            }, i.prototype.scatter = function() {
              var t, o, s = -r.INITIAL_WORLD_BOUNDARY, c = r.INITIAL_WORLD_BOUNDARY;
              t = r.WORLD_CENTER_X + e.nextDouble() * (c - s) + s;
              var l = -r.INITIAL_WORLD_BOUNDARY, T = r.INITIAL_WORLD_BOUNDARY;
              o = r.WORLD_CENTER_Y + e.nextDouble() * (T - l) + l, this.rect.x = t, this.rect.y = o;
            }, i.prototype.updateBounds = function() {
              if (this.getChild() == null)
                throw "assert failed";
              if (this.getChild().getNodes().length != 0) {
                var t = this.getChild();
                if (t.updateBounds(!0), this.rect.x = t.getLeft(), this.rect.y = t.getTop(), this.setWidth(t.getRight() - t.getLeft()), this.setHeight(t.getBottom() - t.getTop()), r.NODE_DIMENSIONS_INCLUDE_LABELS) {
                  var o = t.getRight() - t.getLeft(), s = t.getBottom() - t.getTop();
                  this.labelWidth && (this.labelPosHorizontal == "left" ? (this.rect.x -= this.labelWidth, this.setWidth(o + this.labelWidth)) : this.labelPosHorizontal == "center" && this.labelWidth > o ? (this.rect.x -= (this.labelWidth - o) / 2, this.setWidth(this.labelWidth)) : this.labelPosHorizontal == "right" && this.setWidth(o + this.labelWidth)), this.labelHeight && (this.labelPosVertical == "top" ? (this.rect.y -= this.labelHeight, this.setHeight(s + this.labelHeight)) : this.labelPosVertical == "center" && this.labelHeight > s ? (this.rect.y -= (this.labelHeight - s) / 2, this.setHeight(this.labelHeight)) : this.labelPosVertical == "bottom" && this.setHeight(s + this.labelHeight));
                }
              }
            }, i.prototype.getInclusionTreeDepth = function() {
              if (this.inclusionTreeDepth == h.MAX_VALUE)
                throw "assert failed";
              return this.inclusionTreeDepth;
            }, i.prototype.transform = function(t) {
              var o = this.rect.x;
              o > r.WORLD_BOUNDARY ? o = r.WORLD_BOUNDARY : o < -r.WORLD_BOUNDARY && (o = -r.WORLD_BOUNDARY);
              var s = this.rect.y;
              s > r.WORLD_BOUNDARY ? s = r.WORLD_BOUNDARY : s < -r.WORLD_BOUNDARY && (s = -r.WORLD_BOUNDARY);
              var c = new f(o, s), l = t.inverseTransformPoint(c);
              this.setLocation(l.x, l.y);
            }, i.prototype.getLeft = function() {
              return this.rect.x;
            }, i.prototype.getRight = function() {
              return this.rect.x + this.rect.width;
            }, i.prototype.getTop = function() {
              return this.rect.y;
            }, i.prototype.getBottom = function() {
              return this.rect.y + this.rect.height;
            }, i.prototype.getParent = function() {
              return this.owner == null ? null : this.owner.getParent();
            }, A.exports = i;
          },
          /* 4 */
          /***/
          function(A, P, N) {
            var u = N(0);
            function h() {
            }
            for (var a in u)
              h[a] = u[a];
            h.MAX_ITERATIONS = 2500, h.DEFAULT_EDGE_LENGTH = 50, h.DEFAULT_SPRING_STRENGTH = 0.45, h.DEFAULT_REPULSION_STRENGTH = 4500, h.DEFAULT_GRAVITY_STRENGTH = 0.4, h.DEFAULT_COMPOUND_GRAVITY_STRENGTH = 1, h.DEFAULT_GRAVITY_RANGE_FACTOR = 3.8, h.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = 1.5, h.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION = !0, h.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION = !0, h.DEFAULT_COOLING_FACTOR_INCREMENTAL = 0.3, h.COOLING_ADAPTATION_FACTOR = 0.33, h.ADAPTATION_LOWER_NODE_LIMIT = 1e3, h.ADAPTATION_UPPER_NODE_LIMIT = 5e3, h.MAX_NODE_DISPLACEMENT_INCREMENTAL = 100, h.MAX_NODE_DISPLACEMENT = h.MAX_NODE_DISPLACEMENT_INCREMENTAL * 3, h.MIN_REPULSION_DIST = h.DEFAULT_EDGE_LENGTH / 10, h.CONVERGENCE_CHECK_PERIOD = 100, h.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = 0.1, h.MIN_EDGE_LENGTH = 1, h.GRID_CALCULATION_CHECK_PERIOD = 10, A.exports = h;
          },
          /* 5 */
          /***/
          function(A, P, N) {
            function u(h, a) {
              h == null && a == null ? (this.x = 0, this.y = 0) : (this.x = h, this.y = a);
            }
            u.prototype.getX = function() {
              return this.x;
            }, u.prototype.getY = function() {
              return this.y;
            }, u.prototype.setX = function(h) {
              this.x = h;
            }, u.prototype.setY = function(h) {
              this.y = h;
            }, u.prototype.getDifference = function(h) {
              return new DimensionD(this.x - h.x, this.y - h.y);
            }, u.prototype.getCopy = function() {
              return new u(this.x, this.y);
            }, u.prototype.translate = function(h) {
              return this.x += h.width, this.y += h.height, this;
            }, A.exports = u;
          },
          /* 6 */
          /***/
          function(A, P, N) {
            var u = N(2), h = N(10), a = N(0), r = N(7), e = N(3), f = N(1), i = N(13), g = N(12), t = N(11);
            function o(c, l, T) {
              u.call(this, T), this.estimatedSize = h.MIN_VALUE, this.margin = a.DEFAULT_GRAPH_MARGIN, this.edges = [], this.nodes = [], this.isConnected = !1, this.parent = c, l != null && l instanceof r ? this.graphManager = l : l != null && l instanceof Layout && (this.graphManager = l.graphManager);
            }
            o.prototype = Object.create(u.prototype);
            for (var s in u)
              o[s] = u[s];
            o.prototype.getNodes = function() {
              return this.nodes;
            }, o.prototype.getEdges = function() {
              return this.edges;
            }, o.prototype.getGraphManager = function() {
              return this.graphManager;
            }, o.prototype.getParent = function() {
              return this.parent;
            }, o.prototype.getLeft = function() {
              return this.left;
            }, o.prototype.getRight = function() {
              return this.right;
            }, o.prototype.getTop = function() {
              return this.top;
            }, o.prototype.getBottom = function() {
              return this.bottom;
            }, o.prototype.isConnected = function() {
              return this.isConnected;
            }, o.prototype.add = function(c, l, T) {
              if (l == null && T == null) {
                var d = c;
                if (this.graphManager == null)
                  throw "Graph has no graph mgr!";
                if (this.getNodes().indexOf(d) > -1)
                  throw "Node already in graph!";
                return d.owner = this, this.getNodes().push(d), d;
              } else {
                var v = c;
                if (!(this.getNodes().indexOf(l) > -1 && this.getNodes().indexOf(T) > -1))
                  throw "Source or target not in graph!";
                if (!(l.owner == T.owner && l.owner == this))
                  throw "Both owners must be this graph!";
                return l.owner != T.owner ? null : (v.source = l, v.target = T, v.isInterGraph = !1, this.getEdges().push(v), l.edges.push(v), T != l && T.edges.push(v), v);
              }
            }, o.prototype.remove = function(c) {
              var l = c;
              if (c instanceof e) {
                if (l == null)
                  throw "Node is null!";
                if (!(l.owner != null && l.owner == this))
                  throw "Owner graph is invalid!";
                if (this.graphManager == null)
                  throw "Owner graph manager is invalid!";
                for (var T = l.edges.slice(), d, v = T.length, L = 0; L < v; L++)
                  d = T[L], d.isInterGraph ? this.graphManager.remove(d) : d.source.owner.remove(d);
                var S = this.nodes.indexOf(l);
                if (S == -1)
                  throw "Node not in owner node list!";
                this.nodes.splice(S, 1);
              } else if (c instanceof f) {
                var d = c;
                if (d == null)
                  throw "Edge is null!";
                if (!(d.source != null && d.target != null))
                  throw "Source and/or target is null!";
                if (!(d.source.owner != null && d.target.owner != null && d.source.owner == this && d.target.owner == this))
                  throw "Source and/or target owner is invalid!";
                var C = d.source.edges.indexOf(d), G = d.target.edges.indexOf(d);
                if (!(C > -1 && G > -1))
                  throw "Source and/or target doesn't know this edge!";
                d.source.edges.splice(C, 1), d.target != d.source && d.target.edges.splice(G, 1);
                var S = d.source.owner.getEdges().indexOf(d);
                if (S == -1)
                  throw "Not in owner's edge list!";
                d.source.owner.getEdges().splice(S, 1);
              }
            }, o.prototype.updateLeftTop = function() {
              for (var c = h.MAX_VALUE, l = h.MAX_VALUE, T, d, v, L = this.getNodes(), S = L.length, C = 0; C < S; C++) {
                var G = L[C];
                T = G.getTop(), d = G.getLeft(), c > T && (c = T), l > d && (l = d);
              }
              return c == h.MAX_VALUE ? null : (L[0].getParent().paddingLeft != null ? v = L[0].getParent().paddingLeft : v = this.margin, this.left = l - v, this.top = c - v, new g(this.left, this.top));
            }, o.prototype.updateBounds = function(c) {
              for (var l = h.MAX_VALUE, T = -h.MAX_VALUE, d = h.MAX_VALUE, v = -h.MAX_VALUE, L, S, C, G, K, X = this.nodes, Q = X.length, O = 0; O < Q; O++) {
                var rt = X[O];
                c && rt.child != null && rt.updateBounds(), L = rt.getLeft(), S = rt.getRight(), C = rt.getTop(), G = rt.getBottom(), l > L && (l = L), T < S && (T = S), d > C && (d = C), v < G && (v = G);
              }
              var n = new i(l, d, T - l, v - d);
              l == h.MAX_VALUE && (this.left = this.parent.getLeft(), this.right = this.parent.getRight(), this.top = this.parent.getTop(), this.bottom = this.parent.getBottom()), X[0].getParent().paddingLeft != null ? K = X[0].getParent().paddingLeft : K = this.margin, this.left = n.x - K, this.right = n.x + n.width + K, this.top = n.y - K, this.bottom = n.y + n.height + K;
            }, o.calculateBounds = function(c) {
              for (var l = h.MAX_VALUE, T = -h.MAX_VALUE, d = h.MAX_VALUE, v = -h.MAX_VALUE, L, S, C, G, K = c.length, X = 0; X < K; X++) {
                var Q = c[X];
                L = Q.getLeft(), S = Q.getRight(), C = Q.getTop(), G = Q.getBottom(), l > L && (l = L), T < S && (T = S), d > C && (d = C), v < G && (v = G);
              }
              var O = new i(l, d, T - l, v - d);
              return O;
            }, o.prototype.getInclusionTreeDepth = function() {
              return this == this.graphManager.getRoot() ? 1 : this.parent.getInclusionTreeDepth();
            }, o.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == h.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, o.prototype.calcEstimatedSize = function() {
              for (var c = 0, l = this.nodes, T = l.length, d = 0; d < T; d++) {
                var v = l[d];
                c += v.calcEstimatedSize();
              }
              return c == 0 ? this.estimatedSize = a.EMPTY_COMPOUND_NODE_SIZE : this.estimatedSize = c / Math.sqrt(this.nodes.length), this.estimatedSize;
            }, o.prototype.updateConnected = function() {
              var c = this;
              if (this.nodes.length == 0) {
                this.isConnected = !0;
                return;
              }
              var l = new t(), T = /* @__PURE__ */ new Set(), d = this.nodes[0], v, L, S = d.withChildren();
              for (S.forEach(function(O) {
                l.push(O), T.add(O);
              }); l.length !== 0; ) {
                d = l.shift(), v = d.getEdges();
                for (var C = v.length, G = 0; G < C; G++) {
                  var K = v[G];
                  if (L = K.getOtherEndInGraph(d, this), L != null && !T.has(L)) {
                    var X = L.withChildren();
                    X.forEach(function(O) {
                      l.push(O), T.add(O);
                    });
                  }
                }
              }
              if (this.isConnected = !1, T.size >= this.nodes.length) {
                var Q = 0;
                T.forEach(function(O) {
                  O.owner == c && Q++;
                }), Q == this.nodes.length && (this.isConnected = !0);
              }
            }, A.exports = o;
          },
          /* 7 */
          /***/
          function(A, P, N) {
            var u, h = N(1);
            function a(r) {
              u = N(6), this.layout = r, this.graphs = [], this.edges = [];
            }
            a.prototype.addRoot = function() {
              var r = this.layout.newGraph(), e = this.layout.newNode(null), f = this.add(r, e);
              return this.setRootGraph(f), this.rootGraph;
            }, a.prototype.add = function(r, e, f, i, g) {
              if (f == null && i == null && g == null) {
                if (r == null)
                  throw "Graph is null!";
                if (e == null)
                  throw "Parent node is null!";
                if (this.graphs.indexOf(r) > -1)
                  throw "Graph already in this graph mgr!";
                if (this.graphs.push(r), r.parent != null)
                  throw "Already has a parent!";
                if (e.child != null)
                  throw "Already has a child!";
                return r.parent = e, e.child = r, r;
              } else {
                g = f, i = e, f = r;
                var t = i.getOwner(), o = g.getOwner();
                if (!(t != null && t.getGraphManager() == this))
                  throw "Source not in this graph mgr!";
                if (!(o != null && o.getGraphManager() == this))
                  throw "Target not in this graph mgr!";
                if (t == o)
                  return f.isInterGraph = !1, t.add(f, i, g);
                if (f.isInterGraph = !0, f.source = i, f.target = g, this.edges.indexOf(f) > -1)
                  throw "Edge already in inter-graph edge list!";
                if (this.edges.push(f), !(f.source != null && f.target != null))
                  throw "Edge source and/or target is null!";
                if (!(f.source.edges.indexOf(f) == -1 && f.target.edges.indexOf(f) == -1))
                  throw "Edge already in source and/or target incidency list!";
                return f.source.edges.push(f), f.target.edges.push(f), f;
              }
            }, a.prototype.remove = function(r) {
              if (r instanceof u) {
                var e = r;
                if (e.getGraphManager() != this)
                  throw "Graph not in this graph mgr";
                if (!(e == this.rootGraph || e.parent != null && e.parent.graphManager == this))
                  throw "Invalid parent node!";
                var f = [];
                f = f.concat(e.getEdges());
                for (var i, g = f.length, t = 0; t < g; t++)
                  i = f[t], e.remove(i);
                var o = [];
                o = o.concat(e.getNodes());
                var s;
                g = o.length;
                for (var t = 0; t < g; t++)
                  s = o[t], e.remove(s);
                e == this.rootGraph && this.setRootGraph(null);
                var c = this.graphs.indexOf(e);
                this.graphs.splice(c, 1), e.parent = null;
              } else if (r instanceof h) {
                if (i = r, i == null)
                  throw "Edge is null!";
                if (!i.isInterGraph)
                  throw "Not an inter-graph edge!";
                if (!(i.source != null && i.target != null))
                  throw "Source and/or target is null!";
                if (!(i.source.edges.indexOf(i) != -1 && i.target.edges.indexOf(i) != -1))
                  throw "Source and/or target doesn't know this edge!";
                var c = i.source.edges.indexOf(i);
                if (i.source.edges.splice(c, 1), c = i.target.edges.indexOf(i), i.target.edges.splice(c, 1), !(i.source.owner != null && i.source.owner.getGraphManager() != null))
                  throw "Edge owner graph or owner graph manager is null!";
                if (i.source.owner.getGraphManager().edges.indexOf(i) == -1)
                  throw "Not in owner graph manager's edge list!";
                var c = i.source.owner.getGraphManager().edges.indexOf(i);
                i.source.owner.getGraphManager().edges.splice(c, 1);
              }
            }, a.prototype.updateBounds = function() {
              this.rootGraph.updateBounds(!0);
            }, a.prototype.getGraphs = function() {
              return this.graphs;
            }, a.prototype.getAllNodes = function() {
              if (this.allNodes == null) {
                for (var r = [], e = this.getGraphs(), f = e.length, i = 0; i < f; i++)
                  r = r.concat(e[i].getNodes());
                this.allNodes = r;
              }
              return this.allNodes;
            }, a.prototype.resetAllNodes = function() {
              this.allNodes = null;
            }, a.prototype.resetAllEdges = function() {
              this.allEdges = null;
            }, a.prototype.resetAllNodesToApplyGravitation = function() {
              this.allNodesToApplyGravitation = null;
            }, a.prototype.getAllEdges = function() {
              if (this.allEdges == null) {
                var r = [], e = this.getGraphs();
                e.length;
                for (var f = 0; f < e.length; f++)
                  r = r.concat(e[f].getEdges());
                r = r.concat(this.edges), this.allEdges = r;
              }
              return this.allEdges;
            }, a.prototype.getAllNodesToApplyGravitation = function() {
              return this.allNodesToApplyGravitation;
            }, a.prototype.setAllNodesToApplyGravitation = function(r) {
              if (this.allNodesToApplyGravitation != null)
                throw "assert failed";
              this.allNodesToApplyGravitation = r;
            }, a.prototype.getRoot = function() {
              return this.rootGraph;
            }, a.prototype.setRootGraph = function(r) {
              if (r.getGraphManager() != this)
                throw "Root not in this graph mgr!";
              this.rootGraph = r, r.parent == null && (r.parent = this.layout.newNode("Root node"));
            }, a.prototype.getLayout = function() {
              return this.layout;
            }, a.prototype.isOneAncestorOfOther = function(r, e) {
              if (!(r != null && e != null))
                throw "assert failed";
              if (r == e)
                return !0;
              var f = r.getOwner(), i;
              do {
                if (i = f.getParent(), i == null)
                  break;
                if (i == e)
                  return !0;
                if (f = i.getOwner(), f == null)
                  break;
              } while (!0);
              f = e.getOwner();
              do {
                if (i = f.getParent(), i == null)
                  break;
                if (i == r)
                  return !0;
                if (f = i.getOwner(), f == null)
                  break;
              } while (!0);
              return !1;
            }, a.prototype.calcLowestCommonAncestors = function() {
              for (var r, e, f, i, g, t = this.getAllEdges(), o = t.length, s = 0; s < o; s++) {
                if (r = t[s], e = r.source, f = r.target, r.lca = null, r.sourceInLca = e, r.targetInLca = f, e == f) {
                  r.lca = e.getOwner();
                  continue;
                }
                for (i = e.getOwner(); r.lca == null; ) {
                  for (r.targetInLca = f, g = f.getOwner(); r.lca == null; ) {
                    if (g == i) {
                      r.lca = g;
                      break;
                    }
                    if (g == this.rootGraph)
                      break;
                    if (r.lca != null)
                      throw "assert failed";
                    r.targetInLca = g.getParent(), g = r.targetInLca.getOwner();
                  }
                  if (i == this.rootGraph)
                    break;
                  r.lca == null && (r.sourceInLca = i.getParent(), i = r.sourceInLca.getOwner());
                }
                if (r.lca == null)
                  throw "assert failed";
              }
            }, a.prototype.calcLowestCommonAncestor = function(r, e) {
              if (r == e)
                return r.getOwner();
              var f = r.getOwner();
              do {
                if (f == null)
                  break;
                var i = e.getOwner();
                do {
                  if (i == null)
                    break;
                  if (i == f)
                    return i;
                  i = i.getParent().getOwner();
                } while (!0);
                f = f.getParent().getOwner();
              } while (!0);
              return f;
            }, a.prototype.calcInclusionTreeDepths = function(r, e) {
              r == null && e == null && (r = this.rootGraph, e = 1);
              for (var f, i = r.getNodes(), g = i.length, t = 0; t < g; t++)
                f = i[t], f.inclusionTreeDepth = e, f.child != null && this.calcInclusionTreeDepths(f.child, e + 1);
            }, a.prototype.includesInvalidEdge = function() {
              for (var r, e = [], f = this.edges.length, i = 0; i < f; i++)
                r = this.edges[i], this.isOneAncestorOfOther(r.source, r.target) && e.push(r);
              for (var i = 0; i < e.length; i++)
                this.remove(e[i]);
              return !1;
            }, A.exports = a;
          },
          /* 8 */
          /***/
          function(A, P, N) {
            var u = N(12);
            function h() {
            }
            h.calcSeparationAmount = function(a, r, e, f) {
              if (!a.intersects(r))
                throw "assert failed";
              var i = new Array(2);
              this.decideDirectionsForOverlappingNodes(a, r, i), e[0] = Math.min(a.getRight(), r.getRight()) - Math.max(a.x, r.x), e[1] = Math.min(a.getBottom(), r.getBottom()) - Math.max(a.y, r.y), a.getX() <= r.getX() && a.getRight() >= r.getRight() ? e[0] += Math.min(r.getX() - a.getX(), a.getRight() - r.getRight()) : r.getX() <= a.getX() && r.getRight() >= a.getRight() && (e[0] += Math.min(a.getX() - r.getX(), r.getRight() - a.getRight())), a.getY() <= r.getY() && a.getBottom() >= r.getBottom() ? e[1] += Math.min(r.getY() - a.getY(), a.getBottom() - r.getBottom()) : r.getY() <= a.getY() && r.getBottom() >= a.getBottom() && (e[1] += Math.min(a.getY() - r.getY(), r.getBottom() - a.getBottom()));
              var g = Math.abs((r.getCenterY() - a.getCenterY()) / (r.getCenterX() - a.getCenterX()));
              r.getCenterY() === a.getCenterY() && r.getCenterX() === a.getCenterX() && (g = 1);
              var t = g * e[0], o = e[1] / g;
              e[0] < o ? o = e[0] : t = e[1], e[0] = -1 * i[0] * (o / 2 + f), e[1] = -1 * i[1] * (t / 2 + f);
            }, h.decideDirectionsForOverlappingNodes = function(a, r, e) {
              a.getCenterX() < r.getCenterX() ? e[0] = -1 : e[0] = 1, a.getCenterY() < r.getCenterY() ? e[1] = -1 : e[1] = 1;
            }, h.getIntersection2 = function(a, r, e) {
              var f = a.getCenterX(), i = a.getCenterY(), g = r.getCenterX(), t = r.getCenterY();
              if (a.intersects(r))
                return e[0] = f, e[1] = i, e[2] = g, e[3] = t, !0;
              var o = a.getX(), s = a.getY(), c = a.getRight(), l = a.getX(), T = a.getBottom(), d = a.getRight(), v = a.getWidthHalf(), L = a.getHeightHalf(), S = r.getX(), C = r.getY(), G = r.getRight(), K = r.getX(), X = r.getBottom(), Q = r.getRight(), O = r.getWidthHalf(), rt = r.getHeightHalf(), n = !1, m = !1;
              if (f === g) {
                if (i > t)
                  return e[0] = f, e[1] = s, e[2] = g, e[3] = X, !1;
                if (i < t)
                  return e[0] = f, e[1] = T, e[2] = g, e[3] = C, !1;
              } else if (i === t) {
                if (f > g)
                  return e[0] = o, e[1] = i, e[2] = G, e[3] = t, !1;
                if (f < g)
                  return e[0] = c, e[1] = i, e[2] = S, e[3] = t, !1;
              } else {
                var p = a.height / a.width, E = r.height / r.width, y = (t - i) / (g - f), R = void 0, M = void 0, F = void 0, W = void 0, x = void 0, Z = void 0;
                if (-p === y ? f > g ? (e[0] = l, e[1] = T, n = !0) : (e[0] = c, e[1] = s, n = !0) : p === y && (f > g ? (e[0] = o, e[1] = s, n = !0) : (e[0] = d, e[1] = T, n = !0)), -E === y ? g > f ? (e[2] = K, e[3] = X, m = !0) : (e[2] = G, e[3] = C, m = !0) : E === y && (g > f ? (e[2] = S, e[3] = C, m = !0) : (e[2] = Q, e[3] = X, m = !0)), n && m)
                  return !1;
                if (f > g ? i > t ? (R = this.getCardinalDirection(p, y, 4), M = this.getCardinalDirection(E, y, 2)) : (R = this.getCardinalDirection(-p, y, 3), M = this.getCardinalDirection(-E, y, 1)) : i > t ? (R = this.getCardinalDirection(-p, y, 1), M = this.getCardinalDirection(-E, y, 3)) : (R = this.getCardinalDirection(p, y, 2), M = this.getCardinalDirection(E, y, 4)), !n)
                  switch (R) {
                    case 1:
                      W = s, F = f + -L / y, e[0] = F, e[1] = W;
                      break;
                    case 2:
                      F = d, W = i + v * y, e[0] = F, e[1] = W;
                      break;
                    case 3:
                      W = T, F = f + L / y, e[0] = F, e[1] = W;
                      break;
                    case 4:
                      F = l, W = i + -v * y, e[0] = F, e[1] = W;
                      break;
                  }
                if (!m)
                  switch (M) {
                    case 1:
                      Z = C, x = g + -rt / y, e[2] = x, e[3] = Z;
                      break;
                    case 2:
                      x = Q, Z = t + O * y, e[2] = x, e[3] = Z;
                      break;
                    case 3:
                      Z = X, x = g + rt / y, e[2] = x, e[3] = Z;
                      break;
                    case 4:
                      x = K, Z = t + -O * y, e[2] = x, e[3] = Z;
                      break;
                  }
              }
              return !1;
            }, h.getCardinalDirection = function(a, r, e) {
              return a > r ? e : 1 + e % 4;
            }, h.getIntersection = function(a, r, e, f) {
              if (f == null)
                return this.getIntersection2(a, r, e);
              var i = a.x, g = a.y, t = r.x, o = r.y, s = e.x, c = e.y, l = f.x, T = f.y, d = void 0, v = void 0, L = void 0, S = void 0, C = void 0, G = void 0, K = void 0, X = void 0, Q = void 0;
              return L = o - g, C = i - t, K = t * g - i * o, S = T - c, G = s - l, X = l * c - s * T, Q = L * G - S * C, Q === 0 ? null : (d = (C * X - G * K) / Q, v = (S * K - L * X) / Q, new u(d, v));
            }, h.angleOfVector = function(a, r, e, f) {
              var i = void 0;
              return a !== e ? (i = Math.atan((f - r) / (e - a)), e < a ? i += Math.PI : f < r && (i += this.TWO_PI)) : f < r ? i = this.ONE_AND_HALF_PI : i = this.HALF_PI, i;
            }, h.doIntersect = function(a, r, e, f) {
              var i = a.x, g = a.y, t = r.x, o = r.y, s = e.x, c = e.y, l = f.x, T = f.y, d = (t - i) * (T - c) - (l - s) * (o - g);
              if (d === 0)
                return !1;
              var v = ((T - c) * (l - i) + (s - l) * (T - g)) / d, L = ((g - o) * (l - i) + (t - i) * (T - g)) / d;
              return 0 < v && v < 1 && 0 < L && L < 1;
            }, h.findCircleLineIntersections = function(a, r, e, f, i, g, t) {
              var o = (e - a) * (e - a) + (f - r) * (f - r), s = 2 * ((a - i) * (e - a) + (r - g) * (f - r)), c = (a - i) * (a - i) + (r - g) * (r - g) - t * t, l = s * s - 4 * o * c;
              if (l >= 0) {
                var T = (-s + Math.sqrt(s * s - 4 * o * c)) / (2 * o), d = (-s - Math.sqrt(s * s - 4 * o * c)) / (2 * o), v = null;
                return T >= 0 && T <= 1 ? [T] : d >= 0 && d <= 1 ? [d] : v;
              } else return null;
            }, h.HALF_PI = 0.5 * Math.PI, h.ONE_AND_HALF_PI = 1.5 * Math.PI, h.TWO_PI = 2 * Math.PI, h.THREE_PI = 3 * Math.PI, A.exports = h;
          },
          /* 9 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.sign = function(h) {
              return h > 0 ? 1 : h < 0 ? -1 : 0;
            }, u.floor = function(h) {
              return h < 0 ? Math.ceil(h) : Math.floor(h);
            }, u.ceil = function(h) {
              return h < 0 ? Math.floor(h) : Math.ceil(h);
            }, A.exports = u;
          },
          /* 10 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.MAX_VALUE = 2147483647, u.MIN_VALUE = -2147483648, A.exports = u;
          },
          /* 11 */
          /***/
          function(A, P, N) {
            var u = /* @__PURE__ */ function() {
              function i(g, t) {
                for (var o = 0; o < t.length; o++) {
                  var s = t[o];
                  s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(g, s.key, s);
                }
              }
              return function(g, t, o) {
                return t && i(g.prototype, t), o && i(g, o), g;
              };
            }();
            function h(i, g) {
              if (!(i instanceof g))
                throw new TypeError("Cannot call a class as a function");
            }
            var a = function(g) {
              return { value: g, next: null, prev: null };
            }, r = function(g, t, o, s) {
              return g !== null ? g.next = t : s.head = t, o !== null ? o.prev = t : s.tail = t, t.prev = g, t.next = o, s.length++, t;
            }, e = function(g, t) {
              var o = g.prev, s = g.next;
              return o !== null ? o.next = s : t.head = s, s !== null ? s.prev = o : t.tail = o, g.prev = g.next = null, t.length--, g;
            }, f = function() {
              function i(g) {
                var t = this;
                h(this, i), this.length = 0, this.head = null, this.tail = null, g != null && g.forEach(function(o) {
                  return t.push(o);
                });
              }
              return u(i, [{
                key: "size",
                value: function() {
                  return this.length;
                }
              }, {
                key: "insertBefore",
                value: function(t, o) {
                  return r(o.prev, a(t), o, this);
                }
              }, {
                key: "insertAfter",
                value: function(t, o) {
                  return r(o, a(t), o.next, this);
                }
              }, {
                key: "insertNodeBefore",
                value: function(t, o) {
                  return r(o.prev, t, o, this);
                }
              }, {
                key: "insertNodeAfter",
                value: function(t, o) {
                  return r(o, t, o.next, this);
                }
              }, {
                key: "push",
                value: function(t) {
                  return r(this.tail, a(t), null, this);
                }
              }, {
                key: "unshift",
                value: function(t) {
                  return r(null, a(t), this.head, this);
                }
              }, {
                key: "remove",
                value: function(t) {
                  return e(t, this);
                }
              }, {
                key: "pop",
                value: function() {
                  return e(this.tail, this).value;
                }
              }, {
                key: "popNode",
                value: function() {
                  return e(this.tail, this);
                }
              }, {
                key: "shift",
                value: function() {
                  return e(this.head, this).value;
                }
              }, {
                key: "shiftNode",
                value: function() {
                  return e(this.head, this);
                }
              }, {
                key: "get_object_at",
                value: function(t) {
                  if (t <= this.length()) {
                    for (var o = 1, s = this.head; o < t; )
                      s = s.next, o++;
                    return s.value;
                  }
                }
              }, {
                key: "set_object_at",
                value: function(t, o) {
                  if (t <= this.length()) {
                    for (var s = 1, c = this.head; s < t; )
                      c = c.next, s++;
                    c.value = o;
                  }
                }
              }]), i;
            }();
            A.exports = f;
          },
          /* 12 */
          /***/
          function(A, P, N) {
            function u(h, a, r) {
              this.x = null, this.y = null, h == null && a == null && r == null ? (this.x = 0, this.y = 0) : typeof h == "number" && typeof a == "number" && r == null ? (this.x = h, this.y = a) : h.constructor.name == "Point" && a == null && r == null && (r = h, this.x = r.x, this.y = r.y);
            }
            u.prototype.getX = function() {
              return this.x;
            }, u.prototype.getY = function() {
              return this.y;
            }, u.prototype.getLocation = function() {
              return new u(this.x, this.y);
            }, u.prototype.setLocation = function(h, a, r) {
              h.constructor.name == "Point" && a == null && r == null ? (r = h, this.setLocation(r.x, r.y)) : typeof h == "number" && typeof a == "number" && r == null && (parseInt(h) == h && parseInt(a) == a ? this.move(h, a) : (this.x = Math.floor(h + 0.5), this.y = Math.floor(a + 0.5)));
            }, u.prototype.move = function(h, a) {
              this.x = h, this.y = a;
            }, u.prototype.translate = function(h, a) {
              this.x += h, this.y += a;
            }, u.prototype.equals = function(h) {
              if (h.constructor.name == "Point") {
                var a = h;
                return this.x == a.x && this.y == a.y;
              }
              return this == h;
            }, u.prototype.toString = function() {
              return new u().constructor.name + "[x=" + this.x + ",y=" + this.y + "]";
            }, A.exports = u;
          },
          /* 13 */
          /***/
          function(A, P, N) {
            function u(h, a, r, e) {
              this.x = 0, this.y = 0, this.width = 0, this.height = 0, h != null && a != null && r != null && e != null && (this.x = h, this.y = a, this.width = r, this.height = e);
            }
            u.prototype.getX = function() {
              return this.x;
            }, u.prototype.setX = function(h) {
              this.x = h;
            }, u.prototype.getY = function() {
              return this.y;
            }, u.prototype.setY = function(h) {
              this.y = h;
            }, u.prototype.getWidth = function() {
              return this.width;
            }, u.prototype.setWidth = function(h) {
              this.width = h;
            }, u.prototype.getHeight = function() {
              return this.height;
            }, u.prototype.setHeight = function(h) {
              this.height = h;
            }, u.prototype.getRight = function() {
              return this.x + this.width;
            }, u.prototype.getBottom = function() {
              return this.y + this.height;
            }, u.prototype.intersects = function(h) {
              return !(this.getRight() < h.x || this.getBottom() < h.y || h.getRight() < this.x || h.getBottom() < this.y);
            }, u.prototype.getCenterX = function() {
              return this.x + this.width / 2;
            }, u.prototype.getMinX = function() {
              return this.getX();
            }, u.prototype.getMaxX = function() {
              return this.getX() + this.width;
            }, u.prototype.getCenterY = function() {
              return this.y + this.height / 2;
            }, u.prototype.getMinY = function() {
              return this.getY();
            }, u.prototype.getMaxY = function() {
              return this.getY() + this.height;
            }, u.prototype.getWidthHalf = function() {
              return this.width / 2;
            }, u.prototype.getHeightHalf = function() {
              return this.height / 2;
            }, A.exports = u;
          },
          /* 14 */
          /***/
          function(A, P, N) {
            var u = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(a) {
              return typeof a;
            } : function(a) {
              return a && typeof Symbol == "function" && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a;
            };
            function h() {
            }
            h.lastID = 0, h.createID = function(a) {
              return h.isPrimitive(a) ? a : (a.uniqueID != null || (a.uniqueID = h.getString(), h.lastID++), a.uniqueID);
            }, h.getString = function(a) {
              return a == null && (a = h.lastID), "Object#" + a;
            }, h.isPrimitive = function(a) {
              var r = typeof a > "u" ? "undefined" : u(a);
              return a == null || r != "object" && r != "function";
            }, A.exports = h;
          },
          /* 15 */
          /***/
          function(A, P, N) {
            function u(s) {
              if (Array.isArray(s)) {
                for (var c = 0, l = Array(s.length); c < s.length; c++)
                  l[c] = s[c];
                return l;
              } else
                return Array.from(s);
            }
            var h = N(0), a = N(7), r = N(3), e = N(1), f = N(6), i = N(5), g = N(17), t = N(29);
            function o(s) {
              t.call(this), this.layoutQuality = h.QUALITY, this.createBendsAsNeeded = h.DEFAULT_CREATE_BENDS_AS_NEEDED, this.incremental = h.DEFAULT_INCREMENTAL, this.animationOnLayout = h.DEFAULT_ANIMATION_ON_LAYOUT, this.animationDuringLayout = h.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = h.DEFAULT_ANIMATION_PERIOD, this.uniformLeafNodeSizes = h.DEFAULT_UNIFORM_LEAF_NODE_SIZES, this.edgeToDummyNodes = /* @__PURE__ */ new Map(), this.graphManager = new a(this), this.isLayoutFinished = !1, this.isSubLayout = !1, this.isRemoteUse = !1, s != null && (this.isRemoteUse = s);
            }
            o.RANDOM_SEED = 1, o.prototype = Object.create(t.prototype), o.prototype.getGraphManager = function() {
              return this.graphManager;
            }, o.prototype.getAllNodes = function() {
              return this.graphManager.getAllNodes();
            }, o.prototype.getAllEdges = function() {
              return this.graphManager.getAllEdges();
            }, o.prototype.getAllNodesToApplyGravitation = function() {
              return this.graphManager.getAllNodesToApplyGravitation();
            }, o.prototype.newGraphManager = function() {
              var s = new a(this);
              return this.graphManager = s, s;
            }, o.prototype.newGraph = function(s) {
              return new f(null, this.graphManager, s);
            }, o.prototype.newNode = function(s) {
              return new r(this.graphManager, s);
            }, o.prototype.newEdge = function(s) {
              return new e(null, null, s);
            }, o.prototype.checkLayoutSuccess = function() {
              return this.graphManager.getRoot() == null || this.graphManager.getRoot().getNodes().length == 0 || this.graphManager.includesInvalidEdge();
            }, o.prototype.runLayout = function() {
              this.isLayoutFinished = !1, this.tilingPreLayout && this.tilingPreLayout(), this.initParameters();
              var s;
              return this.checkLayoutSuccess() ? s = !1 : s = this.layout(), h.ANIMATE === "during" ? !1 : (s && (this.isSubLayout || this.doPostLayout()), this.tilingPostLayout && this.tilingPostLayout(), this.isLayoutFinished = !0, s);
            }, o.prototype.doPostLayout = function() {
              this.incremental || this.transform(), this.update();
            }, o.prototype.update2 = function() {
              if (this.createBendsAsNeeded && (this.createBendpointsFromDummyNodes(), this.graphManager.resetAllEdges()), !this.isRemoteUse) {
                for (var s = this.graphManager.getAllEdges(), c = 0; c < s.length; c++)
                  s[c];
                for (var l = this.graphManager.getRoot().getNodes(), c = 0; c < l.length; c++)
                  l[c];
                this.update(this.graphManager.getRoot());
              }
            }, o.prototype.update = function(s) {
              if (s == null)
                this.update2();
              else if (s instanceof r) {
                var c = s;
                if (c.getChild() != null)
                  for (var l = c.getChild().getNodes(), T = 0; T < l.length; T++)
                    update(l[T]);
                if (c.vGraphObject != null) {
                  var d = c.vGraphObject;
                  d.update(c);
                }
              } else if (s instanceof e) {
                var v = s;
                if (v.vGraphObject != null) {
                  var L = v.vGraphObject;
                  L.update(v);
                }
              } else if (s instanceof f) {
                var S = s;
                if (S.vGraphObject != null) {
                  var C = S.vGraphObject;
                  C.update(S);
                }
              }
            }, o.prototype.initParameters = function() {
              this.isSubLayout || (this.layoutQuality = h.QUALITY, this.animationDuringLayout = h.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = h.DEFAULT_ANIMATION_PERIOD, this.animationOnLayout = h.DEFAULT_ANIMATION_ON_LAYOUT, this.incremental = h.DEFAULT_INCREMENTAL, this.createBendsAsNeeded = h.DEFAULT_CREATE_BENDS_AS_NEEDED, this.uniformLeafNodeSizes = h.DEFAULT_UNIFORM_LEAF_NODE_SIZES), this.animationDuringLayout && (this.animationOnLayout = !1);
            }, o.prototype.transform = function(s) {
              if (s == null)
                this.transform(new i(0, 0));
              else {
                var c = new g(), l = this.graphManager.getRoot().updateLeftTop();
                if (l != null) {
                  c.setWorldOrgX(s.x), c.setWorldOrgY(s.y), c.setDeviceOrgX(l.x), c.setDeviceOrgY(l.y);
                  for (var T = this.getAllNodes(), d, v = 0; v < T.length; v++)
                    d = T[v], d.transform(c);
                }
              }
            }, o.prototype.positionNodesRandomly = function(s) {
              if (s == null)
                this.positionNodesRandomly(this.getGraphManager().getRoot()), this.getGraphManager().getRoot().updateBounds(!0);
              else
                for (var c, l, T = s.getNodes(), d = 0; d < T.length; d++)
                  c = T[d], l = c.getChild(), l == null || l.getNodes().length == 0 ? c.scatter() : (this.positionNodesRandomly(l), c.updateBounds());
            }, o.prototype.getFlatForest = function() {
              for (var s = [], c = !0, l = this.graphManager.getRoot().getNodes(), T = !0, d = 0; d < l.length; d++)
                l[d].getChild() != null && (T = !1);
              if (!T)
                return s;
              var v = /* @__PURE__ */ new Set(), L = [], S = /* @__PURE__ */ new Map(), C = [];
              for (C = C.concat(l); C.length > 0 && c; ) {
                for (L.push(C[0]); L.length > 0 && c; ) {
                  var G = L[0];
                  L.splice(0, 1), v.add(G);
                  for (var K = G.getEdges(), d = 0; d < K.length; d++) {
                    var X = K[d].getOtherEnd(G);
                    if (S.get(G) != X)
                      if (!v.has(X))
                        L.push(X), S.set(X, G);
                      else {
                        c = !1;
                        break;
                      }
                  }
                }
                if (!c)
                  s = [];
                else {
                  var Q = [].concat(u(v));
                  s.push(Q);
                  for (var d = 0; d < Q.length; d++) {
                    var O = Q[d], rt = C.indexOf(O);
                    rt > -1 && C.splice(rt, 1);
                  }
                  v = /* @__PURE__ */ new Set(), S = /* @__PURE__ */ new Map();
                }
              }
              return s;
            }, o.prototype.createDummyNodesForBendpoints = function(s) {
              for (var c = [], l = s.source, T = this.graphManager.calcLowestCommonAncestor(s.source, s.target), d = 0; d < s.bendpoints.length; d++) {
                var v = this.newNode(null);
                v.setRect(new Point(0, 0), new Dimension(1, 1)), T.add(v);
                var L = this.newEdge(null);
                this.graphManager.add(L, l, v), c.add(v), l = v;
              }
              var L = this.newEdge(null);
              return this.graphManager.add(L, l, s.target), this.edgeToDummyNodes.set(s, c), s.isInterGraph() ? this.graphManager.remove(s) : T.remove(s), c;
            }, o.prototype.createBendpointsFromDummyNodes = function() {
              var s = [];
              s = s.concat(this.graphManager.getAllEdges()), s = [].concat(u(this.edgeToDummyNodes.keys())).concat(s);
              for (var c = 0; c < s.length; c++) {
                var l = s[c];
                if (l.bendpoints.length > 0) {
                  for (var T = this.edgeToDummyNodes.get(l), d = 0; d < T.length; d++) {
                    var v = T[d], L = new i(v.getCenterX(), v.getCenterY()), S = l.bendpoints.get(d);
                    S.x = L.x, S.y = L.y, v.getOwner().remove(v);
                  }
                  this.graphManager.add(l, l.source, l.target);
                }
              }
            }, o.transform = function(s, c, l, T) {
              if (l != null && T != null) {
                var d = c;
                if (s <= 50) {
                  var v = c / l;
                  d -= (c - v) / 50 * (50 - s);
                } else {
                  var L = c * T;
                  d += (L - c) / 50 * (s - 50);
                }
                return d;
              } else {
                var S, C;
                return s <= 50 ? (S = 9 * c / 500, C = c / 10) : (S = 9 * c / 50, C = -8 * c), S * s + C;
              }
            }, o.findCenterOfTree = function(s) {
              var c = [];
              c = c.concat(s);
              var l = [], T = /* @__PURE__ */ new Map(), d = !1, v = null;
              (c.length == 1 || c.length == 2) && (d = !0, v = c[0]);
              for (var L = 0; L < c.length; L++) {
                var S = c[L], C = S.getNeighborsList().size;
                T.set(S, S.getNeighborsList().size), C == 1 && l.push(S);
              }
              var G = [];
              for (G = G.concat(l); !d; ) {
                var K = [];
                K = K.concat(G), G = [];
                for (var L = 0; L < c.length; L++) {
                  var S = c[L], X = c.indexOf(S);
                  X >= 0 && c.splice(X, 1);
                  var Q = S.getNeighborsList();
                  Q.forEach(function(n) {
                    if (l.indexOf(n) < 0) {
                      var m = T.get(n), p = m - 1;
                      p == 1 && G.push(n), T.set(n, p);
                    }
                  });
                }
                l = l.concat(G), (c.length == 1 || c.length == 2) && (d = !0, v = c[0]);
              }
              return v;
            }, o.prototype.setGraphManager = function(s) {
              this.graphManager = s;
            }, A.exports = o;
          },
          /* 16 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.seed = 1, u.x = 0, u.nextDouble = function() {
              return u.x = Math.sin(u.seed++) * 1e4, u.x - Math.floor(u.x);
            }, A.exports = u;
          },
          /* 17 */
          /***/
          function(A, P, N) {
            var u = N(5);
            function h(a, r) {
              this.lworldOrgX = 0, this.lworldOrgY = 0, this.ldeviceOrgX = 0, this.ldeviceOrgY = 0, this.lworldExtX = 1, this.lworldExtY = 1, this.ldeviceExtX = 1, this.ldeviceExtY = 1;
            }
            h.prototype.getWorldOrgX = function() {
              return this.lworldOrgX;
            }, h.prototype.setWorldOrgX = function(a) {
              this.lworldOrgX = a;
            }, h.prototype.getWorldOrgY = function() {
              return this.lworldOrgY;
            }, h.prototype.setWorldOrgY = function(a) {
              this.lworldOrgY = a;
            }, h.prototype.getWorldExtX = function() {
              return this.lworldExtX;
            }, h.prototype.setWorldExtX = function(a) {
              this.lworldExtX = a;
            }, h.prototype.getWorldExtY = function() {
              return this.lworldExtY;
            }, h.prototype.setWorldExtY = function(a) {
              this.lworldExtY = a;
            }, h.prototype.getDeviceOrgX = function() {
              return this.ldeviceOrgX;
            }, h.prototype.setDeviceOrgX = function(a) {
              this.ldeviceOrgX = a;
            }, h.prototype.getDeviceOrgY = function() {
              return this.ldeviceOrgY;
            }, h.prototype.setDeviceOrgY = function(a) {
              this.ldeviceOrgY = a;
            }, h.prototype.getDeviceExtX = function() {
              return this.ldeviceExtX;
            }, h.prototype.setDeviceExtX = function(a) {
              this.ldeviceExtX = a;
            }, h.prototype.getDeviceExtY = function() {
              return this.ldeviceExtY;
            }, h.prototype.setDeviceExtY = function(a) {
              this.ldeviceExtY = a;
            }, h.prototype.transformX = function(a) {
              var r = 0, e = this.lworldExtX;
              return e != 0 && (r = this.ldeviceOrgX + (a - this.lworldOrgX) * this.ldeviceExtX / e), r;
            }, h.prototype.transformY = function(a) {
              var r = 0, e = this.lworldExtY;
              return e != 0 && (r = this.ldeviceOrgY + (a - this.lworldOrgY) * this.ldeviceExtY / e), r;
            }, h.prototype.inverseTransformX = function(a) {
              var r = 0, e = this.ldeviceExtX;
              return e != 0 && (r = this.lworldOrgX + (a - this.ldeviceOrgX) * this.lworldExtX / e), r;
            }, h.prototype.inverseTransformY = function(a) {
              var r = 0, e = this.ldeviceExtY;
              return e != 0 && (r = this.lworldOrgY + (a - this.ldeviceOrgY) * this.lworldExtY / e), r;
            }, h.prototype.inverseTransformPoint = function(a) {
              var r = new u(this.inverseTransformX(a.x), this.inverseTransformY(a.y));
              return r;
            }, A.exports = h;
          },
          /* 18 */
          /***/
          function(A, P, N) {
            function u(t) {
              if (Array.isArray(t)) {
                for (var o = 0, s = Array(t.length); o < t.length; o++)
                  s[o] = t[o];
                return s;
              } else
                return Array.from(t);
            }
            var h = N(15), a = N(4), r = N(0), e = N(8), f = N(9);
            function i() {
              h.call(this), this.useSmartIdealEdgeLengthCalculation = a.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.gravityConstant = a.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = a.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = a.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = a.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.displacementThresholdPerNode = 3 * a.DEFAULT_EDGE_LENGTH / 100, this.coolingFactor = a.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.initialCoolingFactor = a.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.totalDisplacement = 0, this.oldTotalDisplacement = 0, this.maxIterations = a.MAX_ITERATIONS;
            }
            i.prototype = Object.create(h.prototype);
            for (var g in h)
              i[g] = h[g];
            i.prototype.initParameters = function() {
              h.prototype.initParameters.call(this, arguments), this.totalIterations = 0, this.notAnimatedIterations = 0, this.useFRGridVariant = a.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION, this.grid = [];
            }, i.prototype.calcIdealEdgeLengths = function() {
              for (var t, o, s, c, l, T, d, v = this.getGraphManager().getAllEdges(), L = 0; L < v.length; L++)
                t = v[L], o = t.idealLength, t.isInterGraph && (c = t.getSource(), l = t.getTarget(), T = t.getSourceInLca().getEstimatedSize(), d = t.getTargetInLca().getEstimatedSize(), this.useSmartIdealEdgeLengthCalculation && (t.idealLength += T + d - 2 * r.SIMPLE_NODE_SIZE), s = t.getLca().getInclusionTreeDepth(), t.idealLength += o * a.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR * (c.getInclusionTreeDepth() + l.getInclusionTreeDepth() - 2 * s));
            }, i.prototype.initSpringEmbedder = function() {
              var t = this.getAllNodes().length;
              this.incremental ? (t > a.ADAPTATION_LOWER_NODE_LIMIT && (this.coolingFactor = Math.max(this.coolingFactor * a.COOLING_ADAPTATION_FACTOR, this.coolingFactor - (t - a.ADAPTATION_LOWER_NODE_LIMIT) / (a.ADAPTATION_UPPER_NODE_LIMIT - a.ADAPTATION_LOWER_NODE_LIMIT) * this.coolingFactor * (1 - a.COOLING_ADAPTATION_FACTOR))), this.maxNodeDisplacement = a.MAX_NODE_DISPLACEMENT_INCREMENTAL) : (t > a.ADAPTATION_LOWER_NODE_LIMIT ? this.coolingFactor = Math.max(a.COOLING_ADAPTATION_FACTOR, 1 - (t - a.ADAPTATION_LOWER_NODE_LIMIT) / (a.ADAPTATION_UPPER_NODE_LIMIT - a.ADAPTATION_LOWER_NODE_LIMIT) * (1 - a.COOLING_ADAPTATION_FACTOR)) : this.coolingFactor = 1, this.initialCoolingFactor = this.coolingFactor, this.maxNodeDisplacement = a.MAX_NODE_DISPLACEMENT), this.maxIterations = Math.max(this.getAllNodes().length * 5, this.maxIterations), this.displacementThresholdPerNode = 3 * a.DEFAULT_EDGE_LENGTH / 100, this.totalDisplacementThreshold = this.displacementThresholdPerNode * this.getAllNodes().length, this.repulsionRange = this.calcRepulsionRange();
            }, i.prototype.calcSpringForces = function() {
              for (var t = this.getAllEdges(), o, s = 0; s < t.length; s++)
                o = t[s], this.calcSpringForce(o, o.idealLength);
            }, i.prototype.calcRepulsionForces = function() {
              var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, s, c, l, T, d = this.getAllNodes(), v;
              if (this.useFRGridVariant)
                for (this.totalIterations % a.GRID_CALCULATION_CHECK_PERIOD == 1 && t && this.updateGrid(), v = /* @__PURE__ */ new Set(), s = 0; s < d.length; s++)
                  l = d[s], this.calculateRepulsionForceOfANode(l, v, t, o), v.add(l);
              else
                for (s = 0; s < d.length; s++)
                  for (l = d[s], c = s + 1; c < d.length; c++)
                    T = d[c], l.getOwner() == T.getOwner() && this.calcRepulsionForce(l, T);
            }, i.prototype.calcGravitationalForces = function() {
              for (var t, o = this.getAllNodesToApplyGravitation(), s = 0; s < o.length; s++)
                t = o[s], this.calcGravitationalForce(t);
            }, i.prototype.moveNodes = function() {
              for (var t = this.getAllNodes(), o, s = 0; s < t.length; s++)
                o = t[s], o.move();
            }, i.prototype.calcSpringForce = function(t, o) {
              var s = t.getSource(), c = t.getTarget(), l, T, d, v;
              if (this.uniformLeafNodeSizes && s.getChild() == null && c.getChild() == null)
                t.updateLengthSimple();
              else if (t.updateLength(), t.isOverlapingSourceAndTarget)
                return;
              l = t.getLength(), l != 0 && (T = t.edgeElasticity * (l - o), d = T * (t.lengthX / l), v = T * (t.lengthY / l), s.springForceX += d, s.springForceY += v, c.springForceX -= d, c.springForceY -= v);
            }, i.prototype.calcRepulsionForce = function(t, o) {
              var s = t.getRect(), c = o.getRect(), l = new Array(2), T = new Array(4), d, v, L, S, C, G, K;
              if (s.intersects(c)) {
                e.calcSeparationAmount(s, c, l, a.DEFAULT_EDGE_LENGTH / 2), G = 2 * l[0], K = 2 * l[1];
                var X = t.noOfChildren * o.noOfChildren / (t.noOfChildren + o.noOfChildren);
                t.repulsionForceX -= X * G, t.repulsionForceY -= X * K, o.repulsionForceX += X * G, o.repulsionForceY += X * K;
              } else
                this.uniformLeafNodeSizes && t.getChild() == null && o.getChild() == null ? (d = c.getCenterX() - s.getCenterX(), v = c.getCenterY() - s.getCenterY()) : (e.getIntersection(s, c, T), d = T[2] - T[0], v = T[3] - T[1]), Math.abs(d) < a.MIN_REPULSION_DIST && (d = f.sign(d) * a.MIN_REPULSION_DIST), Math.abs(v) < a.MIN_REPULSION_DIST && (v = f.sign(v) * a.MIN_REPULSION_DIST), L = d * d + v * v, S = Math.sqrt(L), C = (t.nodeRepulsion / 2 + o.nodeRepulsion / 2) * t.noOfChildren * o.noOfChildren / L, G = C * d / S, K = C * v / S, t.repulsionForceX -= G, t.repulsionForceY -= K, o.repulsionForceX += G, o.repulsionForceY += K;
            }, i.prototype.calcGravitationalForce = function(t) {
              var o, s, c, l, T, d, v, L;
              o = t.getOwner(), s = (o.getRight() + o.getLeft()) / 2, c = (o.getTop() + o.getBottom()) / 2, l = t.getCenterX() - s, T = t.getCenterY() - c, d = Math.abs(l) + t.getWidth() / 2, v = Math.abs(T) + t.getHeight() / 2, t.getOwner() == this.graphManager.getRoot() ? (L = o.getEstimatedSize() * this.gravityRangeFactor, (d > L || v > L) && (t.gravitationForceX = -this.gravityConstant * l, t.gravitationForceY = -this.gravityConstant * T)) : (L = o.getEstimatedSize() * this.compoundGravityRangeFactor, (d > L || v > L) && (t.gravitationForceX = -this.gravityConstant * l * this.compoundGravityConstant, t.gravitationForceY = -this.gravityConstant * T * this.compoundGravityConstant));
            }, i.prototype.isConverged = function() {
              var t, o = !1;
              return this.totalIterations > this.maxIterations / 3 && (o = Math.abs(this.totalDisplacement - this.oldTotalDisplacement) < 2), t = this.totalDisplacement < this.totalDisplacementThreshold, this.oldTotalDisplacement = this.totalDisplacement, t || o;
            }, i.prototype.animate = function() {
              this.animationDuringLayout && !this.isSubLayout && (this.notAnimatedIterations == this.animationPeriod ? (this.update(), this.notAnimatedIterations = 0) : this.notAnimatedIterations++);
            }, i.prototype.calcNoOfChildrenForAllNodes = function() {
              for (var t, o = this.graphManager.getAllNodes(), s = 0; s < o.length; s++)
                t = o[s], t.noOfChildren = t.getNoOfChildren();
            }, i.prototype.calcGrid = function(t) {
              var o = 0, s = 0;
              o = parseInt(Math.ceil((t.getRight() - t.getLeft()) / this.repulsionRange)), s = parseInt(Math.ceil((t.getBottom() - t.getTop()) / this.repulsionRange));
              for (var c = new Array(o), l = 0; l < o; l++)
                c[l] = new Array(s);
              for (var l = 0; l < o; l++)
                for (var T = 0; T < s; T++)
                  c[l][T] = new Array();
              return c;
            }, i.prototype.addNodeToGrid = function(t, o, s) {
              var c = 0, l = 0, T = 0, d = 0;
              c = parseInt(Math.floor((t.getRect().x - o) / this.repulsionRange)), l = parseInt(Math.floor((t.getRect().width + t.getRect().x - o) / this.repulsionRange)), T = parseInt(Math.floor((t.getRect().y - s) / this.repulsionRange)), d = parseInt(Math.floor((t.getRect().height + t.getRect().y - s) / this.repulsionRange));
              for (var v = c; v <= l; v++)
                for (var L = T; L <= d; L++)
                  this.grid[v][L].push(t), t.setGridCoordinates(c, l, T, d);
            }, i.prototype.updateGrid = function() {
              var t, o, s = this.getAllNodes();
              for (this.grid = this.calcGrid(this.graphManager.getRoot()), t = 0; t < s.length; t++)
                o = s[t], this.addNodeToGrid(o, this.graphManager.getRoot().getLeft(), this.graphManager.getRoot().getTop());
            }, i.prototype.calculateRepulsionForceOfANode = function(t, o, s, c) {
              if (this.totalIterations % a.GRID_CALCULATION_CHECK_PERIOD == 1 && s || c) {
                var l = /* @__PURE__ */ new Set();
                t.surrounding = new Array();
                for (var T, d = this.grid, v = t.startX - 1; v < t.finishX + 2; v++)
                  for (var L = t.startY - 1; L < t.finishY + 2; L++)
                    if (!(v < 0 || L < 0 || v >= d.length || L >= d[0].length)) {
                      for (var S = 0; S < d[v][L].length; S++)
                        if (T = d[v][L][S], !(t.getOwner() != T.getOwner() || t == T) && !o.has(T) && !l.has(T)) {
                          var C = Math.abs(t.getCenterX() - T.getCenterX()) - (t.getWidth() / 2 + T.getWidth() / 2), G = Math.abs(t.getCenterY() - T.getCenterY()) - (t.getHeight() / 2 + T.getHeight() / 2);
                          C <= this.repulsionRange && G <= this.repulsionRange && l.add(T);
                        }
                    }
                t.surrounding = [].concat(u(l));
              }
              for (v = 0; v < t.surrounding.length; v++)
                this.calcRepulsionForce(t, t.surrounding[v]);
            }, i.prototype.calcRepulsionRange = function() {
              return 0;
            }, A.exports = i;
          },
          /* 19 */
          /***/
          function(A, P, N) {
            var u = N(1), h = N(4);
            function a(e, f, i) {
              u.call(this, e, f, i), this.idealLength = h.DEFAULT_EDGE_LENGTH, this.edgeElasticity = h.DEFAULT_SPRING_STRENGTH;
            }
            a.prototype = Object.create(u.prototype);
            for (var r in u)
              a[r] = u[r];
            A.exports = a;
          },
          /* 20 */
          /***/
          function(A, P, N) {
            var u = N(3), h = N(4);
            function a(e, f, i, g) {
              u.call(this, e, f, i, g), this.nodeRepulsion = h.DEFAULT_REPULSION_STRENGTH, this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0, this.startX = 0, this.finishX = 0, this.startY = 0, this.finishY = 0, this.surrounding = [];
            }
            a.prototype = Object.create(u.prototype);
            for (var r in u)
              a[r] = u[r];
            a.prototype.setGridCoordinates = function(e, f, i, g) {
              this.startX = e, this.finishX = f, this.startY = i, this.finishY = g;
            }, A.exports = a;
          },
          /* 21 */
          /***/
          function(A, P, N) {
            function u(h, a) {
              this.width = 0, this.height = 0, h !== null && a !== null && (this.height = a, this.width = h);
            }
            u.prototype.getWidth = function() {
              return this.width;
            }, u.prototype.setWidth = function(h) {
              this.width = h;
            }, u.prototype.getHeight = function() {
              return this.height;
            }, u.prototype.setHeight = function(h) {
              this.height = h;
            }, A.exports = u;
          },
          /* 22 */
          /***/
          function(A, P, N) {
            var u = N(14);
            function h() {
              this.map = {}, this.keys = [];
            }
            h.prototype.put = function(a, r) {
              var e = u.createID(a);
              this.contains(e) || (this.map[e] = r, this.keys.push(a));
            }, h.prototype.contains = function(a) {
              return u.createID(a), this.map[a] != null;
            }, h.prototype.get = function(a) {
              var r = u.createID(a);
              return this.map[r];
            }, h.prototype.keySet = function() {
              return this.keys;
            }, A.exports = h;
          },
          /* 23 */
          /***/
          function(A, P, N) {
            var u = N(14);
            function h() {
              this.set = {};
            }
            h.prototype.add = function(a) {
              var r = u.createID(a);
              this.contains(r) || (this.set[r] = a);
            }, h.prototype.remove = function(a) {
              delete this.set[u.createID(a)];
            }, h.prototype.clear = function() {
              this.set = {};
            }, h.prototype.contains = function(a) {
              return this.set[u.createID(a)] == a;
            }, h.prototype.isEmpty = function() {
              return this.size() === 0;
            }, h.prototype.size = function() {
              return Object.keys(this.set).length;
            }, h.prototype.addAllTo = function(a) {
              for (var r = Object.keys(this.set), e = r.length, f = 0; f < e; f++)
                a.push(this.set[r[f]]);
            }, h.prototype.size = function() {
              return Object.keys(this.set).length;
            }, h.prototype.addAll = function(a) {
              for (var r = a.length, e = 0; e < r; e++) {
                var f = a[e];
                this.add(f);
              }
            }, A.exports = h;
          },
          /* 24 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.multMat = function(h, a) {
              for (var r = [], e = 0; e < h.length; e++) {
                r[e] = [];
                for (var f = 0; f < a[0].length; f++) {
                  r[e][f] = 0;
                  for (var i = 0; i < h[0].length; i++)
                    r[e][f] += h[e][i] * a[i][f];
                }
              }
              return r;
            }, u.transpose = function(h) {
              for (var a = [], r = 0; r < h[0].length; r++) {
                a[r] = [];
                for (var e = 0; e < h.length; e++)
                  a[r][e] = h[e][r];
              }
              return a;
            }, u.multCons = function(h, a) {
              for (var r = [], e = 0; e < h.length; e++)
                r[e] = h[e] * a;
              return r;
            }, u.minusOp = function(h, a) {
              for (var r = [], e = 0; e < h.length; e++)
                r[e] = h[e] - a[e];
              return r;
            }, u.dotProduct = function(h, a) {
              for (var r = 0, e = 0; e < h.length; e++)
                r += h[e] * a[e];
              return r;
            }, u.mag = function(h) {
              return Math.sqrt(this.dotProduct(h, h));
            }, u.normalize = function(h) {
              for (var a = [], r = this.mag(h), e = 0; e < h.length; e++)
                a[e] = h[e] / r;
              return a;
            }, u.multGamma = function(h) {
              for (var a = [], r = 0, e = 0; e < h.length; e++)
                r += h[e];
              r *= -1 / h.length;
              for (var f = 0; f < h.length; f++)
                a[f] = r + h[f];
              return a;
            }, u.multL = function(h, a, r) {
              for (var e = [], f = [], i = [], g = 0; g < a[0].length; g++) {
                for (var t = 0, o = 0; o < a.length; o++)
                  t += -0.5 * a[o][g] * h[o];
                f[g] = t;
              }
              for (var s = 0; s < r.length; s++) {
                for (var c = 0, l = 0; l < r.length; l++)
                  c += r[s][l] * f[l];
                i[s] = c;
              }
              for (var T = 0; T < a.length; T++) {
                for (var d = 0, v = 0; v < a[0].length; v++)
                  d += a[T][v] * i[v];
                e[T] = d;
              }
              return e;
            }, A.exports = u;
          },
          /* 25 */
          /***/
          function(A, P, N) {
            var u = /* @__PURE__ */ function() {
              function e(f, i) {
                for (var g = 0; g < i.length; g++) {
                  var t = i[g];
                  t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), Object.defineProperty(f, t.key, t);
                }
              }
              return function(f, i, g) {
                return i && e(f.prototype, i), g && e(f, g), f;
              };
            }();
            function h(e, f) {
              if (!(e instanceof f))
                throw new TypeError("Cannot call a class as a function");
            }
            var a = N(11), r = function() {
              function e(f, i) {
                h(this, e), (i !== null || i !== void 0) && (this.compareFunction = this._defaultCompareFunction);
                var g = void 0;
                f instanceof a ? g = f.size() : g = f.length, this._quicksort(f, 0, g - 1);
              }
              return u(e, [{
                key: "_quicksort",
                value: function(i, g, t) {
                  if (g < t) {
                    var o = this._partition(i, g, t);
                    this._quicksort(i, g, o), this._quicksort(i, o + 1, t);
                  }
                }
              }, {
                key: "_partition",
                value: function(i, g, t) {
                  for (var o = this._get(i, g), s = g, c = t; ; ) {
                    for (; this.compareFunction(o, this._get(i, c)); )
                      c--;
                    for (; this.compareFunction(this._get(i, s), o); )
                      s++;
                    if (s < c)
                      this._swap(i, s, c), s++, c--;
                    else return c;
                  }
                }
              }, {
                key: "_get",
                value: function(i, g) {
                  return i instanceof a ? i.get_object_at(g) : i[g];
                }
              }, {
                key: "_set",
                value: function(i, g, t) {
                  i instanceof a ? i.set_object_at(g, t) : i[g] = t;
                }
              }, {
                key: "_swap",
                value: function(i, g, t) {
                  var o = this._get(i, g);
                  this._set(i, g, this._get(i, t)), this._set(i, t, o);
                }
              }, {
                key: "_defaultCompareFunction",
                value: function(i, g) {
                  return g > i;
                }
              }]), e;
            }();
            A.exports = r;
          },
          /* 26 */
          /***/
          function(A, P, N) {
            function u() {
            }
            u.svd = function(h) {
              this.U = null, this.V = null, this.s = null, this.m = 0, this.n = 0, this.m = h.length, this.n = h[0].length;
              var a = Math.min(this.m, this.n);
              this.s = function(Tt) {
                for (var Ct = []; Tt-- > 0; )
                  Ct.push(0);
                return Ct;
              }(Math.min(this.m + 1, this.n)), this.U = function(Tt) {
                var Ct = function Bt(bt) {
                  if (bt.length == 0)
                    return 0;
                  for (var zt = [], St = 0; St < bt[0]; St++)
                    zt.push(Bt(bt.slice(1)));
                  return zt;
                };
                return Ct(Tt);
              }([this.m, a]), this.V = function(Tt) {
                var Ct = function Bt(bt) {
                  if (bt.length == 0)
                    return 0;
                  for (var zt = [], St = 0; St < bt[0]; St++)
                    zt.push(Bt(bt.slice(1)));
                  return zt;
                };
                return Ct(Tt);
              }([this.n, this.n]);
              for (var r = function(Tt) {
                for (var Ct = []; Tt-- > 0; )
                  Ct.push(0);
                return Ct;
              }(this.n), e = function(Tt) {
                for (var Ct = []; Tt-- > 0; )
                  Ct.push(0);
                return Ct;
              }(this.m), f = !0, i = Math.min(this.m - 1, this.n), g = Math.max(0, Math.min(this.n - 2, this.m)), t = 0; t < Math.max(i, g); t++) {
                if (t < i) {
                  this.s[t] = 0;
                  for (var o = t; o < this.m; o++)
                    this.s[t] = u.hypot(this.s[t], h[o][t]);
                  if (this.s[t] !== 0) {
                    h[t][t] < 0 && (this.s[t] = -this.s[t]);
                    for (var s = t; s < this.m; s++)
                      h[s][t] /= this.s[t];
                    h[t][t] += 1;
                  }
                  this.s[t] = -this.s[t];
                }
                for (var c = t + 1; c < this.n; c++) {
                  if (/* @__PURE__ */ function(Tt, Ct) {
                    return Tt && Ct;
                  }(t < i, this.s[t] !== 0)) {
                    for (var l = 0, T = t; T < this.m; T++)
                      l += h[T][t] * h[T][c];
                    l = -l / h[t][t];
                    for (var d = t; d < this.m; d++)
                      h[d][c] += l * h[d][t];
                  }
                  r[c] = h[t][c];
                }
                if (/* @__PURE__ */ function(Tt, Ct) {
                  return Ct;
                }(f, t < i))
                  for (var v = t; v < this.m; v++)
                    this.U[v][t] = h[v][t];
                if (t < g) {
                  r[t] = 0;
                  for (var L = t + 1; L < this.n; L++)
                    r[t] = u.hypot(r[t], r[L]);
                  if (r[t] !== 0) {
                    r[t + 1] < 0 && (r[t] = -r[t]);
                    for (var S = t + 1; S < this.n; S++)
                      r[S] /= r[t];
                    r[t + 1] += 1;
                  }
                  if (r[t] = -r[t], /* @__PURE__ */ function(Tt, Ct) {
                    return Tt && Ct;
                  }(t + 1 < this.m, r[t] !== 0)) {
                    for (var C = t + 1; C < this.m; C++)
                      e[C] = 0;
                    for (var G = t + 1; G < this.n; G++)
                      for (var K = t + 1; K < this.m; K++)
                        e[K] += r[G] * h[K][G];
                    for (var X = t + 1; X < this.n; X++)
                      for (var Q = -r[X] / r[t + 1], O = t + 1; O < this.m; O++)
                        h[O][X] += Q * e[O];
                  }
                  for (var rt = t + 1; rt < this.n; rt++)
                    this.V[rt][t] = r[rt];
                }
              }
              var n = Math.min(this.n, this.m + 1);
              i < this.n && (this.s[i] = h[i][i]), this.m < n && (this.s[n - 1] = 0), g + 1 < n && (r[g] = h[g][n - 1]), r[n - 1] = 0;
              {
                for (var m = i; m < a; m++) {
                  for (var p = 0; p < this.m; p++)
                    this.U[p][m] = 0;
                  this.U[m][m] = 1;
                }
                for (var E = i - 1; E >= 0; E--)
                  if (this.s[E] !== 0) {
                    for (var y = E + 1; y < a; y++) {
                      for (var R = 0, M = E; M < this.m; M++)
                        R += this.U[M][E] * this.U[M][y];
                      R = -R / this.U[E][E];
                      for (var F = E; F < this.m; F++)
                        this.U[F][y] += R * this.U[F][E];
                    }
                    for (var W = E; W < this.m; W++)
                      this.U[W][E] = -this.U[W][E];
                    this.U[E][E] = 1 + this.U[E][E];
                    for (var x = 0; x < E - 1; x++)
                      this.U[x][E] = 0;
                  } else {
                    for (var Z = 0; Z < this.m; Z++)
                      this.U[Z][E] = 0;
                    this.U[E][E] = 1;
                  }
              }
              for (var V = this.n - 1; V >= 0; V--) {
                if (/* @__PURE__ */ function(Tt, Ct) {
                  return Tt && Ct;
                }(V < g, r[V] !== 0))
                  for (var Y = V + 1; Y < a; Y++) {
                    for (var et = 0, z = V + 1; z < this.n; z++)
                      et += this.V[z][V] * this.V[z][Y];
                    et = -et / this.V[V + 1][V];
                    for (var w = V + 1; w < this.n; w++)
                      this.V[w][Y] += et * this.V[w][V];
                  }
                for (var H = 0; H < this.n; H++)
                  this.V[H][V] = 0;
                this.V[V][V] = 1;
              }
              for (var B = n - 1, _ = Math.pow(2, -52), ht = Math.pow(2, -966); n > 0; ) {
                var q = void 0, It = void 0;
                for (q = n - 2; q >= -1 && q !== -1; q--)
                  if (Math.abs(r[q]) <= ht + _ * (Math.abs(this.s[q]) + Math.abs(this.s[q + 1]))) {
                    r[q] = 0;
                    break;
                  }
                if (q === n - 2)
                  It = 4;
                else {
                  var Nt = void 0;
                  for (Nt = n - 1; Nt >= q && Nt !== q; Nt--) {
                    var vt = (Nt !== n ? Math.abs(r[Nt]) : 0) + (Nt !== q + 1 ? Math.abs(r[Nt - 1]) : 0);
                    if (Math.abs(this.s[Nt]) <= ht + _ * vt) {
                      this.s[Nt] = 0;
                      break;
                    }
                  }
                  Nt === q ? It = 3 : Nt === n - 1 ? It = 1 : (It = 2, q = Nt);
                }
                switch (q++, It) {
                  case 1:
                    {
                      var it = r[n - 2];
                      r[n - 2] = 0;
                      for (var gt = n - 2; gt >= q; gt--) {
                        var mt = u.hypot(this.s[gt], it), At = this.s[gt] / mt, Ot = it / mt;
                        this.s[gt] = mt, gt !== q && (it = -Ot * r[gt - 1], r[gt - 1] = At * r[gt - 1]);
                        for (var Et = 0; Et < this.n; Et++)
                          mt = At * this.V[Et][gt] + Ot * this.V[Et][n - 1], this.V[Et][n - 1] = -Ot * this.V[Et][gt] + At * this.V[Et][n - 1], this.V[Et][gt] = mt;
                      }
                    }
                    break;
                  case 2:
                    {
                      var Dt = r[q - 1];
                      r[q - 1] = 0;
                      for (var Rt = q; Rt < n; Rt++) {
                        var Ht = u.hypot(this.s[Rt], Dt), Ut = this.s[Rt] / Ht, Pt = Dt / Ht;
                        this.s[Rt] = Ht, Dt = -Pt * r[Rt], r[Rt] = Ut * r[Rt];
                        for (var Ft = 0; Ft < this.m; Ft++)
                          Ht = Ut * this.U[Ft][Rt] + Pt * this.U[Ft][q - 1], this.U[Ft][q - 1] = -Pt * this.U[Ft][Rt] + Ut * this.U[Ft][q - 1], this.U[Ft][Rt] = Ht;
                      }
                    }
                    break;
                  case 3:
                    {
                      var Yt = Math.max(Math.max(Math.max(Math.max(Math.abs(this.s[n - 1]), Math.abs(this.s[n - 2])), Math.abs(r[n - 2])), Math.abs(this.s[q])), Math.abs(r[q])), Vt = this.s[n - 1] / Yt, b = this.s[n - 2] / Yt, U = r[n - 2] / Yt, $ = this.s[q] / Yt, J = r[q] / Yt, k = ((b + Vt) * (b - Vt) + U * U) / 2, at = Vt * U * (Vt * U), ct = 0;
                      /* @__PURE__ */ (function(Tt, Ct) {
                        return Tt || Ct;
                      })(k !== 0, at !== 0) && (ct = Math.sqrt(k * k + at), k < 0 && (ct = -ct), ct = at / (k + ct));
                      for (var nt = ($ + Vt) * ($ - Vt) + ct, tt = $ * J, j = q; j < n - 1; j++) {
                        var ut = u.hypot(nt, tt), Mt = nt / ut, pt = tt / ut;
                        j !== q && (r[j - 1] = ut), nt = Mt * this.s[j] + pt * r[j], r[j] = Mt * r[j] - pt * this.s[j], tt = pt * this.s[j + 1], this.s[j + 1] = Mt * this.s[j + 1];
                        for (var xt = 0; xt < this.n; xt++)
                          ut = Mt * this.V[xt][j] + pt * this.V[xt][j + 1], this.V[xt][j + 1] = -pt * this.V[xt][j] + Mt * this.V[xt][j + 1], this.V[xt][j] = ut;
                        if (ut = u.hypot(nt, tt), Mt = nt / ut, pt = tt / ut, this.s[j] = ut, nt = Mt * r[j] + pt * this.s[j + 1], this.s[j + 1] = -pt * r[j] + Mt * this.s[j + 1], tt = pt * r[j + 1], r[j + 1] = Mt * r[j + 1], j < this.m - 1)
                          for (var lt = 0; lt < this.m; lt++)
                            ut = Mt * this.U[lt][j] + pt * this.U[lt][j + 1], this.U[lt][j + 1] = -pt * this.U[lt][j] + Mt * this.U[lt][j + 1], this.U[lt][j] = ut;
                      }
                      r[n - 2] = nt;
                    }
                    break;
                  case 4:
                    {
                      if (this.s[q] <= 0) {
                        this.s[q] = this.s[q] < 0 ? -this.s[q] : 0;
                        for (var ot = 0; ot <= B; ot++)
                          this.V[ot][q] = -this.V[ot][q];
                      }
                      for (; q < B && !(this.s[q] >= this.s[q + 1]); ) {
                        var Lt = this.s[q];
                        if (this.s[q] = this.s[q + 1], this.s[q + 1] = Lt, q < this.n - 1)
                          for (var ft = 0; ft < this.n; ft++)
                            Lt = this.V[ft][q + 1], this.V[ft][q + 1] = this.V[ft][q], this.V[ft][q] = Lt;
                        if (q < this.m - 1)
                          for (var st = 0; st < this.m; st++)
                            Lt = this.U[st][q + 1], this.U[st][q + 1] = this.U[st][q], this.U[st][q] = Lt;
                        q++;
                      }
                      n--;
                    }
                    break;
                }
              }
              var Xt = { U: this.U, V: this.V, S: this.s };
              return Xt;
            }, u.hypot = function(h, a) {
              var r = void 0;
              return Math.abs(h) > Math.abs(a) ? (r = a / h, r = Math.abs(h) * Math.sqrt(1 + r * r)) : a != 0 ? (r = h / a, r = Math.abs(a) * Math.sqrt(1 + r * r)) : r = 0, r;
            }, A.exports = u;
          },
          /* 27 */
          /***/
          function(A, P, N) {
            var u = /* @__PURE__ */ function() {
              function r(e, f) {
                for (var i = 0; i < f.length; i++) {
                  var g = f[i];
                  g.enumerable = g.enumerable || !1, g.configurable = !0, "value" in g && (g.writable = !0), Object.defineProperty(e, g.key, g);
                }
              }
              return function(e, f, i) {
                return f && r(e.prototype, f), i && r(e, i), e;
              };
            }();
            function h(r, e) {
              if (!(r instanceof e))
                throw new TypeError("Cannot call a class as a function");
            }
            var a = function() {
              function r(e, f) {
                var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, g = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : -1, t = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : -1;
                h(this, r), this.sequence1 = e, this.sequence2 = f, this.match_score = i, this.mismatch_penalty = g, this.gap_penalty = t, this.iMax = e.length + 1, this.jMax = f.length + 1, this.grid = new Array(this.iMax);
                for (var o = 0; o < this.iMax; o++) {
                  this.grid[o] = new Array(this.jMax);
                  for (var s = 0; s < this.jMax; s++)
                    this.grid[o][s] = 0;
                }
                this.tracebackGrid = new Array(this.iMax);
                for (var c = 0; c < this.iMax; c++) {
                  this.tracebackGrid[c] = new Array(this.jMax);
                  for (var l = 0; l < this.jMax; l++)
                    this.tracebackGrid[c][l] = [null, null, null];
                }
                this.alignments = [], this.score = -1, this.computeGrids();
              }
              return u(r, [{
                key: "getScore",
                value: function() {
                  return this.score;
                }
              }, {
                key: "getAlignments",
                value: function() {
                  return this.alignments;
                }
                // Main dynamic programming procedure
              }, {
                key: "computeGrids",
                value: function() {
                  for (var f = 1; f < this.jMax; f++)
                    this.grid[0][f] = this.grid[0][f - 1] + this.gap_penalty, this.tracebackGrid[0][f] = [!1, !1, !0];
                  for (var i = 1; i < this.iMax; i++)
                    this.grid[i][0] = this.grid[i - 1][0] + this.gap_penalty, this.tracebackGrid[i][0] = [!1, !0, !1];
                  for (var g = 1; g < this.iMax; g++)
                    for (var t = 1; t < this.jMax; t++) {
                      var o = void 0;
                      this.sequence1[g - 1] === this.sequence2[t - 1] ? o = this.grid[g - 1][t - 1] + this.match_score : o = this.grid[g - 1][t - 1] + this.mismatch_penalty;
                      var s = this.grid[g - 1][t] + this.gap_penalty, c = this.grid[g][t - 1] + this.gap_penalty, l = [o, s, c], T = this.arrayAllMaxIndexes(l);
                      this.grid[g][t] = l[T[0]], this.tracebackGrid[g][t] = [T.includes(0), T.includes(1), T.includes(2)];
                    }
                  this.score = this.grid[this.iMax - 1][this.jMax - 1];
                }
                // Gets all possible valid sequence combinations
              }, {
                key: "alignmentTraceback",
                value: function() {
                  var f = [];
                  for (f.push({
                    pos: [this.sequence1.length, this.sequence2.length],
                    seq1: "",
                    seq2: ""
                  }); f[0]; ) {
                    var i = f[0], g = this.tracebackGrid[i.pos[0]][i.pos[1]];
                    g[0] && f.push({
                      pos: [i.pos[0] - 1, i.pos[1] - 1],
                      seq1: this.sequence1[i.pos[0] - 1] + i.seq1,
                      seq2: this.sequence2[i.pos[1] - 1] + i.seq2
                    }), g[1] && f.push({
                      pos: [i.pos[0] - 1, i.pos[1]],
                      seq1: this.sequence1[i.pos[0] - 1] + i.seq1,
                      seq2: "-" + i.seq2
                    }), g[2] && f.push({
                      pos: [i.pos[0], i.pos[1] - 1],
                      seq1: "-" + i.seq1,
                      seq2: this.sequence2[i.pos[1] - 1] + i.seq2
                    }), i.pos[0] === 0 && i.pos[1] === 0 && this.alignments.push({
                      sequence1: i.seq1,
                      sequence2: i.seq2
                    }), f.shift();
                  }
                  return this.alignments;
                }
                // Helper Functions
              }, {
                key: "getAllIndexes",
                value: function(f, i) {
                  for (var g = [], t = -1; (t = f.indexOf(i, t + 1)) !== -1; )
                    g.push(t);
                  return g;
                }
              }, {
                key: "arrayAllMaxIndexes",
                value: function(f) {
                  return this.getAllIndexes(f, Math.max.apply(null, f));
                }
              }]), r;
            }();
            A.exports = a;
          },
          /* 28 */
          /***/
          function(A, P, N) {
            var u = function() {
            };
            u.FDLayout = N(18), u.FDLayoutConstants = N(4), u.FDLayoutEdge = N(19), u.FDLayoutNode = N(20), u.DimensionD = N(21), u.HashMap = N(22), u.HashSet = N(23), u.IGeometry = N(8), u.IMath = N(9), u.Integer = N(10), u.Point = N(12), u.PointD = N(5), u.RandomSeed = N(16), u.RectangleD = N(13), u.Transform = N(17), u.UniqueIDGeneretor = N(14), u.Quicksort = N(25), u.LinkedList = N(11), u.LGraphObject = N(2), u.LGraph = N(6), u.LEdge = N(1), u.LGraphManager = N(7), u.LNode = N(3), u.Layout = N(15), u.LayoutConstants = N(0), u.NeedlemanWunsch = N(27), u.Matrix = N(24), u.SVD = N(26), A.exports = u;
          },
          /* 29 */
          /***/
          function(A, P, N) {
            function u() {
              this.listeners = [];
            }
            var h = u.prototype;
            h.addListener = function(a, r) {
              this.listeners.push({
                event: a,
                callback: r
              });
            }, h.removeListener = function(a, r) {
              for (var e = this.listeners.length; e >= 0; e--) {
                var f = this.listeners[e];
                f.event === a && f.callback === r && this.listeners.splice(e, 1);
              }
            }, h.emit = function(a, r) {
              for (var e = 0; e < this.listeners.length; e++) {
                var f = this.listeners[e];
                a === f.event && f.callback(r);
              }
            }, A.exports = u;
          }
          /******/
        ])
      );
    });
  }(de)), de.exports;
}
var Oe;
function ur() {
  return Oe || (Oe = 1, function(I, D) {
    (function(P, N) {
      I.exports = N(gr());
    })(me, function(A) {
      return (
        /******/
        (() => {
          var P = {
            /***/
            45: (
              /***/
              (a, r, e) => {
                var f = {};
                f.layoutBase = e(551), f.CoSEConstants = e(806), f.CoSEEdge = e(767), f.CoSEGraph = e(880), f.CoSEGraphManager = e(578), f.CoSELayout = e(765), f.CoSENode = e(991), f.ConstraintHandler = e(902), a.exports = f;
              }
            ),
            /***/
            806: (
              /***/
              (a, r, e) => {
                var f = e(551).FDLayoutConstants;
                function i() {
                }
                for (var g in f)
                  i[g] = f[g];
                i.DEFAULT_USE_MULTI_LEVEL_SCALING = !1, i.DEFAULT_RADIAL_SEPARATION = f.DEFAULT_EDGE_LENGTH, i.DEFAULT_COMPONENT_SEPERATION = 60, i.TILE = !0, i.TILING_PADDING_VERTICAL = 10, i.TILING_PADDING_HORIZONTAL = 10, i.TRANSFORM_ON_CONSTRAINT_HANDLING = !0, i.ENFORCE_CONSTRAINTS = !0, i.APPLY_LAYOUT = !0, i.RELAX_MOVEMENT_ON_CONSTRAINTS = !0, i.TREE_REDUCTION_ON_INCREMENTAL = !0, i.PURE_INCREMENTAL = i.DEFAULT_INCREMENTAL, a.exports = i;
              }
            ),
            /***/
            767: (
              /***/
              (a, r, e) => {
                var f = e(551).FDLayoutEdge;
                function i(t, o, s) {
                  f.call(this, t, o, s);
                }
                i.prototype = Object.create(f.prototype);
                for (var g in f)
                  i[g] = f[g];
                a.exports = i;
              }
            ),
            /***/
            880: (
              /***/
              (a, r, e) => {
                var f = e(551).LGraph;
                function i(t, o, s) {
                  f.call(this, t, o, s);
                }
                i.prototype = Object.create(f.prototype);
                for (var g in f)
                  i[g] = f[g];
                a.exports = i;
              }
            ),
            /***/
            578: (
              /***/
              (a, r, e) => {
                var f = e(551).LGraphManager;
                function i(t) {
                  f.call(this, t);
                }
                i.prototype = Object.create(f.prototype);
                for (var g in f)
                  i[g] = f[g];
                a.exports = i;
              }
            ),
            /***/
            765: (
              /***/
              (a, r, e) => {
                var f = e(551).FDLayout, i = e(578), g = e(880), t = e(991), o = e(767), s = e(806), c = e(902), l = e(551).FDLayoutConstants, T = e(551).LayoutConstants, d = e(551).Point, v = e(551).PointD, L = e(551).DimensionD, S = e(551).Layout, C = e(551).Integer, G = e(551).IGeometry, K = e(551).LGraph, X = e(551).Transform, Q = e(551).LinkedList;
                function O() {
                  f.call(this), this.toBeTiled = {}, this.constraints = {};
                }
                O.prototype = Object.create(f.prototype);
                for (var rt in f)
                  O[rt] = f[rt];
                O.prototype.newGraphManager = function() {
                  var n = new i(this);
                  return this.graphManager = n, n;
                }, O.prototype.newGraph = function(n) {
                  return new g(null, this.graphManager, n);
                }, O.prototype.newNode = function(n) {
                  return new t(this.graphManager, n);
                }, O.prototype.newEdge = function(n) {
                  return new o(null, null, n);
                }, O.prototype.initParameters = function() {
                  f.prototype.initParameters.call(this, arguments), this.isSubLayout || (s.DEFAULT_EDGE_LENGTH < 10 ? this.idealEdgeLength = 10 : this.idealEdgeLength = s.DEFAULT_EDGE_LENGTH, this.useSmartIdealEdgeLengthCalculation = s.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.gravityConstant = l.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = l.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = l.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = l.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.prunedNodesAll = [], this.growTreeIterations = 0, this.afterGrowthIterations = 0, this.isTreeGrowing = !1, this.isGrowthFinished = !1);
                }, O.prototype.initSpringEmbedder = function() {
                  f.prototype.initSpringEmbedder.call(this), this.coolingCycle = 0, this.maxCoolingCycle = this.maxIterations / l.CONVERGENCE_CHECK_PERIOD, this.finalTemperature = 0.04, this.coolingAdjuster = 1;
                }, O.prototype.layout = function() {
                  var n = T.DEFAULT_CREATE_BENDS_AS_NEEDED;
                  return n && (this.createBendpoints(), this.graphManager.resetAllEdges()), this.level = 0, this.classicLayout();
                }, O.prototype.classicLayout = function() {
                  if (this.nodesWithGravity = this.calculateNodesToApplyGravitationTo(), this.graphManager.setAllNodesToApplyGravitation(this.nodesWithGravity), this.calcNoOfChildrenForAllNodes(), this.graphManager.calcLowestCommonAncestors(), this.graphManager.calcInclusionTreeDepths(), this.graphManager.getRoot().calcEstimatedSize(), this.calcIdealEdgeLengths(), this.incremental) {
                    if (s.TREE_REDUCTION_ON_INCREMENTAL) {
                      this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                      var m = new Set(this.getAllNodes()), p = this.nodesWithGravity.filter(function(R) {
                        return m.has(R);
                      });
                      this.graphManager.setAllNodesToApplyGravitation(p);
                    }
                  } else {
                    var n = this.getFlatForest();
                    if (n.length > 0)
                      this.positionNodesRadially(n);
                    else {
                      this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                      var m = new Set(this.getAllNodes()), p = this.nodesWithGravity.filter(function(E) {
                        return m.has(E);
                      });
                      this.graphManager.setAllNodesToApplyGravitation(p), this.positionNodesRandomly();
                    }
                  }
                  return Object.keys(this.constraints).length > 0 && (c.handleConstraints(this), this.initConstraintVariables()), this.initSpringEmbedder(), s.APPLY_LAYOUT && this.runSpringEmbedder(), !0;
                }, O.prototype.tick = function() {
                  if (this.totalIterations++, this.totalIterations === this.maxIterations && !this.isTreeGrowing && !this.isGrowthFinished)
                    if (this.prunedNodesAll.length > 0)
                      this.isTreeGrowing = !0;
                    else
                      return !0;
                  if (this.totalIterations % l.CONVERGENCE_CHECK_PERIOD == 0 && !this.isTreeGrowing && !this.isGrowthFinished) {
                    if (this.isConverged())
                      if (this.prunedNodesAll.length > 0)
                        this.isTreeGrowing = !0;
                      else
                        return !0;
                    this.coolingCycle++, this.layoutQuality == 0 ? this.coolingAdjuster = this.coolingCycle : this.layoutQuality == 1 && (this.coolingAdjuster = this.coolingCycle / 3), this.coolingFactor = Math.max(this.initialCoolingFactor - Math.pow(this.coolingCycle, Math.log(100 * (this.initialCoolingFactor - this.finalTemperature)) / Math.log(this.maxCoolingCycle)) / 100 * this.coolingAdjuster, this.finalTemperature), this.animationPeriod = Math.ceil(this.initialAnimationPeriod * Math.sqrt(this.coolingFactor));
                  }
                  if (this.isTreeGrowing) {
                    if (this.growTreeIterations % 10 == 0)
                      if (this.prunedNodesAll.length > 0) {
                        this.graphManager.updateBounds(), this.updateGrid(), this.growTree(this.prunedNodesAll), this.graphManager.resetAllNodesToApplyGravitation();
                        var n = new Set(this.getAllNodes()), m = this.nodesWithGravity.filter(function(y) {
                          return n.has(y);
                        });
                        this.graphManager.setAllNodesToApplyGravitation(m), this.graphManager.updateBounds(), this.updateGrid(), s.PURE_INCREMENTAL ? this.coolingFactor = l.DEFAULT_COOLING_FACTOR_INCREMENTAL / 2 : this.coolingFactor = l.DEFAULT_COOLING_FACTOR_INCREMENTAL;
                      } else
                        this.isTreeGrowing = !1, this.isGrowthFinished = !0;
                    this.growTreeIterations++;
                  }
                  if (this.isGrowthFinished) {
                    if (this.isConverged())
                      return !0;
                    this.afterGrowthIterations % 10 == 0 && (this.graphManager.updateBounds(), this.updateGrid()), s.PURE_INCREMENTAL ? this.coolingFactor = l.DEFAULT_COOLING_FACTOR_INCREMENTAL / 2 * ((100 - this.afterGrowthIterations) / 100) : this.coolingFactor = l.DEFAULT_COOLING_FACTOR_INCREMENTAL * ((100 - this.afterGrowthIterations) / 100), this.afterGrowthIterations++;
                  }
                  var p = !this.isTreeGrowing && !this.isGrowthFinished, E = this.growTreeIterations % 10 == 1 && this.isTreeGrowing || this.afterGrowthIterations % 10 == 1 && this.isGrowthFinished;
                  return this.totalDisplacement = 0, this.graphManager.updateBounds(), this.calcSpringForces(), this.calcRepulsionForces(p, E), this.calcGravitationalForces(), this.moveNodes(), this.animate(), !1;
                }, O.prototype.getPositionsData = function() {
                  for (var n = this.graphManager.getAllNodes(), m = {}, p = 0; p < n.length; p++) {
                    var E = n[p].rect, y = n[p].id;
                    m[y] = {
                      id: y,
                      x: E.getCenterX(),
                      y: E.getCenterY(),
                      w: E.width,
                      h: E.height
                    };
                  }
                  return m;
                }, O.prototype.runSpringEmbedder = function() {
                  this.initialAnimationPeriod = 25, this.animationPeriod = this.initialAnimationPeriod;
                  var n = !1;
                  if (l.ANIMATE === "during")
                    this.emit("layoutstarted");
                  else {
                    for (; !n; )
                      n = this.tick();
                    this.graphManager.updateBounds();
                  }
                }, O.prototype.moveNodes = function() {
                  for (var n = this.getAllNodes(), m, p = 0; p < n.length; p++)
                    m = n[p], m.calculateDisplacement();
                  Object.keys(this.constraints).length > 0 && this.updateDisplacements();
                  for (var p = 0; p < n.length; p++)
                    m = n[p], m.move();
                }, O.prototype.initConstraintVariables = function() {
                  var n = this;
                  this.idToNodeMap = /* @__PURE__ */ new Map(), this.fixedNodeSet = /* @__PURE__ */ new Set();
                  for (var m = this.graphManager.getAllNodes(), p = 0; p < m.length; p++) {
                    var E = m[p];
                    this.idToNodeMap.set(E.id, E);
                  }
                  var y = function w(H) {
                    for (var B = H.getChild().getNodes(), _, ht = 0, q = 0; q < B.length; q++)
                      _ = B[q], _.getChild() == null ? n.fixedNodeSet.has(_.id) && (ht += 100) : ht += w(_);
                    return ht;
                  };
                  if (this.constraints.fixedNodeConstraint) {
                    this.constraints.fixedNodeConstraint.forEach(function(B) {
                      n.fixedNodeSet.add(B.nodeId);
                    });
                    for (var m = this.graphManager.getAllNodes(), E, p = 0; p < m.length; p++)
                      if (E = m[p], E.getChild() != null) {
                        var R = y(E);
                        R > 0 && (E.fixedNodeWeight = R);
                      }
                  }
                  if (this.constraints.relativePlacementConstraint) {
                    var M = /* @__PURE__ */ new Map(), F = /* @__PURE__ */ new Map();
                    if (this.dummyToNodeForVerticalAlignment = /* @__PURE__ */ new Map(), this.dummyToNodeForHorizontalAlignment = /* @__PURE__ */ new Map(), this.fixedNodesOnHorizontal = /* @__PURE__ */ new Set(), this.fixedNodesOnVertical = /* @__PURE__ */ new Set(), this.fixedNodeSet.forEach(function(w) {
                      n.fixedNodesOnHorizontal.add(w), n.fixedNodesOnVertical.add(w);
                    }), this.constraints.alignmentConstraint) {
                      if (this.constraints.alignmentConstraint.vertical)
                        for (var W = this.constraints.alignmentConstraint.vertical, p = 0; p < W.length; p++)
                          this.dummyToNodeForVerticalAlignment.set("dummy" + p, []), W[p].forEach(function(H) {
                            M.set(H, "dummy" + p), n.dummyToNodeForVerticalAlignment.get("dummy" + p).push(H), n.fixedNodeSet.has(H) && n.fixedNodesOnHorizontal.add("dummy" + p);
                          });
                      if (this.constraints.alignmentConstraint.horizontal)
                        for (var x = this.constraints.alignmentConstraint.horizontal, p = 0; p < x.length; p++)
                          this.dummyToNodeForHorizontalAlignment.set("dummy" + p, []), x[p].forEach(function(H) {
                            F.set(H, "dummy" + p), n.dummyToNodeForHorizontalAlignment.get("dummy" + p).push(H), n.fixedNodeSet.has(H) && n.fixedNodesOnVertical.add("dummy" + p);
                          });
                    }
                    if (s.RELAX_MOVEMENT_ON_CONSTRAINTS)
                      this.shuffle = function(w) {
                        var H, B, _;
                        for (_ = w.length - 1; _ >= 2 * w.length / 3; _--)
                          H = Math.floor(Math.random() * (_ + 1)), B = w[_], w[_] = w[H], w[H] = B;
                        return w;
                      }, this.nodesInRelativeHorizontal = [], this.nodesInRelativeVertical = [], this.nodeToRelativeConstraintMapHorizontal = /* @__PURE__ */ new Map(), this.nodeToRelativeConstraintMapVertical = /* @__PURE__ */ new Map(), this.nodeToTempPositionMapHorizontal = /* @__PURE__ */ new Map(), this.nodeToTempPositionMapVertical = /* @__PURE__ */ new Map(), this.constraints.relativePlacementConstraint.forEach(function(w) {
                        if (w.left) {
                          var H = M.has(w.left) ? M.get(w.left) : w.left, B = M.has(w.right) ? M.get(w.right) : w.right;
                          n.nodesInRelativeHorizontal.includes(H) || (n.nodesInRelativeHorizontal.push(H), n.nodeToRelativeConstraintMapHorizontal.set(H, []), n.dummyToNodeForVerticalAlignment.has(H) ? n.nodeToTempPositionMapHorizontal.set(H, n.idToNodeMap.get(n.dummyToNodeForVerticalAlignment.get(H)[0]).getCenterX()) : n.nodeToTempPositionMapHorizontal.set(H, n.idToNodeMap.get(H).getCenterX())), n.nodesInRelativeHorizontal.includes(B) || (n.nodesInRelativeHorizontal.push(B), n.nodeToRelativeConstraintMapHorizontal.set(B, []), n.dummyToNodeForVerticalAlignment.has(B) ? n.nodeToTempPositionMapHorizontal.set(B, n.idToNodeMap.get(n.dummyToNodeForVerticalAlignment.get(B)[0]).getCenterX()) : n.nodeToTempPositionMapHorizontal.set(B, n.idToNodeMap.get(B).getCenterX())), n.nodeToRelativeConstraintMapHorizontal.get(H).push({ right: B, gap: w.gap }), n.nodeToRelativeConstraintMapHorizontal.get(B).push({ left: H, gap: w.gap });
                        } else {
                          var _ = F.has(w.top) ? F.get(w.top) : w.top, ht = F.has(w.bottom) ? F.get(w.bottom) : w.bottom;
                          n.nodesInRelativeVertical.includes(_) || (n.nodesInRelativeVertical.push(_), n.nodeToRelativeConstraintMapVertical.set(_, []), n.dummyToNodeForHorizontalAlignment.has(_) ? n.nodeToTempPositionMapVertical.set(_, n.idToNodeMap.get(n.dummyToNodeForHorizontalAlignment.get(_)[0]).getCenterY()) : n.nodeToTempPositionMapVertical.set(_, n.idToNodeMap.get(_).getCenterY())), n.nodesInRelativeVertical.includes(ht) || (n.nodesInRelativeVertical.push(ht), n.nodeToRelativeConstraintMapVertical.set(ht, []), n.dummyToNodeForHorizontalAlignment.has(ht) ? n.nodeToTempPositionMapVertical.set(ht, n.idToNodeMap.get(n.dummyToNodeForHorizontalAlignment.get(ht)[0]).getCenterY()) : n.nodeToTempPositionMapVertical.set(ht, n.idToNodeMap.get(ht).getCenterY())), n.nodeToRelativeConstraintMapVertical.get(_).push({ bottom: ht, gap: w.gap }), n.nodeToRelativeConstraintMapVertical.get(ht).push({ top: _, gap: w.gap });
                        }
                      });
                    else {
                      var Z = /* @__PURE__ */ new Map(), V = /* @__PURE__ */ new Map();
                      this.constraints.relativePlacementConstraint.forEach(function(w) {
                        if (w.left) {
                          var H = M.has(w.left) ? M.get(w.left) : w.left, B = M.has(w.right) ? M.get(w.right) : w.right;
                          Z.has(H) ? Z.get(H).push(B) : Z.set(H, [B]), Z.has(B) ? Z.get(B).push(H) : Z.set(B, [H]);
                        } else {
                          var _ = F.has(w.top) ? F.get(w.top) : w.top, ht = F.has(w.bottom) ? F.get(w.bottom) : w.bottom;
                          V.has(_) ? V.get(_).push(ht) : V.set(_, [ht]), V.has(ht) ? V.get(ht).push(_) : V.set(ht, [_]);
                        }
                      });
                      var Y = function(H, B) {
                        var _ = [], ht = [], q = new Q(), It = /* @__PURE__ */ new Set(), Nt = 0;
                        return H.forEach(function(vt, it) {
                          if (!It.has(it)) {
                            _[Nt] = [], ht[Nt] = !1;
                            var gt = it;
                            for (q.push(gt), It.add(gt), _[Nt].push(gt); q.length != 0; ) {
                              gt = q.shift(), B.has(gt) && (ht[Nt] = !0);
                              var mt = H.get(gt);
                              mt.forEach(function(At) {
                                It.has(At) || (q.push(At), It.add(At), _[Nt].push(At));
                              });
                            }
                            Nt++;
                          }
                        }), { components: _, isFixed: ht };
                      }, et = Y(Z, n.fixedNodesOnHorizontal);
                      this.componentsOnHorizontal = et.components, this.fixedComponentsOnHorizontal = et.isFixed;
                      var z = Y(V, n.fixedNodesOnVertical);
                      this.componentsOnVertical = z.components, this.fixedComponentsOnVertical = z.isFixed;
                    }
                  }
                }, O.prototype.updateDisplacements = function() {
                  var n = this;
                  if (this.constraints.fixedNodeConstraint && this.constraints.fixedNodeConstraint.forEach(function(z) {
                    var w = n.idToNodeMap.get(z.nodeId);
                    w.displacementX = 0, w.displacementY = 0;
                  }), this.constraints.alignmentConstraint) {
                    if (this.constraints.alignmentConstraint.vertical)
                      for (var m = this.constraints.alignmentConstraint.vertical, p = 0; p < m.length; p++) {
                        for (var E = 0, y = 0; y < m[p].length; y++) {
                          if (this.fixedNodeSet.has(m[p][y])) {
                            E = 0;
                            break;
                          }
                          E += this.idToNodeMap.get(m[p][y]).displacementX;
                        }
                        for (var R = E / m[p].length, y = 0; y < m[p].length; y++)
                          this.idToNodeMap.get(m[p][y]).displacementX = R;
                      }
                    if (this.constraints.alignmentConstraint.horizontal)
                      for (var M = this.constraints.alignmentConstraint.horizontal, p = 0; p < M.length; p++) {
                        for (var F = 0, y = 0; y < M[p].length; y++) {
                          if (this.fixedNodeSet.has(M[p][y])) {
                            F = 0;
                            break;
                          }
                          F += this.idToNodeMap.get(M[p][y]).displacementY;
                        }
                        for (var W = F / M[p].length, y = 0; y < M[p].length; y++)
                          this.idToNodeMap.get(M[p][y]).displacementY = W;
                      }
                  }
                  if (this.constraints.relativePlacementConstraint)
                    if (s.RELAX_MOVEMENT_ON_CONSTRAINTS)
                      this.totalIterations % 10 == 0 && (this.shuffle(this.nodesInRelativeHorizontal), this.shuffle(this.nodesInRelativeVertical)), this.nodesInRelativeHorizontal.forEach(function(z) {
                        if (!n.fixedNodesOnHorizontal.has(z)) {
                          var w = 0;
                          n.dummyToNodeForVerticalAlignment.has(z) ? w = n.idToNodeMap.get(n.dummyToNodeForVerticalAlignment.get(z)[0]).displacementX : w = n.idToNodeMap.get(z).displacementX, n.nodeToRelativeConstraintMapHorizontal.get(z).forEach(function(H) {
                            if (H.right) {
                              var B = n.nodeToTempPositionMapHorizontal.get(H.right) - n.nodeToTempPositionMapHorizontal.get(z) - w;
                              B < H.gap && (w -= H.gap - B);
                            } else {
                              var B = n.nodeToTempPositionMapHorizontal.get(z) - n.nodeToTempPositionMapHorizontal.get(H.left) + w;
                              B < H.gap && (w += H.gap - B);
                            }
                          }), n.nodeToTempPositionMapHorizontal.set(z, n.nodeToTempPositionMapHorizontal.get(z) + w), n.dummyToNodeForVerticalAlignment.has(z) ? n.dummyToNodeForVerticalAlignment.get(z).forEach(function(H) {
                            n.idToNodeMap.get(H).displacementX = w;
                          }) : n.idToNodeMap.get(z).displacementX = w;
                        }
                      }), this.nodesInRelativeVertical.forEach(function(z) {
                        if (!n.fixedNodesOnHorizontal.has(z)) {
                          var w = 0;
                          n.dummyToNodeForHorizontalAlignment.has(z) ? w = n.idToNodeMap.get(n.dummyToNodeForHorizontalAlignment.get(z)[0]).displacementY : w = n.idToNodeMap.get(z).displacementY, n.nodeToRelativeConstraintMapVertical.get(z).forEach(function(H) {
                            if (H.bottom) {
                              var B = n.nodeToTempPositionMapVertical.get(H.bottom) - n.nodeToTempPositionMapVertical.get(z) - w;
                              B < H.gap && (w -= H.gap - B);
                            } else {
                              var B = n.nodeToTempPositionMapVertical.get(z) - n.nodeToTempPositionMapVertical.get(H.top) + w;
                              B < H.gap && (w += H.gap - B);
                            }
                          }), n.nodeToTempPositionMapVertical.set(z, n.nodeToTempPositionMapVertical.get(z) + w), n.dummyToNodeForHorizontalAlignment.has(z) ? n.dummyToNodeForHorizontalAlignment.get(z).forEach(function(H) {
                            n.idToNodeMap.get(H).displacementY = w;
                          }) : n.idToNodeMap.get(z).displacementY = w;
                        }
                      });
                    else {
                      for (var p = 0; p < this.componentsOnHorizontal.length; p++) {
                        var x = this.componentsOnHorizontal[p];
                        if (this.fixedComponentsOnHorizontal[p])
                          for (var y = 0; y < x.length; y++)
                            this.dummyToNodeForVerticalAlignment.has(x[y]) ? this.dummyToNodeForVerticalAlignment.get(x[y]).forEach(function(H) {
                              n.idToNodeMap.get(H).displacementX = 0;
                            }) : this.idToNodeMap.get(x[y]).displacementX = 0;
                        else {
                          for (var Z = 0, V = 0, y = 0; y < x.length; y++)
                            if (this.dummyToNodeForVerticalAlignment.has(x[y])) {
                              var Y = this.dummyToNodeForVerticalAlignment.get(x[y]);
                              Z += Y.length * this.idToNodeMap.get(Y[0]).displacementX, V += Y.length;
                            } else
                              Z += this.idToNodeMap.get(x[y]).displacementX, V++;
                          for (var et = Z / V, y = 0; y < x.length; y++)
                            this.dummyToNodeForVerticalAlignment.has(x[y]) ? this.dummyToNodeForVerticalAlignment.get(x[y]).forEach(function(H) {
                              n.idToNodeMap.get(H).displacementX = et;
                            }) : this.idToNodeMap.get(x[y]).displacementX = et;
                        }
                      }
                      for (var p = 0; p < this.componentsOnVertical.length; p++) {
                        var x = this.componentsOnVertical[p];
                        if (this.fixedComponentsOnVertical[p])
                          for (var y = 0; y < x.length; y++)
                            this.dummyToNodeForHorizontalAlignment.has(x[y]) ? this.dummyToNodeForHorizontalAlignment.get(x[y]).forEach(function(B) {
                              n.idToNodeMap.get(B).displacementY = 0;
                            }) : this.idToNodeMap.get(x[y]).displacementY = 0;
                        else {
                          for (var Z = 0, V = 0, y = 0; y < x.length; y++)
                            if (this.dummyToNodeForHorizontalAlignment.has(x[y])) {
                              var Y = this.dummyToNodeForHorizontalAlignment.get(x[y]);
                              Z += Y.length * this.idToNodeMap.get(Y[0]).displacementY, V += Y.length;
                            } else
                              Z += this.idToNodeMap.get(x[y]).displacementY, V++;
                          for (var et = Z / V, y = 0; y < x.length; y++)
                            this.dummyToNodeForHorizontalAlignment.has(x[y]) ? this.dummyToNodeForHorizontalAlignment.get(x[y]).forEach(function(q) {
                              n.idToNodeMap.get(q).displacementY = et;
                            }) : this.idToNodeMap.get(x[y]).displacementY = et;
                        }
                      }
                    }
                }, O.prototype.calculateNodesToApplyGravitationTo = function() {
                  var n = [], m, p = this.graphManager.getGraphs(), E = p.length, y;
                  for (y = 0; y < E; y++)
                    m = p[y], m.updateConnected(), m.isConnected || (n = n.concat(m.getNodes()));
                  return n;
                }, O.prototype.createBendpoints = function() {
                  var n = [];
                  n = n.concat(this.graphManager.getAllEdges());
                  var m = /* @__PURE__ */ new Set(), p;
                  for (p = 0; p < n.length; p++) {
                    var E = n[p];
                    if (!m.has(E)) {
                      var y = E.getSource(), R = E.getTarget();
                      if (y == R)
                        E.getBendpoints().push(new v()), E.getBendpoints().push(new v()), this.createDummyNodesForBendpoints(E), m.add(E);
                      else {
                        var M = [];
                        if (M = M.concat(y.getEdgeListToNode(R)), M = M.concat(R.getEdgeListToNode(y)), !m.has(M[0])) {
                          if (M.length > 1) {
                            var F;
                            for (F = 0; F < M.length; F++) {
                              var W = M[F];
                              W.getBendpoints().push(new v()), this.createDummyNodesForBendpoints(W);
                            }
                          }
                          M.forEach(function(x) {
                            m.add(x);
                          });
                        }
                      }
                    }
                    if (m.size == n.length)
                      break;
                  }
                }, O.prototype.positionNodesRadially = function(n) {
                  for (var m = new d(0, 0), p = Math.ceil(Math.sqrt(n.length)), E = 0, y = 0, R = 0, M = new v(0, 0), F = 0; F < n.length; F++) {
                    F % p == 0 && (R = 0, y = E, F != 0 && (y += s.DEFAULT_COMPONENT_SEPERATION), E = 0);
                    var W = n[F], x = S.findCenterOfTree(W);
                    m.x = R, m.y = y, M = O.radialLayout(W, x, m), M.y > E && (E = Math.floor(M.y)), R = Math.floor(M.x + s.DEFAULT_COMPONENT_SEPERATION);
                  }
                  this.transform(new v(T.WORLD_CENTER_X - M.x / 2, T.WORLD_CENTER_Y - M.y / 2));
                }, O.radialLayout = function(n, m, p) {
                  var E = Math.max(this.maxDiagonalInTree(n), s.DEFAULT_RADIAL_SEPARATION);
                  O.branchRadialLayout(m, null, 0, 359, 0, E);
                  var y = K.calculateBounds(n), R = new X();
                  R.setDeviceOrgX(y.getMinX()), R.setDeviceOrgY(y.getMinY()), R.setWorldOrgX(p.x), R.setWorldOrgY(p.y);
                  for (var M = 0; M < n.length; M++) {
                    var F = n[M];
                    F.transform(R);
                  }
                  var W = new v(y.getMaxX(), y.getMaxY());
                  return R.inverseTransformPoint(W);
                }, O.branchRadialLayout = function(n, m, p, E, y, R) {
                  var M = (E - p + 1) / 2;
                  M < 0 && (M += 180);
                  var F = (M + p) % 360, W = F * G.TWO_PI / 360, x = y * Math.cos(W), Z = y * Math.sin(W);
                  n.setCenter(x, Z);
                  var V = [];
                  V = V.concat(n.getEdges());
                  var Y = V.length;
                  m != null && Y--;
                  for (var et = 0, z = V.length, w, H = n.getEdgesBetween(m); H.length > 1; ) {
                    var B = H[0];
                    H.splice(0, 1);
                    var _ = V.indexOf(B);
                    _ >= 0 && V.splice(_, 1), z--, Y--;
                  }
                  m != null ? w = (V.indexOf(H[0]) + 1) % z : w = 0;
                  for (var ht = Math.abs(E - p) / Y, q = w; et != Y; q = ++q % z) {
                    var It = V[q].getOtherEnd(n);
                    if (It != m) {
                      var Nt = (p + et * ht) % 360, vt = (Nt + ht) % 360;
                      O.branchRadialLayout(It, n, Nt, vt, y + R, R), et++;
                    }
                  }
                }, O.maxDiagonalInTree = function(n) {
                  for (var m = C.MIN_VALUE, p = 0; p < n.length; p++) {
                    var E = n[p], y = E.getDiagonal();
                    y > m && (m = y);
                  }
                  return m;
                }, O.prototype.calcRepulsionRange = function() {
                  return 2 * (this.level + 1) * this.idealEdgeLength;
                }, O.prototype.groupZeroDegreeMembers = function() {
                  var n = this, m = {};
                  this.memberGroups = {}, this.idToDummyNode = {};
                  for (var p = [], E = this.graphManager.getAllNodes(), y = 0; y < E.length; y++) {
                    var R = E[y], M = R.getParent();
                    this.getNodeDegreeWithChildren(R) === 0 && (M.id == null || !this.getToBeTiled(M)) && p.push(R);
                  }
                  for (var y = 0; y < p.length; y++) {
                    var R = p[y], F = R.getParent().id;
                    typeof m[F] > "u" && (m[F] = []), m[F] = m[F].concat(R);
                  }
                  Object.keys(m).forEach(function(W) {
                    if (m[W].length > 1) {
                      var x = "DummyCompound_" + W;
                      n.memberGroups[x] = m[W];
                      var Z = m[W][0].getParent(), V = new t(n.graphManager);
                      V.id = x, V.paddingLeft = Z.paddingLeft || 0, V.paddingRight = Z.paddingRight || 0, V.paddingBottom = Z.paddingBottom || 0, V.paddingTop = Z.paddingTop || 0, n.idToDummyNode[x] = V;
                      var Y = n.getGraphManager().add(n.newGraph(), V), et = Z.getChild();
                      et.add(V);
                      for (var z = 0; z < m[W].length; z++) {
                        var w = m[W][z];
                        et.remove(w), Y.add(w);
                      }
                    }
                  });
                }, O.prototype.clearCompounds = function() {
                  var n = {}, m = {};
                  this.performDFSOnCompounds();
                  for (var p = 0; p < this.compoundOrder.length; p++)
                    m[this.compoundOrder[p].id] = this.compoundOrder[p], n[this.compoundOrder[p].id] = [].concat(this.compoundOrder[p].getChild().getNodes()), this.graphManager.remove(this.compoundOrder[p].getChild()), this.compoundOrder[p].child = null;
                  this.graphManager.resetAllNodes(), this.tileCompoundMembers(n, m);
                }, O.prototype.clearZeroDegreeMembers = function() {
                  var n = this, m = this.tiledZeroDegreePack = [];
                  Object.keys(this.memberGroups).forEach(function(p) {
                    var E = n.idToDummyNode[p];
                    if (m[p] = n.tileNodes(n.memberGroups[p], E.paddingLeft + E.paddingRight), E.rect.width = m[p].width, E.rect.height = m[p].height, E.setCenter(m[p].centerX, m[p].centerY), E.labelMarginLeft = 0, E.labelMarginTop = 0, s.NODE_DIMENSIONS_INCLUDE_LABELS) {
                      var y = E.rect.width, R = E.rect.height;
                      E.labelWidth && (E.labelPosHorizontal == "left" ? (E.rect.x -= E.labelWidth, E.setWidth(y + E.labelWidth), E.labelMarginLeft = E.labelWidth) : E.labelPosHorizontal == "center" && E.labelWidth > y ? (E.rect.x -= (E.labelWidth - y) / 2, E.setWidth(E.labelWidth), E.labelMarginLeft = (E.labelWidth - y) / 2) : E.labelPosHorizontal == "right" && E.setWidth(y + E.labelWidth)), E.labelHeight && (E.labelPosVertical == "top" ? (E.rect.y -= E.labelHeight, E.setHeight(R + E.labelHeight), E.labelMarginTop = E.labelHeight) : E.labelPosVertical == "center" && E.labelHeight > R ? (E.rect.y -= (E.labelHeight - R) / 2, E.setHeight(E.labelHeight), E.labelMarginTop = (E.labelHeight - R) / 2) : E.labelPosVertical == "bottom" && E.setHeight(R + E.labelHeight));
                    }
                  });
                }, O.prototype.repopulateCompounds = function() {
                  for (var n = this.compoundOrder.length - 1; n >= 0; n--) {
                    var m = this.compoundOrder[n], p = m.id, E = m.paddingLeft, y = m.paddingTop, R = m.labelMarginLeft, M = m.labelMarginTop;
                    this.adjustLocations(this.tiledMemberPack[p], m.rect.x, m.rect.y, E, y, R, M);
                  }
                }, O.prototype.repopulateZeroDegreeMembers = function() {
                  var n = this, m = this.tiledZeroDegreePack;
                  Object.keys(m).forEach(function(p) {
                    var E = n.idToDummyNode[p], y = E.paddingLeft, R = E.paddingTop, M = E.labelMarginLeft, F = E.labelMarginTop;
                    n.adjustLocations(m[p], E.rect.x, E.rect.y, y, R, M, F);
                  });
                }, O.prototype.getToBeTiled = function(n) {
                  var m = n.id;
                  if (this.toBeTiled[m] != null)
                    return this.toBeTiled[m];
                  var p = n.getChild();
                  if (p == null)
                    return this.toBeTiled[m] = !1, !1;
                  for (var E = p.getNodes(), y = 0; y < E.length; y++) {
                    var R = E[y];
                    if (this.getNodeDegree(R) > 0)
                      return this.toBeTiled[m] = !1, !1;
                    if (R.getChild() == null) {
                      this.toBeTiled[R.id] = !1;
                      continue;
                    }
                    if (!this.getToBeTiled(R))
                      return this.toBeTiled[m] = !1, !1;
                  }
                  return this.toBeTiled[m] = !0, !0;
                }, O.prototype.getNodeDegree = function(n) {
                  n.id;
                  for (var m = n.getEdges(), p = 0, E = 0; E < m.length; E++) {
                    var y = m[E];
                    y.getSource().id !== y.getTarget().id && (p = p + 1);
                  }
                  return p;
                }, O.prototype.getNodeDegreeWithChildren = function(n) {
                  var m = this.getNodeDegree(n);
                  if (n.getChild() == null)
                    return m;
                  for (var p = n.getChild().getNodes(), E = 0; E < p.length; E++) {
                    var y = p[E];
                    m += this.getNodeDegreeWithChildren(y);
                  }
                  return m;
                }, O.prototype.performDFSOnCompounds = function() {
                  this.compoundOrder = [], this.fillCompexOrderByDFS(this.graphManager.getRoot().getNodes());
                }, O.prototype.fillCompexOrderByDFS = function(n) {
                  for (var m = 0; m < n.length; m++) {
                    var p = n[m];
                    p.getChild() != null && this.fillCompexOrderByDFS(p.getChild().getNodes()), this.getToBeTiled(p) && this.compoundOrder.push(p);
                  }
                }, O.prototype.adjustLocations = function(n, m, p, E, y, R, M) {
                  m += E + R, p += y + M;
                  for (var F = m, W = 0; W < n.rows.length; W++) {
                    var x = n.rows[W];
                    m = F;
                    for (var Z = 0, V = 0; V < x.length; V++) {
                      var Y = x[V];
                      Y.rect.x = m, Y.rect.y = p, m += Y.rect.width + n.horizontalPadding, Y.rect.height > Z && (Z = Y.rect.height);
                    }
                    p += Z + n.verticalPadding;
                  }
                }, O.prototype.tileCompoundMembers = function(n, m) {
                  var p = this;
                  this.tiledMemberPack = [], Object.keys(n).forEach(function(E) {
                    var y = m[E];
                    if (p.tiledMemberPack[E] = p.tileNodes(n[E], y.paddingLeft + y.paddingRight), y.rect.width = p.tiledMemberPack[E].width, y.rect.height = p.tiledMemberPack[E].height, y.setCenter(p.tiledMemberPack[E].centerX, p.tiledMemberPack[E].centerY), y.labelMarginLeft = 0, y.labelMarginTop = 0, s.NODE_DIMENSIONS_INCLUDE_LABELS) {
                      var R = y.rect.width, M = y.rect.height;
                      y.labelWidth && (y.labelPosHorizontal == "left" ? (y.rect.x -= y.labelWidth, y.setWidth(R + y.labelWidth), y.labelMarginLeft = y.labelWidth) : y.labelPosHorizontal == "center" && y.labelWidth > R ? (y.rect.x -= (y.labelWidth - R) / 2, y.setWidth(y.labelWidth), y.labelMarginLeft = (y.labelWidth - R) / 2) : y.labelPosHorizontal == "right" && y.setWidth(R + y.labelWidth)), y.labelHeight && (y.labelPosVertical == "top" ? (y.rect.y -= y.labelHeight, y.setHeight(M + y.labelHeight), y.labelMarginTop = y.labelHeight) : y.labelPosVertical == "center" && y.labelHeight > M ? (y.rect.y -= (y.labelHeight - M) / 2, y.setHeight(y.labelHeight), y.labelMarginTop = (y.labelHeight - M) / 2) : y.labelPosVertical == "bottom" && y.setHeight(M + y.labelHeight));
                    }
                  });
                }, O.prototype.tileNodes = function(n, m) {
                  var p = this.tileNodesByFavoringDim(n, m, !0), E = this.tileNodesByFavoringDim(n, m, !1), y = this.getOrgRatio(p), R = this.getOrgRatio(E), M;
                  return R < y ? M = E : M = p, M;
                }, O.prototype.getOrgRatio = function(n) {
                  var m = n.width, p = n.height, E = m / p;
                  return E < 1 && (E = 1 / E), E;
                }, O.prototype.calcIdealRowWidth = function(n, m) {
                  var p = s.TILING_PADDING_VERTICAL, E = s.TILING_PADDING_HORIZONTAL, y = n.length, R = 0, M = 0, F = 0;
                  n.forEach(function(z) {
                    R += z.getWidth(), M += z.getHeight(), z.getWidth() > F && (F = z.getWidth());
                  });
                  var W = R / y, x = M / y, Z = Math.pow(p - E, 2) + 4 * (W + E) * (x + p) * y, V = (E - p + Math.sqrt(Z)) / (2 * (W + E)), Y;
                  m ? (Y = Math.ceil(V), Y == V && Y++) : Y = Math.floor(V);
                  var et = Y * (W + E) - E;
                  return F > et && (et = F), et += E * 2, et;
                }, O.prototype.tileNodesByFavoringDim = function(n, m, p) {
                  var E = s.TILING_PADDING_VERTICAL, y = s.TILING_PADDING_HORIZONTAL, R = s.TILING_COMPARE_BY, M = {
                    rows: [],
                    rowWidth: [],
                    rowHeight: [],
                    width: 0,
                    height: m,
                    // assume minHeight equals to minWidth
                    verticalPadding: E,
                    horizontalPadding: y,
                    centerX: 0,
                    centerY: 0
                  };
                  R && (M.idealRowWidth = this.calcIdealRowWidth(n, p));
                  var F = function(w) {
                    return w.rect.width * w.rect.height;
                  }, W = function(w, H) {
                    return F(H) - F(w);
                  };
                  n.sort(function(z, w) {
                    var H = W;
                    return M.idealRowWidth ? (H = R, H(z.id, w.id)) : H(z, w);
                  });
                  for (var x = 0, Z = 0, V = 0; V < n.length; V++) {
                    var Y = n[V];
                    x += Y.getCenterX(), Z += Y.getCenterY();
                  }
                  M.centerX = x / n.length, M.centerY = Z / n.length;
                  for (var V = 0; V < n.length; V++) {
                    var Y = n[V];
                    if (M.rows.length == 0)
                      this.insertNodeToRow(M, Y, 0, m);
                    else if (this.canAddHorizontal(M, Y.rect.width, Y.rect.height)) {
                      var et = M.rows.length - 1;
                      M.idealRowWidth || (et = this.getShortestRowIndex(M)), this.insertNodeToRow(M, Y, et, m);
                    } else
                      this.insertNodeToRow(M, Y, M.rows.length, m);
                    this.shiftToLastRow(M);
                  }
                  return M;
                }, O.prototype.insertNodeToRow = function(n, m, p, E) {
                  var y = E;
                  if (p == n.rows.length) {
                    var R = [];
                    n.rows.push(R), n.rowWidth.push(y), n.rowHeight.push(0);
                  }
                  var M = n.rowWidth[p] + m.rect.width;
                  n.rows[p].length > 0 && (M += n.horizontalPadding), n.rowWidth[p] = M, n.width < M && (n.width = M);
                  var F = m.rect.height;
                  p > 0 && (F += n.verticalPadding);
                  var W = 0;
                  F > n.rowHeight[p] && (W = n.rowHeight[p], n.rowHeight[p] = F, W = n.rowHeight[p] - W), n.height += W, n.rows[p].push(m);
                }, O.prototype.getShortestRowIndex = function(n) {
                  for (var m = -1, p = Number.MAX_VALUE, E = 0; E < n.rows.length; E++)
                    n.rowWidth[E] < p && (m = E, p = n.rowWidth[E]);
                  return m;
                }, O.prototype.getLongestRowIndex = function(n) {
                  for (var m = -1, p = Number.MIN_VALUE, E = 0; E < n.rows.length; E++)
                    n.rowWidth[E] > p && (m = E, p = n.rowWidth[E]);
                  return m;
                }, O.prototype.canAddHorizontal = function(n, m, p) {
                  if (n.idealRowWidth) {
                    var E = n.rows.length - 1, y = n.rowWidth[E];
                    return y + m + n.horizontalPadding <= n.idealRowWidth;
                  }
                  var R = this.getShortestRowIndex(n);
                  if (R < 0)
                    return !0;
                  var M = n.rowWidth[R];
                  if (M + n.horizontalPadding + m <= n.width) return !0;
                  var F = 0;
                  n.rowHeight[R] < p && R > 0 && (F = p + n.verticalPadding - n.rowHeight[R]);
                  var W;
                  n.width - M >= m + n.horizontalPadding ? W = (n.height + F) / (M + m + n.horizontalPadding) : W = (n.height + F) / n.width, F = p + n.verticalPadding;
                  var x;
                  return n.width < m ? x = (n.height + F) / m : x = (n.height + F) / n.width, x < 1 && (x = 1 / x), W < 1 && (W = 1 / W), W < x;
                }, O.prototype.shiftToLastRow = function(n) {
                  var m = this.getLongestRowIndex(n), p = n.rowWidth.length - 1, E = n.rows[m], y = E[E.length - 1], R = y.width + n.horizontalPadding;
                  if (n.width - n.rowWidth[p] > R && m != p) {
                    E.splice(-1, 1), n.rows[p].push(y), n.rowWidth[m] = n.rowWidth[m] - R, n.rowWidth[p] = n.rowWidth[p] + R, n.width = n.rowWidth[instance.getLongestRowIndex(n)];
                    for (var M = Number.MIN_VALUE, F = 0; F < E.length; F++)
                      E[F].height > M && (M = E[F].height);
                    m > 0 && (M += n.verticalPadding);
                    var W = n.rowHeight[m] + n.rowHeight[p];
                    n.rowHeight[m] = M, n.rowHeight[p] < y.height + n.verticalPadding && (n.rowHeight[p] = y.height + n.verticalPadding);
                    var x = n.rowHeight[m] + n.rowHeight[p];
                    n.height += x - W, this.shiftToLastRow(n);
                  }
                }, O.prototype.tilingPreLayout = function() {
                  s.TILE && (this.groupZeroDegreeMembers(), this.clearCompounds(), this.clearZeroDegreeMembers());
                }, O.prototype.tilingPostLayout = function() {
                  s.TILE && (this.repopulateZeroDegreeMembers(), this.repopulateCompounds());
                }, O.prototype.reduceTrees = function() {
                  for (var n = [], m = !0, p; m; ) {
                    var E = this.graphManager.getAllNodes(), y = [];
                    m = !1;
                    for (var R = 0; R < E.length; R++)
                      if (p = E[R], p.getEdges().length == 1 && !p.getEdges()[0].isInterGraph && p.getChild() == null) {
                        if (s.PURE_INCREMENTAL) {
                          var M = p.getEdges()[0].getOtherEnd(p), F = new L(p.getCenterX() - M.getCenterX(), p.getCenterY() - M.getCenterY());
                          y.push([p, p.getEdges()[0], p.getOwner(), F]);
                        } else
                          y.push([p, p.getEdges()[0], p.getOwner()]);
                        m = !0;
                      }
                    if (m == !0) {
                      for (var W = [], x = 0; x < y.length; x++)
                        y[x][0].getEdges().length == 1 && (W.push(y[x]), y[x][0].getOwner().remove(y[x][0]));
                      n.push(W), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
                    }
                  }
                  this.prunedNodesAll = n;
                }, O.prototype.growTree = function(n) {
                  for (var m = n.length, p = n[m - 1], E, y = 0; y < p.length; y++)
                    E = p[y], this.findPlaceforPrunedNode(E), E[2].add(E[0]), E[2].add(E[1], E[1].source, E[1].target);
                  n.splice(n.length - 1, 1), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
                }, O.prototype.findPlaceforPrunedNode = function(n) {
                  var m, p, E = n[0];
                  if (E == n[1].source ? p = n[1].target : p = n[1].source, s.PURE_INCREMENTAL)
                    E.setCenter(p.getCenterX() + n[3].getWidth(), p.getCenterY() + n[3].getHeight());
                  else {
                    var y = p.startX, R = p.finishX, M = p.startY, F = p.finishY, W = 0, x = 0, Z = 0, V = 0, Y = [W, Z, x, V];
                    if (M > 0)
                      for (var et = y; et <= R; et++)
                        Y[0] += this.grid[et][M - 1].length + this.grid[et][M].length - 1;
                    if (R < this.grid.length - 1)
                      for (var et = M; et <= F; et++)
                        Y[1] += this.grid[R + 1][et].length + this.grid[R][et].length - 1;
                    if (F < this.grid[0].length - 1)
                      for (var et = y; et <= R; et++)
                        Y[2] += this.grid[et][F + 1].length + this.grid[et][F].length - 1;
                    if (y > 0)
                      for (var et = M; et <= F; et++)
                        Y[3] += this.grid[y - 1][et].length + this.grid[y][et].length - 1;
                    for (var z = C.MAX_VALUE, w, H, B = 0; B < Y.length; B++)
                      Y[B] < z ? (z = Y[B], w = 1, H = B) : Y[B] == z && w++;
                    if (w == 3 && z == 0)
                      Y[0] == 0 && Y[1] == 0 && Y[2] == 0 ? m = 1 : Y[0] == 0 && Y[1] == 0 && Y[3] == 0 ? m = 0 : Y[0] == 0 && Y[2] == 0 && Y[3] == 0 ? m = 3 : Y[1] == 0 && Y[2] == 0 && Y[3] == 0 && (m = 2);
                    else if (w == 2 && z == 0) {
                      var _ = Math.floor(Math.random() * 2);
                      Y[0] == 0 && Y[1] == 0 ? _ == 0 ? m = 0 : m = 1 : Y[0] == 0 && Y[2] == 0 ? _ == 0 ? m = 0 : m = 2 : Y[0] == 0 && Y[3] == 0 ? _ == 0 ? m = 0 : m = 3 : Y[1] == 0 && Y[2] == 0 ? _ == 0 ? m = 1 : m = 2 : Y[1] == 0 && Y[3] == 0 ? _ == 0 ? m = 1 : m = 3 : _ == 0 ? m = 2 : m = 3;
                    } else if (w == 4 && z == 0) {
                      var _ = Math.floor(Math.random() * 4);
                      m = _;
                    } else
                      m = H;
                    m == 0 ? E.setCenter(p.getCenterX(), p.getCenterY() - p.getHeight() / 2 - l.DEFAULT_EDGE_LENGTH - E.getHeight() / 2) : m == 1 ? E.setCenter(p.getCenterX() + p.getWidth() / 2 + l.DEFAULT_EDGE_LENGTH + E.getWidth() / 2, p.getCenterY()) : m == 2 ? E.setCenter(p.getCenterX(), p.getCenterY() + p.getHeight() / 2 + l.DEFAULT_EDGE_LENGTH + E.getHeight() / 2) : E.setCenter(p.getCenterX() - p.getWidth() / 2 - l.DEFAULT_EDGE_LENGTH - E.getWidth() / 2, p.getCenterY());
                  }
                }, a.exports = O;
              }
            ),
            /***/
            991: (
              /***/
              (a, r, e) => {
                var f = e(551).FDLayoutNode, i = e(551).IMath;
                function g(o, s, c, l) {
                  f.call(this, o, s, c, l);
                }
                g.prototype = Object.create(f.prototype);
                for (var t in f)
                  g[t] = f[t];
                g.prototype.calculateDisplacement = function() {
                  var o = this.graphManager.getLayout();
                  this.getChild() != null && this.fixedNodeWeight ? (this.displacementX += o.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.fixedNodeWeight, this.displacementY += o.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.fixedNodeWeight) : (this.displacementX += o.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.noOfChildren, this.displacementY += o.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.noOfChildren), Math.abs(this.displacementX) > o.coolingFactor * o.maxNodeDisplacement && (this.displacementX = o.coolingFactor * o.maxNodeDisplacement * i.sign(this.displacementX)), Math.abs(this.displacementY) > o.coolingFactor * o.maxNodeDisplacement && (this.displacementY = o.coolingFactor * o.maxNodeDisplacement * i.sign(this.displacementY)), this.child && this.child.getNodes().length > 0 && this.propogateDisplacementToChildren(this.displacementX, this.displacementY);
                }, g.prototype.propogateDisplacementToChildren = function(o, s) {
                  for (var c = this.getChild().getNodes(), l, T = 0; T < c.length; T++)
                    l = c[T], l.getChild() == null ? (l.displacementX += o, l.displacementY += s) : l.propogateDisplacementToChildren(o, s);
                }, g.prototype.move = function() {
                  var o = this.graphManager.getLayout();
                  (this.child == null || this.child.getNodes().length == 0) && (this.moveBy(this.displacementX, this.displacementY), o.totalDisplacement += Math.abs(this.displacementX) + Math.abs(this.displacementY)), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0;
                }, g.prototype.setPred1 = function(o) {
                  this.pred1 = o;
                }, g.prototype.getPred1 = function() {
                  return pred1;
                }, g.prototype.getPred2 = function() {
                  return pred2;
                }, g.prototype.setNext = function(o) {
                  this.next = o;
                }, g.prototype.getNext = function() {
                  return next;
                }, g.prototype.setProcessed = function(o) {
                  this.processed = o;
                }, g.prototype.isProcessed = function() {
                  return processed;
                }, a.exports = g;
              }
            ),
            /***/
            902: (
              /***/
              (a, r, e) => {
                function f(c) {
                  if (Array.isArray(c)) {
                    for (var l = 0, T = Array(c.length); l < c.length; l++)
                      T[l] = c[l];
                    return T;
                  } else
                    return Array.from(c);
                }
                var i = e(806), g = e(551).LinkedList, t = e(551).Matrix, o = e(551).SVD;
                function s() {
                }
                s.handleConstraints = function(c) {
                  var l = {};
                  l.fixedNodeConstraint = c.constraints.fixedNodeConstraint, l.alignmentConstraint = c.constraints.alignmentConstraint, l.relativePlacementConstraint = c.constraints.relativePlacementConstraint;
                  for (var T = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map(), v = [], L = [], S = c.getAllNodes(), C = 0, G = 0; G < S.length; G++) {
                    var K = S[G];
                    K.getChild() == null && (d.set(K.id, C++), v.push(K.getCenterX()), L.push(K.getCenterY()), T.set(K.id, K));
                  }
                  l.relativePlacementConstraint && l.relativePlacementConstraint.forEach(function(b) {
                    !b.gap && b.gap != 0 && (b.left ? b.gap = i.DEFAULT_EDGE_LENGTH + T.get(b.left).getWidth() / 2 + T.get(b.right).getWidth() / 2 : b.gap = i.DEFAULT_EDGE_LENGTH + T.get(b.top).getHeight() / 2 + T.get(b.bottom).getHeight() / 2);
                  });
                  var X = function(U, $) {
                    return { x: U.x - $.x, y: U.y - $.y };
                  }, Q = function(U) {
                    var $ = 0, J = 0;
                    return U.forEach(function(k) {
                      $ += v[d.get(k)], J += L[d.get(k)];
                    }), { x: $ / U.size, y: J / U.size };
                  }, O = function(U, $, J, k, at) {
                    function ct(lt, ot) {
                      var Lt = new Set(lt), ft = !0, st = !1, Xt = void 0;
                      try {
                        for (var Tt = ot[Symbol.iterator](), Ct; !(ft = (Ct = Tt.next()).done); ft = !0) {
                          var Bt = Ct.value;
                          Lt.add(Bt);
                        }
                      } catch (bt) {
                        st = !0, Xt = bt;
                      } finally {
                        try {
                          !ft && Tt.return && Tt.return();
                        } finally {
                          if (st)
                            throw Xt;
                        }
                      }
                      return Lt;
                    }
                    var nt = /* @__PURE__ */ new Map();
                    U.forEach(function(lt, ot) {
                      nt.set(ot, 0);
                    }), U.forEach(function(lt, ot) {
                      lt.forEach(function(Lt) {
                        nt.set(Lt.id, nt.get(Lt.id) + 1);
                      });
                    });
                    var tt = /* @__PURE__ */ new Map(), j = /* @__PURE__ */ new Map(), ut = new g();
                    nt.forEach(function(lt, ot) {
                      lt == 0 ? (ut.push(ot), J || ($ == "horizontal" ? tt.set(ot, d.has(ot) ? v[d.get(ot)] : k.get(ot)) : tt.set(ot, d.has(ot) ? L[d.get(ot)] : k.get(ot)))) : tt.set(ot, Number.NEGATIVE_INFINITY), J && j.set(ot, /* @__PURE__ */ new Set([ot]));
                    }), J && at.forEach(function(lt) {
                      var ot = [];
                      if (lt.forEach(function(st) {
                        J.has(st) && ot.push(st);
                      }), ot.length > 0) {
                        var Lt = 0;
                        ot.forEach(function(st) {
                          $ == "horizontal" ? (tt.set(st, d.has(st) ? v[d.get(st)] : k.get(st)), Lt += tt.get(st)) : (tt.set(st, d.has(st) ? L[d.get(st)] : k.get(st)), Lt += tt.get(st));
                        }), Lt = Lt / ot.length, lt.forEach(function(st) {
                          J.has(st) || tt.set(st, Lt);
                        });
                      } else {
                        var ft = 0;
                        lt.forEach(function(st) {
                          $ == "horizontal" ? ft += d.has(st) ? v[d.get(st)] : k.get(st) : ft += d.has(st) ? L[d.get(st)] : k.get(st);
                        }), ft = ft / lt.length, lt.forEach(function(st) {
                          tt.set(st, ft);
                        });
                      }
                    });
                    for (var Mt = function() {
                      var ot = ut.shift(), Lt = U.get(ot);
                      Lt.forEach(function(ft) {
                        if (tt.get(ft.id) < tt.get(ot) + ft.gap)
                          if (J && J.has(ft.id)) {
                            var st = void 0;
                            if ($ == "horizontal" ? st = d.has(ft.id) ? v[d.get(ft.id)] : k.get(ft.id) : st = d.has(ft.id) ? L[d.get(ft.id)] : k.get(ft.id), tt.set(ft.id, st), st < tt.get(ot) + ft.gap) {
                              var Xt = tt.get(ot) + ft.gap - st;
                              j.get(ot).forEach(function(Tt) {
                                tt.set(Tt, tt.get(Tt) - Xt);
                              });
                            }
                          } else
                            tt.set(ft.id, tt.get(ot) + ft.gap);
                        nt.set(ft.id, nt.get(ft.id) - 1), nt.get(ft.id) == 0 && ut.push(ft.id), J && j.set(ft.id, ct(j.get(ot), j.get(ft.id)));
                      });
                    }; ut.length != 0; )
                      Mt();
                    if (J) {
                      var pt = /* @__PURE__ */ new Set();
                      U.forEach(function(lt, ot) {
                        lt.length == 0 && pt.add(ot);
                      });
                      var xt = [];
                      j.forEach(function(lt, ot) {
                        if (pt.has(ot)) {
                          var Lt = !1, ft = !0, st = !1, Xt = void 0;
                          try {
                            for (var Tt = lt[Symbol.iterator](), Ct; !(ft = (Ct = Tt.next()).done); ft = !0) {
                              var Bt = Ct.value;
                              J.has(Bt) && (Lt = !0);
                            }
                          } catch (St) {
                            st = !0, Xt = St;
                          } finally {
                            try {
                              !ft && Tt.return && Tt.return();
                            } finally {
                              if (st)
                                throw Xt;
                            }
                          }
                          if (!Lt) {
                            var bt = !1, zt = void 0;
                            xt.forEach(function(St, kt) {
                              St.has([].concat(f(lt))[0]) && (bt = !0, zt = kt);
                            }), bt ? lt.forEach(function(St) {
                              xt[zt].add(St);
                            }) : xt.push(new Set(lt));
                          }
                        }
                      }), xt.forEach(function(lt, ot) {
                        var Lt = Number.POSITIVE_INFINITY, ft = Number.POSITIVE_INFINITY, st = Number.NEGATIVE_INFINITY, Xt = Number.NEGATIVE_INFINITY, Tt = !0, Ct = !1, Bt = void 0;
                        try {
                          for (var bt = lt[Symbol.iterator](), zt; !(Tt = (zt = bt.next()).done); Tt = !0) {
                            var St = zt.value, kt = void 0;
                            $ == "horizontal" ? kt = d.has(St) ? v[d.get(St)] : k.get(St) : kt = d.has(St) ? L[d.get(St)] : k.get(St);
                            var Kt = tt.get(St);
                            kt < Lt && (Lt = kt), kt > st && (st = kt), Kt < ft && (ft = Kt), Kt > Xt && (Xt = Kt);
                          }
                        } catch (ee) {
                          Ct = !0, Bt = ee;
                        } finally {
                          try {
                            !Tt && bt.return && bt.return();
                          } finally {
                            if (Ct)
                              throw Bt;
                          }
                        }
                        var he = (Lt + st) / 2 - (ft + Xt) / 2, Qt = !0, jt = !1, _t = void 0;
                        try {
                          for (var Jt = lt[Symbol.iterator](), oe; !(Qt = (oe = Jt.next()).done); Qt = !0) {
                            var te = oe.value;
                            tt.set(te, tt.get(te) + he);
                          }
                        } catch (ee) {
                          jt = !0, _t = ee;
                        } finally {
                          try {
                            !Qt && Jt.return && Jt.return();
                          } finally {
                            if (jt)
                              throw _t;
                          }
                        }
                      });
                    }
                    return tt;
                  }, rt = function(U) {
                    var $ = 0, J = 0, k = 0, at = 0;
                    if (U.forEach(function(j) {
                      j.left ? v[d.get(j.left)] - v[d.get(j.right)] >= 0 ? $++ : J++ : L[d.get(j.top)] - L[d.get(j.bottom)] >= 0 ? k++ : at++;
                    }), $ > J && k > at)
                      for (var ct = 0; ct < d.size; ct++)
                        v[ct] = -1 * v[ct], L[ct] = -1 * L[ct];
                    else if ($ > J)
                      for (var nt = 0; nt < d.size; nt++)
                        v[nt] = -1 * v[nt];
                    else if (k > at)
                      for (var tt = 0; tt < d.size; tt++)
                        L[tt] = -1 * L[tt];
                  }, n = function(U) {
                    var $ = [], J = new g(), k = /* @__PURE__ */ new Set(), at = 0;
                    return U.forEach(function(ct, nt) {
                      if (!k.has(nt)) {
                        $[at] = [];
                        var tt = nt;
                        for (J.push(tt), k.add(tt), $[at].push(tt); J.length != 0; ) {
                          tt = J.shift();
                          var j = U.get(tt);
                          j.forEach(function(ut) {
                            k.has(ut.id) || (J.push(ut.id), k.add(ut.id), $[at].push(ut.id));
                          });
                        }
                        at++;
                      }
                    }), $;
                  }, m = function(U) {
                    var $ = /* @__PURE__ */ new Map();
                    return U.forEach(function(J, k) {
                      $.set(k, []);
                    }), U.forEach(function(J, k) {
                      J.forEach(function(at) {
                        $.get(k).push(at), $.get(at.id).push({ id: k, gap: at.gap, direction: at.direction });
                      });
                    }), $;
                  }, p = function(U) {
                    var $ = /* @__PURE__ */ new Map();
                    return U.forEach(function(J, k) {
                      $.set(k, []);
                    }), U.forEach(function(J, k) {
                      J.forEach(function(at) {
                        $.get(at.id).push({ id: k, gap: at.gap, direction: at.direction });
                      });
                    }), $;
                  }, E = [], y = [], R = !1, M = !1, F = /* @__PURE__ */ new Set(), W = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new Map(), Z = [];
                  if (l.fixedNodeConstraint && l.fixedNodeConstraint.forEach(function(b) {
                    F.add(b.nodeId);
                  }), l.relativePlacementConstraint && (l.relativePlacementConstraint.forEach(function(b) {
                    b.left ? (W.has(b.left) ? W.get(b.left).push({ id: b.right, gap: b.gap, direction: "horizontal" }) : W.set(b.left, [{ id: b.right, gap: b.gap, direction: "horizontal" }]), W.has(b.right) || W.set(b.right, [])) : (W.has(b.top) ? W.get(b.top).push({ id: b.bottom, gap: b.gap, direction: "vertical" }) : W.set(b.top, [{ id: b.bottom, gap: b.gap, direction: "vertical" }]), W.has(b.bottom) || W.set(b.bottom, []));
                  }), x = m(W), Z = n(x)), i.TRANSFORM_ON_CONSTRAINT_HANDLING) {
                    if (l.fixedNodeConstraint && l.fixedNodeConstraint.length > 1)
                      l.fixedNodeConstraint.forEach(function(b, U) {
                        E[U] = [b.position.x, b.position.y], y[U] = [v[d.get(b.nodeId)], L[d.get(b.nodeId)]];
                      }), R = !0;
                    else if (l.alignmentConstraint)
                      (function() {
                        var b = 0;
                        if (l.alignmentConstraint.vertical) {
                          for (var U = l.alignmentConstraint.vertical, $ = function(tt) {
                            var j = /* @__PURE__ */ new Set();
                            U[tt].forEach(function(pt) {
                              j.add(pt);
                            });
                            var ut = new Set([].concat(f(j)).filter(function(pt) {
                              return F.has(pt);
                            })), Mt = void 0;
                            ut.size > 0 ? Mt = v[d.get(ut.values().next().value)] : Mt = Q(j).x, U[tt].forEach(function(pt) {
                              E[b] = [Mt, L[d.get(pt)]], y[b] = [v[d.get(pt)], L[d.get(pt)]], b++;
                            });
                          }, J = 0; J < U.length; J++)
                            $(J);
                          R = !0;
                        }
                        if (l.alignmentConstraint.horizontal) {
                          for (var k = l.alignmentConstraint.horizontal, at = function(tt) {
                            var j = /* @__PURE__ */ new Set();
                            k[tt].forEach(function(pt) {
                              j.add(pt);
                            });
                            var ut = new Set([].concat(f(j)).filter(function(pt) {
                              return F.has(pt);
                            })), Mt = void 0;
                            ut.size > 0 ? Mt = v[d.get(ut.values().next().value)] : Mt = Q(j).y, k[tt].forEach(function(pt) {
                              E[b] = [v[d.get(pt)], Mt], y[b] = [v[d.get(pt)], L[d.get(pt)]], b++;
                            });
                          }, ct = 0; ct < k.length; ct++)
                            at(ct);
                          R = !0;
                        }
                        l.relativePlacementConstraint && (M = !0);
                      })();
                    else if (l.relativePlacementConstraint) {
                      for (var V = 0, Y = 0, et = 0; et < Z.length; et++)
                        Z[et].length > V && (V = Z[et].length, Y = et);
                      if (V < x.size / 2)
                        rt(l.relativePlacementConstraint), R = !1, M = !1;
                      else {
                        var z = /* @__PURE__ */ new Map(), w = /* @__PURE__ */ new Map(), H = [];
                        Z[Y].forEach(function(b) {
                          W.get(b).forEach(function(U) {
                            U.direction == "horizontal" ? (z.has(b) ? z.get(b).push(U) : z.set(b, [U]), z.has(U.id) || z.set(U.id, []), H.push({ left: b, right: U.id })) : (w.has(b) ? w.get(b).push(U) : w.set(b, [U]), w.has(U.id) || w.set(U.id, []), H.push({ top: b, bottom: U.id }));
                          });
                        }), rt(H), M = !1;
                        var B = O(z, "horizontal"), _ = O(w, "vertical");
                        Z[Y].forEach(function(b, U) {
                          y[U] = [v[d.get(b)], L[d.get(b)]], E[U] = [], B.has(b) ? E[U][0] = B.get(b) : E[U][0] = v[d.get(b)], _.has(b) ? E[U][1] = _.get(b) : E[U][1] = L[d.get(b)];
                        }), R = !0;
                      }
                    }
                    if (R) {
                      for (var ht = void 0, q = t.transpose(E), It = t.transpose(y), Nt = 0; Nt < q.length; Nt++)
                        q[Nt] = t.multGamma(q[Nt]), It[Nt] = t.multGamma(It[Nt]);
                      var vt = t.multMat(q, t.transpose(It)), it = o.svd(vt);
                      ht = t.multMat(it.V, t.transpose(it.U));
                      for (var gt = 0; gt < d.size; gt++) {
                        var mt = [v[gt], L[gt]], At = [ht[0][0], ht[1][0]], Ot = [ht[0][1], ht[1][1]];
                        v[gt] = t.dotProduct(mt, At), L[gt] = t.dotProduct(mt, Ot);
                      }
                      M && rt(l.relativePlacementConstraint);
                    }
                  }
                  if (i.ENFORCE_CONSTRAINTS) {
                    if (l.fixedNodeConstraint && l.fixedNodeConstraint.length > 0) {
                      var Et = { x: 0, y: 0 };
                      l.fixedNodeConstraint.forEach(function(b, U) {
                        var $ = { x: v[d.get(b.nodeId)], y: L[d.get(b.nodeId)] }, J = b.position, k = X(J, $);
                        Et.x += k.x, Et.y += k.y;
                      }), Et.x /= l.fixedNodeConstraint.length, Et.y /= l.fixedNodeConstraint.length, v.forEach(function(b, U) {
                        v[U] += Et.x;
                      }), L.forEach(function(b, U) {
                        L[U] += Et.y;
                      }), l.fixedNodeConstraint.forEach(function(b) {
                        v[d.get(b.nodeId)] = b.position.x, L[d.get(b.nodeId)] = b.position.y;
                      });
                    }
                    if (l.alignmentConstraint) {
                      if (l.alignmentConstraint.vertical)
                        for (var Dt = l.alignmentConstraint.vertical, Rt = function(U) {
                          var $ = /* @__PURE__ */ new Set();
                          Dt[U].forEach(function(at) {
                            $.add(at);
                          });
                          var J = new Set([].concat(f($)).filter(function(at) {
                            return F.has(at);
                          })), k = void 0;
                          J.size > 0 ? k = v[d.get(J.values().next().value)] : k = Q($).x, $.forEach(function(at) {
                            F.has(at) || (v[d.get(at)] = k);
                          });
                        }, Ht = 0; Ht < Dt.length; Ht++)
                          Rt(Ht);
                      if (l.alignmentConstraint.horizontal)
                        for (var Ut = l.alignmentConstraint.horizontal, Pt = function(U) {
                          var $ = /* @__PURE__ */ new Set();
                          Ut[U].forEach(function(at) {
                            $.add(at);
                          });
                          var J = new Set([].concat(f($)).filter(function(at) {
                            return F.has(at);
                          })), k = void 0;
                          J.size > 0 ? k = L[d.get(J.values().next().value)] : k = Q($).y, $.forEach(function(at) {
                            F.has(at) || (L[d.get(at)] = k);
                          });
                        }, Ft = 0; Ft < Ut.length; Ft++)
                          Pt(Ft);
                    }
                    l.relativePlacementConstraint && function() {
                      var b = /* @__PURE__ */ new Map(), U = /* @__PURE__ */ new Map(), $ = /* @__PURE__ */ new Map(), J = /* @__PURE__ */ new Map(), k = /* @__PURE__ */ new Map(), at = /* @__PURE__ */ new Map(), ct = /* @__PURE__ */ new Set(), nt = /* @__PURE__ */ new Set();
                      if (F.forEach(function(Gt) {
                        ct.add(Gt), nt.add(Gt);
                      }), l.alignmentConstraint) {
                        if (l.alignmentConstraint.vertical)
                          for (var tt = l.alignmentConstraint.vertical, j = function(yt) {
                            $.set("dummy" + yt, []), tt[yt].forEach(function(wt) {
                              b.set(wt, "dummy" + yt), $.get("dummy" + yt).push(wt), F.has(wt) && ct.add("dummy" + yt);
                            }), k.set("dummy" + yt, v[d.get(tt[yt][0])]);
                          }, ut = 0; ut < tt.length; ut++)
                            j(ut);
                        if (l.alignmentConstraint.horizontal)
                          for (var Mt = l.alignmentConstraint.horizontal, pt = function(yt) {
                            J.set("dummy" + yt, []), Mt[yt].forEach(function(wt) {
                              U.set(wt, "dummy" + yt), J.get("dummy" + yt).push(wt), F.has(wt) && nt.add("dummy" + yt);
                            }), at.set("dummy" + yt, L[d.get(Mt[yt][0])]);
                          }, xt = 0; xt < Mt.length; xt++)
                            pt(xt);
                      }
                      var lt = /* @__PURE__ */ new Map(), ot = /* @__PURE__ */ new Map(), Lt = function(yt) {
                        W.get(yt).forEach(function(wt) {
                          var Zt = void 0, $t = void 0;
                          wt.direction == "horizontal" ? (Zt = b.get(yt) ? b.get(yt) : yt, b.get(wt.id) ? $t = { id: b.get(wt.id), gap: wt.gap, direction: wt.direction } : $t = wt, lt.has(Zt) ? lt.get(Zt).push($t) : lt.set(Zt, [$t]), lt.has($t.id) || lt.set($t.id, [])) : (Zt = U.get(yt) ? U.get(yt) : yt, U.get(wt.id) ? $t = { id: U.get(wt.id), gap: wt.gap, direction: wt.direction } : $t = wt, ot.has(Zt) ? ot.get(Zt).push($t) : ot.set(Zt, [$t]), ot.has($t.id) || ot.set($t.id, []));
                        });
                      }, ft = !0, st = !1, Xt = void 0;
                      try {
                        for (var Tt = W.keys()[Symbol.iterator](), Ct; !(ft = (Ct = Tt.next()).done); ft = !0) {
                          var Bt = Ct.value;
                          Lt(Bt);
                        }
                      } catch (Gt) {
                        st = !0, Xt = Gt;
                      } finally {
                        try {
                          !ft && Tt.return && Tt.return();
                        } finally {
                          if (st)
                            throw Xt;
                        }
                      }
                      var bt = m(lt), zt = m(ot), St = n(bt), kt = n(zt), Kt = p(lt), he = p(ot), Qt = [], jt = [];
                      St.forEach(function(Gt, yt) {
                        Qt[yt] = [], Gt.forEach(function(wt) {
                          Kt.get(wt).length == 0 && Qt[yt].push(wt);
                        });
                      }), kt.forEach(function(Gt, yt) {
                        jt[yt] = [], Gt.forEach(function(wt) {
                          he.get(wt).length == 0 && jt[yt].push(wt);
                        });
                      });
                      var _t = O(lt, "horizontal", ct, k, Qt), Jt = O(ot, "vertical", nt, at, jt), oe = function(yt) {
                        $.get(yt) ? $.get(yt).forEach(function(wt) {
                          v[d.get(wt)] = _t.get(yt);
                        }) : v[d.get(yt)] = _t.get(yt);
                      }, te = !0, ee = !1, Ne = void 0;
                      try {
                        for (var le = _t.keys()[Symbol.iterator](), Le; !(te = (Le = le.next()).done); te = !0) {
                          var fe = Le.value;
                          oe(fe);
                        }
                      } catch (Gt) {
                        ee = !0, Ne = Gt;
                      } finally {
                        try {
                          !te && le.return && le.return();
                        } finally {
                          if (ee)
                            throw Ne;
                        }
                      }
                      var $e = function(yt) {
                        J.get(yt) ? J.get(yt).forEach(function(wt) {
                          L[d.get(wt)] = Jt.get(yt);
                        }) : L[d.get(yt)] = Jt.get(yt);
                      }, ce = !0, Ce = !1, Ae = void 0;
                      try {
                        for (var ge = Jt.keys()[Symbol.iterator](), Me; !(ce = (Me = ge.next()).done); ce = !0) {
                          var fe = Me.value;
                          $e(fe);
                        }
                      } catch (Gt) {
                        Ce = !0, Ae = Gt;
                      } finally {
                        try {
                          !ce && ge.return && ge.return();
                        } finally {
                          if (Ce)
                            throw Ae;
                        }
                      }
                    }();
                  }
                  for (var Yt = 0; Yt < S.length; Yt++) {
                    var Vt = S[Yt];
                    Vt.getChild() == null && Vt.setCenter(v[d.get(Vt.id)], L[d.get(Vt.id)]);
                  }
                }, a.exports = s;
              }
            ),
            /***/
            551: (
              /***/
              (a) => {
                a.exports = A;
              }
            )
            /******/
          }, N = {};
          function u(a) {
            var r = N[a];
            if (r !== void 0)
              return r.exports;
            var e = N[a] = {
              /******/
              // no module.id needed
              /******/
              // no module.loaded needed
              /******/
              exports: {}
              /******/
            };
            return P[a](e, e.exports, u), e.exports;
          }
          var h = u(45);
          return h;
        })()
      );
    });
  }(ue)), ue.exports;
}
(function(I, D) {
  (function(P, N) {
    I.exports = N(ur());
  })(me, function(A) {
    return (
      /******/
      (() => {
        var P = {
          /***/
          658: (
            /***/
            (a) => {
              a.exports = Object.assign != null ? Object.assign.bind(Object) : function(r) {
                for (var e = arguments.length, f = Array(e > 1 ? e - 1 : 0), i = 1; i < e; i++)
                  f[i - 1] = arguments[i];
                return f.forEach(function(g) {
                  Object.keys(g).forEach(function(t) {
                    return r[t] = g[t];
                  });
                }), r;
              };
            }
          ),
          /***/
          548: (
            /***/
            (a, r, e) => {
              var f = /* @__PURE__ */ function() {
                function t(o, s) {
                  var c = [], l = !0, T = !1, d = void 0;
                  try {
                    for (var v = o[Symbol.iterator](), L; !(l = (L = v.next()).done) && (c.push(L.value), !(s && c.length === s)); l = !0)
                      ;
                  } catch (S) {
                    T = !0, d = S;
                  } finally {
                    try {
                      !l && v.return && v.return();
                    } finally {
                      if (T) throw d;
                    }
                  }
                  return c;
                }
                return function(o, s) {
                  if (Array.isArray(o))
                    return o;
                  if (Symbol.iterator in Object(o))
                    return t(o, s);
                  throw new TypeError("Invalid attempt to destructure non-iterable instance");
                };
              }(), i = e(140).layoutBase.LinkedList, g = {};
              g.getTopMostNodes = function(t) {
                for (var o = {}, s = 0; s < t.length; s++)
                  o[t[s].id()] = !0;
                var c = t.filter(function(l, T) {
                  typeof l == "number" && (l = T);
                  for (var d = l.parent()[0]; d != null; ) {
                    if (o[d.id()])
                      return !1;
                    d = d.parent()[0];
                  }
                  return !0;
                });
                return c;
              }, g.connectComponents = function(t, o, s, c) {
                var l = new i(), T = /* @__PURE__ */ new Set(), d = [], v = void 0, L = void 0, S = void 0, C = !1, G = 1, K = [], X = [], Q = function() {
                  var rt = t.collection();
                  X.push(rt);
                  var n = s[0], m = t.collection();
                  m.merge(n).merge(n.descendants().intersection(o)), d.push(n), m.forEach(function(y) {
                    l.push(y), T.add(y), rt.merge(y);
                  });
                  for (var p = function() {
                    n = l.shift();
                    var R = t.collection();
                    n.neighborhood().nodes().forEach(function(x) {
                      o.intersection(n.edgesWith(x)).length > 0 && R.merge(x);
                    });
                    for (var M = 0; M < R.length; M++) {
                      var F = R[M];
                      if (v = s.intersection(F.union(F.ancestors())), v != null && !T.has(v[0])) {
                        var W = v.union(v.descendants());
                        W.forEach(function(x) {
                          l.push(x), T.add(x), rt.merge(x), s.has(x) && d.push(x);
                        });
                      }
                    }
                  }; l.length != 0; )
                    p();
                  if (rt.forEach(function(y) {
                    o.intersection(y.connectedEdges()).forEach(function(R) {
                      rt.has(R.source()) && rt.has(R.target()) && rt.merge(R);
                    });
                  }), d.length == s.length && (C = !0), !C || C && G > 1) {
                    L = d[0], S = L.connectedEdges().length, d.forEach(function(y) {
                      y.connectedEdges().length < S && (S = y.connectedEdges().length, L = y);
                    }), K.push(L.id());
                    var E = t.collection();
                    E.merge(d[0]), d.forEach(function(y) {
                      E.merge(y);
                    }), d = [], s = s.difference(E), G++;
                  }
                };
                do
                  Q();
                while (!C);
                return c && K.length > 0 && c.set("dummy" + (c.size + 1), K), X;
              }, g.relocateComponent = function(t, o, s) {
                if (!s.fixedNodeConstraint) {
                  var c = Number.POSITIVE_INFINITY, l = Number.NEGATIVE_INFINITY, T = Number.POSITIVE_INFINITY, d = Number.NEGATIVE_INFINITY;
                  if (s.quality == "draft") {
                    var v = !0, L = !1, S = void 0;
                    try {
                      for (var C = o.nodeIndexes[Symbol.iterator](), G; !(v = (G = C.next()).done); v = !0) {
                        var K = G.value, X = f(K, 2), Q = X[0], O = X[1], rt = s.cy.getElementById(Q);
                        if (rt) {
                          var n = rt.boundingBox(), m = o.xCoords[O] - n.w / 2, p = o.xCoords[O] + n.w / 2, E = o.yCoords[O] - n.h / 2, y = o.yCoords[O] + n.h / 2;
                          m < c && (c = m), p > l && (l = p), E < T && (T = E), y > d && (d = y);
                        }
                      }
                    } catch (x) {
                      L = !0, S = x;
                    } finally {
                      try {
                        !v && C.return && C.return();
                      } finally {
                        if (L)
                          throw S;
                      }
                    }
                    var R = t.x - (l + c) / 2, M = t.y - (d + T) / 2;
                    o.xCoords = o.xCoords.map(function(x) {
                      return x + R;
                    }), o.yCoords = o.yCoords.map(function(x) {
                      return x + M;
                    });
                  } else {
                    Object.keys(o).forEach(function(x) {
                      var Z = o[x], V = Z.getRect().x, Y = Z.getRect().x + Z.getRect().width, et = Z.getRect().y, z = Z.getRect().y + Z.getRect().height;
                      V < c && (c = V), Y > l && (l = Y), et < T && (T = et), z > d && (d = z);
                    });
                    var F = t.x - (l + c) / 2, W = t.y - (d + T) / 2;
                    Object.keys(o).forEach(function(x) {
                      var Z = o[x];
                      Z.setCenter(Z.getCenterX() + F, Z.getCenterY() + W);
                    });
                  }
                }
              }, g.calcBoundingBox = function(t, o, s, c) {
                for (var l = Number.MAX_SAFE_INTEGER, T = Number.MIN_SAFE_INTEGER, d = Number.MAX_SAFE_INTEGER, v = Number.MIN_SAFE_INTEGER, L = void 0, S = void 0, C = void 0, G = void 0, K = t.descendants().not(":parent"), X = K.length, Q = 0; Q < X; Q++) {
                  var O = K[Q];
                  L = o[c.get(O.id())] - O.width() / 2, S = o[c.get(O.id())] + O.width() / 2, C = s[c.get(O.id())] - O.height() / 2, G = s[c.get(O.id())] + O.height() / 2, l > L && (l = L), T < S && (T = S), d > C && (d = C), v < G && (v = G);
                }
                var rt = {};
                return rt.topLeftX = l, rt.topLeftY = d, rt.width = T - l, rt.height = v - d, rt;
              }, g.calcParentsWithoutChildren = function(t, o) {
                var s = t.collection();
                return o.nodes(":parent").forEach(function(c) {
                  var l = !1;
                  c.children().forEach(function(T) {
                    T.css("display") != "none" && (l = !0);
                  }), l || s.merge(c);
                }), s;
              }, a.exports = g;
            }
          ),
          /***/
          816: (
            /***/
            (a, r, e) => {
              var f = e(548), i = e(140).CoSELayout, g = e(140).CoSENode, t = e(140).layoutBase.PointD, o = e(140).layoutBase.DimensionD, s = e(140).layoutBase.LayoutConstants, c = e(140).layoutBase.FDLayoutConstants, l = e(140).CoSEConstants, T = function(v, L) {
                var S = v.cy, C = v.eles, G = C.nodes(), K = C.edges(), X = void 0, Q = void 0, O = void 0, rt = {};
                v.randomize && (X = L.nodeIndexes, Q = L.xCoords, O = L.yCoords);
                var n = function(x) {
                  return typeof x == "function";
                }, m = function(x, Z) {
                  return n(x) ? x(Z) : x;
                }, p = f.calcParentsWithoutChildren(S, C), E = function W(x, Z, V, Y) {
                  for (var et = Z.length, z = 0; z < et; z++) {
                    var w = Z[z], H = null;
                    w.intersection(p).length == 0 && (H = w.children());
                    var B = void 0, _ = w.layoutDimensions({
                      nodeDimensionsIncludeLabels: Y.nodeDimensionsIncludeLabels
                    });
                    if (w.outerWidth() != null && w.outerHeight() != null)
                      if (Y.randomize)
                        if (!w.isParent())
                          B = x.add(new g(V.graphManager, new t(Q[X.get(w.id())] - _.w / 2, O[X.get(w.id())] - _.h / 2), new o(parseFloat(_.w), parseFloat(_.h))));
                        else {
                          var ht = f.calcBoundingBox(w, Q, O, X);
                          w.intersection(p).length == 0 ? B = x.add(new g(V.graphManager, new t(ht.topLeftX, ht.topLeftY), new o(ht.width, ht.height))) : B = x.add(new g(V.graphManager, new t(ht.topLeftX, ht.topLeftY), new o(parseFloat(_.w), parseFloat(_.h))));
                        }
                      else
                        B = x.add(new g(V.graphManager, new t(w.position("x") - _.w / 2, w.position("y") - _.h / 2), new o(parseFloat(_.w), parseFloat(_.h))));
                    else
                      B = x.add(new g(this.graphManager));
                    if (B.id = w.data("id"), B.nodeRepulsion = m(Y.nodeRepulsion, w), B.paddingLeft = parseInt(w.css("padding")), B.paddingTop = parseInt(w.css("padding")), B.paddingRight = parseInt(w.css("padding")), B.paddingBottom = parseInt(w.css("padding")), Y.nodeDimensionsIncludeLabels && (B.labelWidth = w.boundingBox({ includeLabels: !0, includeNodes: !1, includeOverlays: !1 }).w, B.labelHeight = w.boundingBox({ includeLabels: !0, includeNodes: !1, includeOverlays: !1 }).h, B.labelPosVertical = w.css("text-valign"), B.labelPosHorizontal = w.css("text-halign")), rt[w.data("id")] = B, isNaN(B.rect.x) && (B.rect.x = 0), isNaN(B.rect.y) && (B.rect.y = 0), H != null && H.length > 0) {
                      var q = void 0;
                      q = V.getGraphManager().add(V.newGraph(), B), W(q, H, V, Y);
                    }
                  }
                }, y = function(x, Z, V) {
                  for (var Y = 0, et = 0, z = 0; z < V.length; z++) {
                    var w = V[z], H = rt[w.data("source")], B = rt[w.data("target")];
                    if (H && B && H !== B && H.getEdgesBetween(B).length == 0) {
                      var _ = Z.add(x.newEdge(), H, B);
                      _.id = w.id(), _.idealLength = m(v.idealEdgeLength, w), _.edgeElasticity = m(v.edgeElasticity, w), Y += _.idealLength, et++;
                    }
                  }
                  v.idealEdgeLength != null && (et > 0 ? l.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = Y / et : n(v.idealEdgeLength) ? l.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = 50 : l.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = v.idealEdgeLength, l.MIN_REPULSION_DIST = c.MIN_REPULSION_DIST = c.DEFAULT_EDGE_LENGTH / 10, l.DEFAULT_RADIAL_SEPARATION = c.DEFAULT_EDGE_LENGTH);
                }, R = function(x, Z) {
                  Z.fixedNodeConstraint && (x.constraints.fixedNodeConstraint = Z.fixedNodeConstraint), Z.alignmentConstraint && (x.constraints.alignmentConstraint = Z.alignmentConstraint), Z.relativePlacementConstraint && (x.constraints.relativePlacementConstraint = Z.relativePlacementConstraint);
                };
                v.nestingFactor != null && (l.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = c.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = v.nestingFactor), v.gravity != null && (l.DEFAULT_GRAVITY_STRENGTH = c.DEFAULT_GRAVITY_STRENGTH = v.gravity), v.numIter != null && (l.MAX_ITERATIONS = c.MAX_ITERATIONS = v.numIter), v.gravityRange != null && (l.DEFAULT_GRAVITY_RANGE_FACTOR = c.DEFAULT_GRAVITY_RANGE_FACTOR = v.gravityRange), v.gravityCompound != null && (l.DEFAULT_COMPOUND_GRAVITY_STRENGTH = c.DEFAULT_COMPOUND_GRAVITY_STRENGTH = v.gravityCompound), v.gravityRangeCompound != null && (l.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = c.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = v.gravityRangeCompound), v.initialEnergyOnIncremental != null && (l.DEFAULT_COOLING_FACTOR_INCREMENTAL = c.DEFAULT_COOLING_FACTOR_INCREMENTAL = v.initialEnergyOnIncremental), v.tilingCompareBy != null && (l.TILING_COMPARE_BY = v.tilingCompareBy), v.quality == "proof" ? s.QUALITY = 2 : s.QUALITY = 0, l.NODE_DIMENSIONS_INCLUDE_LABELS = c.NODE_DIMENSIONS_INCLUDE_LABELS = s.NODE_DIMENSIONS_INCLUDE_LABELS = v.nodeDimensionsIncludeLabels, l.DEFAULT_INCREMENTAL = c.DEFAULT_INCREMENTAL = s.DEFAULT_INCREMENTAL = !v.randomize, l.ANIMATE = c.ANIMATE = s.ANIMATE = v.animate, l.TILE = v.tile, l.TILING_PADDING_VERTICAL = typeof v.tilingPaddingVertical == "function" ? v.tilingPaddingVertical.call() : v.tilingPaddingVertical, l.TILING_PADDING_HORIZONTAL = typeof v.tilingPaddingHorizontal == "function" ? v.tilingPaddingHorizontal.call() : v.tilingPaddingHorizontal, l.DEFAULT_INCREMENTAL = c.DEFAULT_INCREMENTAL = s.DEFAULT_INCREMENTAL = !0, l.PURE_INCREMENTAL = !v.randomize, s.DEFAULT_UNIFORM_LEAF_NODE_SIZES = v.uniformNodeDimensions, v.step == "transformed" && (l.TRANSFORM_ON_CONSTRAINT_HANDLING = !0, l.ENFORCE_CONSTRAINTS = !1, l.APPLY_LAYOUT = !1), v.step == "enforced" && (l.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, l.ENFORCE_CONSTRAINTS = !0, l.APPLY_LAYOUT = !1), v.step == "cose" && (l.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, l.ENFORCE_CONSTRAINTS = !1, l.APPLY_LAYOUT = !0), v.step == "all" && (v.randomize ? l.TRANSFORM_ON_CONSTRAINT_HANDLING = !0 : l.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, l.ENFORCE_CONSTRAINTS = !0, l.APPLY_LAYOUT = !0), v.fixedNodeConstraint || v.alignmentConstraint || v.relativePlacementConstraint ? l.TREE_REDUCTION_ON_INCREMENTAL = !1 : l.TREE_REDUCTION_ON_INCREMENTAL = !0;
                var M = new i(), F = M.newGraphManager();
                return E(F.addRoot(), f.getTopMostNodes(G), M, v), y(M, F, K), R(M, v), M.runLayout(), rt;
              };
              a.exports = { coseLayout: T };
            }
          ),
          /***/
          212: (
            /***/
            (a, r, e) => {
              var f = /* @__PURE__ */ function() {
                function v(L, S) {
                  for (var C = 0; C < S.length; C++) {
                    var G = S[C];
                    G.enumerable = G.enumerable || !1, G.configurable = !0, "value" in G && (G.writable = !0), Object.defineProperty(L, G.key, G);
                  }
                }
                return function(L, S, C) {
                  return S && v(L.prototype, S), C && v(L, C), L;
                };
              }();
              function i(v, L) {
                if (!(v instanceof L))
                  throw new TypeError("Cannot call a class as a function");
              }
              var g = e(658), t = e(548), o = e(657), s = o.spectralLayout, c = e(816), l = c.coseLayout, T = Object.freeze({
                // 'draft', 'default' or 'proof' 
                // - 'draft' only applies spectral layout 
                // - 'default' improves the quality with subsequent CoSE layout (fast cooling rate)
                // - 'proof' improves the quality with subsequent CoSE layout (slow cooling rate) 
                quality: "default",
                // Use random node positions at beginning of layout
                // if this is set to false, then quality option must be "proof"
                randomize: !0,
                // Whether or not to animate the layout
                animate: !0,
                // Duration of animation in ms, if enabled
                animationDuration: 1e3,
                // Easing of animation, if enabled
                animationEasing: void 0,
                // Fit the viewport to the repositioned nodes
                fit: !0,
                // Padding around layout
                padding: 30,
                // Whether to include labels in node dimensions. Valid in "proof" quality
                nodeDimensionsIncludeLabels: !1,
                // Whether or not simple nodes (non-compound nodes) are of uniform dimensions
                uniformNodeDimensions: !1,
                // Whether to pack disconnected components - valid only if randomize: true
                packComponents: !0,
                // Layout step - all, transformed, enforced, cose - for debug purpose only
                step: "all",
                /* spectral layout options */
                // False for random, true for greedy
                samplingType: !0,
                // Sample size to construct distance matrix
                sampleSize: 25,
                // Separation amount between nodes
                nodeSeparation: 75,
                // Power iteration tolerance
                piTol: 1e-7,
                /* CoSE layout options */
                // Node repulsion (non overlapping) multiplier
                nodeRepulsion: function(L) {
                  return 4500;
                },
                // Ideal edge (non nested) length
                idealEdgeLength: function(L) {
                  return 50;
                },
                // Divisor to compute edge forces
                edgeElasticity: function(L) {
                  return 0.45;
                },
                // Nesting factor (multiplier) to compute ideal edge length for nested edges
                nestingFactor: 0.1,
                // Gravity force (constant)
                gravity: 0.25,
                // Maximum number of iterations to perform
                numIter: 2500,
                // For enabling tiling
                tile: !0,
                // The function that specifies the criteria for comparing nodes while sorting them during tiling operation.
                // Takes the node id as a parameter and the default tiling operation is perfomed when this option is not set.
                tilingCompareBy: void 0,
                // Represents the amount of the vertical space to put between the zero degree members during the tiling operation(can also be a function)
                tilingPaddingVertical: 10,
                // Represents the amount of the horizontal space to put between the zero degree members during the tiling operation(can also be a function)
                tilingPaddingHorizontal: 10,
                // Gravity range (constant) for compounds
                gravityRangeCompound: 1.5,
                // Gravity force (constant) for compounds
                gravityCompound: 1,
                // Gravity range (constant)
                gravityRange: 3.8,
                // Initial cooling factor for incremental layout  
                initialEnergyOnIncremental: 0.3,
                /* constraint options */
                // Fix required nodes to predefined positions
                // [{nodeId: 'n1', position: {x: 100, y: 200}, {...}]
                fixedNodeConstraint: void 0,
                // Align required nodes in vertical/horizontal direction
                // {vertical: [['n1', 'n2')], ['n3', 'n4']], horizontal: ['n2', 'n4']}
                alignmentConstraint: void 0,
                // Place two nodes relatively in vertical/horizontal direction 
                // [{top: 'n1', bottom: 'n2', gap: 100}, {left: 'n3', right: 'n4', gap: 75}]
                relativePlacementConstraint: void 0,
                /* layout event callbacks */
                ready: function() {
                },
                // on layoutready
                stop: function() {
                }
                // on layoutstop
              }), d = function() {
                function v(L) {
                  i(this, v), this.options = g({}, T, L);
                }
                return f(v, [{
                  key: "run",
                  value: function() {
                    var S = this, C = this.options, G = C.cy, K = C.eles, X = [], Q = [], O = void 0, rt = [];
                    C.fixedNodeConstraint && (!Array.isArray(C.fixedNodeConstraint) || C.fixedNodeConstraint.length == 0) && (C.fixedNodeConstraint = void 0), C.alignmentConstraint && (C.alignmentConstraint.vertical && (!Array.isArray(C.alignmentConstraint.vertical) || C.alignmentConstraint.vertical.length == 0) && (C.alignmentConstraint.vertical = void 0), C.alignmentConstraint.horizontal && (!Array.isArray(C.alignmentConstraint.horizontal) || C.alignmentConstraint.horizontal.length == 0) && (C.alignmentConstraint.horizontal = void 0)), C.relativePlacementConstraint && (!Array.isArray(C.relativePlacementConstraint) || C.relativePlacementConstraint.length == 0) && (C.relativePlacementConstraint = void 0);
                    var n = C.fixedNodeConstraint || C.alignmentConstraint || C.relativePlacementConstraint;
                    n && (C.tile = !1, C.packComponents = !1);
                    var m = void 0, p = !1;
                    if (G.layoutUtilities && C.packComponents && (m = G.layoutUtilities("get"), m || (m = G.layoutUtilities()), p = !0), K.nodes().length > 0)
                      if (p) {
                        var R = t.getTopMostNodes(C.eles.nodes());
                        if (O = t.connectComponents(G, C.eles, R), O.forEach(function(vt) {
                          var it = vt.boundingBox();
                          rt.push({ x: it.x1 + it.w / 2, y: it.y1 + it.h / 2 });
                        }), C.randomize && O.forEach(function(vt) {
                          C.eles = vt, X.push(s(C));
                        }), C.quality == "default" || C.quality == "proof") {
                          var M = G.collection();
                          if (C.tile) {
                            var F = /* @__PURE__ */ new Map(), W = [], x = [], Z = 0, V = { nodeIndexes: F, xCoords: W, yCoords: x }, Y = [];
                            if (O.forEach(function(vt, it) {
                              vt.edges().length == 0 && (vt.nodes().forEach(function(gt, mt) {
                                M.merge(vt.nodes()[mt]), gt.isParent() || (V.nodeIndexes.set(vt.nodes()[mt].id(), Z++), V.xCoords.push(vt.nodes()[0].position().x), V.yCoords.push(vt.nodes()[0].position().y));
                              }), Y.push(it));
                            }), M.length > 1) {
                              var et = M.boundingBox();
                              rt.push({ x: et.x1 + et.w / 2, y: et.y1 + et.h / 2 }), O.push(M), X.push(V);
                              for (var z = Y.length - 1; z >= 0; z--)
                                O.splice(Y[z], 1), X.splice(Y[z], 1), rt.splice(Y[z], 1);
                            }
                          }
                          O.forEach(function(vt, it) {
                            C.eles = vt, Q.push(l(C, X[it])), t.relocateComponent(rt[it], Q[it], C);
                          });
                        } else
                          O.forEach(function(vt, it) {
                            t.relocateComponent(rt[it], X[it], C);
                          });
                        var w = /* @__PURE__ */ new Set();
                        if (O.length > 1) {
                          var H = [], B = K.filter(function(vt) {
                            return vt.css("display") == "none";
                          });
                          O.forEach(function(vt, it) {
                            var gt = void 0;
                            if (C.quality == "draft" && (gt = X[it].nodeIndexes), vt.nodes().not(B).length > 0) {
                              var mt = {};
                              mt.edges = [], mt.nodes = [];
                              var At = void 0;
                              vt.nodes().not(B).forEach(function(Ot) {
                                if (C.quality == "draft")
                                  if (!Ot.isParent())
                                    At = gt.get(Ot.id()), mt.nodes.push({ x: X[it].xCoords[At] - Ot.boundingbox().w / 2, y: X[it].yCoords[At] - Ot.boundingbox().h / 2, width: Ot.boundingbox().w, height: Ot.boundingbox().h });
                                  else {
                                    var Et = t.calcBoundingBox(Ot, X[it].xCoords, X[it].yCoords, gt);
                                    mt.nodes.push({ x: Et.topLeftX, y: Et.topLeftY, width: Et.width, height: Et.height });
                                  }
                                else
                                  Q[it][Ot.id()] && mt.nodes.push({ x: Q[it][Ot.id()].getLeft(), y: Q[it][Ot.id()].getTop(), width: Q[it][Ot.id()].getWidth(), height: Q[it][Ot.id()].getHeight() });
                              }), vt.edges().forEach(function(Ot) {
                                var Et = Ot.source(), Dt = Ot.target();
                                if (Et.css("display") != "none" && Dt.css("display") != "none")
                                  if (C.quality == "draft") {
                                    var Rt = gt.get(Et.id()), Ht = gt.get(Dt.id()), Ut = [], Pt = [];
                                    if (Et.isParent()) {
                                      var Ft = t.calcBoundingBox(Et, X[it].xCoords, X[it].yCoords, gt);
                                      Ut.push(Ft.topLeftX + Ft.width / 2), Ut.push(Ft.topLeftY + Ft.height / 2);
                                    } else
                                      Ut.push(X[it].xCoords[Rt]), Ut.push(X[it].yCoords[Rt]);
                                    if (Dt.isParent()) {
                                      var Yt = t.calcBoundingBox(Dt, X[it].xCoords, X[it].yCoords, gt);
                                      Pt.push(Yt.topLeftX + Yt.width / 2), Pt.push(Yt.topLeftY + Yt.height / 2);
                                    } else
                                      Pt.push(X[it].xCoords[Ht]), Pt.push(X[it].yCoords[Ht]);
                                    mt.edges.push({ startX: Ut[0], startY: Ut[1], endX: Pt[0], endY: Pt[1] });
                                  } else
                                    Q[it][Et.id()] && Q[it][Dt.id()] && mt.edges.push({ startX: Q[it][Et.id()].getCenterX(), startY: Q[it][Et.id()].getCenterY(), endX: Q[it][Dt.id()].getCenterX(), endY: Q[it][Dt.id()].getCenterY() });
                              }), mt.nodes.length > 0 && (H.push(mt), w.add(it));
                            }
                          });
                          var _ = m.packComponents(H, C.randomize).shifts;
                          if (C.quality == "draft")
                            X.forEach(function(vt, it) {
                              var gt = vt.xCoords.map(function(At) {
                                return At + _[it].dx;
                              }), mt = vt.yCoords.map(function(At) {
                                return At + _[it].dy;
                              });
                              vt.xCoords = gt, vt.yCoords = mt;
                            });
                          else {
                            var ht = 0;
                            w.forEach(function(vt) {
                              Object.keys(Q[vt]).forEach(function(it) {
                                var gt = Q[vt][it];
                                gt.setCenter(gt.getCenterX() + _[ht].dx, gt.getCenterY() + _[ht].dy);
                              }), ht++;
                            });
                          }
                        }
                      } else {
                        var E = C.eles.boundingBox();
                        if (rt.push({ x: E.x1 + E.w / 2, y: E.y1 + E.h / 2 }), C.randomize) {
                          var y = s(C);
                          X.push(y);
                        }
                        C.quality == "default" || C.quality == "proof" ? (Q.push(l(C, X[0])), t.relocateComponent(rt[0], Q[0], C)) : t.relocateComponent(rt[0], X[0], C);
                      }
                    var q = function(it, gt) {
                      if (C.quality == "default" || C.quality == "proof") {
                        typeof it == "number" && (it = gt);
                        var mt = void 0, At = void 0, Ot = it.data("id");
                        return Q.forEach(function(Dt) {
                          Ot in Dt && (mt = { x: Dt[Ot].getRect().getCenterX(), y: Dt[Ot].getRect().getCenterY() }, At = Dt[Ot]);
                        }), C.nodeDimensionsIncludeLabels && (At.labelWidth && (At.labelPosHorizontal == "left" ? mt.x += At.labelWidth / 2 : At.labelPosHorizontal == "right" && (mt.x -= At.labelWidth / 2)), At.labelHeight && (At.labelPosVertical == "top" ? mt.y += At.labelHeight / 2 : At.labelPosVertical == "bottom" && (mt.y -= At.labelHeight / 2))), mt == null && (mt = { x: it.position("x"), y: it.position("y") }), {
                          x: mt.x,
                          y: mt.y
                        };
                      } else {
                        var Et = void 0;
                        return X.forEach(function(Dt) {
                          var Rt = Dt.nodeIndexes.get(it.id());
                          Rt != null && (Et = { x: Dt.xCoords[Rt], y: Dt.yCoords[Rt] });
                        }), Et == null && (Et = { x: it.position("x"), y: it.position("y") }), {
                          x: Et.x,
                          y: Et.y
                        };
                      }
                    };
                    if (C.quality == "default" || C.quality == "proof" || C.randomize) {
                      var It = t.calcParentsWithoutChildren(G, K), Nt = K.filter(function(vt) {
                        return vt.css("display") == "none";
                      });
                      C.eles = K.not(Nt), K.nodes().not(":parent").not(Nt).layoutPositions(S, C, q), It.length > 0 && It.forEach(function(vt) {
                        vt.position(q(vt));
                      });
                    } else
                      console.log("If randomize option is set to false, then quality option must be 'default' or 'proof'.");
                  }
                }]), v;
              }();
              a.exports = d;
            }
          ),
          /***/
          657: (
            /***/
            (a, r, e) => {
              var f = e(548), i = e(140).layoutBase.Matrix, g = e(140).layoutBase.SVD, t = function(s) {
                var c = s.cy, l = s.eles, T = l.nodes(), d = l.nodes(":parent"), v = /* @__PURE__ */ new Map(), L = /* @__PURE__ */ new Map(), S = /* @__PURE__ */ new Map(), C = [], G = [], K = [], X = [], Q = [], O = [], rt = [], n = [], m = void 0, p = 1e8, E = 1e-9, y = s.piTol, R = s.samplingType, M = s.nodeSeparation, F = void 0, W = function() {
                  for (var U = 0, $ = 0, J = !1; $ < F; ) {
                    U = Math.floor(Math.random() * m), J = !1;
                    for (var k = 0; k < $; k++)
                      if (X[k] == U) {
                        J = !0;
                        break;
                      }
                    if (!J)
                      X[$] = U, $++;
                    else
                      continue;
                  }
                }, x = function(U, $, J) {
                  for (var k = [], at = 0, ct = 0, nt = 0, tt = void 0, j = [], ut = 0, Mt = 1, pt = 0; pt < m; pt++)
                    j[pt] = p;
                  for (k[ct] = U, j[U] = 0; ct >= at; ) {
                    nt = k[at++];
                    for (var xt = C[nt], lt = 0; lt < xt.length; lt++)
                      tt = L.get(xt[lt]), j[tt] == p && (j[tt] = j[nt] + 1, k[++ct] = tt);
                    O[nt][$] = j[nt] * M;
                  }
                  if (J) {
                    for (var ot = 0; ot < m; ot++)
                      O[ot][$] < Q[ot] && (Q[ot] = O[ot][$]);
                    for (var Lt = 0; Lt < m; Lt++)
                      Q[Lt] > ut && (ut = Q[Lt], Mt = Lt);
                  }
                  return Mt;
                }, Z = function(U) {
                  var $ = void 0;
                  if (U) {
                    $ = Math.floor(Math.random() * m);
                    for (var k = 0; k < m; k++)
                      Q[k] = p;
                    for (var at = 0; at < F; at++)
                      X[at] = $, $ = x($, at, U);
                  } else {
                    W();
                    for (var J = 0; J < F; J++)
                      x(X[J], J, U);
                  }
                  for (var ct = 0; ct < m; ct++)
                    for (var nt = 0; nt < F; nt++)
                      O[ct][nt] *= O[ct][nt];
                  for (var tt = 0; tt < F; tt++)
                    rt[tt] = [];
                  for (var j = 0; j < F; j++)
                    for (var ut = 0; ut < F; ut++)
                      rt[j][ut] = O[X[ut]][j];
                }, V = function() {
                  for (var U = g.svd(rt), $ = U.S, J = U.U, k = U.V, at = $[0] * $[0] * $[0], ct = [], nt = 0; nt < F; nt++) {
                    ct[nt] = [];
                    for (var tt = 0; tt < F; tt++)
                      ct[nt][tt] = 0, nt == tt && (ct[nt][tt] = $[nt] / ($[nt] * $[nt] + at / ($[nt] * $[nt])));
                  }
                  n = i.multMat(i.multMat(k, ct), i.transpose(J));
                }, Y = function() {
                  for (var U = void 0, $ = void 0, J = [], k = [], at = [], ct = [], nt = 0; nt < m; nt++)
                    J[nt] = Math.random(), k[nt] = Math.random();
                  J = i.normalize(J), k = i.normalize(k);
                  for (var tt = E, j = E, ut = void 0; ; ) {
                    for (var Mt = 0; Mt < m; Mt++)
                      at[Mt] = J[Mt];
                    if (J = i.multGamma(i.multL(i.multGamma(at), O, n)), U = i.dotProduct(at, J), J = i.normalize(J), tt = i.dotProduct(at, J), ut = Math.abs(tt / j), ut <= 1 + y && ut >= 1)
                      break;
                    j = tt;
                  }
                  for (var pt = 0; pt < m; pt++)
                    at[pt] = J[pt];
                  for (j = E; ; ) {
                    for (var xt = 0; xt < m; xt++)
                      ct[xt] = k[xt];
                    if (ct = i.minusOp(ct, i.multCons(at, i.dotProduct(at, ct))), k = i.multGamma(i.multL(i.multGamma(ct), O, n)), $ = i.dotProduct(ct, k), k = i.normalize(k), tt = i.dotProduct(ct, k), ut = Math.abs(tt / j), ut <= 1 + y && ut >= 1)
                      break;
                    j = tt;
                  }
                  for (var lt = 0; lt < m; lt++)
                    ct[lt] = k[lt];
                  G = i.multCons(at, Math.sqrt(Math.abs(U))), K = i.multCons(ct, Math.sqrt(Math.abs($)));
                };
                f.connectComponents(c, l, f.getTopMostNodes(T), v), d.forEach(function(b) {
                  f.connectComponents(c, l, f.getTopMostNodes(b.descendants().intersection(l)), v);
                });
                for (var et = 0, z = 0; z < T.length; z++)
                  T[z].isParent() || L.set(T[z].id(), et++);
                var w = !0, H = !1, B = void 0;
                try {
                  for (var _ = v.keys()[Symbol.iterator](), ht; !(w = (ht = _.next()).done); w = !0) {
                    var q = ht.value;
                    L.set(q, et++);
                  }
                } catch (b) {
                  H = !0, B = b;
                } finally {
                  try {
                    !w && _.return && _.return();
                  } finally {
                    if (H)
                      throw B;
                  }
                }
                for (var It = 0; It < L.size; It++)
                  C[It] = [];
                d.forEach(function(b) {
                  for (var U = b.children().intersection(l); U.nodes(":childless").length == 0; )
                    U = U.nodes()[0].children().intersection(l);
                  var $ = 0, J = U.nodes(":childless")[0].connectedEdges().length;
                  U.nodes(":childless").forEach(function(k, at) {
                    k.connectedEdges().length < J && (J = k.connectedEdges().length, $ = at);
                  }), S.set(b.id(), U.nodes(":childless")[$].id());
                }), T.forEach(function(b) {
                  var U = void 0;
                  b.isParent() ? U = L.get(S.get(b.id())) : U = L.get(b.id()), b.neighborhood().nodes().forEach(function($) {
                    l.intersection(b.edgesWith($)).length > 0 && ($.isParent() ? C[U].push(S.get($.id())) : C[U].push($.id()));
                  });
                });
                var Nt = function(U) {
                  var $ = L.get(U), J = void 0;
                  v.get(U).forEach(function(k) {
                    c.getElementById(k).isParent() ? J = S.get(k) : J = k, C[$].push(J), C[L.get(J)].push(U);
                  });
                }, vt = !0, it = !1, gt = void 0;
                try {
                  for (var mt = v.keys()[Symbol.iterator](), At; !(vt = (At = mt.next()).done); vt = !0) {
                    var Ot = At.value;
                    Nt(Ot);
                  }
                } catch (b) {
                  it = !0, gt = b;
                } finally {
                  try {
                    !vt && mt.return && mt.return();
                  } finally {
                    if (it)
                      throw gt;
                  }
                }
                m = L.size;
                var Et = void 0;
                if (m > 2) {
                  F = m < s.sampleSize ? m : s.sampleSize;
                  for (var Dt = 0; Dt < m; Dt++)
                    O[Dt] = [];
                  for (var Rt = 0; Rt < F; Rt++)
                    n[Rt] = [];
                  return s.quality == "draft" || s.step == "all" ? (Z(R), V(), Y(), Et = { nodeIndexes: L, xCoords: G, yCoords: K }) : (L.forEach(function(b, U) {
                    G.push(c.getElementById(U).position("x")), K.push(c.getElementById(U).position("y"));
                  }), Et = { nodeIndexes: L, xCoords: G, yCoords: K }), Et;
                } else {
                  var Ht = L.keys(), Ut = c.getElementById(Ht.next().value), Pt = Ut.position(), Ft = Ut.outerWidth();
                  if (G.push(Pt.x), K.push(Pt.y), m == 2) {
                    var Yt = c.getElementById(Ht.next().value), Vt = Yt.outerWidth();
                    G.push(Pt.x + Ft / 2 + Vt / 2 + s.idealEdgeLength), K.push(Pt.y);
                  }
                  return Et = { nodeIndexes: L, xCoords: G, yCoords: K }, Et;
                }
              };
              a.exports = { spectralLayout: t };
            }
          ),
          /***/
          579: (
            /***/
            (a, r, e) => {
              var f = e(212), i = function(t) {
                t && t("layout", "fcose", f);
              };
              typeof cytoscape < "u" && i(cytoscape), a.exports = i;
            }
          ),
          /***/
          140: (
            /***/
            (a) => {
              a.exports = A;
            }
          )
          /******/
        }, N = {};
        function u(a) {
          var r = N[a];
          if (r !== void 0)
            return r.exports;
          var e = N[a] = {
            /******/
            // no module.id needed
            /******/
            // no module.loaded needed
            /******/
            exports: {}
            /******/
          };
          return P[a](e, e.exports, u), e.exports;
        }
        var h = u(579);
        return h;
      })()
    );
  });
})(Fe);
var dr = Fe.exports;
const vr = /* @__PURE__ */ cr(dr);
var De = {
  L: "left",
  R: "right",
  T: "top",
  B: "bottom"
}, xe = {
  L: /* @__PURE__ */ dt((I) => `${I},${I / 2} 0,${I} 0,0`, "L"),
  R: /* @__PURE__ */ dt((I) => `0,${I / 2} ${I},0 ${I},${I}`, "R"),
  T: /* @__PURE__ */ dt((I) => `0,0 ${I},0 ${I / 2},${I}`, "T"),
  B: /* @__PURE__ */ dt((I) => `${I / 2},0 ${I},${I} 0,${I}`, "B")
}, se = {
  L: /* @__PURE__ */ dt((I, D) => I - D + 2, "L"),
  R: /* @__PURE__ */ dt((I, D) => I - 2, "R"),
  T: /* @__PURE__ */ dt((I, D) => I - D + 2, "T"),
  B: /* @__PURE__ */ dt((I, D) => I - 2, "B")
}, pr = /* @__PURE__ */ dt(function(I) {
  return Wt(I) ? I === "L" ? "R" : "L" : I === "T" ? "B" : "T";
}, "getOppositeArchitectureDirection"), Ie = /* @__PURE__ */ dt(function(I) {
  const D = I;
  return D === "L" || D === "R" || D === "T" || D === "B";
}, "isArchitectureDirection"), Wt = /* @__PURE__ */ dt(function(I) {
  const D = I;
  return D === "L" || D === "R";
}, "isArchitectureDirectionX"), qt = /* @__PURE__ */ dt(function(I) {
  const D = I;
  return D === "T" || D === "B";
}, "isArchitectureDirectionY"), Te = /* @__PURE__ */ dt(function(I, D) {
  const A = Wt(I) && qt(D), P = qt(I) && Wt(D);
  return A || P;
}, "isArchitectureDirectionXY"), yr = /* @__PURE__ */ dt(function(I) {
  const D = I[0], A = I[1], P = Wt(D) && qt(A), N = qt(D) && Wt(A);
  return P || N;
}, "isArchitecturePairXY"), Er = /* @__PURE__ */ dt(function(I) {
  return I !== "LL" && I !== "RR" && I !== "TT" && I !== "BB";
}, "isValidArchitectureDirectionPair"), pe = /* @__PURE__ */ dt(function(I, D) {
  const A = `${I}${D}`;
  return Er(A) ? A : void 0;
}, "getArchitectureDirectionPair"), mr = /* @__PURE__ */ dt(function([I, D], A) {
  const P = A[0], N = A[1];
  return Wt(P) ? qt(N) ? [I + (P === "L" ? -1 : 1), D + (N === "T" ? 1 : -1)] : [I + (P === "L" ? -1 : 1), D] : Wt(N) ? [I + (N === "L" ? 1 : -1), D + (P === "T" ? 1 : -1)] : [I, D + (P === "T" ? 1 : -1)];
}, "shiftPositionByArchitectureDirectionPair"), Tr = /* @__PURE__ */ dt(function(I) {
  return I === "LT" || I === "TL" ? [1, 1] : I === "BL" || I === "LB" ? [1, -1] : I === "BR" || I === "RB" ? [-1, -1] : [-1, 1];
}, "getArchitectureDirectionXYFactors"), Nr = /* @__PURE__ */ dt(function(I, D) {
  return Te(I, D) ? "bend" : Wt(I) ? "horizontal" : "vertical";
}, "getArchitectureDirectionAlignment"), Lr = /* @__PURE__ */ dt(function(I) {
  return I.type === "service";
}, "isArchitectureService"), Cr = /* @__PURE__ */ dt(function(I) {
  return I.type === "junction";
}, "isArchitectureJunction"), be = /* @__PURE__ */ dt((I) => I.data(), "edgeData"), ie = /* @__PURE__ */ dt((I) => I.data(), "nodeData"), Ar = ir.architecture, ae, Pe = (ae = class {
  constructor() {
    this.nodes = {}, this.groups = {}, this.edges = [], this.registeredIds = {}, this.elements = {}, this.setAccTitle = qe, this.getAccTitle = Qe, this.setDiagramTitle = Je, this.getDiagramTitle = Ke, this.getAccDescription = je, this.setAccDescription = _e, this.clear();
  }
  clear() {
    this.nodes = {}, this.groups = {}, this.edges = [], this.registeredIds = {}, this.dataStructures = void 0, this.elements = {}, tr();
  }
  addService({
    id: D,
    icon: A,
    in: P,
    title: N,
    iconText: u
  }) {
    if (this.registeredIds[D] !== void 0)
      throw new Error(
        `The service id [${D}] is already in use by another ${this.registeredIds[D]}`
      );
    if (P !== void 0) {
      if (D === P)
        throw new Error(`The service [${D}] cannot be placed within itself`);
      if (this.registeredIds[P] === void 0)
        throw new Error(
          `The service [${D}]'s parent does not exist. Please make sure the parent is created before this service`
        );
      if (this.registeredIds[P] === "node")
        throw new Error(`The service [${D}]'s parent is not a group`);
    }
    this.registeredIds[D] = "node", this.nodes[D] = {
      id: D,
      type: "service",
      icon: A,
      iconText: u,
      title: N,
      edges: [],
      in: P
    };
  }
  getServices() {
    return Object.values(this.nodes).filter(Lr);
  }
  addJunction({ id: D, in: A }) {
    this.registeredIds[D] = "node", this.nodes[D] = {
      id: D,
      type: "junction",
      edges: [],
      in: A
    };
  }
  getJunctions() {
    return Object.values(this.nodes).filter(Cr);
  }
  getNodes() {
    return Object.values(this.nodes);
  }
  getNode(D) {
    return this.nodes[D] ?? null;
  }
  addGroup({ id: D, icon: A, in: P, title: N }) {
    var u, h, a;
    if (((u = this.registeredIds) == null ? void 0 : u[D]) !== void 0)
      throw new Error(
        `The group id [${D}] is already in use by another ${this.registeredIds[D]}`
      );
    if (P !== void 0) {
      if (D === P)
        throw new Error(`The group [${D}] cannot be placed within itself`);
      if (((h = this.registeredIds) == null ? void 0 : h[P]) === void 0)
        throw new Error(
          `The group [${D}]'s parent does not exist. Please make sure the parent is created before this group`
        );
      if (((a = this.registeredIds) == null ? void 0 : a[P]) === "node")
        throw new Error(`The group [${D}]'s parent is not a group`);
    }
    this.registeredIds[D] = "group", this.groups[D] = {
      id: D,
      icon: A,
      title: N,
      in: P
    };
  }
  getGroups() {
    return Object.values(this.groups);
  }
  addEdge({
    lhsId: D,
    rhsId: A,
    lhsDir: P,
    rhsDir: N,
    lhsInto: u,
    rhsInto: h,
    lhsGroup: a,
    rhsGroup: r,
    title: e
  }) {
    if (!Ie(P))
      throw new Error(
        `Invalid direction given for left hand side of edge ${D}--${A}. Expected (L,R,T,B) got ${String(P)}`
      );
    if (!Ie(N))
      throw new Error(
        `Invalid direction given for right hand side of edge ${D}--${A}. Expected (L,R,T,B) got ${String(N)}`
      );
    if (this.nodes[D] === void 0 && this.groups[D] === void 0)
      throw new Error(
        `The left-hand id [${D}] does not yet exist. Please create the service/group before declaring an edge to it.`
      );
    if (this.nodes[A] === void 0 && this.groups[A] === void 0)
      throw new Error(
        `The right-hand id [${A}] does not yet exist. Please create the service/group before declaring an edge to it.`
      );
    const f = this.nodes[D].in, i = this.nodes[A].in;
    if (a && f && i && f == i)
      throw new Error(
        `The left-hand id [${D}] is modified to traverse the group boundary, but the edge does not pass through two groups.`
      );
    if (r && f && i && f == i)
      throw new Error(
        `The right-hand id [${A}] is modified to traverse the group boundary, but the edge does not pass through two groups.`
      );
    const g = {
      lhsId: D,
      lhsDir: P,
      lhsInto: u,
      lhsGroup: a,
      rhsId: A,
      rhsDir: N,
      rhsInto: h,
      rhsGroup: r,
      title: e
    };
    this.edges.push(g), this.nodes[D] && this.nodes[A] && (this.nodes[D].edges.push(this.edges[this.edges.length - 1]), this.nodes[A].edges.push(this.edges[this.edges.length - 1]));
  }
  getEdges() {
    return this.edges;
  }
  /**
   * Returns the current diagram's adjacency list, spatial map, & group alignments.
   * If they have not been created, run the algorithms to generate them.
   * @returns
   */
  getDataStructures() {
    if (this.dataStructures === void 0) {
      const D = {}, A = Object.entries(this.nodes).reduce((r, [e, f]) => (r[e] = f.edges.reduce((i, g) => {
        var s, c;
        const t = (s = this.getNode(g.lhsId)) == null ? void 0 : s.in, o = (c = this.getNode(g.rhsId)) == null ? void 0 : c.in;
        if (t && o && t !== o) {
          const l = Nr(g.lhsDir, g.rhsDir);
          l !== "bend" && (D[t] ?? (D[t] = {}), D[t][o] = l, D[o] ?? (D[o] = {}), D[o][t] = l);
        }
        if (g.lhsId === e) {
          const l = pe(g.lhsDir, g.rhsDir);
          l && (i[l] = g.rhsId);
        } else {
          const l = pe(g.rhsDir, g.lhsDir);
          l && (i[l] = g.lhsId);
        }
        return i;
      }, {}), r), {}), P = Object.keys(A)[0], N = { [P]: 1 }, u = Object.keys(A).reduce(
        (r, e) => e === P ? r : { ...r, [e]: 1 },
        {}
      ), h = /* @__PURE__ */ dt((r) => {
        const e = { [r]: [0, 0] }, f = [r];
        for (; f.length > 0; ) {
          const i = f.shift();
          if (i) {
            N[i] = 1, delete u[i];
            const g = A[i], [t, o] = e[i];
            Object.entries(g).forEach(([s, c]) => {
              N[c] || (e[c] = mr(
                [t, o],
                s
              ), f.push(c));
            });
          }
        }
        return e;
      }, "BFS"), a = [h(P)];
      for (; Object.keys(u).length > 0; )
        a.push(h(Object.keys(u)[0]));
      this.dataStructures = {
        adjList: A,
        spatialMaps: a,
        groupAlignments: D
      };
    }
    return this.dataStructures;
  }
  setElementForId(D, A) {
    this.elements[D] = A;
  }
  getElementById(D) {
    return this.elements[D];
  }
  getConfig() {
    return er({
      ...Ar,
      ...rr().architecture
    });
  }
  getConfigField(D) {
    return this.getConfig()[D];
  }
}, dt(ae, "ArchitectureDB"), ae), Mr = /* @__PURE__ */ dt((I, D) => {
  lr(I, D), I.groups.map((A) => D.addGroup(A)), I.services.map((A) => D.addService({ ...A, type: "service" })), I.junctions.map((A) => D.addJunction({ ...A, type: "junction" })), I.edges.map((A) => D.addEdge(A));
}, "populateDb"), Ge = {
  parser: {
    // @ts-expect-error - ArchitectureDB is not assignable to DiagramDB
    yy: void 0
  },
  parse: /* @__PURE__ */ dt(async (I) => {
    var P;
    const D = await fr("architecture", I);
    Re.debug(D);
    const A = (P = Ge.parser) == null ? void 0 : P.yy;
    if (!(A instanceof Pe))
      throw new Error(
        "parser.parser?.yy was not a ArchitectureDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues."
      );
    Mr(D, A);
  }, "parse")
}, wr = /* @__PURE__ */ dt((I) => `
  .edge {
    stroke-width: ${I.archEdgeWidth};
    stroke: ${I.archEdgeColor};
    fill: none;
  }

  .arrow {
    fill: ${I.archEdgeArrowColor};
  }

  .node-bkg {
    fill: none;
    stroke: ${I.archGroupBorderColor};
    stroke-width: ${I.archGroupBorderWidth};
    stroke-dasharray: 8;
  }
  .node-icon-text {
    display: flex; 
    align-items: center;
  }
  
  .node-icon-text > div {
    color: #fff;
    margin: 1px;
    height: fit-content;
    text-align: center;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
  }
`, "getStyles"), Or = wr, re = /* @__PURE__ */ dt((I) => `<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/>${I}</g>`, "wrapIcon"), ne = {
  prefix: "mermaid-architecture",
  height: 80,
  width: 80,
  icons: {
    database: {
      body: re(
        '<path id="b" data-name="4" d="m20,57.86c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path id="c" data-name="3" d="m20,45.95c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path id="d" data-name="2" d="m20,34.05c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse id="e" data-name="1" cx="40" cy="22.14" rx="20" ry="7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="20" y1="57.86" x2="20" y2="22.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="60" y1="57.86" x2="60" y2="22.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>'
      )
    },
    server: {
      body: re(
        '<rect x="17.5" y="17.5" width="45" height="45" rx="2" ry="2" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="32.5" x2="62.5" y2="32.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="47.5" x2="62.5" y2="47.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><g><path d="m56.25,25c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,25c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><path d="m56.25,40c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,40c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><path d="m56.25,55c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,55c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g>'
      )
    },
    disk: {
      body: re(
        '<rect x="20" y="15" width="40" height="50" rx="1" ry="1" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="24" cy="19.17" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="56" cy="19.17" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="24" cy="60.83" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="56" cy="60.83" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="40" cy="33.75" rx="14" ry="14.58" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="40" cy="33.75" rx="4" ry="4.17" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m37.51,42.52l-4.83,13.22c-.26.71-1.1,1.02-1.76.64l-4.18-2.42c-.66-.38-.81-1.26-.33-1.84l9.01-10.8c.88-1.05,2.56-.08,2.09,1.2Z" style="fill: #fff; stroke-width: 0px;"/>'
      )
    },
    internet: {
      body: re(
        '<circle cx="40" cy="40" r="22.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="40" y1="17.5" x2="40" y2="62.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="40" x2="62.5" y2="40" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m39.99,17.51c-15.28,11.1-15.28,33.88,0,44.98" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m40.01,17.51c15.28,11.1,15.28,33.88,0,44.98" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="19.75" y1="30.1" x2="60.25" y2="30.1" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="19.75" y1="49.9" x2="60.25" y2="49.9" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>'
      )
    },
    cloud: {
      body: re(
        '<path d="m65,47.5c0,2.76-2.24,5-5,5H20c-2.76,0-5-2.24-5-5,0-1.87,1.03-3.51,2.56-4.36-.04-.21-.06-.42-.06-.64,0-2.6,2.48-4.74,5.65-4.97,1.65-4.51,6.34-7.76,11.85-7.76.86,0,1.69.08,2.5.23,2.09-1.57,4.69-2.5,7.5-2.5,6.1,0,11.19,4.38,12.28,10.17,2.14.56,3.72,2.51,3.72,4.83,0,.03,0,.07-.01.1,2.29.46,4.01,2.48,4.01,4.9Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>'
      )
    },
    unknown: hr,
    blank: {
      body: re("")
    }
  }
}, Dr = /* @__PURE__ */ dt(async function(I, D, A) {
  const P = A.getConfigField("padding"), N = A.getConfigField("iconSize"), u = N / 2, h = N / 6, a = h / 2;
  await Promise.all(
    D.edges().map(async (r) => {
      var K, X;
      const {
        source: e,
        sourceDir: f,
        sourceArrow: i,
        sourceGroup: g,
        target: t,
        targetDir: o,
        targetArrow: s,
        targetGroup: c,
        label: l
      } = be(r);
      let { x: T, y: d } = r[0].sourceEndpoint();
      const { x: v, y: L } = r[0].midpoint();
      let { x: S, y: C } = r[0].targetEndpoint();
      const G = P + 4;
      if (g && (Wt(f) ? T += f === "L" ? -G : G : d += f === "T" ? -G : G + 18), c && (Wt(o) ? S += o === "L" ? -G : G : C += o === "T" ? -G : G + 18), !g && ((K = A.getNode(e)) == null ? void 0 : K.type) === "junction" && (Wt(f) ? T += f === "L" ? u : -u : d += f === "T" ? u : -u), !c && ((X = A.getNode(t)) == null ? void 0 : X.type) === "junction" && (Wt(o) ? S += o === "L" ? u : -u : C += o === "T" ? u : -u), r[0]._private.rscratch) {
        const Q = I.insert("g");
        if (Q.insert("path").attr("d", `M ${T},${d} L ${v},${L} L${S},${C} `).attr("class", "edge").attr("id", or(e, t, { prefix: "L" })), i) {
          const O = Wt(f) ? se[f](T, h) : T - a, rt = qt(f) ? se[f](d, h) : d - a;
          Q.insert("polygon").attr("points", xe[f](h)).attr("transform", `translate(${O},${rt})`).attr("class", "arrow");
        }
        if (s) {
          const O = Wt(o) ? se[o](S, h) : S - a, rt = qt(o) ? se[o](C, h) : C - a;
          Q.insert("polygon").attr("points", xe[o](h)).attr("transform", `translate(${O},${rt})`).attr("class", "arrow");
        }
        if (l) {
          const O = Te(f, o) ? "XY" : Wt(f) ? "X" : "Y";
          let rt = 0;
          O === "X" ? rt = Math.abs(T - S) : O === "Y" ? rt = Math.abs(d - C) / 1.5 : rt = Math.abs(T - S) / 2;
          const n = Q.append("g");
          if (await Ee(
            n,
            l,
            {
              useHtmlLabels: !1,
              width: rt,
              classes: "architecture-service-label"
            },
            ye()
          ), n.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle"), O === "X")
            n.attr("transform", "translate(" + v + ", " + L + ")");
          else if (O === "Y")
            n.attr("transform", "translate(" + v + ", " + L + ") rotate(-90)");
          else if (O === "XY") {
            const m = pe(f, o);
            if (m && yr(m)) {
              const p = n.node().getBoundingClientRect(), [E, y] = Tr(m);
              n.attr("dominant-baseline", "auto").attr("transform", `rotate(${-1 * E * y * 45})`);
              const R = n.node().getBoundingClientRect();
              n.attr(
                "transform",
                `
                translate(${v}, ${L - p.height / 2})
                translate(${E * R.width / 2}, ${y * R.height / 2})
                rotate(${-1 * E * y * 45}, 0, ${p.height / 2})
              `
              );
            }
          }
        }
      }
    })
  );
}, "drawEdges"), xr = /* @__PURE__ */ dt(async function(I, D, A) {
  const N = A.getConfigField("padding") * 0.75, u = A.getConfigField("fontSize"), a = A.getConfigField("iconSize") / 2;
  await Promise.all(
    D.nodes().map(async (r) => {
      const e = ie(r);
      if (e.type === "group") {
        const { h: f, w: i, x1: g, y1: t } = r.boundingBox(), o = I.append("rect");
        o.attr("id", `group-${e.id}`).attr("x", g + a).attr("y", t + a).attr("width", i).attr("height", f).attr("class", "node-bkg");
        const s = I.append("g");
        let c = g, l = t;
        if (e.icon) {
          const T = s.append("g");
          T.html(
            `<g>${await ve(e.icon, { height: N, width: N, fallbackPrefix: ne.prefix })}</g>`
          ), T.attr(
            "transform",
            "translate(" + (c + a + 1) + ", " + (l + a + 1) + ")"
          ), c += N, l += u / 2 - 1 - 2;
        }
        if (e.label) {
          const T = s.append("g");
          await Ee(
            T,
            e.label,
            {
              useHtmlLabels: !1,
              width: i,
              classes: "architecture-service-label"
            },
            ye()
          ), T.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "start").attr("text-anchor", "start"), T.attr(
            "transform",
            "translate(" + (c + a + 4) + ", " + (l + a + 2) + ")"
          );
        }
        A.setElementForId(e.id, o);
      }
    })
  );
}, "drawGroups"), Ir = /* @__PURE__ */ dt(async function(I, D, A) {
  const P = ye();
  for (const N of A) {
    const u = D.append("g"), h = I.getConfigField("iconSize");
    if (N.title) {
      const f = u.append("g");
      await Ee(
        f,
        N.title,
        {
          useHtmlLabels: !1,
          width: h * 1.5,
          classes: "architecture-service-label"
        },
        P
      ), f.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle"), f.attr("transform", "translate(" + h / 2 + ", " + h + ")");
    }
    const a = u.append("g");
    if (N.icon)
      a.html(
        `<g>${await ve(N.icon, { height: h, width: h, fallbackPrefix: ne.prefix })}</g>`
      );
    else if (N.iconText) {
      a.html(
        `<g>${await ve("blank", { height: h, width: h, fallbackPrefix: ne.prefix })}</g>`
      );
      const g = a.append("g").append("foreignObject").attr("width", h).attr("height", h).append("div").attr("class", "node-icon-text").attr("style", `height: ${h}px;`).append("div").html(ar(N.iconText, P)), t = parseInt(
        window.getComputedStyle(g.node(), null).getPropertyValue("font-size").replace(/\D/g, "")
      ) ?? 16;
      g.attr("style", `-webkit-line-clamp: ${Math.floor((h - 2) / t)};`);
    } else
      a.append("path").attr("class", "node-bkg").attr("id", "node-" + N.id).attr(
        "d",
        `M0 ${h} v${-h} q0,-5 5,-5 h${h} q5,0 5,5 v${h} H0 Z`
      );
    u.attr("id", `service-${N.id}`).attr("class", "architecture-service");
    const { width: r, height: e } = u.node().getBBox();
    N.width = r, N.height = e, I.setElementForId(N.id, u);
  }
  return 0;
}, "drawServices"), Rr = /* @__PURE__ */ dt(function(I, D, A) {
  A.forEach((P) => {
    const N = D.append("g"), u = I.getConfigField("iconSize");
    N.append("g").append("rect").attr("id", "node-" + P.id).attr("fill-opacity", "0").attr("width", u).attr("height", u), N.attr("class", "architecture-junction");
    const { width: a, height: r } = N._groups[0][0].getBBox();
    N.width = a, N.height = r, I.setElementForId(P.id, N);
  });
}, "drawJunctions");
sr([
  {
    name: ne.prefix,
    icons: ne
  }
]);
Se.use(vr);
function Ue(I, D, A) {
  I.forEach((P) => {
    D.add({
      group: "nodes",
      data: {
        type: "service",
        id: P.id,
        icon: P.icon,
        label: P.title,
        parent: P.in,
        width: A.getConfigField("iconSize"),
        height: A.getConfigField("iconSize")
      },
      classes: "node-service"
    });
  });
}
dt(Ue, "addServices");
function Ye(I, D, A) {
  I.forEach((P) => {
    D.add({
      group: "nodes",
      data: {
        type: "junction",
        id: P.id,
        parent: P.in,
        width: A.getConfigField("iconSize"),
        height: A.getConfigField("iconSize")
      },
      classes: "node-junction"
    });
  });
}
dt(Ye, "addJunctions");
function Xe(I, D) {
  D.nodes().map((A) => {
    const P = ie(A);
    if (P.type === "group")
      return;
    P.x = A.position().x, P.y = A.position().y, I.getElementById(P.id).attr("transform", "translate(" + (P.x || 0) + "," + (P.y || 0) + ")");
  });
}
dt(Xe, "positionNodes");
function He(I, D) {
  I.forEach((A) => {
    D.add({
      group: "nodes",
      data: {
        type: "group",
        id: A.id,
        icon: A.icon,
        label: A.title,
        parent: A.in
      },
      classes: "node-group"
    });
  });
}
dt(He, "addGroups");
function We(I, D) {
  I.forEach((A) => {
    const { lhsId: P, rhsId: N, lhsInto: u, lhsGroup: h, rhsInto: a, lhsDir: r, rhsDir: e, rhsGroup: f, title: i } = A, g = Te(A.lhsDir, A.rhsDir) ? "segments" : "straight", t = {
      id: `${P}-${N}`,
      label: i,
      source: P,
      sourceDir: r,
      sourceArrow: u,
      sourceGroup: h,
      sourceEndpoint: r === "L" ? "0 50%" : r === "R" ? "100% 50%" : r === "T" ? "50% 0" : "50% 100%",
      target: N,
      targetDir: e,
      targetArrow: a,
      targetGroup: f,
      targetEndpoint: e === "L" ? "0 50%" : e === "R" ? "100% 50%" : e === "T" ? "50% 0" : "50% 100%"
    };
    D.add({
      group: "edges",
      data: t,
      classes: g
    });
  });
}
dt(We, "addEdges");
function Ve(I, D, A) {
  const P = /* @__PURE__ */ dt((a, r) => Object.entries(a).reduce(
    (e, [f, i]) => {
      var o;
      let g = 0;
      const t = Object.entries(i);
      if (t.length === 1)
        return e[f] = t[0][1], e;
      for (let s = 0; s < t.length - 1; s++)
        for (let c = s + 1; c < t.length; c++) {
          const [l, T] = t[s], [d, v] = t[c];
          if (((o = A[l]) == null ? void 0 : o[d]) === r)
            e[f] ?? (e[f] = []), e[f] = [...e[f], ...T, ...v];
          else if (l === "default" || d === "default")
            e[f] ?? (e[f] = []), e[f] = [...e[f], ...T, ...v];
          else {
            const S = `${f}-${g++}`;
            e[S] = T;
            const C = `${f}-${g++}`;
            e[C] = v;
          }
        }
      return e;
    },
    {}
  ), "flattenAlignments"), N = D.map((a) => {
    const r = {}, e = {};
    return Object.entries(a).forEach(([f, [i, g]]) => {
      var o, s, c;
      const t = ((o = I.getNode(f)) == null ? void 0 : o.in) ?? "default";
      r[g] ?? (r[g] = {}), (s = r[g])[t] ?? (s[t] = []), r[g][t].push(f), e[i] ?? (e[i] = {}), (c = e[i])[t] ?? (c[t] = []), e[i][t].push(f);
    }), {
      horiz: Object.values(P(r, "horizontal")).filter(
        (f) => f.length > 1
      ),
      vert: Object.values(P(e, "vertical")).filter(
        (f) => f.length > 1
      )
    };
  }), [u, h] = N.reduce(
    ([a, r], { horiz: e, vert: f }) => [
      [...a, ...e],
      [...r, ...f]
    ],
    [[], []]
  );
  return {
    horizontal: u,
    vertical: h
  };
}
dt(Ve, "getAlignments");
function ze(I, D) {
  const A = [], P = /* @__PURE__ */ dt((u) => `${u[0]},${u[1]}`, "posToStr"), N = /* @__PURE__ */ dt((u) => u.split(",").map((h) => parseInt(h)), "strToPos");
  return I.forEach((u) => {
    const h = Object.fromEntries(
      Object.entries(u).map(([f, i]) => [P(i), f])
    ), a = [P([0, 0])], r = {}, e = {
      L: [-1, 0],
      R: [1, 0],
      T: [0, 1],
      B: [0, -1]
    };
    for (; a.length > 0; ) {
      const f = a.shift();
      if (f) {
        r[f] = 1;
        const i = h[f];
        if (i) {
          const g = N(f);
          Object.entries(e).forEach(([t, o]) => {
            const s = P([g[0] + o[0], g[1] + o[1]]), c = h[s];
            c && !r[s] && (a.push(s), A.push({
              [De[t]]: c,
              [De[pr(t)]]: i,
              gap: 1.5 * D.getConfigField("iconSize")
            }));
          });
        }
      }
    }
  }), A;
}
dt(ze, "getRelativeConstraints");
function Be(I, D, A, P, N, { spatialMaps: u, groupAlignments: h }) {
  return new Promise((a) => {
    const r = nr("body").append("div").attr("id", "cy").attr("style", "display:none"), e = Se({
      container: document.getElementById("cy"),
      style: [
        {
          selector: "edge",
          style: {
            "curve-style": "straight",
            label: "data(label)",
            "source-endpoint": "data(sourceEndpoint)",
            "target-endpoint": "data(targetEndpoint)"
          }
        },
        {
          selector: "edge.segments",
          style: {
            "curve-style": "segments",
            "segment-weights": "0",
            "segment-distances": [0.5],
            // @ts-ignore Incorrect library types
            "edge-distances": "endpoints",
            "source-endpoint": "data(sourceEndpoint)",
            "target-endpoint": "data(targetEndpoint)"
          }
        },
        {
          selector: "node",
          style: {
            // @ts-ignore Incorrect library types
            "compound-sizing-wrt-labels": "include"
          }
        },
        {
          selector: "node[label]",
          style: {
            "text-valign": "bottom",
            "text-halign": "center",
            "font-size": `${N.getConfigField("fontSize")}px`
          }
        },
        {
          selector: ".node-service",
          style: {
            label: "data(label)",
            width: "data(width)",
            height: "data(height)"
          }
        },
        {
          selector: ".node-junction",
          style: {
            width: "data(width)",
            height: "data(height)"
          }
        },
        {
          selector: ".node-group",
          style: {
            // @ts-ignore Incorrect library types
            padding: `${N.getConfigField("padding")}px`
          }
        }
      ],
      layout: {
        name: "grid",
        boundingBox: {
          x1: 0,
          x2: 100,
          y1: 0,
          y2: 100
        }
      }
    });
    r.remove(), He(A, e), Ue(I, e, N), Ye(D, e, N), We(P, e);
    const f = Ve(N, u, h), i = ze(u, N), g = e.layout({
      name: "fcose",
      quality: "proof",
      styleEnabled: !1,
      animate: !1,
      nodeDimensionsIncludeLabels: !1,
      // Adjust the edge parameters if it passes through the border of a group
      // Hacky fix for: https://github.com/iVis-at-Bilkent/cytoscape.js-fcose/issues/67
      idealEdgeLength(t) {
        const [o, s] = t.connectedNodes(), { parent: c } = ie(o), { parent: l } = ie(s);
        return c === l ? 1.5 * N.getConfigField("iconSize") : 0.5 * N.getConfigField("iconSize");
      },
      edgeElasticity(t) {
        const [o, s] = t.connectedNodes(), { parent: c } = ie(o), { parent: l } = ie(s);
        return c === l ? 0.45 : 1e-3;
      },
      alignmentConstraint: f,
      relativePlacementConstraint: i
    });
    g.one("layoutstop", () => {
      var o;
      function t(s, c, l, T) {
        let d, v;
        const { x: L, y: S } = s, { x: C, y: G } = c;
        v = (T - S + (L - l) * (S - G) / (L - C)) / Math.sqrt(1 + Math.pow((S - G) / (L - C), 2)), d = Math.sqrt(Math.pow(T - S, 2) + Math.pow(l - L, 2) - Math.pow(v, 2));
        const K = Math.sqrt(Math.pow(C - L, 2) + Math.pow(G - S, 2));
        d = d / K;
        let X = (C - L) * (T - S) - (G - S) * (l - L);
        switch (!0) {
          case X >= 0:
            X = 1;
            break;
          case X < 0:
            X = -1;
            break;
        }
        let Q = (C - L) * (l - L) + (G - S) * (T - S);
        switch (!0) {
          case Q >= 0:
            Q = 1;
            break;
          case Q < 0:
            Q = -1;
            break;
        }
        return v = Math.abs(v) * X, d = d * Q, {
          distances: v,
          weights: d
        };
      }
      dt(t, "getSegmentWeights"), e.startBatch();
      for (const s of Object.values(e.edges()))
        if ((o = s.data) != null && o.call(s)) {
          const { x: c, y: l } = s.source().position(), { x: T, y: d } = s.target().position();
          if (c !== T && l !== d) {
            const v = s.sourceEndpoint(), L = s.targetEndpoint(), { sourceDir: S } = be(s), [C, G] = qt(S) ? [v.x, L.y] : [L.x, v.y], { weights: K, distances: X } = t(v, L, C, G);
            s.style("segment-distances", X), s.style("segment-weights", K);
          }
        }
      e.endBatch(), g.run();
    }), g.run(), e.ready((t) => {
      Re.info("Ready", t), a(e);
    });
  });
}
dt(Be, "layoutArchitecture");
var Sr = /* @__PURE__ */ dt(async (I, D, A, P) => {
  const N = P.db, u = N.getServices(), h = N.getJunctions(), a = N.getGroups(), r = N.getEdges(), e = N.getDataStructures(), f = ke(D), i = f.append("g");
  i.attr("class", "architecture-edges");
  const g = f.append("g");
  g.attr("class", "architecture-services");
  const t = f.append("g");
  t.attr("class", "architecture-groups"), await Ir(N, g, u), Rr(N, g, h);
  const o = await Be(u, h, a, r, N, e);
  await Dr(i, o, N), await xr(t, o, N), Xe(N, o), Ze(void 0, f, N.getConfigField("padding"), N.getConfigField("useMaxWidth"));
}, "draw"), Fr = { draw: Sr }, Xr = {
  parser: Ge,
  get db() {
    return new Pe();
  },
  renderer: Fr,
  styles: Or
};
export {
  Xr as diagram
};
