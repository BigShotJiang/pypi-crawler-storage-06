import { I as f } from "./Index-Dxzk1Xy0.js";
export {
  f as default
};
