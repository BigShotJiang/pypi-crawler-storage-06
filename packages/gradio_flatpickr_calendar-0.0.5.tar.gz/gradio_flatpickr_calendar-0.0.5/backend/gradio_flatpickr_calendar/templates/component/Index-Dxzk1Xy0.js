var Ra = Object.defineProperty;
var on = (n) => {
  throw TypeError(n);
};
var Ha = (n, t, e) => t in n ? Ra(n, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : n[t] = e;
var U = (n, t, e) => Ha(n, typeof t != "symbol" ? t + "" : t, e), za = (n, t, e) => t.has(n) || on("Cannot " + e);
var sn = (n, t, e) => t.has(n) ? on("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(n) : t.set(n, e);
var tt = (n, t, e) => (za(n, t, "access private method"), e);
const {
  SvelteComponent: ja,
  append: qt,
  assign: Ya,
  attr: J,
  binding_callbacks: Ga,
  create_slot: Ua,
  detach: We,
  element: qn,
  empty: Wa,
  get_all_dirty_from_scope: Za,
  get_slot_changes: Ka,
  get_spread_update: Va,
  init: Xa,
  insert: Ze,
  listen: Ja,
  noop: Qa,
  safe_not_equal: ei,
  set_dynamic_element_data: ln,
  set_style: H,
  space: On,
  svg_element: $t,
  toggle_class: V,
  transition_in: Ln,
  transition_out: Pn,
  update_slot_base: ti
} = window.__gradio__svelte__internal;
function un(n) {
  let t, e, a, i, r;
  return {
    c() {
      t = $t("svg"), e = $t("line"), a = $t("line"), J(e, "x1", "1"), J(e, "y1", "9"), J(e, "x2", "9"), J(e, "y2", "1"), J(e, "stroke", "gray"), J(e, "stroke-width", "0.5"), J(a, "x1", "5"), J(a, "y1", "9"), J(a, "x2", "9"), J(a, "y2", "5"), J(a, "stroke", "gray"), J(a, "stroke-width", "0.5"), J(t, "class", "resize-handle svelte-239wnu"), J(t, "xmlns", "http://www.w3.org/2000/svg"), J(t, "viewBox", "0 0 10 10");
    },
    m(o, u) {
      Ze(o, t, u), qt(t, e), qt(t, a), i || (r = Ja(
        t,
        "mousedown",
        /*resize*/
        n[27]
      ), i = !0);
    },
    p: Qa,
    d(o) {
      o && We(t), i = !1, r();
    }
  };
}
function ni(n) {
  var C;
  let t, e, a, i, r;
  const o = (
    /*#slots*/
    n[31].default
  ), u = Ua(
    o,
    n,
    /*$$scope*/
    n[30],
    null
  );
  let c = (
    /*resizable*/
    n[19] && un(n)
  ), b = [
    { "data-testid": (
      /*test_id*/
      n[11]
    ) },
    { id: (
      /*elem_id*/
      n[6]
    ) },
    {
      class: a = "block " + /*elem_classes*/
      (((C = n[7]) == null ? void 0 : C.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      n[20] ? "rtl" : "ltr"
    }
  ], _ = {};
  for (let f = 0; f < b.length; f += 1)
    _ = Ya(_, b[f]);
  return {
    c() {
      t = qn(
        /*tag*/
        n[25]
      ), u && u.c(), e = On(), c && c.c(), ln(
        /*tag*/
        n[25]
      )(t, _), V(
        t,
        "hidden",
        /*visible*/
        n[14] === !1 || /*visible*/
        n[14] === "hidden"
      ), V(
        t,
        "padded",
        /*padding*/
        n[10]
      ), V(
        t,
        "flex",
        /*flex*/
        n[1]
      ), V(
        t,
        "border_focus",
        /*border_mode*/
        n[9] === "focus"
      ), V(
        t,
        "border_contrast",
        /*border_mode*/
        n[9] === "contrast"
      ), V(t, "hide-container", !/*explicit_call*/
      n[12] && !/*container*/
      n[13]), V(
        t,
        "fullscreen",
        /*fullscreen*/
        n[0]
      ), V(
        t,
        "animating",
        /*fullscreen*/
        n[0] && /*preexpansionBoundingRect*/
        n[24] !== null
      ), V(
        t,
        "auto-margin",
        /*scale*/
        n[17] === null
      ), H(
        t,
        "height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*height*/
            n[2]
          )
        )
      ), H(
        t,
        "min-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*min_height*/
            n[3]
          )
        )
      ), H(
        t,
        "max-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*max_height*/
            n[4]
          )
        )
      ), H(
        t,
        "--start-top",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].top}px` : "0px"
      ), H(
        t,
        "--start-left",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].left}px` : "0px"
      ), H(
        t,
        "--start-width",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].width}px` : "0px"
      ), H(
        t,
        "--start-height",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].height}px` : "0px"
      ), H(
        t,
        "width",
        /*fullscreen*/
        n[0] ? void 0 : typeof /*width*/
        n[5] == "number" ? `calc(min(${/*width*/
        n[5]}px, 100%))` : (
          /*get_dimension*/
          n[26](
            /*width*/
            n[5]
          )
        )
      ), H(
        t,
        "border-style",
        /*variant*/
        n[8]
      ), H(
        t,
        "overflow",
        /*allow_overflow*/
        n[15] ? (
          /*overflow_behavior*/
          n[16]
        ) : "hidden"
      ), H(
        t,
        "flex-grow",
        /*scale*/
        n[17]
      ), H(t, "min-width", `calc(min(${/*min_width*/
      n[18]}px, 100%))`), H(t, "border-width", "var(--block-border-width)");
    },
    m(f, w) {
      Ze(f, t, w), u && u.m(t, null), qt(t, e), c && c.m(t, null), n[32](t), r = !0;
    },
    p(f, w) {
      var O;
      u && u.p && (!r || w[0] & /*$$scope*/
      1073741824) && ti(
        u,
        o,
        f,
        /*$$scope*/
        f[30],
        r ? Ka(
          o,
          /*$$scope*/
          f[30],
          w,
          null
        ) : Za(
          /*$$scope*/
          f[30]
        ),
        null
      ), /*resizable*/
      f[19] ? c ? c.p(f, w) : (c = un(f), c.c(), c.m(t, null)) : c && (c.d(1), c = null), ln(
        /*tag*/
        f[25]
      )(t, _ = Va(b, [
        (!r || w[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          f[11]
        ) },
        (!r || w[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          f[6]
        ) },
        (!r || w[0] & /*elem_classes*/
        128 && a !== (a = "block " + /*elem_classes*/
        (((O = f[7]) == null ? void 0 : O.join(" ")) || "") + " svelte-239wnu")) && { class: a },
        (!r || w[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        f[20] ? "rtl" : "ltr")) && { dir: i }
      ])), V(
        t,
        "hidden",
        /*visible*/
        f[14] === !1 || /*visible*/
        f[14] === "hidden"
      ), V(
        t,
        "padded",
        /*padding*/
        f[10]
      ), V(
        t,
        "flex",
        /*flex*/
        f[1]
      ), V(
        t,
        "border_focus",
        /*border_mode*/
        f[9] === "focus"
      ), V(
        t,
        "border_contrast",
        /*border_mode*/
        f[9] === "contrast"
      ), V(t, "hide-container", !/*explicit_call*/
      f[12] && !/*container*/
      f[13]), V(
        t,
        "fullscreen",
        /*fullscreen*/
        f[0]
      ), V(
        t,
        "animating",
        /*fullscreen*/
        f[0] && /*preexpansionBoundingRect*/
        f[24] !== null
      ), V(
        t,
        "auto-margin",
        /*scale*/
        f[17] === null
      ), w[0] & /*fullscreen, height*/
      5 && H(
        t,
        "height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*height*/
            f[2]
          )
        )
      ), w[0] & /*fullscreen, min_height*/
      9 && H(
        t,
        "min-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*min_height*/
            f[3]
          )
        )
      ), w[0] & /*fullscreen, max_height*/
      17 && H(
        t,
        "max-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*max_height*/
            f[4]
          )
        )
      ), w[0] & /*preexpansionBoundingRect*/
      16777216 && H(
        t,
        "--start-top",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].top}px` : "0px"
      ), w[0] & /*preexpansionBoundingRect*/
      16777216 && H(
        t,
        "--start-left",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].left}px` : "0px"
      ), w[0] & /*preexpansionBoundingRect*/
      16777216 && H(
        t,
        "--start-width",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].width}px` : "0px"
      ), w[0] & /*preexpansionBoundingRect*/
      16777216 && H(
        t,
        "--start-height",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].height}px` : "0px"
      ), w[0] & /*fullscreen, width*/
      33 && H(
        t,
        "width",
        /*fullscreen*/
        f[0] ? void 0 : typeof /*width*/
        f[5] == "number" ? `calc(min(${/*width*/
        f[5]}px, 100%))` : (
          /*get_dimension*/
          f[26](
            /*width*/
            f[5]
          )
        )
      ), w[0] & /*variant*/
      256 && H(
        t,
        "border-style",
        /*variant*/
        f[8]
      ), w[0] & /*allow_overflow, overflow_behavior*/
      98304 && H(
        t,
        "overflow",
        /*allow_overflow*/
        f[15] ? (
          /*overflow_behavior*/
          f[16]
        ) : "hidden"
      ), w[0] & /*scale*/
      131072 && H(
        t,
        "flex-grow",
        /*scale*/
        f[17]
      ), w[0] & /*min_width*/
      262144 && H(t, "min-width", `calc(min(${/*min_width*/
      f[18]}px, 100%))`);
    },
    i(f) {
      r || (Ln(u, f), r = !0);
    },
    o(f) {
      Pn(u, f), r = !1;
    },
    d(f) {
      f && We(t), u && u.d(f), c && c.d(), n[32](null);
    }
  };
}
function cn(n) {
  let t;
  return {
    c() {
      t = qn("div"), J(t, "class", "placeholder svelte-239wnu"), H(
        t,
        "height",
        /*placeholder_height*/
        n[22] + "px"
      ), H(
        t,
        "width",
        /*placeholder_width*/
        n[23] + "px"
      );
    },
    m(e, a) {
      Ze(e, t, a);
    },
    p(e, a) {
      a[0] & /*placeholder_height*/
      4194304 && H(
        t,
        "height",
        /*placeholder_height*/
        e[22] + "px"
      ), a[0] & /*placeholder_width*/
      8388608 && H(
        t,
        "width",
        /*placeholder_width*/
        e[23] + "px"
      );
    },
    d(e) {
      e && We(t);
    }
  };
}
function ai(n) {
  let t, e, a, i = (
    /*tag*/
    n[25] && ni(n)
  ), r = (
    /*fullscreen*/
    n[0] && cn(n)
  );
  return {
    c() {
      i && i.c(), t = On(), r && r.c(), e = Wa();
    },
    m(o, u) {
      i && i.m(o, u), Ze(o, t, u), r && r.m(o, u), Ze(o, e, u), a = !0;
    },
    p(o, u) {
      /*tag*/
      o[25] && i.p(o, u), /*fullscreen*/
      o[0] ? r ? r.p(o, u) : (r = cn(o), r.c(), r.m(e.parentNode, e)) : r && (r.d(1), r = null);
    },
    i(o) {
      a || (Ln(i, o), a = !0);
    },
    o(o) {
      Pn(i, o), a = !1;
    },
    d(o) {
      o && (We(t), We(e)), i && i.d(o), r && r.d(o);
    }
  };
}
function ii(n, t, e) {
  let { $$slots: a = {}, $$scope: i } = t, { height: r = void 0 } = t, { min_height: o = void 0 } = t, { max_height: u = void 0 } = t, { width: c = void 0 } = t, { elem_id: b = "" } = t, { elem_classes: _ = [] } = t, { variant: C = "solid" } = t, { border_mode: f = "base" } = t, { padding: w = !0 } = t, { type: O = "normal" } = t, { test_id: k = void 0 } = t, { explicit_call: B = !1 } = t, { container: P = !0 } = t, { visible: g = !0 } = t, { allow_overflow: p = !0 } = t, { overflow_behavior: F = "auto" } = t, { scale: m = null } = t, { min_width: D = 0 } = t, { flex: v = !1 } = t, { resizable: S = !1 } = t, { rtl: E = !1 } = t, { fullscreen: T = !1 } = t, Y = T, R, ie = O === "fieldset" ? "fieldset" : "div", we = 0, Fe = 0, Ce = null;
  function $e(A) {
    T && A.key === "Escape" && e(0, T = !1);
  }
  const Z = (A) => {
    if (A !== void 0) {
      if (typeof A == "number")
        return A + "px";
      if (typeof A == "string")
        return A;
    }
  }, ee = (A) => {
    let X = A.clientY;
    const Te = (ne) => {
      const ge = ne.clientY - X;
      X = ne.clientY, e(21, R.style.height = `${R.offsetHeight + ge}px`, R);
    }, re = () => {
      window.removeEventListener("mousemove", Te), window.removeEventListener("mouseup", re);
    };
    window.addEventListener("mousemove", Te), window.addEventListener("mouseup", re);
  };
  function pe(A) {
    Ga[A ? "unshift" : "push"](() => {
      R = A, e(21, R);
    });
  }
  return n.$$set = (A) => {
    "height" in A && e(2, r = A.height), "min_height" in A && e(3, o = A.min_height), "max_height" in A && e(4, u = A.max_height), "width" in A && e(5, c = A.width), "elem_id" in A && e(6, b = A.elem_id), "elem_classes" in A && e(7, _ = A.elem_classes), "variant" in A && e(8, C = A.variant), "border_mode" in A && e(9, f = A.border_mode), "padding" in A && e(10, w = A.padding), "type" in A && e(28, O = A.type), "test_id" in A && e(11, k = A.test_id), "explicit_call" in A && e(12, B = A.explicit_call), "container" in A && e(13, P = A.container), "visible" in A && e(14, g = A.visible), "allow_overflow" in A && e(15, p = A.allow_overflow), "overflow_behavior" in A && e(16, F = A.overflow_behavior), "scale" in A && e(17, m = A.scale), "min_width" in A && e(18, D = A.min_width), "flex" in A && e(1, v = A.flex), "resizable" in A && e(19, S = A.resizable), "rtl" in A && e(20, E = A.rtl), "fullscreen" in A && e(0, T = A.fullscreen), "$$scope" in A && e(30, i = A.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && T !== Y && (e(29, Y = T), T ? (e(24, Ce = R.getBoundingClientRect()), e(22, we = R.offsetHeight), e(23, Fe = R.offsetWidth), window.addEventListener("keydown", $e)) : (e(24, Ce = null), window.removeEventListener("keydown", $e))), n.$$.dirty[0] & /*visible*/
    16384 && (g || e(1, v = !1));
  }, [
    T,
    v,
    r,
    o,
    u,
    c,
    b,
    _,
    C,
    f,
    w,
    k,
    B,
    P,
    g,
    p,
    F,
    m,
    D,
    S,
    E,
    R,
    we,
    Fe,
    Ce,
    ie,
    Z,
    ee,
    O,
    Y,
    i,
    a,
    pe
  ];
}
class ri extends ja {
  constructor(t) {
    super(), Xa(
      this,
      t,
      ii,
      ai,
      ei,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Ht() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Me = Ht();
function Nn(n) {
  Me = n;
}
const Rn = /[&<>"']/, oi = new RegExp(Rn.source, "g"), Hn = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, si = new RegExp(Hn.source, "g"), li = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, dn = (n) => li[n];
function ue(n, t) {
  if (t) {
    if (Rn.test(n))
      return n.replace(oi, dn);
  } else if (Hn.test(n))
    return n.replace(si, dn);
  return n;
}
const ui = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function ci(n) {
  return n.replace(ui, (t, e) => (e = e.toLowerCase(), e === "colon" ? ":" : e.charAt(0) === "#" ? e.charAt(1) === "x" ? String.fromCharCode(parseInt(e.substring(2), 16)) : String.fromCharCode(+e.substring(1)) : ""));
}
const di = /(^|[^\[])\^/g;
function j(n, t) {
  let e = typeof n == "string" ? n : n.source;
  t = t || "";
  const a = {
    replace: (i, r) => {
      let o = typeof r == "string" ? r : r.source;
      return o = o.replace(di, "$1"), e = e.replace(i, o), a;
    },
    getRegex: () => new RegExp(e, t)
  };
  return a;
}
function fn(n) {
  try {
    n = encodeURI(n).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return n;
}
const Ye = { exec: () => null };
function pn(n, t) {
  const e = n.replace(/\|/g, (r, o, u) => {
    let c = !1, b = o;
    for (; --b >= 0 && u[b] === "\\"; )
      c = !c;
    return c ? "|" : " |";
  }), a = e.split(/ \|/);
  let i = 0;
  if (a[0].trim() || a.shift(), a.length > 0 && !a[a.length - 1].trim() && a.pop(), t)
    if (a.length > t)
      a.splice(t);
    else
      for (; a.length < t; )
        a.push("");
  for (; i < a.length; i++)
    a[i] = a[i].trim().replace(/\\\|/g, "|");
  return a;
}
function nt(n, t, e) {
  const a = n.length;
  if (a === 0)
    return "";
  let i = 0;
  for (; i < a && n.charAt(a - i - 1) === t; )
    i++;
  return n.slice(0, a - i);
}
function fi(n, t) {
  if (n.indexOf(t[1]) === -1)
    return -1;
  let e = 0;
  for (let a = 0; a < n.length; a++)
    if (n[a] === "\\")
      a++;
    else if (n[a] === t[0])
      e++;
    else if (n[a] === t[1] && (e--, e < 0))
      return a;
  return -1;
}
function gn(n, t, e, a) {
  const i = t.href, r = t.title ? ue(t.title) : null, o = n[1].replace(/\\([\[\]])/g, "$1");
  if (n[0].charAt(0) !== "!") {
    a.state.inLink = !0;
    const u = {
      type: "link",
      raw: e,
      href: i,
      title: r,
      text: o,
      tokens: a.inlineTokens(o)
    };
    return a.state.inLink = !1, u;
  }
  return {
    type: "image",
    raw: e,
    href: i,
    title: r,
    text: ue(o)
  };
}
function pi(n, t) {
  const e = n.match(/^(\s+)(?:```)/);
  if (e === null)
    return t;
  const a = e[1];
  return t.split(`
`).map((i) => {
    const r = i.match(/^\s+/);
    if (r === null)
      return i;
    const [o] = r;
    return o.length >= a.length ? i.slice(a.length) : i;
  }).join(`
`);
}
class gt {
  // set by the lexer
  constructor(t) {
    U(this, "options");
    U(this, "rules");
    // set by the lexer
    U(this, "lexer");
    this.options = t || Me;
  }
  space(t) {
    const e = this.rules.block.newline.exec(t);
    if (e && e[0].length > 0)
      return {
        type: "space",
        raw: e[0]
      };
  }
  code(t) {
    const e = this.rules.block.code.exec(t);
    if (e) {
      const a = e[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: e[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? a : nt(a, `
`)
      };
    }
  }
  fences(t) {
    const e = this.rules.block.fences.exec(t);
    if (e) {
      const a = e[0], i = pi(a, e[3] || "");
      return {
        type: "code",
        raw: a,
        lang: e[2] ? e[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : e[2],
        text: i
      };
    }
  }
  heading(t) {
    const e = this.rules.block.heading.exec(t);
    if (e) {
      let a = e[2].trim();
      if (/#$/.test(a)) {
        const i = nt(a, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (a = i.trim());
      }
      return {
        type: "heading",
        raw: e[0],
        depth: e[1].length,
        text: a,
        tokens: this.lexer.inline(a)
      };
    }
  }
  hr(t) {
    const e = this.rules.block.hr.exec(t);
    if (e)
      return {
        type: "hr",
        raw: e[0]
      };
  }
  blockquote(t) {
    const e = this.rules.block.blockquote.exec(t);
    if (e) {
      let a = e[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      a = nt(a.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const r = this.lexer.blockTokens(a);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: e[0],
        tokens: r,
        text: a
      };
    }
  }
  list(t) {
    let e = this.rules.block.list.exec(t);
    if (e) {
      let a = e[1].trim();
      const i = a.length > 1, r = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +a.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      a = i ? `\\d{1,9}\\${a.slice(-1)}` : `\\${a}`, this.options.pedantic && (a = i ? a : "[*+-]");
      const o = new RegExp(`^( {0,3}${a})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let u = "", c = "", b = !1;
      for (; t; ) {
        let _ = !1;
        if (!(e = o.exec(t)) || this.rules.block.hr.test(t))
          break;
        u = e[0], t = t.substring(u.length);
        let C = e[2].split(`
`, 1)[0].replace(/^\t+/, (P) => " ".repeat(3 * P.length)), f = t.split(`
`, 1)[0], w = 0;
        this.options.pedantic ? (w = 2, c = C.trimStart()) : (w = e[2].search(/[^ ]/), w = w > 4 ? 1 : w, c = C.slice(w), w += e[1].length);
        let O = !1;
        if (!C && /^ *$/.test(f) && (u += f + `
`, t = t.substring(f.length + 1), _ = !0), !_) {
          const P = new RegExp(`^ {0,${Math.min(3, w - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), g = new RegExp(`^ {0,${Math.min(3, w - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), p = new RegExp(`^ {0,${Math.min(3, w - 1)}}(?:\`\`\`|~~~)`), F = new RegExp(`^ {0,${Math.min(3, w - 1)}}#`);
          for (; t; ) {
            const m = t.split(`
`, 1)[0];
            if (f = m, this.options.pedantic && (f = f.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), p.test(f) || F.test(f) || P.test(f) || g.test(t))
              break;
            if (f.search(/[^ ]/) >= w || !f.trim())
              c += `
` + f.slice(w);
            else {
              if (O || C.search(/[^ ]/) >= 4 || p.test(C) || F.test(C) || g.test(C))
                break;
              c += `
` + f;
            }
            !O && !f.trim() && (O = !0), u += m + `
`, t = t.substring(m.length + 1), C = f.slice(w);
          }
        }
        r.loose || (b ? r.loose = !0 : /\n *\n *$/.test(u) && (b = !0));
        let k = null, B;
        this.options.gfm && (k = /^\[[ xX]\] /.exec(c), k && (B = k[0] !== "[ ] ", c = c.replace(/^\[[ xX]\] +/, ""))), r.items.push({
          type: "list_item",
          raw: u,
          task: !!k,
          checked: B,
          loose: !1,
          text: c,
          tokens: []
        }), r.raw += u;
      }
      r.items[r.items.length - 1].raw = u.trimEnd(), r.items[r.items.length - 1].text = c.trimEnd(), r.raw = r.raw.trimEnd();
      for (let _ = 0; _ < r.items.length; _++)
        if (this.lexer.state.top = !1, r.items[_].tokens = this.lexer.blockTokens(r.items[_].text, []), !r.loose) {
          const C = r.items[_].tokens.filter((w) => w.type === "space"), f = C.length > 0 && C.some((w) => /\n.*\n/.test(w.raw));
          r.loose = f;
        }
      if (r.loose)
        for (let _ = 0; _ < r.items.length; _++)
          r.items[_].loose = !0;
      return r;
    }
  }
  html(t) {
    const e = this.rules.block.html.exec(t);
    if (e)
      return {
        type: "html",
        block: !0,
        raw: e[0],
        pre: e[1] === "pre" || e[1] === "script" || e[1] === "style",
        text: e[0]
      };
  }
  def(t) {
    const e = this.rules.block.def.exec(t);
    if (e) {
      const a = e[1].toLowerCase().replace(/\s+/g, " "), i = e[2] ? e[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", r = e[3] ? e[3].substring(1, e[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : e[3];
      return {
        type: "def",
        tag: a,
        raw: e[0],
        href: i,
        title: r
      };
    }
  }
  table(t) {
    const e = this.rules.block.table.exec(t);
    if (!e || !/[:|]/.test(e[2]))
      return;
    const a = pn(e[1]), i = e[2].replace(/^\||\| *$/g, "").split("|"), r = e[3] && e[3].trim() ? e[3].replace(/\n[ \t]*$/, "").split(`
`) : [], o = {
      type: "table",
      raw: e[0],
      header: [],
      align: [],
      rows: []
    };
    if (a.length === i.length) {
      for (const u of i)
        /^ *-+: *$/.test(u) ? o.align.push("right") : /^ *:-+: *$/.test(u) ? o.align.push("center") : /^ *:-+ *$/.test(u) ? o.align.push("left") : o.align.push(null);
      for (const u of a)
        o.header.push({
          text: u,
          tokens: this.lexer.inline(u)
        });
      for (const u of r)
        o.rows.push(pn(u, o.header.length).map((c) => ({
          text: c,
          tokens: this.lexer.inline(c)
        })));
      return o;
    }
  }
  lheading(t) {
    const e = this.rules.block.lheading.exec(t);
    if (e)
      return {
        type: "heading",
        raw: e[0],
        depth: e[2].charAt(0) === "=" ? 1 : 2,
        text: e[1],
        tokens: this.lexer.inline(e[1])
      };
  }
  paragraph(t) {
    const e = this.rules.block.paragraph.exec(t);
    if (e) {
      const a = e[1].charAt(e[1].length - 1) === `
` ? e[1].slice(0, -1) : e[1];
      return {
        type: "paragraph",
        raw: e[0],
        text: a,
        tokens: this.lexer.inline(a)
      };
    }
  }
  text(t) {
    const e = this.rules.block.text.exec(t);
    if (e)
      return {
        type: "text",
        raw: e[0],
        text: e[0],
        tokens: this.lexer.inline(e[0])
      };
  }
  escape(t) {
    const e = this.rules.inline.escape.exec(t);
    if (e)
      return {
        type: "escape",
        raw: e[0],
        text: ue(e[1])
      };
  }
  tag(t) {
    const e = this.rules.inline.tag.exec(t);
    if (e)
      return !this.lexer.state.inLink && /^<a /i.test(e[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(e[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(e[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(e[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: e[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: e[0]
      };
  }
  link(t) {
    const e = this.rules.inline.link.exec(t);
    if (e) {
      const a = e[2].trim();
      if (!this.options.pedantic && /^</.test(a)) {
        if (!/>$/.test(a))
          return;
        const o = nt(a.slice(0, -1), "\\");
        if ((a.length - o.length) % 2 === 0)
          return;
      } else {
        const o = fi(e[2], "()");
        if (o > -1) {
          const c = (e[0].indexOf("!") === 0 ? 5 : 4) + e[1].length + o;
          e[2] = e[2].substring(0, o), e[0] = e[0].substring(0, c).trim(), e[3] = "";
        }
      }
      let i = e[2], r = "";
      if (this.options.pedantic) {
        const o = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        o && (i = o[1], r = o[3]);
      } else
        r = e[3] ? e[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(a) ? i = i.slice(1) : i = i.slice(1, -1)), gn(e, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: r && r.replace(this.rules.inline.anyPunctuation, "$1")
      }, e[0], this.lexer);
    }
  }
  reflink(t, e) {
    let a;
    if ((a = this.rules.inline.reflink.exec(t)) || (a = this.rules.inline.nolink.exec(t))) {
      const i = (a[2] || a[1]).replace(/\s+/g, " "), r = e[i.toLowerCase()];
      if (!r) {
        const o = a[0].charAt(0);
        return {
          type: "text",
          raw: o,
          text: o
        };
      }
      return gn(a, r, a[0], this.lexer);
    }
  }
  emStrong(t, e, a = "") {
    let i = this.rules.inline.emStrongLDelim.exec(t);
    if (!i || i[3] && a.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !a || this.rules.inline.punctuation.exec(a)) {
      const o = [...i[0]].length - 1;
      let u, c, b = o, _ = 0;
      const C = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (C.lastIndex = 0, e = e.slice(-1 * t.length + o); (i = C.exec(e)) != null; ) {
        if (u = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !u)
          continue;
        if (c = [...u].length, i[3] || i[4]) {
          b += c;
          continue;
        } else if ((i[5] || i[6]) && o % 3 && !((o + c) % 3)) {
          _ += c;
          continue;
        }
        if (b -= c, b > 0)
          continue;
        c = Math.min(c, c + b + _);
        const f = [...i[0]][0].length, w = t.slice(0, o + i.index + f + c);
        if (Math.min(o, c) % 2) {
          const k = w.slice(1, -1);
          return {
            type: "em",
            raw: w,
            text: k,
            tokens: this.lexer.inlineTokens(k)
          };
        }
        const O = w.slice(2, -2);
        return {
          type: "strong",
          raw: w,
          text: O,
          tokens: this.lexer.inlineTokens(O)
        };
      }
    }
  }
  codespan(t) {
    const e = this.rules.inline.code.exec(t);
    if (e) {
      let a = e[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(a), r = /^ /.test(a) && / $/.test(a);
      return i && r && (a = a.substring(1, a.length - 1)), a = ue(a, !0), {
        type: "codespan",
        raw: e[0],
        text: a
      };
    }
  }
  br(t) {
    const e = this.rules.inline.br.exec(t);
    if (e)
      return {
        type: "br",
        raw: e[0]
      };
  }
  del(t) {
    const e = this.rules.inline.del.exec(t);
    if (e)
      return {
        type: "del",
        raw: e[0],
        text: e[2],
        tokens: this.lexer.inlineTokens(e[2])
      };
  }
  autolink(t) {
    const e = this.rules.inline.autolink.exec(t);
    if (e) {
      let a, i;
      return e[2] === "@" ? (a = ue(e[1]), i = "mailto:" + a) : (a = ue(e[1]), i = a), {
        type: "link",
        raw: e[0],
        text: a,
        href: i,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  url(t) {
    var a;
    let e;
    if (e = this.rules.inline.url.exec(t)) {
      let i, r;
      if (e[2] === "@")
        i = ue(e[0]), r = "mailto:" + i;
      else {
        let o;
        do
          o = e[0], e[0] = ((a = this.rules.inline._backpedal.exec(e[0])) == null ? void 0 : a[0]) ?? "";
        while (o !== e[0]);
        i = ue(e[0]), e[1] === "www." ? r = "http://" + e[0] : r = e[0];
      }
      return {
        type: "link",
        raw: e[0],
        text: i,
        href: r,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(t) {
    const e = this.rules.inline.text.exec(t);
    if (e) {
      let a;
      return this.lexer.state.inRawBlock ? a = e[0] : a = ue(e[0]), {
        type: "text",
        raw: e[0],
        text: a
      };
    }
  }
}
const gi = /^(?: *(?:\n|$))+/, hi = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, mi = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Ve = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, _i = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, zn = /(?:[*+-]|\d{1,9}[.)])/, jn = j(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, zn).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), zt = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Di = /^[^\n]+/, jt = /(?!\s*\])(?:\\.|[^\[\]\\])+/, vi = j(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", jt).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), wi = j(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, zn).getRegex(), Dt = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Yt = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, bi = j("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Yt).replace("tag", Dt).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Yn = j(zt).replace("hr", Ve).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Dt).getRegex(), Fi = j(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Yn).getRegex(), Gt = {
  blockquote: Fi,
  code: hi,
  def: vi,
  fences: mi,
  heading: _i,
  hr: Ve,
  html: bi,
  lheading: jn,
  list: wi,
  newline: gi,
  paragraph: Yn,
  table: Ye,
  text: Di
}, hn = j("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Ve).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Dt).getRegex(), Ci = {
  ...Gt,
  table: hn,
  paragraph: j(zt).replace("hr", Ve).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", hn).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Dt).getRegex()
}, $i = {
  ...Gt,
  html: j(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Yt).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Ye,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: j(zt).replace("hr", Ve).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", jn).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Gn = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, ki = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Un = /^( {2,}|\\)\n(?!\s*$)/, Ei = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Xe = "\\p{P}\\p{S}", yi = j(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Xe).getRegex(), Ai = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Si = j(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Xe).getRegex(), xi = j("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Xe).getRegex(), Mi = j("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Xe).getRegex(), Ti = j(/\\([punct])/, "gu").replace(/punct/g, Xe).getRegex(), Bi = j(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Ii = j(Yt).replace("(?:-->|$)", "-->").getRegex(), qi = j("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Ii).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), ht = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Oi = j(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", ht).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Wn = j(/^!?\[(label)\]\[(ref)\]/).replace("label", ht).replace("ref", jt).getRegex(), Zn = j(/^!?\[(ref)\](?:\[\])?/).replace("ref", jt).getRegex(), Li = j("reflink|nolink(?!\\()", "g").replace("reflink", Wn).replace("nolink", Zn).getRegex(), Ut = {
  _backpedal: Ye,
  // only used for GFM url
  anyPunctuation: Ti,
  autolink: Bi,
  blockSkip: Ai,
  br: Un,
  code: ki,
  del: Ye,
  emStrongLDelim: Si,
  emStrongRDelimAst: xi,
  emStrongRDelimUnd: Mi,
  escape: Gn,
  link: Oi,
  nolink: Zn,
  punctuation: yi,
  reflink: Wn,
  reflinkSearch: Li,
  tag: qi,
  text: Ei,
  url: Ye
}, Pi = {
  ...Ut,
  link: j(/^!?\[(label)\]\((.*?)\)/).replace("label", ht).getRegex(),
  reflink: j(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", ht).getRegex()
}, Ot = {
  ...Ut,
  escape: j(Gn).replace("])", "~|])").getRegex(),
  url: j(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Ni = {
  ...Ot,
  br: j(Un).replace("{2,}", "*").getRegex(),
  text: j(Ot.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, at = {
  normal: Gt,
  gfm: Ci,
  pedantic: $i
}, He = {
  normal: Ut,
  gfm: Ot,
  breaks: Ni,
  pedantic: Pi
};
class me {
  constructor(t) {
    U(this, "tokens");
    U(this, "options");
    U(this, "state");
    U(this, "tokenizer");
    U(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || Me, this.options.tokenizer = this.options.tokenizer || new gt(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const e = {
      block: at.normal,
      inline: He.normal
    };
    this.options.pedantic ? (e.block = at.pedantic, e.inline = He.pedantic) : this.options.gfm && (e.block = at.gfm, this.options.breaks ? e.inline = He.breaks : e.inline = He.gfm), this.tokenizer.rules = e;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: at,
      inline: He
    };
  }
  /**
   * Static Lex Method
   */
  static lex(t, e) {
    return new me(e).lex(t);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(t, e) {
    return new me(e).inlineTokens(t);
  }
  /**
   * Preprocessing
   */
  lex(t) {
    t = t.replace(/\r\n|\r/g, `
`), this.blockTokens(t, this.tokens);
    for (let e = 0; e < this.inlineQueue.length; e++) {
      const a = this.inlineQueue[e];
      this.inlineTokens(a.src, a.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, e = []) {
    this.options.pedantic ? t = t.replace(/\t/g, "    ").replace(/^ +$/gm, "") : t = t.replace(/^( *)(\t+)/gm, (u, c, b) => c + "    ".repeat(b.length));
    let a, i, r, o;
    for (; t; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((u) => (a = u.call({ lexer: this }, t, e)) ? (t = t.substring(a.raw.length), e.push(a), !0) : !1))) {
        if (a = this.tokenizer.space(t)) {
          t = t.substring(a.raw.length), a.raw.length === 1 && e.length > 0 ? e[e.length - 1].raw += `
` : e.push(a);
          continue;
        }
        if (a = this.tokenizer.code(t)) {
          t = t.substring(a.raw.length), i = e[e.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + a.raw, i.text += `
` + a.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : e.push(a);
          continue;
        }
        if (a = this.tokenizer.fences(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.heading(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.hr(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.blockquote(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.list(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.html(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.def(t)) {
          t = t.substring(a.raw.length), i = e[e.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + a.raw, i.text += `
` + a.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[a.tag] || (this.tokens.links[a.tag] = {
            href: a.href,
            title: a.title
          });
          continue;
        }
        if (a = this.tokenizer.table(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.lheading(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (r = t, this.options.extensions && this.options.extensions.startBlock) {
          let u = 1 / 0;
          const c = t.slice(1);
          let b;
          this.options.extensions.startBlock.forEach((_) => {
            b = _.call({ lexer: this }, c), typeof b == "number" && b >= 0 && (u = Math.min(u, b));
          }), u < 1 / 0 && u >= 0 && (r = t.substring(0, u + 1));
        }
        if (this.state.top && (a = this.tokenizer.paragraph(r))) {
          i = e[e.length - 1], o && i.type === "paragraph" ? (i.raw += `
` + a.raw, i.text += `
` + a.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : e.push(a), o = r.length !== t.length, t = t.substring(a.raw.length);
          continue;
        }
        if (a = this.tokenizer.text(t)) {
          t = t.substring(a.raw.length), i = e[e.length - 1], i && i.type === "text" ? (i.raw += `
` + a.raw, i.text += `
` + a.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : e.push(a);
          continue;
        }
        if (t) {
          const u = "Infinite loop on byte: " + t.charCodeAt(0);
          if (this.options.silent) {
            console.error(u);
            break;
          } else
            throw new Error(u);
        }
      }
    return this.state.top = !0, e;
  }
  inline(t, e = []) {
    return this.inlineQueue.push({ src: t, tokens: e }), e;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(t, e = []) {
    let a, i, r, o = t, u, c, b;
    if (this.tokens.links) {
      const _ = Object.keys(this.tokens.links);
      if (_.length > 0)
        for (; (u = this.tokenizer.rules.inline.reflinkSearch.exec(o)) != null; )
          _.includes(u[0].slice(u[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, u.index) + "[" + "a".repeat(u[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (u = this.tokenizer.rules.inline.blockSkip.exec(o)) != null; )
      o = o.slice(0, u.index) + "[" + "a".repeat(u[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (u = this.tokenizer.rules.inline.anyPunctuation.exec(o)) != null; )
      o = o.slice(0, u.index) + "++" + o.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; t; )
      if (c || (b = ""), c = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((_) => (a = _.call({ lexer: this }, t, e)) ? (t = t.substring(a.raw.length), e.push(a), !0) : !1))) {
        if (a = this.tokenizer.escape(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.tag(t)) {
          t = t.substring(a.raw.length), i = e[e.length - 1], i && a.type === "text" && i.type === "text" ? (i.raw += a.raw, i.text += a.text) : e.push(a);
          continue;
        }
        if (a = this.tokenizer.link(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.reflink(t, this.tokens.links)) {
          t = t.substring(a.raw.length), i = e[e.length - 1], i && a.type === "text" && i.type === "text" ? (i.raw += a.raw, i.text += a.text) : e.push(a);
          continue;
        }
        if (a = this.tokenizer.emStrong(t, o, b)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.codespan(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.br(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.del(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (a = this.tokenizer.autolink(t)) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (!this.state.inLink && (a = this.tokenizer.url(t))) {
          t = t.substring(a.raw.length), e.push(a);
          continue;
        }
        if (r = t, this.options.extensions && this.options.extensions.startInline) {
          let _ = 1 / 0;
          const C = t.slice(1);
          let f;
          this.options.extensions.startInline.forEach((w) => {
            f = w.call({ lexer: this }, C), typeof f == "number" && f >= 0 && (_ = Math.min(_, f));
          }), _ < 1 / 0 && _ >= 0 && (r = t.substring(0, _ + 1));
        }
        if (a = this.tokenizer.inlineText(r)) {
          t = t.substring(a.raw.length), a.raw.slice(-1) !== "_" && (b = a.raw.slice(-1)), c = !0, i = e[e.length - 1], i && i.type === "text" ? (i.raw += a.raw, i.text += a.text) : e.push(a);
          continue;
        }
        if (t) {
          const _ = "Infinite loop on byte: " + t.charCodeAt(0);
          if (this.options.silent) {
            console.error(_);
            break;
          } else
            throw new Error(_);
        }
      }
    return e;
  }
}
class mt {
  constructor(t) {
    U(this, "options");
    this.options = t || Me;
  }
  code(t, e, a) {
    var r;
    const i = (r = (e || "").match(/^\S*/)) == null ? void 0 : r[0];
    return t = t.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + ue(i) + '">' + (a ? t : ue(t, !0)) + `</code></pre>
` : "<pre><code>" + (a ? t : ue(t, !0)) + `</code></pre>
`;
  }
  blockquote(t) {
    return `<blockquote>
${t}</blockquote>
`;
  }
  html(t, e) {
    return t;
  }
  heading(t, e, a) {
    return `<h${e}>${t}</h${e}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(t, e, a) {
    const i = e ? "ol" : "ul", r = e && a !== 1 ? ' start="' + a + '"' : "";
    return "<" + i + r + `>
` + t + "</" + i + `>
`;
  }
  listitem(t, e, a) {
    return `<li>${t}</li>
`;
  }
  checkbox(t) {
    return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(t) {
    return `<p>${t}</p>
`;
  }
  table(t, e) {
    return e && (e = `<tbody>${e}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + e + `</table>
`;
  }
  tablerow(t) {
    return `<tr>
${t}</tr>
`;
  }
  tablecell(t, e) {
    const a = e.header ? "th" : "td";
    return (e.align ? `<${a} align="${e.align}">` : `<${a}>`) + t + `</${a}>
`;
  }
  /**
   * span level renderer
   */
  strong(t) {
    return `<strong>${t}</strong>`;
  }
  em(t) {
    return `<em>${t}</em>`;
  }
  codespan(t) {
    return `<code>${t}</code>`;
  }
  br() {
    return "<br>";
  }
  del(t) {
    return `<del>${t}</del>`;
  }
  link(t, e, a) {
    const i = fn(t);
    if (i === null)
      return a;
    t = i;
    let r = '<a href="' + t + '"';
    return e && (r += ' title="' + e + '"'), r += ">" + a + "</a>", r;
  }
  image(t, e, a) {
    const i = fn(t);
    if (i === null)
      return a;
    t = i;
    let r = `<img src="${t}" alt="${a}"`;
    return e && (r += ` title="${e}"`), r += ">", r;
  }
  text(t) {
    return t;
  }
}
class Wt {
  // no need for block level renderers
  strong(t) {
    return t;
  }
  em(t) {
    return t;
  }
  codespan(t) {
    return t;
  }
  del(t) {
    return t;
  }
  html(t) {
    return t;
  }
  text(t) {
    return t;
  }
  link(t, e, a) {
    return "" + a;
  }
  image(t, e, a) {
    return "" + a;
  }
  br() {
    return "";
  }
}
class _e {
  constructor(t) {
    U(this, "options");
    U(this, "renderer");
    U(this, "textRenderer");
    this.options = t || Me, this.options.renderer = this.options.renderer || new mt(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Wt();
  }
  /**
   * Static Parse Method
   */
  static parse(t, e) {
    return new _e(e).parse(t);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(t, e) {
    return new _e(e).parseInline(t);
  }
  /**
   * Parse Loop
   */
  parse(t, e = !0) {
    let a = "";
    for (let i = 0; i < t.length; i++) {
      const r = t[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[r.type]) {
        const o = r, u = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (u !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(o.type)) {
          a += u || "";
          continue;
        }
      }
      switch (r.type) {
        case "space":
          continue;
        case "hr": {
          a += this.renderer.hr();
          continue;
        }
        case "heading": {
          const o = r;
          a += this.renderer.heading(this.parseInline(o.tokens), o.depth, ci(this.parseInline(o.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const o = r;
          a += this.renderer.code(o.text, o.lang, !!o.escaped);
          continue;
        }
        case "table": {
          const o = r;
          let u = "", c = "";
          for (let _ = 0; _ < o.header.length; _++)
            c += this.renderer.tablecell(this.parseInline(o.header[_].tokens), { header: !0, align: o.align[_] });
          u += this.renderer.tablerow(c);
          let b = "";
          for (let _ = 0; _ < o.rows.length; _++) {
            const C = o.rows[_];
            c = "";
            for (let f = 0; f < C.length; f++)
              c += this.renderer.tablecell(this.parseInline(C[f].tokens), { header: !1, align: o.align[f] });
            b += this.renderer.tablerow(c);
          }
          a += this.renderer.table(u, b);
          continue;
        }
        case "blockquote": {
          const o = r, u = this.parse(o.tokens);
          a += this.renderer.blockquote(u);
          continue;
        }
        case "list": {
          const o = r, u = o.ordered, c = o.start, b = o.loose;
          let _ = "";
          for (let C = 0; C < o.items.length; C++) {
            const f = o.items[C], w = f.checked, O = f.task;
            let k = "";
            if (f.task) {
              const B = this.renderer.checkbox(!!w);
              b ? f.tokens.length > 0 && f.tokens[0].type === "paragraph" ? (f.tokens[0].text = B + " " + f.tokens[0].text, f.tokens[0].tokens && f.tokens[0].tokens.length > 0 && f.tokens[0].tokens[0].type === "text" && (f.tokens[0].tokens[0].text = B + " " + f.tokens[0].tokens[0].text)) : f.tokens.unshift({
                type: "text",
                text: B + " "
              }) : k += B + " ";
            }
            k += this.parse(f.tokens, b), _ += this.renderer.listitem(k, O, !!w);
          }
          a += this.renderer.list(_, u, c);
          continue;
        }
        case "html": {
          const o = r;
          a += this.renderer.html(o.text, o.block);
          continue;
        }
        case "paragraph": {
          const o = r;
          a += this.renderer.paragraph(this.parseInline(o.tokens));
          continue;
        }
        case "text": {
          let o = r, u = o.tokens ? this.parseInline(o.tokens) : o.text;
          for (; i + 1 < t.length && t[i + 1].type === "text"; )
            o = t[++i], u += `
` + (o.tokens ? this.parseInline(o.tokens) : o.text);
          a += e ? this.renderer.paragraph(u) : u;
          continue;
        }
        default: {
          const o = 'Token with "' + r.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return a;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(t, e) {
    e = e || this.renderer;
    let a = "";
    for (let i = 0; i < t.length; i++) {
      const r = t[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[r.type]) {
        const o = this.options.extensions.renderers[r.type].call({ parser: this }, r);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(r.type)) {
          a += o || "";
          continue;
        }
      }
      switch (r.type) {
        case "escape": {
          const o = r;
          a += e.text(o.text);
          break;
        }
        case "html": {
          const o = r;
          a += e.html(o.text);
          break;
        }
        case "link": {
          const o = r;
          a += e.link(o.href, o.title, this.parseInline(o.tokens, e));
          break;
        }
        case "image": {
          const o = r;
          a += e.image(o.href, o.title, o.text);
          break;
        }
        case "strong": {
          const o = r;
          a += e.strong(this.parseInline(o.tokens, e));
          break;
        }
        case "em": {
          const o = r;
          a += e.em(this.parseInline(o.tokens, e));
          break;
        }
        case "codespan": {
          const o = r;
          a += e.codespan(o.text);
          break;
        }
        case "br": {
          a += e.br();
          break;
        }
        case "del": {
          const o = r;
          a += e.del(this.parseInline(o.tokens, e));
          break;
        }
        case "text": {
          const o = r;
          a += e.text(o.text);
          break;
        }
        default: {
          const o = 'Token with "' + r.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return a;
  }
}
class Ge {
  constructor(t) {
    U(this, "options");
    this.options = t || Me;
  }
  /**
   * Process markdown before marked
   */
  preprocess(t) {
    return t;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(t) {
    return t;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(t) {
    return t;
  }
}
U(Ge, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var xe, Lt, Vn;
class Kn {
  constructor(...t) {
    sn(this, xe);
    U(this, "defaults", Ht());
    U(this, "options", this.setOptions);
    U(this, "parse", tt(this, xe, Lt).call(this, me.lex, _e.parse));
    U(this, "parseInline", tt(this, xe, Lt).call(this, me.lexInline, _e.parseInline));
    U(this, "Parser", _e);
    U(this, "Renderer", mt);
    U(this, "TextRenderer", Wt);
    U(this, "Lexer", me);
    U(this, "Tokenizer", gt);
    U(this, "Hooks", Ge);
    this.use(...t);
  }
  /**
   * Run callback for every token
   */
  walkTokens(t, e) {
    var i, r;
    let a = [];
    for (const o of t)
      switch (a = a.concat(e.call(this, o)), o.type) {
        case "table": {
          const u = o;
          for (const c of u.header)
            a = a.concat(this.walkTokens(c.tokens, e));
          for (const c of u.rows)
            for (const b of c)
              a = a.concat(this.walkTokens(b.tokens, e));
          break;
        }
        case "list": {
          const u = o;
          a = a.concat(this.walkTokens(u.items, e));
          break;
        }
        default: {
          const u = o;
          (r = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && r[u.type] ? this.defaults.extensions.childTokens[u.type].forEach((c) => {
            const b = u[c].flat(1 / 0);
            a = a.concat(this.walkTokens(b, e));
          }) : u.tokens && (a = a.concat(this.walkTokens(u.tokens, e)));
        }
      }
    return a;
  }
  use(...t) {
    const e = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return t.forEach((a) => {
      const i = { ...a };
      if (i.async = this.defaults.async || i.async || !1, a.extensions && (a.extensions.forEach((r) => {
        if (!r.name)
          throw new Error("extension name required");
        if ("renderer" in r) {
          const o = e.renderers[r.name];
          o ? e.renderers[r.name] = function(...u) {
            let c = r.renderer.apply(this, u);
            return c === !1 && (c = o.apply(this, u)), c;
          } : e.renderers[r.name] = r.renderer;
        }
        if ("tokenizer" in r) {
          if (!r.level || r.level !== "block" && r.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const o = e[r.level];
          o ? o.unshift(r.tokenizer) : e[r.level] = [r.tokenizer], r.start && (r.level === "block" ? e.startBlock ? e.startBlock.push(r.start) : e.startBlock = [r.start] : r.level === "inline" && (e.startInline ? e.startInline.push(r.start) : e.startInline = [r.start]));
        }
        "childTokens" in r && r.childTokens && (e.childTokens[r.name] = r.childTokens);
      }), i.extensions = e), a.renderer) {
        const r = this.defaults.renderer || new mt(this.defaults);
        for (const o in a.renderer) {
          if (!(o in r))
            throw new Error(`renderer '${o}' does not exist`);
          if (o === "options")
            continue;
          const u = o, c = a.renderer[u], b = r[u];
          r[u] = (..._) => {
            let C = c.apply(r, _);
            return C === !1 && (C = b.apply(r, _)), C || "";
          };
        }
        i.renderer = r;
      }
      if (a.tokenizer) {
        const r = this.defaults.tokenizer || new gt(this.defaults);
        for (const o in a.tokenizer) {
          if (!(o in r))
            throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o))
            continue;
          const u = o, c = a.tokenizer[u], b = r[u];
          r[u] = (..._) => {
            let C = c.apply(r, _);
            return C === !1 && (C = b.apply(r, _)), C;
          };
        }
        i.tokenizer = r;
      }
      if (a.hooks) {
        const r = this.defaults.hooks || new Ge();
        for (const o in a.hooks) {
          if (!(o in r))
            throw new Error(`hook '${o}' does not exist`);
          if (o === "options")
            continue;
          const u = o, c = a.hooks[u], b = r[u];
          Ge.passThroughHooks.has(o) ? r[u] = (_) => {
            if (this.defaults.async)
              return Promise.resolve(c.call(r, _)).then((f) => b.call(r, f));
            const C = c.call(r, _);
            return b.call(r, C);
          } : r[u] = (..._) => {
            let C = c.apply(r, _);
            return C === !1 && (C = b.apply(r, _)), C;
          };
        }
        i.hooks = r;
      }
      if (a.walkTokens) {
        const r = this.defaults.walkTokens, o = a.walkTokens;
        i.walkTokens = function(u) {
          let c = [];
          return c.push(o.call(this, u)), r && (c = c.concat(r.call(this, u))), c;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(t) {
    return this.defaults = { ...this.defaults, ...t }, this;
  }
  lexer(t, e) {
    return me.lex(t, e ?? this.defaults);
  }
  parser(t, e) {
    return _e.parse(t, e ?? this.defaults);
  }
}
xe = new WeakSet(), Lt = function(t, e) {
  return (a, i) => {
    const r = { ...i }, o = { ...this.defaults, ...r };
    this.defaults.async === !0 && r.async === !1 && (o.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), o.async = !0);
    const u = tt(this, xe, Vn).call(this, !!o.silent, !!o.async);
    if (typeof a > "u" || a === null)
      return u(new Error("marked(): input parameter is undefined or null"));
    if (typeof a != "string")
      return u(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(a) + ", string expected"));
    if (o.hooks && (o.hooks.options = o), o.async)
      return Promise.resolve(o.hooks ? o.hooks.preprocess(a) : a).then((c) => t(c, o)).then((c) => o.hooks ? o.hooks.processAllTokens(c) : c).then((c) => o.walkTokens ? Promise.all(this.walkTokens(c, o.walkTokens)).then(() => c) : c).then((c) => e(c, o)).then((c) => o.hooks ? o.hooks.postprocess(c) : c).catch(u);
    try {
      o.hooks && (a = o.hooks.preprocess(a));
      let c = t(a, o);
      o.hooks && (c = o.hooks.processAllTokens(c)), o.walkTokens && this.walkTokens(c, o.walkTokens);
      let b = e(c, o);
      return o.hooks && (b = o.hooks.postprocess(b)), b;
    } catch (c) {
      return u(c);
    }
  };
}, Vn = function(t, e) {
  return (a) => {
    if (a.message += `
Please report this to https://github.com/markedjs/marked.`, t) {
      const i = "<p>An error occurred:</p><pre>" + ue(a.message + "", !0) + "</pre>";
      return e ? Promise.resolve(i) : i;
    }
    if (e)
      return Promise.reject(a);
    throw a;
  };
};
const Se = new Kn();
function z(n, t) {
  return Se.parse(n, t);
}
z.options = z.setOptions = function(n) {
  return Se.setOptions(n), z.defaults = Se.defaults, Nn(z.defaults), z;
};
z.getDefaults = Ht;
z.defaults = Me;
z.use = function(...n) {
  return Se.use(...n), z.defaults = Se.defaults, Nn(z.defaults), z;
};
z.walkTokens = function(n, t) {
  return Se.walkTokens(n, t);
};
z.parseInline = Se.parseInline;
z.Parser = _e;
z.parser = _e.parse;
z.Renderer = mt;
z.TextRenderer = Wt;
z.Lexer = me;
z.lexer = me.lex;
z.Tokenizer = gt;
z.Hooks = Ge;
z.parse = z;
z.options;
z.setOptions;
z.use;
z.walkTokens;
z.parseInline;
_e.parse;
me.lex;
function Ri(n) {
  if (typeof n == "function" && (n = {
    highlight: n
  }), !n || typeof n.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof n.langPrefix != "string" && (n.langPrefix = "language-"), typeof n.emptyLangClass != "string" && (n.emptyLangClass = ""), {
    async: !!n.async,
    walkTokens(t) {
      if (t.type !== "code")
        return;
      const e = mn(t.lang);
      if (n.async)
        return Promise.resolve(n.highlight(t.text, e, t.lang || "")).then(_n(t));
      const a = n.highlight(t.text, e, t.lang || "");
      if (a instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      _n(t)(a);
    },
    useNewRenderer: !0,
    renderer: {
      code(t, e, a) {
        typeof t == "object" && (a = t.escaped, e = t.lang, t = t.text);
        const i = mn(e), r = i ? n.langPrefix + vn(i) : n.emptyLangClass, o = r ? ` class="${r}"` : "";
        return t = t.replace(/\n$/, ""), `<pre><code${o}>${a ? t : vn(t, !0)}
</code></pre>`;
      }
    }
  };
}
function mn(n) {
  return (n || "").match(/\S*/)[0];
}
function _n(n) {
  return (t) => {
    typeof t == "string" && t !== n.text && (n.escaped = !0, n.text = t);
  };
}
const Xn = /[&<>"']/, Hi = new RegExp(Xn.source, "g"), Jn = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, zi = new RegExp(Jn.source, "g"), ji = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Dn = (n) => ji[n];
function vn(n, t) {
  if (t) {
    if (Xn.test(n))
      return n.replace(Hi, Dn);
  } else if (Jn.test(n))
    return n.replace(zi, Dn);
  return n;
}
const Yi = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Gi = Object.hasOwnProperty;
class Zt {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(t, e) {
    const a = this;
    let i = Ui(t, e === !0);
    const r = i;
    for (; Gi.call(a.occurrences, i); )
      a.occurrences[r]++, i = r + "-" + a.occurrences[r];
    return a.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Ui(n, t) {
  return typeof n != "string" ? "" : (t || (n = n.toLowerCase()), n.replace(Yi, "").replace(/ /g, "-"));
}
let Qn = new Zt(), ea = [];
function Wi({ prefix: n = "", globalSlugs: t = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(e) {
        return t || Zi(), e;
      }
    },
    renderer: {
      heading(e, a, i) {
        i = i.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const r = `${n}${Qn.slug(i)}`, o = { level: a, text: e, id: r };
        return ea.push(o), `<h${a} id="${r}">${e}</h${a}>
`;
      }
    }
  };
}
function Zi() {
  ea = [], Qn = new Zt();
}
var wn = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Uo(n) {
  return n && n.__esModule && Object.prototype.hasOwnProperty.call(n, "default") ? n.default : n;
}
var ta = { exports: {} };
(function(n) {
  var t = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var e = function(a) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, r = 0, o = {}, u = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: a.Prism && a.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: a.Prism && a.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function g(p) {
          return p instanceof c ? new c(p.type, g(p.content), p.alias) : Array.isArray(p) ? p.map(g) : p.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(g) {
          return Object.prototype.toString.call(g).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(g) {
          return g.__id || Object.defineProperty(g, "__id", { value: ++r }), g.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function g(p, F) {
          F = F || {};
          var m, D;
          switch (u.util.type(p)) {
            case "Object":
              if (D = u.util.objId(p), F[D])
                return F[D];
              m = /** @type {Record<string, any>} */
              {}, F[D] = m;
              for (var v in p)
                p.hasOwnProperty(v) && (m[v] = g(p[v], F));
              return (
                /** @type {any} */
                m
              );
            case "Array":
              return D = u.util.objId(p), F[D] ? F[D] : (m = [], F[D] = m, /** @type {Array} */
              /** @type {any} */
              p.forEach(function(S, E) {
                m[E] = g(S, F);
              }), /** @type {any} */
              m);
            default:
              return p;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(g) {
          for (; g; ) {
            var p = i.exec(g.className);
            if (p)
              return p[1].toLowerCase();
            g = g.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(g, p) {
          g.className = g.className.replace(RegExp(i, "gi"), ""), g.classList.add("language-" + p);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (m) {
            var g = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(m.stack) || [])[1];
            if (g) {
              var p = document.getElementsByTagName("script");
              for (var F in p)
                if (p[F].src == g)
                  return p[F];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(g, p, F) {
          for (var m = "no-" + p; g; ) {
            var D = g.classList;
            if (D.contains(p))
              return !0;
            if (D.contains(m))
              return !1;
            g = g.parentElement;
          }
          return !!F;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(g, p) {
          var F = u.util.clone(u.languages[g]);
          for (var m in p)
            F[m] = p[m];
          return F;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(g, p, F, m) {
          m = m || /** @type {any} */
          u.languages;
          var D = m[g], v = {};
          for (var S in D)
            if (D.hasOwnProperty(S)) {
              if (S == p)
                for (var E in F)
                  F.hasOwnProperty(E) && (v[E] = F[E]);
              F.hasOwnProperty(S) || (v[S] = D[S]);
            }
          var T = m[g];
          return m[g] = v, u.languages.DFS(u.languages, function(Y, R) {
            R === T && Y != g && (this[Y] = v);
          }), v;
        },
        // Traverse a language definition with Depth First Search
        DFS: function g(p, F, m, D) {
          D = D || {};
          var v = u.util.objId;
          for (var S in p)
            if (p.hasOwnProperty(S)) {
              F.call(p, S, p[S], m || S);
              var E = p[S], T = u.util.type(E);
              T === "Object" && !D[v(E)] ? (D[v(E)] = !0, g(E, F, null, D)) : T === "Array" && !D[v(E)] && (D[v(E)] = !0, g(E, F, S, D));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(g, p) {
        u.highlightAllUnder(document, g, p);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(g, p, F) {
        var m = {
          callback: F,
          container: g,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        u.hooks.run("before-highlightall", m), m.elements = Array.prototype.slice.apply(m.container.querySelectorAll(m.selector)), u.hooks.run("before-all-elements-highlight", m);
        for (var D = 0, v; v = m.elements[D++]; )
          u.highlightElement(v, p === !0, m.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(g, p, F) {
        var m = u.util.getLanguage(g), D = u.languages[m];
        u.util.setLanguage(g, m);
        var v = g.parentElement;
        v && v.nodeName.toLowerCase() === "pre" && u.util.setLanguage(v, m);
        var S = g.textContent, E = {
          element: g,
          language: m,
          grammar: D,
          code: S
        };
        function T(R) {
          E.highlightedCode = R, u.hooks.run("before-insert", E), E.element.innerHTML = E.highlightedCode, u.hooks.run("after-highlight", E), u.hooks.run("complete", E), F && F.call(E.element);
        }
        if (u.hooks.run("before-sanity-check", E), v = E.element.parentElement, v && v.nodeName.toLowerCase() === "pre" && !v.hasAttribute("tabindex") && v.setAttribute("tabindex", "0"), !E.code) {
          u.hooks.run("complete", E), F && F.call(E.element);
          return;
        }
        if (u.hooks.run("before-highlight", E), !E.grammar) {
          T(u.util.encode(E.code));
          return;
        }
        if (p && a.Worker) {
          var Y = new Worker(u.filename);
          Y.onmessage = function(R) {
            T(R.data);
          }, Y.postMessage(JSON.stringify({
            language: E.language,
            code: E.code,
            immediateClose: !0
          }));
        } else
          T(u.highlight(E.code, E.grammar, E.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(g, p, F) {
        var m = {
          code: g,
          grammar: p,
          language: F
        };
        if (u.hooks.run("before-tokenize", m), !m.grammar)
          throw new Error('The language "' + m.language + '" has no grammar.');
        return m.tokens = u.tokenize(m.code, m.grammar), u.hooks.run("after-tokenize", m), c.stringify(u.util.encode(m.tokens), m.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(g, p) {
        var F = p.rest;
        if (F) {
          for (var m in F)
            p[m] = F[m];
          delete p.rest;
        }
        var D = new C();
        return f(D, D.head, g), _(g, D, p, D.head, 0), O(D);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(g, p) {
          var F = u.hooks.all;
          F[g] = F[g] || [], F[g].push(p);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(g, p) {
          var F = u.hooks.all[g];
          if (!(!F || !F.length))
            for (var m = 0, D; D = F[m++]; )
              D(p);
        }
      },
      Token: c
    };
    a.Prism = u;
    function c(g, p, F, m) {
      this.type = g, this.content = p, this.alias = F, this.length = (m || "").length | 0;
    }
    c.stringify = function g(p, F) {
      if (typeof p == "string")
        return p;
      if (Array.isArray(p)) {
        var m = "";
        return p.forEach(function(T) {
          m += g(T, F);
        }), m;
      }
      var D = {
        type: p.type,
        content: g(p.content, F),
        tag: "span",
        classes: ["token", p.type],
        attributes: {},
        language: F
      }, v = p.alias;
      v && (Array.isArray(v) ? Array.prototype.push.apply(D.classes, v) : D.classes.push(v)), u.hooks.run("wrap", D);
      var S = "";
      for (var E in D.attributes)
        S += " " + E + '="' + (D.attributes[E] || "").replace(/"/g, "&quot;") + '"';
      return "<" + D.tag + ' class="' + D.classes.join(" ") + '"' + S + ">" + D.content + "</" + D.tag + ">";
    };
    function b(g, p, F, m) {
      g.lastIndex = p;
      var D = g.exec(F);
      if (D && m && D[1]) {
        var v = D[1].length;
        D.index += v, D[0] = D[0].slice(v);
      }
      return D;
    }
    function _(g, p, F, m, D, v) {
      for (var S in F)
        if (!(!F.hasOwnProperty(S) || !F[S])) {
          var E = F[S];
          E = Array.isArray(E) ? E : [E];
          for (var T = 0; T < E.length; ++T) {
            if (v && v.cause == S + "," + T)
              return;
            var Y = E[T], R = Y.inside, ie = !!Y.lookbehind, we = !!Y.greedy, Fe = Y.alias;
            if (we && !Y.pattern.global) {
              var Ce = Y.pattern.toString().match(/[imsuy]*$/)[0];
              Y.pattern = RegExp(Y.pattern.source, Ce + "g");
            }
            for (var $e = Y.pattern || Y, Z = m.next, ee = D; Z !== p.tail && !(v && ee >= v.reach); ee += Z.value.length, Z = Z.next) {
              var pe = Z.value;
              if (p.length > g.length)
                return;
              if (!(pe instanceof c)) {
                var A = 1, X;
                if (we) {
                  if (X = b($e, ee, g, ie), !X || X.index >= g.length)
                    break;
                  var ge = X.index, Te = X.index + X[0].length, re = ee;
                  for (re += Z.value.length; ge >= re; )
                    Z = Z.next, re += Z.value.length;
                  if (re -= Z.value.length, ee = re, Z.value instanceof c)
                    continue;
                  for (var ne = Z; ne !== p.tail && (re < Te || typeof ne.value == "string"); ne = ne.next)
                    A++, re += ne.value.length;
                  A--, pe = g.slice(ee, re), X.index -= ee;
                } else if (X = b($e, 0, pe, ie), !X)
                  continue;
                var ge = X.index, De = X[0], de = pe.slice(0, ge), ke = pe.slice(ge + De.length), Pe = ee + pe.length;
                v && Pe > v.reach && (v.reach = Pe);
                var Ee = Z.prev;
                de && (Ee = f(p, Ee, de), ee += de.length), w(p, Ee, A);
                var Be = new c(S, R ? u.tokenize(De, R) : De, Fe, De);
                if (Z = f(p, Ee, Be), ke && f(p, Z, ke), A > 1) {
                  var Ne = {
                    cause: S + "," + T,
                    reach: Pe
                  };
                  _(g, p, F, Z.prev, ee, Ne), v && Ne.reach > v.reach && (v.reach = Ne.reach);
                }
              }
            }
          }
        }
    }
    function C() {
      var g = { value: null, prev: null, next: null }, p = { value: null, prev: g, next: null };
      g.next = p, this.head = g, this.tail = p, this.length = 0;
    }
    function f(g, p, F) {
      var m = p.next, D = { value: F, prev: p, next: m };
      return p.next = D, m.prev = D, g.length++, D;
    }
    function w(g, p, F) {
      for (var m = p.next, D = 0; D < F && m !== g.tail; D++)
        m = m.next;
      p.next = m, m.prev = p, g.length -= D;
    }
    function O(g) {
      for (var p = [], F = g.head.next; F !== g.tail; )
        p.push(F.value), F = F.next;
      return p;
    }
    if (!a.document)
      return a.addEventListener && (u.disableWorkerMessageHandler || a.addEventListener("message", function(g) {
        var p = JSON.parse(g.data), F = p.language, m = p.code, D = p.immediateClose;
        a.postMessage(u.highlight(m, u.languages[F], F)), D && a.close();
      }, !1)), u;
    var k = u.util.currentScript();
    k && (u.filename = k.src, k.hasAttribute("data-manual") && (u.manual = !0));
    function B() {
      u.manual || u.highlightAll();
    }
    if (!u.manual) {
      var P = document.readyState;
      P === "loading" || P === "interactive" && k && k.defer ? document.addEventListener("DOMContentLoaded", B) : window.requestAnimationFrame ? window.requestAnimationFrame(B) : window.setTimeout(B, 16);
    }
    return u;
  }(t);
  n.exports && (n.exports = e), typeof wn < "u" && (wn.Prism = e), e.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, e.languages.markup.tag.inside["attr-value"].inside.entity = e.languages.markup.entity, e.languages.markup.doctype.inside["internal-subset"].inside = e.languages.markup, e.hooks.add("wrap", function(a) {
    a.type === "entity" && (a.attributes.title = a.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(e.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, r) {
      var o = {};
      o["language-" + r] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: e.languages[r]
      }, o.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var u = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: o
        }
      };
      u["language-" + r] = {
        pattern: /[\s\S]+/,
        inside: e.languages[r]
      };
      var c = {};
      c[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: u
      }, e.languages.insertBefore("markup", "cdata", c);
    }
  }), Object.defineProperty(e.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(a, i) {
      e.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + a + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: e.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), e.languages.html = e.languages.markup, e.languages.mathml = e.languages.markup, e.languages.svg = e.languages.markup, e.languages.xml = e.languages.extend("markup", {}), e.languages.ssml = e.languages.xml, e.languages.atom = e.languages.xml, e.languages.rss = e.languages.xml, function(a) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    a.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, a.languages.css.atrule.inside.rest = a.languages.css;
    var r = a.languages.markup;
    r && (r.tag.addInlined("style", "css"), r.tag.addAttribute("style", "css"));
  }(e), e.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, e.languages.javascript = e.languages.extend("clike", {
    "class-name": [
      e.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), e.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, e.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: e.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: e.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: e.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: e.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: e.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), e.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: e.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), e.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), e.languages.markup && (e.languages.markup.tag.addInlined("script", "javascript"), e.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), e.languages.js = e.languages.javascript, function() {
    if (typeof e > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var a = "Loading…", i = function(k, B) {
      return "✖ Error " + k + " while fetching file: " + B;
    }, r = "✖ Error: File does not exist or is empty", o = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, u = "data-src-status", c = "loading", b = "loaded", _ = "failed", C = "pre[data-src]:not([" + u + '="' + b + '"]):not([' + u + '="' + c + '"])';
    function f(k, B, P) {
      var g = new XMLHttpRequest();
      g.open("GET", k, !0), g.onreadystatechange = function() {
        g.readyState == 4 && (g.status < 400 && g.responseText ? B(g.responseText) : g.status >= 400 ? P(i(g.status, g.statusText)) : P(r));
      }, g.send(null);
    }
    function w(k) {
      var B = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(k || "");
      if (B) {
        var P = Number(B[1]), g = B[2], p = B[3];
        return g ? p ? [P, Number(p)] : [P, void 0] : [P, P];
      }
    }
    e.hooks.add("before-highlightall", function(k) {
      k.selector += ", " + C;
    }), e.hooks.add("before-sanity-check", function(k) {
      var B = (
        /** @type {HTMLPreElement} */
        k.element
      );
      if (B.matches(C)) {
        k.code = "", B.setAttribute(u, c);
        var P = B.appendChild(document.createElement("CODE"));
        P.textContent = a;
        var g = B.getAttribute("data-src"), p = k.language;
        if (p === "none") {
          var F = (/\.(\w+)$/.exec(g) || [, "none"])[1];
          p = o[F] || F;
        }
        e.util.setLanguage(P, p), e.util.setLanguage(B, p);
        var m = e.plugins.autoloader;
        m && m.loadLanguages(p), f(
          g,
          function(D) {
            B.setAttribute(u, b);
            var v = w(B.getAttribute("data-range"));
            if (v) {
              var S = D.split(/\r\n?|\n/g), E = v[0], T = v[1] == null ? S.length : v[1];
              E < 0 && (E += S.length), E = Math.max(0, Math.min(E - 1, S.length)), T < 0 && (T += S.length), T = Math.max(0, Math.min(T, S.length)), D = S.slice(E, T).join(`
`), B.hasAttribute("data-start") || B.setAttribute("data-start", String(E + 1));
            }
            P.textContent = D, e.highlightElement(P);
          },
          function(D) {
            B.setAttribute(u, _), P.textContent = D;
          }
        );
      }
    }), e.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(B) {
        for (var P = (B || document).querySelectorAll(C), g = 0, p; p = P[g++]; )
          e.highlightElement(p);
      }
    };
    var O = !1;
    e.fileHighlight = function() {
      O || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), O = !0), e.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(ta);
var kt = ta.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(n) {
  var t = /\\(?:[^a-z()[\]]|[a-z*]+)/i, e = {
    "equation-command": {
      pattern: t,
      alias: "regex"
    }
  };
  n.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: e,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: e,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: t,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, n.languages.tex = n.languages.latex, n.languages.context = n.languages.latex;
})(Prism);
(function(n) {
  var t = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", e = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, a = {
    bash: e,
    environment: {
      pattern: RegExp("\\$" + t),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + t),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  n.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + t),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: a
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: e
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: a
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: a.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + t),
      alias: "constant"
    },
    variable: a.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, e.inside = n.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], r = a.variable[1].inside, o = 0; o < i.length; o++)
    r[i[o]] = n.languages.bash[i[o]];
  n.languages.sh = n.languages.bash, n.languages.shell = n.languages.bash;
})(Prism);
const Ki = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', Vi = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, Xi = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, bn = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${Vi}</span>
  <span class="check">${Xi}</span>
</button>`, na = /[&<>"']/, Ji = new RegExp(na.source, "g"), aa = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Qi = new RegExp(aa.source, "g"), er = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Fn = (n) => er[n] || "";
function Et(n, t) {
  if (t) {
    if (na.test(n))
      return n.replace(Ji, Fn);
  } else if (aa.test(n))
    return n.replace(Qi, Fn);
  return n;
}
function tr(n) {
  const t = n.map((e) => ({
    start: new RegExp(e.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(e.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(e) {
      for (const a of t) {
        const i = e.match(a.start);
        if (i)
          return i.index;
      }
      return -1;
    },
    tokenizer(e, a) {
      for (const i of t) {
        const r = new RegExp(`${i.start.source}([\\s\\S]+?)${i.end.source}`).exec(e);
        if (r)
          return {
            type: "latex",
            raw: r[0],
            text: r[1].trim()
          };
      }
    },
    renderer(e) {
      return `<div class="latex-block">${e.text}</div>`;
    }
  };
}
function nr() {
  return {
    name: "mermaid",
    level: "block",
    start(n) {
      var t;
      return (t = n.match(/^```mermaid\s*\n/)) == null ? void 0 : t.index;
    },
    tokenizer(n) {
      const t = /^```mermaid\s*\n([\s\S]*?)```\s*(?:\n|$)/.exec(n);
      if (t)
        return {
          type: "mermaid",
          raw: t[0],
          text: t[1].trim()
        };
    },
    renderer(n) {
      return `<div class="mermaid">${n.text}</div>
`;
    }
  };
}
const ar = {
  code(n, t, e) {
    var i;
    const a = ((i = (t ?? "").match(/\S*/)) == null ? void 0 : i[0]) ?? "";
    return n = n.replace(/\n$/, "") + `
`, !a || a === "mermaid" ? '<div class="code_wrap">' + bn + "<pre><code>" + (e ? n : Et(n, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + bn + '<pre><code class="language-' + Et(a) + '">' + (e ? n : Et(n, !0)) + `</code></pre></div>
`;
  }
}, ir = new Zt();
function rr({ header_links: n, line_breaks: t, latex_delimiters: e }) {
  const a = new Kn();
  a.use({
    gfm: !0,
    pedantic: !1,
    breaks: t
  }, Ri({
    highlight: (o, u) => {
      var c;
      return (c = kt.languages) != null && c[u] ? kt.highlight(o, kt.languages[u], u) : o;
    }
  }), { renderer: ar }), n && (a.use(Wi()), a.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(o) {
          const u = o.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), c = "h" + ir.slug(u), b = o.depth, _ = this.parser.parseInline(o.tokens);
          return `<h${b} id="${c}"><a class="md-header-anchor" href="#${c}">${Ki}</a>${_}</h${b}>
`;
        }
      }
    ]
  }));
  const i = nr(), r = tr(e);
  return a.use({
    extensions: [i, r]
  }), a;
}
const Pt = (n) => JSON.parse(JSON.stringify(n)), or = (n) => n.nodeType === 1, sr = (n) => Ar.has(n.tagName), lr = (n) => "action" in n, ur = (n) => n.tagName === "IFRAME", cr = (n) => "formAction" in n, dr = (n) => "protocol" in n, it = /* @__PURE__ */ (() => {
  const n = /^(?:\w+script|data):/i;
  return (t) => n.test(t);
})(), fr = /* @__PURE__ */ (() => {
  const n = /(?:script|data):/i;
  return (t) => n.test(t);
})(), pr = (n) => {
  const t = {};
  for (let e = 0, a = n.length; e < a; e++) {
    const i = n[e];
    for (const r in i)
      t[r] ? t[r] = t[r].concat(i[r]) : t[r] = i[r];
  }
  return t;
}, ia = (n, t) => {
  let e = n.firstChild;
  for (; e; ) {
    const a = e.nextSibling;
    or(e) && (t(e, n), e.parentNode && ia(e, t)), e = a;
  }
}, gr = (n, t) => {
  const e = document.createNodeIterator(n, NodeFilter.SHOW_ELEMENT);
  let a;
  for (; a = e.nextNode(); ) {
    const i = a.parentNode;
    i && t(a, i);
  }
}, hr = (n, t) => !!globalThis.document && !!globalThis.document.createNodeIterator ? gr(n, t) : ia(n, t), ra = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], mr = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], _r = /* @__PURE__ */ new Set([
  ...ra,
  ...mr
]), oa = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], Dr = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], vr = /* @__PURE__ */ new Set([
  ...oa,
  ...Dr
]), sa = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], wr = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], br = /* @__PURE__ */ new Set([
  ...sa,
  ...wr
]), Fr = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Cr = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], $r = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], fe = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, kr = {
  [fe.HTML]: _r,
  [fe.SVG]: vr,
  [fe.MATH]: br
}, Er = {
  [fe.HTML]: "html",
  [fe.SVG]: "svg",
  [fe.MATH]: "math"
}, yr = {
  [fe.HTML]: "",
  [fe.SVG]: "svg:",
  [fe.MATH]: "math:"
}, Ar = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), la = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...ra,
    ...oa.map((n) => `svg:${n}`),
    ...sa.map((n) => `math:${n}`)
  ],
  allowAttributes: pr([
    Object.fromEntries(Fr.map((n) => [n, ["*"]])),
    Object.fromEntries(Cr.map((n) => [n, ["svg:*"]])),
    Object.fromEntries($r.map((n) => [n, ["math:*"]]))
  ])
};
var yt = function(n, t, e, a, i) {
  if (a === "m") throw new TypeError("Private method is not writable");
  if (a === "a" && !i) throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? n !== t || !i : !t.has(n)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return a === "a" ? i.call(n, e) : i ? i.value = e : t.set(n, e), e;
}, ye = function(n, t, e, a) {
  if (e === "a" && !a) throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? n !== t || !a : !t.has(n)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return e === "m" ? a : e === "a" ? a.call(n) : a ? a.value : t.get(n);
}, be, ct, dt;
class ua {
  /* CONSTRUCTOR */
  constructor(t = {}) {
    be.set(this, void 0), ct.set(this, void 0), dt.set(this, void 0), this.getConfiguration = () => Pt(ye(this, be, "f")), this.sanitize = (_) => {
      const C = ye(this, ct, "f"), f = ye(this, dt, "f");
      return hr(_, (w, O) => {
        const k = w.namespaceURI || fe.HTML, B = O.namespaceURI || fe.HTML, P = kr[k], g = Er[k], p = yr[k], F = w.tagName.toLowerCase(), m = `${p}${F}`, v = `${p}*`;
        if (!P.has(F) || !C.has(m) || k !== B && F !== g)
          O.removeChild(w);
        else {
          const S = w.getAttributeNames(), E = S.length;
          if (E) {
            for (let T = 0; T < E; T++) {
              const Y = S[T], R = f[Y];
              (!R || !R.has(v) && !R.has(m)) && w.removeAttribute(Y);
            }
            if (sr(w))
              if (dr(w)) {
                const T = w.getAttribute("href");
                T && fr(T) && it(w.protocol) && w.removeAttribute("href");
              } else lr(w) ? it(w.action) && w.removeAttribute("action") : cr(w) ? it(w.formAction) && w.removeAttribute("formaction") : ur(w) && (it(w.src) && w.removeAttribute("formaction"), w.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), _;
    }, this.sanitizeFor = (_, C) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: e, allowCustomElements: a, allowUnknownMarkup: i, blockElements: r, dropElements: o, dropAttributes: u } = t;
    if (e === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (a)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (i)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (r)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (o)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (u)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    yt(this, be, Pt(la), "f");
    const { allowElements: c, allowAttributes: b } = t;
    c && (ye(this, be, "f").allowElements = t.allowElements), b && (ye(this, be, "f").allowAttributes = t.allowAttributes), yt(this, ct, new Set(ye(this, be, "f").allowElements), "f"), yt(this, dt, Object.fromEntries(Object.entries(ye(this, be, "f").allowAttributes || {}).map(([_, C]) => [_, new Set(C)])), "f");
  }
}
be = /* @__PURE__ */ new WeakMap(), ct = /* @__PURE__ */ new WeakMap(), dt = /* @__PURE__ */ new WeakMap();
ua.getDefaultConfiguration = () => Pt(la);
const Sr = (n, t = location.href) => {
  try {
    return !!n && new URL(n).origin !== new URL(t).origin;
  } catch {
    return !1;
  }
};
function Cn(n) {
  const t = new ua(), e = new DOMParser().parseFromString(n, "text/html");
  return ca(e.body, "A", (a) => {
    a instanceof HTMLElement && "target" in a && Sr(a.getAttribute("href"), location.href) && (a.setAttribute("target", "_blank"), a.setAttribute("rel", "noopener noreferrer"));
  }), t.sanitize(e).body.innerHTML;
}
function ca(n, t, e) {
  n && (n.nodeName === t || typeof t == "function") && e(n);
  const a = (n == null ? void 0 : n.childNodes) || [];
  for (let i = 0; i < a.length; i++)
    ca(a[i], t, e);
}
const $n = [
  "!--",
  "!doctype",
  "a",
  "abbr",
  "acronym",
  "address",
  "applet",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "basefont",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "meta",
  "meter",
  "nav",
  "noframes",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "search",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], xr = [
  // Base structural elements
  "g",
  "defs",
  "use",
  "symbol",
  // Shape elements
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "path",
  "image",
  // Text elements
  "text",
  "tspan",
  "textPath",
  // Gradient and effects
  "linearGradient",
  "radialGradient",
  "stop",
  "pattern",
  "clipPath",
  "mask",
  "filter",
  // Filter effects
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feGaussianBlur",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTurbulence",
  "feMergeNode",
  "feFuncR",
  "feFuncG",
  "feFuncB",
  "feFuncA",
  "feDistantLight",
  "fePointLight",
  "feSpotLight",
  "feFlood",
  "feTile",
  // Animation elements
  "animate",
  "animateTransform",
  "animateMotion",
  "mpath",
  "set",
  // Interactive and other elements
  "view",
  "cursor",
  "foreignObject",
  "desc",
  "title",
  "metadata",
  "switch"
], Mr = [
  ...$n,
  ...xr.filter((n) => !$n.includes(n))
], {
  SvelteComponent: Tr,
  attr: Br,
  binding_callbacks: Ir,
  detach: qr,
  element: Or,
  init: Lr,
  insert: Pr,
  noop: kn,
  safe_not_equal: Nr,
  toggle_class: rt
} = window.__gradio__svelte__internal, { afterUpdate: Rr, tick: Hr, onMount: Wo } = window.__gradio__svelte__internal;
function zr(n) {
  let t;
  return {
    c() {
      t = Or("span"), Br(t, "class", "md svelte-1m32c2s"), rt(
        t,
        "chatbot",
        /*chatbot*/
        n[0]
      ), rt(
        t,
        "prose",
        /*render_markdown*/
        n[1]
      );
    },
    m(e, a) {
      Pr(e, t, a), t.innerHTML = /*html*/
      n[3], n[11](t);
    },
    p(e, [a]) {
      a & /*html*/
      8 && (t.innerHTML = /*html*/
      e[3]), a & /*chatbot*/
      1 && rt(
        t,
        "chatbot",
        /*chatbot*/
        e[0]
      ), a & /*render_markdown*/
      2 && rt(
        t,
        "prose",
        /*render_markdown*/
        e[1]
      );
    },
    i: kn,
    o: kn,
    d(e) {
      e && qr(t), n[11](null);
    }
  };
}
function En(n) {
  return n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function jr(n, t, e) {
  let { chatbot: a = !0 } = t, { message: i } = t, { sanitize_html: r = !0 } = t, { latex_delimiters: o = [] } = t, { render_markdown: u = !0 } = t, { line_breaks: c = !0 } = t, { header_links: b = !1 } = t, { allow_tags: _ = !1 } = t, { theme_mode: C = "system" } = t, f, w, O = !1;
  const k = rr({
    header_links: b,
    line_breaks: c,
    latex_delimiters: o || []
  });
  function B(m) {
    return !o || o.length === 0 ? !1 : o.some((D) => m.includes(D.left) && m.includes(D.right));
  }
  function P(m, D) {
    if (D === !0) {
      const v = /<\/?([a-zA-Z][a-zA-Z0-9-]*)([\s>])/g;
      return m.replace(v, (S, E, T) => Mr.includes(E.toLowerCase()) ? S : S.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    if (Array.isArray(D)) {
      const v = D.map((E) => ({
        open: new RegExp(`<(${E})(\\s+[^>]*)?>`, "gi"),
        close: new RegExp(`</(${E})>`, "gi")
      }));
      let S = m;
      return v.forEach((E) => {
        S = S.replace(E.open, (T) => T.replace(/</g, "&lt;").replace(/>/g, "&gt;")), S = S.replace(E.close, (T) => T.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      }), S;
    }
    return m;
  }
  function g(m) {
    let D = m;
    if (u) {
      const v = [];
      o.forEach((S, E) => {
        const T = En(S.left), Y = En(S.right), R = new RegExp(`${T}([\\s\\S]+?)${Y}`, "g");
        D = D.replace(R, (ie, we) => (v.push(ie), `%%%LATEX_BLOCK_${v.length - 1}%%%`));
      }), D = k.parse(D), D = D.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, (S, E) => v[parseInt(E, 10)]);
    }
    return _ && (D = P(D, _)), r && Cn && (D = Cn(D)), D;
  }
  async function p(m) {
    if (o.length > 0 && m && B(m))
      if (!O)
        await Promise.all([Promise.resolve({              }), import("./auto-render-BwaQGe8P.js")]).then(([, { default: D }]) => {
          O = !0, D(f, {
            delimiters: o,
            throwOnError: !1
          });
        });
      else {
        const { default: D } = await import("./auto-render-BwaQGe8P.js");
        D(f, {
          delimiters: o,
          throwOnError: !1
        });
      }
    if (f) {
      const D = f.querySelectorAll(".mermaid");
      if (D.length > 0) {
        await Hr();
        const { default: v } = await import("./mermaid.core-C8Sj0WRA.js").then((S) => S.bC);
        v.initialize({
          startOnLoad: !1,
          theme: C === "dark" ? "dark" : "default",
          securityLevel: "antiscript"
        }), await v.run({
          nodes: Array.from(D).map((S) => S)
        });
      }
    }
  }
  Rr(async () => {
    f && document.body.contains(f) ? await p(i) : console.error("Element is not in the DOM");
  });
  function F(m) {
    Ir[m ? "unshift" : "push"](() => {
      f = m, e(2, f);
    });
  }
  return n.$$set = (m) => {
    "chatbot" in m && e(0, a = m.chatbot), "message" in m && e(4, i = m.message), "sanitize_html" in m && e(5, r = m.sanitize_html), "latex_delimiters" in m && e(6, o = m.latex_delimiters), "render_markdown" in m && e(1, u = m.render_markdown), "line_breaks" in m && e(7, c = m.line_breaks), "header_links" in m && e(8, b = m.header_links), "allow_tags" in m && e(9, _ = m.allow_tags), "theme_mode" in m && e(10, C = m.theme_mode);
  }, n.$$.update = () => {
    n.$$.dirty & /*message*/
    16 && (i && i.trim() ? e(3, w = g(i)) : e(3, w = ""));
  }, [
    a,
    u,
    f,
    w,
    i,
    r,
    o,
    c,
    b,
    _,
    C,
    F
  ];
}
class Yr extends Tr {
  constructor(t) {
    super(), Lr(this, t, jr, zr, Nr, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      allow_tags: 9,
      theme_mode: 10
    });
  }
}
const {
  SvelteComponent: Gr,
  attr: Ur,
  create_component: Wr,
  destroy_component: Zr,
  detach: Kr,
  element: Vr,
  init: Xr,
  insert: Jr,
  mount_component: Qr,
  safe_not_equal: eo,
  transition_in: to,
  transition_out: no
} = window.__gradio__svelte__internal;
function ao(n) {
  let t, e, a;
  return e = new Yr({
    props: {
      message: (
        /*info*/
        n[0]
      ),
      sanitize_html: !0
    }
  }), {
    c() {
      t = Vr("div"), Wr(e.$$.fragment), Ur(t, "class", "svelte-17qq50w");
    },
    m(i, r) {
      Jr(i, t, r), Qr(e, t, null), a = !0;
    },
    p(i, [r]) {
      const o = {};
      r & /*info*/
      1 && (o.message = /*info*/
      i[0]), e.$set(o);
    },
    i(i) {
      a || (to(e.$$.fragment, i), a = !0);
    },
    o(i) {
      no(e.$$.fragment, i), a = !1;
    },
    d(i) {
      i && Kr(t), Zr(e);
    }
  };
}
function io(n, t, e) {
  let { info: a } = t;
  return n.$$set = (i) => {
    "info" in i && e(0, a = i.info);
  }, [a];
}
class ro extends Gr {
  constructor(t) {
    super(), Xr(this, t, io, ao, eo, { info: 0 });
  }
}
const {
  SvelteComponent: oo,
  attr: ot,
  check_outros: so,
  create_component: lo,
  create_slot: uo,
  destroy_component: co,
  detach: At,
  element: fo,
  empty: po,
  get_all_dirty_from_scope: go,
  get_slot_changes: ho,
  group_outros: mo,
  init: _o,
  insert: St,
  mount_component: Do,
  safe_not_equal: vo,
  space: wo,
  toggle_class: qe,
  transition_in: ze,
  transition_out: ft,
  update_slot_base: bo
} = window.__gradio__svelte__internal;
function yn(n) {
  let t, e;
  return t = new ro({ props: { info: (
    /*info*/
    n[1]
  ) } }), {
    c() {
      lo(t.$$.fragment);
    },
    m(a, i) {
      Do(t, a, i), e = !0;
    },
    p(a, i) {
      const r = {};
      i & /*info*/
      2 && (r.info = /*info*/
      a[1]), t.$set(r);
    },
    i(a) {
      e || (ze(t.$$.fragment, a), e = !0);
    },
    o(a) {
      ft(t.$$.fragment, a), e = !1;
    },
    d(a) {
      co(t, a);
    }
  };
}
function Fo(n) {
  let t, e, a, i, r;
  const o = (
    /*#slots*/
    n[4].default
  ), u = uo(
    o,
    n,
    /*$$scope*/
    n[3],
    null
  );
  let c = (
    /*info*/
    n[1] && yn(n)
  );
  return {
    c() {
      t = fo("span"), u && u.c(), a = wo(), c && c.c(), i = po(), ot(t, "data-testid", "block-info"), ot(t, "dir", e = /*rtl*/
      n[2] ? "rtl" : "ltr"), ot(t, "class", "svelte-zgrq3"), qe(t, "sr-only", !/*show_label*/
      n[0]), qe(t, "hide", !/*show_label*/
      n[0]), qe(
        t,
        "has-info",
        /*info*/
        n[1] != null
      );
    },
    m(b, _) {
      St(b, t, _), u && u.m(t, null), St(b, a, _), c && c.m(b, _), St(b, i, _), r = !0;
    },
    p(b, [_]) {
      u && u.p && (!r || _ & /*$$scope*/
      8) && bo(
        u,
        o,
        b,
        /*$$scope*/
        b[3],
        r ? ho(
          o,
          /*$$scope*/
          b[3],
          _,
          null
        ) : go(
          /*$$scope*/
          b[3]
        ),
        null
      ), (!r || _ & /*rtl*/
      4 && e !== (e = /*rtl*/
      b[2] ? "rtl" : "ltr")) && ot(t, "dir", e), (!r || _ & /*show_label*/
      1) && qe(t, "sr-only", !/*show_label*/
      b[0]), (!r || _ & /*show_label*/
      1) && qe(t, "hide", !/*show_label*/
      b[0]), (!r || _ & /*info*/
      2) && qe(
        t,
        "has-info",
        /*info*/
        b[1] != null
      ), /*info*/
      b[1] ? c ? (c.p(b, _), _ & /*info*/
      2 && ze(c, 1)) : (c = yn(b), c.c(), ze(c, 1), c.m(i.parentNode, i)) : c && (mo(), ft(c, 1, 1, () => {
        c = null;
      }), so());
    },
    i(b) {
      r || (ze(u, b), ze(c), r = !0);
    },
    o(b) {
      ft(u, b), ft(c), r = !1;
    },
    d(b) {
      b && (At(t), At(a), At(i)), u && u.d(b), c && c.d(b);
    }
  };
}
function Co(n, t, e) {
  let { $$slots: a = {}, $$scope: i } = t, { show_label: r = !0 } = t, { info: o = void 0 } = t, { rtl: u = !1 } = t;
  return n.$$set = (c) => {
    "show_label" in c && e(0, r = c.show_label), "info" in c && e(1, o = c.info), "rtl" in c && e(2, u = c.rtl), "$$scope" in c && e(3, i = c.$$scope);
  }, [r, o, u, i, a];
}
class $o extends oo {
  constructor(t) {
    super(), _o(this, t, Co, Fo, vo, { show_label: 0, info: 1, rtl: 2 });
  }
}
const {
  SvelteComponent: Zo,
  append: Ko,
  attr: Vo,
  create_component: Xo,
  destroy_component: Jo,
  detach: Qo,
  element: es,
  init: ts,
  insert: ns,
  mount_component: as,
  safe_not_equal: is,
  set_data: rs,
  space: os,
  text: ss,
  toggle_class: ls,
  transition_in: us,
  transition_out: cs
} = window.__gradio__svelte__internal, {
  SvelteComponent: ds,
  assign: fs,
  compute_rest_props: ps,
  create_slot: gs,
  detach: hs,
  element: ms,
  exclude_internal_props: _s,
  get_all_dirty_from_scope: Ds,
  get_slot_changes: vs,
  get_spread_update: ws,
  init: bs,
  insert: Fs,
  listen: Cs,
  safe_not_equal: $s,
  set_attributes: ks,
  set_style: Es,
  toggle_class: ys,
  transition_in: As,
  transition_out: Ss,
  update_slot_base: xs
} = window.__gradio__svelte__internal, { createEventDispatcher: Ms } = window.__gradio__svelte__internal, {
  SvelteComponent: Ts,
  append: Bs,
  attr: Is,
  bubble: qs,
  check_outros: Os,
  construct_svelte_component: Ls,
  create_component: Ps,
  create_slot: Ns,
  destroy_component: Rs,
  detach: Hs,
  element: zs,
  get_all_dirty_from_scope: js,
  get_slot_changes: Ys,
  group_outros: Gs,
  init: Us,
  insert: Ws,
  listen: Zs,
  mount_component: Ks,
  safe_not_equal: Vs,
  set_data: Xs,
  set_style: Js,
  space: Qs,
  text: el,
  toggle_class: tl,
  transition_in: nl,
  transition_out: al,
  update_slot_base: il
} = window.__gradio__svelte__internal, {
  SvelteComponent: rl,
  append: ol,
  attr: sl,
  binding_callbacks: ll,
  create_slot: ul,
  detach: cl,
  element: dl,
  get_all_dirty_from_scope: fl,
  get_slot_changes: pl,
  init: gl,
  insert: hl,
  safe_not_equal: ml,
  toggle_class: _l,
  transition_in: Dl,
  transition_out: vl,
  update_slot_base: wl
} = window.__gradio__svelte__internal, {
  SvelteComponent: bl,
  append: Fl,
  attr: Cl,
  detach: $l,
  init: kl,
  insert: El,
  noop: yl,
  safe_not_equal: Al,
  svg_element: Sl
} = window.__gradio__svelte__internal, {
  SvelteComponent: xl,
  append: Ml,
  attr: Tl,
  detach: Bl,
  init: Il,
  insert: ql,
  noop: Ol,
  safe_not_equal: Ll,
  svg_element: Pl
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nl,
  append: Rl,
  attr: Hl,
  detach: zl,
  init: jl,
  insert: Yl,
  noop: Gl,
  safe_not_equal: Ul,
  svg_element: Wl
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zl,
  append: Kl,
  attr: Vl,
  detach: Xl,
  init: Jl,
  insert: Ql,
  noop: eu,
  safe_not_equal: tu,
  svg_element: nu
} = window.__gradio__svelte__internal, {
  SvelteComponent: au,
  append: iu,
  attr: ru,
  detach: ou,
  init: su,
  insert: lu,
  noop: uu,
  safe_not_equal: cu,
  svg_element: du
} = window.__gradio__svelte__internal, {
  SvelteComponent: fu,
  append: pu,
  attr: gu,
  detach: hu,
  init: mu,
  insert: _u,
  noop: Du,
  safe_not_equal: vu,
  svg_element: wu
} = window.__gradio__svelte__internal, {
  SvelteComponent: bu,
  append: Fu,
  attr: Cu,
  detach: $u,
  init: ku,
  insert: Eu,
  noop: yu,
  safe_not_equal: Au,
  svg_element: Su
} = window.__gradio__svelte__internal, {
  SvelteComponent: xu,
  append: Mu,
  attr: Tu,
  detach: Bu,
  init: Iu,
  insert: qu,
  noop: Ou,
  safe_not_equal: Lu,
  svg_element: Pu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nu,
  append: Ru,
  attr: Hu,
  detach: zu,
  init: ju,
  insert: Yu,
  noop: Gu,
  safe_not_equal: Uu,
  svg_element: Wu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zu,
  append: Ku,
  attr: Vu,
  detach: Xu,
  init: Ju,
  insert: Qu,
  noop: ec,
  safe_not_equal: tc,
  svg_element: nc
} = window.__gradio__svelte__internal, {
  SvelteComponent: ac,
  append: ic,
  attr: rc,
  detach: oc,
  init: sc,
  insert: lc,
  noop: uc,
  safe_not_equal: cc,
  svg_element: dc
} = window.__gradio__svelte__internal, {
  SvelteComponent: fc,
  append: pc,
  attr: gc,
  detach: hc,
  init: mc,
  insert: _c,
  noop: Dc,
  safe_not_equal: vc,
  svg_element: wc
} = window.__gradio__svelte__internal, {
  SvelteComponent: bc,
  append: Fc,
  attr: Cc,
  detach: $c,
  init: kc,
  insert: Ec,
  noop: yc,
  safe_not_equal: Ac,
  set_style: Sc,
  svg_element: xc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mc,
  append: Tc,
  attr: Bc,
  detach: Ic,
  init: qc,
  insert: Oc,
  noop: Lc,
  safe_not_equal: Pc,
  svg_element: Nc,
  text: Rc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hc,
  append: zc,
  attr: jc,
  detach: Yc,
  init: Gc,
  insert: Uc,
  noop: Wc,
  safe_not_equal: Zc,
  svg_element: Kc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vc,
  append: Xc,
  attr: Jc,
  detach: Qc,
  init: ed,
  insert: td,
  noop: nd,
  safe_not_equal: ad,
  svg_element: id
} = window.__gradio__svelte__internal, {
  SvelteComponent: rd,
  append: od,
  attr: sd,
  detach: ld,
  init: ud,
  insert: cd,
  noop: dd,
  safe_not_equal: fd,
  svg_element: pd
} = window.__gradio__svelte__internal, {
  SvelteComponent: gd,
  append: hd,
  attr: md,
  detach: _d,
  init: Dd,
  insert: vd,
  noop: wd,
  safe_not_equal: bd,
  svg_element: Fd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cd,
  append: $d,
  attr: kd,
  detach: Ed,
  init: yd,
  insert: Ad,
  noop: Sd,
  safe_not_equal: xd,
  svg_element: Md
} = window.__gradio__svelte__internal, {
  SvelteComponent: Td,
  append: Bd,
  attr: Id,
  detach: qd,
  init: Od,
  insert: Ld,
  noop: Pd,
  safe_not_equal: Nd,
  svg_element: Rd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hd,
  append: zd,
  attr: jd,
  detach: Yd,
  init: Gd,
  insert: Ud,
  noop: Wd,
  safe_not_equal: Zd,
  svg_element: Kd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vd,
  append: Xd,
  attr: Jd,
  detach: Qd,
  init: ef,
  insert: tf,
  noop: nf,
  safe_not_equal: af,
  svg_element: rf
} = window.__gradio__svelte__internal, {
  SvelteComponent: of,
  append: sf,
  attr: lf,
  detach: uf,
  init: cf,
  insert: df,
  noop: ff,
  safe_not_equal: pf,
  svg_element: gf
} = window.__gradio__svelte__internal, {
  SvelteComponent: hf,
  append: mf,
  attr: _f,
  detach: Df,
  init: vf,
  insert: wf,
  noop: bf,
  safe_not_equal: Ff,
  svg_element: Cf
} = window.__gradio__svelte__internal, {
  SvelteComponent: $f,
  append: kf,
  attr: Ef,
  detach: yf,
  init: Af,
  insert: Sf,
  noop: xf,
  safe_not_equal: Mf,
  svg_element: Tf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bf,
  append: If,
  attr: qf,
  detach: Of,
  init: Lf,
  insert: Pf,
  noop: Nf,
  safe_not_equal: Rf,
  svg_element: Hf
} = window.__gradio__svelte__internal, {
  SvelteComponent: zf,
  append: jf,
  attr: Yf,
  detach: Gf,
  init: Uf,
  insert: Wf,
  noop: Zf,
  safe_not_equal: Kf,
  svg_element: Vf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xf,
  append: Jf,
  attr: Qf,
  detach: ep,
  init: tp,
  insert: np,
  noop: ap,
  safe_not_equal: ip,
  svg_element: rp
} = window.__gradio__svelte__internal, {
  SvelteComponent: op,
  append: sp,
  attr: lp,
  detach: up,
  init: cp,
  insert: dp,
  noop: fp,
  safe_not_equal: pp,
  svg_element: gp
} = window.__gradio__svelte__internal, {
  SvelteComponent: hp,
  append: mp,
  attr: _p,
  detach: Dp,
  init: vp,
  insert: wp,
  noop: bp,
  safe_not_equal: Fp,
  svg_element: Cp
} = window.__gradio__svelte__internal, {
  SvelteComponent: $p,
  append: kp,
  attr: Ep,
  detach: yp,
  init: Ap,
  insert: Sp,
  noop: xp,
  safe_not_equal: Mp,
  svg_element: Tp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bp,
  append: Ip,
  attr: qp,
  detach: Op,
  init: Lp,
  insert: Pp,
  noop: Np,
  safe_not_equal: Rp,
  svg_element: Hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: zp,
  append: jp,
  attr: Yp,
  detach: Gp,
  init: Up,
  insert: Wp,
  noop: Zp,
  safe_not_equal: Kp,
  svg_element: Vp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xp,
  append: Jp,
  attr: Qp,
  detach: eg,
  init: tg,
  insert: ng,
  noop: ag,
  safe_not_equal: ig,
  svg_element: rg
} = window.__gradio__svelte__internal, {
  SvelteComponent: og,
  append: sg,
  attr: lg,
  detach: ug,
  init: cg,
  insert: dg,
  noop: fg,
  safe_not_equal: pg,
  svg_element: gg
} = window.__gradio__svelte__internal, {
  SvelteComponent: hg,
  append: mg,
  attr: _g,
  detach: Dg,
  init: vg,
  insert: wg,
  noop: bg,
  safe_not_equal: Fg,
  svg_element: Cg
} = window.__gradio__svelte__internal, {
  SvelteComponent: $g,
  append: kg,
  attr: Eg,
  detach: yg,
  init: Ag,
  insert: Sg,
  noop: xg,
  safe_not_equal: Mg,
  svg_element: Tg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bg,
  append: Ig,
  attr: qg,
  detach: Og,
  init: Lg,
  insert: Pg,
  noop: Ng,
  safe_not_equal: Rg,
  svg_element: Hg
} = window.__gradio__svelte__internal, {
  SvelteComponent: zg,
  append: jg,
  attr: Yg,
  detach: Gg,
  init: Ug,
  insert: Wg,
  noop: Zg,
  safe_not_equal: Kg,
  svg_element: Vg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xg,
  append: Jg,
  attr: Qg,
  detach: eh,
  init: th,
  insert: nh,
  noop: ah,
  safe_not_equal: ih,
  svg_element: rh
} = window.__gradio__svelte__internal, {
  SvelteComponent: oh,
  append: sh,
  attr: lh,
  detach: uh,
  init: ch,
  insert: dh,
  noop: fh,
  safe_not_equal: ph,
  svg_element: gh
} = window.__gradio__svelte__internal, {
  SvelteComponent: hh,
  append: mh,
  attr: _h,
  detach: Dh,
  init: vh,
  insert: wh,
  noop: bh,
  safe_not_equal: Fh,
  svg_element: Ch
} = window.__gradio__svelte__internal, {
  SvelteComponent: $h,
  append: kh,
  attr: Eh,
  detach: yh,
  init: Ah,
  insert: Sh,
  noop: xh,
  safe_not_equal: Mh,
  svg_element: Th
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bh,
  append: Ih,
  attr: qh,
  detach: Oh,
  init: Lh,
  insert: Ph,
  noop: Nh,
  safe_not_equal: Rh,
  svg_element: Hh
} = window.__gradio__svelte__internal, {
  SvelteComponent: zh,
  append: jh,
  attr: Yh,
  detach: Gh,
  init: Uh,
  insert: Wh,
  noop: Zh,
  safe_not_equal: Kh,
  svg_element: Vh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xh,
  append: Jh,
  attr: Qh,
  detach: em,
  init: tm,
  insert: nm,
  noop: am,
  safe_not_equal: im,
  svg_element: rm
} = window.__gradio__svelte__internal, {
  SvelteComponent: om,
  append: sm,
  attr: lm,
  detach: um,
  init: cm,
  insert: dm,
  noop: fm,
  safe_not_equal: pm,
  svg_element: gm
} = window.__gradio__svelte__internal, {
  SvelteComponent: hm,
  append: mm,
  attr: _m,
  detach: Dm,
  init: vm,
  insert: wm,
  noop: bm,
  safe_not_equal: Fm,
  set_style: Cm,
  svg_element: $m
} = window.__gradio__svelte__internal, {
  SvelteComponent: km,
  append: Em,
  attr: ym,
  detach: Am,
  init: Sm,
  insert: xm,
  noop: Mm,
  safe_not_equal: Tm,
  svg_element: Bm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Im,
  append: qm,
  attr: Om,
  detach: Lm,
  init: Pm,
  insert: Nm,
  noop: Rm,
  safe_not_equal: Hm,
  svg_element: zm
} = window.__gradio__svelte__internal, {
  SvelteComponent: jm,
  append: Ym,
  attr: Gm,
  detach: Um,
  init: Wm,
  insert: Zm,
  noop: Km,
  safe_not_equal: Vm,
  svg_element: Xm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jm,
  append: Qm,
  attr: e_,
  detach: t_,
  init: n_,
  insert: a_,
  noop: i_,
  safe_not_equal: r_,
  svg_element: o_
} = window.__gradio__svelte__internal, {
  SvelteComponent: s_,
  append: l_,
  attr: u_,
  detach: c_,
  init: d_,
  insert: f_,
  noop: p_,
  safe_not_equal: g_,
  svg_element: h_
} = window.__gradio__svelte__internal, {
  SvelteComponent: m_,
  append: __,
  attr: D_,
  detach: v_,
  init: w_,
  insert: b_,
  noop: F_,
  safe_not_equal: C_,
  svg_element: $_
} = window.__gradio__svelte__internal, {
  SvelteComponent: k_,
  append: E_,
  attr: y_,
  detach: A_,
  init: S_,
  insert: x_,
  noop: M_,
  safe_not_equal: T_,
  svg_element: B_
} = window.__gradio__svelte__internal, {
  SvelteComponent: I_,
  append: q_,
  attr: O_,
  detach: L_,
  init: P_,
  insert: N_,
  noop: R_,
  safe_not_equal: H_,
  svg_element: z_
} = window.__gradio__svelte__internal, {
  SvelteComponent: j_,
  append: Y_,
  attr: G_,
  detach: U_,
  init: W_,
  insert: Z_,
  noop: K_,
  safe_not_equal: V_,
  svg_element: X_,
  text: J_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q_,
  append: e0,
  attr: t0,
  detach: n0,
  init: a0,
  insert: i0,
  noop: r0,
  safe_not_equal: o0,
  svg_element: s0
} = window.__gradio__svelte__internal, {
  SvelteComponent: l0,
  append: u0,
  attr: c0,
  detach: d0,
  init: f0,
  insert: p0,
  noop: g0,
  safe_not_equal: h0,
  svg_element: m0
} = window.__gradio__svelte__internal, {
  SvelteComponent: _0,
  append: D0,
  attr: v0,
  detach: w0,
  init: b0,
  insert: F0,
  noop: C0,
  safe_not_equal: $0,
  svg_element: k0
} = window.__gradio__svelte__internal, {
  SvelteComponent: E0,
  append: y0,
  attr: A0,
  detach: S0,
  init: x0,
  insert: M0,
  noop: T0,
  safe_not_equal: B0,
  svg_element: I0
} = window.__gradio__svelte__internal, {
  SvelteComponent: q0,
  append: O0,
  attr: L0,
  detach: P0,
  init: N0,
  insert: R0,
  noop: H0,
  safe_not_equal: z0,
  svg_element: j0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y0,
  append: G0,
  attr: U0,
  detach: W0,
  init: Z0,
  insert: K0,
  noop: V0,
  safe_not_equal: X0,
  svg_element: J0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q0,
  append: eD,
  attr: tD,
  detach: nD,
  init: aD,
  insert: iD,
  noop: rD,
  safe_not_equal: oD,
  svg_element: sD
} = window.__gradio__svelte__internal, {
  SvelteComponent: lD,
  append: uD,
  attr: cD,
  detach: dD,
  init: fD,
  insert: pD,
  noop: gD,
  safe_not_equal: hD,
  svg_element: mD,
  text: _D
} = window.__gradio__svelte__internal, {
  SvelteComponent: DD,
  append: vD,
  attr: wD,
  detach: bD,
  init: FD,
  insert: CD,
  noop: $D,
  safe_not_equal: kD,
  svg_element: ED,
  text: yD
} = window.__gradio__svelte__internal, {
  SvelteComponent: AD,
  append: SD,
  attr: xD,
  detach: MD,
  init: TD,
  insert: BD,
  noop: ID,
  safe_not_equal: qD,
  svg_element: OD,
  text: LD
} = window.__gradio__svelte__internal, {
  SvelteComponent: PD,
  append: ND,
  attr: RD,
  detach: HD,
  init: zD,
  insert: jD,
  noop: YD,
  safe_not_equal: GD,
  svg_element: UD
} = window.__gradio__svelte__internal, {
  SvelteComponent: WD,
  append: ZD,
  attr: KD,
  detach: VD,
  init: XD,
  insert: JD,
  noop: QD,
  safe_not_equal: e1,
  svg_element: t1
} = window.__gradio__svelte__internal, {
  SvelteComponent: n1,
  append: a1,
  attr: i1,
  detach: r1,
  init: o1,
  insert: s1,
  noop: l1,
  safe_not_equal: u1,
  svg_element: c1
} = window.__gradio__svelte__internal, {
  SvelteComponent: d1,
  append: f1,
  attr: p1,
  detach: g1,
  init: h1,
  insert: m1,
  noop: _1,
  safe_not_equal: D1,
  svg_element: v1
} = window.__gradio__svelte__internal, {
  SvelteComponent: w1,
  append: b1,
  attr: F1,
  detach: C1,
  init: $1,
  insert: k1,
  noop: E1,
  safe_not_equal: y1,
  svg_element: A1
} = window.__gradio__svelte__internal, {
  SvelteComponent: S1,
  append: x1,
  attr: M1,
  detach: T1,
  init: B1,
  insert: I1,
  noop: q1,
  safe_not_equal: O1,
  svg_element: L1
} = window.__gradio__svelte__internal, {
  SvelteComponent: P1,
  append: N1,
  attr: R1,
  detach: H1,
  init: z1,
  insert: j1,
  noop: Y1,
  safe_not_equal: G1,
  svg_element: U1
} = window.__gradio__svelte__internal, {
  SvelteComponent: W1,
  append: Z1,
  attr: K1,
  detach: V1,
  init: X1,
  insert: J1,
  noop: Q1,
  safe_not_equal: ev,
  svg_element: tv
} = window.__gradio__svelte__internal, {
  SvelteComponent: nv,
  append: av,
  attr: iv,
  detach: rv,
  init: ov,
  insert: sv,
  noop: lv,
  safe_not_equal: uv,
  svg_element: cv
} = window.__gradio__svelte__internal, {
  SvelteComponent: dv,
  append: fv,
  attr: pv,
  detach: gv,
  init: hv,
  insert: mv,
  noop: _v,
  safe_not_equal: Dv,
  svg_element: vv
} = window.__gradio__svelte__internal, {
  SvelteComponent: wv,
  append: bv,
  attr: Fv,
  detach: Cv,
  init: $v,
  insert: kv,
  noop: Ev,
  safe_not_equal: yv,
  svg_element: Av
} = window.__gradio__svelte__internal, ko = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], An = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
ko.reduce((n, { color: t, primary: e, secondary: a }) => ({
  ...n,
  [t]: {
    primary: An[t][e],
    secondary: An[t][a]
  }
}), {});
const {
  SvelteComponent: Sv,
  create_component: xv,
  destroy_component: Mv,
  init: Tv,
  mount_component: Bv,
  safe_not_equal: Iv,
  transition_in: qv,
  transition_out: Ov
} = window.__gradio__svelte__internal, { createEventDispatcher: Lv } = window.__gradio__svelte__internal, {
  SvelteComponent: Pv,
  append: Nv,
  attr: Rv,
  check_outros: Hv,
  create_component: zv,
  destroy_component: jv,
  detach: Yv,
  element: Gv,
  empty: Uv,
  group_outros: Wv,
  init: Zv,
  insert: Kv,
  mount_component: Vv,
  safe_not_equal: Xv,
  set_data: Jv,
  space: Qv,
  text: ew,
  toggle_class: tw,
  transition_in: nw,
  transition_out: aw
} = window.__gradio__svelte__internal, {
  SvelteComponent: iw,
  attr: rw,
  create_slot: ow,
  detach: sw,
  element: lw,
  get_all_dirty_from_scope: uw,
  get_slot_changes: cw,
  init: dw,
  insert: fw,
  safe_not_equal: pw,
  toggle_class: gw,
  transition_in: hw,
  transition_out: mw,
  update_slot_base: _w
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dw,
  append: vw,
  attr: ww,
  check_outros: bw,
  create_component: Fw,
  destroy_component: Cw,
  detach: $w,
  element: kw,
  empty: Ew,
  group_outros: yw,
  init: Aw,
  insert: Sw,
  listen: xw,
  mount_component: Mw,
  safe_not_equal: Tw,
  space: Bw,
  toggle_class: Iw,
  transition_in: qw,
  transition_out: Ow
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lw,
  attr: Pw,
  create_slot: Nw,
  detach: Rw,
  element: Hw,
  get_all_dirty_from_scope: zw,
  get_slot_changes: jw,
  init: Yw,
  insert: Gw,
  null_to_empty: Uw,
  safe_not_equal: Ww,
  transition_in: Zw,
  transition_out: Kw,
  update_slot_base: Vw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xw,
  check_outros: Jw,
  create_component: Qw,
  destroy_component: eb,
  detach: tb,
  empty: nb,
  group_outros: ab,
  init: ib,
  insert: rb,
  mount_component: ob,
  noop: sb,
  safe_not_equal: lb,
  transition_in: ub,
  transition_out: cb
} = window.__gradio__svelte__internal, { createEventDispatcher: db } = window.__gradio__svelte__internal;
var xt = [
  "onChange",
  "onClose",
  "onDayCreate",
  "onDestroy",
  "onKeyDown",
  "onMonthChange",
  "onOpen",
  "onParseConfig",
  "onReady",
  "onValueUpdate",
  "onYearChange",
  "onPreCalendarPosition"
], Oe = {
  _disable: [],
  allowInput: !1,
  allowInvalidPreload: !1,
  altFormat: "F j, Y",
  altInput: !1,
  altInputClass: "form-control input",
  animate: typeof window == "object" && window.navigator.userAgent.indexOf("MSIE") === -1,
  ariaDateFormat: "F j, Y",
  autoFillDefaultTime: !0,
  clickOpens: !0,
  closeOnSelect: !0,
  conjunction: ", ",
  dateFormat: "Y-m-d",
  defaultHour: 12,
  defaultMinute: 0,
  defaultSeconds: 0,
  disable: [],
  disableMobile: !1,
  enableSeconds: !1,
  enableTime: !1,
  errorHandler: function(n) {
    return typeof console < "u" && console.warn(n);
  },
  getWeek: function(n) {
    var t = new Date(n.getTime());
    t.setHours(0, 0, 0, 0), t.setDate(t.getDate() + 3 - (t.getDay() + 6) % 7);
    var e = new Date(t.getFullYear(), 0, 4);
    return 1 + Math.round(((t.getTime() - e.getTime()) / 864e5 - 3 + (e.getDay() + 6) % 7) / 7);
  },
  hourIncrement: 1,
  ignoredFocusElements: [],
  inline: !1,
  locale: "default",
  minuteIncrement: 5,
  mode: "single",
  monthSelectorType: "dropdown",
  nextArrow: "<svg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 17 17'><g></g><path d='M13.207 8.472l-7.854 7.854-0.707-0.707 7.146-7.146-7.146-7.148 0.707-0.707 7.854 7.854z' /></svg>",
  noCalendar: !1,
  now: /* @__PURE__ */ new Date(),
  onChange: [],
  onClose: [],
  onDayCreate: [],
  onDestroy: [],
  onKeyDown: [],
  onMonthChange: [],
  onOpen: [],
  onParseConfig: [],
  onReady: [],
  onValueUpdate: [],
  onYearChange: [],
  onPreCalendarPosition: [],
  plugins: [],
  position: "auto",
  positionElement: void 0,
  prevArrow: "<svg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 17 17'><g></g><path d='M5.207 8.471l7.146 7.147-0.707 0.707-7.853-7.854 7.854-7.853 0.707 0.707-7.147 7.146z' /></svg>",
  shorthandCurrentMonth: !1,
  showMonths: 1,
  static: !1,
  time_24hr: !1,
  weekNumbers: !1,
  wrap: !1
}, Ke = {
  weekdays: {
    shorthand: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    longhand: [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday"
    ]
  },
  months: {
    shorthand: [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ],
    longhand: [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ]
  },
  daysInMonth: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
  firstDayOfWeek: 0,
  ordinal: function(n) {
    var t = n % 100;
    if (t > 3 && t < 21)
      return "th";
    switch (t % 10) {
      case 1:
        return "st";
      case 2:
        return "nd";
      case 3:
        return "rd";
      default:
        return "th";
    }
  },
  rangeSeparator: " to ",
  weekAbbreviation: "Wk",
  scrollTitle: "Scroll to increment",
  toggleTitle: "Click to toggle",
  amPM: ["AM", "PM"],
  yearAriaLabel: "Year",
  monthAriaLabel: "Month",
  hourAriaLabel: "Hour",
  minuteAriaLabel: "Minute",
  time_24hr: !1
}, ae = function(n, t) {
  return t === void 0 && (t = 2), ("000" + n).slice(t * -1);
}, ce = function(n) {
  return n === !0 ? 1 : 0;
};
function Sn(n, t) {
  var e;
  return function() {
    var a = this, i = arguments;
    clearTimeout(e), e = setTimeout(function() {
      return n.apply(a, i);
    }, t);
  };
}
var Mt = function(n) {
  return n instanceof Array ? n : [n];
};
function te(n, t, e) {
  if (e === !0)
    return n.classList.add(t);
  n.classList.remove(t);
}
function N(n, t, e) {
  var a = window.document.createElement(n);
  return t = t || "", e = e || "", a.className = t, e !== void 0 && (a.textContent = e), a;
}
function st(n) {
  for (; n.firstChild; )
    n.removeChild(n.firstChild);
}
function da(n, t) {
  if (t(n))
    return n;
  if (n.parentNode)
    return da(n.parentNode, t);
}
function lt(n, t) {
  var e = N("div", "numInputWrapper"), a = N("input", "numInput " + n), i = N("span", "arrowUp"), r = N("span", "arrowDown");
  if (navigator.userAgent.indexOf("MSIE 9.0") === -1 ? a.type = "number" : (a.type = "text", a.pattern = "\\d*"), t !== void 0)
    for (var o in t)
      a.setAttribute(o, t[o]);
  return e.appendChild(a), e.appendChild(i), e.appendChild(r), e;
}
function se(n) {
  try {
    if (typeof n.composedPath == "function") {
      var t = n.composedPath();
      return t[0];
    }
    return n.target;
  } catch {
    return n.target;
  }
}
var Tt = function() {
}, _t = function(n, t, e) {
  return e.months[t ? "shorthand" : "longhand"][n];
}, Eo = {
  D: Tt,
  F: function(n, t, e) {
    n.setMonth(e.months.longhand.indexOf(t));
  },
  G: function(n, t) {
    n.setHours((n.getHours() >= 12 ? 12 : 0) + parseFloat(t));
  },
  H: function(n, t) {
    n.setHours(parseFloat(t));
  },
  J: function(n, t) {
    n.setDate(parseFloat(t));
  },
  K: function(n, t, e) {
    n.setHours(n.getHours() % 12 + 12 * ce(new RegExp(e.amPM[1], "i").test(t)));
  },
  M: function(n, t, e) {
    n.setMonth(e.months.shorthand.indexOf(t));
  },
  S: function(n, t) {
    n.setSeconds(parseFloat(t));
  },
  U: function(n, t) {
    return new Date(parseFloat(t) * 1e3);
  },
  W: function(n, t, e) {
    var a = parseInt(t), i = new Date(n.getFullYear(), 0, 2 + (a - 1) * 7, 0, 0, 0, 0);
    return i.setDate(i.getDate() - i.getDay() + e.firstDayOfWeek), i;
  },
  Y: function(n, t) {
    n.setFullYear(parseFloat(t));
  },
  Z: function(n, t) {
    return new Date(t);
  },
  d: function(n, t) {
    n.setDate(parseFloat(t));
  },
  h: function(n, t) {
    n.setHours((n.getHours() >= 12 ? 12 : 0) + parseFloat(t));
  },
  i: function(n, t) {
    n.setMinutes(parseFloat(t));
  },
  j: function(n, t) {
    n.setDate(parseFloat(t));
  },
  l: Tt,
  m: function(n, t) {
    n.setMonth(parseFloat(t) - 1);
  },
  n: function(n, t) {
    n.setMonth(parseFloat(t) - 1);
  },
  s: function(n, t) {
    n.setSeconds(parseFloat(t));
  },
  u: function(n, t) {
    return new Date(parseFloat(t));
  },
  w: Tt,
  y: function(n, t) {
    n.setFullYear(2e3 + parseFloat(t));
  }
}, Ae = {
  D: "",
  F: "",
  G: "(\\d\\d|\\d)",
  H: "(\\d\\d|\\d)",
  J: "(\\d\\d|\\d)\\w+",
  K: "",
  M: "",
  S: "(\\d\\d|\\d)",
  U: "(.+)",
  W: "(\\d\\d|\\d)",
  Y: "(\\d{4})",
  Z: "(.+)",
  d: "(\\d\\d|\\d)",
  h: "(\\d\\d|\\d)",
  i: "(\\d\\d|\\d)",
  j: "(\\d\\d|\\d)",
  l: "",
  m: "(\\d\\d|\\d)",
  n: "(\\d\\d|\\d)",
  s: "(\\d\\d|\\d)",
  u: "(.+)",
  w: "(\\d\\d|\\d)",
  y: "(\\d{2})"
}, Ue = {
  Z: function(n) {
    return n.toISOString();
  },
  D: function(n, t, e) {
    return t.weekdays.shorthand[Ue.w(n, t, e)];
  },
  F: function(n, t, e) {
    return _t(Ue.n(n, t, e) - 1, !1, t);
  },
  G: function(n, t, e) {
    return ae(Ue.h(n, t, e));
  },
  H: function(n) {
    return ae(n.getHours());
  },
  J: function(n, t) {
    return t.ordinal !== void 0 ? n.getDate() + t.ordinal(n.getDate()) : n.getDate();
  },
  K: function(n, t) {
    return t.amPM[ce(n.getHours() > 11)];
  },
  M: function(n, t) {
    return _t(n.getMonth(), !0, t);
  },
  S: function(n) {
    return ae(n.getSeconds());
  },
  U: function(n) {
    return n.getTime() / 1e3;
  },
  W: function(n, t, e) {
    return e.getWeek(n);
  },
  Y: function(n) {
    return ae(n.getFullYear(), 4);
  },
  d: function(n) {
    return ae(n.getDate());
  },
  h: function(n) {
    return n.getHours() % 12 ? n.getHours() % 12 : 12;
  },
  i: function(n) {
    return ae(n.getMinutes());
  },
  j: function(n) {
    return n.getDate();
  },
  l: function(n, t) {
    return t.weekdays.longhand[n.getDay()];
  },
  m: function(n) {
    return ae(n.getMonth() + 1);
  },
  n: function(n) {
    return n.getMonth() + 1;
  },
  s: function(n) {
    return n.getSeconds();
  },
  u: function(n) {
    return n.getTime();
  },
  w: function(n) {
    return n.getDay();
  },
  y: function(n) {
    return String(n.getFullYear()).substring(2);
  }
}, fa = function(n) {
  var t = n.config, e = t === void 0 ? Oe : t, a = n.l10n, i = a === void 0 ? Ke : a, r = n.isMobile, o = r === void 0 ? !1 : r;
  return function(u, c, b) {
    var _ = b || i;
    return e.formatDate !== void 0 && !o ? e.formatDate(u, c, _) : c.split("").map(function(C, f, w) {
      return Ue[C] && w[f - 1] !== "\\" ? Ue[C](u, _, e) : C !== "\\" ? C : "";
    }).join("");
  };
}, Nt = function(n) {
  var t = n.config, e = t === void 0 ? Oe : t, a = n.l10n, i = a === void 0 ? Ke : a;
  return function(r, o, u, c) {
    if (!(r !== 0 && !r)) {
      var b = c || i, _, C = r;
      if (r instanceof Date)
        _ = new Date(r.getTime());
      else if (typeof r != "string" && r.toFixed !== void 0)
        _ = new Date(r);
      else if (typeof r == "string") {
        var f = o || (e || Oe).dateFormat, w = String(r).trim();
        if (w === "today")
          _ = /* @__PURE__ */ new Date(), u = !0;
        else if (e && e.parseDate)
          _ = e.parseDate(r, f);
        else if (/Z$/.test(w) || /GMT$/.test(w))
          _ = new Date(r);
        else {
          for (var O = void 0, k = [], B = 0, P = 0, g = ""; B < f.length; B++) {
            var p = f[B], F = p === "\\", m = f[B - 1] === "\\" || F;
            if (Ae[p] && !m) {
              g += Ae[p];
              var D = new RegExp(g).exec(r);
              D && (O = !0) && k[p !== "Y" ? "push" : "unshift"]({
                fn: Eo[p],
                val: D[++P]
              });
            } else F || (g += ".");
          }
          _ = !e || !e.noCalendar ? new Date((/* @__PURE__ */ new Date()).getFullYear(), 0, 1, 0, 0, 0, 0) : new Date((/* @__PURE__ */ new Date()).setHours(0, 0, 0, 0)), k.forEach(function(v) {
            var S = v.fn, E = v.val;
            return _ = S(_, E, b) || _;
          }), _ = O ? _ : void 0;
        }
      }
      if (!(_ instanceof Date && !isNaN(_.getTime()))) {
        e.errorHandler(new Error("Invalid date provided: " + C));
        return;
      }
      return u === !0 && _.setHours(0, 0, 0, 0), _;
    }
  };
};
function le(n, t, e) {
  return e === void 0 && (e = !0), e !== !1 ? new Date(n.getTime()).setHours(0, 0, 0, 0) - new Date(t.getTime()).setHours(0, 0, 0, 0) : n.getTime() - t.getTime();
}
var yo = function(n, t, e) {
  return n > Math.min(t, e) && n < Math.max(t, e);
}, Bt = function(n, t, e) {
  return n * 3600 + t * 60 + e;
}, Ao = function(n) {
  var t = Math.floor(n / 3600), e = (n - t * 3600) / 60;
  return [t, e, n - t * 3600 - e * 60];
}, So = {
  DAY: 864e5
};
function It(n) {
  var t = n.defaultHour, e = n.defaultMinute, a = n.defaultSeconds;
  if (n.minDate !== void 0) {
    var i = n.minDate.getHours(), r = n.minDate.getMinutes(), o = n.minDate.getSeconds();
    t < i && (t = i), t === i && e < r && (e = r), t === i && e === r && a < o && (a = n.minDate.getSeconds());
  }
  if (n.maxDate !== void 0) {
    var u = n.maxDate.getHours(), c = n.maxDate.getMinutes();
    t = Math.min(t, u), t === u && (e = Math.min(c, e)), t === u && e === c && (a = n.maxDate.getSeconds());
  }
  return { hours: t, minutes: e, seconds: a };
}
typeof Object.assign != "function" && (Object.assign = function(n) {
  for (var t = [], e = 1; e < arguments.length; e++)
    t[e - 1] = arguments[e];
  if (!n)
    throw TypeError("Cannot convert undefined or null to object");
  for (var a = function(u) {
    u && Object.keys(u).forEach(function(c) {
      return n[c] = u[c];
    });
  }, i = 0, r = t; i < r.length; i++) {
    var o = r[i];
    a(o);
  }
  return n;
});
var Q = function() {
  return Q = Object.assign || function(n) {
    for (var t, e = 1, a = arguments.length; e < a; e++) {
      t = arguments[e];
      for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (n[i] = t[i]);
    }
    return n;
  }, Q.apply(this, arguments);
}, xn = function() {
  for (var n = 0, t = 0, e = arguments.length; t < e; t++) n += arguments[t].length;
  for (var a = Array(n), i = 0, t = 0; t < e; t++)
    for (var r = arguments[t], o = 0, u = r.length; o < u; o++, i++)
      a[i] = r[o];
  return a;
}, xo = 300;
function Mo(n, t) {
  var e = {
    config: Q(Q({}, Oe), K.defaultConfig),
    l10n: Ke
  };
  e.parseDate = Nt({ config: e.config, l10n: e.l10n }), e._handlers = [], e.pluginElements = [], e.loadedPlugins = [], e._bind = k, e._setHoursFromDate = f, e._positionCalendar = Je, e.changeMonth = A, e.changeYear = De, e.clear = X, e.close = Te, e.onMouseOver = Be, e._createElement = N, e.createDay = D, e.destroy = re, e.isEnabled = de, e.jumpToDate = g, e.updateValue = ve, e.open = Da, e.redraw = en, e.set = Fa, e.setDate = Ca, e.toggle = ya;
  function a() {
    e.utils = {
      getDaysInMonth: function(s, l) {
        return s === void 0 && (s = e.currentMonth), l === void 0 && (l = e.currentYear), s === 1 && (l % 4 === 0 && l % 100 !== 0 || l % 400 === 0) ? 29 : e.l10n.daysInMonth[s];
      }
    };
  }
  function i() {
    e.element = e.input = n, e.isOpen = !1, va(), Qt(), ka(), $a(), a(), e.isMobile || m(), P(), (e.selectedDates.length || e.config.noCalendar) && (e.config.enableTime && f(e.config.noCalendar ? e.latestSelectedDateObj : void 0), ve(!1)), u();
    var s = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    !e.isMobile && s && Je(), W("onReady");
  }
  function r() {
    var s;
    return ((s = e.calendarContainer) === null || s === void 0 ? void 0 : s.getRootNode()).activeElement || document.activeElement;
  }
  function o(s) {
    return s.bind(e);
  }
  function u() {
    var s = e.config;
    s.weekNumbers === !1 && s.showMonths === 1 || s.noCalendar !== !0 && window.requestAnimationFrame(function() {
      if (e.calendarContainer !== void 0 && (e.calendarContainer.style.visibility = "hidden", e.calendarContainer.style.display = "block"), e.daysContainer !== void 0) {
        var l = (e.days.offsetWidth + 1) * s.showMonths;
        e.daysContainer.style.width = l + "px", e.calendarContainer.style.width = l + (e.weekWrapper !== void 0 ? e.weekWrapper.offsetWidth : 0) + "px", e.calendarContainer.style.removeProperty("visibility"), e.calendarContainer.style.removeProperty("display");
      }
    });
  }
  function c(s) {
    if (e.selectedDates.length === 0) {
      var l = e.config.minDate === void 0 || le(/* @__PURE__ */ new Date(), e.config.minDate) >= 0 ? /* @__PURE__ */ new Date() : new Date(e.config.minDate.getTime()), d = It(e.config);
      l.setHours(d.hours, d.minutes, d.seconds, l.getMilliseconds()), e.selectedDates = [l], e.latestSelectedDateObj = l;
    }
    s !== void 0 && s.type !== "blur" && xa(s);
    var h = e._input.value;
    C(), ve(), e._input.value !== h && e._debouncedChange();
  }
  function b(s, l) {
    return s % 12 + 12 * ce(l === e.l10n.amPM[1]);
  }
  function _(s) {
    switch (s % 24) {
      case 0:
      case 12:
        return 12;
      default:
        return s % 12;
    }
  }
  function C() {
    if (!(e.hourElement === void 0 || e.minuteElement === void 0)) {
      var s = (parseInt(e.hourElement.value.slice(-2), 10) || 0) % 24, l = (parseInt(e.minuteElement.value, 10) || 0) % 60, d = e.secondElement !== void 0 ? (parseInt(e.secondElement.value, 10) || 0) % 60 : 0;
      e.amPM !== void 0 && (s = b(s, e.amPM.textContent));
      var h = e.config.minTime !== void 0 || e.config.minDate && e.minDateHasTime && e.latestSelectedDateObj && le(e.latestSelectedDateObj, e.config.minDate, !0) === 0, $ = e.config.maxTime !== void 0 || e.config.maxDate && e.maxDateHasTime && e.latestSelectedDateObj && le(e.latestSelectedDateObj, e.config.maxDate, !0) === 0;
      if (e.config.maxTime !== void 0 && e.config.minTime !== void 0 && e.config.minTime > e.config.maxTime) {
        var y = Bt(e.config.minTime.getHours(), e.config.minTime.getMinutes(), e.config.minTime.getSeconds()), q = Bt(e.config.maxTime.getHours(), e.config.maxTime.getMinutes(), e.config.maxTime.getSeconds()), M = Bt(s, l, d);
        if (M > q && M < y) {
          var L = Ao(y);
          s = L[0], l = L[1], d = L[2];
        }
      } else {
        if ($) {
          var x = e.config.maxTime !== void 0 ? e.config.maxTime : e.config.maxDate;
          s = Math.min(s, x.getHours()), s === x.getHours() && (l = Math.min(l, x.getMinutes())), l === x.getMinutes() && (d = Math.min(d, x.getSeconds()));
        }
        if (h) {
          var I = e.config.minTime !== void 0 ? e.config.minTime : e.config.minDate;
          s = Math.max(s, I.getHours()), s === I.getHours() && l < I.getMinutes() && (l = I.getMinutes()), l === I.getMinutes() && (d = Math.max(d, I.getSeconds()));
        }
      }
      w(s, l, d);
    }
  }
  function f(s) {
    var l = s || e.latestSelectedDateObj;
    l && l instanceof Date && w(l.getHours(), l.getMinutes(), l.getSeconds());
  }
  function w(s, l, d) {
    e.latestSelectedDateObj !== void 0 && e.latestSelectedDateObj.setHours(s % 24, l, d || 0, 0), !(!e.hourElement || !e.minuteElement || e.isMobile) && (e.hourElement.value = ae(e.config.time_24hr ? s : (12 + s) % 12 + 12 * ce(s % 12 === 0)), e.minuteElement.value = ae(l), e.amPM !== void 0 && (e.amPM.textContent = e.l10n.amPM[ce(s >= 12)]), e.secondElement !== void 0 && (e.secondElement.value = ae(d)));
  }
  function O(s) {
    var l = se(s), d = parseInt(l.value) + (s.delta || 0);
    (d / 1e3 > 1 || s.key === "Enter" && !/[^\d]/.test(d.toString())) && De(d);
  }
  function k(s, l, d, h) {
    if (l instanceof Array)
      return l.forEach(function($) {
        return k(s, $, d, h);
      });
    if (s instanceof Array)
      return s.forEach(function($) {
        return k($, l, d, h);
      });
    s.addEventListener(l, d, h), e._handlers.push({
      remove: function() {
        return s.removeEventListener(l, d, h);
      }
    });
  }
  function B() {
    W("onChange");
  }
  function P() {
    if (e.config.wrap && ["open", "close", "toggle", "clear"].forEach(function(d) {
      Array.prototype.forEach.call(e.element.querySelectorAll("[data-" + d + "]"), function(h) {
        return k(h, "click", e[d]);
      });
    }), e.isMobile) {
      Ea();
      return;
    }
    var s = Sn(Ne, 50);
    if (e._debouncedChange = Sn(B, xo), e.daysContainer && !/iPhone|iPad|iPod/i.test(navigator.userAgent) && k(e.daysContainer, "mouseover", function(d) {
      e.config.mode === "range" && Be(se(d));
    }), k(e._input, "keydown", Ee), e.calendarContainer !== void 0 && k(e.calendarContainer, "keydown", Ee), !e.config.inline && !e.config.static && k(window, "resize", s), window.ontouchstart !== void 0 ? k(window.document, "touchstart", ge) : k(window.document, "mousedown", ge), k(window.document, "focus", ge, { capture: !0 }), e.config.clickOpens === !0 && (k(e._input, "focus", e.open), k(e._input, "click", e.open)), e.daysContainer !== void 0 && (k(e.monthNav, "click", Sa), k(e.monthNav, ["keyup", "increment"], O), k(e.daysContainer, "click", tn)), e.timeContainer !== void 0 && e.minuteElement !== void 0 && e.hourElement !== void 0) {
      var l = function(d) {
        return se(d).select();
      };
      k(e.timeContainer, ["increment"], c), k(e.timeContainer, "blur", c, { capture: !0 }), k(e.timeContainer, "click", p), k([e.hourElement, e.minuteElement], ["focus", "click"], l), e.secondElement !== void 0 && k(e.secondElement, "focus", function() {
        return e.secondElement && e.secondElement.select();
      }), e.amPM !== void 0 && k(e.amPM, "click", function(d) {
        c(d);
      });
    }
    e.config.allowInput && k(e._input, "blur", Pe);
  }
  function g(s, l) {
    var d = s !== void 0 ? e.parseDate(s) : e.latestSelectedDateObj || (e.config.minDate && e.config.minDate > e.now ? e.config.minDate : e.config.maxDate && e.config.maxDate < e.now ? e.config.maxDate : e.now), h = e.currentYear, $ = e.currentMonth;
    try {
      d !== void 0 && (e.currentYear = d.getFullYear(), e.currentMonth = d.getMonth());
    } catch (y) {
      y.message = "Invalid date supplied: " + d, e.config.errorHandler(y);
    }
    l && e.currentYear !== h && (W("onYearChange"), ie()), l && (e.currentYear !== h || e.currentMonth !== $) && W("onMonthChange"), e.redraw();
  }
  function p(s) {
    var l = se(s);
    ~l.className.indexOf("arrow") && F(s, l.classList.contains("arrowUp") ? 1 : -1);
  }
  function F(s, l, d) {
    var h = s && se(s), $ = d || h && h.parentNode && h.parentNode.firstChild, y = wt("increment");
    y.delta = l, $ && $.dispatchEvent(y);
  }
  function m() {
    var s = window.document.createDocumentFragment();
    if (e.calendarContainer = N("div", "flatpickr-calendar"), e.calendarContainer.tabIndex = -1, !e.config.noCalendar) {
      if (s.appendChild(Ce()), e.innerContainer = N("div", "flatpickr-innerContainer"), e.config.weekNumbers) {
        var l = pe(), d = l.weekWrapper, h = l.weekNumbers;
        e.innerContainer.appendChild(d), e.weekNumbers = h, e.weekWrapper = d;
      }
      e.rContainer = N("div", "flatpickr-rContainer"), e.rContainer.appendChild(Z()), e.daysContainer || (e.daysContainer = N("div", "flatpickr-days"), e.daysContainer.tabIndex = -1), R(), e.rContainer.appendChild(e.daysContainer), e.innerContainer.appendChild(e.rContainer), s.appendChild(e.innerContainer);
    }
    e.config.enableTime && s.appendChild($e()), te(e.calendarContainer, "rangeMode", e.config.mode === "range"), te(e.calendarContainer, "animate", e.config.animate === !0), te(e.calendarContainer, "multiMonth", e.config.showMonths > 1), e.calendarContainer.appendChild(s);
    var $ = e.config.appendTo !== void 0 && e.config.appendTo.nodeType !== void 0;
    if ((e.config.inline || e.config.static) && (e.calendarContainer.classList.add(e.config.inline ? "inline" : "static"), e.config.inline && (!$ && e.element.parentNode ? e.element.parentNode.insertBefore(e.calendarContainer, e._input.nextSibling) : e.config.appendTo !== void 0 && e.config.appendTo.appendChild(e.calendarContainer)), e.config.static)) {
      var y = N("div", "flatpickr-wrapper");
      e.element.parentNode && e.element.parentNode.insertBefore(y, e.element), y.appendChild(e.element), e.altInput && y.appendChild(e.altInput), y.appendChild(e.calendarContainer);
    }
    !e.config.static && !e.config.inline && (e.config.appendTo !== void 0 ? e.config.appendTo : window.document.body).appendChild(e.calendarContainer);
  }
  function D(s, l, d, h) {
    var $ = de(l, !0), y = N("span", s, l.getDate().toString());
    return y.dateObj = l, y.$i = h, y.setAttribute("aria-label", e.formatDate(l, e.config.ariaDateFormat)), s.indexOf("hidden") === -1 && le(l, e.now) === 0 && (e.todayDateElem = y, y.classList.add("today"), y.setAttribute("aria-current", "date")), $ ? (y.tabIndex = -1, bt(l) && (y.classList.add("selected"), e.selectedDateElem = y, e.config.mode === "range" && (te(y, "startRange", e.selectedDates[0] && le(l, e.selectedDates[0], !0) === 0), te(y, "endRange", e.selectedDates[1] && le(l, e.selectedDates[1], !0) === 0), s === "nextMonthDay" && y.classList.add("inRange")))) : y.classList.add("flatpickr-disabled"), e.config.mode === "range" && Aa(l) && !bt(l) && y.classList.add("inRange"), e.weekNumbers && e.config.showMonths === 1 && s !== "prevMonthDay" && h % 7 === 6 && e.weekNumbers.insertAdjacentHTML("beforeend", "<span class='flatpickr-day'>" + e.config.getWeek(l) + "</span>"), W("onDayCreate", y), y;
  }
  function v(s) {
    s.focus(), e.config.mode === "range" && Be(s);
  }
  function S(s) {
    for (var l = s > 0 ? 0 : e.config.showMonths - 1, d = s > 0 ? e.config.showMonths : -1, h = l; h != d; h += s)
      for (var $ = e.daysContainer.children[h], y = s > 0 ? 0 : $.children.length - 1, q = s > 0 ? $.children.length : -1, M = y; M != q; M += s) {
        var L = $.children[M];
        if (L.className.indexOf("hidden") === -1 && de(L.dateObj))
          return L;
      }
  }
  function E(s, l) {
    for (var d = s.className.indexOf("Month") === -1 ? s.dateObj.getMonth() : e.currentMonth, h = l > 0 ? e.config.showMonths : -1, $ = l > 0 ? 1 : -1, y = d - e.currentMonth; y != h; y += $)
      for (var q = e.daysContainer.children[y], M = d - e.currentMonth === y ? s.$i + l : l < 0 ? q.children.length - 1 : 0, L = q.children.length, x = M; x >= 0 && x < L && x != (l > 0 ? L : -1); x += $) {
        var I = q.children[x];
        if (I.className.indexOf("hidden") === -1 && de(I.dateObj) && Math.abs(s.$i - x) >= Math.abs(l))
          return v(I);
      }
    e.changeMonth($), T(S($), 0);
  }
  function T(s, l) {
    var d = r(), h = ke(d || document.body), $ = s !== void 0 ? s : h ? d : e.selectedDateElem !== void 0 && ke(e.selectedDateElem) ? e.selectedDateElem : e.todayDateElem !== void 0 && ke(e.todayDateElem) ? e.todayDateElem : S(l > 0 ? 1 : -1);
    $ === void 0 ? e._input.focus() : h ? E($, l) : v($);
  }
  function Y(s, l) {
    for (var d = (new Date(s, l, 1).getDay() - e.l10n.firstDayOfWeek + 7) % 7, h = e.utils.getDaysInMonth((l - 1 + 12) % 12, s), $ = e.utils.getDaysInMonth(l, s), y = window.document.createDocumentFragment(), q = e.config.showMonths > 1, M = q ? "prevMonthDay hidden" : "prevMonthDay", L = q ? "nextMonthDay hidden" : "nextMonthDay", x = h + 1 - d, I = 0; x <= h; x++, I++)
      y.appendChild(D("flatpickr-day " + M, new Date(s, l - 1, x), x, I));
    for (x = 1; x <= $; x++, I++)
      y.appendChild(D("flatpickr-day", new Date(s, l, x), x, I));
    for (var G = $ + 1; G <= 42 - d && (e.config.showMonths === 1 || I % 7 !== 0); G++, I++)
      y.appendChild(D("flatpickr-day " + L, new Date(s, l + 1, G % $), G, I));
    var he = N("div", "dayContainer");
    return he.appendChild(y), he;
  }
  function R() {
    if (e.daysContainer !== void 0) {
      st(e.daysContainer), e.weekNumbers && st(e.weekNumbers);
      for (var s = document.createDocumentFragment(), l = 0; l < e.config.showMonths; l++) {
        var d = new Date(e.currentYear, e.currentMonth, 1);
        d.setMonth(e.currentMonth + l), s.appendChild(Y(d.getFullYear(), d.getMonth()));
      }
      e.daysContainer.appendChild(s), e.days = e.daysContainer.firstChild, e.config.mode === "range" && e.selectedDates.length === 1 && Be();
    }
  }
  function ie() {
    if (!(e.config.showMonths > 1 || e.config.monthSelectorType !== "dropdown")) {
      var s = function(h) {
        return e.config.minDate !== void 0 && e.currentYear === e.config.minDate.getFullYear() && h < e.config.minDate.getMonth() ? !1 : !(e.config.maxDate !== void 0 && e.currentYear === e.config.maxDate.getFullYear() && h > e.config.maxDate.getMonth());
      };
      e.monthsDropdownContainer.tabIndex = -1, e.monthsDropdownContainer.innerHTML = "";
      for (var l = 0; l < 12; l++)
        if (s(l)) {
          var d = N("option", "flatpickr-monthDropdown-month");
          d.value = new Date(e.currentYear, l).getMonth().toString(), d.textContent = _t(l, e.config.shorthandCurrentMonth, e.l10n), d.tabIndex = -1, e.currentMonth === l && (d.selected = !0), e.monthsDropdownContainer.appendChild(d);
        }
    }
  }
  function we() {
    var s = N("div", "flatpickr-month"), l = window.document.createDocumentFragment(), d;
    e.config.showMonths > 1 || e.config.monthSelectorType === "static" ? d = N("span", "cur-month") : (e.monthsDropdownContainer = N("select", "flatpickr-monthDropdown-months"), e.monthsDropdownContainer.setAttribute("aria-label", e.l10n.monthAriaLabel), k(e.monthsDropdownContainer, "change", function(q) {
      var M = se(q), L = parseInt(M.value, 10);
      e.changeMonth(L - e.currentMonth), W("onMonthChange");
    }), ie(), d = e.monthsDropdownContainer);
    var h = lt("cur-year", { tabindex: "-1" }), $ = h.getElementsByTagName("input")[0];
    $.setAttribute("aria-label", e.l10n.yearAriaLabel), e.config.minDate && $.setAttribute("min", e.config.minDate.getFullYear().toString()), e.config.maxDate && ($.setAttribute("max", e.config.maxDate.getFullYear().toString()), $.disabled = !!e.config.minDate && e.config.minDate.getFullYear() === e.config.maxDate.getFullYear());
    var y = N("div", "flatpickr-current-month");
    return y.appendChild(d), y.appendChild(h), l.appendChild(y), s.appendChild(l), {
      container: s,
      yearElement: $,
      monthElement: d
    };
  }
  function Fe() {
    st(e.monthNav), e.monthNav.appendChild(e.prevMonthNav), e.config.showMonths && (e.yearElements = [], e.monthElements = []);
    for (var s = e.config.showMonths; s--; ) {
      var l = we();
      e.yearElements.push(l.yearElement), e.monthElements.push(l.monthElement), e.monthNav.appendChild(l.container);
    }
    e.monthNav.appendChild(e.nextMonthNav);
  }
  function Ce() {
    return e.monthNav = N("div", "flatpickr-months"), e.yearElements = [], e.monthElements = [], e.prevMonthNav = N("span", "flatpickr-prev-month"), e.prevMonthNav.innerHTML = e.config.prevArrow, e.nextMonthNav = N("span", "flatpickr-next-month"), e.nextMonthNav.innerHTML = e.config.nextArrow, Fe(), Object.defineProperty(e, "_hidePrevMonthArrow", {
      get: function() {
        return e.__hidePrevMonthArrow;
      },
      set: function(s) {
        e.__hidePrevMonthArrow !== s && (te(e.prevMonthNav, "flatpickr-disabled", s), e.__hidePrevMonthArrow = s);
      }
    }), Object.defineProperty(e, "_hideNextMonthArrow", {
      get: function() {
        return e.__hideNextMonthArrow;
      },
      set: function(s) {
        e.__hideNextMonthArrow !== s && (te(e.nextMonthNav, "flatpickr-disabled", s), e.__hideNextMonthArrow = s);
      }
    }), e.currentYearElement = e.yearElements[0], et(), e.monthNav;
  }
  function $e() {
    e.calendarContainer.classList.add("hasTime"), e.config.noCalendar && e.calendarContainer.classList.add("noCalendar");
    var s = It(e.config);
    e.timeContainer = N("div", "flatpickr-time"), e.timeContainer.tabIndex = -1;
    var l = N("span", "flatpickr-time-separator", ":"), d = lt("flatpickr-hour", {
      "aria-label": e.l10n.hourAriaLabel
    });
    e.hourElement = d.getElementsByTagName("input")[0];
    var h = lt("flatpickr-minute", {
      "aria-label": e.l10n.minuteAriaLabel
    });
    if (e.minuteElement = h.getElementsByTagName("input")[0], e.hourElement.tabIndex = e.minuteElement.tabIndex = -1, e.hourElement.value = ae(e.latestSelectedDateObj ? e.latestSelectedDateObj.getHours() : e.config.time_24hr ? s.hours : _(s.hours)), e.minuteElement.value = ae(e.latestSelectedDateObj ? e.latestSelectedDateObj.getMinutes() : s.minutes), e.hourElement.setAttribute("step", e.config.hourIncrement.toString()), e.minuteElement.setAttribute("step", e.config.minuteIncrement.toString()), e.hourElement.setAttribute("min", e.config.time_24hr ? "0" : "1"), e.hourElement.setAttribute("max", e.config.time_24hr ? "23" : "12"), e.hourElement.setAttribute("maxlength", "2"), e.minuteElement.setAttribute("min", "0"), e.minuteElement.setAttribute("max", "59"), e.minuteElement.setAttribute("maxlength", "2"), e.timeContainer.appendChild(d), e.timeContainer.appendChild(l), e.timeContainer.appendChild(h), e.config.time_24hr && e.timeContainer.classList.add("time24hr"), e.config.enableSeconds) {
      e.timeContainer.classList.add("hasSeconds");
      var $ = lt("flatpickr-second");
      e.secondElement = $.getElementsByTagName("input")[0], e.secondElement.value = ae(e.latestSelectedDateObj ? e.latestSelectedDateObj.getSeconds() : s.seconds), e.secondElement.setAttribute("step", e.minuteElement.getAttribute("step")), e.secondElement.setAttribute("min", "0"), e.secondElement.setAttribute("max", "59"), e.secondElement.setAttribute("maxlength", "2"), e.timeContainer.appendChild(N("span", "flatpickr-time-separator", ":")), e.timeContainer.appendChild($);
    }
    return e.config.time_24hr || (e.amPM = N("span", "flatpickr-am-pm", e.l10n.amPM[ce((e.latestSelectedDateObj ? e.hourElement.value : e.config.defaultHour) > 11)]), e.amPM.title = e.l10n.toggleTitle, e.amPM.tabIndex = -1, e.timeContainer.appendChild(e.amPM)), e.timeContainer;
  }
  function Z() {
    e.weekdayContainer ? st(e.weekdayContainer) : e.weekdayContainer = N("div", "flatpickr-weekdays");
    for (var s = e.config.showMonths; s--; ) {
      var l = N("div", "flatpickr-weekdaycontainer");
      e.weekdayContainer.appendChild(l);
    }
    return ee(), e.weekdayContainer;
  }
  function ee() {
    if (e.weekdayContainer) {
      var s = e.l10n.firstDayOfWeek, l = xn(e.l10n.weekdays.shorthand);
      s > 0 && s < l.length && (l = xn(l.splice(s, l.length), l.splice(0, s)));
      for (var d = e.config.showMonths; d--; )
        e.weekdayContainer.children[d].innerHTML = `
      <span class='flatpickr-weekday'>
        ` + l.join("</span><span class='flatpickr-weekday'>") + `
      </span>
      `;
    }
  }
  function pe() {
    e.calendarContainer.classList.add("hasWeeks");
    var s = N("div", "flatpickr-weekwrapper");
    s.appendChild(N("span", "flatpickr-weekday", e.l10n.weekAbbreviation));
    var l = N("div", "flatpickr-weeks");
    return s.appendChild(l), {
      weekWrapper: s,
      weekNumbers: l
    };
  }
  function A(s, l) {
    l === void 0 && (l = !0);
    var d = l ? s : s - e.currentMonth;
    d < 0 && e._hidePrevMonthArrow === !0 || d > 0 && e._hideNextMonthArrow === !0 || (e.currentMonth += d, (e.currentMonth < 0 || e.currentMonth > 11) && (e.currentYear += e.currentMonth > 11 ? 1 : -1, e.currentMonth = (e.currentMonth + 12) % 12, W("onYearChange"), ie()), R(), W("onMonthChange"), et());
  }
  function X(s, l) {
    if (s === void 0 && (s = !0), l === void 0 && (l = !0), e.input.value = "", e.altInput !== void 0 && (e.altInput.value = ""), e.mobileInput !== void 0 && (e.mobileInput.value = ""), e.selectedDates = [], e.latestSelectedDateObj = void 0, l === !0 && (e.currentYear = e._initialDate.getFullYear(), e.currentMonth = e._initialDate.getMonth()), e.config.enableTime === !0) {
      var d = It(e.config), h = d.hours, $ = d.minutes, y = d.seconds;
      w(h, $, y);
    }
    e.redraw(), s && W("onChange");
  }
  function Te() {
    e.isOpen = !1, e.isMobile || (e.calendarContainer !== void 0 && e.calendarContainer.classList.remove("open"), e._input !== void 0 && e._input.classList.remove("active")), W("onClose");
  }
  function re() {
    e.config !== void 0 && W("onDestroy");
    for (var s = e._handlers.length; s--; )
      e._handlers[s].remove();
    if (e._handlers = [], e.mobileInput)
      e.mobileInput.parentNode && e.mobileInput.parentNode.removeChild(e.mobileInput), e.mobileInput = void 0;
    else if (e.calendarContainer && e.calendarContainer.parentNode)
      if (e.config.static && e.calendarContainer.parentNode) {
        var l = e.calendarContainer.parentNode;
        if (l.lastChild && l.removeChild(l.lastChild), l.parentNode) {
          for (; l.firstChild; )
            l.parentNode.insertBefore(l.firstChild, l);
          l.parentNode.removeChild(l);
        }
      } else
        e.calendarContainer.parentNode.removeChild(e.calendarContainer);
    e.altInput && (e.input.type = "text", e.altInput.parentNode && e.altInput.parentNode.removeChild(e.altInput), delete e.altInput), e.input && (e.input.type = e.input._type, e.input.classList.remove("flatpickr-input"), e.input.removeAttribute("readonly")), [
      "_showTimeInput",
      "latestSelectedDateObj",
      "_hideNextMonthArrow",
      "_hidePrevMonthArrow",
      "__hideNextMonthArrow",
      "__hidePrevMonthArrow",
      "isMobile",
      "isOpen",
      "selectedDateElem",
      "minDateHasTime",
      "maxDateHasTime",
      "days",
      "daysContainer",
      "_input",
      "_positionElement",
      "innerContainer",
      "rContainer",
      "monthNav",
      "todayDateElem",
      "calendarContainer",
      "weekdayContainer",
      "prevMonthNav",
      "nextMonthNav",
      "monthsDropdownContainer",
      "currentMonthElement",
      "currentYearElement",
      "navigationCurrentMonth",
      "selectedDateElem",
      "config"
    ].forEach(function(d) {
      try {
        delete e[d];
      } catch {
      }
    });
  }
  function ne(s) {
    return e.calendarContainer.contains(s);
  }
  function ge(s) {
    if (e.isOpen && !e.config.inline) {
      var l = se(s), d = ne(l), h = l === e.input || l === e.altInput || e.element.contains(l) || s.path && s.path.indexOf && (~s.path.indexOf(e.input) || ~s.path.indexOf(e.altInput)), $ = !h && !d && !ne(s.relatedTarget), y = !e.config.ignoredFocusElements.some(function(q) {
        return q.contains(l);
      });
      $ && y && (e.config.allowInput && e.setDate(e._input.value, !1, e.config.altInput ? e.config.altFormat : e.config.dateFormat), e.timeContainer !== void 0 && e.minuteElement !== void 0 && e.hourElement !== void 0 && e.input.value !== "" && e.input.value !== void 0 && c(), e.close(), e.config && e.config.mode === "range" && e.selectedDates.length === 1 && e.clear(!1));
    }
  }
  function De(s) {
    if (!(!s || e.config.minDate && s < e.config.minDate.getFullYear() || e.config.maxDate && s > e.config.maxDate.getFullYear())) {
      var l = s, d = e.currentYear !== l;
      e.currentYear = l || e.currentYear, e.config.maxDate && e.currentYear === e.config.maxDate.getFullYear() ? e.currentMonth = Math.min(e.config.maxDate.getMonth(), e.currentMonth) : e.config.minDate && e.currentYear === e.config.minDate.getFullYear() && (e.currentMonth = Math.max(e.config.minDate.getMonth(), e.currentMonth)), d && (e.redraw(), W("onYearChange"), ie());
    }
  }
  function de(s, l) {
    var d;
    l === void 0 && (l = !0);
    var h = e.parseDate(s, void 0, l);
    if (e.config.minDate && h && le(h, e.config.minDate, l !== void 0 ? l : !e.minDateHasTime) < 0 || e.config.maxDate && h && le(h, e.config.maxDate, l !== void 0 ? l : !e.maxDateHasTime) > 0)
      return !1;
    if (!e.config.enable && e.config.disable.length === 0)
      return !0;
    if (h === void 0)
      return !1;
    for (var $ = !!e.config.enable, y = (d = e.config.enable) !== null && d !== void 0 ? d : e.config.disable, q = 0, M = void 0; q < y.length; q++) {
      if (M = y[q], typeof M == "function" && M(h))
        return $;
      if (M instanceof Date && h !== void 0 && M.getTime() === h.getTime())
        return $;
      if (typeof M == "string") {
        var L = e.parseDate(M, void 0, !0);
        return L && L.getTime() === h.getTime() ? $ : !$;
      } else if (typeof M == "object" && h !== void 0 && M.from && M.to && h.getTime() >= M.from.getTime() && h.getTime() <= M.to.getTime())
        return $;
    }
    return !$;
  }
  function ke(s) {
    return e.daysContainer !== void 0 ? s.className.indexOf("hidden") === -1 && s.className.indexOf("flatpickr-disabled") === -1 && e.daysContainer.contains(s) : !1;
  }
  function Pe(s) {
    var l = s.target === e._input, d = e._input.value.trimEnd() !== Ft();
    l && d && !(s.relatedTarget && ne(s.relatedTarget)) && e.setDate(e._input.value, !0, s.target === e.altInput ? e.config.altFormat : e.config.dateFormat);
  }
  function Ee(s) {
    var l = se(s), d = e.config.wrap ? n.contains(l) : l === e._input, h = e.config.allowInput, $ = e.isOpen && (!h || !d), y = e.config.inline && d && !h;
    if (s.keyCode === 13 && d) {
      if (h)
        return e.setDate(e._input.value, !0, l === e.altInput ? e.config.altFormat : e.config.dateFormat), e.close(), l.blur();
      e.open();
    } else if (ne(l) || $ || y) {
      var q = !!e.timeContainer && e.timeContainer.contains(l);
      switch (s.keyCode) {
        case 13:
          q ? (s.preventDefault(), c(), vt()) : tn(s);
          break;
        case 27:
          s.preventDefault(), vt();
          break;
        case 8:
        case 46:
          d && !e.config.allowInput && (s.preventDefault(), e.clear());
          break;
        case 37:
        case 39:
          if (!q && !d) {
            s.preventDefault();
            var M = r();
            if (e.daysContainer !== void 0 && (h === !1 || M && ke(M))) {
              var L = s.keyCode === 39 ? 1 : -1;
              s.ctrlKey ? (s.stopPropagation(), A(L), T(S(1), 0)) : T(void 0, L);
            }
          } else e.hourElement && e.hourElement.focus();
          break;
        case 38:
        case 40:
          s.preventDefault();
          var x = s.keyCode === 40 ? 1 : -1;
          e.daysContainer && l.$i !== void 0 || l === e.input || l === e.altInput ? s.ctrlKey ? (s.stopPropagation(), De(e.currentYear - x), T(S(1), 0)) : q || T(void 0, x * 7) : l === e.currentYearElement ? De(e.currentYear - x) : e.config.enableTime && (!q && e.hourElement && e.hourElement.focus(), c(s), e._debouncedChange());
          break;
        case 9:
          if (q) {
            var I = [
              e.hourElement,
              e.minuteElement,
              e.secondElement,
              e.amPM
            ].concat(e.pluginElements).filter(function(oe) {
              return oe;
            }), G = I.indexOf(l);
            if (G !== -1) {
              var he = I[G + (s.shiftKey ? -1 : 1)];
              s.preventDefault(), (he || e._input).focus();
            }
          } else !e.config.noCalendar && e.daysContainer && e.daysContainer.contains(l) && s.shiftKey && (s.preventDefault(), e._input.focus());
          break;
      }
    }
    if (e.amPM !== void 0 && l === e.amPM)
      switch (s.key) {
        case e.l10n.amPM[0].charAt(0):
        case e.l10n.amPM[0].charAt(0).toLowerCase():
          e.amPM.textContent = e.l10n.amPM[0], C(), ve();
          break;
        case e.l10n.amPM[1].charAt(0):
        case e.l10n.amPM[1].charAt(0).toLowerCase():
          e.amPM.textContent = e.l10n.amPM[1], C(), ve();
          break;
      }
    (d || ne(l)) && W("onKeyDown", s);
  }
  function Be(s, l) {
    if (l === void 0 && (l = "flatpickr-day"), !(e.selectedDates.length !== 1 || s && (!s.classList.contains(l) || s.classList.contains("flatpickr-disabled")))) {
      for (var d = s ? s.dateObj.getTime() : e.days.firstElementChild.dateObj.getTime(), h = e.parseDate(e.selectedDates[0], void 0, !0).getTime(), $ = Math.min(d, e.selectedDates[0].getTime()), y = Math.max(d, e.selectedDates[0].getTime()), q = !1, M = 0, L = 0, x = $; x < y; x += So.DAY)
        de(new Date(x), !0) || (q = q || x > $ && x < y, x < h && (!M || x > M) ? M = x : x > h && (!L || x < L) && (L = x));
      var I = Array.from(e.rContainer.querySelectorAll("*:nth-child(-n+" + e.config.showMonths + ") > ." + l));
      I.forEach(function(G) {
        var he = G.dateObj, oe = he.getTime(), Re = M > 0 && oe < M || L > 0 && oe > L;
        if (Re) {
          G.classList.add("notAllowed"), ["inRange", "startRange", "endRange"].forEach(function(Ie) {
            G.classList.remove(Ie);
          });
          return;
        } else if (q && !Re)
          return;
        ["startRange", "inRange", "endRange", "notAllowed"].forEach(function(Ie) {
          G.classList.remove(Ie);
        }), s !== void 0 && (s.classList.add(d <= e.selectedDates[0].getTime() ? "startRange" : "endRange"), h < d && oe === h ? G.classList.add("startRange") : h > d && oe === h && G.classList.add("endRange"), oe >= M && (L === 0 || oe <= L) && yo(oe, h, d) && G.classList.add("inRange"));
      });
    }
  }
  function Ne() {
    e.isOpen && !e.config.static && !e.config.inline && Je();
  }
  function Da(s, l) {
    if (l === void 0 && (l = e._positionElement), e.isMobile === !0) {
      if (s) {
        s.preventDefault();
        var d = se(s);
        d && d.blur();
      }
      e.mobileInput !== void 0 && (e.mobileInput.focus(), e.mobileInput.click()), W("onOpen");
      return;
    } else if (e._input.disabled || e.config.inline)
      return;
    var h = e.isOpen;
    e.isOpen = !0, h || (e.calendarContainer.classList.add("open"), e._input.classList.add("active"), W("onOpen"), Je(l)), e.config.enableTime === !0 && e.config.noCalendar === !0 && e.config.allowInput === !1 && (s === void 0 || !e.timeContainer.contains(s.relatedTarget)) && setTimeout(function() {
      return e.hourElement.select();
    }, 50);
  }
  function Xt(s) {
    return function(l) {
      var d = e.config["_" + s + "Date"] = e.parseDate(l, e.config.dateFormat), h = e.config["_" + (s === "min" ? "max" : "min") + "Date"];
      d !== void 0 && (e[s === "min" ? "minDateHasTime" : "maxDateHasTime"] = d.getHours() > 0 || d.getMinutes() > 0 || d.getSeconds() > 0), e.selectedDates && (e.selectedDates = e.selectedDates.filter(function($) {
        return de($);
      }), !e.selectedDates.length && s === "min" && f(d), ve()), e.daysContainer && (en(), d !== void 0 ? e.currentYearElement[s] = d.getFullYear().toString() : e.currentYearElement.removeAttribute(s), e.currentYearElement.disabled = !!h && d !== void 0 && h.getFullYear() === d.getFullYear());
    };
  }
  function va() {
    var s = [
      "wrap",
      "weekNumbers",
      "allowInput",
      "allowInvalidPreload",
      "clickOpens",
      "time_24hr",
      "enableTime",
      "noCalendar",
      "altInput",
      "shorthandCurrentMonth",
      "inline",
      "static",
      "enableSeconds",
      "disableMobile"
    ], l = Q(Q({}, JSON.parse(JSON.stringify(n.dataset || {}))), t), d = {};
    e.config.parseDate = l.parseDate, e.config.formatDate = l.formatDate, Object.defineProperty(e.config, "enable", {
      get: function() {
        return e.config._enable;
      },
      set: function(I) {
        e.config._enable = an(I);
      }
    }), Object.defineProperty(e.config, "disable", {
      get: function() {
        return e.config._disable;
      },
      set: function(I) {
        e.config._disable = an(I);
      }
    });
    var h = l.mode === "time";
    if (!l.dateFormat && (l.enableTime || h)) {
      var $ = K.defaultConfig.dateFormat || Oe.dateFormat;
      d.dateFormat = l.noCalendar || h ? "H:i" + (l.enableSeconds ? ":S" : "") : $ + " H:i" + (l.enableSeconds ? ":S" : "");
    }
    if (l.altInput && (l.enableTime || h) && !l.altFormat) {
      var y = K.defaultConfig.altFormat || Oe.altFormat;
      d.altFormat = l.noCalendar || h ? "h:i" + (l.enableSeconds ? ":S K" : " K") : y + (" h:i" + (l.enableSeconds ? ":S" : "") + " K");
    }
    Object.defineProperty(e.config, "minDate", {
      get: function() {
        return e.config._minDate;
      },
      set: Xt("min")
    }), Object.defineProperty(e.config, "maxDate", {
      get: function() {
        return e.config._maxDate;
      },
      set: Xt("max")
    });
    var q = function(I) {
      return function(G) {
        e.config[I === "min" ? "_minTime" : "_maxTime"] = e.parseDate(G, "H:i:S");
      };
    };
    Object.defineProperty(e.config, "minTime", {
      get: function() {
        return e.config._minTime;
      },
      set: q("min")
    }), Object.defineProperty(e.config, "maxTime", {
      get: function() {
        return e.config._maxTime;
      },
      set: q("max")
    }), l.mode === "time" && (e.config.noCalendar = !0, e.config.enableTime = !0), Object.assign(e.config, d, l);
    for (var M = 0; M < s.length; M++)
      e.config[s[M]] = e.config[s[M]] === !0 || e.config[s[M]] === "true";
    xt.filter(function(I) {
      return e.config[I] !== void 0;
    }).forEach(function(I) {
      e.config[I] = Mt(e.config[I] || []).map(o);
    }), e.isMobile = !e.config.disableMobile && !e.config.inline && e.config.mode === "single" && !e.config.disable.length && !e.config.enable && !e.config.weekNumbers && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    for (var M = 0; M < e.config.plugins.length; M++) {
      var L = e.config.plugins[M](e) || {};
      for (var x in L)
        xt.indexOf(x) > -1 ? e.config[x] = Mt(L[x]).map(o).concat(e.config[x]) : typeof l[x] > "u" && (e.config[x] = L[x]);
    }
    l.altInputClass || (e.config.altInputClass = Jt().className + " " + e.config.altInputClass), W("onParseConfig");
  }
  function Jt() {
    return e.config.wrap ? n.querySelector("[data-input]") : n;
  }
  function Qt() {
    typeof e.config.locale != "object" && typeof K.l10ns[e.config.locale] > "u" && e.config.errorHandler(new Error("flatpickr: invalid locale " + e.config.locale)), e.l10n = Q(Q({}, K.l10ns.default), typeof e.config.locale == "object" ? e.config.locale : e.config.locale !== "default" ? K.l10ns[e.config.locale] : void 0), Ae.D = "(" + e.l10n.weekdays.shorthand.join("|") + ")", Ae.l = "(" + e.l10n.weekdays.longhand.join("|") + ")", Ae.M = "(" + e.l10n.months.shorthand.join("|") + ")", Ae.F = "(" + e.l10n.months.longhand.join("|") + ")", Ae.K = "(" + e.l10n.amPM[0] + "|" + e.l10n.amPM[1] + "|" + e.l10n.amPM[0].toLowerCase() + "|" + e.l10n.amPM[1].toLowerCase() + ")";
    var s = Q(Q({}, t), JSON.parse(JSON.stringify(n.dataset || {})));
    s.time_24hr === void 0 && K.defaultConfig.time_24hr === void 0 && (e.config.time_24hr = e.l10n.time_24hr), e.formatDate = fa(e), e.parseDate = Nt({ config: e.config, l10n: e.l10n });
  }
  function Je(s) {
    if (typeof e.config.position == "function")
      return void e.config.position(e, s);
    if (e.calendarContainer !== void 0) {
      W("onPreCalendarPosition");
      var l = s || e._positionElement, d = Array.prototype.reduce.call(e.calendarContainer.children, function(Pa, Na) {
        return Pa + Na.offsetHeight;
      }, 0), h = e.calendarContainer.offsetWidth, $ = e.config.position.split(" "), y = $[0], q = $.length > 1 ? $[1] : null, M = l.getBoundingClientRect(), L = window.innerHeight - M.bottom, x = y === "above" || y !== "below" && L < d && M.top > d, I = window.pageYOffset + M.top + (x ? -d - 2 : l.offsetHeight + 2);
      if (te(e.calendarContainer, "arrowTop", !x), te(e.calendarContainer, "arrowBottom", x), !e.config.inline) {
        var G = window.pageXOffset + M.left, he = !1, oe = !1;
        q === "center" ? (G -= (h - M.width) / 2, he = !0) : q === "right" && (G -= h - M.width, oe = !0), te(e.calendarContainer, "arrowLeft", !he && !oe), te(e.calendarContainer, "arrowCenter", he), te(e.calendarContainer, "arrowRight", oe);
        var Re = window.document.body.offsetWidth - (window.pageXOffset + M.right), Ie = G + h > window.document.body.offsetWidth, Ma = Re + h > window.document.body.offsetWidth;
        if (te(e.calendarContainer, "rightMost", Ie), !e.config.static)
          if (e.calendarContainer.style.top = I + "px", !Ie)
            e.calendarContainer.style.left = G + "px", e.calendarContainer.style.right = "auto";
          else if (!Ma)
            e.calendarContainer.style.left = "auto", e.calendarContainer.style.right = Re + "px";
          else {
            var Ct = wa();
            if (Ct === void 0)
              return;
            var Ta = window.document.body.offsetWidth, Ba = Math.max(0, Ta / 2 - h / 2), Ia = ".flatpickr-calendar.centerMost:before", qa = ".flatpickr-calendar.centerMost:after", Oa = Ct.cssRules.length, La = "{left:" + M.left + "px;right:auto;}";
            te(e.calendarContainer, "rightMost", !1), te(e.calendarContainer, "centerMost", !0), Ct.insertRule(Ia + "," + qa + La, Oa), e.calendarContainer.style.left = Ba + "px", e.calendarContainer.style.right = "auto";
          }
      }
    }
  }
  function wa() {
    for (var s = null, l = 0; l < document.styleSheets.length; l++) {
      var d = document.styleSheets[l];
      if (d.cssRules) {
        try {
          d.cssRules;
        } catch {
          continue;
        }
        s = d;
        break;
      }
    }
    return s ?? ba();
  }
  function ba() {
    var s = document.createElement("style");
    return document.head.appendChild(s), s.sheet;
  }
  function en() {
    e.config.noCalendar || e.isMobile || (ie(), et(), R());
  }
  function vt() {
    e._input.focus(), window.navigator.userAgent.indexOf("MSIE") !== -1 || navigator.msMaxTouchPoints !== void 0 ? setTimeout(e.close, 0) : e.close();
  }
  function tn(s) {
    s.preventDefault(), s.stopPropagation();
    var l = function(I) {
      return I.classList && I.classList.contains("flatpickr-day") && !I.classList.contains("flatpickr-disabled") && !I.classList.contains("notAllowed");
    }, d = da(se(s), l);
    if (d !== void 0) {
      var h = d, $ = e.latestSelectedDateObj = new Date(h.dateObj.getTime()), y = ($.getMonth() < e.currentMonth || $.getMonth() > e.currentMonth + e.config.showMonths - 1) && e.config.mode !== "range";
      if (e.selectedDateElem = h, e.config.mode === "single")
        e.selectedDates = [$];
      else if (e.config.mode === "multiple") {
        var q = bt($);
        q ? e.selectedDates.splice(parseInt(q), 1) : e.selectedDates.push($);
      } else e.config.mode === "range" && (e.selectedDates.length === 2 && e.clear(!1, !1), e.latestSelectedDateObj = $, e.selectedDates.push($), le($, e.selectedDates[0], !0) !== 0 && e.selectedDates.sort(function(I, G) {
        return I.getTime() - G.getTime();
      }));
      if (C(), y) {
        var M = e.currentYear !== $.getFullYear();
        e.currentYear = $.getFullYear(), e.currentMonth = $.getMonth(), M && (W("onYearChange"), ie()), W("onMonthChange");
      }
      if (et(), R(), ve(), !y && e.config.mode !== "range" && e.config.showMonths === 1 ? v(h) : e.selectedDateElem !== void 0 && e.hourElement === void 0 && e.selectedDateElem && e.selectedDateElem.focus(), e.hourElement !== void 0 && e.hourElement !== void 0 && e.hourElement.focus(), e.config.closeOnSelect) {
        var L = e.config.mode === "single" && !e.config.enableTime, x = e.config.mode === "range" && e.selectedDates.length === 2 && !e.config.enableTime;
        (L || x) && vt();
      }
      B();
    }
  }
  var Qe = {
    locale: [Qt, ee],
    showMonths: [Fe, u, Z],
    minDate: [g],
    maxDate: [g],
    positionElement: [rn],
    clickOpens: [
      function() {
        e.config.clickOpens === !0 ? (k(e._input, "focus", e.open), k(e._input, "click", e.open)) : (e._input.removeEventListener("focus", e.open), e._input.removeEventListener("click", e.open));
      }
    ]
  };
  function Fa(s, l) {
    if (s !== null && typeof s == "object") {
      Object.assign(e.config, s);
      for (var d in s)
        Qe[d] !== void 0 && Qe[d].forEach(function(h) {
          return h();
        });
    } else
      e.config[s] = l, Qe[s] !== void 0 ? Qe[s].forEach(function(h) {
        return h();
      }) : xt.indexOf(s) > -1 && (e.config[s] = Mt(l));
    e.redraw(), ve(!0);
  }
  function nn(s, l) {
    var d = [];
    if (s instanceof Array)
      d = s.map(function(h) {
        return e.parseDate(h, l);
      });
    else if (s instanceof Date || typeof s == "number")
      d = [e.parseDate(s, l)];
    else if (typeof s == "string")
      switch (e.config.mode) {
        case "single":
        case "time":
          d = [e.parseDate(s, l)];
          break;
        case "multiple":
          d = s.split(e.config.conjunction).map(function(h) {
            return e.parseDate(h, l);
          });
          break;
        case "range":
          d = s.split(e.l10n.rangeSeparator).map(function(h) {
            return e.parseDate(h, l);
          });
          break;
      }
    else
      e.config.errorHandler(new Error("Invalid date supplied: " + JSON.stringify(s)));
    e.selectedDates = e.config.allowInvalidPreload ? d : d.filter(function(h) {
      return h instanceof Date && de(h, !1);
    }), e.config.mode === "range" && e.selectedDates.sort(function(h, $) {
      return h.getTime() - $.getTime();
    });
  }
  function Ca(s, l, d) {
    if (l === void 0 && (l = !1), d === void 0 && (d = e.config.dateFormat), s !== 0 && !s || s instanceof Array && s.length === 0)
      return e.clear(l);
    nn(s, d), e.latestSelectedDateObj = e.selectedDates[e.selectedDates.length - 1], e.redraw(), g(void 0, l), f(), e.selectedDates.length === 0 && e.clear(!1), ve(l), l && W("onChange");
  }
  function an(s) {
    return s.slice().map(function(l) {
      return typeof l == "string" || typeof l == "number" || l instanceof Date ? e.parseDate(l, void 0, !0) : l && typeof l == "object" && l.from && l.to ? {
        from: e.parseDate(l.from, void 0),
        to: e.parseDate(l.to, void 0)
      } : l;
    }).filter(function(l) {
      return l;
    });
  }
  function $a() {
    e.selectedDates = [], e.now = e.parseDate(e.config.now) || /* @__PURE__ */ new Date();
    var s = e.config.defaultDate || ((e.input.nodeName === "INPUT" || e.input.nodeName === "TEXTAREA") && e.input.placeholder && e.input.value === e.input.placeholder ? null : e.input.value);
    s && nn(s, e.config.dateFormat), e._initialDate = e.selectedDates.length > 0 ? e.selectedDates[0] : e.config.minDate && e.config.minDate.getTime() > e.now.getTime() ? e.config.minDate : e.config.maxDate && e.config.maxDate.getTime() < e.now.getTime() ? e.config.maxDate : e.now, e.currentYear = e._initialDate.getFullYear(), e.currentMonth = e._initialDate.getMonth(), e.selectedDates.length > 0 && (e.latestSelectedDateObj = e.selectedDates[0]), e.config.minTime !== void 0 && (e.config.minTime = e.parseDate(e.config.minTime, "H:i")), e.config.maxTime !== void 0 && (e.config.maxTime = e.parseDate(e.config.maxTime, "H:i")), e.minDateHasTime = !!e.config.minDate && (e.config.minDate.getHours() > 0 || e.config.minDate.getMinutes() > 0 || e.config.minDate.getSeconds() > 0), e.maxDateHasTime = !!e.config.maxDate && (e.config.maxDate.getHours() > 0 || e.config.maxDate.getMinutes() > 0 || e.config.maxDate.getSeconds() > 0);
  }
  function ka() {
    if (e.input = Jt(), !e.input) {
      e.config.errorHandler(new Error("Invalid input element specified"));
      return;
    }
    e.input._type = e.input.type, e.input.type = "text", e.input.classList.add("flatpickr-input"), e._input = e.input, e.config.altInput && (e.altInput = N(e.input.nodeName, e.config.altInputClass), e._input = e.altInput, e.altInput.placeholder = e.input.placeholder, e.altInput.disabled = e.input.disabled, e.altInput.required = e.input.required, e.altInput.tabIndex = e.input.tabIndex, e.altInput.type = "text", e.input.setAttribute("type", "hidden"), !e.config.static && e.input.parentNode && e.input.parentNode.insertBefore(e.altInput, e.input.nextSibling)), e.config.allowInput || e._input.setAttribute("readonly", "readonly"), rn();
  }
  function rn() {
    e._positionElement = e.config.positionElement || e._input;
  }
  function Ea() {
    var s = e.config.enableTime ? e.config.noCalendar ? "time" : "datetime-local" : "date";
    e.mobileInput = N("input", e.input.className + " flatpickr-mobile"), e.mobileInput.tabIndex = 1, e.mobileInput.type = s, e.mobileInput.disabled = e.input.disabled, e.mobileInput.required = e.input.required, e.mobileInput.placeholder = e.input.placeholder, e.mobileFormatStr = s === "datetime-local" ? "Y-m-d\\TH:i:S" : s === "date" ? "Y-m-d" : "H:i:S", e.selectedDates.length > 0 && (e.mobileInput.defaultValue = e.mobileInput.value = e.formatDate(e.selectedDates[0], e.mobileFormatStr)), e.config.minDate && (e.mobileInput.min = e.formatDate(e.config.minDate, "Y-m-d")), e.config.maxDate && (e.mobileInput.max = e.formatDate(e.config.maxDate, "Y-m-d")), e.input.getAttribute("step") && (e.mobileInput.step = String(e.input.getAttribute("step"))), e.input.type = "hidden", e.altInput !== void 0 && (e.altInput.type = "hidden");
    try {
      e.input.parentNode && e.input.parentNode.insertBefore(e.mobileInput, e.input.nextSibling);
    } catch {
    }
    k(e.mobileInput, "change", function(l) {
      e.setDate(se(l).value, !1, e.mobileFormatStr), W("onChange"), W("onClose");
    });
  }
  function ya(s) {
    if (e.isOpen === !0)
      return e.close();
    e.open(s);
  }
  function W(s, l) {
    if (e.config !== void 0) {
      var d = e.config[s];
      if (d !== void 0 && d.length > 0)
        for (var h = 0; d[h] && h < d.length; h++)
          d[h](e.selectedDates, e.input.value, e, l);
      s === "onChange" && (e.input.dispatchEvent(wt("change")), e.input.dispatchEvent(wt("input")));
    }
  }
  function wt(s) {
    var l = document.createEvent("Event");
    return l.initEvent(s, !0, !0), l;
  }
  function bt(s) {
    for (var l = 0; l < e.selectedDates.length; l++) {
      var d = e.selectedDates[l];
      if (d instanceof Date && le(d, s) === 0)
        return "" + l;
    }
    return !1;
  }
  function Aa(s) {
    return e.config.mode !== "range" || e.selectedDates.length < 2 ? !1 : le(s, e.selectedDates[0]) >= 0 && le(s, e.selectedDates[1]) <= 0;
  }
  function et() {
    e.config.noCalendar || e.isMobile || !e.monthNav || (e.yearElements.forEach(function(s, l) {
      var d = new Date(e.currentYear, e.currentMonth, 1);
      d.setMonth(e.currentMonth + l), e.config.showMonths > 1 || e.config.monthSelectorType === "static" ? e.monthElements[l].textContent = _t(d.getMonth(), e.config.shorthandCurrentMonth, e.l10n) + " " : e.monthsDropdownContainer.value = d.getMonth().toString(), s.value = d.getFullYear().toString();
    }), e._hidePrevMonthArrow = e.config.minDate !== void 0 && (e.currentYear === e.config.minDate.getFullYear() ? e.currentMonth <= e.config.minDate.getMonth() : e.currentYear < e.config.minDate.getFullYear()), e._hideNextMonthArrow = e.config.maxDate !== void 0 && (e.currentYear === e.config.maxDate.getFullYear() ? e.currentMonth + 1 > e.config.maxDate.getMonth() : e.currentYear > e.config.maxDate.getFullYear()));
  }
  function Ft(s) {
    var l = s || (e.config.altInput ? e.config.altFormat : e.config.dateFormat);
    return e.selectedDates.map(function(d) {
      return e.formatDate(d, l);
    }).filter(function(d, h, $) {
      return e.config.mode !== "range" || e.config.enableTime || $.indexOf(d) === h;
    }).join(e.config.mode !== "range" ? e.config.conjunction : e.l10n.rangeSeparator);
  }
  function ve(s) {
    s === void 0 && (s = !0), e.mobileInput !== void 0 && e.mobileFormatStr && (e.mobileInput.value = e.latestSelectedDateObj !== void 0 ? e.formatDate(e.latestSelectedDateObj, e.mobileFormatStr) : ""), e.input.value = Ft(e.config.dateFormat), e.altInput !== void 0 && (e.altInput.value = Ft(e.config.altFormat)), s !== !1 && W("onValueUpdate");
  }
  function Sa(s) {
    var l = se(s), d = e.prevMonthNav.contains(l), h = e.nextMonthNav.contains(l);
    d || h ? A(d ? -1 : 1) : e.yearElements.indexOf(l) >= 0 ? l.select() : l.classList.contains("arrowUp") ? e.changeYear(e.currentYear + 1) : l.classList.contains("arrowDown") && e.changeYear(e.currentYear - 1);
  }
  function xa(s) {
    s.preventDefault();
    var l = s.type === "keydown", d = se(s), h = d;
    e.amPM !== void 0 && d === e.amPM && (e.amPM.textContent = e.l10n.amPM[ce(e.amPM.textContent === e.l10n.amPM[0])]);
    var $ = parseFloat(h.getAttribute("min")), y = parseFloat(h.getAttribute("max")), q = parseFloat(h.getAttribute("step")), M = parseInt(h.value, 10), L = s.delta || (l ? s.which === 38 ? 1 : -1 : 0), x = M + q * L;
    if (typeof h.value < "u" && h.value.length === 2) {
      var I = h === e.hourElement, G = h === e.minuteElement;
      x < $ ? (x = y + x + ce(!I) + (ce(I) && ce(!e.amPM)), G && F(void 0, -1, e.hourElement)) : x > y && (x = h === e.hourElement ? x - y - ce(!e.amPM) : $, G && F(void 0, 1, e.hourElement)), e.amPM && I && (q === 1 ? x + M === 23 : Math.abs(x - M) > q) && (e.amPM.textContent = e.l10n.amPM[ce(e.amPM.textContent === e.l10n.amPM[0])]), h.value = ae(x);
    }
  }
  return i(), e;
}
function Le(n, t) {
  for (var e = Array.prototype.slice.call(n).filter(function(o) {
    return o instanceof HTMLElement;
  }), a = [], i = 0; i < e.length; i++) {
    var r = e[i];
    try {
      if (r.getAttribute("data-fp-omit") !== null)
        continue;
      r._flatpickr !== void 0 && (r._flatpickr.destroy(), r._flatpickr = void 0), r._flatpickr = Mo(r, t || {}), a.push(r._flatpickr);
    } catch (o) {
      console.error(o);
    }
  }
  return a.length === 1 ? a[0] : a;
}
typeof HTMLElement < "u" && typeof HTMLCollection < "u" && typeof NodeList < "u" && (HTMLCollection.prototype.flatpickr = NodeList.prototype.flatpickr = function(n) {
  return Le(this, n);
}, HTMLElement.prototype.flatpickr = function(n) {
  return Le([this], n);
});
var K = function(n, t) {
  return typeof n == "string" ? Le(window.document.querySelectorAll(n), t) : n instanceof Node ? Le([n], t) : Le(n, t);
};
K.defaultConfig = {};
K.l10ns = {
  en: Q({}, Ke),
  default: Q({}, Ke)
};
K.localize = function(n) {
  K.l10ns.default = Q(Q({}, K.l10ns.default), n);
};
K.setDefaults = function(n) {
  K.defaultConfig = Q(Q({}, K.defaultConfig), n);
};
K.parseDate = Nt({});
K.formatDate = fa({});
K.compareDates = le;
typeof jQuery < "u" && typeof jQuery.fn < "u" && (jQuery.fn.flatpickr = function(n) {
  return Le(this, n);
});
Date.prototype.fp_incr = function(n) {
  return new Date(this.getFullYear(), this.getMonth(), this.getDate() + (typeof n == "string" ? parseInt(n, 10) : n));
};
typeof window < "u" && (window.flatpickr = K);
const {
  SvelteComponent: To,
  append: ut,
  attr: je,
  binding_callbacks: Bo,
  create_component: pa,
  destroy_component: ga,
  detach: Kt,
  element: pt,
  init: Io,
  insert: Vt,
  listen: Rt,
  mount_component: ha,
  noop: qo,
  run_all: Oo,
  safe_not_equal: Lo,
  set_data: Po,
  set_input_value: Mn,
  space: Tn,
  text: No,
  toggle_class: Bn,
  transition_in: ma,
  transition_out: _a
} = window.__gradio__svelte__internal, { onMount: Ro } = window.__gradio__svelte__internal;
function Ho(n) {
  let t;
  return {
    c() {
      t = No(
        /*label*/
        n[2]
      );
    },
    m(e, a) {
      Vt(e, t, a);
    },
    p(e, a) {
      a & /*label*/
      4 && Po(
        t,
        /*label*/
        e[2]
      );
    },
    d(e) {
      e && Kt(t);
    }
  };
}
function In(n) {
  let t, e, a;
  return {
    c() {
      t = pt("button"), t.textContent = "×", je(t, "class", "clear-button svelte-1094lmz");
    },
    m(i, r) {
      Vt(i, t, r), e || (a = Rt(
        t,
        "click",
        /*clear_value*/
        n[14]
      ), e = !0);
    },
    p: qo,
    d(i) {
      i && Kt(t), e = !1, a();
    }
  };
}
function zo(n) {
  let t, e, a, i, r, o, u, c, b, _;
  e = new $o({
    props: {
      show_label: (
        /*show_label*/
        n[9]
      ),
      info: (
        /*info*/
        n[7]
      ),
      $$slots: { default: [Ho] },
      $$scope: { ctx: n }
    }
  });
  let C = (
    /*interactive*/
    n[11] && !/*value_is_output*/
    n[1] && In(n)
  );
  return {
    c() {
      t = pt("label"), pa(e.$$.fragment), a = Tn(), i = pt("div"), r = pt("input"), u = Tn(), C && C.c(), je(r, "type", "text"), r.disabled = o = !/*interactive*/
      n[11], je(r, "class", "svelte-1094lmz"), je(i, "class", "input-with-clear svelte-1094lmz"), je(t, "class", "svelte-1094lmz"), Bn(
        t,
        "container",
        /*container*/
        n[10]
      );
    },
    m(f, w) {
      Vt(f, t, w), ha(e, t, null), ut(t, a), ut(t, i), ut(i, r), n[18](r), Mn(
        r,
        /*value*/
        n[0]
      ), ut(i, u), C && C.m(i, null), c = !0, b || (_ = [
        Rt(
          r,
          "input",
          /*input_input_handler*/
          n[19]
        ),
        Rt(
          r,
          "change",
          /*handle_change*/
          n[13]
        )
      ], b = !0);
    },
    p(f, w) {
      const O = {};
      w & /*show_label*/
      512 && (O.show_label = /*show_label*/
      f[9]), w & /*info*/
      128 && (O.info = /*info*/
      f[7]), w & /*$$scope, label*/
      1048580 && (O.$$scope = { dirty: w, ctx: f }), e.$set(O), (!c || w & /*interactive*/
      2048 && o !== (o = !/*interactive*/
      f[11])) && (r.disabled = o), w & /*value*/
      1 && r.value !== /*value*/
      f[0] && Mn(
        r,
        /*value*/
        f[0]
      ), /*interactive*/
      f[11] && !/*value_is_output*/
      f[1] ? C ? C.p(f, w) : (C = In(f), C.c(), C.m(i, null)) : C && (C.d(1), C = null), (!c || w & /*container*/
      1024) && Bn(
        t,
        "container",
        /*container*/
        f[10]
      );
    },
    i(f) {
      c || (ma(e.$$.fragment, f), c = !0);
    },
    o(f) {
      _a(e.$$.fragment, f), c = !1;
    },
    d(f) {
      f && Kt(t), ga(e), n[18](null), C && C.d(), b = !1, Oo(_);
    }
  };
}
function jo(n) {
  let t, e;
  return t = new ri({
    props: {
      visible: (
        /*visible*/
        n[3]
      ),
      elem_id: (
        /*elem_id*/
        n[5]
      ),
      elem_classes: (
        /*elem_classes*/
        n[4]
      ),
      scale: (
        /*scale*/
        n[6]
      ),
      min_width: (
        /*min_width*/
        n[8]
      ),
      allow_overflow: !1,
      padding: !0,
      $$slots: { default: [zo] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      pa(t.$$.fragment);
    },
    m(a, i) {
      ha(t, a, i), e = !0;
    },
    p(a, [i]) {
      const r = {};
      i & /*visible*/
      8 && (r.visible = /*visible*/
      a[3]), i & /*elem_id*/
      32 && (r.elem_id = /*elem_id*/
      a[5]), i & /*elem_classes*/
      16 && (r.elem_classes = /*elem_classes*/
      a[4]), i & /*scale*/
      64 && (r.scale = /*scale*/
      a[6]), i & /*min_width*/
      256 && (r.min_width = /*min_width*/
      a[8]), i & /*$$scope, container, interactive, value_is_output, el, value, show_label, info, label*/
      1056391 && (r.$$scope = { dirty: i, ctx: a }), t.$set(r);
    },
    i(a) {
      e || (ma(t.$$.fragment, a), e = !0);
    },
    o(a) {
      _a(t.$$.fragment, a), e = !1;
    },
    d(a) {
      ga(t, a);
    }
  };
}
function Yo(n, t, e) {
  let { value: a = null } = t, { value_is_output: i = !1 } = t, { label: r } = t, { visible: o = !0 } = t, { elem_classes: u } = t, { elem_id: c } = t, { scale: b } = t, { info: _ } = t, { min_width: C } = t, { show_label: f = !0 } = t, { container: w = !0 } = t, { interactive: O = !0 } = t, { gradio: k } = t, { mode: B = "single" } = t, { date_format: P = "%Y-%m-%d" } = t, g;
  function p() {
    k.dispatch("change"), i || k.dispatch("input");
  }
  function F() {
    e(0, a = null), p();
  }
  Ro(() => {
    const v = P.replace(/%Y/g, "Y").replace(/%m/g, "m").replace(/%d/g, "d");
    K(g, {
      mode: B === "range" ? "range" : "single",
      dateFormat: v,
      onChange: (E, T) => {
        B === "range" ? e(0, a = T.split(" to ")) : e(0, a = T), p();
      }
    });
  });
  function m(v) {
    Bo[v ? "unshift" : "push"](() => {
      g = v, e(12, g);
    });
  }
  function D() {
    a = this.value, e(0, a);
  }
  return n.$$set = (v) => {
    "value" in v && e(0, a = v.value), "value_is_output" in v && e(1, i = v.value_is_output), "label" in v && e(2, r = v.label), "visible" in v && e(3, o = v.visible), "elem_classes" in v && e(4, u = v.elem_classes), "elem_id" in v && e(5, c = v.elem_id), "scale" in v && e(6, b = v.scale), "info" in v && e(7, _ = v.info), "min_width" in v && e(8, C = v.min_width), "show_label" in v && e(9, f = v.show_label), "container" in v && e(10, w = v.container), "interactive" in v && e(11, O = v.interactive), "gradio" in v && e(15, k = v.gradio), "mode" in v && e(16, B = v.mode), "date_format" in v && e(17, P = v.date_format);
  }, n.$$.update = () => {
    n.$$.dirty & /*value*/
    1 && p();
  }, [
    a,
    i,
    r,
    o,
    u,
    c,
    b,
    _,
    C,
    f,
    w,
    O,
    g,
    p,
    F,
    k,
    B,
    P,
    m,
    D
  ];
}
class fb extends To {
  constructor(t) {
    super(), Io(this, t, Yo, jo, Lo, {
      value: 0,
      value_is_output: 1,
      label: 2,
      visible: 3,
      elem_classes: 4,
      elem_id: 5,
      scale: 6,
      info: 7,
      min_width: 8,
      show_label: 9,
      container: 10,
      interactive: 11,
      gradio: 15,
      mode: 16,
      date_format: 17
    });
  }
}
export {
  fb as I,
  wn as c,
  Uo as g
};
