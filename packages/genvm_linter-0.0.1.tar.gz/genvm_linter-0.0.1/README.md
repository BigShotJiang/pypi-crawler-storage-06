# genvm-linter

GenVM Linter - Implementation coming soon.

This is a placeholder package. The actual linter implementation will be published shortly.
