from enum import Enum


class PageOrientation(Enum):
    Portrait = "Portrait"
    Landscape = "Landscape"