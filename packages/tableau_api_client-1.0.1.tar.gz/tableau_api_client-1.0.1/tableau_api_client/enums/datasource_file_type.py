from enum import Enum


class DatasourceFileType(Enum):
    hyper = "hyper"
    tds = "tds"
    tdsx = "tdsx"
    tde = "tde"