from enum import Enum


class Orientation(Enum):
    Portrait = "Portrait"
    Landscape = "Landscape"