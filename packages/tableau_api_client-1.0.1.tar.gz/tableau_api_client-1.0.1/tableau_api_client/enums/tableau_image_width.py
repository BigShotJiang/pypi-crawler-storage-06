from enum import Enum


class TableauImageWidth(Enum):
    Default_784px = "Default_784px"
    High_1568 = "High_1568"