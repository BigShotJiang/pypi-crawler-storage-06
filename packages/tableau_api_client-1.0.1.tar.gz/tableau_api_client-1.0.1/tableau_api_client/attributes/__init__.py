from .api_version_attribute import ApiVersionAttribute
from .on_premise_only_attribute import OnPremiseOnlyAttribute

__all__ = ['ApiVersionAttribute', 'OnPremiseOnlyAttribute']