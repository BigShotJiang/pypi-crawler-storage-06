# choose a mode among the following
mode = 'simple' # 'polynomial' # 'chebyshev' # 'none'
# not used parameters will be ignored
order_polynom = 4
order_chebyshev = 10
# choose q-range where the baseline should be drawn (can be important for 'polynomial' & 'chebyshev')
q_min=0 
q_max=100