CLI Docs
========

Installation
------------

To check if the Dragonfly command line interface is installed correctly use ``dragonfly viz`` and you
should get a ``viiiiiiiiiiiiizzzzzzzzz!`` back in response!

































Commands
--------
.. toctree::
   :maxdepth: 1

   create
   edit
   translate
   validate
