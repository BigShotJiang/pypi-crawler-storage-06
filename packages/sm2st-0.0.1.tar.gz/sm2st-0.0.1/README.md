SM2ST package.  You can see
(https://github.com/binbin-coder/SM2ST)
to use.