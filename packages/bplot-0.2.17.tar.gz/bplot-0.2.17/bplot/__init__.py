"""
   .. include:: ../README.md
"""

#from .module import *