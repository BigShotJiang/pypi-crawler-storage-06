# SPDX-FileCopyrightText: 2025-present Keisuke Magara <61485115+kei-mag@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
