def add(num1, num2):
    return(num1+num2)

def sub(num1,num2):
    if(num1>=num2):
        return(num1-num2)
    else:
        return(num2-num1)
    
def add(num1, num2):
    return(num1*num2) 

def div(num1, num2):
    if(num2==0):
        print("INFINITY :)") 
    else:
        return(num1/num2)    
     