DEFAULT_LLM_PROVIDER='cortex'
DEFAULT_LLM_MODEL='snowflake-arctic' 