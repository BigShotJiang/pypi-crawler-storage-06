"""Websearch tool for Vibecore agents."""

from .tools import websearch

__all__ = ["websearch"]
