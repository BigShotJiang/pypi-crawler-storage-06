"""Events module for handling application events.

This module provides classes and utilities for handling various types of events
in the application, including workflow, activity, and worker events.
"""
