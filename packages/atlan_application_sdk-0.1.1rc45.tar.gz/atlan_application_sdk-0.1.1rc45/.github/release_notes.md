## v0.1.1rc45 (September 18, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc44...v0.1.1rc45

### Features

- add MCP (Model Context Protocol) integration to application-sdk (#698) (by @AdvitXAtlan in [a5d496e](https://github.com/atlanhq/application-sdk/commit/a5d496e))
- fix credentials and extra field information in docs (#724) (by @Nishchith Shetty in [a0808db](https://github.com/atlanhq/application-sdk/commit/a0808db))
- add minimal API docs for endpoints exposed (#721) (by @Nishchith Shetty in [3301b61](https://github.com/atlanhq/application-sdk/commit/3301b61))
