
## CATO-CLI - mutation.site:
[Click here](https://api.catonetworks.com/documentation/#mutation-site) for documentation on this operation.

### Usage for mutation.site:

`catocli mutation site -h`
