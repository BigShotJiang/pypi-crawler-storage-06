"""Make the CLI runnable using python -m exoyone."""

from .cli import app  # pragma: no cover

app(prog_name="exoyone")  # pragma: no cover
