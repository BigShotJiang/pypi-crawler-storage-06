class ParserError(Exception):
    """
    Base parser exception class.
    Throws when any error occurs.
    """
    pass
