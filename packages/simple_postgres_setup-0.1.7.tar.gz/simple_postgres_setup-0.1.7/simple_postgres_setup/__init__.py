import simple_postgres_setup.code
from .main import setup_database
from .main import drop_database
