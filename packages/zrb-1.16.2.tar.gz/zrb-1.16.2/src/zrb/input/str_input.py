from zrb.input.base_input import BaseInput


class StrInput(BaseInput):
    pass
