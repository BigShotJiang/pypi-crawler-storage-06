1.  Go to **Inventory** dashboard and open any picking.
2.  If picking state is **available** you can see an split button.
3.  On the "Operations" tab, fill the field "Done" to the quantity you
    want to split for each line.
4.  If you click on **Split** button, wizard will split current picking
    into two different pickings depends on quantity done you entered
    above.
5.  Both pickings remain confirmed.
6.  When splitting a picking in an unassigned state, wizard won't be
    auto completed with picking lines.
