This module adds a "Split" button on the pickings form.

It works like the classical picking Transfer but it leaves both pickings
(picking and its backorder) as confirmed without processing the
transfer.

You can also choose to put all moves into separate pickings, or select
moves to be put into a new picking.
