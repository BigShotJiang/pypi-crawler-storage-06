## Test Session: 2025-08-30 19:13:17 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 1
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-08-30 19:21:06 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| github (SSE) | http://47.76.139.105:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://47.76.139.105:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-30 19:45:27 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 27
- **Passed:** 18 (66.7%)
- **Partial:** 8 (29.6%)
- **Failed:** 1 (3.7%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://47.76.139.105:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://47.76.139.105:13001/perplexity-as... | ✅ | 1 (0%) | ⚠️ PARTIAL | N/A |
| exa-search (SSE) | http://47.76.139.105:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://47.76.139.105:13001/exa-search/mc... | ✅ | 6 (67%) | ✅ PASSED | N/A |
| github (SSE) | http://47.76.139.105:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://47.76.139.105:18001/github/mcp | ✅ | 28 (0%) | ⚠️ PARTIAL | API Key Missing |
| fetch (SSE) | http://47.76.139.105:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://47.76.139.105:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://47.76.139.105:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://47.76.139.105:13001/filesystem/mc... | ✅ | 12 (0%) | ⚠️ PARTIAL | N/A |
| sequentialthinking (SSE) | http://47.76.139.105:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://47.76.139.105:13001/sequentialthi... | ✅ | 1 (0%) | ⚠️ PARTIAL | N/A |
| time (SSE) | http://47.76.139.105:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://47.76.139.105:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://47.76.139.105:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://47.76.139.105:18001/minimax/mcp | ✅ | 9 (33%) | ⚠️ PARTIAL | N/A |
| variflight (SSE) | http://47.76.139.105:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://47.76.139.105:13001/variflight/mc... | ✅ | 8 (0%) | ⚠️ PARTIAL | N/A |
| 12306 (SSE) | http://47.76.139.105:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://47.76.139.105:13001/12306/mcp | ✅ | 8 (0%) | ⚠️ PARTIAL | N/A |
| amap-maps (SSE) | http://47.76.139.105:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://47.76.139.105:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://47.76.139.105:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://47.76.139.105:13001/chart/mcp | ✅ | 25 (33%) | ⚠️ PARTIAL | N/A |
| brave-search (SSE) | http://47.76.139.105:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://47.76.139.105:13001/brave-search/... | ✅ | 2 (50%) | ✅ PASSED | Quota Exceeded |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

### Failed Servers Details

#### didichuxing (Streamable HTTP)

- **URL:** https://mcp.didichuxing.com/mcp-servers?key=Kz6BZgAW2DlpjX0WzYenvNXR8OL3jYpV
- **Test Time:** 2025-08-30T19:45:26.698429
- **Connection Error:** Failed to establish connection


---

## Test Session: 2025-08-30 20:05:47 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (SSE) | http://47.76.139.105:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://47.76.139.105:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-30 20:06:51 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 2
- **Passed:** 1 (50.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (50.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (SSE) | http://47.76.139.105:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://47.76.139.105:13001/chart/mcp | ✅ | 25 (0%) | ❌ FAILED | N/A |

### Failed Servers Details

#### chart (Streamable HTTP)

- **URL:** http://47.76.139.105:13001/chart/mcp
- **Test Time:** 2025-08-30T20:06:06.195780


---

## Test Session: 2025-08-30 20:09:42 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 2
- **Passed:** 1 (50.0%)
- **Partial:** 1 (50.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (SSE) | http://47.76.139.105:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://47.76.139.105:13001/chart/mcp | ✅ | 25 (0%) | ⚠️ PARTIAL | N/A |

---

## Test Session: 2025-08-30 20:10:18 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (SSE) | http://47.76.139.105:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://47.76.139.105:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-30 20:13:08 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 2
- **Passed:** 1 (50.0%)
- **Partial:** 1 (50.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (SSE) | http://47.76.139.105:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://47.76.139.105:13001/chart/mcp | ✅ | 25 (0%) | ⚠️ PARTIAL | N/A |

---

## Test Session: 2025-08-30 20:15:10 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 2
- **Passed:** 1 (50.0%)
- **Partial:** 1 (50.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (SSE) | http://47.76.139.105:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://47.76.139.105:13001/chart/mcp | ✅ | 25 (0%) | ⚠️ PARTIAL | N/A |

---

## Test Session: 2025-08-30 20:18:43 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (SSE) | http://47.76.139.105:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://47.76.139.105:13001/chart/mcp | ✅ | 25 (67%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-30 20:48:34 [TEST MODE]

### Summary

- **Test Mode:** TEST
- **Total Servers Tested:** 2
- **Passed:** 1 (50.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (50.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| Test Server 1 | http://test1.example.com | ✅ | 10 (100%) | ✅ PASSED | N/A |
| Test Server 2 | http://test2.example.com | ❌ | ❌ | ❌ FAILED | Connection: Connection failed |

---

## Test Session: 2025-08-30 20:50:40 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 27
- **Passed:** 26 (96.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.7%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://47.76.139.105:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://47.76.139.105:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://47.76.139.105:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://47.76.139.105:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://47.76.139.105:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://47.76.139.105:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://47.76.139.105:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://47.76.139.105:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://47.76.139.105:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://47.76.139.105:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://47.76.139.105:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://47.76.139.105:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://47.76.139.105:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://47.76.139.105:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://47.76.139.105:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://47.76.139.105:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://47.76.139.105:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://47.76.139.105:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://47.76.139.105:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://47.76.139.105:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://47.76.139.105:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://47.76.139.105:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://47.76.139.105:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://47.76.139.105:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://47.76.139.105:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://47.76.139.105:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-08-31 18:10:18 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 1
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

### Failed Servers Details

#### didichuxing (Streamable HTTP)

- **URL:** https://mcp.didichuxing.com/mcp-servers?key=Kz6BZgAW2DlpjX0WzYenvNXR8OL3jYpV
- **Test Time:** 2025-08-31T18:10:18.347282
- **Connection Error:** Failed to establish connection


---

## Test Session: 2025-08-31 18:32:58 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 26 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 18:40:21 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 26 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 18:43:24 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 18:44:21 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 18:46:22 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 18:47:41 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 18:48:27 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 19:11:54 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 24 (92.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 2 (7.7%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | ❌ | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | ❌ | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 19:14:15 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 19:16:05 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 19:42:35 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 26 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 19:46:04 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 26 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:00:01 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 8
- **Passed:** 8 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:03:50 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:04:24 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:04:41 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 26 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:06:35 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:06:48 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:08:01 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:09:52 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:10:19 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:13:07 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:13:20 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:13:20 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:13:59 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:14:32 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:14:44 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:15:18 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 12 (41.4%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-08-31 20:19:00 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 22 (84.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:25:52 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 14 (48.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-08-31 20:27:16 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 16 (55.2%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-08-31 20:28:15 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 24 (82.8%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.4%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-08-31 20:29:02 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 24 (82.8%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.4%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-08-31 20:36:35 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 20 (69.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-08-31 20:37:29 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 24 (92.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-08-31 20:38:43 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 26
- **Passed:** 24 (92.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| google-maps (SSE) | http://127.0.0.1:13002/google-maps/sse | ✅ | 7 (100%) | ✅ PASSED | N/A |
| google-maps (Streamable HTTP) | http://127.0.0.1:13002/google-maps/mcp | ✅ | 7 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 12:46:00 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 27 (93.1%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 12:47:06 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 27 (93.1%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 12:48:02 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 27 (93.1%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 12:51:36 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 12:52:49 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 27 (93.1%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 12:53:37 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 27 (93.1%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 13:02:39 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 1 (50.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-09-05 13:03:15 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 13:17:24 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 29 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (SSE) | http://127.0.0.1:18002/github/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (SSE) | http://127.0.0.1:18002/git/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (SSE) | http://127.0.0.1:18002/time/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 13:17:44 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 29 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (SSE) | http://127.0.0.1:18002/github/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (SSE) | http://127.0.0.1:18002/git/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (SSE) | http://127.0.0.1:18002/time/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 13:21:02 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 29 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (SSE) | http://127.0.0.1:18002/github/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (SSE) | http://127.0.0.1:18002/git/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (SSE) | http://127.0.0.1:18002/time/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 13:22:21 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 29 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (SSE) | http://127.0.0.1:18002/github/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (SSE) | http://127.0.0.1:18002/git/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (SSE) | http://127.0.0.1:18002/time/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 13:23:15 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 29 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (SSE) | http://127.0.0.1:18002/github/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (SSE) | http://127.0.0.1:18002/git/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (SSE) | http://127.0.0.1:18002/time/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 13:24:41 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 29 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (SSE) | http://127.0.0.1:18002/github/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (SSE) | http://127.0.0.1:18002/git/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (SSE) | http://127.0.0.1:18002/time/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 13:32:21 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 2
- **Passed:** 2 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 13:32:34 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 14:03:05 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | ❌ | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | ❌ | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 14:33:35 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | ❌ | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | ❌ | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 15:04:05 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | ❌ | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | ❌ | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 15:34:35 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | ❌ | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | ❌ | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 16:13:48 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 29
- **Passed:** 22 (75.9%)
- **Partial:** 7 (24.1%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (0%) | ⚠️ PARTIAL | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (33%) | ⚠️ PARTIAL | API Key Missing |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (0%) | ⚠️ PARTIAL | API Key Missing |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (0%) | ⚠️ PARTIAL | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (0%) | ⚠️ PARTIAL | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (67%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (33%) | ⚠️ PARTIAL | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | ❌ | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | ❌ | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (0%) | ⚠️ PARTIAL | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (50%) | ✅ PASSED | Quota Exceeded |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (67%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 16:44:18 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | ❌ | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | ❌ | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 17:30:30 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 17:32:21 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 17:32:56 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 17:34:51 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:05:36 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:20:41 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 4 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| Proxy Server 1 | https://mcpstore.co/mcp/4c31848d8843221a... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| Proxy Server 2 | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| Proxy Server 3 | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| Proxy Server 4 | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 18:21:00 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:22:10 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 4 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| Proxy Server 1 | https://mcpstore.co/mcp/4c31848d8843221a... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| Proxy Server 2 | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| Proxy Server 3 | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| Proxy Server 4 | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 18:26:22 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 4 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 18:30:47 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:32:20 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:32:39 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:34:10 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:34:49 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:35:15 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:35:44 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:36:14 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:36:29 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:37:23 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:37:41 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:37:57 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 29 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ✅ | 3 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:42:44 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:45:32 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 28 (96.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.4%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 18:52:01 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:52:13 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 28 (96.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.4%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 18:53:19 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:53:26 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 28 (96.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.4%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 18:53:42 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 18:54:25 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 28 (96.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.4%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 18:54:36 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 3
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 3 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| 12306 (12306) | http://localhost:8090/mcp/fN951rmyCd6td1... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (MiniMax) | http://localhost:8090/mcp/tpC0HWyvShn3l2... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Perplexity) | http://localhost:8090/mcp/Gmd7ZsDXblvdQu... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 18:59:08 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 3
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 3 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| 12306 (12306) | http://localhost:8090/mcp/fN951rmyCd6td1... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (MiniMax) | http://localhost:8090/mcp/tpC0HWyvShn3l2... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Perplexity) | http://localhost:8090/mcp/Gmd7ZsDXblvdQu... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 19:00:26 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 28 (96.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.4%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 19:00:35 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 3
- **Passed:** 3 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| 12306 (12306) | http://localhost:8090/mcp/fN951rmyCd6td1... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| minimax (MiniMax) | http://localhost:8090/mcp/tpC0HWyvShn3l2... | ✅ | 9 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://localhost:8090/mcp/Gmd7ZsDXblvdQu... | ✅ | 1 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:02:03 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:05:04 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:05:38 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:06:00 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:06:01 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 22 (75.9%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-09-05 19:06:47 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:07:08 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 29
- **Passed:** 28 (96.6%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.4%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| didichuxing (Streamable HTTP) | https://mcp.didichuxing.com/mcp-servers?... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 19:11:05 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 4
- **Passed:** 4 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:12:59 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 15
- **Passed:** 14 (93.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (6.7%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| exa-search (Exa MCP) | http://mcpmarket.cn/mcp/L5SWtPoyojW7YWrI... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Sequential | http://mcpmarket.cn/mcp/Sdx1SESGE14CgeHu... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (Git) | http://mcpmarket.cn/mcp/0JVKXDN139AbFTPQ... | ✅ | 13 (100%) | ✅ PASSED | N/A |
| filesystem (Filesystem) | http://mcpmarket.cn/mcp/5eEt9UbQFeHd5L9m... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| fetch (Fetch ) | http://mcpmarket.cn/mcp/Dc88hMW4xQbfbv5d... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| amap-maps (amap-maps) | http://mcpmarket.cn/mcp/loFcbGcebZHcavwQ... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| didichuxing (滴滴打车) | http://mcpmarket.cn/mcp/HixhBSZQYbRiyODp... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (VariFlight飞友科技) | http://mcpmarket.cn/mcp/Fz2h16JOz495QodG... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| brave-search (Brave Search) | http://mcpmarket.cn/mcp/K5VkFdsZq5EiR3tp... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| 12306 (12306车票查询) | http://mcpmarket.cn/mcp/emXfMYUgx3OTPW60... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| minimax (MiniMax) | http://mcpmarket.cn/mcp/jLujhEounP2YR5Io... | ✅ | 9 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:13:25 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 15
- **Passed:** 14 (93.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (6.7%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| exa-search (Exa MCP) | http://mcpmarket.cn/mcp/L5SWtPoyojW7YWrI... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Sequential | http://mcpmarket.cn/mcp/Sdx1SESGE14CgeHu... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (Git) | http://mcpmarket.cn/mcp/0JVKXDN139AbFTPQ... | ✅ | 13 (100%) | ✅ PASSED | N/A |
| filesystem (Filesystem) | http://mcpmarket.cn/mcp/5eEt9UbQFeHd5L9m... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| fetch (Fetch ) | http://mcpmarket.cn/mcp/Dc88hMW4xQbfbv5d... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| amap-maps (amap-maps) | http://mcpmarket.cn/mcp/loFcbGcebZHcavwQ... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| didichuxing (滴滴打车) | http://mcpmarket.cn/mcp/HixhBSZQYbRiyODp... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (VariFlight飞友科技) | http://mcpmarket.cn/mcp/Fz2h16JOz495QodG... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| brave-search (Brave Search) | http://mcpmarket.cn/mcp/K5VkFdsZq5EiR3tp... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| 12306 (12306车票查询) | http://mcpmarket.cn/mcp/emXfMYUgx3OTPW60... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| minimax (MiniMax) | http://mcpmarket.cn/mcp/jLujhEounP2YR5Io... | ✅ | 9 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:13:54 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 15
- **Passed:** 14 (93.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (6.7%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| exa-search (Exa MCP) | http://mcpmarket.cn/mcp/L5SWtPoyojW7YWrI... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Sequential | http://mcpmarket.cn/mcp/Sdx1SESGE14CgeHu... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (Git) | http://mcpmarket.cn/mcp/0JVKXDN139AbFTPQ... | ✅ | 13 (100%) | ✅ PASSED | N/A |
| filesystem (Filesystem) | http://mcpmarket.cn/mcp/5eEt9UbQFeHd5L9m... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| fetch (Fetch ) | http://mcpmarket.cn/mcp/Dc88hMW4xQbfbv5d... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| amap-maps (amap-maps) | http://mcpmarket.cn/mcp/loFcbGcebZHcavwQ... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| didichuxing (滴滴打车) | http://mcpmarket.cn/mcp/HixhBSZQYbRiyODp... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (VariFlight飞友科技) | http://mcpmarket.cn/mcp/Fz2h16JOz495QodG... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| brave-search (Brave Search) | http://mcpmarket.cn/mcp/K5VkFdsZq5EiR3tp... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| 12306 (12306车票查询) | http://mcpmarket.cn/mcp/emXfMYUgx3OTPW60... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| minimax (MiniMax) | http://mcpmarket.cn/mcp/jLujhEounP2YR5Io... | ✅ | 9 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:14:25 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 15
- **Passed:** 14 (93.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (6.7%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| exa-search (Exa MCP) | http://mcpmarket.cn/mcp/L5SWtPoyojW7YWrI... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Sequential | http://mcpmarket.cn/mcp/Sdx1SESGE14CgeHu... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (Git) | http://mcpmarket.cn/mcp/0JVKXDN139AbFTPQ... | ✅ | 13 (100%) | ✅ PASSED | N/A |
| filesystem (Filesystem) | http://mcpmarket.cn/mcp/5eEt9UbQFeHd5L9m... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| fetch (Fetch ) | http://mcpmarket.cn/mcp/Dc88hMW4xQbfbv5d... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| amap-maps (amap-maps) | http://mcpmarket.cn/mcp/loFcbGcebZHcavwQ... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| didichuxing (滴滴打车) | http://mcpmarket.cn/mcp/HixhBSZQYbRiyODp... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (VariFlight飞友科技) | http://mcpmarket.cn/mcp/Fz2h16JOz495QodG... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| brave-search (Brave Search) | http://mcpmarket.cn/mcp/K5VkFdsZq5EiR3tp... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| 12306 (12306车票查询) | http://mcpmarket.cn/mcp/emXfMYUgx3OTPW60... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| minimax (MiniMax) | http://mcpmarket.cn/mcp/jLujhEounP2YR5Io... | ✅ | 9 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:14:46 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 15
- **Passed:** 14 (93.3%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (6.7%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| time (Time) | https://mcpstore.co/mcp/4c31848d8843221a... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| exa-search (Exa MCP) | http://mcpmarket.cn/mcp/L5SWtPoyojW7YWrI... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Sequential | http://mcpmarket.cn/mcp/Sdx1SESGE14CgeHu... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| git (Git) | http://mcpmarket.cn/mcp/0JVKXDN139AbFTPQ... | ✅ | 13 (100%) | ✅ PASSED | N/A |
| filesystem (Filesystem) | http://mcpmarket.cn/mcp/5eEt9UbQFeHd5L9m... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| fetch (Fetch ) | http://mcpmarket.cn/mcp/Dc88hMW4xQbfbv5d... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| amap-maps (amap-maps) | http://mcpmarket.cn/mcp/loFcbGcebZHcavwQ... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| didichuxing (滴滴打车) | http://mcpmarket.cn/mcp/HixhBSZQYbRiyODp... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| variflight (VariFlight飞友科技) | http://mcpmarket.cn/mcp/Fz2h16JOz495QodG... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| brave-search (Brave Search) | http://mcpmarket.cn/mcp/K5VkFdsZq5EiR3tp... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| 12306 (12306车票查询) | http://mcpmarket.cn/mcp/emXfMYUgx3OTPW60... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| minimax (MiniMax) | http://mcpmarket.cn/mcp/jLujhEounP2YR5Io... | ✅ | 9 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | http://mcpmarket.cn/mcp/lGLUnnKhhVI2TkRn... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | http://mcpmarket.cn/mcp/XvonagL3KBYDd48n... | ✅ | 25 (100%) | ✅ PASSED | N/A |
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:15:07 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 1
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| didichuxing (滴滴打车) | http://mcpmarket.cn/mcp/HixhBSZQYbRiyODp... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 19:15:34 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 1
- **Passed:** 1 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| github (Github) | http://mcpmarket.cn/mcp/pgXHgqYVBNX760aU... | ✅ | 28 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 19:15:59 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 1
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| didichuxing (滴滴打车) | http://mcpmarket.cn/mcp/HixhBSZQYbRiyODp... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 19:36:09 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 20:06:18 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 20:23:28 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 20:24:45 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://127.0.0.1:13002/perplexity-ask/ss... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://127.0.0.1:13002/perplexity-ask/mc... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://127.0.0.1:13002/exa-search/sse | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://127.0.0.1:13002/exa-search/mcp | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://127.0.0.1:18002/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://127.0.0.1:18002/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://127.0.0.1:18002/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://127.0.0.1:18002/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://127.0.0.1:13002/filesystem/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://127.0.0.1:13002/filesystem/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://127.0.0.1:18002/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://127.0.0.1:18002/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://127.0.0.1:13002/sequentialthinkin... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://127.0.0.1:18002/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://127.0.0.1:18002/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://127.0.0.1:18002/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://127.0.0.1:18002/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://127.0.0.1:13002/variflight/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://127.0.0.1:13002/variflight/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://127.0.0.1:13002/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://127.0.0.1:13002/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://127.0.0.1:13002/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://127.0.0.1:13002/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://127.0.0.1:13002/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://127.0.0.1:13002/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://127.0.0.1:13002/brave-search/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://127.0.0.1:13002/brave-search/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 20:25:35 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 5
- **Passed:** 0 (0.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 5 (100.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| brave-search (Brave Search) | http://localhost:8090/mcp/shnSmwozhEPzkT... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| didichuxing (滴滴打车) | http://localhost:8090/mcp/FeXJG7B30aqvb4... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| 12306 (12306) | http://localhost:8090/mcp/fN951rmyCd6td1... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| minimax (MiniMax) | http://localhost:8090/mcp/tpC0HWyvShn3l2... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| perplexity-ask (Perplexity) | http://localhost:8090/mcp/Gmd7ZsDXblvdQu... | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |

---

## Test Session: 2025-09-05 20:37:19 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 5 (17.9%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| git (SSE) | http://8.217.130.241:18001/git/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| time (SSE) | http://8.217.130.241:18001/time/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-09-05 23:16:19 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-05 23:46:27 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 00:17:07 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 01:20:17 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 01:50:24 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 02:20:31 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 02:50:38 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 03:20:45 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 03:50:55 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 04:21:01 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 04:51:09 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 05:21:20 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 05:51:27 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 06:21:35 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 06:51:44 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 07:22:01 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 27 (96.4%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 07:52:10 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 10:18:56 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 10:49:18 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 11:19:34 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 5 (17.9%)
- **Partial:** 0 (0.0%)
- **Failed:** 1 (3.6%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ❌ | ❌ | ❌ FAILED | Connection: Failed to establish connection |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| git (SSE) | http://8.217.130.241:18001/git/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| time (SSE) | http://8.217.130.241:18001/time/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-09-06 11:50:04 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 28 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| github (SSE) | http://8.217.130.241:18001/github/sse | ✅ | 28 (100%) | ✅ PASSED | N/A |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ✅ | 28 (100%) | ✅ PASSED | N/A |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ✅ | 1 (100%) | ✅ PASSED | N/A |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ✅ | 1 (100%) | ✅ PASSED | N/A |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ✅ | 12 (100%) | ✅ PASSED | N/A |
| git (SSE) | http://8.217.130.241:18001/git/sse | ✅ | 13 (100%) | ✅ PASSED | N/A |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ✅ | 13 (100%) | ✅ PASSED | N/A |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| time (SSE) | http://8.217.130.241:18001/time/sse | ✅ | 2 (100%) | ✅ PASSED | N/A |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ✅ | 2 (100%) | ✅ PASSED | N/A |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ✅ | 9 (100%) | ✅ PASSED | N/A |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ✅ | 9 (100%) | ✅ PASSED | N/A |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ✅ | 8 (100%) | ✅ PASSED | N/A |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ✅ | 8 (100%) | ✅ PASSED | N/A |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ✅ | 12 (100%) | ✅ PASSED | N/A |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ✅ | 12 (100%) | ✅ PASSED | N/A |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ✅ | 25 (100%) | ✅ PASSED | N/A |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ✅ | 25 (100%) | ✅ PASSED | N/A |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-06 12:20:23 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 28
- **Passed:** 3 (10.7%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| perplexity-ask (SSE) | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Streamable HTT | http://8.217.130.241:13001/perplexity-as... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| exa-search (SSE) | http://8.217.130.241:13001/exa-search/ss... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| exa-search (Streamable HTTP) | http://8.217.130.241:13001/exa-search/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| github (SSE) | http://8.217.130.241:18001/github/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| github (Streamable HTTP) | http://8.217.130.241:18001/github/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| fetch (SSE) | http://8.217.130.241:18001/fetch/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| fetch (Streamable HTTP) | http://8.217.130.241:18001/fetch/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (SSE) | http://8.217.130.241:13001/filesystem/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| filesystem (Streamable HTTP) | http://8.217.130.241:13001/filesystem/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| git (SSE) | http://8.217.130.241:18001/git/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| git (Streamable HTTP) | http://8.217.130.241:18001/git/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (SSE) | http://8.217.130.241:13001/sequentialthi... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| sequentialthinking (Streamable | http://8.217.130.241:13001/sequentialthi... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| time (SSE) | http://8.217.130.241:18001/time/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| time (Streamable HTTP) | http://8.217.130.241:18001/time/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| minimax (SSE) | http://8.217.130.241:18001/minimax/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| minimax (Streamable HTTP) | http://8.217.130.241:18001/minimax/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (SSE) | http://8.217.130.241:13001/variflight/ss... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| variflight (Streamable HTTP) | http://8.217.130.241:13001/variflight/mc... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (SSE) | http://8.217.130.241:13001/12306/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| 12306 (Streamable HTTP) | http://8.217.130.241:13001/12306/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (SSE) | http://8.217.130.241:13001/amap-maps/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| amap-maps (Streamable HTTP) | http://8.217.130.241:13001/amap-maps/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (SSE) | http://8.217.130.241:13001/chart/sse | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| chart (Streamable HTTP) | http://8.217.130.241:13001/chart/mcp | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (SSE) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |
| brave-search (Streamable HTTP) | http://8.217.130.241:13001/brave-search/... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-09-21 07:21:03 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 6
- **Passed:** 6 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| 企业大数据查询MCP (企业大数据查询MCP) | https://mcpmarket.cn/mcp/392bcdd1888ff5f... | ✅ | 11 (100%) | ✅ PASSED | N/A |
| douyin (抖音文案提取) | https://mcpmarket.cn/mcp/ca54f62968bafb6... | ✅ | 3 (100%) | ✅ PASSED | N/A |
| exa-search (Exa MCP) | https://mcpmarket.cn/mcp/207adf63f7027fc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| minimax (MiniMax) | https://mcpmarket.cn/mcp/ac01a47bff2d95d... | ✅ | 9 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | https://mcpmarket.cn/mcp/543eab59bbecfd7... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | https://mcpmarket.cn/mcp/ca58eb072562d68... | ✅ | 25 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-21 07:21:51 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 6
- **Passed:** 6 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| 企业大数据查询MCP (企业大数据查询MCP) | https://mcpmarket.cn/mcp/392bcdd1888ff5f... | ✅ | 11 (100%) | ✅ PASSED | N/A |
| douyin (抖音文案提取) | https://mcpmarket.cn/mcp/ca54f62968bafb6... | ✅ | 3 (100%) | ✅ PASSED | N/A |
| exa-search (Exa MCP) | https://mcpmarket.cn/mcp/207adf63f7027fc... | ✅ | 6 (100%) | ✅ PASSED | N/A |
| minimax (MiniMax) | https://mcpmarket.cn/mcp/ac01a47bff2d95d... | ✅ | 9 (100%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | https://mcpmarket.cn/mcp/543eab59bbecfd7... | ✅ | 1 (100%) | ✅ PASSED | N/A |
| chart (AntV可视化图表) | https://mcpmarket.cn/mcp/ca58eb072562d68... | ✅ | 25 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-21 07:24:22 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 6
- **Passed:** 2 (33.3%)
- **Partial:** 3 (50.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| 企业大数据查询MCP (企业大数据查询MCP) | https://mcpmarket.cn/mcp/392bcdd1888ff5f... | ✅ | 11 (67%) | ✅ PASSED | N/A |
| douyin (抖音文案提取) | https://mcpmarket.cn/mcp/ca54f62968bafb6... | ✅ | 3 (0%) | ⚠️ PARTIAL | N/A |
| exa-search (Exa MCP) | https://mcpmarket.cn/mcp/207adf63f7027fc... | ✅ | 6 (0%) | ⚠️ PARTIAL | API Key Missing |
| minimax (MiniMax) | https://mcpmarket.cn/mcp/ac01a47bff2d95d... | ✅ | 9 (67%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | https://mcpmarket.cn/mcp/543eab59bbecfd7... | ✅ | 1 (0%) | ⚠️ PARTIAL | N/A |
| chart (AntV可视化图表) | https://mcpmarket.cn/mcp/ca58eb072562d68... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-09-21 07:25:56 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 1
- **Passed:** 1 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (AntV可视化图表) | https://mcpmarket.cn/mcp/ca58eb072562d68... | ✅ | 25 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-21 07:28:27 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 1
- **Passed:** 0 (0.0%)
- **Partial:** 1 (100.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (AntV可视化图表) | https://mcpmarket.cn/mcp/ca58eb072562d68... | ✅ | 25 (0%) | ⚠️ PARTIAL | N/A |

---

## Test Session: 2025-09-21 07:30:25 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 1
- **Passed:** 0 (0.0%)
- **Partial:** 1 (100.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (AntV可视化图表) | https://mcpmarket.cn/mcp/ca58eb072562d68... | ✅ | 25 (0%) | ⚠️ PARTIAL | N/A |

---

## Test Session: 2025-09-21 07:31:25 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 1
- **Passed:** 1 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| chart (AntV可视化图表) | https://mcpmarket.cn/mcp/ca58eb072562d68... | ✅ | 25 (67%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-21 07:33:06 [FULL MODE]

### Summary

- **Test Mode:** FULL
- **Total Servers Tested:** 6
- **Passed:** 2 (33.3%)
- **Partial:** 3 (50.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| 企业大数据查询MCP (企业大数据查询MCP) | https://mcpmarket.cn/mcp/392bcdd1888ff5f... | ✅ | 11 (67%) | ✅ PASSED | N/A |
| douyin (抖音文案提取) | https://mcpmarket.cn/mcp/ca54f62968bafb6... | ✅ | 3 (0%) | ⚠️ PARTIAL | N/A |
| exa-search (Exa MCP) | https://mcpmarket.cn/mcp/207adf63f7027fc... | ✅ | 6 (33%) | ⚠️ PARTIAL | API Key Missing |
| minimax (MiniMax) | https://mcpmarket.cn/mcp/ac01a47bff2d95d... | ✅ | 9 (67%) | ✅ PASSED | N/A |
| perplexity-ask (Perplexity) | https://mcpmarket.cn/mcp/543eab59bbecfd7... | ✅ | 1 (0%) | ⚠️ PARTIAL | N/A |
| chart (AntV可视化图表) | https://mcpmarket.cn/mcp/ca58eb072562d68... | ❌ | ❌ | ❓ UNKNOWN | Connection: Test timed out |

---

## Test Session: 2025-09-21 08:12:59 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 1
- **Passed:** 1 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| 12306 (12306车票查询) | https://mcpmarket.cn/mcp/d33e8518753adf5... | ✅ | 8 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-21 09:51:14 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 1
- **Passed:** 1 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| brave-search (Brave Search) | https://mcpmarket.cn/mcp/e23504bca23ba84... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

## Test Session: 2025-09-21 11:29:14 [QUICK MODE]

### Summary

- **Test Mode:** QUICK
- **Total Servers Tested:** 1
- **Passed:** 1 (100.0%)
- **Partial:** 0 (0.0%)
- **Failed:** 0 (0.0%)

### Detailed Results

| Server Name | URL | Connection | Tools | Status | Failure Reason |
|-------------|-----|------------|-------|--------|----------------|
| brave-search (Brave Search) | https://mcpmarket.cn/mcp/e23504bca23ba84... | ✅ | 2 (100%) | ✅ PASSED | N/A |

---

