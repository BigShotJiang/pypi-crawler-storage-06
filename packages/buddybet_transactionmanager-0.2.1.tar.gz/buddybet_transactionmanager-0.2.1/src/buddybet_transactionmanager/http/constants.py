class Constants:
    ALGORITHM = "RS256"
    TOKEN_TYPE = "Bearer"
    DEV_ENV = "DEV"
    PRE_ENV = "PRE"
    PRO_ENV = "PRO"
    RETRIES = 3
    DELAY = 2.0
