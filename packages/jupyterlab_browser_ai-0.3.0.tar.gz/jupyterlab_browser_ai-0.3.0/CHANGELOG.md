# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 0.3.0

([Full Changelog](https://github.com/jtpio/jupyterlab-browser-ai/compare/v0.2.0...b3150296b45fa6bbdb6ad1036c6a2582a965a3ba))

### Enhancements made

- Generate alt text for images with ChromeAI [#2](https://github.com/jtpio/jupyterlab-browser-ai/pull/2) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jtpio/jupyterlab-browser-ai/graphs/contributors?from=2025-09-23&to=2025-09-25&type=c))

[@jtpio](https://github.com/search?q=repo%3Ajtpio%2Fjupyterlab-browser-ai+involves%3Ajtpio+updated%3A2025-09-23..2025-09-25&type=Issues)

<!-- <END NEW CHANGELOG ENTRY> -->

## 0.2.0

([Full Changelog](https://github.com/jtpio/jupyterlab-browser-ai/compare/v0.1.1...71832ff300dc0db534cc302c9fe8431061269f09))

### Enhancements made

- Add WebLLM [#1](https://github.com/jtpio/jupyterlab-browser-ai/pull/1) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jtpio/jupyterlab-browser-ai/graphs/contributors?from=2025-09-22&to=2025-09-23&type=c))

[@jtpio](https://github.com/search?q=repo%3Ajtpio%2Fjupyterlab-browser-ai+involves%3Ajtpio+updated%3A2025-09-22..2025-09-23&type=Issues)

## 0.1.1

No merged PRs
