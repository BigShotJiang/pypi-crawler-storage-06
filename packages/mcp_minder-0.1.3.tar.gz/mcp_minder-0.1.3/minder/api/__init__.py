"""
MCP Minder API 模块

提供 FastAPI 接口用于远程管理 MCP 服务
"""
