"""
MCP Minder Web界面模块

提供基于Gradio的Web界面用于管理MCP服务
"""
