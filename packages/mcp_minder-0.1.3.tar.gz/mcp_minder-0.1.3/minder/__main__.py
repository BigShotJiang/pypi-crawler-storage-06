"""
MCP生成器主入口点

支持 python -m minder 方式运行
"""

from .cli.main import main

if __name__ == "__main__":
    main()
