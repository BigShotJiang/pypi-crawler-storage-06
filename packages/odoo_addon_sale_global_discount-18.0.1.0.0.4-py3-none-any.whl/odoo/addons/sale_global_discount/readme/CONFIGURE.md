To configure this module please refer to configure section of the
base_global_discount module.
