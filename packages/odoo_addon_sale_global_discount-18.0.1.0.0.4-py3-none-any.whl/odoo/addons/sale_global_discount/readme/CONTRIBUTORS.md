- [Tecnativa](https://www.tecnativa.com)
  - David Vidal
  - Pedro M. Baeza
- Omar Castiñeira \<<omar@comunitea.com>\>

- [Studio73](https://www.studio73.es)
  - Miguel Gandia
  - Eugenio Micó
