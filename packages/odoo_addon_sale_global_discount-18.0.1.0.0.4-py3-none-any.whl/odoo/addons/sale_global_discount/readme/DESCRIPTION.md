Apply global financial discounts to sales that will be transmited to
invoices and accounting.
