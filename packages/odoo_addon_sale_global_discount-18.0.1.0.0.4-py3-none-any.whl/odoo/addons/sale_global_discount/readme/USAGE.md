To use this module, you need to:

1.  See usage section of the base_global_discount module.
2.  Create a new sale order and choose a partner.
3.  If the partner has customer global discounts set, those will be
    applied to the order by default.
4.  Otherwise, you can set them manually from the header of the sale
    order.
5.  In the order footer, you can see the computed discounts.
6.  When you create an invoice from the order, the proper global
    discounts will be applied on it.
