from . import models
from .hooks import _pre_init_global_discount_fields
