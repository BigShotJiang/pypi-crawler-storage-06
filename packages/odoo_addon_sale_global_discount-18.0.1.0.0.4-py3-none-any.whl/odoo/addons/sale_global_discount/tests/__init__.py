from . import test_sale_global_discount
from . import test_account_tax
