"""Implementation of syndrome trellis coding (STC).

Author: Martin Benes
Affiliation: University of Innsbruck
"""

pass
