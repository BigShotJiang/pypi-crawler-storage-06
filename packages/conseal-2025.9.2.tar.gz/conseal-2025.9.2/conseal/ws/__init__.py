"""

Author: Martin Benes
Affiliation: University of Innsbruck
"""

from ._costmap import compute_cost_adjusted
from . import _costmap
