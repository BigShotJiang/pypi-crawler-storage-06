.. SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
.. SPDX-FileCopyrightText: 2025 Felix Dombrowski
.. SPDX-License-Identifier: EUPL-1.2



=======
Credits
=======

Development Lead
----------------

* Global Land Monitoring <stassin@gfz.de>
* Global Land Monitoring <besnard@gfz.de>
* Global Land Monitoring <felix.dombrowski@gfz.de>
* FERN.Lab <daniel.scheffler@gfz.de>
* FERN.Lab <johannes.knoch@gfz.de>

Contributors
------------

None yet. Why not be the first?
