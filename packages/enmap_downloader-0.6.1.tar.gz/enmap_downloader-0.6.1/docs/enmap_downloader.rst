.. SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
.. SPDX-FileCopyrightText: 2025 Felix Dombrowski
.. SPDX-License-Identifier: EUPL-1.2

enmap\_downloader package
=========================

Submodules
----------

enmap\_downloader.enmap\_downloader module
------------------------------------------

.. automodule:: enmap_downloader.enmap_downloader
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

enmap\_downloader.enmap\_downloader\_cli module
-----------------------------------------------

.. automodule:: enmap_downloader.enmap_downloader_cli
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

enmap\_downloader.version module
--------------------------------

.. automodule:: enmap_downloader.version
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

Module contents
---------------

.. automodule:: enmap_downloader
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
