.. SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
.. SPDX-FileCopyrightText: 2025 Felix Dombrowski
.. SPDX-License-Identifier: EUPL-1.2

Python API reference
====================

.. toctree::
   :maxdepth: 4

   enmap_downloader
