---
title: "The dsd_config object"
hide:
    - footer
---

# The `dsd_config` object

Most of your work as a plugin author is done in `platform_deployer.py`. This module imports `dsd_config`, which contains information that should be useful about the user's project.

To see all attributes that are available for inspection, expand the source code underneath `__init__()` below.

::: django_simple_deploy.management.commands.utils.dsd_config
