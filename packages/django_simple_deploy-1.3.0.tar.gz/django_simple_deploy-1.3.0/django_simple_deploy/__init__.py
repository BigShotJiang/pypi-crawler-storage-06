import pluggy

hookimpl = pluggy.HookimplMarker("django_simple_deploy")
