# d_back

**d-zone** is an ambient life simulation where the presence and activity of users in a Discord server subtly influence a living digital environment.

This Python module, **d_back**, serves as the bridge between Discord and the [d-zone frontend](https://pixelatomy.com/dzone/).
The current version uses static mock data to simulate user activity and drive the ambient simulation.