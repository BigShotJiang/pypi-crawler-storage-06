from __future__ import annotations

from blescope.utils._compat import metadata


__version__ = metadata.version("blescope")
