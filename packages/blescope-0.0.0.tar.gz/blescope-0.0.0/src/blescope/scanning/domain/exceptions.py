class InvalidScanStateError(Exception):
    pass
