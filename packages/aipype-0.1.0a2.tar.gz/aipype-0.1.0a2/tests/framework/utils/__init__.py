"""Tests for framework utils package."""
