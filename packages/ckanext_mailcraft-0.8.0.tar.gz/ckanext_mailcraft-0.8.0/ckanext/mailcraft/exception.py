class MailerException(Exception):
    pass
