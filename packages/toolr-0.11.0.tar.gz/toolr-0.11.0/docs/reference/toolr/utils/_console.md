# toolr.utils._console

::: toolr.utils._console
