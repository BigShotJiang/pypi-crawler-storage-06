// Include the tests from the lib_test.rs file
include!("command_test.rs");
