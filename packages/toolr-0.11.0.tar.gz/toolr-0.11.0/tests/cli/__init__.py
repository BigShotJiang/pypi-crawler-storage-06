"""CLI integration tests for argument parsing and type casting."""
