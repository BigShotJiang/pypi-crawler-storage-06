# Simple case tools
