# math-utils-demo-你的昵称
简易数学工具库，支持基本运算和单位转换。
## 安装
```bash
pip install math-utils-demo-你的昵称