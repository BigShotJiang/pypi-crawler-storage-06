def add(a, b):
    return a + b

def multiply(a, b):
    return a * b