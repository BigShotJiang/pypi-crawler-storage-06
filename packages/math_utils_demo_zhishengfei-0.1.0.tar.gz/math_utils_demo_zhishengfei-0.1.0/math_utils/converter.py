def cm_to_inch(cm):
    return cm / 2.54