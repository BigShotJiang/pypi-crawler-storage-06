"""Visualization utilities for qualitative outputs."""
from .viz import plot_metric_curve  # noqa: F401
__all__ = ['plot_metric_curve']
