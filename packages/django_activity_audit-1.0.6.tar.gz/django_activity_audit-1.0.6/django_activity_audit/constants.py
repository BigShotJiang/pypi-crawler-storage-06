CONSOLE_FORMAT = (
    "%(levelname)s %(asctime)s %(pathname)s %(module)s %(funcName)s %(message)s"
)

REQUEST_TYPES = [
    "internal",
    "external",
]
