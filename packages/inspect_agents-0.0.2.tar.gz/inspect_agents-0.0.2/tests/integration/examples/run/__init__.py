"""Examples runner tests package.

Holds example-driven runner integration tests, enabling focused selection via
`pytest -k runner` and clearer organization under the `examples/run/` area.
"""
