"""Runner integration tests package.

This package groups `inspect_agents.run` integration tests so they can be
easily selected via `pytest -k runner` and kept organized by scope.
"""
