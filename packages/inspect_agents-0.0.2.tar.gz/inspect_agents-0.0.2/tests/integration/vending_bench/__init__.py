"""Integration tests for vending bench harness."""
