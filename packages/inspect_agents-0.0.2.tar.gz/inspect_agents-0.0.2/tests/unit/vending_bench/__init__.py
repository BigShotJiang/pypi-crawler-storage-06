"""Unit tests for vending bench simulator."""
