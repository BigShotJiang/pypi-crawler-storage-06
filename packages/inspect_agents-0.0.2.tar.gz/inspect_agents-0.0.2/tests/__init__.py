"""Test suite for inspect_agents package."""
