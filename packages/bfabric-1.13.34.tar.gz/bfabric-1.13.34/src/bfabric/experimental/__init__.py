from .multi_query import MultiQuery

__all__ = ["MultiQuery"]
