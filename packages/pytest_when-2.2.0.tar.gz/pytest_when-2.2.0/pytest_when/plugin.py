pytest_plugins = [
    "pytest_when.when",
]
