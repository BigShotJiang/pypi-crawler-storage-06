# -*- coding: utf-8 -*-
from . import main
# try:
#     from .scripts import get_metadata
# except ImportError:
#     from scripts import get_metadata
