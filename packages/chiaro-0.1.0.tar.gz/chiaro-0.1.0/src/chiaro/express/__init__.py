"""Quick plottting API"""

from .api import bar, scatter

__all__ = [
    "bar",
    "scatter",
]
