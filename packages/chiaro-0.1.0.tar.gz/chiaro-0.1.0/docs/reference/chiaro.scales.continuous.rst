chiaro.scales.continuous
========================

.. automodule:: chiaro.scales.continuous

   