chiaro.guides.legend
====================

.. automodule:: chiaro.guides.legend

   