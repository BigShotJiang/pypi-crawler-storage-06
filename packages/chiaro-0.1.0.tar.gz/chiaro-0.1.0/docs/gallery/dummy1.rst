This example shows how to create a scatter plot using Bokeh and export as PNG.
==============================================================================

Source Code
-----------

.. literalinclude:: /../example_scripts/dummy1.py
   :language: python
   :caption: Example code

Interactive Plot
----------------

.. raw:: html

   <iframe src="../_static/gallery/html/dummy1.html" width="100%" height=500 style="border:none; max-width:100%; display:block;"></iframe>
