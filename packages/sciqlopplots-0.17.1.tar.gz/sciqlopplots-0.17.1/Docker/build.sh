#!/usr/bin/sh

docker build -t  sciqlopplots_build --build-arg QT_VERSION=6.7.1 .
