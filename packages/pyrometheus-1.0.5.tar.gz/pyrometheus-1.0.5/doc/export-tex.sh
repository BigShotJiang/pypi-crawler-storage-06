#! /bin/bash

pandoc model.rst -o model.tex
