from .peaks_valleys import detect_peaks_valleys

__all__ = [
    "detect_peaks_valleys",
]