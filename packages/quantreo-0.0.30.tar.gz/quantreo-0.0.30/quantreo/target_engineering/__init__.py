from . import directional
from . import event_based
from . import magnitude