__license__ = "GPL3"
__title__ = "python-usajobsapi"
__version__ = "0.0.1"
