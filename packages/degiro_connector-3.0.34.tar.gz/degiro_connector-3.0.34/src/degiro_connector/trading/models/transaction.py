from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field, field_serializer
from pydantic.alias_generators import to_camel


class HistoryRequest(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,
    )

    from_date: date
    to_date: date
    group_transactions_by_order: bool = Field(default=False)

    int_account: int | None = Field(default=None)
    session_id: str | None = Field(default=None)

    @field_serializer("from_date", "to_date")
    def serialize_date(self, v: date | None) -> str | None:
        return v.strftime("%d/%m/%Y") if v else None


class HistoryItem(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        extra="allow",
        validate_by_name=True,
    )

    auto_fx_fee_in_base_currency: float | None = Field(default=None)
    buysell: str | None = Field(default=None)
    counter_party: str | None = Field(default=None)
    date: datetime | None = Field(default=None)
    executing_entity_id: str | None = Field(default=None)
    fee_in_base_currency: float | None = Field(default=None)
    fx_rate: float | None = Field(default=None)
    gross_fx_rate: float | None = Field(default=None)
    id: int | None = Field(default=None)
    nett_fx_rate: float | None = Field(default=None)
    order_type_id: int | None = Field(default=None)
    price: float | None = Field(default=None)
    product_id: int | None = Field(default=None)
    quantity: int | None = Field(default=None)
    total: float | None = Field(default=None)
    total_fees_in_base_currency: float | None = Field(default=None)
    total_in_base_currency: float | None = Field(default=None)
    total_plus_all_fees_in_base_currency: float | None = Field(default=None)
    total_plus_fee_in_base_currency: float | None = Field(default=None)
    transfered: bool | None = Field(default=None)
    trading_venue: str | None = Field(default=None)
    transaction_type_id: int | None = Field(default=None)


class TransactionsHistory(BaseModel):
    data: list[HistoryItem] = Field(default_factory=list)
