"""
Test suite for ReqSmith API Tester.
"""