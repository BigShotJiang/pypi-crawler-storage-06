"""
Unit tests for ReqSmith core components.
"""