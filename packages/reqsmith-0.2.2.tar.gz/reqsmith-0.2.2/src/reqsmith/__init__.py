"""
ReqSmith - A Postman-like command-line tool for API testing
"""

__version__ = "0.1.0"
__author__ = "ReqSmith Team"
__description__ = "Command-line API testing tool with hybrid caching and optional AI assistance"