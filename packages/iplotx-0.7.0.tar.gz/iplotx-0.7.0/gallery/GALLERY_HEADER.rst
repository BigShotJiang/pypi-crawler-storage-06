Gallery
=======
This is a gallery of examples that demonstrate the capabilities of the ``iplotx`` library.
