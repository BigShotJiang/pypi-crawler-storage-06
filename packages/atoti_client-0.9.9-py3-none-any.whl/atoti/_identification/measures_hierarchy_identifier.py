from .hierarchy_identifier import HierarchyIdentifier

MEASURES_HIERARCHY_IDENTIFIER = HierarchyIdentifier.from_key(("Measures", "Measures"))
