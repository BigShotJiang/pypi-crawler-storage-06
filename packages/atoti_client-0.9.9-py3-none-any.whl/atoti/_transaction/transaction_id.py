from typing import NewType

TransactionId = NewType("TransactionId", str)
