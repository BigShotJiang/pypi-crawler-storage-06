from datetime import timedelta

DEFAULT_QUERY_TIMEOUT = timedelta(seconds=30)
