from fastmcp import FastMCP

# single instance used by all tool modules
mcp = FastMCP("finbrain-mcp")
