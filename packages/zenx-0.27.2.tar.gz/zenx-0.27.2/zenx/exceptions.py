
class DropItem(Exception):
    pass


class NoBlueprintsAvailable(Exception):
    pass