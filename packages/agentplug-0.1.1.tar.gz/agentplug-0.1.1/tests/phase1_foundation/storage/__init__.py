"""Storage module tests."""
