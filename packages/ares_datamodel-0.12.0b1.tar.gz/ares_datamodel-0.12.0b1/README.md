# ARES-datamodel

This python project uses code from the protoletariat repository (https://github.com/cpcloud/protoletariat) under Apache 2.0 license as part of the build toolchain. 