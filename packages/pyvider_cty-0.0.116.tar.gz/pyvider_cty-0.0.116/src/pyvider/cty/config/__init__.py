from __future__ import annotations

"""Configuration and defaults for pyvider-cty."""
