def step_from_external_module() -> int:
    return 1
