from typing import Type, Dict, TYPE_CHECKING
if TYPE_CHECKING:
    from .table import Table

TABLE_REGISTRY = {}
""""""