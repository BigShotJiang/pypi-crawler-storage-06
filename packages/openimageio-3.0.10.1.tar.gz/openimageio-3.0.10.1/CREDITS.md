This is a list of all the contributors to OpenImageIO, sorted alphabetically
by first name.

If you know of somebody that I missed or have corrections, please email:
lg@openimageio.org

* Aaron Colwell
* Adam Mains
* Akihiro Yamasaki
* Alan Jones
* Alejandro Conty
* Alejandro Aguirre
* Aleksandr Motsjonov
* Alex Guirre
* Alex Hughes
* Alex Schworer
* Alexander Kuleshov
* Alexander Murashko
* Alexandre Gauthier
* Alexis Oblet
* Alexy Pawlow
* Alister Chowdhury
* Aman Shah
* Ananth Garre
* Anders Langlands
* Andy Chan
* AngryLoki
* Angus Davis
* Ankit Sinha
* Anton Dukhovnikov
* Anthony Nemoff
* Anthony Roberts
* Aras Pranckevičius
* Arkady Shapkin
* Basile Fraboni
* Basileios Anastasatos
* Bastien Montagne
* Ben De Luca
* Bernhard Rosenkraenzer
* Biswapriyo Nath
* Blair Tennessy
* Blazej Floch
* Brad Smith
* Bram Stolk
* Brecht Van Lommel
* Brent Davis
* Brian Hall
* Brice Gros
* Campbell Barton
* Carl Rand
* Cassian Andrei
* Chad Dombrova
* Changlin Hsieh
* Chaitanya Sharma
* Chris Crosetto
* Chris Foster
* Chris Hellmuth
* Chris Kulla
* Chris Whalen
* Christoph Willing
* Clément Champetier
* Cliff Stein
* Curtis Black
* D-Spirits
* Dalai Felinto
* Dan Wexler
* Daniel Dresser
* Daniel Flehner Heen
* Daniel Wyatt
* Danny Greenstein
* Darby Johnston
* Dharshan Vishwanatha
* David Adler
* David Aguilar
* David Gordon
* Deepak Gopinath
* Dennis Schridde
* Dieter De Baets
* Dinko Galetik
* Dominik Bartkiewicz
* Dominik Wójt
* Duncan Chan
* Dustin Rodrigues
* Edgar Velazquez-Armendariz
* Eloi Du Bois
* Elvic Liang
* Emil Dohne
* Fabien Castan
* Fabien Servant
* Fredrik Averpil
* Frédéric Devernay
* Gaurav Bansal
* Gerrard Tai
* Gerdya
* Ghislain Antony Vaillant
* Gonzalo Garramuño
* Gregor Mueckl
* Grégoire De Lillo
* Guillaume Chatelet
* Hanspeter Niederstrasser
* Harry Mallon
* Heiko Becker
* Henri Fousse
* Hugh Macdonald
* Imarz
* Irena Damsky
* Ismael Cortes
* Jan Hettenkofer
* Jan Honsbrok
* Jens Lindgren
* Jep Hill
* Jeph Alapat
* Jeremy Retailleau
* Jeremy Rose
* Jeremy Selan
* Jesse Yurkovich
* Jim Hourihan
* Joachim Reichel
* Johannes Unterguggenberger
* John Burnett
* John Fea
* John Haddon
* Jonathan Hearn
* Jonathan Scruggs
* Joris Nijs
* Joseph Goldstone
* Julien Enche
* Justin Israel
* Justina Mikonyte
* Kaarrot
* Kazuki Takahashi
* Kevin Brightwell
* Kimball Thurston
* Konrad Kleine
* Krzysztof Blicharski
* Larry Gritz (project leader)
* LazyDodo
* Leonid Onokhov
* Leszek Godlewski
* Li Ji
* Loïc Vital
* Lucas Panian
* Lucille Caillaud
* Lukas Schrangl
* Lukasz Maliszewski
* Luke Emrose
* Lydia Zheng
* M Joonas Pihlaja
* Malcolm Humphreys
* Manuel Gamito
* Manuel Leonhardt
* Marcos Fajardo
* Marie Fetiveau
* Mariusz Szczepanczyk
* Mark Boorer
* Mark Visser
* Massimo Paladin
* Matteo F. Vescovi
* Matthew E. Levine
* Max Liani
* Mel Massadian
* Merwan Achibet
* Michael Cho
* Michael Oliver
* Michel Lerenard
* Michel Normand
* Mikael Sundell
* Mike Root
* Morteza Ramezanali
* Nandan Dubey
* Nathan Rusch
* Nicholas Yue
* Nick Black
* Nicolas Burtnyk
* Nixon Kwok
* Noah Rahm (designer of our logo!)
* Northon Patrick
* Nuno Cardoso
* Oktay Comu
* Ole Gulbrandsen
* Ott Tinn
* Pascal Lecocq
* Patrick Hodoul
* Patrick Piché
* Paul Franz
* Paul Melis
* Paul Molodowitch
* Pavel Karneliuk
* Pete Larabell
* Peter Horvath
* Peter Kovář
* Philip Nemec
* Pino Toscano
* Povilas Kanapickas
* Puneet Jain
* Radu Arjocu
* Ramon Montoya
* Ray Molenkamp
* Rémi Achard
* Richard Shaw
* Robert Matusewicz
* Roeland Schoukens
* Roman Zulak
* Rui Chen
* Rui Li
* Russell Greene
* Ryen
* Saket Jalan
* Sam Richards
* Samuel Nicholas
* Scott Milner
* Scott Wilson
* Sebastian Elsner
* SebTV
* Seifeddine Dridi
* Sergey Sharybin
* Sergio Rojas
* Shane Ambler
* Simon Boorer
* Solomon Boulos
* SRHMorris
* Stefan Bruens
* Stefan Stavrev
* Thiago Ize
* Thomas Dinges
* Thomas Klausner
* Thomas Mansencal
* Till Dechent
* Tim D. Smith
* Tim Grant
* Todica Ionut
* toge
* Tom Knowles
* Troy James Sobotka
* Vernal Chen
* Vic P
* Vinod Khare
* Vishal Agrawal
* Vitor Franchi
* Vlad (Kuzmin) Erium
* Wayne Arnold
* Will Rosecrans
* William Krick
* Wormszer
* Xo Wang
* Yang Yang
* Yann Lanthony
* Zach Lewis
* Ziad Khouri
* zomgrolf
