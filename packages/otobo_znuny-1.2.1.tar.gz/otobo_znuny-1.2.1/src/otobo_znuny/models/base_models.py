from typing import Literal

from pydantic import BaseModel

type BooleanInteger = Literal[0, 1]