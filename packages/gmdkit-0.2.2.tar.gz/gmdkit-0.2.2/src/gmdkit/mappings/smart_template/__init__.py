from . import prop
from . import var_prop