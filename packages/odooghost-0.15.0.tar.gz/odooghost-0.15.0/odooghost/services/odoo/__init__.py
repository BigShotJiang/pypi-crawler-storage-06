from .service import OdooService, get_filestore_path

__all__ = ("OdooService", "get_filestore_path")
