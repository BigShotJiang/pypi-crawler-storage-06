# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import test_account_invoice_report
from . import test_sale_order_report
from . import test_sale_order_type
