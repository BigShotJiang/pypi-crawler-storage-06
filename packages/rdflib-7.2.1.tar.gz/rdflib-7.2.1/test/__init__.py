#
import os

TEST_DIR = os.path.abspath(os.path.dirname(__file__))
