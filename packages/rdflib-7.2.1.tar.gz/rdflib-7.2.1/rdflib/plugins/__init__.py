"""
Default plugins for rdflib.

This is a namespace package and contains the default plugins for
rdflib.

"""
