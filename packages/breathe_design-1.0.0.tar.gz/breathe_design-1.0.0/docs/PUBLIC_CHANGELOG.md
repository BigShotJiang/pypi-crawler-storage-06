# Changelog


## [1.0.0] - 16/09/2025

- Breathe Design is released.
