import asyncio

from cuery.actors import score

asyncio.run(score.main())
