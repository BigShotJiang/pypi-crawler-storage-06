import asyncio

from cuery.actors import assign_topic

asyncio.run(assign_topic.main())
