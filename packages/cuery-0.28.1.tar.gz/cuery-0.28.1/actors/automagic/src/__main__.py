import asyncio

from cuery.actors import automagic

asyncio.run(automagic.main())
