import asyncio

from cuery.actors import entities

asyncio.run(entities.main())
