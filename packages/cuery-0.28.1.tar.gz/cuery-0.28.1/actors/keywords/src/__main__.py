import asyncio

from cuery.actors import keywords

asyncio.run(keywords.main())
