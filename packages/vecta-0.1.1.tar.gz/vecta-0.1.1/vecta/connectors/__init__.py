"""Connector implementations for various vector databases."""
