from .client import InflationClient

__all__ = ['InflationClient']
