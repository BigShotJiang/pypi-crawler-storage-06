from zoneinfo import ZoneInfo

TIMEZONE_BZ = ZoneInfo("America/Sao_Paulo")
