__author__ = "iiPython"
__license__ = "MIT"
__version__ = "0.10.2"

from .controller import LRCLib  # noqa: F401
from .audio import AudioFile, format_lyrics  # noqa: F401
