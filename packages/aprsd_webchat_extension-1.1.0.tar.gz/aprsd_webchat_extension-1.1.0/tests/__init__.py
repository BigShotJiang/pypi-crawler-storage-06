"""Unit test package for aprsd_webchat_extension."""
