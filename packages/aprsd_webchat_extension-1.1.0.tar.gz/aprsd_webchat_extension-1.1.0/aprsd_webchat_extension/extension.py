from aprsd_webchat_extension.cmds import webchat  # noqa: F401
