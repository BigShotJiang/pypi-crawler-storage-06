"""
爬虫的调试：
使用pycharm以新项目模式打开spider下爬虫对应的文件夹即可
    例如调试stock10jqka爬虫，pycharm操作为：【File】->【Open...】->选择*/yangke/spider/stock10jqka项目->【Ok】
"""
import stock10jqka.start_stock10jqka
import stock10jqka.stock10jqka.spiders.jqka_spider
