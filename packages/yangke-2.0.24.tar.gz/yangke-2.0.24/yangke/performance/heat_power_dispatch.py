from PyQt5.QtCore import QUrl
from PyQt5.QtWebEngineWidgets import QWebEngineView


def display_available_region(points_list):
    """
    显示热电可行域的组件

    :return:
    """
    ...



