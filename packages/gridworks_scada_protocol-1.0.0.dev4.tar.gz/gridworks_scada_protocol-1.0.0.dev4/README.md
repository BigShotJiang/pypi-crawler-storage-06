# gridworks-scada-protocol

This package contains data structures used in messages between gridworks-scada
devices, the gridworks ATN and the gridworks-admin.