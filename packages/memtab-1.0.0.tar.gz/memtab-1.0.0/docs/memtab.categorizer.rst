memtab.categorizer module
=========================

.. automodule:: memtab.categorizer
   :members:
   :undoc-members:
   :show-inheritance:
