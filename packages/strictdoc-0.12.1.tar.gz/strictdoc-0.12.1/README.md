# StrictDoc

The documentation is hosted on Read the Docs:
[StrictDoc documentation](https://strictdoc.readthedocs.io/en/stable/).

For a quick overview of the project, check out the
[StrictDoc project](https://github.com/strictdoc-project/strictdoc/blob/main/about/StrictDoc.pdf)
slide deck.
