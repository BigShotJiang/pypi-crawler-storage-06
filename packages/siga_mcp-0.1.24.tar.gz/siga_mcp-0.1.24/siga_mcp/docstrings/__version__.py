from siga_mcp.utils import get_version


def docs() -> str:
    return get_version()
