import React from "react";
export default function App() { return <div>Hello from Agent Hub!</div>; }