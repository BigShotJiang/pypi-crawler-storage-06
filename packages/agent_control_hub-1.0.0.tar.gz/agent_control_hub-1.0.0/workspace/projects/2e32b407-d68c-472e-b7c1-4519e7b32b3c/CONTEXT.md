# Project Context

## Original Prompt
Create a trivia app that includes a login/signup flow.

## Enhanced Prompt
Create a trivia app that includes a login/signup flow.

## Language
react-ts

## Guidance Level
standard
