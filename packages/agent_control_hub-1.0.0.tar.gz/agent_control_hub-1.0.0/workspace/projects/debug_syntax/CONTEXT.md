# Project Context

## Original Prompt
Create a simple hello world app

## Enhanced Prompt
Create a simple hello world app

## Language
python

## Guidance Level
minimal
