"""Python utilities for the multi-agent core."""
