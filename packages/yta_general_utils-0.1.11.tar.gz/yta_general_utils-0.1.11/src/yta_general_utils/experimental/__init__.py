"""
    TODO:

    Hi! Any file and method that is inside the 'experimental'
    folder is not suitable to be actually used with the
    library. The developer is trying the code and making 
    progress but, as the name says, the code is experimental.

    Any use of the code contained in this folder is not the
    developers foul. Thank you for using the library.
"""