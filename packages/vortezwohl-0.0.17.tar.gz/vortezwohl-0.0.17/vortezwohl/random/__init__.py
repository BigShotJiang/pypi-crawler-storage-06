from .seed_generator import next_seed
