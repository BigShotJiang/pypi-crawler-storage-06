# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, TypedDict

__all__ = ["TextEditor20241022Def"]


class TextEditor20241022Def(TypedDict, total=False):
    name: str

    type: Literal["text_editor_20241022"]
