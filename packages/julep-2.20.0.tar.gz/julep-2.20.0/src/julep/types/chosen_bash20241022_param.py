# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["ChosenBash20241022Param"]


class ChosenBash20241022Param(TypedDict, total=False):
    command: Optional[str]

    restart: bool
