from ML_management.local_debug import debug_job_result

DebugJobResult = debug_job_result.DebugJobResult
