from .train_executor import TrainExecutor


def get_object():
    return TrainExecutor()
