from .base_executor import BaseExecutor
from .no_model_executor_pattern import NoModelExecutorPattern

NoModelExecutorPattern = NoModelExecutorPattern
BaseExecutor = BaseExecutor
