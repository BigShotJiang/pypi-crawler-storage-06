"""
光合平台元素操作模块
"""

from .talent_elements import GuangheTalentElements

__all__ = [
    'GuangheCommonElements',
    'GuangheDashboardElements',
    'GuangheAnalyticsElements',
    'GuangheTalentElements'
]
