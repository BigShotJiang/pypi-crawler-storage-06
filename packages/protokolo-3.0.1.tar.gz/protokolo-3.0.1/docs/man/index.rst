..
  SPDX-FileCopyrightText: 2024 Carmen Bianca BAKKER <carmen@carmenbianca.eu>

  SPDX-License-Identifier: CC-BY-SA-4.0 OR EUPL-1.2+

Command-line reference
======================

.. toctree::
   :maxdepth: 1

   protokolo
   protokolo-compile
   protokolo-init
