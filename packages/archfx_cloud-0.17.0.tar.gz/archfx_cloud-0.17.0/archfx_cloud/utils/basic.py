
def datetime_to_str(dt):
    return dt.strftime('%Y-%m-%dT%H:%M:%SZ')