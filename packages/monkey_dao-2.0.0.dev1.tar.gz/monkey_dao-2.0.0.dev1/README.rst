Monkey DAO
==========

Simple Data Access Object pattern implementation

Installation guide
------------------

::

    pip install monkey-dao

User guide
----------

   
