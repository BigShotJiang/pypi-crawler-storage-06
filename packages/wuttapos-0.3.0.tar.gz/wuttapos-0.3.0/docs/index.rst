
WuttaPOS
========

WuttaPOS is a `Python`_ point of sale app based on `Rattail`_.

.. _Python: https://www.python.org/
.. _Rattail: https://rattailproject.org/

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   quickstart
   menus


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
