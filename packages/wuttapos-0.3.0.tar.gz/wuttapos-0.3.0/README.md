
# WuttaPOS

Point of sale system based on Rattail

See docs at https://rattailproject.org/docs/wuttapos/
