from setuptools import setup, find_packages

setup(
    name='diag_pythoncode',
    version='0.0.2',
    packages=find_packages(),
    install_requires=[
        'requests>=2.20.0',
        'numpy',
    ],
    # 其他元数据...

    include_package_data=True,

    # ======= 这是关键的 package_data 部分 =======
    package_data={  # 这是一个字典的开始
        'diag_pythoncode': ['data/document.7z'],  # 键 'diag_pythoncode' 和值 ['data/document.7z'] 之间用冒号 ':' 分隔
    },              # 这是字典的结束
    # ============================================
)
