
# hyperpod-jumpstart-inference-template

## Installation
`pip install hyperpod-jumpstart-inference-template`

## Overview 
This package provides the configuration schema for JumpStart Inference Operator.

