def ping() -> str:
    return "pong"
