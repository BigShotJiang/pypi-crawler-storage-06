1.  Go to *Contacts*.
2.  Select default delivery address, invoice address or contact for
    partner.
