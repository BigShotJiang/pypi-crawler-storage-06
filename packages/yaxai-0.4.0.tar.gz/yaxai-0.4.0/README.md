# yax: You Are eXpert

`yax` goal is to arm your AI agents with your expert knowledge.