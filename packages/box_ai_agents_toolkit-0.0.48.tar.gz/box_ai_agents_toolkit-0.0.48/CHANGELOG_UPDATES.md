## 0.0.48 - 2025-09-17

* Merge pull request #3 from box-community/rb/users (b1fd38d)
* Update src/box_ai_agents_toolkit/box_api_users.py (310ceda)
* Update src/box_ai_agents_toolkit/box_api_users.py (a9ec88d)
* fix copilot suggestion (9219cd1)
* fix test while loop (e500c9e)
* implementing users list and search (25ebe22)
* Update version to 0.0.47 and changelog (e6719a2)