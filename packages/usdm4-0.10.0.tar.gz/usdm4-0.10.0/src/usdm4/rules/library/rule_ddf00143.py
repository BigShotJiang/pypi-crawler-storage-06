from usdm3.rules.library.rule_ddf00143 import RuleDDF00143 as V3Rule


class RuleDDF00143(V3Rule):
    pass
