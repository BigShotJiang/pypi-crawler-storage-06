from usdm3.rules.library.rule_ddf00146 import RuleDDF00146 as V3Rule


class RuleDDF00146(V3Rule):
    pass
