from usdm3.rules.library.rule_ddf00144 import RuleDDF00144 as V3Rule


class RuleDDF00144(V3Rule):
    pass
