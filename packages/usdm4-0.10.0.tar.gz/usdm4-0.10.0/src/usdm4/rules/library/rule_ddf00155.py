from usdm3.rules.library.rule_ddf00155 import RuleDDF00155 as V3Rule


class RuleDDF00155(V3Rule):
    pass
