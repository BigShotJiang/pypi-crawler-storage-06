from usdm3.rules.library.rule_ddf00150 import RuleDDF00150 as V3Rule


class RuleDDF00150(V3Rule):
    pass
