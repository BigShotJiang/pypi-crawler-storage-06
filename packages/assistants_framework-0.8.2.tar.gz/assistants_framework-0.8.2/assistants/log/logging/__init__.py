from ._loguru_logger import logger

__all__ = ["logger"]
