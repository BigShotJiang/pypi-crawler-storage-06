# main entry point for ispeak

import sys

from ispeak.cli import main

if __name__ == "__main__":
    sys.exit(main())
