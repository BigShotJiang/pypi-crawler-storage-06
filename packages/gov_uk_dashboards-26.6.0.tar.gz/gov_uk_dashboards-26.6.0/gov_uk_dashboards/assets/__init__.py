"""Module containing the shared front end assets"""

from .get_assets_folder import get_assets_folder
