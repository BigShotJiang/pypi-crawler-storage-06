This module propagates the owner_id from a source document to new Purchase Order created by the stock rule.
