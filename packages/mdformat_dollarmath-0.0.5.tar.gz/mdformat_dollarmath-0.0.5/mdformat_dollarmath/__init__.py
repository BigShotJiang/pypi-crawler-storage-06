"""An mdformat plugin for formatting dollarmath."""

__version__ = "0.0.5"

from .plugin import RENDERERS, update_mdit  # noqa: F401
