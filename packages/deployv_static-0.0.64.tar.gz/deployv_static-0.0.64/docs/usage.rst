========
Usage
========

To use DeployV static in a project::

    import deployv-static
