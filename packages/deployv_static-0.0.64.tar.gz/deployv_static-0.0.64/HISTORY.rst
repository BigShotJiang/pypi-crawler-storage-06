.. :changelog:

History
-------

0.0.1 (2019-07-12)
---------------------

* First release on PyPI.
