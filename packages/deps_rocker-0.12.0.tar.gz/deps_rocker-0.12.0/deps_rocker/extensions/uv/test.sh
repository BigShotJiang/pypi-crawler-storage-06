#!/bin/bash

set -e 

uv --version
echo "uv is installed and working"
