from .omega import Omega
