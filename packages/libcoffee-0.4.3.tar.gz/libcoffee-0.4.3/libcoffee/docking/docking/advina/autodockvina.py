class ADVina:
    pass
