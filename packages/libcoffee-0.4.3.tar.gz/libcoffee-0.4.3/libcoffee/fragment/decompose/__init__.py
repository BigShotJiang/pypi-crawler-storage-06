from .decompose import CmpdDecompose
