# libcoffee
Library for COmpound Filtering via Fragment-based Efficient Evaluation

## installation

```sh
pip install -e .
```

## check code typing

```sh
mypy libcoffee --explicit-package-bases
```