"""Foundation CLI commands."""

from __future__ import annotations

# This module provides CLI commands for foundation utilities
