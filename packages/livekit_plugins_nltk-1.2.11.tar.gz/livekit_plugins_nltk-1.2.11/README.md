# NLTK plugin for LiveKit Agents

Support for [NLTK](https://www.nltk.org/)-based text processing. Currently featuring a `SentenceTokenizer`.

## Installation

```bash
pip install livekit-plugins-nltk
```
