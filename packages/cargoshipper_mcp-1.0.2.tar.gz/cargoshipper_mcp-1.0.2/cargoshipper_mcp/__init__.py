"""CargoShipper MCP Server - Docker, DigitalOcean, and CloudFlare API integration"""

__version__ = "1.0.0"
__author__ = "CargoShipper Team"