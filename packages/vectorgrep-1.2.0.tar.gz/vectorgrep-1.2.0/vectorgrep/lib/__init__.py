"""Shared files and libraries across languages for reading raw text files with Vectorscan."""
