## 23.0.0.20250923 (2025-09-23)

Add stubs for gunicorn ([#14690](https://github.com/python/typeshed/pull/14690))

