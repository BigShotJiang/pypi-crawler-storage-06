# Store the version here
from importlib import metadata

__version__ = metadata.version('cnn2snn')
