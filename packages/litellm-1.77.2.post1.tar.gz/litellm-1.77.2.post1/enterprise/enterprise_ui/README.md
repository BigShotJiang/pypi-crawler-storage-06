## Admin UI

Customize the Admin UI to your companies branding / logo
![Group 204](https://github.com/BerriAI/litellm/assets/29436595/3b7dbfc2-6fcd-42af-996d-f734fb8f461b)

## Docs to set up Custom Admin UI [here](https://docs.litellm.ai/docs/proxy/ui)
