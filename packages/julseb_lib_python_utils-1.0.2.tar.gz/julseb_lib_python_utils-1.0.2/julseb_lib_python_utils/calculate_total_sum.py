def calculate_total_sum(array: list[float]) -> float:
    """
    Returns the sum of all numbers in the array.
    """
    return sum(array)
