from pydantic import BaseModel


class SimpleActionSchema(BaseModel):
    pass


    
