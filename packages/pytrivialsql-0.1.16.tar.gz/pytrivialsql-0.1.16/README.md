# PyTrivialSQL

_A basic set of quality-of-life bindings for SQL interaction that I've copy/pasted more than twice. Currently supports Sqlite3 and Postgres. PRs welcome for other databases._
