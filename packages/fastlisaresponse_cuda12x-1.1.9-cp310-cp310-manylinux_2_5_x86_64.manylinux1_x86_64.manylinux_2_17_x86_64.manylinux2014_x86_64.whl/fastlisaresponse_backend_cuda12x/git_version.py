"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "e507635d347e1be3a4be0f56baee8d7ce289c7dd"
short_id = "e507635"
