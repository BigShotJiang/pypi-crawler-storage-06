from django.apps import AppConfig


class PaypleHj3415Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'payple_hj3415'
