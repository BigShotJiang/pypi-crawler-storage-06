"""Fastmail platform implementation"""

from .client import FastmailClient

__all__ = ['FastmailClient']