"""GitHub Issue Analysis - Collect and analyze GitHub issues with AI."""

__version__ = "0.1.0"
