"""Storage package for managing GitHub issue data."""

from .manager import StorageManager

__all__ = [
    "StorageManager",
]
