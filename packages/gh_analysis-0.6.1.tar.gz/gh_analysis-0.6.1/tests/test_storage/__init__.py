"""Tests for storage package."""
