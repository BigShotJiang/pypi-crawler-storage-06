"""CLI tests."""
