| app_name   | version   | positive_pct   | app_path   | app_url   |
|------------|-----------|----------------|------------|-----------|