from __future__ import annotations

HOST_NAME = "localhost"
SERVER_PORT = 8080
OAUTH_RETURN_PATH = "/oauth/return"
