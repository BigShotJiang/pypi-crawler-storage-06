from .core import PlaywrightScraper

__all__ = ["PlaywrightScraper"]
