"""Core utilities and helper functions for the vector database."""
