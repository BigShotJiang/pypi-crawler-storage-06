from snanpy.functions import figax

# Version of the snanpy package
__version__ = "2.2.12"