#!/usr/bin/env python3
"""Entry point for running sl_transit_repl as a module."""

from .main import main

if __name__ == "__main__":
    main()
