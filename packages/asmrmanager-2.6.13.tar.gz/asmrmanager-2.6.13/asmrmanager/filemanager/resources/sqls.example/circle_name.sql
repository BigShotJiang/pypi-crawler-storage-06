select distinct circle_name from asmr
order by random()
limit 20;