"""
Custom generator for API routers.
"""
from tai_api.generators import RoutersGenerator


class CustomRoutersGenerator(RoutersGenerator):
    """
    TODO: Custom generator for API routers that extends the base RoutersGenerator.
    """
    pass

