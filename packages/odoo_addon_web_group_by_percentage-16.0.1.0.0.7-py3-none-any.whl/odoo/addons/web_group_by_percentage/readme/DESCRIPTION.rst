This module shows the percentage of the total sum in group by rows.

.. image:: ../static/description/screenshot.png
   :alt: Printscreen of percentages in group rows
