To use this module, you need to:

#. Go to any list view;
#. group by one or more fields.
