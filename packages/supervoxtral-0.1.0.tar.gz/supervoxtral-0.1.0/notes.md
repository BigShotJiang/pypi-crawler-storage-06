todo

- localisation reccording dans config
- paste directement ?
- nettoyer xml réponse (option)
- post prompt
- dépendance ffmpeg
- fichier ? ou sont il meme si suppr ? possible record en opus direct ?
