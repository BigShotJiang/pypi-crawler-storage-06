* Antonio Espinosa <antonio.espinosa@tecnativa.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Jordi Ballester Alomar <https://github.com/JordiBForgeFlow>
* Sergio Corato <https://github.com/sergiocorato>
* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>

* `Ooops <https://ooops404.com>`__

  * Giovanni Serra <giovanni@gslab.it>
