class IdpConstants:
    ALGORITHM = "RS256"
    TOKEN_TYPE = "Bearer"