from llama_index.llms.yi.base import Yi


__all__ = ["Yi"]
