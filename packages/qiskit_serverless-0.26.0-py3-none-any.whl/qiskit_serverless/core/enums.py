"""This file contains the enums used in the project."""

from enum import Enum


class Channel(str, Enum):
    """
    This enum identifies the different types of channels with that a user can
    authenticate against.
    """

    LOCAL = "local"
    IBM_CLOUD = "ibm_cloud"
    IBM_QUANTUM_PLATFORM = "ibm_quantum_platform"
