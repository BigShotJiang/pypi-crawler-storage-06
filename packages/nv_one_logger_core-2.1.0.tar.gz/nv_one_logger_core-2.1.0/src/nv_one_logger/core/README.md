# `nv-one-logger.core`

This package contains API and models (classes) used inside the OneLogger framework.

If the API / models are needed by external code (the application code that call `nv-one-logger`),
 then they should reside in `nv-one-logger.api`.
