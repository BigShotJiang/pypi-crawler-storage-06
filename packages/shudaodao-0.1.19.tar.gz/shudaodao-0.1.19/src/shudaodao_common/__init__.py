#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# @License  ：(C)Copyright 2025, 数道智融科技
# @Author   ：李锋
# @Software ：PyCharm
# @Date     ：2025/8/27 上午1:29
# @Desc     ：

from .controller_table.dept import Dept_Router
from .controller_table.user import User_Router
from .shared.controller.upload import Upload_Router
from .shared.service.upload import UploadService
