"""To run this module directly."""

import logging

from . import bescli

logging.basicConfig()
bescli.main()
