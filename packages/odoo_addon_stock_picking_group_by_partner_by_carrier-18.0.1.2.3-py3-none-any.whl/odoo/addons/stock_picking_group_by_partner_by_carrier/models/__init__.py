from . import (
    procurement_group,
    res_partner,
    sale_order,
    sale_order_line,
    stock_move,
    stock_picking,
    stock_picking_type,
    stock_rule,
    stock_warehouse,
)
