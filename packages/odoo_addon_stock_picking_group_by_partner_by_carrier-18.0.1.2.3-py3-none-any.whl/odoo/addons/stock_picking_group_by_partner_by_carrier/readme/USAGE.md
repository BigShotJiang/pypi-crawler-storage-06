To use this module you need to enable grouping on the picking types for
which you want grouping.

If you want to enable this for the shippings of a warehouse:

- be sure that in the settings of the Inventory app, you checked "Manage
  Push and Pull inventory flows"
- enable "debug mode"
- go to the warehouse for which you want grouping and check the setting
  "Group Shippings"

You can also enable this for individual picking types by checking the
setting "Group Pickings" on the picking type view.
