from legacy.cli import BATCLI

BATCLI()
