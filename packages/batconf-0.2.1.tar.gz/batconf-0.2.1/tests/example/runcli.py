from project.cli import BATCLI

BATCLI()
