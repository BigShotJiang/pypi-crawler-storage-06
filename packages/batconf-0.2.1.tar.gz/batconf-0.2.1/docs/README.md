# BatConf Documentation

## How to build the docs
### Install required packages
`pip install --editable .[docs]`
* on Mac/zsh put quotes around `".[docs]"`


### build the document files
```bash
cd docs/
make docs
```
