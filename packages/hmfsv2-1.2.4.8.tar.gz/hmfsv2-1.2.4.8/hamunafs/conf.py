REDIS = {
    'host': 'cache.ai.hamuna.club',
    'port': 6379,
    'pass': '1987yang',
    'db': 2
}

NSQ = {
    'host': 'kafka.ai.hamuna.club',
    'port': 34150,
    'httpport': 34151
}