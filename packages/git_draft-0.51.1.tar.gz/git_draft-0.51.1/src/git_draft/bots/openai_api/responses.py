"""Responses API backed implementation

* https://platform.openai.com/docs/guides/function-calling?api-mode=responses
"""

# TODO: Implement.
