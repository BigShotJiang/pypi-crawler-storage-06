select origin_branch
  from folios
  where id = :id;
