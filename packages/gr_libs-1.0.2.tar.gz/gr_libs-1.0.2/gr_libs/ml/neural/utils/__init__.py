""" utility functions for GR algorithms that use neural networks """
