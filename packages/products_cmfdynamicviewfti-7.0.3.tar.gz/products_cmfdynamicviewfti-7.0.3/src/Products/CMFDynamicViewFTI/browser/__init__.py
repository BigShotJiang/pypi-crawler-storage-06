"""
Browser subpackage
"""

# $Id$
