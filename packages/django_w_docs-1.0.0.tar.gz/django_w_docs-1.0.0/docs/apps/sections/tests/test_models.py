"""Tests for docs.sections.models"""

from django.test import TestCase


# Create your tests here.
class DocsSectionTests(TestCase):
    """DocsSection model tests"""

    def setUp(self) -> None:
        """Setup before tests"""

        return super().setUp()
