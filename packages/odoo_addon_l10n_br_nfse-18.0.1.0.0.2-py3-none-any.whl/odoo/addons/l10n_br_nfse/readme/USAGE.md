Após o módulo do serviço de transmissão necessário ser instalado, crie
um documento do tipo Notas Fiscais de Serviço Eletrônicas (NFS-e) para
ser possível confirmá-lo e transmiti-lo.
