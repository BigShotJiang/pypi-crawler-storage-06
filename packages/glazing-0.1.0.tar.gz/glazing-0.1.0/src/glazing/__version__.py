"""Version information for the glazing package."""

__version__ = "0.1.0"
__version_info__ = tuple(int(i) for i in __version__.split("."))
