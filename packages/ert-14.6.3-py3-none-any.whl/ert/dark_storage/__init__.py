"""
Dark Storage is an API towards data provided the `storage/` directory.
"""
