# Copyright 2025 © BeeAI a Series of LF Projects, LLC
# SPDX-License-Identifier: Apache-2.0

from beeai_framework.tools.search.retrieval.vector_store import VectorStoreSearchTool

__all__ = ["VectorStoreSearchTool"]
