posttroll
=========

[![Coverage Status](https://coveralls.io/repos/mraspaud/posttroll/badge.png?branch=feature-no-datatypes)](https://coveralls.io/r/mraspaud/posttroll?branch=feature-no-datatypes)

High-level messaging system for pytroll.
