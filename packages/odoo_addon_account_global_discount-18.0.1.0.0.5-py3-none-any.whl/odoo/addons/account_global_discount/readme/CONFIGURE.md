To configure this module, you need to:

1.  Go to *Settings \> Parameters \> Global Discounts*.
2.  Add a new discount percentage.
3.  Choose the discount scope (sales or purchases).
4.  You can also restrict it to a certain company if needed.

You can assign global discounts to partners as well:

1.  Go to a partner that is a company.
2.  Go to the *Sales & Purchases* tab.
3.  In section sale, you can set sale discounts.
4.  In section purchase, you can set purchase discounts.
