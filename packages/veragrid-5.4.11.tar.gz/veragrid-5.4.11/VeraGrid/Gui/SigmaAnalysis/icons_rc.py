# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x0dZ\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22g\
ear.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x22784\x22\x0a     i\
nkscape:window-h\
eight=\x22480\x22\x0a    \
 id=\x22namedview4\x22\
\x0a     showgrid=\x22\
false\x22\x0a     inks\
cape:zoom=\x221.229\
1667\x22\x0a     inksc\
ape:cx=\x22-47.9999\
97\x22\x0a     inkscap\
e:cy=\x2296.000003\x22\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x220\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <path\x0a     s\
tyle=\x22fill:#9999\
99;stroke-width:\
1.33333337\x22\x0a    \
 d=\x22m 77.685212,\
176.62546 c -0.3\
6495,-0.59051 -1\
.359378,-6.15571\
 -2.20984,-12.36\
712 -0.85046,-6.\
21142 -1.647284,\
-11.29448 -1.770\
72,-11.2957 -0.2\
92876,-0.003 -8.\
928958,-4.7575 -\
11.737142,-6.461\
93 -1.605474,-0.\
97444 -5.033267,\
-0.14448 -13.016\
802,3.15168 -6.6\
91473,2.76271 -1\
1.300681,3.99631\
 -12.048381,3.22\
459 -2.638601,-2\
.72336 -17.42210\
1,-29.37153 -17.\
422101,-31.4044 \
0,-1.19223 3.885\
057,-5.09518 8.6\
3346,-8.67324 l \
8.63346,-6.50555\
 v -8.666671 -8.\
666667 l -8.6334\
6,-6.505556 c -4\
.748403,-3.57805\
6 -8.63346,-7.48\
1016 -8.63346,-8\
.673242 0,-2.039\
252 14.78798,-28\
.686171 17.43578\
9,-31.41809 0.76\
5807,-0.790132 5\
.266256,0.388912\
 12.011621,3.146\
851 10.735632,4.\
389415 10.808082\
,4.399033 15.223\
394,2.021232 9.2\
26118,-4.968593 \
9.854293,-5.9181\
76 11.40331,-17.\
237861 0.802812,\
-5.866667 1.9121\
58,-11.134266 2.\
465212,-11.70577\
5 0.553056,-0.57\
1509 9.357958,-0\
.871509 19.56645\
2,-0.666667 l 18\
.560886,0.372442\
 2,11.741416 2,1\
1.741416 6.3294,\
3.92525 c 3.4811\
7,2.158888 6.792\
53,3.925251 7.35\
858,3.925251 0.5\
6605,0 5.41918,-\
1.844483 10.7847\
4,-4.098851 5.36\
556,-2.254369 10\
.45926,-3.828818\
 11.31934,-3.498\
777 2.03324,0.78\
0228 18.20794,29\
.028695 18.20794\
,31.799445 0,1.1\
66222 -3.88505,5\
.047904 -8.63345\
,8.62596 l -8.63\
347,6.505556 v 8\
.666667 8.666671\
 l 8.63347,6.505\
55 c 4.7484,3.57\
806 8.63345,7.48\
101 8.63345,8.67\
324 0,2.03287 -1\
4.7835,28.68104 \
-17.4221,31.4044\
 -0.74772,0.7717\
4 -5.29872,-0.43\
786 -11.89703,-3\
.1621 l -10.6860\
6,-4.41197 -7.21\
862,3.77944 -7.2\
1861,3.77943 -1.\
77879,12.04933 -\
1.77879,12.04933\
 -18.899066,0.36\
932 c -10.394484\
,0.20314 -19.197\
66,-0.11386 -19.\
562612,-0.7043 z\
 m 29.504508,-53\
.06908 c 14.6252\
1,-6.10929 21.57\
602,-23.26646 15\
.09602,-37.26259\
4 -10.20217,-22.\
03565 -40.74219,\
-22.03565 -50.94\
4364,0 -10.32964\
1,22.310974 13.1\
68754,46.736394 \
35.848344,37.262\
594 z\x22\x0a     id=\x22\
path817\x22\x0a     in\
kscape:connector\
-curvature=\x220\x22 /\
>\x0a</svg>\x0a\
\x00\x00\x04\x9d\
\x00\
\x00\x10\x03x\xda\xe5WK\x8f\xdb6\x10\xbe\xef\xaf`\
\x95K\x82\x9a\x14IQ\xa2\xa4\xda\x0e\xd0\x04\x01r\xe8\
\xa5M\xd13-\xd2k%\x92hH\xf4z7\xbf>\
CY\x0f{\x1f\xc06)\x0al\xcb\xc5\x02\x9e\x079\
3\xdf|\x1c\xda\xcb\xb7\xb7u\x85nL\xdb\x95\xb6Y\
\x05\x8c\xd0\x00\x99\xa6\xb0\xbal\xaeW\xc1\x9f\x9f>\xe0\
4@\x9dS\x8dV\x95m\xcc*hl\xf0v}\xb5\
\xfc\x09c\xf4\xae5\xca\x19\x8d\x8e\xa5\xdb\xa1\x8f\xcd\x97\
\xaeP{\x83^\xef\x9c\xdb\xe7ax<\x1eI9(\
\x89m\xaf\xc37\x08\xe3\xf5\xd5\xd5\xb2\xbb\xb9\xbeB\x08\
A\xdc\xa6\xcbu\xb1\x0a\x86\x0d\xfbC[\xf5\x8e\xba\x08\
Mej\xd3\xb8.d\x84\x85\xc1\xec^\xcc\xee\x85\x8f\
^\xde\x98\xc2\xd6\xb5m\xba~g\xd3\xbd:sn\xf5\
v\xf2\xf6\xd9\x1c\xa3\xde\x89eY\x16R\x1er\x8e\xc1\
\x03ww\x8dS\xb7\xf8r+\xe4\xf8\xd8VN)\x0d\
\xc16{>\xcf+\xef\x00\xd0=\xfcO\xee\xa3\x82t\
\xf6\xd0\x16f\x0b\xfb\x0ci\x8c\x0b\xdf\x7fz?\x191\
%\xda\xe9\xb3cF</\xa2^\x80\xdc\xa8\xdat{\
U\x98.\x1c\xf5\xfd\xfe\xb3\x0e\xb3^Q\xeaU\x009\
\xf2^8\x96\xda\xed\xc0\x96\x9d\xc4\x9d)\xafwn\x96\
oJs\xfc\xd5\xde\xae\x02\x8a(\x02%\x1a\x0dc\xa2\
\xb9\xb6\x85\x8f\xbc\x0a*\x88\x8a\x9d\xc5\x1dt\xb0p\x10\
\x91\x8c@\x8c\xe9\xe4S*\x94d\x9cD\xe85\x174\
\x8eE\xb2@\x9c\xb2\x14\xd3\x083\xf6&X\xc3\x9ee\
m\x9c\xd2\xca)\xbf\xff\x94\xf2\xa8I{\x07p\x81\x16\
\xe6\xbf\xbf\xffp\x92@.\x8a\xfc/\xdb~\x19DX\
\xdeAm\xec\x01\xea\x09\xd6\x93z\xa9\x8b\x1c@\xaf\x95\
[\x97\xb5\xba6\xbe_?\x03\xc8\xcbp6\x5c8\xbb\
\xbb\xbd\x99\x0f=\x1d\xdb\x9aS\xf7\x1e\xa5\xb0.\xea\xd2\
o\x0a\xffpeU}\xf4A\x02\x14\xde;\xb4t\x95\
Y\xf71O\x1f\xc7*\xc2\xa1\x8c\xa1\xc8\xf0\xac\xcae\
8b\xd0K\xdal\xbb\x19\x1e/%C\x98\xe5\xd4\x1d\
\xdf\x1a\xed\x9bxr\xdcC*\x85\xadl\xbb\x0a^m\
\xfb\x15\x9c\x0c\x1b\xdbj\xd3\x8e\xa6\xa4_\x17&\x0b\xcc\
\x82\xa2\x80\x19\x83\xdan>C\x9b\x9d\xadL\xab\x1a\x0f\
\x04\xa3\x83\xe5\xba\x05N=\xa6?\x94\xda<f\x98\xf8\
\xe1\xd3\x9b\x02=j\xedvJ\xdb\xe3*\xe0\xf7\x8d\xc7\
\xb2\x01\x03\x1e\xe9\x9c&\xd1\x13\x1e\x13\xc3)\x8f\x83\x19\
\xbe\x09(1(\xbb\x9d=\xfaJV\xc1VU\x9d\xb9\
\x7f\xdaWkk\x7f\xa58\xcfX\x92\xc8\xfb\xe6\x02\xae\
\x0c\x16\x92d~\xa5\x0f\xacP^\x96\x10\xeaW\xf2D\
\x9ep@,\x9f\xb0\xc1v\xfe\x94\xadV\xb7e]~\
5zn\xd5\x1c\xf7\xd0\xb60[q\xa5\xeeL;\x0c\
\x81\x811-4s(\xdc\xddU\xd0\x9d\xa1\x0f9\xfb\
e\x0b$\xce_\xa5\x8ao\x0c\xef\x05<\xdb:\xd7\xda\
/&\x1f\xc84\x88\xa7.\xe4\x94DRf1\x97\xf1\
\xa8\x87\x11a \x91\xbc\xb5\x87F\x9f+?\xdb\xb2\xc9\
7\xe6\xc6T\xa3\x16n\x90i+\xa8\xc4\xe5b\xd4i\
\x05\xedo[u\x977\xf0 \x8d\xda9\x99\xbd*\xa1\
\xb8\x9e\xae\xe0\x01\x17\xb9:k\xb0/0e#o\x06\
\x9e\x88\x880\xe0\x8a\x18\x990\x92C0\x222\x16\xf3\
\x91\x0c\xbe\x9b,\x95$\xe6\xb1\x18uw^\xc7\xc1\x91\
\xd1tl\x86\x03jw~\x86\x00\xb8\x85\xaa\xcck\x0c\
\xf3\xec\xb9\x08\x0b\x96d\x86\xbdx\x84q\xf4\xfd\x18\xc3\
\x8d\xe9]\xb33\x8c3Jh\x9a\xa6<{\x06\xc6{\
\xe5v\x17\x18\xf7\xc8\xf6\xb5\xf4\xb0\xb6\x87\xca\xe4\x00B\
c\xb5\x9e\x90M\xa9\xff\xbbD\xf6\x01\xa0\x9b\x83s\x0f\
\xf0\xec!\xfc\xfbxz\xad\xddn;\xe3r\xfa\x00\xe3\
\xa1J\xc0\xf37\xc4DL8cR.\x18\x85\xefg\
\x8c'\x12\xbdC\x8c\x0a\x92$<\x11\x8bL\x90,M\
i\x14!\xc6\xe0cB\xa3x!\x19\x89b\xc1c\x8e\
DB\xa4\x94Q,\x17IF\x04\xe5\x19\xe7g\xdd\xf2\
P\xcd\xa0\xce#\xc26P\xb0\xb3-\x86aq\xa3\xdc\
\xa15\xf3(\x9e\x9f\x15\x0b\x93\x1c^8\xf8\x12T\x14\
\xcf'\xf8\x86\xd2\xf4\xe5\x8f\x10\x9c\xfc\xd8\x10\xa1\x09c\
g\xfcNRB\xb9\x14\xd3{\xfb\xbf\xe1w\x0d\xfc\x16\
D\x0a)\xa2\x05\x5c\xfc\x04\x08\x9apT ,(\x89\
\x01\xb9h\x81\xe1\x8d\xe4\x22\x89\x10\xe6\x19\x91\xa9\xa4\xe9\
\x82GDr\x91e\x08g\xf0\xbaJJe\xb4\x80!\
\x0c<\x9f\x00<c7\x96\xff&\xbf7*\x8eu\xf4\
\xf2\xf9\x1d\xff0\xbfiz\xfeHJ\x0e\x9d\x82\x89\xf5\
\x9f!\xf8\x13\xc3z$3`Bb\x99\x0a>\x0ck\
\x96\xa5\xa0\x84q\x1c\xc7\x91\xcc\xbe\x7fV\xe3\xe8\x9fb\
\xf3\xd2\xff\xe8Y_}\x03\x0d\xf2\xdf\xcb\
\x00\x00\x0b\x13\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22c\
opy2down.svg\x22\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0a  <metadata\x0a  \
   id=\x22metadata8\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a       \
 <dc:title />\x0a  \
    </cc:Work>\x0a \
   </rdf:RDF>\x0a  \
</metadata>\x0a  <d\
efs\x0a     id=\x22def\
s6\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview4\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x221.2291667\x22\x0a   \
  inkscape:cx=\x22-\
328.06314\x22\x0a     \
inkscape:cy=\x2296.\
000009\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
g820\x22 />\x0a  <path\
\x0a     style=\x22fil\
l:#999999;stroke\
-width:1.3333333\
7\x22\x0a     d=\x22m 53.\
118644,179.49816\
 c -1.46666,-0.6\
2009 -4.16666,-2\
.7414 -6,-4.7140\
1 l -3.33333,-3.\
58656 V 108.6639\
8 46.130379 l 4.\
35897,-4.358975 \
4.35898,-4.35897\
4 h 50.615376 50\
.61539 l 4.35897\
,4.358974 4.3589\
7,4.358975 v 62.\
615381 62.61539 \
l -4.35758,4.358\
97 -4.3576,4.358\
97 -48.97574,0.2\
7327 c -26.93665\
6,0.15029 -50.17\
5736,-0.23409 -5\
1.642406,-0.8542\
 z m 93.999996,-\
70.7524 V 52.745\
763 h -44 -43.99\
9996 v 55.999997\
 56 h 43.999996 \
44 z M 11.412064\
,73.437035 l 0.3\
7325,-59.308728 \
4.35767,-4.35793\
95 4.35768,-4.35\
79381 51.30899,-\
0.3786652 51.308\
986,-0.3786654 v\
 8.0453322 8.045\
332 h -47.999996\
 -48 v 56 55.999\
997 h -8.03992 -\
8.03991 z\x22\x0a     \
id=\x22path817\x22\x0a   \
  inkscape:conne\
ctor-curvature=\x22\
0\x22 />\x0a  <g\x0a     \
id=\x22g820\x22\x0a     t\
ransform=\x22matrix\
(-4,0,0,-4,-202.\
16948,208.67797)\
\x22>\x0a    <path\x0a   \
    id=\x22path2\x22\x0a \
      d=\x22M 0,0 H\
 48 V 48 H 0 Z\x22\x0a\
       inkscape:\
connector-curvat\
ure=\x220\x22\x0a       s\
tyle=\x22fill:none\x22\
 />\x0a    <path\x0a  \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a       id=\
\x22path4489\x22\x0a     \
  d=\x22m -82.71455\
9,29.629973 13.0\
37829,0.118525 -\
6.755966,-11.496\
992 z\x22\x0a       st\
yle=\x22fill:#37c8a\
b;fill-rule:even\
odd;stroke:#37c8\
ab;stroke-width:\
1.16550279;strok\
e-linecap:butt;s\
troke-linejoin:r\
ound;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1\x22\
 />\x0a  </g>\x0a</svg\
>\x0a\
\x00\x00\x09\xf5\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22a\
uto-link.svg\x22\x0a  \
 inkscape:versio\
n=\x220.92.3 (24055\
46, 2018-03-11)\x22\
>\x0a  <metadata\x0a  \
   id=\x22metadata8\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a       \
 <dc:title />\x0a  \
    </cc:Work>\x0a \
   </rdf:RDF>\x0a  \
</metadata>\x0a  <d\
efs\x0a     id=\x22def\
s6\x22 />\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview4\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x221.2291667\x22\x0a   \
  inkscape:cx=\x22-\
47.999998\x22\x0a     \
inkscape:cy=\x2296.\
000006\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
svg2\x22 />\x0a  <rect\
\x0a     style=\x22opa\
city:1;fill:#416\
9e1;fill-opacity\
:1;stroke:#fffff\
f;stroke-width:0\
.37795275;stroke\
-linecap:round;s\
troke-linejoin:b\
evel;stroke-mite\
rlimit:4;stroke-\
dasharray:none;s\
troke-opacity:1;\
paint-order:norm\
al\x22\x0a     id=\x22rec\
t812\x22\x0a     width\
=\x2243.118645\x22\x0a   \
  height=\x2241.491\
524\x22\x0a     x=\x223.2\
542515\x22\x0a     y=\x22\
64.271187\x22 />\x0a  \
<rect\x0a     style\
=\x22opacity:1;fill\
:#20b2aa;fill-op\
acity:1;stroke:#\
ffffff;stroke-wi\
dth:0.37795275;s\
troke-linecap:ro\
und;stroke-linej\
oin:bevel;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1;paint-order\
:normal\x22\x0a     id\
=\x22rect812-3\x22\x0a   \
  width=\x2243.1186\
45\x22\x0a     height=\
\x2241.491524\x22\x0a    \
 x=\x22143.59323\x22\x0a \
    y=\x2295.593224\
\x22 />\x0a  <path\x0a   \
  style=\x22fill:no\
ne;fill-rule:eve\
nodd;stroke:#808\
080;stroke-width\
:5;stroke-lineca\
p:butt;stroke-li\
nejoin:miter;str\
oke-opacity:1;st\
roke-miterlimit:\
4;stroke-dasharr\
ay:none\x22\x0a     d=\
\x22M 45.567915,84.\
669386 C 86.1170\
49,90.694019 75.\
819334,114.3278 \
144.00233,116.27\
913\x22\x0a     id=\x22pa\
th829\x22\x0a     inks\
cape:connector-c\
urvature=\x220\x22\x0a   \
  sodipodi:nodet\
ypes=\x22cc\x22 />\x0a</s\
vg>\x0a\
\x00\x00\x08K\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22d\
elete.svg\x22\x0a   in\
kscape:version=\x22\
0.92.2 (5c3e80d,\
 2017-08-06)\x22>\x0a \
 <metadata\x0a     \
id=\x22metadata8\x22>\x0a\
    <rdf:RDF>\x0a  \
    <cc:Work\x0a   \
      rdf:about=\
\x22\x22>\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0a        <dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0a        <d\
c:title />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs6\x22\
 />\x0a  <sodipodi:\
namedview\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#666666\x22\x0a  \
   borderopacity\
=\x221\x22\x0a     object\
tolerance=\x2210\x22\x0a \
    gridtoleranc\
e=\x2210\x22\x0a     guid\
etolerance=\x2210\x22\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0a  \
   inkscape:page\
shadow=\x222\x22\x0a     \
inkscape:window-\
width=\x22784\x22\x0a    \
 inkscape:window\
-height=\x22480\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0a     ink\
scape:cx=\x22-47.99\
9997\x22\x0a     inksc\
ape:cy=\x2296.00000\
3\x22\x0a     inkscape\
:window-x=\x2257\x22\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0a     \
inkscape:window-\
maximized=\x220\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <path\x0a    \
 style=\x22fill:#99\
9999;stroke-widt\
h:1.33333337\x22\x0a  \
   d=\x22M 44.01994\
,147.1665 38.367\
572,141.51412 60\
.68885,119.16384\
 83.010129,96.81\
3559 60.68885,74\
.463272 38.36757\
2,52.112986 44.0\
1994,46.460618 4\
9.672308,40.8082\
5 72.022594,63.1\
29528 94.372885,\
85.450807 116.72\
318,63.129528 13\
9.07346,40.80825\
 l 5.65238,5.652\
368 5.65236,5.65\
2368 -22.32128,2\
2.350286 -22.321\
28,22.350287 22.\
32128,22.350281 \
22.32128,22.3502\
8 -5.65236,5.652\
38 -5.65238,5.65\
236 -22.35028,-2\
2.32128 -22.3502\
95,-22.32127 -22\
.350291,22.32127\
 -22.350286,22.3\
2128 z\x22\x0a     id=\
\x22path817\x22\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22 \
/>\x0a</svg>\x0a\
\x00\x00\x0a\xef\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22i\
mport_profiles.s\
vg\x22\x0a   inkscape:\
version=\x220.92.3 \
(2405546, 2018-0\
3-11)\x22>\x0a  <metad\
ata\x0a     id=\x22met\
adata8\x22>\x0a    <rd\
f:RDF>\x0a      <cc\
:Work\x0a         r\
df:about=\x22\x22>\x0a   \
     <dc:format>\
image/svg+xml</d\
c:format>\x0a      \
  <dc:type\x0a     \
      rdf:resour\
ce=\x22http://purl.\
org/dc/dcmitype/\
StillImage\x22 />\x0a \
       <dc:title\
 />\x0a      </cc:W\
ork>\x0a    </rdf:R\
DF>\x0a  </metadata\
>\x0a  <defs\x0a     i\
d=\x22defs6\x22 />\x0a  <\
sodipodi:namedvi\
ew\x0a     pagecolo\
r=\x22#ffffff\x22\x0a    \
 bordercolor=\x22#6\
66666\x22\x0a     bord\
eropacity=\x221\x22\x0a  \
   objecttoleran\
ce=\x2210\x22\x0a     gri\
dtolerance=\x2210\x22\x0a\
     guidetolera\
nce=\x2210\x22\x0a     in\
kscape:pageopaci\
ty=\x220\x22\x0a     inks\
cape:pageshadow=\
\x222\x22\x0a     inkscap\
e:window-width=\x22\
1851\x22\x0a     inksc\
ape:window-heigh\
t=\x221025\x22\x0a     id\
=\x22namedview4\x22\x0a  \
   showgrid=\x22fal\
se\x22\x0a     inkscap\
e:zoom=\x221.229166\
7\x22\x0a     inkscape\
:cx=\x22-346.57627\x22\
\x0a     inkscape:c\
y=\x2296.000009\x22\x0a  \
   inkscape:wind\
ow-x=\x2269\x22\x0a     i\
nkscape:window-y\
=\x2227\x22\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0a     in\
kscape:current-l\
ayer=\x22svg2\x22 />\x0a \
 <g\x0a     id=\x22g83\
5\x22\x0a     transfor\
m=\x22matrix(1.1587\
003,0,0,1.158700\
3,275.47132,85.1\
71948)\x22>\x0a    <pa\
th\x0a       inksca\
pe:connector-cur\
vature=\x220\x22\x0a     \
  id=\x22path817\x22\x0a \
      d=\x22m -218.\
01167,4.573994 0\
.37325,59.308728\
 4.35767,4.35793\
9 4.35768,4.3579\
38 51.30899,0.37\
8665 51.309,0.37\
8666 v -8.045332\
 -8.045332 h -48\
.00001 -48 v -56\
 -55.999998 h -8\
.03992 -8.03991 \
z\x22\x0a       style=\
\x22fill:#999999;st\
roke-width:1.333\
33337\x22 />\x0a    <p\
ath\x0a       inksc\
ape:connector-cu\
rvature=\x220\x22\x0a    \
   id=\x22path817-3\
\x22\x0a       d=\x22m -9\
0.5985,4.5739917\
 -0.37325,59.308\
7243 -4.35767,4.\
35794 -4.35768,4\
.35794 -51.30899\
,0.37867 -51.309\
,0.37866 v -8.04\
533 -8.04533 h 4\
8.00001 48 V 1.2\
652637 -54.73473\
1 h 8.03992 8.03\
991 z\x22\x0a       st\
yle=\x22fill:#99999\
9;stroke-width:1\
.33333337\x22 />\x0a  \
</g>\x0a  <path\x0a   \
  inkscape:conne\
ctor-curvature=\x22\
0\x22\x0a     id=\x22path\
817-5\x22\x0a     d=\x22m\
 61.642009,123.8\
6307 v -5.22167 \
h 36.551624 36.5\
51627 v 5.22167 \
5.22166 H 98.193\
633 61.642009 Z \
M 79.917819,89.4\
87134 62.093068,\
71.646462 h 10.2\
17791 10.21779 V\
 55.981481 40.31\
6499 h 15.664984\
 15.664987 v 15.\
664982 15.664981\
 h 10.21779 10.2\
1778 l -17.82474\
,17.840672 c -9.\
80362,9.812372 -\
18.027727,17.840\
686 -18.275817,1\
7.840686 -0.2480\
82,0 -8.472201,-\
8.028314 -18.275\
814,-17.840686 z\
\x22\x0a     style=\x22fi\
ll:#37c8ab;strok\
e-width:0.870276\
75\x22 />\x0a</svg>\x0a\
\x00\x00\x08\xe8\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22c\
opy.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0a     \
inkscape:window-\
height=\x221025\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0a     ink\
scape:cx=\x22-47.99\
9997\x22\x0a     inksc\
ape:cy=\x2296.00000\
3\x22\x0a     inkscape\
:window-x=\x2257\x22\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <path\x0a    \
 style=\x22fill:#99\
9999;stroke-widt\
h:1.33333337\x22\x0a  \
   d=\x22m 59.62711\
6,180.31172 c -1\
.46666,-0.62009 \
-4.16666,-2.7414\
 -6,-4.71401 l -\
3.33333,-3.58656\
 V 109.47754 46.\
943938 l 4.35897\
,-4.358975 4.358\
98,-4.358974 h 5\
0.615384 50.6153\
9 l 4.35897,4.35\
8974 4.35897,4.3\
58975 v 62.61538\
2 62.61539 l -4.\
35758,4.35897 -4\
.3576,4.35897 -4\
8.97574,0.27327 \
c -26.936664,0.1\
5029 -50.175744,\
-0.23409 -51.642\
414,-0.8542 z m \
94.000004,-70.75\
24 V 53.559322 h\
 -44 -44.000004 \
v 55.999998 56 h\
 44.000004 44 z \
M 17.920536,74.2\
50594 l 0.37325,\
-59.308728 4.357\
67,-4.357939 4.3\
5768,-4.3579383 \
51.30899,-0.3786\
652 51.308994,-0\
.3786654 v 8.045\
3319 8.045332 h \
-48.000004 -48 v\
 56 55.999998 h \
-8.03992 -8.0399\
1 z\x22\x0a     id=\x22pa\
th817\x22\x0a     inks\
cape:connector-c\
urvature=\x220\x22 />\x0a\
</svg>\x0a\
\x00\x00\x0bL\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
id=\x22svg2\x22\x0a   ver\
sion=\x221.1\x22\x0a   in\
kscape:version=\x22\
0.92.4 (unknown)\
\x22\x0a   sodipodi:do\
cname=\x22sigma.svg\
\x22>\x0a  <metadata\x0a \
    id=\x22metadata\
12\x22>\x0a    <rdf:RD\
F>\x0a      <cc:Wor\
k\x0a         rdf:a\
bout=\x22\x22>\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0a        <d\
c:type\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 />\x0a     \
   <dc:title />\x0a\
      </cc:Work>\
\x0a    </rdf:RDF>\x0a\
  </metadata>\x0a  \
<defs\x0a     id=\x22d\
efs10\x22>\x0a    <mar\
ker\x0a       inksc\
ape:stockid=\x22Arr\
ow1Lstart\x22\x0a     \
  orient=\x22auto\x22\x0a\
       refY=\x220.0\
\x22\x0a       refX=\x220\
.0\x22\x0a       id=\x22A\
rrow1Lstart\x22\x0a   \
    style=\x22overf\
low:visible\x22\x0a   \
    inkscape:iss\
tock=\x22true\x22>\x0a   \
   <path\x0a       \
  id=\x22path4598\x22\x0a\
         d=\x22M 0.\
0,0.0 L 5.0,-5.0\
 L -12.5,0.0 L 5\
.0,5.0 L 0.0,0.0\
 z \x22\x0a         st\
yle=\x22fill-rule:e\
venodd;stroke:#0\
00000;stroke-wid\
th:1.0pt\x22\x0a      \
   transform=\x22sc\
ale(0.8) transla\
te(12.5,0)\x22 />\x0a \
   </marker>\x0a  <\
/defs>\x0a  <sodipo\
di:namedview\x0a   \
  pagecolor=\x22#ff\
ffff\x22\x0a     borde\
rcolor=\x22#666666\x22\
\x0a     borderopac\
ity=\x221\x22\x0a     obj\
ecttolerance=\x2210\
\x22\x0a     gridtoler\
ance=\x2210\x22\x0a     g\
uidetolerance=\x221\
0\x22\x0a     inkscape\
:pageopacity=\x220\x22\
\x0a     inkscape:p\
ageshadow=\x222\x22\x0a  \
   inkscape:wind\
ow-width=\x221863\x22\x0a\
     inkscape:wi\
ndow-height=\x22102\
5\x22\x0a     id=\x22name\
dview8\x22\x0a     sho\
wgrid=\x22false\x22\x0a  \
   inkscape:zoom\
=\x222.3901682\x22\x0a   \
  inkscape:cx=\x22-\
111.72336\x22\x0a     \
inkscape:cy=\x2252.\
947194\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
g4544\x22 />\x0a  <g\x0a \
    id=\x22g4150\x22>\x0a\
    <g\x0a       id\
=\x22g4544\x22>\x0a      \
<text\x0a         x\
ml:space=\x22preser\
ve\x22\x0a         sty\
le=\x22font-style:n\
ormal;font-varia\
nt:normal;font-w\
eight:normal;fon\
t-stretch:normal\
;font-size:56.84\
185028px;line-he\
ight:125%;font-f\
amily:'Alte Haas\
 Grotesk';-inksc\
ape-font-specifi\
cation:'Alte Haa\
s Grotesk';lette\
r-spacing:0px;wo\
rd-spacing:0px;f\
ill:#37c8ab;fill\
-opacity:1;strok\
e:none;stroke-wi\
dth:1.42104638px\
;stroke-linecap:\
butt;stroke-line\
join:miter;strok\
e-opacity:1;\x22\x0a  \
       x=\x227.9387\
598\x22\x0a         y=\
\x2238.530277\x22\x0a    \
     id=\x22text843\
\x22><tspan\x0a       \
    sodipodi:rol\
e=\x22line\x22\x0a       \
    id=\x22tspan841\
\x22\x0a           x=\x22\
7.9387598\x22\x0a     \
      y=\x2238.5302\
77\x22\x0a           s\
tyle=\x22font-style\
:normal;font-var\
iant:normal;font\
-weight:normal;f\
ont-stretch:norm\
al;font-family:'\
TeX Gyre Termes \
Math';-inkscape-\
font-specificati\
on:'TeX Gyre Ter\
mes Math';stroke\
-width:1.4210463\
8px;fill:#37c8ab\
;\x22>\xcf\x83</tspan></t\
ext>\x0a    </g>\x0a  \
  <g\x0a       tran\
sform=\x22translate\
(1.0067283,-25.8\
87299)\x22\x0a       i\
d=\x22g4144\x22 />\x0a  <\
/g>\x0a</svg>\x0a\
\x00\x00\x04\x97\
\x00\
\x00\x0f\xfdx\xda\xe5W[o\xdb6\x14~\xcf\xaf\xe0\
\x94\x97\x143)\x92\xa2DI\xb3]`-\x0a\xf4a\
/[\x87=3\x22\x1d\xab\x91D\x83\xa2\xe3\xa4\xbf~\
G\xb2.v.@\xd6\x0e\x03\xda1\x08\xe0s#\xcf\
\xf9\xce\xc7C{\xf9\xf6\xbe\xae\xd0\x9dqmi\x9bU\
\xc0\x08\x0d\x90i\x0a\xab\xcb\xe6f\x15\xfc\xf9\xe9\x03N\
\x03\xd4z\xd5hU\xd9\xc6\xac\x82\xc6\x06o\xd7\x17\xcb\
\x9f0F\xef\x9cQ\xdeht(\xfd\x16}ln\xdb\
B\xed\x0c\xba\xdaz\xbf\xcb\xc3\xf0p8\x90rP\x12\
\xebn\xc27\x08\xe3\xf5\xc5\xc5\xb2\xbd\xbb\xb9@\x08\xc1\
\xb9M\x9b\xebb\x15\x0c\x01\xbb\xbd\xabzG]\x84\xa6\
2\xb5i|\x1b2\xc2\xc2`v/f\xf7\xa2;\xbd\
\xbc3\x85\xadk\xdb\xb4}d\xd3^\x9e8;\xbd\x99\
\xbc\xbbl\x0eQ\xef\xc4\xb2,\x0b)\x0f9\xc7\xe0\x81\
\xdb\x87\xc6\xab{|\x1e\x0a9>\x17\xca)\xa5!\xd8\
f\xcf\xd7y\xe5-\x00\xba\x83\xff\xc9}T\x90\xd6\xee\
]a6\x10gHc|\xf8\xfe\xd3\xfb\xc9\x88)\xd1\
^\x9fl3\xe2yv\xea\x19\xc8\x8d\xaaM\xbbS\x85\
i\xc3Q\xdf\xc7\x9ft\x98\xf5\x8aR\xaf\x02\xc8\x91\xf7\
\xc2\xa1\xd4~\x0b\xb6\xec(nMy\xb3\xf5\xb3|W\
\x9a\xc3\xaf\xf6~\x15PD\x11(\xd1h\x18\x13\xcd\xb5\
-\xba\x93WA\x05\xa7bo\xb1\xaa*2B0&\
\x92OIP\x92q\x12\xa1+.h\x1c\x8bd\x818\
e)\xa6\x11f\xecM\xb0\x86\x98em\xbc\xd2\xca\xab\
.\xfe\x98\xec\xa8I{\x07p\x81\xe6\xe5\xbf\xbf\xffp\
\x94@.\x8a\xfc/\xebn\x07\x11V\xe7\xa0\xae\xed\x1e\
*\x09\xd6\x93z\xa9\x8b\x1c\xe0\xae\x95_\x97\xb5\xba1\
]\xa7~\x06x\x97\xe1l8s\xf6\x0f;3oz\
\xdc\xd6\x99c\xdf\x9e%\xaf.\xea\xb2\x0b\x0a\xff\xf0e\
U}\xec\x0e\x09P\xf8h\xd3\xd2Wf\xdd\x9fy\xfc\
8V\x11\x0ee\x0cE\x86'U.\xc3\x11\x83^\xd2\
f\xd3\xce\xf0tR2\x1c\xb3\x9c\xfa\xd25Ew\xed\
;:\xee \x95\xc2V\xd6\xad\x82\xcbM\xbf\x82\xa3\xe1\
\xda:m\xdchJ\xfauf\xb2\xc0)(\x0a81\
\xa8\xed\xf5gSxo+\xe3T\xd3\x01\xc1\xe8`\xb9\
q\xc0\xa6\xe7\xf4\xfbR\x9b\xe7\x0c\x13?\xba\xf4\xa6\x83\
\x9e\xb5\xb6[\xa5\xeda\x15\xf0\xc7\xc6C\xd9\x80\x01\x8f\
DN\x93\xe8\x05\x8f\x89\xdb\x94\xc7\xc1\x0c\xdf\x04\x94\x18\
\x94\xed\xd6\x1e\xbaJV\xc1FU\xady\xbc\xdb\x17k\
\xeb\xee2q\x9e\xb1$\x91\x8f\xcd\x05\x5c\x16,$\xc9\
\xba\x95>\xb1ByYBh\xb7\x92\x17\xf2\x84\x0db\
\xf9\x82\x0d\xc2\xf9K\xb6Z\xdd\x97u\xf9\xc5\xe8\xb9U\
\xf3\xb9{\xe7`\xaa\xe2J=\x187\x5c\xff\x811\x0e\
\x9a9\x14\xee\x1f*\xe8\xce\xd0\x87\x9c\xfd\xb2\x01\x12\xe7\
\x97\x9c^s\xa5z\x01\xcf\xb6\xd6;{k\xf2\x81L\
\x83x\xecBNI$e\x16s\x19\x8fz\x18\x0e\x06\
\x12\xc9\x9d\xdd7\xfaT\xf9\xd9\x96M~m\xeeL5\
j\xe1\x06\x19WA%>\x17\xa3N+h\xbfs\xea\
!o\xe0)\x1a\xb5s2;UBq=]\xc1\x03\
.ru\xd2\xe0\xae\xc0\x94\x8d\xbc\x19x\x22\x22\xc2\x80\
+bd\xc2H\x0e\xc1\x88\xc8X\xccG2t\xddd\
\xa9$1\x8f\xc5\xa8{\xe8t\x1c\x1c\x19M\xc7fx\
\xa0v\xdb\xcd\x10\x00\xb7P\x95\xb9\xc20\xcf^\x8b\xb0\
`If\xd8w\x8f0\x8e\xbe\x1ec\xb81\xbdkv\
\x82qF\x09M\xd3\x94g\xaf\xc0x\xa7\xfc\xf6\x0c\xe3\
\x1e\xd9\xbe\x96\x1eV\xb7\xafL\x0e 4V\xeb\x09\xd9\
\x94v\x7f\xe7\xc8>\x01\xf4z\xef\xfd\x13<{\x08\xff\
9\x9e\x9d\xd6n6\xad\xf19}\x82\xf1P%\xe0\xf9\
\x1bb\x22&\x9c1)\x17\x8c\xc273\xc6\x13\x89\xde\
!F\x05I\x12\x9e\x88E&H\x96\xa64\x8a\x10c\
\xf01\xa1Q\xbc\x90\x8cD\xb1\xe01G\x22!R\xca\
(\x96\x8b$#\x82\xf2\x8c\xf3\x93nuP\xcd\xa0\xce\
#\xc26P\xb0\xb7\x0e\xc3\xb0\xb8S~\xef\xcc<\x8a\
\xe7g\xc5\xc2$\x87\x17\x0e\xbe\xfe\x14\xc5\xab\x09N\x8f\
@\x7f\xf7\x04O\xbem\x88\xd0\x84\xb1\x13~')\xa1\
\x5c\x8a\xe9\xbd\xfd\xdf\xf0\xbb\x06~\x0b\x22\x85\x14\xd1\x02\
.~\x02\x04M8*\x10\x16\x94\xc4\x80\x5c\xb4\xc0\xf0\
Fr\x91D\x08\xf3\x8c\xc8T\xd2t\xc1#\x22\xb9\xc8\
2\x843x]%\xa52Z\xc0\x10\x06\x9eO\x00\x9e\
\xb0\x1b\xcb\xff\x92\xdf\x82\x1a\xaa\x7f\x00~\xc7\xdf\xcco\
\x9a\x9e>\x92\x92C\xa7`b\xfd0\x04\x7faX\x8f\
d\x06LH,S\xc1\x87a\xcd\xb2\x14\x940\x8e\xe3\
8\x92\xd9\xd7\xcfj\x1c\xfd[l^v?z\xd6\x17\
\x7f\x03\xa6\xde\xdc\xcb\
\x00\x00\x08\xea\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22m\
ultiply.svg\x22\x0a   \
inkscape:version\
=\x220.92.3 (240554\
6, 2018-03-11)\x22>\
\x0a  <metadata\x0a   \
  id=\x22metadata8\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a        \
<dc:title />\x0a   \
   </cc:Work>\x0a  \
  </rdf:RDF>\x0a  <\
/metadata>\x0a  <de\
fs\x0a     id=\x22defs\
6\x22 />\x0a  <sodipod\
i:namedview\x0a    \
 pagecolor=\x22#fff\
fff\x22\x0a     border\
color=\x22#666666\x22\x0a\
     borderopaci\
ty=\x221\x22\x0a     obje\
cttolerance=\x2210\x22\
\x0a     gridtolera\
nce=\x2210\x22\x0a     gu\
idetolerance=\x2210\
\x22\x0a     inkscape:\
pageopacity=\x220\x22\x0a\
     inkscape:pa\
geshadow=\x222\x22\x0a   \
  inkscape:windo\
w-width=\x221851\x22\x0a \
    inkscape:win\
dow-height=\x22998\x22\
\x0a     id=\x22namedv\
iew4\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
1.7383042\x22\x0a     \
inkscape:cx=\x22-74\
.178672\x22\x0a     in\
kscape:cy=\x22209.4\
4504\x22\x0a     inksc\
ape:window-x=\x2269\
\x22\x0a     inkscape:\
window-y=\x2227\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22g8\
31\x22 />\x0a  <g\x0a    \
 id=\x22g831\x22\x0a     \
style=\x22stroke:#b\
3b3b3;stroke-lin\
ecap:round\x22>\x0a   \
 <path\x0a       so\
dipodi:nodetypes\
=\x22cc\x22\x0a       ink\
scape:connector-\
curvature=\x220\x22\x0a  \
     id=\x22path812\
-3\x22\x0a       d=\x22M \
128.27157,122.07\
037 71.060637,66\
.445036\x22\x0a       \
style=\x22fill:none\
;fill-rule:eveno\
dd;stroke:#b3b3b\
3;stroke-width:1\
6;stroke-linecap\
:round;stroke-li\
nejoin:miter;str\
oke-miterlimit:4\
;stroke-dasharra\
y:none;stroke-op\
acity:1\x22 />\x0a    \
<path\x0a       sod\
ipodi:nodetypes=\
\x22cc\x22\x0a       inks\
cape:connector-c\
urvature=\x220\x22\x0a   \
    id=\x22path812-\
3-3\x22\x0a       d=\x22M\
 71.065141,122.0\
75 128.26707,66.\
440407\x22\x0a       s\
tyle=\x22fill:none;\
fill-rule:evenod\
d;stroke:#b3b3b3\
;stroke-width:16\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22 />\x0a  </g\
>\x0a</svg>\x0a\
\x00\x00\x04\x97\
\x00\
\x00\x0f\x88x\xda\xd5W[o\xdb6\x14~\xcf\xaf\xe0\
\xd4\x97\x16\xb3(\xdet\xa1f\xbb\xc0Z\x14\xe8\xc3^\
\xb6\x0e{\xa6E:V+\x89\x06E\xc7I\x7f\xfd\x8e\
d]\xec\xc4\x19\x82u\x18Z\x06\x01rn<\xe7|\
\xe7#\xa9,\xdf\xde\xd7\x15\xba3\xae-m\xb3\x0a(\
&\x012Mau\xd9\xdc\xae\x82??}\x08\xb3\x00\
\xb5^5ZU\xb61\xab\xa0\xb1\xc1\xdb\xf5\xcd\xf2\xa7\
0D\xef\x9cQ\xdeht,\xfd\x0e}l\xbe\xb4\x85\
\xda\x1b\xf4z\xe7\xfd>\x8f\xa2\xe3\xf1\x88\xcbA\x89\xad\
\xbb\x8d\xde\xa00\x5c\xdf\xdc,\xdb\xbb\xdb\x1b\x84\x10\xe4\
m\xda\x5c\x17\xab`\x08\xd8\x1f\x5c\xd5;\xea\x222\x95\
\xa9M\xe3\xdb\x88b\x1a\x05\xb3{1\xbb\x17]\xf6\xf2\
\xce\x14\xb6\xaem\xd3\xf6\x91M\xfb\xea\xcc\xd9\xe9\xed\xe4\
\xddUs\xe4\xbd\x13\x95RF\x84E\x8c\x85\xe0\x11\xb6\
\x0f\x8dW\xf7\xe1e(\xd4x-\x94\x11B\x22\xb0\xcd\
\x9e/\xf3\xca[\x00t\x0f\xbf\x93\xfb\xa8\xc0\xad=\xb8\
\xc2l!\xce\xe0\xc6\xf8\xe8\xfd\xa7\xf7\x931$X{\
}\xb6\xcd\x88\xe7E\xd6\x0b\x90\x1bU\x9bv\xaf\x0a\xd3\
F\xa3\xbe\x8f?\x9b0\xed\x15\xa5^\x05P#\xeb\x85\
c\xa9\xfd\x0el\xf2$\xeeLy\xbb\xf3\xb3|W\x9a\
\xe3\xaf\xf6~\x15\x10D\x10(\xd1h\x18\x0b\xcd\xb5-\
\xba\xcc\xab@\x1d\xbc\x0d+H\x1d\xbaF\xe3\x11\x84\xb1\
\x94|*\x83`\xc90G\xaf\x99 q,\x92\x05b\
\x84f!\xe1!\xa5o\x825\xc4,k\xe3\x95V^\
u\xf1\xa7rGM\xd6;\x80\x0b\x8c/\xff\xfd\xfd\x87\
\x93\x04rQ\xe4\x7fY\xf7e\x10au\x0ejc\x0f\
\xd0K\xb0\x9e\xd4K]\xe4\x00x\xad\xfc\xba\xac\xd5\xad\
\xe9f\xf53\x00\xbc\x8cf\xc3\x85\xb3\x7f\xd8\x9by\xd3\
\xd3\xb6\xce\x9c&w\x95\xbe\xba\xa8\xcb.(\xfa\xc3\x97\
U\xf5\xb1K\x12\xa0\xe8\xd1\xa6\xa5\xaf\xcc\xba\xcfy\xfa\
s\xec\x22\x1a\xda\x18\x9a\x8c\xce\xba\x5cF#\x06\xbd\xa4\
\xcd\xb6\x9d\xe1\xe9\xa4dH\xb3\x9c&\xd3\x8dEw\x03\
<9\xee\xa1\x94\xc2V\xd6\xad\x82W\xdb~\x05'\xc3\
\xc6:m\xdchJ\xfaua\xb2\xc0*h\x0aX1\
\xa8\xed\xe6\xb3)\xbc\xb7\x95q\xaa\xe9\x80\xa0d\xb0\xdc\
:\xe0\xd35\xfd\xa1\xd4\xe6\x9aa\xe2GW\xde\x94\xe8\
\xaa\xb5\xdd)m\x8f\xab\x80=6\x1e\xcb\x06\x0c\xe1H\
\xe5,\xe1\xcfxL\xec&,\x0ef\xf8&\xa0\xc4\xa0\
lw\xf6\xd8u\xb2\x0a\xb6\xaaj\xcd\xe3\xdd\xbeZ[\
w\xc7\x891I\x93$}l.\xe0\xb8\x84\x22\xc5\xb2\
[\xd9\x13+\xb4'\x13L\xba\x95<S'l\x10\xa7\
\xcf\xd8 \x9c=g\xab\xd5}Y\x97_\x8d\x9eG5\
\xe7=8\x07\xf7jX\xa9\x07\xe3\x86\x0b``\x8c\x83\
a\x0e\x8d\xfb\x87\x0a\xa63\xcc!\xa7\xbfl\x81\xc4\xf9\
\xabD\xc8\xd8\xe8^\x08g[\xeb\x9d\xfdb\xf2\x81L\
\x83x\x9aBN0OS\x19\xb34\x1e\xf5p3\x18\
($w\xf6\xd0\xe8s\xe5g[6\xf9\xc6\xdc\x99j\
\xd4\xc2\x092\xae\x82N|.F\x9dV0~\xe7\xd4\
C\xde\xc0c4j\xe7b\xf6\xaa\x84\xe6z\xba\x82\x07\
\x1c\xe4\xeal\xc0]\x83\x19\x1dy3\xf0DpL\x81\
+bd\xc2H\x0eA\xb1\x904f#\x19`\x18\x1c\
\xb3X\xb0\x98\x8e\xae0\x83D`\x96B|\xfab\x10\
\x19\xd90\xa5~x\x10C\xfe\xafa\xa4\xe0\x1bK\xce\
\xf8\x0c\xa3\x8c{\x0dx\x0d0\xee\x95\xdf]\xc0\xd8\x83\
\xd7\x97\xdb#\xe7\x0e\x95\xc9\xa1\xcf\xc6j=\x81\x97\x91\
\xee\xe7\x12\xbc'\x98m\x0e\xde?\x81\xacG\xe9)\x10\
/\xc20^\xc4\xe7J\xbb\xdd\xb6\xc6\xe7\xe3\xd5\x05\x88\
\xfd\x86\x04\xb4\x97\xa4\x00\xc3\x22\x138I$\xcf\x12\xf4\
\x0ee\x09@\x96\x12!\x17\x92\xe0D\x0aB%Jc\
\x9cQ\xc9\xb9XP*0gi\x86\xa8\x10pM0\
\xceA\x95\x00\xdb$\xe5g\xe3\xe8\x80\xca\x98|r\xcc\
m\x03\xedz\xebB8\xf0w\xca\x1f\x9c\x99\xaf\xd3\xf9\
i\xb0p\x1b\xc3+\x05\x1f1E\xf1b\x06\x13\xb2\xe9\
8\xfa\xc338\xf9\x86\x8b \xa5Y,\xc9\xd9E\x00\
\x93\xc4I,b\xf9=0\xf8\xc5\x84}B\xf5\xeb\x0c\
\xae\x91\x80\xa7\x0a\xceg\x1c/(\xcf0\x81QJT\
 Ap\x0c\xd8\x00[\xc1\xccD\xc2\x11\x938\xcdR\
\x92\xcaE\xc8\x00%&\xa4D\x12\xde\xc0\x94\x904\x06\
\x1d\xc5i\xca\xa7\xef\x8a3\x02\x87\xe9\xffIaA\x13\
i\xe8\x8fO\xe1\xf8[)<\xa9:\x0a3\x9c\x92X\
p\xfe\xfdS\xf8*d\xd7\xf8*\x16\x1c0!<\xe1\
\xc9?\xf15\x93\x8b\xac\xfb\x90\x03^\x88\x89\xaf\xc9\x22\
\x83\xd8\x14\x22\xc4\x15\xbe\xf2\xff\x8a\xaf\xcb\xee\xbf\x8f\xf5\
\xcd\xdf\xf0\xb6\xbc\x10\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x08\
\x0b\x85Wg\
\x00g\
\x00e\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x15\
\x01uN\xa7\
\x00l\
\x00i\x00n\x00k\x00-\x00t\x00o\x00-\x00s\x00e\x00l\x00e\x00c\x00t\x00i\x00o\x00n\
\x00.\x00s\x00v\x00g\
\x00\x0d\
\x02.\xca\x07\
\x00c\
\x00o\x00p\x00y\x002\x00d\x00o\x00w\x00n\x00.\x00s\x00v\x00g\
\x00\x0d\
\x01\xdc\x10\xc7\
\x00a\
\x00u\x00t\x00o\x00-\x00l\x00i\x00n\x00k\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x13\
\x0f-z\xc7\
\x00i\
\x00m\x00p\x00o\x00r\x00t\x00_\x00p\x00r\x00o\x00f\x00i\x00l\x00e\x00s\x00.\x00s\
\x00v\x00g\
\x00\x08\
\x06|W\x87\
\x00c\
\x00o\x00p\x00y\x00.\x00s\x00v\x00g\
\x00\x09\
\x0e4\xa9'\
\x00s\
\x00i\x00g\x00m\x00a\x00.\x00s\x00v\x00g\
\x00\x0f\
\x01\xe7\xeaG\
\x00l\
\x00i\x00n\x00k\x00-\x00t\x00o\x00-\x00a\x00l\x00l\x00.\x00s\x00v\x00g\
\x00\x0c\
\x09\xa4,\xc7\
\x00m\
\x00u\x00l\x00t\x00i\x00p\x00l\x00y\x00.\x00s\x00v\x00g\
\x00\x11\
\x03D\xe2\xc7\
\x00a\
\x00u\x00t\x00o\x00-\x00l\x00i\x00n\x00k\x00-\x00r\x00n\x00d\x00.\x00s\x00v\x00g\
\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x0b\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x006\x00\x01\x00\x00\x00\x01\x00\x00\x0d^\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00\x86\x00\x00\x00\x00\x00\x01\x00\x00\x1d\x16\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01\x1a\x00\x01\x00\x00\x00\x01\x00\x00N\x8d\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00f\x00\x00\x00\x00\x00\x01\x00\x00\x11\xff\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01\x5c\x00\x01\x00\x00\x00\x01\x00\x00\x5c\x16\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00\xec\x00\x00\x00\x00\x00\x01\x00\x00:Q\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01>\x00\x00\x00\x00\x00\x01\x00\x00S(\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00\xa6\x00\x00\x00\x00\x00\x01\x00\x00'\x0f\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x01\x02\x00\x00\x00\x00\x00\x01\x00\x00C=\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00\xc0\x00\x00\x00\x00\x00\x01\x00\x00/^\
\x00\x00\x01\x88\xae\xf9[-\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
