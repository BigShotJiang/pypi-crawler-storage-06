# How to install Uxarray

Please see our
[Uxarray Installation](https://uxarray.readthedocs.io/en/latest/getting-started/installation.html)
instructions for detailed information!
