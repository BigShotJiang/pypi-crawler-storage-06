# tgedr-dataops

[[_TOC_]]


## development

Clone the repository like this:

``` bash
git clone git@github.com:jtviegas/dataops
```

Open VSCode in the repository folder

