"""Language parsers for MCP Vector Search."""
