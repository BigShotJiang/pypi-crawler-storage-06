# util/qnvip_tools.py
import os
from typing import Annotated

import requests
from fastmcp import Context


async def content(
    query: Annotated[str, '查询内容'],
    ctx: Context
) -> str:
    """
     搜索查询公司文档，代码规范，技术文档，需求文档，周报，日报，代码
     """
    # 先从环境变量读取，读不到再从request_context读取
    token = os.environ.get('PERSONAL_AUTHORIZATION') or ctx.request_context.request.headers.get('personal-authorization')
    headers = {
        "Authorization": f"Bearer {os.environ.get('DIFY_API_KEY', 'app-qWKYM3MWAaJR9PGTAL3y69Lt')}",
        "Content-Type": "application/json",
        "PersonalAuthorization": token,  # 来自客户端配置
    }

    payload = {
        "inputs": {"personal_token": token},
        "query": query,
        "response_mode": "blocking",
        "conversation_id": "",
        "user": token
    }

    response = requests.post(os.environ.get('DIFY_API_URL', "https://ai.qnvip.com/v1/chat-messages"), headers=headers, json=payload, timeout=None)
    response.raise_for_status()

    response_data = response.json()
    return response_data.get("answer", "响应数据为空")
