from gooddata_api_client.paths.api_v1_entities_color_palettes.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_color_palettes.post import ApiForpost


class ApiV1EntitiesColorPalettes(
    ApiForget,
    ApiForpost,
):
    pass
