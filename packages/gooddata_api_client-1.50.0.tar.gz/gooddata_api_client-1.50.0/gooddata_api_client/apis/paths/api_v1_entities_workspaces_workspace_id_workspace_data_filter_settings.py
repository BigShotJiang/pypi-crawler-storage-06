from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_workspace_data_filter_settings.get import ApiForget


class ApiV1EntitiesWorkspacesWorkspaceIdWorkspaceDataFilterSettings(
    ApiForget,
):
    pass
