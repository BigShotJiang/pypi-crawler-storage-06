from gooddata_api_client.paths.api_v1_entities_users_user_id_api_tokens.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_users_user_id_api_tokens.post import ApiForpost


class ApiV1EntitiesUsersUserIdApiTokens(
    ApiForget,
    ApiForpost,
):
    pass
