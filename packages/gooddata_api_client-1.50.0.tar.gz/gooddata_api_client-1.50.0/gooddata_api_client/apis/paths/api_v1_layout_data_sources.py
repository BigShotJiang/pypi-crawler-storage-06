from gooddata_api_client.paths.api_v1_layout_data_sources.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_data_sources.put import ApiForput


class ApiV1LayoutDataSources(
    ApiForget,
    ApiForput,
):
    pass
