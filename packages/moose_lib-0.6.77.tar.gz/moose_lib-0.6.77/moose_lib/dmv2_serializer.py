from .internal import load_models

load_models()
