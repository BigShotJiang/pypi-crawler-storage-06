from enum import IntEnum, auto


class Representations(IntEnum):
    BODY_FIXED_REPRESENTATION = auto()
    MIXED_REPRESENTATION = auto()
