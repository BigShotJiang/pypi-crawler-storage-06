adam.parametric.numpy package
=============================

Submodules
----------

adam.parametric.numpy.computations\_parametric module
-----------------------------------------------------

.. automodule:: adam.parametric.numpy.computations_parametric
   :members:
   :undoc-members:
   :show-inheritance:
