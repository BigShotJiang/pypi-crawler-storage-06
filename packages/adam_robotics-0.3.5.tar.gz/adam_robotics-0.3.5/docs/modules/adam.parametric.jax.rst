adam.parametric.jax package
===========================

Submodules
----------

adam.parametric.jax.computations\_parametric module
---------------------------------------------------

.. automodule:: adam.parametric.jax.computations_parametric
   :members:
   :undoc-members:
   :show-inheritance:
