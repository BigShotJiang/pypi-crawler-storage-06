CasADi interface
===================

This module provides an interface to CasADi, a symbolic framework for automatic differentiation and optimization.

----------------

.. currentmodule:: adam.casadi

.. automodule:: adam.casadi.computations
   :members:
   :undoc-members:
   :show-inheritance:
