NumPy
==================

This module provides the NumPy implementation of the Rigid Body Dynamics algorithms.

----------------

.. currentmodule:: adam.numpy

.. automodule:: adam.numpy.computations
   :members:
   :undoc-members:
   :show-inheritance:
