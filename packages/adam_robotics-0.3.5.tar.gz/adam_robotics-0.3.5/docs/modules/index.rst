Modules
==========

This section contains the documentation for the different modules of the library.

.. _modules:

.. toctree::
    :maxdepth: 2

    casadi
    jax
    pytorch
    pytorch_batched
    numpy
    model
    model.conversions
    adam.parametric
