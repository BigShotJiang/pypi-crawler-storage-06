Quickstart
===========

This section contains some snippets of code that show how to use the library.

.. _quickstart:

.. toctree::
    :maxdepth: 2

    casadi
    jax
    pytorch
    pytorch_batched
