import numpy as np
import numpy.typing as npt

ImageType = npt.NDArray[np.floating | np.integer]
