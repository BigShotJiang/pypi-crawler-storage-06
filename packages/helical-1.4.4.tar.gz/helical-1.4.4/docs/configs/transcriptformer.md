::: helical.models.transcriptformer.TranscriptFormerConfig
    handler: python
    options:
      show_root_heading: True
      show_source: True