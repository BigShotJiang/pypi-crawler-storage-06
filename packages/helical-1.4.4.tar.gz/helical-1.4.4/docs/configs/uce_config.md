::: helical.models.uce.UCEConfig
    handler: python
    options:
      show_root_heading: True
      show_source: True