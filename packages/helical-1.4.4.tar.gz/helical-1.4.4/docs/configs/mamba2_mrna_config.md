::: helical.models.mamba2_mrna.Mamba2mRNAConfig
    handler: python
    options:
      show_root_heading: True
      show_source: True