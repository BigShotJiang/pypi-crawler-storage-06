::: helical.models.geneformer.GeneformerConfig
    handler: python
    options:
      show_root_heading: True
      show_source: True