::: helical.models.evo_2.Evo2Config
    handler: python
    options:
      show_root_heading: True
      show_source: True