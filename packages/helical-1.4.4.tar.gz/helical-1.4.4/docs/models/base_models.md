::: helical.models.base_models.HelicalBaseFoundationModel
    handler: python
    options:
      show_root_heading: True
      show_source: True
::: helical.models.base_models.HelicalRNAModel
    handler: python
    options:
      show_root_heading: True
      show_source: True
::: helical.models.base_models.HelicalDNAModel
    handler: python
    options:
      show_root_heading: True
      show_source: True
::: helical.models.base_models.HelicalBaseFineTuningModel
    handler: python
    options:
      show_root_heading: True
      show_source: True
::: helical.models.base_models.HelicalBaseFineTuningHead
    handler: python
    options:
      show_root_heading: True
      show_source: True
