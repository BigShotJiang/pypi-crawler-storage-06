#!/bin/bash
python3 ci/run_all.py