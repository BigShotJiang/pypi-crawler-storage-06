- Go to "Settings/Technical/Database Structure/Fields Export Anonymize"
- Add the filed to anonymize
- Add users to "Technical Settings / Anonymize data in export" group
- You can customize the displayed string when anonymizing from the
  system parameters.

With a user of "Technical Settings / Anonymize data in export" group,
export the anonymized field.
