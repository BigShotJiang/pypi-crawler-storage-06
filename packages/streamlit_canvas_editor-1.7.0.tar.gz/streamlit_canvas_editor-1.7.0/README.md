# streamlit_canvas_editor

Streamlit component that allows you to do X

## Installation instructions 

```sh
pip install streamlit_canvas_editor
```

## Usage instructions

```python
import streamlit as st

from streamlit_canvas_editor import streamlit_canvas_editor

value = streamlit_canvas_editor()

st.write(value)
