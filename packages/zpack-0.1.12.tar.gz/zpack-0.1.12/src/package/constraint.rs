// pub trait Constraint {
//     fn satisfied(spec: &PackageSpec) -> bool;
// }
