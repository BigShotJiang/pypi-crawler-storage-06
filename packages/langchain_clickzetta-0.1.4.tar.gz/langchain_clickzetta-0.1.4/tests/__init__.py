"""Tests for langchain-clickzetta."""
