# Template Catalog

Copy files from this directory into `.spec-dev/active-dev/` or `.spec-dev/active-memories/`
as needed.

## Active Cycle Templates (`active/`)
| Template | Copy To | Purpose |
|----------|---------|---------|
| `spec-template.md` | `active-spec.md` | Seed for Specify phase.
| `plan-template.md` | `active-plan.md` | Seed for Plan phase.
| `tasks-template.md` | `active-tasks.md` | Seed for Tasks board.
| `implementation-log-template.md` | `active-implementation.md` | Seed for implementation log.

## Memory Templates (`memories/`)
| Template | Purpose |
|----------|---------|
| `task-memory-template.md` | Blank scaffold for new task memories (`T-XXX-memory.md`); keep only the sections that fit. |
| `task-memory-example.md` | Completed example showing a concise, high-signal write-up. |

Guidelines:
1. Copy the template, rename to the canonical filename, and update header metadata.
2. Drop active templates into `.spec-dev/active-dev/` and memory templates into `.spec-dev/active-memories/`.
3. Remove instructional comments as you fill in real content.
4. Leave templates untouched so future cycles start with a clean slate.
