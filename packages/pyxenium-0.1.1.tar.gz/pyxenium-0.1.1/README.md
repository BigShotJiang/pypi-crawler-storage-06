# pyXenium

A toy Python package for analyzing 10x Xenium data.

## Quickstart
```bash
pip install pyXenium
pyXenium demo
```
