```bash
pip install pyXenium
pyXenium demo
```