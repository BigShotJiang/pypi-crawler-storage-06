# Sub-chapter 2 - this time with a longer name

A sample chapter, there's no content here, just a placeholder to demo the navbar.

```{toctree}
chapterpage1.md
chapterpage2.md
chapterpage3.md
```
