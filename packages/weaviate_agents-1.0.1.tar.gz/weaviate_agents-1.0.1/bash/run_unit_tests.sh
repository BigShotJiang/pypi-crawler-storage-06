#!/bin/bash

uv run pytest -v test/
