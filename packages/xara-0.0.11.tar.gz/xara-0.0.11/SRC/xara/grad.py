


def compose(model, loading, output, solve=None, solve_args=None):
    pass
