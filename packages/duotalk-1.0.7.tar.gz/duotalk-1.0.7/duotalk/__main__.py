#!/usr/bin/env python3
"""
DuoTalk CLI Entry Point
"""

if __name__ == "__main__":
    from duotalk.cli.simple import app
    app()
