"""
CLI package exports.
"""

from .main import app

__all__ = ["app"]
