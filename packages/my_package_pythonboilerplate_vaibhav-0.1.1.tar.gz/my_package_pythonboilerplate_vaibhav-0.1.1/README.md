pip install -e ".[dev]"
my-package
pytest
