import importlib.metadata

__version__ = importlib.metadata.version("openeo_processes_dask")
