# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteResourceRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'workspace': 'str',
        'resource_id': 'str'
    }

    attribute_map = {
        'workspace': 'workspace',
        'resource_id': 'resource_id'
    }

    def __init__(self, workspace=None, resource_id=None):
        r"""DeleteResourceRequest

        The model defined in huaweicloud sdk

        :param workspace: 工作空间id
        :type workspace: str
        :param resource_id: 资源id.
        :type resource_id: str
        """
        
        

        self._workspace = None
        self._resource_id = None
        self.discriminator = None

        if workspace is not None:
            self.workspace = workspace
        self.resource_id = resource_id

    @property
    def workspace(self):
        r"""Gets the workspace of this DeleteResourceRequest.

        工作空间id

        :return: The workspace of this DeleteResourceRequest.
        :rtype: str
        """
        return self._workspace

    @workspace.setter
    def workspace(self, workspace):
        r"""Sets the workspace of this DeleteResourceRequest.

        工作空间id

        :param workspace: The workspace of this DeleteResourceRequest.
        :type workspace: str
        """
        self._workspace = workspace

    @property
    def resource_id(self):
        r"""Gets the resource_id of this DeleteResourceRequest.

        资源id.

        :return: The resource_id of this DeleteResourceRequest.
        :rtype: str
        """
        return self._resource_id

    @resource_id.setter
    def resource_id(self, resource_id):
        r"""Sets the resource_id of this DeleteResourceRequest.

        资源id.

        :param resource_id: The resource_id of this DeleteResourceRequest.
        :type resource_id: str
        """
        self._resource_id = resource_id

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteResourceRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
