"""nxtomomill applications"""
