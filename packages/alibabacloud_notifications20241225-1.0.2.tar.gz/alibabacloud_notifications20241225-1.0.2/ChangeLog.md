2025-08-07 Version: 1.0.1
- Update API ReadMessageList: add response parameters Body.Data.Rows.$.Titleh.
- Update API ReadNumGroupTotal: add request parameters Title.


2025-05-20 Version: 1.0.0
- Generated python 2024-12-25 for Notifications.

