<div align="center">
  <a href="https://www.accqsure.ai/"><img src="https://app.accqsure.ai/logo.png"></a><br>
</div>

# AccQsure Python SDK and Command Line Tools

Provides programmatic access to [AccQsure platform](https://app.accqsure.ai).

## Installation

Python 3.10 or above is required.

```
pip install accqsure
```
