from .use_case import Input, Output


async def solution(_: Input) -> Output:
    raise NotImplementedError
