class X10Error(Exception):
    pass
