# vidfilter_scripter

An mpv front-end which creates a mencoder script with video adjustments.

### Usage

Preview the video you wish to reencode, adjusting brightness, contrast, hue,
saturation, and gamma, and when satisfied, click the "Create script" button.
The created menocoder script will be shown with a "Save as" function available
to save it.

