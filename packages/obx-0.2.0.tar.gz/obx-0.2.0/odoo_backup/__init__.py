"""Odoo Backup Tool Package"""
__version__ = "0.2.0"