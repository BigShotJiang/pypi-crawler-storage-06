# Rlooper Simulation Python - Version Information

__version__ = "1.0.6"
__release_date__ = "2025-09-24"
__author__ = "srhartono"
__description__ = "Rlooper with R-loop Peak Simulator (Python Implementation)"

# Version history
CHANGELOG = """
## v1.0.5 (2025-09-23)
- Fixed DAG not being made
- Fixed summary report generation
"""