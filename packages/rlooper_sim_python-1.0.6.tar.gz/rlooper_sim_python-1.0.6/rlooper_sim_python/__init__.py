"""
Rlooper with R-loop Peak Simulator (Python Implementation)

"""

from .version import __version__, __author__, __description__

__all__ = ['__version__', '__author__', '__description__']