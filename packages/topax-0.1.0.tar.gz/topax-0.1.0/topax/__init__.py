
from . import _version
__version__ = _version.get_versions()['version']

from topax._app import show_part
