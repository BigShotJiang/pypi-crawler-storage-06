Not Enough Virtual Stock: \#. Go to *Sales \> Products \> Products*. \#.
Create new storable product without stock available. \#. Go to *Sales \>
Orders \> Quotations* \#. Create new quotation. \#. Add product without
stock available. \#. An exception will be displayed.

No ZIP code on destination: \#. Go to *Contacts*. \#. Edit or create new
contact. \#. Set empty zip code. \#. Go to *Sales \> Orders \>
Quotations* \#. Create new quotation. \#. Set delivery address with no
zip code. \#. An exception will be displayed.

Product warning: \#. Go to *Sales \> Products \> Products*. \#. Edit or
create new product. \#. Go to *Sales* tab. \#. Set your desired warning
option under the *Warning when Selling this Product* group. \#. Set some
warning message. \#. Go to *Sales \> Orders \> Quotations* \#. Create
new quotation. \#. Add product with warning message. \#. An exception
will be displayed.

Partner warning: \#. Go to *Contacts*. \#. Edit or create new contact.
\#. Go to *Internal notes* tab. \#. Set warning option according to
*Warning on the Sales Order* group. \#. Set some warning message. \#. Go
to *Sales \> Orders \> Quotations* \#. Create new quotation. \#. Set
partner with warning message. \#. An exception will be displayed.
