# Stub tiktoken module to satisfy imports
"""
Minimal stub for tiktoken
"""
def get_encoding(name):
    return None
class Encoding:
    pass
class Tokenizer:
    pass