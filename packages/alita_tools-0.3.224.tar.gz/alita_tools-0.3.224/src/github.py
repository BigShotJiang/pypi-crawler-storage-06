"""
Stub module to satisfy imports of PyGithub package
"""
class Auth:
    pass

class Github:
    pass

class GithubIntegration:
    pass

class Repository:
    pass