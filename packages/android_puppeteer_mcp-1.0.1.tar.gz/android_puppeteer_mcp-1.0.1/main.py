def main():
    print("Hello from android-puppeteer!")


if __name__ == "__main__":
    main()
