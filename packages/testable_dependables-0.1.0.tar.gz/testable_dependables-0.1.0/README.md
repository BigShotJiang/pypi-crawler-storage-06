# testable-dependables

`testable-dependables` outputs the testable versions of `Python` for use in a `justfile` or CI/CD workflow instead of hardcoding them. Automatically stay on top of supported Python versions.

It supports modern Python packages that use the [`pyproject.toml`](https://packaging.python.org/en/latest/guides/writing-pyproject-toml/) standard (aka [PEP 621](https://peps.python.org/pep-0621/)).

## Why?

I wanted a command to automatically test all supported Python versions for a library based on its `pyproject.toml` Python requirements, i.e. not hardcoding versions somewhere.

Here's an example `justfile` that utilizes `testable-dependables` and `uv` to run unit tests in isolated environments for each supported Python version.

```
# Run tests across all supported Python versions
test-all-versions:
    #!/usr/bin/env bash
    set -euo pipefail

    for version in $(uvx testable-dependables); do
      echo -e "\n=== Testing with Python $version ==="
      uv run --all-extras --python "$version" pytest
      echo -e "\n=== Tests completed for Python $version ===\n"
    done
    
    echo "All tests completed successfully"
```

## Usage

### `uvx`

`uv` is an extremely fast Python package and project manager, written in Rust. `uvx` is an alias for [`uv tool run ...`](https://docs.astral.sh/uv/concepts/tools/).

1. Install [`uv`](https://docs.astral.sh/uv/getting-started/installation/)
2. Go to a directory with source code for a Python package
3. `uvx testable-dependables`

### `pipx`

`pipx` is a way to run install and run Python applications in isolated environments.

1. Install [`pipx`](https://pipx.pypa.io/latest/installation/)
2. `pipx install testable-dependables`
3. Go to a directory with source code for a Python package
4. `testable-dependables`

### `pip --user`

Install `testable-dependables` to the Python user install directory. More details [in the pip docs](https://pip.pypa.io/en/stable/cli/pip_install/#cmdoption-user).

1. `pip install --user testable-dependables`
2. Go to a directory with source code for a Python package
3. `testable-dependables`

## CLI arguments

### path

`testable-dependables` optionally accepts a path as the first argument. Defaults to `.` for the current directory.

`uvx testable-dependables /path/to/project`

#### --json

Output as `json`.

`uvx troml --json /path/to/project`

#### --verbose

Outputs more verbose information.

`uvx troml --verbose /path/to/project/`

## Development

1. Install `just`: https://just.systems/man/en/packages.html
2. `just fetch`

### Run from source

`uv run testable-dependables [PATH-TO-PYPROJECT-TOML]`

### Commands

- unit tests (via `pytest`): `just test`
- linting (via `ruff`): `just lint`
- type checking (via `mypy`): `just type`
- unit test coverage (via `coverage.py`): `just coverage`
- run 'em all: `just dev`

## Inspiration

- https://indieweb.social/@adamghill/115210565251655417