# -*- coding: utf-8 -*-
from .types.timer import Timer


kbEscTimer = Timer()
msAutoTimer = Timer()
wakeupTimer = Timer()
msDoubleTimer = Timer()
