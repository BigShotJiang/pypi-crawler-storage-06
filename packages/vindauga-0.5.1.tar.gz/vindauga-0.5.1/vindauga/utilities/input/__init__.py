# -*- coding: utf-8 -*-
"""
Input handling utilities package
"""