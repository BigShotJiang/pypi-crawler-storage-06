Integer Cycling
===============

.. admonition:: Get a copy of this example
   :class: hint

   .. code-block:: console

      $ cylc get-resources examples/integer-cycling

.. literalinclude:: flow.cylc
   :language: cylc

Run it with::

   $ cylc vip integer-cycling
