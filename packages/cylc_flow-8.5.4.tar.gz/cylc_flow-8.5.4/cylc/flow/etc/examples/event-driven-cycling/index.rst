Event Driven Cycling
====================

.. admonition:: Get a copy of this example
   :class: hint

   .. code-block:: console

      $ cylc get-resources examples/event-driven-cycling

.. include:: README.rst

.. literalinclude:: flow.cylc
   :language: cylc
