"""Contain the dataclasses, TypedDicts and basic registries of icclim."""
