2023-03-10 Version: 3.0.3
- Update videoseg.

2022-10-17 Version: 3.0.2
- Update videoseg.

2021-03-08 Version: 3.0.1
- Generated python 2020-03-20 for videoseg.

2021-02-01 Version: 3.0.0
- Release SegmentGreenScreenVideo.

2020-12-30 Version: 2.0.0
- AMP Version Change.

