from __future__ import annotations
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray
import pandas as pd
import yaml


@dataclass
class StateData:

    # KMC State
    iteration: NDArray[np.uint64]
    kmc_step: NDArray[np.uint64]
    kmc_time: NDArray[np.float64]
    sim_time: NDArray[np.float64]
    sim_time_per_1e6_steps: NDArray[np.float64]
    NAV: NDArray[np.float64]

    # Species State
    unit_convs: Dict[str, NDArray[np.float64]]
    total_conv: NDArray[np.float64]
    unit_counts: Dict[str, NDArray[np.uint64]]
    polymer_counts: Dict[str, NDArray[np.uint64]]

    # Analysis State
    nAvgCL: NDArray[np.float64]
    wAvgCL: NDArray[np.float64]
    dispCL: NDArray[np.float64]
    nAvgMW: NDArray[np.float64]
    wAvgMW: NDArray[np.float64]
    dispMW: NDArray[np.float64]

    nAvgSL: Dict[str, NDArray[np.float64]]
    wAvgSL: Dict[str, NDArray[np.float64]]
    dispSL: Dict[str, NDArray[np.float64]]

    _raw_data: pd.DataFrame

    @staticmethod
    def from_csv(filepath: Path | str, metadata: Metadata) -> StateData:

        df = pd.read_csv(filepath)

        monomer_names = metadata.get_monomer_map().values()
        polymer_names = metadata.get_polymer_names()

        return StateData(
            iteration=df["Iteration"].to_numpy(np.uint64),
            kmc_step=df["KMC Step"].to_numpy(np.uint64),
            kmc_time=df["KMC Time"].to_numpy(np.float64),
            sim_time=df["Simulation Time"].to_numpy(np.float64),
            sim_time_per_1e6_steps=df["Simulation Time per 1e6 KMC Steps"].to_numpy(
                np.float64
            ),
            NAV=df["NAV"].to_numpy(np.float64),
            unit_convs={
                name: df[f"{name} Conversion"].to_numpy(np.float64)
                for name in monomer_names
            },
            total_conv=df["Total Conversion"].to_numpy(np.float64),
            unit_counts={
                name: df[f"{name} Count"].to_numpy(np.uint64) for name in monomer_names
            },
            polymer_counts={
                name: df[f"{name} Count"].to_numpy(np.uint64) for name in polymer_names
            },
            nAvgCL=df["nAvgChainLength"].to_numpy(np.float64),
            wAvgCL=df["wAvgChainLength"].to_numpy(np.float64),
            dispCL=df["chainLengthDispersity"].to_numpy(np.float64),
            nAvgMW=df["nAvgMolecularWeight"].to_numpy(np.float64),
            wAvgMW=df["wAvgMolecularWeight"].to_numpy(np.float64),
            dispMW=df["molecularWeightDispersity"].to_numpy(np.float64),
            nAvgSL={
                name: df[f"nAvgSequenceLength_{name}"].to_numpy(np.float64)
                for name in monomer_names
            },
            wAvgSL={
                name: df[f"wAvgSequenceLength_{name}"].to_numpy(np.float64)
                for name in monomer_names
            },
            dispSL={
                name: df[f"sequenceLengthDispersity_{name}"].to_numpy(np.float64)
                for name in monomer_names
            },
            _raw_data=df,
        )


@dataclass
class SequenceData:

    iteration: NDArray[np.uint64]
    kmc_time: NDArray[np.float64]
    bucket: NDArray[np.uint64]
    monomer_count: Dict[str, NDArray[np.uint64]]
    sequence_count: Dict[str, NDArray[np.uint64]]
    sequence_length2: Dict[str, NDArray[np.float64]]

    _raw_data: pd.DataFrame

    @staticmethod
    def from_csv(filepath: Path | str, metadata: Metadata) -> SequenceData:

        df = pd.read_csv(filepath)

        monomer_names = metadata.get_monomer_map().values()

        return SequenceData(
            iteration=df["Iteration"].to_numpy(np.uint64),
            kmc_time=df["KMC Time"].to_numpy(np.float64),
            bucket=df["Bucket"].to_numpy(np.uint64),
            monomer_count={
                name: df[f"{name} Count"].to_numpy(np.uint64) for name in monomer_names
            },
            sequence_count={
                name: df[f"{name} Sequence Count"].to_numpy(np.uint64)
                for name in monomer_names
            },
            sequence_length2={
                name: df[f"{name} Sequence Length^2"].to_numpy(np.float64)
                for name in monomer_names
            },
            _raw_data=df,
        )


@dataclass
class Metadata:
    run_info: Dict[str, Any]
    species: Dict[str, Any]
    reactions: Dict[str, Any]
    parameters: Dict[str, Any]

    _metadata_path: Optional[Path] = None
    _raw_data: Optional[Dict[str, Any]] = None

    @staticmethod
    def load(metadata_path: Path | str) -> Metadata:

        metadata_path = Path(metadata_path)
        with open(metadata_path, "r") as file:
            data = yaml.safe_load(file)

        assert (
            data is not None
        ), f"Metadata file {metadata_path} is empty or invalid YAML."
        assert isinstance(
            data, dict
        ), f"Metadata file {metadata_path} does not contain a valid YAML dictionary."

        required_keys = ["run_info", "parameters", "species", "reactions"]
        missing_keys = [key for key in required_keys if key not in data.keys()]
        if missing_keys:
            raise ValueError(
                f"Metadata file {metadata_path} is missing required keys: {missing_keys}"
            )

        return Metadata(
            run_info=data["run_info"],
            species=data["species"],
            reactions=data["reactions"],
            parameters=data["parameters"],
            _metadata_path=metadata_path,
            _raw_data=data,
        )

    def to_dict(self) -> Dict[str, Any]:
        return self._raw_data if self._raw_data is not None else {}

    def get_monomer_map(self) -> Dict[int, str]:
        """Mapping of monomer IDs to names"""

        monomer_map = {}

        units: List[Dict[str, Any]] = self.species.get("units", [])
        for unit in units:
            if unit["type"] == "M":
                monomer_map[int(unit["id"])] = unit["name"]

        if not monomer_map or len(monomer_map) == 0:
            raise ValueError(f"Metadata file does not contain any monomer information.")

        return monomer_map

    def get_polymer_names(self) -> List[str]:

        polymer_names = []

        polymers: List[Dict[str, Any]] = self.species.get("polymers", [])
        if len(polymers) == 0:
            raise ValueError(f"Metadata file does not contain any polymer information.")

        for polymer in polymers:
            polymer_names.append(polymer["name"])

        return polymer_names


class PolymerEnsemble:
    pass
