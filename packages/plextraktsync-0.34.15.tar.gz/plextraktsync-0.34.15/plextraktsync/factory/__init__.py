from __future__ import annotations

from .Factory import Factory

factory = Factory()
logger = factory.logger
logging = factory.logging
