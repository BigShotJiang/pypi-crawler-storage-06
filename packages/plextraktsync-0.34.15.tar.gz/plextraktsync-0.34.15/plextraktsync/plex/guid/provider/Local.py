from __future__ import annotations

from .Abstract import Abstract


class Local(Abstract):
    pass
