from llama_index.llms.fireworks.base import Fireworks

__all__ = ["Fireworks"]
