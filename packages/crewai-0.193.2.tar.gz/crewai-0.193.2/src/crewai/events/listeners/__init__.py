"""Event listener implementations for CrewAI.

This module contains various event listener implementations
for handling memory, tracing, and other event-driven functionality.
"""
