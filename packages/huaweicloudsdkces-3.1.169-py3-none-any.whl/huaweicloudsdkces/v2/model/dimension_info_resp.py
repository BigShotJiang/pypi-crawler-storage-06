# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DimensionInfoResp:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'filter_type': 'str',
        'values': 'list[str]'
    }

    attribute_map = {
        'name': 'name',
        'filter_type': 'filter_type',
        'values': 'values'
    }

    def __init__(self, name=None, filter_type=None, values=None):
        r"""DimensionInfoResp

        The model defined in huaweicloud sdk

        :param name: **参数描述**： 维度名称。 **取值范围**： 多维度用逗号分隔，各服务支持的维度可参考：“[服务维度名称](ces_03_0059.xml)”。必须以字母开头，只能包含0-9/a-z/A-Z/_/-，多维度用\&quot;,\&quot;分隔，每个维度的最大长度为32。总长度为[1,131]个字符。目前最大支持4个维度。举例：单维度场景：instance_id；多维度场景：instance_id,disk 
        :type name: str
        :param filter_type: **参数描述**： 资源类型。 **取值范围**： - all_instances: 全部资源 - specific_instances: 指定资源 
        :type filter_type: str
        :param values: **参数描述**： 维度值列表。 
        :type values: list[str]
        """
        
        

        self._name = None
        self._filter_type = None
        self._values = None
        self.discriminator = None

        if name is not None:
            self.name = name
        if filter_type is not None:
            self.filter_type = filter_type
        if values is not None:
            self.values = values

    @property
    def name(self):
        r"""Gets the name of this DimensionInfoResp.

        **参数描述**： 维度名称。 **取值范围**： 多维度用逗号分隔，各服务支持的维度可参考：“[服务维度名称](ces_03_0059.xml)”。必须以字母开头，只能包含0-9/a-z/A-Z/_/-，多维度用\",\"分隔，每个维度的最大长度为32。总长度为[1,131]个字符。目前最大支持4个维度。举例：单维度场景：instance_id；多维度场景：instance_id,disk 

        :return: The name of this DimensionInfoResp.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this DimensionInfoResp.

        **参数描述**： 维度名称。 **取值范围**： 多维度用逗号分隔，各服务支持的维度可参考：“[服务维度名称](ces_03_0059.xml)”。必须以字母开头，只能包含0-9/a-z/A-Z/_/-，多维度用\",\"分隔，每个维度的最大长度为32。总长度为[1,131]个字符。目前最大支持4个维度。举例：单维度场景：instance_id；多维度场景：instance_id,disk 

        :param name: The name of this DimensionInfoResp.
        :type name: str
        """
        self._name = name

    @property
    def filter_type(self):
        r"""Gets the filter_type of this DimensionInfoResp.

        **参数描述**： 资源类型。 **取值范围**： - all_instances: 全部资源 - specific_instances: 指定资源 

        :return: The filter_type of this DimensionInfoResp.
        :rtype: str
        """
        return self._filter_type

    @filter_type.setter
    def filter_type(self, filter_type):
        r"""Sets the filter_type of this DimensionInfoResp.

        **参数描述**： 资源类型。 **取值范围**： - all_instances: 全部资源 - specific_instances: 指定资源 

        :param filter_type: The filter_type of this DimensionInfoResp.
        :type filter_type: str
        """
        self._filter_type = filter_type

    @property
    def values(self):
        r"""Gets the values of this DimensionInfoResp.

        **参数描述**： 维度值列表。 

        :return: The values of this DimensionInfoResp.
        :rtype: list[str]
        """
        return self._values

    @values.setter
    def values(self, values):
        r"""Sets the values of this DimensionInfoResp.

        **参数描述**： 维度值列表。 

        :param values: The values of this DimensionInfoResp.
        :type values: list[str]
        """
        self._values = values

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DimensionInfoResp):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
