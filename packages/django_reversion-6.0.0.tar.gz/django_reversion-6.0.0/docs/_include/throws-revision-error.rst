Throws :ref:`RevisionManagementError` if there is no active revision block.
