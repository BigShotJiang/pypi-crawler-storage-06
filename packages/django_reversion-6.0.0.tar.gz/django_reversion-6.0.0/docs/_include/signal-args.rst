``sender``
    The ``reversion.create_revision`` object.

``revision``
    The :ref:`Revision` model.

``versions``
    The :ref:`Version` models in the revision.
