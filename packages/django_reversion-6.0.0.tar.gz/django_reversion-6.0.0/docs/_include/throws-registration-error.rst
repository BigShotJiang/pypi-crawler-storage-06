Throws :ref:`RegistrationError` if the model has not been registered with django-reversion.
