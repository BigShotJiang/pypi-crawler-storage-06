# FILE: tests/test_transformer_sota_import.py
def test_transformer_sota_import():
    import importlib; importlib.import_module("a3d.reweight_transformer_sota")
