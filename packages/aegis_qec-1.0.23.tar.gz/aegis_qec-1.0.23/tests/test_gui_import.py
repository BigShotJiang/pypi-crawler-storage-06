# FILE: tests/test_gui_import.py
def test_gui_import():
    import importlib; importlib.import_module("gui.app")
