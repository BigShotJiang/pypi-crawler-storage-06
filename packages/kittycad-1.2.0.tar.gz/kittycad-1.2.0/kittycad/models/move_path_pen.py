from .base import KittyCadBaseModel


class MovePathPen(KittyCadBaseModel):
    """The response from the `MovePathPen` endpoint."""
