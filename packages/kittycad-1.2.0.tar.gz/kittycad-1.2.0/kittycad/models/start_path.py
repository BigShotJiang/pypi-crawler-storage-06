from .base import KittyCadBaseModel


class StartPath(KittyCadBaseModel):
    """The response from the `StartPath` endpoint."""
