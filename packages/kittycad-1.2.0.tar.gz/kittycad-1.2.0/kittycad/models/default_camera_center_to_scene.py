from .base import KittyCadBaseModel


class DefaultCameraCenterToScene(KittyCadBaseModel):
    """The response from the `DefaultCameraCenterToScene` endpoint."""
