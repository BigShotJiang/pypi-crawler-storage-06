from .base import KittyCadBaseModel


class ReconfigureStream(KittyCadBaseModel):
    """The response from the `ReconfigureStream` endpoint."""
