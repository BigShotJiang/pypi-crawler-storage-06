# config.py - global configuration.

APP = "xcltk"
VERSION = "0.5.0"
DEBUG = 0
