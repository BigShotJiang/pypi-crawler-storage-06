### Summary
<!-- What & why -->

### Changes
- [ ] ...

### Checklist
- [ ] Branch is `arched/<feature>`
- [ ] PR title auto-set by CI (leave it alone unless wrong)
- [ ] Conventional Commits respected (`feat:`, `fix:`, `chore:`, `docs:`)
- [ ] Linters & tests pass

<!-- The workflow will add labels:
     feature: {feature} | date: YYYY-MM-DD | time: HH:MM (Europe/London) -->