class ComponentDefinition:
    pass

class NextPageData:
    pass

class Feature:
    def __init__(self, name, manager, options, invokerType):
        pass
    def execute(self):
        pass
    def _generate_page_content(self):
        pass
