__init__.py

"""
This file initializes the mytsoss library and may contain metadata about the package.
"""