from tidy3d_mcp_proxy.server import main

__all__ = ['main']
