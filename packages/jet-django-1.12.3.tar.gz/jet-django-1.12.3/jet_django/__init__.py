VERSION = '1.12.3'
default_app_config = 'jet_django.apps.JetDjangoConfig'
