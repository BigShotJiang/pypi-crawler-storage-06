# Example use in Marimo notebooks

Examples using the [marimo](https://marimo.io) notebooks.

```
uv run marimo edit
```
