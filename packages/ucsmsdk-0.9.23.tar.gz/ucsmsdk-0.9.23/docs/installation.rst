============
Installation
============

At the command line::

    $ easy_install ucsmsdk

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv ucsmsdk
    $ pip install ucsmsdk
