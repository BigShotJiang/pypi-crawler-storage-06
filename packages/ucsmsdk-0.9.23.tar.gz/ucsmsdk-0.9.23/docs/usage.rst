========
Usage
========

To use ucsmsdk in a project::

    import ucsmsdk
