"""Version information."""
# Version digit interpretation
# First digit: major updates
# Second digit: minor features / modifications
# Third digit: bug fixing

__version__ = "1.5.2"
