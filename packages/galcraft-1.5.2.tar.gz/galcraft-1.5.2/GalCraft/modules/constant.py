cvel = 299792.458 # speed of light in km/s
