- Complete screen workflows (currently enough for a demo, not for
  production)
- Inventory: find a way to have a nice autofocus for quantity, still
  compatible with barcode scanner (Odoo disables the autofocus when
  using barcode, which makes sense)
- Put-away: handle packages
- Handle "multi-shuttle" put-away
- Create glue module for product_expiry
- Challenge the save + release buttons and workflow
