Add configuration and dedicated screens to work with Vertical Lift
systems (such as Kardex Remstar, Modula, ...). Drivers for controlling
the lifts physically must be added by additional addons.
