"""skpro."""

__version__ = "2.9.4"

__all__ = ["show_versions"]

from skpro.utils._maint._show_versions import show_versions
