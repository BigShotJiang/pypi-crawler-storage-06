"""Tests for registry and lookup functionality."""
