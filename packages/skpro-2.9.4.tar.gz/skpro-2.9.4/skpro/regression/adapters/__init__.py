"""Adapters for probabilistic regressors."""
# copyright: skpro developers, BSD-3-Clause License (see LICENSE file)
