"""Tests for skpro package."""
