import "http://localhost:5211/@vite/client";
export { getFeature } from "http://localhost:5211/src/pages/labelEditor.tsx";
