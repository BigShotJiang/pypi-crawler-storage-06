Versions used:
vis.js v4.20.1
    Don't use latest v4.21 - Hierarchical view is not working with it