.. _license:

LICENSE
-------

.. include:: ../LICENSE.rst
