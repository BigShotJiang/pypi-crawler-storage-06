================
The logging page
================

The `logging page <https://pesummary.github.io/GW190412/html/Logging.html>`_
shows the output of the logger for when these pages were generated. The
handler is set to `debug` meaning all messages are displayed. This is a useful
page for seeing why a certain plot may not have been generated for example.
