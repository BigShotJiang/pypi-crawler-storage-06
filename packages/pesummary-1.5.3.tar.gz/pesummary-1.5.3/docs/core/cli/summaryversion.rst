==============
summaryversion
==============

The `summaryversion` executable allows the user to find out the version of
PESummary that they are running from the command line. An example output is
below

.. command-output:: summaryversion
