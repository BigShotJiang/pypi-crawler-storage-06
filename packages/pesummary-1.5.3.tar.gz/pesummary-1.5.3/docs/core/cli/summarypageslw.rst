==============
summarypageslw
==============

The `summarypageslw` executable is meant to be a lightweight version of the
`summarypages <summarypages.html>`_ executable. The plots and pages produced
from this executable will show you exactly what you asked for and no more. It is
designed to be used when the user does not have time to wait for the complete
summarypages to be produced.

To see help for this executable please run:

.. code-block:: console

    $ summarypageslw --help

.. program-output:: summarypageslw --help
