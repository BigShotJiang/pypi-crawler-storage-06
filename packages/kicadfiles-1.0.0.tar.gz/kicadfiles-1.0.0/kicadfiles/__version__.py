"""Version information for KiCadFiles."""

__version__ = "1.0.0"
__version_info__ = (1, 0, 0)

# Version history
# 1.0.0 - Initial release with complete KiCad S-expression support
