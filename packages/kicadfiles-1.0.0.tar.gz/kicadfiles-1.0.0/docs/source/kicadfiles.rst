KiCadFiles API
==============

Submodules
----------

kicadfiles.advanced\_graphics module
------------------------------------

.. automodule:: kicadfiles.advanced_graphics
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.base\_element module
-------------------------------

.. automodule:: kicadfiles.base_element
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.base\_types module
-----------------------------

.. automodule:: kicadfiles.base_types
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.board\_layout module
-------------------------------

.. automodule:: kicadfiles.board_layout
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.design\_rules module
-------------------------------

.. automodule:: kicadfiles.design_rules
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.enums module
-----------------------

.. automodule:: kicadfiles.enums
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.footprint\_library module
------------------------------------

.. automodule:: kicadfiles.footprint_library
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.json\_base\_element module
-------------------------------------

.. automodule:: kicadfiles.json_base_element
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.pad\_and\_drill module
---------------------------------

.. automodule:: kicadfiles.pad_and_drill
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.primitive\_graphics module
-------------------------------------

.. automodule:: kicadfiles.primitive_graphics
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.project\_settings module
-----------------------------------

.. automodule:: kicadfiles.project_settings
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.schematic\_system module
-----------------------------------

.. automodule:: kicadfiles.schematic_system
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.sexpdata module
--------------------------

.. automodule:: kicadfiles.sexpdata
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.sexpr\_parser module
-------------------------------

.. automodule:: kicadfiles.sexpr_parser
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.symbol\_library module
---------------------------------

.. automodule:: kicadfiles.symbol_library
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.text\_and\_documents module
--------------------------------------

.. automodule:: kicadfiles.text_and_documents
   :members:
   :show-inheritance:
   :undoc-members:

kicadfiles.zone\_system module
------------------------------

.. automodule:: kicadfiles.zone_system
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: kicadfiles
   :members:
   :show-inheritance:
   :undoc-members:
