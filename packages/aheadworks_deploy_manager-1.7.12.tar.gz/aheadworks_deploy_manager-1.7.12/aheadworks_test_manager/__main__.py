import fire
from aheadworks_test_manager.console.console import Console

if __name__ != '__main__':
    pass
else:
    fire.Fire(Console)
