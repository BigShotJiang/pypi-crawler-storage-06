# RuleType


## Enum

* `KEYWORDRULE` (value: `'KeywordRule'`)

* `MODELHALLUCINATIONRULEV2` (value: `'ModelHallucinationRuleV2'`)

* `MODELSENSITIVEDATARULE` (value: `'ModelSensitiveDataRule'`)

* `PIIDATARULE` (value: `'PIIDataRule'`)

* `PROMPTINJECTIONRULE` (value: `'PromptInjectionRule'`)

* `REGEXRULE` (value: `'RegexRule'`)

* `TOXICITYRULE` (value: `'ToxicityRule'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


