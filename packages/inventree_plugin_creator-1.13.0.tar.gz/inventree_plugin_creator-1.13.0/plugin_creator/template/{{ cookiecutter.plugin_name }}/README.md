# {{ cookiecutter.plugin_name }}

{{ cookiecutter.plugin_description }}

## Installation

### InvenTree Plugin Manager

... todo ...

### Command Line 

To install manually via the command line, run the following command:

```bash
pip install {{ cookiecutter.plugin_slug }}
```

## Configuration

... todo ...

## Usage

... todo ...
