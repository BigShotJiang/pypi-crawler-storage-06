# -*- coding: utf-8 -*-

PLUGIN_VERSION = "{{ cookiecutter.plugin_version }}"
