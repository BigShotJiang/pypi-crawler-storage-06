from ._linn import LinnModel, save_linn  # noqa
