#!/usr/bin/env python
from argparse import ArgumentParser

def main():
    print("This has been replaced with the fully-featured Moku Command Line Utility `mokucli`. Please download from https://liquidinstruments.com/software/utilities/")


# Compatible with direct run and distutils binary packaging
if __name__ == "__main__":
    main()
