from ats_base.common import func


def sys_time():
    return func.sys_current_time()
