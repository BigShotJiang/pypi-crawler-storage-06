**Italiano**

Questo modulo consente di generare correttamente la fattura elettronica
(XML) quando il modulo account_invoice_triple_discount è installato.

**English**

The module allows to use correctly generate the Electronic Invoice (XML)
when the module account_invoice_triple_discount is installed.
