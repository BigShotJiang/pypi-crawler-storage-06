"""Initialize the app"""

__version__ = "1.0.8"
__title__ = "Markettracker"
