# qrs32lib

A Python library for **Quantum Resonance Search (QRS)** simulations up to 32 qubits.  

## Install
```bash
pip install qrs32lib
