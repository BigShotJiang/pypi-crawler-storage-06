"""Phase 2.5 Tool Injection - Core/Tools Tests"""
