# Calculator!!!

To run, simply install the package, `pip install space-coder-cmd-calc` and then run `python3 -m cmd_calc`

If it fails, make sure to check that you have installed python from the Microsoft store. You can also try running `python.exe -m cmd_calc` or on Linux `cmd_calc` (untested)

## Usefull funtions!

The traditional *, x, /, +, -, ^, and ** operators are supported as of now, but there are many other funtions of this calculator that you can find out about by running the 'help' or 'funcs' command. 

## Note:
As this calculator uses regex, it can react to other noise, so please keep statements consise. Although 'what is 3 plus 3' will work, it is recommended to use '3+3' as the calculator has been more thoroughly tested to be used in this manor.