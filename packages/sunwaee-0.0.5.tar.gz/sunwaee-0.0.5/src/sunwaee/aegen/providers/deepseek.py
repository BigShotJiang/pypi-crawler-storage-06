# standard
# third party
# custom
from sunwaee.aegen.provider import Provider


DEEPSEEK = Provider(
    name="deepseek",
    url="https://api.deepseek.com/v1/chat/completions",
)
