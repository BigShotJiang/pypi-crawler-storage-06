# standard
# third party
# custom
from sunwaee.aegen.provider import Provider

XAI = Provider(
    name="xai",
    url="https://api.x.ai/v1/chat/completions",
)
