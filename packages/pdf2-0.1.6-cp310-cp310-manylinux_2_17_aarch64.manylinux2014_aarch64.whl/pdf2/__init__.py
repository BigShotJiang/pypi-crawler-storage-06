from .pdf2 import *

__doc__ = pdf2.__doc__
if hasattr(pdf2, "__all__"):
    __all__ = pdf2.__all__