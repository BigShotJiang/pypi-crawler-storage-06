{# 
  Python incremental models are now handled by the main incremental materialization.
  Use materialized='incremental' with language='python' instead of materialized='python_incremental'
#}
