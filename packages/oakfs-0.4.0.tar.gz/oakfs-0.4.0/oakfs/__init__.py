__author__ = "Ritchie Mwewa"
__pkg__ = "oakfs"
__project__ = "[dim]oak[/]"
__version__ = "0.4.0"
