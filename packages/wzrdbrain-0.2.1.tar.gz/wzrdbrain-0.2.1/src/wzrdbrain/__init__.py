from .wzrdbrain import generate_combo

"""
wzrdbrain: Basic APIs to generate tricks for wizard skating.
"""


__all__ = ["generate_combo"]

__version__ = "0.1.0"
