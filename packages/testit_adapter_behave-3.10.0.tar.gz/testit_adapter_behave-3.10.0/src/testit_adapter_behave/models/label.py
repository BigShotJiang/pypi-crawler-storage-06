# TODO: Add model to python-commons; implement via attrs
def get_label_model(label):
    return {
        'name': label
    }
