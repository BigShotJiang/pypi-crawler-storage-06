

# # 全局变量定义
# worker_secret_key = None
from .authorizer import Authorizer

authorizer = Authorizer()

# from .mcp_adapter.mcp_manager import MCPManager

# mcp_manager = MCPManager()
