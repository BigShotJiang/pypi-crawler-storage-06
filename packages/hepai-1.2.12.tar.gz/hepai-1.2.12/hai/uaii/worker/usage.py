"""
使用方法：
```python
import hai
hai.worker.start()
"""

