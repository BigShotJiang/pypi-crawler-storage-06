# src/playbook/__init__.py
"""Playbook - A workflow engine for operations"""

__version__ = "1.1.1"
