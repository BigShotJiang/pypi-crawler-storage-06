import uuid


def create_request_id():
    return str(uuid.uuid4())
