API
===

The specification of the Pindakaas API

.. automodule:: pindakaas
   :members:
   :undoc-members:

.. automodule:: pindakaas.solver
   :members:
   :undoc-members:


