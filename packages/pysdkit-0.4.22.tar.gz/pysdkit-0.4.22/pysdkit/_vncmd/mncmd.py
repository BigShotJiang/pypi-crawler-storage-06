# -*- coding: utf-8 -*-
"""
Created on 2025/02/05 13:22:51
@author: Whenxuan Wang
@email: wwhenxuan@gmail.com
"""
import numpy as np


class MNCMD(object):
    pass
