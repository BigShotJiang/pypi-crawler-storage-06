# -*- coding: utf-8 -*-
"""
Created on 2025/02/05 13:32:00
@author: Whenxuan Wang
@email: wwhenxuan@gmail.com
"""
from .jmd import JMD
