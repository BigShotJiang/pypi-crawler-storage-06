# -*- coding: utf-8 -*-
"""
Created on 2025/02/01 22:30:27
@author: Whenxuan Wang
@email: wwhenxuan@gmail.com
"""

from .faemd import FAEMD

from .faemd2d import FAEMD2D

from .faemd3d import FAEMD3D
