from typing import Any, Dict


def kwargs(**kwargs) -> Dict[str, Any]:
    return kwargs
