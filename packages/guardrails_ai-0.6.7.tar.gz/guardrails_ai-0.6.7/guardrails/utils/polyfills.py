def anext(aiter):
    return aiter.__anext__()
