from typing import Any, List


def args(*args: Any) -> List[Any]:
    return list(args)
