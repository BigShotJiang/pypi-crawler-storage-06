from importlib.metadata import version as importlib_version

GUARDRAILS_VERSION = importlib_version("guardrails-ai")
