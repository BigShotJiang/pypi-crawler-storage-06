# Energy Communities

Base addon for the basis operacion with energy communities

## Changelog

### 2025-09-24 (v16.0.0.5.6)

- added roles ids to config

### 2025-09-17 (v16.0.0.5.5)

- Clean commented code

### 2025-06-03 (v16.0.0.4.5)

- New function `res_company.get_all_energy_actions_dict_list`

### 2025-05-21

- Added Readme
