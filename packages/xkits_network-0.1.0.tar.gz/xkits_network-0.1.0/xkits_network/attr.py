# coding:utf-8

__project__ = "xkits-network"
__version__ = "0.1.0"
__urlhome__ = "https://github.com/bondbox/xnetwork/"
__description__ = "Network module"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
