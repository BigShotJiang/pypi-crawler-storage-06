#包初始化文件

from .core import add, multiply
from .utils import version

# 版本号
__version__ = "1.0.0"