# TruthAI SDK

Coming soon from TruthAI.

## Installation

```bash
pip install truthai-sdk
```

## Usage

This package is currently in development. Stay tuned for updates!

## License

MIT License
