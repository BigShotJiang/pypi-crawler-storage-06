"""
TruthAI SDK

Coming soon from TruthAI.
"""

__version__ = "0.0.2"
__author__ = "TruthAI"
__email__ = "contact@truthai.com"