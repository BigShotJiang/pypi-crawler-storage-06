.. all-saltext.s3fs.fileserver:

__________________
Fileserver Modules
__________________

.. currentmodule:: saltext.s3fs.fileserver

.. autosummary::
    :toctree:

    s3fs
