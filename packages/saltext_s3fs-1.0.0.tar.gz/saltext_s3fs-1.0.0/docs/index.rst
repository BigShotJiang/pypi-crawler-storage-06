``saltext-s3fs``: Integrate Salt with s3fs
==========================================

Salt Extension enabling the use of S3 as a fileserver backend

.. toctree::
  :maxdepth: 2
  :caption: Guides
  :hidden:

  topics/installation

.. toctree::
  :maxdepth: 2
  :caption: Provided Modules
  :hidden:

  ref/fileserver/index

.. toctree::
  :maxdepth: 2
  :caption: Reference
  :hidden:

  changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
