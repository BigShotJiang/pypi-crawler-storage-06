from __future__ import annotations

from .views import router

__all__ = ["router"]
