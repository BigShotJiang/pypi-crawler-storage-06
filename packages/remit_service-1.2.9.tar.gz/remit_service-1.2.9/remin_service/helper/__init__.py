class __DataCent:
    data = {}
    

DataCent = __DataCent()