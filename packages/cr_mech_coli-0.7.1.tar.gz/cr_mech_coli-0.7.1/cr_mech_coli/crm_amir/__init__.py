"""
.. code-block:: text
    :caption: Usage of the `crm_multilayer` script
"""

from cr_mech_coli.crm_amir.crm_amir_rs import *

from .main import crm_amir_main
