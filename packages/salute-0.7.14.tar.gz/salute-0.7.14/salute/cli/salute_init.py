def salute_init():
    print("salute init")
