from salute.app.app import App
from salute.app.config import app_config
