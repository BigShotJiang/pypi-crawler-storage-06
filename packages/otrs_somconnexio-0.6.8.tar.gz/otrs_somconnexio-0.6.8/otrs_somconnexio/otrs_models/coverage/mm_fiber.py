class MMFiberCoverage:
    VALUES = [
        ("fibraFTTH", "Fibra (FTTH)"),
        ("NoFibra", "No Fibra (MM)"),
        ("NoRevisat", "No revisat"),
        ("fibraIndirecta", "Fibra (indirecta)"),
    ]
