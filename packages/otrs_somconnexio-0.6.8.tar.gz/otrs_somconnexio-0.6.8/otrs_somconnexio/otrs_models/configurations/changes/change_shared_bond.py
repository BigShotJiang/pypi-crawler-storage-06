class ChangeSharedBondTicketConfiguration:
    process_id = "Process-304d80eb0f377a484aae9ef23c6c5b74"
    activity_id = "Activity-2a3858fe1d17a3777858ed273eb549f0"
    type = "Petición"
    queue_id = 225
    state = "new"
    priority = "3 normal"
