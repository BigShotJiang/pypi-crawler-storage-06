# coding: utf-8
class Router4GTicketConfiguration:
    process_id = "Process-4b7130980e3fb4fcf3c57f00c7a2e903"
    activity_id = "Activity-ac1a618667aedbb7c25e196bffb5bf09"
    type = "Petición"
    queue_id = 146
    state = "new"
    priority = "3 normal"
