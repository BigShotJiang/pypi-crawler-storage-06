# coding: utf-8
class SwitchboardTicketConfiguration:
    process_id = "Process-340f0714fca27d563373adda18b505d9"
    activity_id = "Activity-cbf9c1acfd068e164d7e7c53cbd6a137"
    type = "Petición"
    SLA = "No pendent resposta"
    service = "Centraleta Virtual"
    queue_id = 242
    state = "new"
    priority = "3 normal"
