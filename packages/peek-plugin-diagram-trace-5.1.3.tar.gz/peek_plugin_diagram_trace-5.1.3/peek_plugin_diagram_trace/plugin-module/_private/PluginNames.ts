export let diagramTraceFilt = { plugin: "peek_plugin_diagram_trace" };
export let diagramTraceTuplePrefix = "peek_plugin_diagram_trace.";

export let diagramTraceObservableName = "peek_plugin_diagram_trace";
export let diagramTraceActionProcessorName = "peek_plugin_diagram_trace";
export let diagramTraceTupleOfflineServiceName = "peek_plugin_diagram_trace";

export let diagramTraceBaseUrl = "peek_plugin_diagram_trace";
