export { DiagramTraceService } from "@peek/peek_plugin_diagram_trace/DiagramTraceService";
