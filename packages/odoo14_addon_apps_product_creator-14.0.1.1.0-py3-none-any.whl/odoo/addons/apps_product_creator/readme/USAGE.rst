To see the module working

 * Import some modules with `github_connector <https://odoo-community.org/shop/product/1024>`_

#. Run manually the scheduled action mentioned on the configure section or wait until its execution.
#. Go to *Website > Products > Products*.
#. Click on Filters > Add Custom Filter, and apply the filter "Odoo Module" > "is set".
#. You will see the created products in the list.

 Now you can see the products created.
