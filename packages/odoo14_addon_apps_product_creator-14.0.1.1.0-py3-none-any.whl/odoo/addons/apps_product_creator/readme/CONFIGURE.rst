There's an scheduled action that creates the product, disabled by default. For enabling it:

#. Go to *Settings > Technical > Automation > Scheduled Actions*.
#. Locate "Create/Update product variants for each module version" and access its form.
