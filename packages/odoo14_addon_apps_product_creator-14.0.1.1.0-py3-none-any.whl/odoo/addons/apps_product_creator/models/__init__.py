from . import product_template
from . import product_product
from . import odoo_module
from . import odoo_module_version
