from . import permissions
from zope.i18nmessageid import MessageFactory


permissions  # pyflakes

_ = MessageFactory("plone")
