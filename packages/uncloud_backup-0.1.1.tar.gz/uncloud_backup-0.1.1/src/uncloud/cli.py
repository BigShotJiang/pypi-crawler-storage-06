import click


@click.command("Uncloud")
def main():
    print("It works!")