# Data directory for Bhumi MAP-Elites archive
# This directory contains optimized buffer configurations for best performance 