from os import path

import swh.core

SQL_DIR = path.join(path.dirname(swh.core.__file__), "sql")
