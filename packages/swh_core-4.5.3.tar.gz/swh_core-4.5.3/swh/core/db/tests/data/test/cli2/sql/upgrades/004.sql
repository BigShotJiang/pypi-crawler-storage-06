--

insert into origin2(url, hash)
values ('version004', hash_sha1('version004'));
