--

insert into origin2(url, hash)
values ('version002', hash_sha1('version002'));
