--

insert into origin(url, hash)
values ('version004', hash_sha1('version004'));
