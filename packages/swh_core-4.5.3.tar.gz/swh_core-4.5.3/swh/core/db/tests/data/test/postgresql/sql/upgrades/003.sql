--

insert into origin(url, hash)
values ('version003', hash_sha1('version003'));
