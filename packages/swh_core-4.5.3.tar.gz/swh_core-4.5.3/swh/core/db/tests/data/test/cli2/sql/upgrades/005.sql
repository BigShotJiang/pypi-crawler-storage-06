--

insert into origin2(url, hash)
values ('version005', hash_sha1('version005'));
