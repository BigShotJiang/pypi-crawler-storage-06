--

insert into origin(url, hash)
values ('version002', hash_sha1('version002'));
