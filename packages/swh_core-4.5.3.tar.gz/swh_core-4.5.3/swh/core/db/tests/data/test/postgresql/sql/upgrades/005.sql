--

insert into origin(url, hash)
values ('version005', hash_sha1('version005'));
