--

insert into origin2(url, hash)
values ('version003', hash_sha1('version003'));
