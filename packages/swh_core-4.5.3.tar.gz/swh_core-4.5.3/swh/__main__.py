# provides the main swh cli entry point from standard 'python -m swh'
if __name__ == "__main__":
    from swh.core.cli import main

    main()
