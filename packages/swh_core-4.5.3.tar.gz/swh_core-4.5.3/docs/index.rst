.. _swh-core:

.. include:: README.rst

Reference Documentation
-----------------------

.. toctree::
   :maxdepth: 2

   cli
   db

.. only:: standalone_package_doc

   Indices and tables
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
