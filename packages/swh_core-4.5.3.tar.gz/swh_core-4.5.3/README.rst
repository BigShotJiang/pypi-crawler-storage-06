Software Heritage - Core foundations
====================================

Low-level utilities and helpers used by almost all other modules in the stack.

core library for swh's modules:

- config parser
- serialization
- logging mechanism
- database connection
- http-based RPC client/server
