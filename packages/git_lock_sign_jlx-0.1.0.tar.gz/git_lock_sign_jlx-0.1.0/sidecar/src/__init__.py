"""CELN Sidecar service package."""
