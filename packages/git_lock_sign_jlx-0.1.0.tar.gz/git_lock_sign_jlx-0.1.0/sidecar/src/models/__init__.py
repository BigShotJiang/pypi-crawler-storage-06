"""Sidecar data models module."""
