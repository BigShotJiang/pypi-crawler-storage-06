"""
Template files for the CELN sidecar service.

This package contains template files used by the sidecar services,
such as .gitignore templates for different environments.
"""
