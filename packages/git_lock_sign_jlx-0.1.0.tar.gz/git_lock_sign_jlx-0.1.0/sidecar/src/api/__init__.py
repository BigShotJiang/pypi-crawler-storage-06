"""Sidecar API module."""
