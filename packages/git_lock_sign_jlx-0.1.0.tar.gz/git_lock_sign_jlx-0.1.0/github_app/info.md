Owned by: @liuji1031

App ID: 1783232

Using your App ID to get installation tokens? You can now use your Client ID instead.

Client ID: Iv23liMvHlMQ85EnuIF9

Installation ID: 81119717