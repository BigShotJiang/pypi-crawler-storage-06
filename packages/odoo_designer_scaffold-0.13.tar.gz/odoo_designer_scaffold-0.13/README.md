# Odoo designer's Scaffold

This is a Python library for creating an Odoo Design Project.

## Installation

Use the package manager pip to install it.

```bash
pip install odoo_designer_scaffold
```

## Usage

```bash
# create your module with
create-scaffold 
# by answering the questions
```

Enjoy <3
