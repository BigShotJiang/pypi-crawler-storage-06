# pysatgeo


[![image](https://img.shields.io/pypi/v/pysatgeo.svg)](https://pypi.python.org/pypi/pysatgeo)
[![image](https://img.shields.io/conda/vn/conda-forge/pysatgeo.svg)](https://anaconda.org/conda-forge/pysatgeo)


**Python package for satellite processing functions for raster and also vector**


-   Free software: MIT License
-   Documentation: https://JPPereira93.github.io/pysatgeo
    

## Features

-   TODO
