"""Integration tests for MCP Browser."""
