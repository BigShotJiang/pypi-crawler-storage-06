"""Test package for MCP Browser."""
