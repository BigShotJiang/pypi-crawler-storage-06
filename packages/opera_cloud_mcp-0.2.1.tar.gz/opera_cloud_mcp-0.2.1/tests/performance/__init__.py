"""
Performance tests for OPERA Cloud MCP server.
"""
