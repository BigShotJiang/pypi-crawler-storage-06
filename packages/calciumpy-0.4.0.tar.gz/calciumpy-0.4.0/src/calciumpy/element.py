import typing


Element = typing.Union[int, str, bool, list, dict, None]
