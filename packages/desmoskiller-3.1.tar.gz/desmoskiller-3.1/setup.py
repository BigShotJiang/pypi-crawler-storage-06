from setuptools import setup

setup(name="DesmosKiller",
      version="3.1",
      packages=["DesmosKiller"],#uGauss moved. DWAI
      author="YusufA442",
      author_email="yusuf365820@gmail.com",
      license='Creative Commons Attribution-Noncommercial-Share Alike license',
      long_description=open('readme.txt').read())