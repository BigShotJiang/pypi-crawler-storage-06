"""Top-level package for OctopuSV."""

__version__ = "0.2.3"
__PACKAGE_NAME__ = "octopusv"
