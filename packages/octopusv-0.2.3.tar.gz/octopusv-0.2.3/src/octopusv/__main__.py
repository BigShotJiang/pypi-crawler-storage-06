from .cli.cli import app

app()
