# -*- coding: utf-8 -*-


def getBlockParams(ws):
    """Auxiliary method to obtain ``ref_block_num`` and
    ``ref_block_prefix``. Requires a websocket connection to a
    witness node!
    """
    raise DeprecationWarning(
        "This method shouldn't be called anymore. It is part of transactionbuilder now"
    )
