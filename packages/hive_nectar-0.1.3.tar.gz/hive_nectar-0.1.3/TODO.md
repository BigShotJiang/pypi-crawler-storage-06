# Test cases

- [x] uv run pytest -v tests/nectar
- [x] uv run pytest -v tests/nectarapi
- [x] uv run pytest -v tests/nectarbase
- [x] uv run pytest -v tests/nectargraphene
- [x] uv run pytest -v tests/nectarstorage
