from setuptools import setup, find_packages

VERSION = '1.0'
setup(
    name='moduvent',
    version=VERSION,
    description='A package for managing events',
    packages=find_packages(),
)