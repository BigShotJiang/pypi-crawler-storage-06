from . import SPLASH


if __name__ == "__main__":
    print(SPLASH)
