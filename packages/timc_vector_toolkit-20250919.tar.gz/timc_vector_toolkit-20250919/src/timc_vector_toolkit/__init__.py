from importlib.resources import read_text


SPLASH = read_text(__name__, "_readme.md")
