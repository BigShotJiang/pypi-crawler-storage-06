# (C) 2021 GoodData Corporation
from gooddata_fdw._version import __version__
from gooddata_fdw.fdw import GoodDataForeignDataWrapper
