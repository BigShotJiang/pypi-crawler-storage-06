#
# Copyright 2020-present by A. Mathis Group and contributors. All rights reserved.
#
# This project and all its files are licensed under GNU AGPLv3 or later version. 
# A copy is included in dlc2action/LICENSE.AGPL.
#
"""
DLC2Action Toolbox
© A. Mathis Lab
"""

__version__ = "1.0"
VERSION = __version__
