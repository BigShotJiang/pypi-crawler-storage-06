"""Test suite for the nima package."""
