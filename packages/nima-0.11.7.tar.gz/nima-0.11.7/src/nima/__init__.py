"""The numerical image `nima` analysis."""
