=====
Usage
=====

To use the LAMMPS plug-in in a project::

    import lammps_step
