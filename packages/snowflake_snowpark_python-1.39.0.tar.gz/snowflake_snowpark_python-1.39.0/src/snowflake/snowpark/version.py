#!/usr/bin/env python3


# Update this for the versions
VERSION = (1, 39, 0)
