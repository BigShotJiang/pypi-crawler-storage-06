from enum import Enum


class WorkbookFileType(Enum):
    twb = "twb"
    twbx = "twbx"