def test_cleaner_basic():
    pass
