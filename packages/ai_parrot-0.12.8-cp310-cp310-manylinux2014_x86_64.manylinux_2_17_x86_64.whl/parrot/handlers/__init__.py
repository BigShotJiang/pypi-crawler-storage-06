"""
Parrot basic Handlers.
"""
from .bots import ChatbotHandler
