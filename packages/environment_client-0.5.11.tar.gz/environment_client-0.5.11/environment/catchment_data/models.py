from pydantic import BaseModel


class CatchmentData(BaseModel):
    """
    A placeholder model for catchment data.
    """

    # TODO: Define the actual fields for CatchmentData once the API endpoint is determined.
    pass
