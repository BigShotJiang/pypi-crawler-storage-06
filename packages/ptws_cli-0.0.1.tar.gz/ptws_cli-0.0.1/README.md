# ptws-cli (placeholder alias)

This is a placeholder alias for the forthcoming **PenTest.WS CLI**.

Installing `ptws-cli` will install the canonical package: **`ptws`**.

-   Canonical package: https://pypi.org/project/ptws/
-   Publisher: PenTest.WS (https://pentest.ws)
-   GitHub: https://github.com/PenTestWS
