# geneinfo
Jupyter notebook utility functions for working with gene information, go ontologies, and gene networks, and for plotting data over gene and chromosome ideograms.

## install

 conda install -c conda-forge -c bioconda -c kaspermunch geneinfo
 
