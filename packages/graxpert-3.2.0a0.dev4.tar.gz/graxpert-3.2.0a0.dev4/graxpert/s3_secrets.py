# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: /home/runner/work/GraXpert/GraXpert/graxpert/s3_secrets.py
# Bytecode version: 3.10.0rc2 (3439)
# Source timestamp: 2024-05-03 17:20:08 UTC (1714756808)

endpoint = 'minio.schmelly.de'
ro_access_key = 'IynFklnoqVLigqvqkBR5'
ro_secret_key = '1250a0FYS2WlUF78aZk0yoeT5daJQkRsNiIjLlhQ'
bucket_name = 'graxpert-ai'
bge_bucket_name = 'graxpert-bge-ai-onnx'
denoise_bucket_name = 'graxpert-denoise-ai-onnx'

deconvolution_object_bucket_name = 'graxpert-deconv-object'
deconvolution_stars_bucket_name = 'graxpert-deconvolution-stars'
deconvolution_object_bucket_name = "graxpert-deconvolution-object-ai-onnx"
deconvolution_stars_bucket_name = "graxpert-deconvolution-stars-ai-onnx"