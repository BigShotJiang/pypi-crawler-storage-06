VERSION = (0, 7, 0)

__author__ = "Nathaniel Albright"
__email__ = "developer@3dcg.guru"
__version__ = '.'.join(map(str, VERSION))

#0.7.0 = Option to use convert ascii fbx to binary.  Maya 2025 support.
#0.6.4 = Add option to strip SubDeformer namespaces from FBX
#0.6.3 = Fixes bug where the uData utilities didn't update class versions when finding records
