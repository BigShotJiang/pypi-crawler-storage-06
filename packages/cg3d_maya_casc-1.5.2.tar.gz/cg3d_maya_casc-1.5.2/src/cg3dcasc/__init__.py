from .core import *
from . import preferences
#from .core import hik

VERSION = (1, 5, 2)

__author__ = "Nathaniel Albright"
__email__ = "developer@3dcg.guru"
__version__ = '.'.join(map(str, VERSION))