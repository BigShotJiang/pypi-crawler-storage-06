from django.apps import AppConfig


class GenericFormsConfig(AppConfig):
    name = 'app_kit.features.generic_forms'
