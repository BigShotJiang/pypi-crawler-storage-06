from django.apps import AppConfig


class AppKitApiConfig(AppConfig):
    name = 'app_kit.app_kit_api'
