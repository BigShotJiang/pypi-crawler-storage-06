# Hertz point-particle mode module

## API

```{eval-rst}
.. automodule:: pybhpt.hertz
   :no-index:
   :members:
   :undoc-members:
   :show-inheritance:
```
