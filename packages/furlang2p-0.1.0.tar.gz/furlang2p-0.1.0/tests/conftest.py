"""Reserved for shared fixtures when real tests are added."""

from __future__ import annotations
