"""Test package marker."""

from __future__ import annotations
