Examples
========

Small scripts demonstrating the public API. Run them after installing the
package or by setting ``PYTHONPATH=src`` in the repository root.

- ``pipeline_example.py`` – normalises and phonemises a short phrase using the
  :class:`PipelineService`.
