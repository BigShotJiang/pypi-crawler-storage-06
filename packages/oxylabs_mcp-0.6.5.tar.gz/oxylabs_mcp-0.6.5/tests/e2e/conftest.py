import dotenv


dotenv.load_dotenv()
