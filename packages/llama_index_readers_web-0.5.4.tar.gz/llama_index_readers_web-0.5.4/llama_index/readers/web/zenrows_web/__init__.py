"""ZenRows Web Reader module."""

from llama_index.readers.web.zenrows_web.base import ZenRowsWebReader

__all__ = ["ZenRowsWebReader"]
