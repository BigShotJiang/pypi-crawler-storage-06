mod styling;
mod syntaxhl;

pub(crate) use styling::StyledText;
