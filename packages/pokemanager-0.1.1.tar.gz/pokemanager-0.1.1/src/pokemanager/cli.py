"""CLI."""


def main():
    """Main entry point for the CLI."""
    print("Hello, World!")


if __name__ == "__main__":
    main()
