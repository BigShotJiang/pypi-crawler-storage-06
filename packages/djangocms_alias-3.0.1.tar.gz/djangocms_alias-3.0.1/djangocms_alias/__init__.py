"""
An alias is a collection of plugins that is managed centrally.
A reference can be added to any placeholder using the Alias plugin.
"""

__version__ = "3.0.1"
