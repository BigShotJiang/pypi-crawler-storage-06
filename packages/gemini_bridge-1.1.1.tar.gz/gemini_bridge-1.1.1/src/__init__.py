"""Gemini Bridge MCP server."""

from .mcp_server import main

__version__ = "1.1.1"
__all__ = ["main"]
