- Ismael Calvo \<<ismael.calvo@es.gt.com>\>

- Michael Michot \<<michotm@gmail.com>\>

- Koen Loodts \<<koen.loodts@dynapps.be>\>

- [Tecnativa](https://www.tecnativa.com):  
  - Vicent Cubells \<<vicent.cubells@tecnativa.com>\>
  - Manuel Calero - Tecnativa

- Tharathip Chaweewongphan \<<tharathipc@ecosoft.co.th>\>

- Alan Ramos \<<alan.ramos@jarsa.com>\>
