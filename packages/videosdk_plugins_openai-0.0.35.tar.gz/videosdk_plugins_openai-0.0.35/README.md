# VideoSDK OpenAI Plugin

Agent Framework plugin for realtime, LLM, STT and TTS services from OpenAI.

## Installation

```bash
pip install videosdk-plugins-openai
```