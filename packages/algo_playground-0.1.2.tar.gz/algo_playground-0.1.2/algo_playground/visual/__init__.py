from __future__ import annotations

__all__ = ["animate_sorting", "animate_binary_search", "animate_graph_traversal"]
