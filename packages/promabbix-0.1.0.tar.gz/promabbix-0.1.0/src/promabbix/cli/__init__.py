# CLI module for promabbix commands
