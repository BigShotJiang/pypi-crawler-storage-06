"""UpDay plugin for ofxstatement"""

from ofxstatement_upday.upday import UpDayPlugin
