export const environment = {
  production: true,
  serviceWorkerEnabled: true,
};
