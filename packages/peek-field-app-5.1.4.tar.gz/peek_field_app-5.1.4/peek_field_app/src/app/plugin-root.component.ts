import { Component } from "@angular/core";

@Component({
  selector: "peek-main-root-components",
  templateUrl: "../@_peek/plugin-root.component.web.html",
})
export class PluginRootComponent {
  constructor() {}
}
