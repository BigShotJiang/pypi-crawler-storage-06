# Contribution to MNE-LSL

Contribution of all sorts are the welcome in MNE-LSL. Please fork the repository
and open a PR with changes applied on your fork for review. See the
[contributing instructions online](https://mne.tools/mne-lsl/stable/development/contributing.html)
to run the documentation build and the unit tests locally.
