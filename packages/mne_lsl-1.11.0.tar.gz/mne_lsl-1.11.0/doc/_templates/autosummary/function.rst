{{ fullname | escape | underline }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. minigallery:: {{ fullname }}
    :add-heading:
