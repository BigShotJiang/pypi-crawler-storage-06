Legacy
------

.. currentmodule:: mne_lsl.stream_viewer

Legacy classes and functions will be replaced with backward incompatible equivalent in
future versions.

.. autosummary::
    :toctree: ../generated/api
    :nosignatures:

    StreamViewer
