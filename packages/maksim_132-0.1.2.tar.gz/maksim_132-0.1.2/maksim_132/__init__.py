from .mousecolor import mousecolor, stop

__version__ = "0.1.2"
__all__ = ['mousecolor', 'stop']