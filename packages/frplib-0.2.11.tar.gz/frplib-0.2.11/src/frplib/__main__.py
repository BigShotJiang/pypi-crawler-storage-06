# SPDX-FileCopyrightText: 2023-present Christopher R. Genovese <genovese@cmu.edu>
#
# SPDX-License-Identifier: MIT
import sys

if __name__ == "__main__":
    from frplib.cli import frp

    sys.exit(frp())
