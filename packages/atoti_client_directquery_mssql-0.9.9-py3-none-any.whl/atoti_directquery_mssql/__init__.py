"""Code to use DirectQuery with `Microsoft SQL Server <https://www.microsoft.com/en-us/sql-server>`__."""

from .connection_config import ConnectionConfig as ConnectionConfig
from .table_config import TableConfig as TableConfig
