PKG_NAME = "bbuploader"

FILE_FOLDER_NAME = "geo_files"

DEFAULT_GEO_TAG = "samples"


class STATUS:
    SUCCESS = "SUCCESS"
    FAIL = "FAIL"
    PARTIAL = "PARTIAL"
    PROCESSING = "PROCESSING"
    SKIPPED = "SKIPPED"
