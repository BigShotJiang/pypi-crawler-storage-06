from .fm import approx_FM_new

__all__ = ["approx_FM_new"]
__version__ = "0.1.0"
