# iatoolkit-core

Un toolkit de herramientas de IA para desarrollo y análisis.

## Instalación

bash pip install iatoolkit-core


## Uso básico

```python
from iatoolkit import *

# Aquí va tu código de ejemplo
```

## Contribuir

Las contribuciones son bienvenidas. 
Por favor, abre un issue o envía un pull request.

## Licencia
MIT License

## 2. Configurar GitHub Actions

Crea la carpeta `.github/workflows/` y el archivo `publish.yml`:
