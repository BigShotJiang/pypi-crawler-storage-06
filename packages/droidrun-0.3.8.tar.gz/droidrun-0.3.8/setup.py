"""
Setup file for backward compatibility.
Configuration is handled by pyproject.toml
"""

from setuptools import setup

setup() 