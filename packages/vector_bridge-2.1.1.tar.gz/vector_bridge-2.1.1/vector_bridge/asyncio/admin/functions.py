from typing import Union
from collections.abc import Callable

from vector_bridge import AsyncVectorBridgeClient
from vector_bridge.schema.errors.functions import raise_for_function_detail
from vector_bridge.schema.functions import (CodeExecuteFunctionCreate,
                                            CodeExecuteFunctionUpdate,
                                            Function, FunctionExtractor,
                                            JsonFunctionCreate,
                                            JsonFunctionUpdate,
                                            SemanticSearchFunctionCreate,
                                            SemanticSearchFunctionUpdate,
                                            SimilarSearchFunctionCreate,
                                            SimilarSearchFunctionUpdate,
                                            SummaryFunctionCreate,
                                            SummaryFunctionUpdate)


class AsyncFunctionsAdmin:
    """Async admin client for functions management endpoints."""

    def __init__(self, client: AsyncVectorBridgeClient):
        self.client = client

    async def add_function(
        self,
        function_data: (
            SemanticSearchFunctionCreate |
            SimilarSearchFunctionCreate |
            SummaryFunctionCreate |
            JsonFunctionCreate |
            CodeExecuteFunctionCreate
        ),
        integration_name: str = None,
    ) -> Function:
        """
        Add new Function to the integration.

        Args:
            function_data: Function details
            integration_name: The name of the Integration

        Returns:
            Created function object
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/function/create"
        params = {"integration_name": integration_name}
        headers = self.client._get_auth_headers()

        async with self.client.session.post(
            url, headers=headers, params=params, json=function_data.model_dump()
        ) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_function_detail)
            return Function.to_valid_subclass(result)

    async def add_python_function(
        self,
        function: Callable,
        integration_name: str = None,
    ) -> Function:
        """
        Add a Python function directly.

        This automatically extracts the function's code, signature, and documentation
        to create a CODE_EXEC function that can be called remotely.

        Args:
            function: The Python function to add (must have type annotations and docstrings)
            integration_name: The name of the Integration

        Returns:
            Created function object
        """
        # Extract function metadata and code
        extractor = FunctionExtractor(function)
        function_data = extractor.get_function_metadata()

        # Create the CodeExecuteFunctionCreate model
        function_model = CodeExecuteFunctionCreate.model_validate(function_data)

        # Call the existing add_function method
        return await self.add_function(function_model, integration_name)

    async def update_function(
        self,
        function_id: str,
        function_data: (
            SemanticSearchFunctionUpdate |
            SimilarSearchFunctionUpdate |
            SummaryFunctionUpdate |
            JsonFunctionUpdate |
            CodeExecuteFunctionUpdate
        ),
        integration_name: str = None,
    ) -> Function:
        """
        Update an existing Function.

        Args:
            function_id: The ID of the Function to update
            function_data: Updated function details
            integration_name: The name of the Integration

        Returns:
            Updated function object
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/function/{function_id}/update"
        params = {"integration_name": integration_name}
        headers = self.client._get_auth_headers()

        async with self.client.session.put(
            url, headers=headers, params=params, json=function_data.model_dump()
        ) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_function_detail)
            return Function.to_valid_subclass(result)

    async def delete_function(self, function_id: str, integration_name: str = None) -> None:
        """
        Delete a function.

        Args:
            function_id: The ID of the function to delete
            integration_name: The name of the Integration
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        url = f"{self.client.base_url}/v1/admin/function/{function_id}/delete"
        params = {"integration_name": integration_name}
        headers = self.client._get_auth_headers()

        async with self.client.session.delete(url, headers=headers, params=params) as response:
            await self.client._handle_response(response=response, error_callable=raise_for_function_detail)
