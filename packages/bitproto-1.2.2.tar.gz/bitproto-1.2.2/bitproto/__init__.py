"""
bitproto
~~~~~~~~

Bit level data interchange format.

:copyright: (c) 2020~2025 by Chao Wang <hit9@icloud.com>.

"""

__version__ = "1.2.2"
__description__ = "bit level data interchange format."
