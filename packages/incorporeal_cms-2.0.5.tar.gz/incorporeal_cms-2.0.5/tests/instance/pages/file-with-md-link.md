[Foo](foo.md)
[Anchored Foo](foo.md#anchor)
[Sub Foo](sub/foo.md)
[Anchored Sub Foo](sub/foo.md#anchor)
