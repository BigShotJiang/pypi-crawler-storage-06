# test of figures

|> ![fancy captioned logo](bss-square-no-bg.png)
|: this is my cool logo!
{: .right }

|> ![vanilla captioned logo](bss-square-no-bg.png)
|: this is my cool logo without an attr!

|> ![fancy logo](bss-square-no-bg.png)
{: .left }

|> ![just a logo](bss-square-no-bg.png)
