# test

test
~~~{ pydot:attack-plan }
    rankdir=LR
    Earth
    Mars
    Earth -> Mars
}
~~~
more test
