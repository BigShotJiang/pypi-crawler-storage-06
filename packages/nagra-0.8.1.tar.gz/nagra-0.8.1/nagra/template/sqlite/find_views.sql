SELECT name, sql from sqlite_master WHERE type = 'view';
