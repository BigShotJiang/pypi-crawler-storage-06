CREATE VIEW "{{name}}" AS {{view_def}};
