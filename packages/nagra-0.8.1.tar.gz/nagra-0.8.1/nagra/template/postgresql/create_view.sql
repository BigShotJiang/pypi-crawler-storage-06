CREATE OR REPLACE VIEW  "{{name}}" AS {{view_def}};
