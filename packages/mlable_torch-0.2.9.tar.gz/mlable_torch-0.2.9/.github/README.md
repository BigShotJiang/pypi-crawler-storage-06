# MLable

PyTorch libs: layers, blocks, optimizers, etc.

## TODO

See [TODO](TODO.md).

## License

Licensed under the [aGPLv3](LICENSE.md).

[code-micrograd]: https://github.com/karpathy/micrograd
[video-karpathy]: https://www.youtube.com/@AndrejKarpathy/videos
