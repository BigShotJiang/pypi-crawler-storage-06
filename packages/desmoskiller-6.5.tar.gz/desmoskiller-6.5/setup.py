from setuptools import setup

setup(name="DesmosKiller",
      version="6.5",
      packages=["DesmosKiller"],
      author="YusufA442",
      author_email="yusuf365820@gmail.com",
      license='Creative Commons Attribution-Noncommercial-Share Alike license',
      long_description=open('readme.txt').read())