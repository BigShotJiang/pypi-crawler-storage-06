"""titiler.core.resources."""
