from ._model_adapter import create_model_adapter

__all__ = ["create_model_adapter"]
