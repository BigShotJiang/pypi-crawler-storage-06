__VERSION__ = "0.1.15"
LOGGER_NAME = "fractal-health"
