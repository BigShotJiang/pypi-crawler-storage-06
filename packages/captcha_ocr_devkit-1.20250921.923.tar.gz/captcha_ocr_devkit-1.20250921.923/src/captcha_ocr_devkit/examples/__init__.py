"""
CAPTCHA OCR 範例和範本

這個目錄包含了各種 handler 的範例實作
"""
