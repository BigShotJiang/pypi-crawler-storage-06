TYPE_ALIAS = {
    "uint": "uint256",
    "int": "int256",
}
GAS_BUFFER = 100000
