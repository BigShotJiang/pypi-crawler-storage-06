"""Tests for finlab-guard package."""
