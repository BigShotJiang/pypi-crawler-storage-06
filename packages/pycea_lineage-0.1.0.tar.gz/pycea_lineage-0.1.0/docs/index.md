```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 1

notebooks/getting-started
notebooks/plotting
notebooks/growth-dynamics

api.md
changelog.md
contributing.md
references.md

```
