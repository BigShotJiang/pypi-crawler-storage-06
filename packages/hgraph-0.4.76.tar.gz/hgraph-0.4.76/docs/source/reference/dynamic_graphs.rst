Dynamic Graphs
==============

.. autofunction:: hgraph.map_

.. autofunction:: hgraph.reduce

.. autofunction:: hgraph.switch_

.. autofunction:: hgraph.mesh_

