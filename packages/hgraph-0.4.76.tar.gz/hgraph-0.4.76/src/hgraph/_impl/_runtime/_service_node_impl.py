from hgraph._impl._runtime._nested_graph_node import PythonNestedGraphNodeImpl


class PythonServiceNodeImpl(PythonNestedGraphNodeImpl):
    pass
