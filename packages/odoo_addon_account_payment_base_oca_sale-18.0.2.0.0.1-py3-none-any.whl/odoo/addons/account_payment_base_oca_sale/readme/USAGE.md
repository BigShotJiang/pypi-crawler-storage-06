You are able to add a payment mode directly on a partner. This payment
mode is automatically associated to the sale order, then copied to the
related customer invoices. This default value can be changed on sale orders and/or on
draft customer invoices.
