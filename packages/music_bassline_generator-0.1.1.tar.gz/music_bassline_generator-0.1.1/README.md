# Music Bassline-Generator
Generate musical basslines

## DESCRIPTION

TODO

## SYNOPSIS
```python
# TODO
```

## MUSICAL EXAMPLES
```python
# TODO
```
