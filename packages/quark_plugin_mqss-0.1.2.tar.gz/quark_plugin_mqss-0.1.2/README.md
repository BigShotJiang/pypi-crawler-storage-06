# QUARK-plugin-mqss

### Provided Modules:

| Module           | Upstream Interface                   | Downstream Interface                 |
|------------------|--------------------------------------|--------------------------------------|
| circuit_provider | None                                 | quark.interface_types.other[circuit] |
| job_execution    | quark.interface_types.other[circuit] | None                                 |
