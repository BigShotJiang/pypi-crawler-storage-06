from django.apps import AppConfig


class FrenchHighSchoolConfig(AppConfig):
    name = "french_highschool"
    verbose_name = "Ecoles françaises"
