# Pygments Styles

A curated collection of Pygments styles based on VS Code themes.
