__version__ = "0.1.0"
__author__ = "Hsiaoming Yang <me@lepture.com>"
__license__ = "BSD-3-Clause"
