"""Website discovery pipeline for Legacy Web MCP."""

from legacy_web_mcp.discovery.pipeline import WebsiteDiscoveryService

__all__ = ["WebsiteDiscoveryService"]
