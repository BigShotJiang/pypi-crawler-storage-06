import typer

email_app = typer.Typer()
