#!/usr/bin/env bash

# export OCT_VERSION=
# export OCT_AUTOUPDATE=

# export LOAD_ON_START=

export DEVICE=cpu
# export OCT_BASE_DIR=
# export DATABASE_NAME=

export DJANGO_DEBUG=true
export DJANGO_LOG_LEVEL=INFO

./run.sh
