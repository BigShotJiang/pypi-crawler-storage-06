

  **Markdown**

  ```markdown
[![GitHub Clones](https://img.shields.io/badge/dynamic/json?color=success&label=Clone&query=count&url=https://gist.githubusercontent.com/ocpm/14f03deaf32d51b785ee31e71447857a/raw/clone.json&logo=github)](https://github.com/MShawon/github-clone-count-badge)

  ```

  **HTML**
  ```html
<a href='https://github.com/MShawon/github-clone-count-badge'><img alt='GitHub Clones' src='https://img.shields.io/badge/dynamic/json?color=success&label=Clone&query=count&url=https://gist.githubusercontent.com/ocpm/14f03deaf32d51b785ee31e71447857a/raw/clone.json&logo=github'></a>
```
