ocpa.algo.conformance.pattern.versions package
==============================================

Submodules
----------

ocpa.algo.conformance.pattern.versions.log\_based module
--------------------------------------------------------

.. automodule:: ocpa.algo.conformance.pattern.versions.log_based
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.conformance.pattern.versions.model\_based module
----------------------------------------------------------

.. automodule:: ocpa.algo.conformance.pattern.versions.model_based
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.conformance.pattern.versions
   :members:
   :undoc-members:
   :show-inheritance:
