ocpa.algo.util.process\_executions package
==========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.util.process_executions.versions

Submodules
----------

ocpa.algo.util.process\_executions.factory module
-------------------------------------------------

.. automodule:: ocpa.algo.util.process_executions.factory
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.util.process_executions
   :members:
   :undoc-members:
   :show-inheritance:
