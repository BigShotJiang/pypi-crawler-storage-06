ocpa.algo.conformance.pattern package
=====================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.conformance.pattern.versions

Submodules
----------

ocpa.algo.conformance.pattern.algorithm module
----------------------------------------------

.. automodule:: ocpa.algo.conformance.pattern.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.conformance.pattern
   :members:
   :undoc-members:
   :show-inheritance:
