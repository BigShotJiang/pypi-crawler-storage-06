ocpa.util.filtering.graph.event\_graph package
==============================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.util.filtering.graph.event_graph.versions

Submodules
----------

ocpa.util.filtering.graph.event\_graph.algorithm module
-------------------------------------------------------

.. automodule:: ocpa.util.filtering.graph.event_graph.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.util.filtering.graph.event_graph
   :members:
   :undoc-members:
   :show-inheritance:
