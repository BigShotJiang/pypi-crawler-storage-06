ocpa.algo.discovery.mvp.projection.versions package
===================================================

Submodules
----------

ocpa.algo.discovery.mvp.projection.versions.activity\_occurrence module
-----------------------------------------------------------------------

.. automodule:: ocpa.algo.discovery.mvp.projection.versions.activity_occurrence
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.discovery.mvp.projection.versions.classic module
----------------------------------------------------------

.. automodule:: ocpa.algo.discovery.mvp.projection.versions.classic
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.discovery.mvp.projection.versions.object\_count module
----------------------------------------------------------------

.. automodule:: ocpa.algo.discovery.mvp.projection.versions.object_count
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.discovery.mvp.projection.versions
   :members:
   :undoc-members:
   :show-inheritance:
