ocpa.visualization.pattern\_graph package
=========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.visualization.pattern_graph.versions

Submodules
----------

ocpa.visualization.pattern\_graph.algorithm module
--------------------------------------------------

.. automodule:: ocpa.visualization.pattern_graph.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.visualization.pattern_graph
   :members:
   :undoc-members:
   :show-inheritance:
