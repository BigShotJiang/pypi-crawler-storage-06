ocpa.objects.log.importer.csv.versions package
==============================================

Submodules
----------

ocpa.objects.log.importer.csv.versions.to\_df module
----------------------------------------------------

.. automodule:: ocpa.objects.log.importer.csv.versions.to_df
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.objects.log.importer.csv.versions.to\_obj module
-----------------------------------------------------

.. automodule:: ocpa.objects.log.importer.csv.versions.to_obj
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.objects.log.importer.csv.versions.to\_ocel module
------------------------------------------------------

.. automodule:: ocpa.objects.log.importer.csv.versions.to_ocel
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.objects.log.importer.csv.versions
   :members:
   :undoc-members:
   :show-inheritance:
