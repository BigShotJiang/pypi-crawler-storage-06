ocpa.algo.filtering.log package
===============================

Submodules
----------

ocpa.algo.filtering.log.activity\_filtering module
--------------------------------------------------

.. automodule:: ocpa.algo.filtering.log.activity_filtering
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.filtering.log.case\_filtering module
----------------------------------------------

.. automodule:: ocpa.algo.filtering.log.case_filtering
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.filtering.log.time\_filtering module
----------------------------------------------

.. automodule:: ocpa.algo.filtering.log.time_filtering
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.filtering.log.variant\_filtering module
-------------------------------------------------

.. automodule:: ocpa.algo.filtering.log.variant_filtering
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.filtering.log
   :members:
   :undoc-members:
   :show-inheritance:
