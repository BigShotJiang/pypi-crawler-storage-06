ocpa package
============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo
   ocpa.objects
   ocpa.util
   ocpa.visualization

Module contents
---------------

.. automodule:: ocpa
   :members:
   :undoc-members:
   :show-inheritance:
