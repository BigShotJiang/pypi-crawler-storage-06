ocpa.algo.evaluation.precision\_and\_fitness package
====================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.evaluation.precision_and_fitness.variants

Submodules
----------

ocpa.algo.evaluation.precision\_and\_fitness.evaluator module
-------------------------------------------------------------

.. automodule:: ocpa.algo.evaluation.precision_and_fitness.evaluator
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.evaluation.precision\_and\_fitness.utils module
---------------------------------------------------------

.. automodule:: ocpa.algo.evaluation.precision_and_fitness.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.evaluation.precision_and_fitness
   :members:
   :undoc-members:
   :show-inheritance:
