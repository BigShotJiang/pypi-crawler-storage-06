ocpa.algo.feature\_extraction package
=====================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.feature_extraction.event_based_features
   ocpa.algo.feature_extraction.execution_based_features

Submodules
----------

ocpa.algo.feature\_extraction.factory module
--------------------------------------------

.. automodule:: ocpa.algo.feature_extraction.factory
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.feature\_extraction.obj module
----------------------------------------

.. automodule:: ocpa.algo.feature_extraction.obj
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.feature\_extraction.sequential module
-----------------------------------------------

.. automodule:: ocpa.algo.feature_extraction.sequential
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.feature\_extraction.tabular module
--------------------------------------------

.. automodule:: ocpa.algo.feature_extraction.tabular
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.feature\_extraction.time\_series module
-------------------------------------------------

.. automodule:: ocpa.algo.feature_extraction.time_series
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.feature_extraction
   :members:
   :undoc-members:
   :show-inheritance:
