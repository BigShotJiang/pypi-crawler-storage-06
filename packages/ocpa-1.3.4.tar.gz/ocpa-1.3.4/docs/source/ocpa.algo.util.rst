ocpa.algo.util package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.util.filtering
   ocpa.algo.util.process_executions
   ocpa.algo.util.retrieval
   ocpa.algo.util.variants

Submodules
----------

ocpa.algo.util.util module
--------------------------

.. automodule:: ocpa.algo.util.util
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.util
   :members:
   :undoc-members:
   :show-inheritance:
