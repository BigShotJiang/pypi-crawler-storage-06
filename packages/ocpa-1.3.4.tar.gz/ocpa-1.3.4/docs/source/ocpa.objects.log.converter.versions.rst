ocpa.objects.log.converter.versions package
===========================================

Submodules
----------

ocpa.objects.log.converter.versions.csv\_to\_ocel module
--------------------------------------------------------

.. automodule:: ocpa.objects.log.converter.versions.csv_to_ocel
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.objects.log.converter.versions.jsonocel\_to\_csv module
------------------------------------------------------------

.. automodule:: ocpa.objects.log.converter.versions.jsonocel_to_csv
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.objects.log.converter.versions
   :members:
   :undoc-members:
   :show-inheritance:
