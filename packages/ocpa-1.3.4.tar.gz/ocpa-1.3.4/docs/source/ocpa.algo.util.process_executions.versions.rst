ocpa.algo.util.process\_executions.versions package
===================================================

Submodules
----------

ocpa.algo.util.process\_executions.versions.connected\_components module
------------------------------------------------------------------------

.. automodule:: ocpa.algo.util.process_executions.versions.connected_components
   :members:
   :undoc-members:
   :show-inheritance:

ocpa.algo.util.process\_executions.versions.leading\_type module
----------------------------------------------------------------

.. automodule:: ocpa.algo.util.process_executions.versions.leading_type
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.util.process_executions.versions
   :members:
   :undoc-members:
   :show-inheritance:
