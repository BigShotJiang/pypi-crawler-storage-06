ocpa.algo.filtering.graph.event\_graph package
==============================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.filtering.graph.event_graph.versions

Submodules
----------

ocpa.algo.filtering.graph.event\_graph.algorithm module
-------------------------------------------------------

.. automodule:: ocpa.algo.filtering.graph.event_graph.algorithm
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ocpa.algo.filtering.graph.event_graph
   :members:
   :undoc-members:
   :show-inheritance:
