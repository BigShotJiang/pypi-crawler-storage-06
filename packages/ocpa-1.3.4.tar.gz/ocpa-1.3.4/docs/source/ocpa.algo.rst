ocpa.algo package
=================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ocpa.algo.conformance
   ocpa.algo.discovery
   ocpa.algo.enhancement
   ocpa.algo.predictive_monitoring
   ocpa.algo.util

Module contents
---------------

.. automodule:: ocpa.algo
   :members:
   :undoc-members:
   :show-inheritance:
