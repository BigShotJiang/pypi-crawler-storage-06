
DEFAULT_TIMESTAMP_KEY = 'time:timestamp'
DEFAULT_OCEL_TIMESTAMP_KEY = 'event_timestamp'
DEFAULT_START_TIMESTAMP_KEY = 'event_start_timestamp'
DEFAULT_OCEL_START_TIMESTAMP_KEY = 'start_timestamp'

CONN_COMP= "connected_components"
LEAD_TYPE = "leading_type"

TWO_PHASE= "two_phase"
ONE_PHASE = "one_phase"
