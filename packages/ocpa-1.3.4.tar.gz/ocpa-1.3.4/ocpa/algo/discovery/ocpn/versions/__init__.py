from ocpa.algo.discovery.ocpn.versions import inductive
from ocpa.algo.discovery.ocpn.versions import new_inductive
