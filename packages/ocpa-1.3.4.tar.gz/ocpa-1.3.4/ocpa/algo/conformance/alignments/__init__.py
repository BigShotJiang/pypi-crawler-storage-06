import ocpa.algo.conformance.alignments.alignment
import ocpa.algo.conformance.alignments.algorithm
import ocpa.algo.conformance.alignments.helperfunctions