from ocpa.algo.util.variants.versions import twophase
from ocpa.algo.util.variants.versions import onephase
