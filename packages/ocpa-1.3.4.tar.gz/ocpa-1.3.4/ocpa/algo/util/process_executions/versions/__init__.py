import ocpa.algo.util.process_executions.versions.connected_components
import ocpa.algo.util.process_executions.versions.leading_type
