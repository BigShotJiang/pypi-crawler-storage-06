# silverback.exceptions

```{eval-rst}
.. automodule:: silverback.exceptions
    :members:
    :show-inheritance:
```
