__version__ = "0.2.38"

def get_versions():
    return {"version": __version__}
