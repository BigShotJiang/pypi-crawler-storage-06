"""Integration tests for augint-org."""
