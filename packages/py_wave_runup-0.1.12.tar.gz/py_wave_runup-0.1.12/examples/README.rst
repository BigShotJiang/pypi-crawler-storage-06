Examples
~~~~~~~~

Here we show examples of how to apply py-wave-runup in practice: