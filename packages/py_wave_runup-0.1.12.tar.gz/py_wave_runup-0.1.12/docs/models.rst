Wave runup models
=========================

.. automodule:: models
   :members:
   :undoc-members:

   .. autosummary::
        :nosignatures:

        Stockdon2006
        Power2018
        Holman1986
        Nielsen2009
        Ruggiero2001
        Vousdoukas2012
        Senechal2011
        Beuzen2019
        Passarella2018
