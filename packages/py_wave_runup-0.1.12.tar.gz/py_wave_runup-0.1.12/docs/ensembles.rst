Ensemble models
==========================

.. automodule:: ensembles
   :members:
   :undoc-members:

   .. autosummary::
        :nosignatures:

        EnsembleRaw
        EnsembleMean