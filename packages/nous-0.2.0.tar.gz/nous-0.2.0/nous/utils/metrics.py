from __future__ import annotations
# Placeholder for future metric utilities