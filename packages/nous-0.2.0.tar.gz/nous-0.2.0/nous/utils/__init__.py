from .seed import set_global_seed

__all__ = ["set_global_seed"]