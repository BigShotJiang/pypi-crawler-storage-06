from typing import Any

TensorLike = Any
NDArrayLike = Any