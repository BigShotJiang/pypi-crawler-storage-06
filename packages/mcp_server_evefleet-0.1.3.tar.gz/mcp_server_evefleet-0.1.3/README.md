mcp-name: io.github.tedfytw1209/mcp-server-EVEfleet

https://pypi.org/project/mcp-server-evefleet/#description

