from demalign.core import detect_asp
assert callable(detect_asp)
