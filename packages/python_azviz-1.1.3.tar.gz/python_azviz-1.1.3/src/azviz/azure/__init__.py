"""Azure integration module."""

from .client import AzureClient

__all__ = ["AzureClient"]