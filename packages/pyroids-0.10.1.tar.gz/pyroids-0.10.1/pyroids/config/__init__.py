r"""Config subpackage.

See pyroids\config\template.py for instructions on setting up configuration
files.
"""
