from jst_django.commands import *  # noqa
from jst_django.cli.app import app


if __name__ == "__main__":
    app()
