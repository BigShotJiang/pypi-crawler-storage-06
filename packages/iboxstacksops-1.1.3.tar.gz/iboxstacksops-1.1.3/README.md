# AwsIBoxStackOps
Aws Infrastucture in a Box - Stacks management program.

Used to create and update an AWS CloudFormation stack in a simple way.

## Installation ##
`pip install iboxstacksops`

## License ##

This software is distributed under the terms of the MIT [license](LICENSE).
