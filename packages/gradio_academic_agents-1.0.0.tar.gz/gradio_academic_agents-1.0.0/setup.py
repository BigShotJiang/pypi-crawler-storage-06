import setuptools


setuptools.setup(
        name = "gradio-academic-agents",
        version = "1.0.0",
        author = "AIOAGI",
        author_email = "aioagi@aioagi.tech",
        description = "gradio for academic agents studio",
        long_description = "gradio for academic agents studio",
        long_description_content_type = "text/markdown",
        url = "https://github.com/AcademicAgentsStudio",
        packages = setuptools.find_packages(),
        classifiers=[
        "Programming Language :: Python :: 3",
            ],
        )
