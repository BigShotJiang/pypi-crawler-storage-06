import resources.runner.example_module_a as example_module_a
from ordeq import run

run(example_module_a, verbose=True)
