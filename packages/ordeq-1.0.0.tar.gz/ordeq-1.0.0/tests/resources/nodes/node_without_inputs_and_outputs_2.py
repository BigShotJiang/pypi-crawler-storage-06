from ordeq import node


@node
def func() -> None:
    pass
