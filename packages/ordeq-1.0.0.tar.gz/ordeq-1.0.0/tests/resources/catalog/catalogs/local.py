from ordeq_common import StringBuffer

hello = StringBuffer("Hello from local")
result = StringBuffer()
