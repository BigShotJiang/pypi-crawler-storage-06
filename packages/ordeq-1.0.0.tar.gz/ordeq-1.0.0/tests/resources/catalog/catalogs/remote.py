from ordeq_common import StringBuffer

hello = StringBuffer("Hello from remote")
result = StringBuffer()
