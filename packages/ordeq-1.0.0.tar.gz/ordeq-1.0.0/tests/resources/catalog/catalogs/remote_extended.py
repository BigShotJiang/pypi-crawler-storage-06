from resources.catalog.catalogs.remote import *  # 'remote' is the catalog that is extended

from ordeq_common import Print

another_io = Print()  # this IO is not defined in the base catalog
