from ordeq_common import StringBuffer

hello = StringBuffer("Hello from remote")
# This catalog does not define an IO for 'result' = StringBuffer()
