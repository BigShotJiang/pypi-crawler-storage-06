This module allows you to manage branded contracts. It adds a brand
field on the contract and propagate the value on the invoices.
