from sklearn.mixture import BayesianGaussianMixture as CluModel


def clu_figs(cfg, stage):

