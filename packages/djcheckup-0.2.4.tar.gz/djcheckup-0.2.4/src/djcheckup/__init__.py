"""DJ Checkup CLI package."""

from djcheckup.run import run_checks

__all__ = ["run_checks"]
