import plugin from './plugin';

export default plugin;
