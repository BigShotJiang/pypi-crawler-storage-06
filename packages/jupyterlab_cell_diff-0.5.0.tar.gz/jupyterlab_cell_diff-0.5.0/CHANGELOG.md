# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 0.5.0

([Full Changelog](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/compare/v0.4.2...787f10383f9ce4eb2b6d781b57ddd808b859b14c))

### New features added

- Allow diffing with `@codemirror/merge` [#6](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/pull/6) ([@jtpio](https://github.com/jtpio))

### Enhancements made

- Localize user-facing strings with `ITranslator` [#8](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/pull/8) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Drop support for `nbdime` diffs [#12](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/pull/12) ([@jtpio](https://github.com/jtpio))
- Fix links after the move to the `jupyter-ai-contrib` organization [#7](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/pull/7) ([@jtpio](https://github.com/jtpio))
- Delete Untitled.ipynb [#4](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/pull/4) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/graphs/contributors?from=2025-01-03&to=2025-09-17&type=c))

[@jtpio](https://github.com/search?q=repo%3Ajupyter-ai-contrib%2Fjupyterlab-cell-diff+involves%3Ajtpio+updated%3A2025-01-03..2025-09-17&type=Issues)

<!-- <END NEW CHANGELOG ENTRY> -->

## 0.4.2

([Full Changelog](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/compare/v0.4.1...822c684ae378d6c22af60940bf38d0f7c2a89ab4))

### Bugs fixed

- add logic to remove the 'compare' button [#2](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/pull/2) ([@Zsailer](https://github.com/Zsailer))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/graphs/contributors?from=2025-01-03&to=2025-01-03&type=c))

[@Zsailer](https://github.com/search?q=repo%3AZsailer%2Fjupyterlab-cell-diff+involves%3AZsailer+updated%3A2025-01-03..2025-01-03&type=Issues)

## 0.4.1

([Full Changelog](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/compare/v0.4.0...8a4b27aaef88370762f7173b94d472be7b230e52))

### Enhancements made

- Remove old diffs when a new diff is created [#1](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/pull/1) ([@Zsailer](https://github.com/Zsailer))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-ai-contrib/jupyterlab-cell-diff/graphs/contributors?from=2024-12-20&to=2025-01-03&type=c))

[@Zsailer](https://github.com/search?q=repo%3AZsailer%2Fjupyterlab-cell-diff+involves%3AZsailer+updated%3A2024-12-20..2025-01-03&type=Issues)

## 0.4.0

No merged PRs

## 0.3.0

No merged PRs

## 0.2.0

No merged PRs

## 0.1.2

No merged PRs

## 0.1.1

No merged PRs
