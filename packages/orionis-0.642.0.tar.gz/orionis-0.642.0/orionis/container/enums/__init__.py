from .lifetimes import Lifetime

__all__ = [
    "Lifetime"
]