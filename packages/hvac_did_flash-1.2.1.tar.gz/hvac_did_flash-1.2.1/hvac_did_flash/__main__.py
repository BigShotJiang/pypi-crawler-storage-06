#!/usr/bin/env python3
"""Entry point for running hvac_did_flash as a module."""

from .did_flash import main

if __name__ == "__main__":
    main()