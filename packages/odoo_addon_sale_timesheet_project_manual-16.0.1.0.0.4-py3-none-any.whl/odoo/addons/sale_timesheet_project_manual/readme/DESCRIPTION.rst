Allows to create the project/tasks before the sale confirmation.
