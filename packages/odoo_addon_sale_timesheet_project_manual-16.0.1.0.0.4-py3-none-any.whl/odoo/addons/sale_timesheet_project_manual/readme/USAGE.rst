To use this module, you need to:

#. Create a service product and set its service tracking to *Create a task* or *Create a project*
#. Create a SO and select the previous product
#. When the SO is in draft, a button *Generate Project/Task* is available and it will create the project and tasks based on the order lines
