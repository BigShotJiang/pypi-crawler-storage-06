* `Acsone <https://www.acsone.eu/>`__

  * Benjamin Willig <benjamin.willig@acsone.eu>
  * Maxime Franco <maxime.franco@acsone.eu>
