.. automodule:: verry.typing
