.. automodule:: verry.affineform
