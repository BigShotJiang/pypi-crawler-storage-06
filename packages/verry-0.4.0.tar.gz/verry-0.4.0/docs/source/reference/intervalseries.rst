.. automodule:: verry.intervalseries
