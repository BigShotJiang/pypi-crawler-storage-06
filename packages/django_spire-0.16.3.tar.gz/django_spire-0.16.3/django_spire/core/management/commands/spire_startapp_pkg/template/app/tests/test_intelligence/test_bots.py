from django.test import TestCase


class SpireChildAppBotTestCase(TestCase):
    def setUp(self):
        super().setUp()
