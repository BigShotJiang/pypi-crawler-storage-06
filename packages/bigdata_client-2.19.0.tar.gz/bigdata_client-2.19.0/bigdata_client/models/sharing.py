from bigdata_client.enum_utils import StrEnum


class SharePermission(StrEnum):
    READ = "read"
    UNDEFINED = "undefined"
