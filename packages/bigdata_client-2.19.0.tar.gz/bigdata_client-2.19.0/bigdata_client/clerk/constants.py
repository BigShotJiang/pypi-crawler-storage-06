from enum import Enum


class ClerkInstanceType(str, Enum):
    DEV = "DEV"
    PROD = "PROD"
