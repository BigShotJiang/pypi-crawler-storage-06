"""
blueprint - Project structure generator
"""

__version__ = "0.1.0"

from .core import Blueprint
