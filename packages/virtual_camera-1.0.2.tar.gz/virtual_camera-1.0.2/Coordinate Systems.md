## **Coordinate Systems**

- openGL-style x-y-z:  right-up-backward
- image-style x-y-z:   right-down-forward
- motovis-style x-y-z: right-forward-up

|   STYLE   |       X-Y-Z        |
| :-------: | :----------------: |
|  MOTOVIS  |  right-forward-up  |
|  openGL   | right-up-backward  |
|   image   | right-down-forward |
| pytorch3d |  left-up-forward   |

