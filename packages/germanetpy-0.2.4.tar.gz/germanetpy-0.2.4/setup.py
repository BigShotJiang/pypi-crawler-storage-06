import pathlib
import setuptools
#import requests
#
#session = requests.Session()
#session.verify = False

# The directory containing this file
HERE = pathlib.Path(__file__).parent
requirements = ["numpy>=1.18.1", "lxml>=4.4.2", "pytest>=5.3.2", "fastenum>=0.0.1", "tqdm>=4.14",
                "python-Levenshtein==0.25.1"]

# The text of the README file
long_description = (HERE / "README.md").read_text()
setuptools.setup(
    name="germanetpy",
    version="0.2.4",
    author="Ben Campbell",
    author_email="ben.campbell@uni-tuebingen.de",
    description="Python API for GermaNet",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Germanet-sfs/germanetpy.git",
    install_requires=requirements,
    packages=["germanetpy"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
    ],
)
