



# !!!IMPORTANT!!!

- Always use `docker compose` instead of `docker-compose`