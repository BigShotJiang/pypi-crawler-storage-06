"""Admin API tools for members management."""

from fastmcp import FastMCP


def register_admin_member_tools(mcp: FastMCP) -> None:
    """Register member management Admin API tools."""
    # Member management tools would go here
    pass