from django.apps import AppConfig


class BootyPrintConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bootyprint'
    verbose_name = 'BootyPrint'
