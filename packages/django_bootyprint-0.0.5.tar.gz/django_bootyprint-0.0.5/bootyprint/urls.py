urlpatterns = []
from django.urls import path

# Empty urlpatterns as this is just for tests
urlpatterns = []
