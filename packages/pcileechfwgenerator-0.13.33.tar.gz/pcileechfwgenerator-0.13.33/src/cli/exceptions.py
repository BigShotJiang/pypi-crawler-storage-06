"""VFIO-related exception classes."""
