"""Unit test package for django_msteams_notify."""
