from pytestifyx.utils.data_factory.run import MakeData

md = MakeData()
