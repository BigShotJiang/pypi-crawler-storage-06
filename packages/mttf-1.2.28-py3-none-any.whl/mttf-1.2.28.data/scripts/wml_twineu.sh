#/!bin/bash
wml_nexus.py uv publish --allow-insecure-host "localhost" --publish-url https://localhost:5443/repository/ml-py-repo/ --username minhtri --password Winnow2019python $@
