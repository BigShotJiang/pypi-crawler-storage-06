.. title:: Table of Contents

#######################
Ncpol2sdpa User's Guide
#######################


.. toctree::
   :maxdepth: 2
  
   introduction.rst
   download.rst
   tutorial.rst
   examples.rst
   revision_history.rst
   reference.rst
   bibliography.rst
   
