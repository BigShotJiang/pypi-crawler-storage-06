from MK_SSL.multimodal.models.utils.registry import get_method, register_method

__all__ = [
    "get_method",
    "register_method",
]