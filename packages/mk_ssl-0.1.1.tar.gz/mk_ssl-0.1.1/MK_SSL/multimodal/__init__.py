from MK_SSL.multimodal.Trainer import Trainer

__all__ = ["Trainer"]
