// User menu removed for local usage
