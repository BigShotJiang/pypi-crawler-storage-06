type CoWorkBenchStatusControlType = {
    isTerminated: boolean
    isFetchingAgentAction: boolean
    isFetchingObservation: boolean
    isWaitingForHumanResponse: boolean
    isWaitingForHumanAction: boolean
}