# Changelog

See changelog for `pumpkin-solver`.
