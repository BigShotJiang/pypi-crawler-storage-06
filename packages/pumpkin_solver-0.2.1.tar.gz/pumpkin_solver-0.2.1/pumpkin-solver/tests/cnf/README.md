# DIMACS CNF Tests
These are the test instances for the CNF functionality of the solver. The tests 
are taken from the [CaDiCaL](https://github.com/arminbiere/cadical) repository.
