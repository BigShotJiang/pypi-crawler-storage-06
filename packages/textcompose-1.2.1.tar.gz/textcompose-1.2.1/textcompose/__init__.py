__all__ = ["Template"]

import importlib.metadata as _metadata

from textcompose.template import Template

__version__ = _metadata.version("textcompose")
