__all__ = ["If"]

from textcompose.logics.if_then_else import If
