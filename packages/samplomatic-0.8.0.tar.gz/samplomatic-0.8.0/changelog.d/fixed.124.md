Fixed a bug where `Samplex.__str__()` would raise an error for samplexes that require a noise model.
