samplomatic.distributions package
=================================

.. automodule:: samplomatic.distributions
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

samplomatic.distributions.distribution module
---------------------------------------------

.. automodule:: samplomatic.distributions.distribution
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.distributions.haar\_u2 module
-----------------------------------------

.. automodule:: samplomatic.distributions.haar_u2
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.distributions.uniform\_pauli module
-----------------------------------------------

.. automodule:: samplomatic.distributions.uniform_pauli
   :members:
   :show-inheritance:
   :undoc-members:
