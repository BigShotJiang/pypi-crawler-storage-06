samplomatic.virtual\_registers package
======================================

.. automodule:: samplomatic.virtual_registers
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

samplomatic.virtual\_registers.group\_register module
-----------------------------------------------------

.. automodule:: samplomatic.virtual_registers.group_register
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.virtual\_registers.pauli\_register module
-----------------------------------------------------

.. automodule:: samplomatic.virtual_registers.pauli_register
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.virtual\_registers.u2\_register module
--------------------------------------------------

.. automodule:: samplomatic.virtual_registers.u2_register
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.virtual\_registers.virtual\_register module
-------------------------------------------------------

.. automodule:: samplomatic.virtual_registers.virtual_register
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.virtual\_registers.z2\_register module
--------------------------------------------------

.. automodule:: samplomatic.virtual_registers.z2_register
   :members:
   :show-inheritance:
   :undoc-members:
