samplomatic.synths package
==========================

.. automodule:: samplomatic.synths
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

samplomatic.synths.get\_synth module
------------------------------------

.. automodule:: samplomatic.synths.get_synth
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.synths.rzrx\_synth module
-------------------------------------

.. automodule:: samplomatic.synths.rzrx_synth
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.synths.rzsx\_synth module
-------------------------------------

.. automodule:: samplomatic.synths.rzsx_synth
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.synths.synth module
-------------------------------

.. automodule:: samplomatic.synths.synth
   :members:
   :show-inheritance:
   :undoc-members:
