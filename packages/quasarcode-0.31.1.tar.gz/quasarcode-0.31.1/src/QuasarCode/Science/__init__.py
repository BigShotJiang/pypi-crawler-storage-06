#from .fitline import LineType, LineOfBestFit
#from .graph import Graph
#from .figure import ManualFigure, Figure, DrawInstruction
from .data import consistancy_test, is_consistant, error_string, sig_fig, standard_form, standard_form_string, standard_form_string_if_nessessary, true_round
from ._plotting import polygon_y_error_region, polygon_x_error_region
