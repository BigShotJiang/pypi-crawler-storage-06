from .gains import CapitalGainsReport

__all__ = ["CapitalGainsReport"]
