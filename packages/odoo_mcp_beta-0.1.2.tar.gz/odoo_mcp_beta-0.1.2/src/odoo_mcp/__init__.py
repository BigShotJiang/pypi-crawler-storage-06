"""
Odoo MCP Server - MCP Server for Odoo Integration
"""

from .server import mcp

__all__ = ["mcp"]
