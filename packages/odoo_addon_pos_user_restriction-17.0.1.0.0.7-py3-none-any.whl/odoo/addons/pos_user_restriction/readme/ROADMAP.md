This module alone is not compatible with pos_cache; you need to install
a bridge module like
<https://github.com/OCA/pos/tree/12.0/pos_cache_user_restriction> for it
to work.
