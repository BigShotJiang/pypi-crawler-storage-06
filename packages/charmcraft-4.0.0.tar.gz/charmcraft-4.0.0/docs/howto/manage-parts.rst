.. _manage-parts:

Manage parts
============

   See first: :ref:`part`

Remove a part's assets
----------------------

TBA

   See more: :ref:`ref_commands_clean`

Download or retrieve artifacts defined for a part
-------------------------------------------------

TBA

   See more: :ref:`ref_commands_pull`

Build artifacts defined for a part
----------------------------------

TBA

   See more: :ref:`ref_commands_build`

Stage built artifacts into a common staging area
------------------------------------------------

TBA

   See more: :ref:`ref_commands_build`

Prime artifacts defined for a part
----------------------------------

TBA

   See more: :ref:`ref_commands_prime`

Build the charm
---------------

TBA

   See more: :ref:`ref_commands_pack`
