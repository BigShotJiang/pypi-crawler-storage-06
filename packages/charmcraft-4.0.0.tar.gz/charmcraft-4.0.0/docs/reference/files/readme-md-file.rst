.. _readme-md-file:


``README.md`` file
==================

The ``README.md`` file should describe the charm's behaviour and provide
instructions on to deploy the charm as well as links to resources for
the supported application.
