# This allows running the package directly using `python -m akaidoo`
from .cli import app

app(prog_name="akaidoo")
