"""
Schedules for training.

This module contains various learning rate and exploration schedules for training reinforcement
learning agents.
"""
