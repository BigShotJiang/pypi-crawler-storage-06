#Ai_security_platform

This is for getting summary of the IICS session log

## Installation
```bash
pip Ai_security_platform
