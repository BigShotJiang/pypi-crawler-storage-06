// Entry point is: 'StrOrInt'

type StrOrInt = string | number
