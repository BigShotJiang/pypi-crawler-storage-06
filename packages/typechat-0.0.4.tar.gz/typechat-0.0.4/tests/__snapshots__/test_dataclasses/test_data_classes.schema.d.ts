// Entry point is: 'Response'

interface Response {
    attr_1: string;
    // Hello!
    attr_2: number;
    attr_3: string | null;
    attr_4?: string;
    attr_5?: string | null;
    attr_6?: string[];
    attr_7?: Options;
    _underscore_attr_1?: number;
}

// TODO: someone add something here.
interface Options {
}
