// Entry point is: 'Derived'

interface Derived {
    my_attr_1: string;
    my_attr_2: number;
}
