# SPDX-FileCopyrightText: Microsoft Corporation
#
# SPDX-License-Identifier: MIT
