Glue module that sets uninvoiced amount to 0 when force invoiced is
enabled on purchase order lines.
