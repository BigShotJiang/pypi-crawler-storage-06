Add widgets that define custom visualizations for your extension, so that
the visualizations can be displayed with
[nwbwidgets](https://github.com/NeurodataWithoutBorders/nwbwidgets).

You will also need to update the `vis_spec` dictionary in `__init__.py` so that
nwbwidgets can find your custom visualizations.