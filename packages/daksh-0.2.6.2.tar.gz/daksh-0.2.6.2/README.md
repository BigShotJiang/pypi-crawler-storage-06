# DAKSH

## Install
```
$ git clone https://github.com/divamidesignlabs/ai-daksh
$ cd ai-daksh
$ uv pip install -e .
$ daksh --help
```

## Usage

To update the latest docs, prd, epic, task generation prompts in .github folder of your repository, run the following command:
```
$ daksh update-prompts --no-dry-run
```