Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/spa06_003_simpletest.py
    :caption: examples/spa06_003_simpletest.py
    :linenos:
