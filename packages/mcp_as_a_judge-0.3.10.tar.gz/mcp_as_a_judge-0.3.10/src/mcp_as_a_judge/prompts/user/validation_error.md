The AI assistant's submission failed validation with this issue:
{{ validation_issue }}

Context: {{ context }}

Generate a clear, actionable error message that tells the AI assistant exactly what they need to do to fix this validation issue. The message should be direct, specific, and help them understand both what went wrong and how to correct it.
