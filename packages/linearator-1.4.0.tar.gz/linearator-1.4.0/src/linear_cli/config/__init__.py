"""Configuration management module."""
