"""CLI module for Linearator."""
