"""Tests for Linearator."""
