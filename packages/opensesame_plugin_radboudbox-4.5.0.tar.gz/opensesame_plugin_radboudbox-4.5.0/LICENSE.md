LICENSE
==========

Radboud Buttonbox plug-in is distributed under the terms of the GNU General Public License 3.
The full license should be included in the file COPYING, or can be obtained from

- <http://www.gnu.org/licenses/gpl.txt>

Radboud Buttonbox plug-in contains works of others. For the full license information, please
refer to `README`.
