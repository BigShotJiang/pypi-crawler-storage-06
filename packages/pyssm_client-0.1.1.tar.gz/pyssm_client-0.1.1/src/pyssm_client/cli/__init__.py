"""CLI package for session-manager-plugin."""
