"""PySSM Client - Enhanced Python AWS SSM Session Manager client."""

__version__ = "0.1.0"
__author__ = "Damon Cortesi"
