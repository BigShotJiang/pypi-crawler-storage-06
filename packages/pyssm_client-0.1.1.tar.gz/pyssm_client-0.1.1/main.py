def main():
    print("Hello from python-session-manager-plugin!")


if __name__ == "__main__":
    main()
