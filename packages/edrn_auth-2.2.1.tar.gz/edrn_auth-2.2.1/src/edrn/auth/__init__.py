# encoding: utf-8

'''🔐 EDRN Auth.'''

import importlib.metadata


PACKAGE_NAME = __name__
__version__ = VERSION = importlib.metadata.version(__name__)
