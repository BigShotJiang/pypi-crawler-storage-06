# encoding: utf-8

'''🔐 EDRN auth: defaults.'''
