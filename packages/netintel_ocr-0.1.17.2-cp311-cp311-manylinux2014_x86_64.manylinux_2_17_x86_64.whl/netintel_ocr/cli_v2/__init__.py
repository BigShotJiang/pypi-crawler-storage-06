"""
NetIntel-OCR v0.1.17 CLI - Clean hierarchical command structure
"""

from .main import cli

__all__ = ['cli']