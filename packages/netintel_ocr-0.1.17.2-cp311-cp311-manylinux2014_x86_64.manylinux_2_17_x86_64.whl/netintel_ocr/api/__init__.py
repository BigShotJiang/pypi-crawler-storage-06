"""
NetIntel-OCR API Module
FastAPI server for document processing and management
"""

__version__ = "0.1.13"