#!/usr/bin/env python3
"""
NetIntel-OCR v0.1.17 - New hierarchical CLI
"""

from netintel_ocr.cli_v2.main import main

if __name__ == '__main__':
    main()