# LICENSE HEADER MANAGED BY add-license-header
#
# Copyright (c) 2025 Stacklet, Inc.
#

"""Stacklet MCP server."""

__version__ = "0.1.0"
