# Changelog

## 0.1.0
- Initial release: emoji→text, diacritics removal, hashtag splitting,
  Hinglish shorthand & filler handling, optional PII redaction, CLI.
