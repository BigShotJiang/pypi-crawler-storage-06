﻿py3dframe.FrameTransform.rotation
=================================

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.rotation