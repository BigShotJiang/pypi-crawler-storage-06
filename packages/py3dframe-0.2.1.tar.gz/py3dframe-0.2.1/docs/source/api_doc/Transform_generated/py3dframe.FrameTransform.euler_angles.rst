﻿py3dframe.FrameTransform.euler\_angles
======================================

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.euler_angles