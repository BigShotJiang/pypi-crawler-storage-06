﻿py3dframe.FrameTransform.get\_rotation\_vector
==============================================

.. currentmodule:: py3dframe

.. automethod:: FrameTransform.get_rotation_vector