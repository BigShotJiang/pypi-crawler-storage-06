﻿py3dframe.FrameTransform.quaternion
===================================

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.quaternion