py3dframe.matrix
================

``py3dframe.matrix`` module is used to manage 3D matrices.

.. automodule:: py3dframe.matrix
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:
    :noindex: