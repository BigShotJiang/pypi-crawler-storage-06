﻿py3dframe.Frame.global\_x\_axis
===============================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_x_axis