﻿py3dframe.Frame.global\_rotation\_vector
========================================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_rotation_vector