﻿py3dframe.Frame.z\_axis
=======================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.z_axis