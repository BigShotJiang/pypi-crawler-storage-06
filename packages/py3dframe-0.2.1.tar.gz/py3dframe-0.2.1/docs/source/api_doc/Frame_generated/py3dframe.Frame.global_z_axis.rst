﻿py3dframe.Frame.global\_z\_axis
===============================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_z_axis