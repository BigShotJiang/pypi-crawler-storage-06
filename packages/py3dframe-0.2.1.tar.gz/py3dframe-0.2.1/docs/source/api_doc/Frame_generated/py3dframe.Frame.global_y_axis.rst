﻿py3dframe.Frame.global\_y\_axis
===============================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_y_axis