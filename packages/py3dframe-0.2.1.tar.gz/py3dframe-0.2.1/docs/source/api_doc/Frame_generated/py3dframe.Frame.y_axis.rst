﻿py3dframe.Frame.y\_axis
=======================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.y_axis