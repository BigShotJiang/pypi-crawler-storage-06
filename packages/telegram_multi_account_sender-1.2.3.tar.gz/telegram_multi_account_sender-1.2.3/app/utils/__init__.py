"""
Utility modules for the application.
"""