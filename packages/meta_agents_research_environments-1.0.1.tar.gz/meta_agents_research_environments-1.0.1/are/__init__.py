# Meta Platforms, Inc. and affiliates. Confidential and proprietary.
