# Apps

For detailed information about Meta Agents Research Environments Apps API, please refer to the comprehensive documentation:

[docs/api_reference/apps.rst](../../docs/api_reference/apps.rst)
