# Concepts

For detailed information about Meta Agents Research Environments concepts, please refer to the comprehensive documentation:

[docs/user_guide/concepts.rst](../docs/user_guide/concepts.rst)
