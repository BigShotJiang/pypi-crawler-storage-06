"""
File: __init__.py
Author: Panyi Dong
GitHub: https://github.com/PanyiDong/
Mathematics Department, University of Illinois at Urbana-Champaign (UIUC)

Project: InsurAutoML
Latest Version: 0.2.5
Relative Path: /InsurAutoML/hyperparameters/__init__.py
File Created: Tuesday, 5th April 2022 11:01:43 pm
Author: Panyi Dong (panyid2@illinois.edu)

-----
Last Modified: Sunday, 28th May 2023 10:05:10 pm
Modified By: Panyi Dong (panyid2@illinois.edu)

-----
MIT License

Copyright (c) 2022 - 2022, Panyi Dong

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

from .ray.encoder_hyperparameter import encoder_hyperparameter
from .ray.imputer_hyperparameter import imputer_hyperparameter
from .ray.scaling_hyperparameter import scaling_hyperparameter
from .ray.balancing_hyperparameter import balancing_hyperparameter
from .ray.feature_selection_hyperparameter import (
    feature_selection_hyperparameter,
)
from .ray.classifier_hyperparameter import classifier_hyperparameter
from .ray.regressor_hyperparameter import regressor_hyperparameter

"""
Notice for designing hyperparameters space:
1. tune.qrandint (ray) allows inclusive lower/upper bound, when interact
with scope.int(hp.quniform) (hyperopt), which is exclusive upper bound,
be careful to use at least two step size in hyerparameter space.

2. When designing hyperparameters space, make sure all hyperparameters
are wrapped in tune methods (even it's not a choice, like a method name),
unless, ray.tune can ignore those hyperparameters and causes further error.
However, since we need to determine whether to contain the hyperparameters
space for the method in search space, which is determined by string comparison,
the method names are stored as string and after comparison in code, it will
be converted in to a tune.choice (with only one choice).

3. As discussed in issue 1, https://github.com/PanyiDong/My_AutoML/issues/1
HyperOpt search algorithm option will convert the ray.tune space into a hyperopt
space, which can be problematic when same hyperparameter names are used in those
methods. So, the default hyperparameter space is designed as: the method namess
contain a order indication (suffix "_1", "_2", ...) and hyperparameter names
contain a method name prefix ("KNNClassifier_", "MLPClassifier_", ...). When
reading in, those suffixes/prefixes are removed in a processing step and becomes
method readable strings.
"""

"""
Classifiers/Hyperparameters from autosklearn:
1. AdaBoost: n_estimators, learning_rate, algorithm, max_depth
2. Bernoulli naive Bayes: alpha, fit_prior
3. Decision Tree: criterion, max_features, max_depth_factor, min_samples_split,
            min_samples_leaf, min_weight_fraction_leaf, max_leaf_nodes, min_impurity_decrease
4. Extra Trees: criterion, min_samples_leaf, min_samples_split,  max_features,
            bootstrap, max_leaf_nodes, max_depth, min_weight_fraction_leaf, min_impurity_decrease
5. Gaussian naive Bayes
6. Gradient boosting: loss, learning_rate, min_samples_leaf, max_depth,
            max_leaf_nodes, max_bins, l2_regularization, early_stop, tol, scoring
7. KNN: n_neighbors, weights, p
8. LDA: shrinkage, tol
9. Linear SVC (LibLinear): penalty, loss, dual, tol, C, multi_class,
            fit_intercept, intercept_scaling
10. kernel SVC (LibSVM): C, kernel, gamma, shrinking, tol, max_iter
11. MLP (Multilayer Perceptron): hidden_layer_depth, num_nodes_per_layer, activation, alpha,
            learning_rate_init, early_stopping, solver, batch_size, n_iter_no_change, tol,
            shuffle, beta_1, beta_2, epsilon
12. Multinomial naive Bayes: alpha, fit_prior
13. Passive aggressive: C, fit_intercept, tol, loss, average
14. QDA: reg_param
15. Random forest: criterion, max_features, max_depth, min_samples_split,
            min_samples_leaf, min_weight_fraction_leaf, bootstrap, max_leaf_nodes
16. SGD (Stochastic Gradient Descent): loss, penalty, alpha, fit_intercept, tol,
            learning_rate
"""

"""
Regressors/Hyperparameters from sklearn:
1. AdaBoost: n_estimators, learning_rate, loss, max_depth
2. Ard regression: n_iter, tol, alpha_1, alpha_2, lambda_1, lambda_2,
            threshold_lambda, fit_intercept
3. Decision tree: criterion, max_features, max_depth_factor,
            min_samples_split, min_samples_leaf, min_weight_fraction_leaf,
            max_leaf_nodes, min_impurity_decrease
4. extra trees: criterion, min_samples_leaf, min_samples_split,
            max_features, bootstrap, max_leaf_nodes, max_depth,
            min_weight_fraction_leaf, min_impurity_decrease
5. Gaussian Process: alpha, thetaL, thetaU
6. Gradient boosting: loss, learning_rate, min_samples_leaf, max_depth,
            max_leaf_nodes, max_bins, l2_regularization, early_stop, tol, scoring
7. KNN: n_neighbors, weights, p
8. Linear SVR (LibLinear): loss, epsilon, dual, tol, C, fit_intercept,
            intercept_scaling
9. Kernel SVR (LibSVM): kernel, C, epsilon, tol, shrinking
10. Random forest: criterion, max_features, max_depth, min_samples_split,
            min_samples_leaf, min_weight_fraction_leaf, bootstrap,
            max_leaf_nodes, min_impurity_decrease
11. SGD (Stochastic Gradient Descent): loss, penalty, alpha, fit_intercept, tol,
            learning_rate
12. MLP (Multilayer Perceptron): hidden_layer_depth, num_nodes_per_layer,
            activation, alpha, learning_rate_init, early_stopping, solver,
            batch_size, n_iter_no_change, tol, shuffle, beta_1, beta_2, epsilon
"""

__all__ = [
    "encoder_hyperparameter",
    "imputer_hyperparameter",
    "scaling_hyperparameter",
    "balancing_hyperparameter",
    "feature_selection_hyperparameter",
    "classifier_hyperparameter",
    "regressor_hyperparameter",
]
