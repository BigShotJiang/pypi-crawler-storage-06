# prefect-redis

<p align="center">
    <a href="https://pypi.python.org/pypi/prefect-redis/" alt="PyPI version">
        <img alt="PyPI" src="https://img.shields.io/pypi/v/prefect-redis?color=0052FF&labelColor=090422"></a>
    <a href="https://pepy.tech/badge/prefect-redis/" alt="Downloads">
        <img src="https://img.shields.io/pypi/dm/prefect-redis?color=0052FF&labelColor=090422" /></a>
</p>

For more information about how to use Prefect, please refer to the [Prefect documentation](https://docs.prefect.io/).
