from .fastseqio import seqioStdinFile, seqioFile, Record

__all__ = ["seqioFile", "seqioStdinFile", "Record"]
