"""A light-weight package for training AI models."""

from ._version import __version__

__all__ = ["__version__"]
