# TODO: make this more DRY
def before_scenario(context, scenario):
    context.responses = []
