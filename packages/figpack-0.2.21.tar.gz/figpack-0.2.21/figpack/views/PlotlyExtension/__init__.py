from .PlotlyExtension import PlotlyFigure

__all__ = ["PlotlyFigure"]
