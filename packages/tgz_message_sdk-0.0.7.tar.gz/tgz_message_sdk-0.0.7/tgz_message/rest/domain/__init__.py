class BaseDomain:

    BASE_URL = "https://apiapps.techgenzi.com/api/v1/api-gateway/messaging"
