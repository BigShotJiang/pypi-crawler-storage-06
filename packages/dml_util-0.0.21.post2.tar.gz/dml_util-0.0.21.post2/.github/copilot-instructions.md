# Formatting

- Use numpy style for docstrings.
- Prefer double quotes for strings.
