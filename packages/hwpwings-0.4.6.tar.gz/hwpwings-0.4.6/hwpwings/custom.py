# 커스텀 함수 작성
class custom():
    
    def 함수작성():
        print('def로 커스텀 함수를 작성하시죠.')