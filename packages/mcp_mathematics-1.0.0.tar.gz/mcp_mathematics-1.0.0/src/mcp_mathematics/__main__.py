from mcp_mathematics import main

main()
