"""
Initialize the app
"""

__version__ = "1.0.0"
__title__ = "AA Mumble Quick Connect"
