"""scottbrian_utils package."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__version__ = "6.0.0"
