.. automodule:: unique_ts
   :members: UniqueTS