.. automodule:: pauser
   :members: Pauser, MetricResults