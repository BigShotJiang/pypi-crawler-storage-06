.. automodule:: time_hdr
   :members: time_box, get_datetime_match_string