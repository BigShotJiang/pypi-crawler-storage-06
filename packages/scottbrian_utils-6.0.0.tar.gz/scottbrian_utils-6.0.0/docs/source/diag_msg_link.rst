.. automodule:: diag_msg
   :members: CallerInfo, diag_msg, get_caller_info, get_formatted_call_sequence
