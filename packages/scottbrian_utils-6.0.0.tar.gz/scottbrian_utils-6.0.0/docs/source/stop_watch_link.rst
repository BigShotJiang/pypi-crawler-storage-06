.. automodule:: stop_watch
   :members: StopWatch