.. automodule:: testlib_verifier
   :members: verify_lib