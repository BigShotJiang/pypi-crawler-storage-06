.. automodule:: doc_checker
   :members: