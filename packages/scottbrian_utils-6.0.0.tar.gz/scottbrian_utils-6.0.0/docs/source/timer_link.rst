.. automodule:: timer
   :members: Timer