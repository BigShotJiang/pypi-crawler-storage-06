.. automodule:: msgs
   :members: Msgs