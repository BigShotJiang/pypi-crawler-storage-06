from .client import SkillcornerOnDemandClient
from .method import METHOD_DOCSTRING, METHODS_BINDING

__all__ = ['SkillcornerOnDemandClient', 'METHODS_BINDING', 'METHOD_DOCSTRING']
