from .core import *
from .utils import *

version = "1.0.0"
print(f"Welcome to PySvg2Csv package version {version}!")
