MAJOR = 1
MINOR = 1
MICRO = '0'
__version__ = '%d.%d.%s' % (MAJOR, MINOR, MICRO)
