"""Test base classes for optimizers and experiments."""
# copyright: hyperactive developers, MIT License (see LICENSE file)
