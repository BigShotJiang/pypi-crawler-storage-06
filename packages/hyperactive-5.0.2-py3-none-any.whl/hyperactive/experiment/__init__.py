"""Base classes for optimizers and experiments."""

from hyperactive.base import BaseExperiment

__all__ = ["BaseExperiment"]
