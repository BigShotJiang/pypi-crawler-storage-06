"""Utility functionality."""

from hyperactive.utils.estimator_checks import check_estimator

__all__ = [
    "check_estimator",
]
