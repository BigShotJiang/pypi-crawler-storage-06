# Changelog

## [1.4.0] - 2025-09-23
- add main section

## [1.3.0] - 2025-09-18
- fix nix build

## [1.2.1] - 2025-09-18
- upgraded requirements

## [1.2.0] - 2025-09-18
- fixes jupyter notebook and documentation

## [1.1.0] - 2025-09-18
- fixes script and cli run behaviour

## [1.0.0] - 2025-09-18
- fixes script and cli run behaviour

## [Unreleased]
- Populate once new logging features land.

## [0.1.0] - 2025-09-16
- Bootstrap `bitranox_template_py_cli` using the shared scaffold.
- Replace implementation-specific modules with placeholders ready for Rich-based logging.
