from lonboard._cli import main

main()
