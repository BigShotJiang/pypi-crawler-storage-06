"""Public type hints."""

# Module `types` shadows a Python standard-library module
