# CLI integration tests - currently disabled due to config complexity
# These tests require proper YAML config files and complex server lifecycle management
# They can be re-enabled in the future when we have a simpler CLI testing approach

# TODO: Add simpler CLI unit tests that don't require full server integration
