"""Wallet action provider for basic wallet operations."""
