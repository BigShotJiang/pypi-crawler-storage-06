"""Pyth action provider for price feed interactions."""
