"""Basename action provider for Base domain name operations."""
