"""Twitter action provider for social interaction."""
