"""WOW action provider for memecoin interactions."""
