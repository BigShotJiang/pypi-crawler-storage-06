"""Constants for the Onramp action provider."""

VERSION = "0.38.2"  # Should match TypeScript version
ONRAMP_BUY_URL = "https://pay.coinbase.com/buy"
