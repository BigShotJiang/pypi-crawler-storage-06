"""Morpho action provider for lending protocol interactions."""
