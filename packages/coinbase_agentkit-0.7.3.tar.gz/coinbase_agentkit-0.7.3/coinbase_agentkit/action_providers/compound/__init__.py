"""Compound action provider for borrowing and lending."""
