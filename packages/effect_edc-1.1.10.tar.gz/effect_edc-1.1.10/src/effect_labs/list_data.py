model_data = {
    "edc_lab.consignee": [
        {
            "name": "The EFFECT Trial",
            "contact_name": "Sile Molloy",
            "address": "NIMR Tanzania",
            "postal_code": "-",
            "city": "Dar es Salaam",
            "state": "",
            "country": "Tanzania",
            "telephone": "+255763244779",
            "mobile": "+255763244779",
            "fax": "",
            "email": "sile.molloy@sgul.ac.uk",
        },
    ],
}
