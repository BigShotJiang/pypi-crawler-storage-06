Errors
======

.. automodule:: sans.errors
    :members:
    :undoc-members:
    :show-inheritance:
