Lock
====

.. automodule:: sans.lock
    :members:
    :undoc-members:
    :show-inheritance:
