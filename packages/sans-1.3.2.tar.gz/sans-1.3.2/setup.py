from setuptools import find_namespace_packages, setup

if __name__ == "__main__":
    setup(packages=find_namespace_packages(include=["sans"]))
