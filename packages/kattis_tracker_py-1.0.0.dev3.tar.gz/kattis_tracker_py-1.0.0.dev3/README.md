# kattis-tracker-py

[![PyPI - Version](https://img.shields.io/pypi/v/kattis-tracker-py.svg)](https://pypi.org/project/kattis-tracker-py)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/kattis-tracker-py.svg)](https://pypi.org/project/kattis-tracker-py)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install kattis-tracker-py
```

## License

`kattis-tracker-py` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
