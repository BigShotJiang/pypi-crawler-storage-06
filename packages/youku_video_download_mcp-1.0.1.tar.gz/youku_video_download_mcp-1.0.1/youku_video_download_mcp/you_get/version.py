#!/usr/bin/env python3

"""Version information for the video download MCP service."""

script_name = 'video-download-mcp'
__version__ = '1.0.0'

def get_version():
    """Get version string."""
    return __version__
