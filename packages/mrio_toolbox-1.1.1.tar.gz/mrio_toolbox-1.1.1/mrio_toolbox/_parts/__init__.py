"""
This module provides the Part and Axe classes.
"""

from ._Part import Part,load_part

__all__ = ['Part','load_part']