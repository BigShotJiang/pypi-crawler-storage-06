"""
This module provides utility functions and classes for loading, saving and converting MRIO tables.
"""