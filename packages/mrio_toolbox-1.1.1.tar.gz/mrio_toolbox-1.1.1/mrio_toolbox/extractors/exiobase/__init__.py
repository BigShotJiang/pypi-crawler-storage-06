"""
This module contains the exiobase 3 extractor
"""