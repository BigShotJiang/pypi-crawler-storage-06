"""
This module contains the WIOD extractor.
"""