"""
This module contains the EORA extractor.
"""