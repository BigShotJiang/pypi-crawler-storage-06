"""
The code in this module is copied from the HARPY package, which you can visit on github:
https://github.com/GEMPACKsoftware/HARPY/tree/master

Both the HARPY library and the MRIO toolbox library are licenced under the GPL 3 license.
"""