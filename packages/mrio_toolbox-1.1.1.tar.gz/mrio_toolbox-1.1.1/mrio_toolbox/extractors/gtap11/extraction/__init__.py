"""
This module contains the GTAP 11 extractor. 
"""