"""
This module contains the figaro extractor and the figaro downloader.
"""