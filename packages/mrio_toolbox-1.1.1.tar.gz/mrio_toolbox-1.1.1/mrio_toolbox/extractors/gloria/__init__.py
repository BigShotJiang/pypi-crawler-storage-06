"""
This module contains the gloria extractor
"""