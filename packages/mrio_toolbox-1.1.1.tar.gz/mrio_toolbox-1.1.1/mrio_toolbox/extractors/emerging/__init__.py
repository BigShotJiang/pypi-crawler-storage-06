"""
This module contains the emerging extractor
"""