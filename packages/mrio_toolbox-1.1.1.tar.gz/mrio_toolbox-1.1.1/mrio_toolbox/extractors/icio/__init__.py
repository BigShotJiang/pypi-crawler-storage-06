"""
This module contains the ICIO extractor.
"""