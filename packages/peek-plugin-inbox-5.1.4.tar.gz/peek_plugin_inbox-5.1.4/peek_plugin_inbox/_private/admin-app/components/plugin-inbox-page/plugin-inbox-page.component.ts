
import { Component, ChangeDetectionStrategy } from "@angular/core";

@Component({
    selector: "plugin-inbox-admin",
    templateUrl: "plugin-inbox-page.component.html",
    styleUrls: ["plugin-inbox-page.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PluginInboxPageComponent {}