"""
Scorpius Training Module
Training utilities for the learning system
"""

from .trainer import main

__all__ = ["main"]