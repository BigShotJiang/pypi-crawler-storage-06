# Licence Notification
The files in this directory were got from Aviation Weather Center.
These data are not subject to NakaMetPy copyright protection.

# Reference
stations.json were got from https://aviationweather.gov/data/api/#cache at 2025/08/15 15UTC 