# argus-api

`argus-api` is a CLI client for [mnemonic](https://www.mnemonic.io/)'s Argus API.

Documentation can be found at: [argus-toolbelt documentation](https://argus-toolbelt.docs.mnemonic.no)

## feedback

In order to report issues or request features, please contact Mnemonic's development
team: [opensource@mnemonic.no](mailto:opensource@mnemonic.no)
