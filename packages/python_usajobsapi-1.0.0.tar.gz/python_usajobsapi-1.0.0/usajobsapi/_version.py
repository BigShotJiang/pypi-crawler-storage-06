__license__ = "GPL3"
__title__ = "python-usajobsapi"
__version__ = "1.0.0"
