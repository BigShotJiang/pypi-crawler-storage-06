from ptetools.version import __version__  # noqa
