class GetMblogsFailedError(BaseException):
    """获取用户的mblog列表失败错误"""


class UnknownError(BaseException):
    """未知错误"""
