APP_VERBOSE_NAME = 'Электронные документы'

# Возможные расширения для файла подписи
EXT_SIG = 'sig'
EXT_P7S = 'p7s'
EXT_SGN = 'sgn'
