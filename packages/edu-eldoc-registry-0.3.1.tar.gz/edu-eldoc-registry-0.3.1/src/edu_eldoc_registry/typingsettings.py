# Dummy-настройки Django для django-stubs
INSTALLED_APPS = [
    'django.contrib.contenttypes',
    "educommon",
    "edu_eldoc_registry",
]
SERVICE_DB_ALIAS = 'service'
SIGN_DOCUMENT_STORE_PATH = 'sign'
