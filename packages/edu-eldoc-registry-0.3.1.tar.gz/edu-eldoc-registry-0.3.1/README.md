# Реестр электронных документов

Приложение представляет реестр электронных документов для встраивания в ИС.

Организует хранение документов на сервере и позволяет подписывать их электронной подписью.

## Дополнительное ссылки

Для работы с пакетом нужно предварительно настроить работу с ЭП у себя на ПК, данные ссылки содержат полезные материалы по этой теме

- [Проверка создания электронной подписи CAdES-BES](https://www.cryptopro.ru/sites/default/files/products/cades/demopage/cades_bes_sample.html)

- [Работа с КриптоПро CSP в linux](https://support.cryptopro.ru/index.php?/Knowledgebase/Article/View/390/0/rbot-s-kriptopro-csp-v-linux-n-primere-debian-11)
