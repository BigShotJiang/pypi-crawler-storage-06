This module extends the functionality of stock module to support Drained
Weight. (fluid excluded)

You could be interested by another modules like as:

- product_net_weight
