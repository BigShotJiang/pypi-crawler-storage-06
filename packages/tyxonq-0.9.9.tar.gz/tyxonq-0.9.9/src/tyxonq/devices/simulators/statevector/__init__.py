"""Statevector simulator.

See `statevector.engine.StatevectorEngine` for details.
"""

from .engine import StatevectorEngine

__all__ = ["StatevectorEngine"]


