"""Compilation stages package.

Initial skeleton exposes no-op stages and measurement rewrite placeholder.
"""


