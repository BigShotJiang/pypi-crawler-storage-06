"""Ordinance document download and structured data extraction"""

from ._version import __version__
from .utilities.logs import _setup_logging_levels, COMPASS_DEBUG_LEVEL

_setup_logging_levels()
