"""COMPASS web information retrieval utilities"""
