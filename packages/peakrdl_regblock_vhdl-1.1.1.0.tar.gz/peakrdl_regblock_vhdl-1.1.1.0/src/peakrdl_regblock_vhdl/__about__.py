version_info = (1, 1, 1, 0)
__version__ = ".".join([str(n) for n in version_info])
