def output():
	print("这是我的第一个python包，可以学习的！！！")

