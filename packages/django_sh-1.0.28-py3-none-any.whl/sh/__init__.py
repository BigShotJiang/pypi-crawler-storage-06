"""Django shell app for browser"""

__version__ = "1.0.28"
