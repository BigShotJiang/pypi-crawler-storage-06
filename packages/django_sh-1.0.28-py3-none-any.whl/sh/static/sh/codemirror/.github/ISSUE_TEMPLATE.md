<!--
Do not use this bug tracker for questions. We have a forum (https://discuss.codemirror.net) for those.

In order to get us to look at something, you need to make it easy for us to understand what you are doing and what went wrong. When possible, a code example that demonstrates the problem helps a lot. If there's any chance at all that a problem is related to the browser, include information about which browser(s) you tested with.
-->