.. OASIS-API documentation master file, created by
   sphinx-quickstart on Thu Aug 14 18:37:20 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

OASIS-API documentation
=======================

.. toctree::
	api