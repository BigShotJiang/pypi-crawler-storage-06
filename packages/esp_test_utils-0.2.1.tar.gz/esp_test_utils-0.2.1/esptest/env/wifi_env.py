# try:
#     from typing import Self
# except ImportError:
#     pass


class WiFiMixin:
    pass
