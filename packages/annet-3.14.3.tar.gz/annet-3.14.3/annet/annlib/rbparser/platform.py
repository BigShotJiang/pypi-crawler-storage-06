VENDOR_ALIASES = {
    "h3c": "huawei",
}
