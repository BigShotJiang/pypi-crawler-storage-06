# SPDX-FileCopyrightText: 2023 Coop IT Easy SC
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from . import subscription_request
from . import res_company
from . import res_config_settings
from . import res_partner
