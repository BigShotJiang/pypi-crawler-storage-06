from .contact_manager import ContactManager

__all__ = [
    "ContactManager",
]
