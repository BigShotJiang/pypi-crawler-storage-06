# Pythreejs backend

```{eval-rst}
.. currentmodule:: plopp

.. autosummary::
   :toctree: ../generated

   backends.pythreejs.canvas.Canvas
   backends.pythreejs.figure.Figure
   backends.pythreejs.outline.Outline
   backends.pythreejs.scatter3d.Scatter3d
   backends.pythreejs.mesh3d.Mesh3d
```
