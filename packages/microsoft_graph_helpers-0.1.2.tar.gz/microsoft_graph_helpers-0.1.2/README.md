# Microsoft Graph Helpers

A Python module for calling various Microsoft Graph endpoints. Not nearly as comprehensive as Microsoft's official modules, but far lighter weight and with a minimal amount of dependencies.

Not comprehensive, only contains calls that I've needed to user in my other applets.