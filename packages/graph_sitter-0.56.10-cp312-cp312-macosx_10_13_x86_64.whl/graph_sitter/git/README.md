# Graph-sitter Git

A codegen module to supports git operations on codebase.

### Dependencies

- [codegen.sdk](https://github.com/codegen-sh/graph-sitter/tree/develop/src/codegen/sdk)
- [codegen.shared](https://github.com/codegen-sh/graph-sitter/tree/develop/src/codegen/shared)
