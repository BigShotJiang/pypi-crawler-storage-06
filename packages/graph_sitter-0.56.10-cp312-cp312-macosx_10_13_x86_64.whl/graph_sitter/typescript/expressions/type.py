TSType = "TSUnionType[Parent] | TSObjectType[Parent] | TSNamedType[Parent] | TSGenericType[Parent] | TSQueryType[Parent] | TSReadonlyType[Parent] | NoneType[Parent] | TSUndefinedType[Parent]"
__all__ = ["TSType"]
