from mate.utils.utils import get_device_list
from mate.utils.istarmap import istarmap