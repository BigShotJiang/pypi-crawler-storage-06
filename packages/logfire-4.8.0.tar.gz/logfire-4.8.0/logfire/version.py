"""Version information for logfire package."""

import importlib_metadata

VERSION = importlib_metadata.version('logfire')
