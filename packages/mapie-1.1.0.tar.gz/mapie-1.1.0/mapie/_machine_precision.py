import numpy as np

EPSILON = np.float64(1e-8)

__all__ = ["EPSILON"]
