.. _usage-getting-started:

################################
 Generating your first forecast
################################

For an example of how to quickly use anemoi to make predictions with a
trained model, please visit the `hugging-face example for AIFS Single 1
<https://huggingface.co/ecmwf/aifs-single-1.0#how-to-get-started-with-the-model>`_.
