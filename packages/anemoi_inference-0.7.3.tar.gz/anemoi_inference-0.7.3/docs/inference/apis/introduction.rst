.. _api_introduction:

######
 APIs
######

anemoi-inference support theree differents APIs to generate a forecast:

-  NumPy to NumPy API (see :ref:`api_level1`)
-  Object oriented API (see :ref:`api_level2`)
-  Command line API (see :ref:`api_level3`)

.. toctree::
   :maxdepth: 1
   :hidden:
   :caption: APIs

   level1
   level2
   level3
