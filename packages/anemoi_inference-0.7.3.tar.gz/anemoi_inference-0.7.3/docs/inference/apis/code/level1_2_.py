latitudes = runner.checkpoint.latitudes
longitudes = runner.checkpoint.longitudes
