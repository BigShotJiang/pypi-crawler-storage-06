anemoi-inference run aifs.yaml
