# Internal Search Tool

Internal Search Tool to find documents in the Knowledge Base