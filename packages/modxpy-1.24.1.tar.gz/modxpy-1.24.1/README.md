# ModX

ModX — The Python Module Universe at Your Fingertips.

## Installation

```bash
pip install modx
```

## Usage

```python
import modx

modx.import_all()
modx.imported()
```
