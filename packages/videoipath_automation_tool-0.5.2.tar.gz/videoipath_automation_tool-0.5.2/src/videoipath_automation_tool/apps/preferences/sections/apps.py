# import logging

# from videoipath_automation_tool.apps.preferences.preferences_api import PreferencesAPI

# --- Prepare for further implementation ---

# class Apps:
#     def __init__(self, preferences_api: PreferencesAPI, logger: logging.Logger):
#         self._logger = logger
#         self._preferences_api = preferences_api
#     # TODO
