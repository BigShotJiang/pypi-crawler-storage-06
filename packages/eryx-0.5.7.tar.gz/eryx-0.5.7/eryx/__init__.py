"""Version of the package."""

CURRENT_VERSION = "0.5.7"
