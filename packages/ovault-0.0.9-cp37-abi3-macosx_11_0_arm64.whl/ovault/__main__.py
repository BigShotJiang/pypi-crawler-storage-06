import ovault.help

if __name__ == "__main__":
    ovault.help.main()
