"""Import and export code for `ACT-R <http://act-r.psy.cmu.edu/>`_ models"""

from .importer import actr_to_mdf
