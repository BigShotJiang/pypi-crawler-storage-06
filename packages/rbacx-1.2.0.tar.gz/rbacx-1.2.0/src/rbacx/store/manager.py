"""rbacx.store.manager has been removed.

Use `rbacx.policy.loader.HotReloader` instead.
"""

from __future__ import annotations

raise ImportError("rbacx.store.manager is removed; use rbacx.policy.loader.HotReloader")
