#!/usr/bin/env python3
"""Entry point for check-requirements-txt when run as a module."""

from check_requirements_txt import main

if __name__ == "__main__":
    main()
