# encoding: utf-8
"""Lasso Requirements: tag management."""
