from puppy_mcp_server.main import main

if __name__ == "__main__":
    main()