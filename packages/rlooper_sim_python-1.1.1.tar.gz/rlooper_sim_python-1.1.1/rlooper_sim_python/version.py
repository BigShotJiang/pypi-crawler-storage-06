# Rlooper Simulation Python - Version Information

__version__ = "1.1.1"
__release_date__ = "2025-09-24"
__author__ = "srhartono"
__description__ = "Rlooper with R-loop Peak Simulator (Python Implementation)"

# Version history
CHANGELOG = """
## v1.1.1 (2025-09-23)
- Fixed sim graph that's wrong at n=0
"""