
# Nive application base package
This is the base package. 

## Source code
The source code is hosted on github: https://github.com/nive

### The form module nive.components.reform
The reform package is a merge of deform and colander and includes several changes 
to make form handling easier. Please see nive.components.reform.README.txt for details.

### Translations
Translations can be extracted using lingua>=3.2

    > pip install lingua-3.2
    > bin/pot-create -o nive/locale/nive.pot nive



