
from nive.components.webapi.view import configuration