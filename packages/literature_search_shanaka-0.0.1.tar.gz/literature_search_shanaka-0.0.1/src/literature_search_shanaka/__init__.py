# Copyright (c) 2024 Shanaka Abeysiriwardhana
# This file is part of literature_search_shanaka and is licensed under the GNU GPL v3.
# Please carry the copyright notice in derived works.
# See LICENSE file for details.
# __init__.py for literature_search_shanaka package
