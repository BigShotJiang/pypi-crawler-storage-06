drop view if exists file_provenance, files_with_provenance;
drop table if exists files_datasets, datasets_parent_child, users_roles, parent_child, queries, parameter_definitions, authenticators cascade;
drop table if exists files, datasets, users, parameter_categories, namespaces, roles cascade;

