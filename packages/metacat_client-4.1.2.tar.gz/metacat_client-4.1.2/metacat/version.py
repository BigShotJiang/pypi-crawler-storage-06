Version = "4.1.2"

if __name__ == "__main__":
    print(Version)
