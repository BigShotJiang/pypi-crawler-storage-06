from .version import Version
from .version import Version as __version__

