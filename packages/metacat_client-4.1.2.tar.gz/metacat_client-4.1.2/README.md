
## MetaCat

Data Catalog designed for use with the [Rucio](https://rucio.cern.ch/) data management system

* [Documentation](https://fermitools.github.io/metacat/)

### Related Projects

* [Data Dispatcher](https://github.com/fermitools/data_dispatcher) 
* [Declad](https://github.com/fermitools/declad)
