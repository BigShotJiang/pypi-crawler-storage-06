provider_class = "strong_opx.providers.azure.provider.AzureProvider"
