from strong_opx.providers.aws.credentials import AWSCredential, AWSCredentialConfig

provider_class = "strong_opx.providers.aws.provider.AWSProvider"
