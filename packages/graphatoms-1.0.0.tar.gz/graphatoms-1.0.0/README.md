# GraphAtoms

The Chemical Core Class for Graph Theory Analysis & Graph Neural Network.
