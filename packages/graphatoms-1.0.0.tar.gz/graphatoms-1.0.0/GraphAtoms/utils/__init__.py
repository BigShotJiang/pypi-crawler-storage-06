"""The utils of this packages."""

from ._pyarrow import get_pyarrow_schema

__all__ = ["get_pyarrow_schema"]
