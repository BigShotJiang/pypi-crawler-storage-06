streamwatch.commands.invoker module
===================================

.. automodule:: streamwatch.commands.invoker
   :members:
   :show-inheritance:
   :undoc-members:
