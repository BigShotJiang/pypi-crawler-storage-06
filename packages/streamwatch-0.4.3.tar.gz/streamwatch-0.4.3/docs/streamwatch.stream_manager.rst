streamwatch.stream\_manager module
==================================

.. automodule:: streamwatch.stream_manager
   :members:
   :show-inheritance:
   :undoc-members:
