streamwatch.naming\_standards module
====================================

.. automodule:: streamwatch.naming_standards
   :members:
   :show-inheritance:
   :undoc-members:
