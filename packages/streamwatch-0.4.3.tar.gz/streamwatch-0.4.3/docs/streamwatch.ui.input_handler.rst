streamwatch.ui.input\_handler module
====================================

.. automodule:: streamwatch.ui.input_handler
   :members:
   :show-inheritance:
   :undoc-members:
