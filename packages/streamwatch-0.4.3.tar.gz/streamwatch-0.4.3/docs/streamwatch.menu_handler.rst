streamwatch.menu\_handler module
================================

.. automodule:: streamwatch.menu_handler
   :members:
   :show-inheritance:
   :undoc-members:
