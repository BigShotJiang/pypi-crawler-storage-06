streamwatch.recording\_menu module
==================================

.. automodule:: streamwatch.recording_menu
   :members:
   :show-inheritance:
   :undoc-members:
