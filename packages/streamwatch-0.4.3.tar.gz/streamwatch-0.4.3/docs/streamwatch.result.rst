streamwatch.result module
=========================

.. automodule:: streamwatch.result
   :members:
   :show-inheritance:
   :undoc-members:
