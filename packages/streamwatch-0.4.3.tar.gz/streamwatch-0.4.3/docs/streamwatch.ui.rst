streamwatch.ui package
======================

Submodules
----------

.. toctree::
   :maxdepth: 4

   streamwatch.ui.display
   streamwatch.ui.input_handler
   streamwatch.ui.pagination
   streamwatch.ui.styles

Module contents
---------------

.. automodule:: streamwatch.ui
   :members:
   :show-inheritance:
   :undoc-members:
