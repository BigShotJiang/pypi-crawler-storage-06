StreamWatch Documentation
=========================

Welcome to StreamWatch's documentation!

StreamWatch is a modern, fast, and powerful command-line tool for managing and watching your favorite live streams—all without the resource drain of a web browser.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
