streamwatch.ui.styles module
============================

.. automodule:: streamwatch.ui.styles
   :members:
   :show-inheritance:
   :undoc-members:
