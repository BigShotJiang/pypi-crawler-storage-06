streamwatch.app module
======================

.. automodule:: streamwatch.app
   :members:
   :show-inheritance:
   :undoc-members:
