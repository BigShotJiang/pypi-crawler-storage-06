# Type stubs for external libraries
