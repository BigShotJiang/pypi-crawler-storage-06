class SDKError(Exception):
    pass
