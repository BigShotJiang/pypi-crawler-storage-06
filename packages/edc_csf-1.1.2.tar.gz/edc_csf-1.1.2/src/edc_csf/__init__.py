from importlib.metadata import version

__version__ = version("edc_csf")
