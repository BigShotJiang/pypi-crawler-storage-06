# express-love ❤️

A simple Python package to express love to anyone 💖.

## Installation
```bash
pip install mahesh

# yolo2trt 🚀

Easily convert YOLO `.pt` models to ONNX and TensorRT engine files.



