"""Kedro plugin for collecting Kedro usage data."""

__version__ = "0.6.5"

import logging

logging.getLogger(__name__).setLevel(logging.DEBUG)
