v4l2-ctl -d /dev/video0 -p 30
v4l2-ctl -d /dev/video0 -p 30
v4l2-ctl -d /dev/video0 -set-ctrl 30
v4l2-ctl -d /dev/video0 -p 30
