uv run mcp install server_local.py --with "snowflake-connector-python[pandas]" -f .env


