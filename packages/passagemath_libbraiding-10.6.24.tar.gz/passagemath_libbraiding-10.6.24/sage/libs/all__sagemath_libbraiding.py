# sage_setup: distribution = sagemath-libbraiding
