"""Test suite for augint-org."""
