# Youtube Autonomous File add-on

The way to work with files and filenames.

- [ ! ] This project has some optional dependencies.