def test_import():
    import safe
