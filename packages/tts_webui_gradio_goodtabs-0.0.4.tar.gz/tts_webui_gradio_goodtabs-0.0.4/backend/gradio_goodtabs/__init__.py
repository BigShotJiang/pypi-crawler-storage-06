
from .goodtabs import GoodTabs, GoodTab

__all__ = ['GoodTabs', 'GoodTab']
