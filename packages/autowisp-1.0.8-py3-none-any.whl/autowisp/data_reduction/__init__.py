"""Module for working with Data Reduction files."""
