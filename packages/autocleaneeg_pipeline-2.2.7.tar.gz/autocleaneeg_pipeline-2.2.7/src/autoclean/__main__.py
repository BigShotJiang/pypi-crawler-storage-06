"""Main entry point for the autoclean package."""

import sys

from autoclean.cli import main

if __name__ == "__main__":
    sys.exit(main())
