"""Reporting-related mixins for AutoClean tasks."""
