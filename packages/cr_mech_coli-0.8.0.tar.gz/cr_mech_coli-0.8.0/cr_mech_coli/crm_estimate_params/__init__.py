"""
.. code-block:: text
    :caption: Usage of the `crm_estimate_params` script
"""

from cr_mech_coli.crm_estimate_params.crm_estimate_params_rs import *

from .main import crm_estimate_params_main
