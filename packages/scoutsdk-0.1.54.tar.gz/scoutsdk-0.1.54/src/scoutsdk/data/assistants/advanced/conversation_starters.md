This is a starter prompt from a file.
