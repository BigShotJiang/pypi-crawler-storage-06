# -*- coding: utf-8 -*-

PLUGIN_VERSION = "0.2.7"
