# `ryo3-http`

ryo3-wrapper for `http` crate

[//]: # "<GENERATED>"

## Ref:

- docs.rs: [https://docs.rs/http](https://docs.rs/http)
- crates: [https://crates.io/crates/http](https://crates.io/crates/http)

[//]: # "</GENERATED>"
