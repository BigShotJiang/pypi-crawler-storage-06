CFDP Libre Cube Cross Test
=========

1. Install the LibreCube `cfdp` dependency first:  `pip install -r requirements.txt`
2. The `libre-cube-server.py` runs as the remote entity, so start it first.
3. Now you can run `tmtccmd-client.py` to perform a file transfer. See `tmtccmd-client.py -h` for
   more information.
