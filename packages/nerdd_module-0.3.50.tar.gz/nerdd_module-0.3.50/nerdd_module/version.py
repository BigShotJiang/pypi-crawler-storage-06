from .polyfills import version

__all__ = ["__version__"]

__version__ = version(__package__)
