"""Exceptions classes for the Rank Entropy Module"""

# Imports
# Standard Library Imports
from __future__ import annotations

# External Imports

# Local Imports


class NotFitError(Exception):
    pass
