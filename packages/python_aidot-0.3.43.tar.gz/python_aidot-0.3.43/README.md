# python-aidot
 Can control the WiFi lights of AIDOT in the local area network
