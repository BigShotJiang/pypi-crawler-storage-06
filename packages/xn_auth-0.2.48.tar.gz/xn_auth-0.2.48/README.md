# X-Auth
###### JWT authentication for x-api

#### Requirements
- Python >= 3.12

### INSTALL
```bash
pip install xn-auth
```

---
Made with ❤ on top of the [X-Model](https://github.com/XyncNet/x-model).
