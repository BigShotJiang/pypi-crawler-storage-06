"""Tests package for ClearFlow.

This package contains comprehensive tests for the ClearFlow framework,
demonstrating functional programming testing patterns and verifying
the correctness of all core functionality.
"""
