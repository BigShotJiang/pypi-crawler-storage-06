"""RAG (Retrieval-Augmented Generation) example for ClearFlow."""
