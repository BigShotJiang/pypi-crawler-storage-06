# TODO
# [x] dense
#    - simple rw
# [] sparse
# [] metadata
# [] property access
# [] strings (attrs and dims)
# [] "interesting" query range distributions?
