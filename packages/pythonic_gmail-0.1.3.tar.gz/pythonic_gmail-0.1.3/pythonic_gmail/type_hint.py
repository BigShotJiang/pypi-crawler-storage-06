# -*- coding: utf-8 -*-

import typing as T

T_KWARGS = dict[str, T.Any]
T_RESPONSE = T_KWARGS
