from elasticai.creator.ir2vhdl import (
    InstanceFactory,
)

InstanceFactoryForCombinatorial = InstanceFactory()
