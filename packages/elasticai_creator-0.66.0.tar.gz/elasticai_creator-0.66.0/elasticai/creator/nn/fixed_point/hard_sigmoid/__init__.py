from .layer import HardSigmoid as HardSigmoid
