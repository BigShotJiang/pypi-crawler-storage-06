from .layer import HardTanh as HardTanh
