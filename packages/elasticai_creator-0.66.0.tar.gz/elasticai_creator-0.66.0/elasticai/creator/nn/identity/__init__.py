from .layer import BufferedIdentity as BufferedIdentity
from .layer import BufferlessIdentity as BufferlessIdentity
