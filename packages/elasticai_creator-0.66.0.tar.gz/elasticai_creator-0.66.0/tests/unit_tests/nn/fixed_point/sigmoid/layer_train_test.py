import pytest
import torch

import elasticai.creator.nn.fixed_point as nn_creator
from elasticai.creator.arithmetic import FxpParams
from elasticai.creator.nn import Sequential


class SimpleSigmoid(torch.nn.Module):
    def __init__(
        self,
        total_width: int,
        frac_width: int,
        num_steps: int,
        vrange: tuple[float, float],
    ):
        super().__init__()
        self.model = Sequential(
            nn_creator.Linear(
                in_features=10,
                out_features=10,
                total_bits=total_width,
                frac_bits=frac_width,
            ),
            nn_creator.Sigmoid(
                total_bits=total_width,
                frac_bits=frac_width,
                num_steps=num_steps,
                sampling_intervall=vrange,
            ),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x)


@pytest.mark.slow
@pytest.mark.parametrize("total_bits, frac_bits, num_steps", [(4, 3, 4)])
def test_trainable_layer_silu(total_bits: int, frac_bits: int, num_steps: int) -> None:
    params = FxpParams(total_bits=total_bits, frac_bits=frac_bits, signed=True)
    vrange = (params.minimum_as_rational, params.maximum_as_rational)

    stimuli = torch.rand((4, 10)) * (vrange[1] - vrange[0]) + vrange[0]
    model = SimpleSigmoid(
        total_width=total_bits, frac_width=frac_bits, num_steps=num_steps, vrange=vrange
    )
    criterion = torch.nn.MSELoss()
    optim = torch.optim.Adam(model.parameters())

    for epoch in range(2):
        y = model(stimuli).squeeze()
        loss = criterion(y, stimuli.float())
        optim.zero_grad()
        loss.backward()
        optim.step()
