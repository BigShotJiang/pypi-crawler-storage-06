```{include} ../../../elasticai/creator_plugins/counter/README.md
```
