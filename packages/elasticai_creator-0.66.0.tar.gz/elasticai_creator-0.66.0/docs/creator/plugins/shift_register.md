```{include} ../../../elasticai/creator_plugins/shift_register/README.md
```
