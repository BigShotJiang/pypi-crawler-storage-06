# Builtin Plugins

The Elastic-AI.creator comes bundled with a few plugins.


```{toctree}
vhdl
```
