```{include} ../../../elasticai/creator_plugins/striding_shift_register/README.md
```
