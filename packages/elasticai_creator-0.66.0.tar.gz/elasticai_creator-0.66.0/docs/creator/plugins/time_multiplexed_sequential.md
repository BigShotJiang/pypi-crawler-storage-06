```{include} ../../../elasticai/creator_plugins/time_multiplexed_sequential/README.md
```
