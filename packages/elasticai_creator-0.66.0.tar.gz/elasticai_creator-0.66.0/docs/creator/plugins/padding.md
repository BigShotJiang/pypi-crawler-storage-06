```{include} ../../../elasticai/creator_plugins/padding/README.md
```
