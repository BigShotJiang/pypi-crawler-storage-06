```{include} ../../../elasticai/creator_plugins/skeleton/README.md
```
