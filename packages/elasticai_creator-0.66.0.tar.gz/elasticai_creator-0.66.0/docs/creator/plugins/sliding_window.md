```{include} ../../../elasticai/creator_plugins/sliding_window/README.md
```
