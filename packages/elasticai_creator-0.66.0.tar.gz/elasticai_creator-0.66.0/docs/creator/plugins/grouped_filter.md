```{include} ../../../elasticai/creator_plugins/grouped_filter/README.md
```
