# Users Guide

```{include} ../../README.md
:start-line: 32
:end-line: 97
:heading-offset: 1
:relative-docs: .
``` 

