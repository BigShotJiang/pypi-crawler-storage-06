from fileslicer._core import FileSlice

__all__ = ["FileSlice"]
