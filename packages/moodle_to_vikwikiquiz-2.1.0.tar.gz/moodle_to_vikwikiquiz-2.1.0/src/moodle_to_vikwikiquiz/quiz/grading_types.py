from enum import Enum


class GradingType(Enum):
    Strict = "-"
    Kind = "+"
