from enum import Enum


class QuestionType(Enum):
    SingleChoice = "egy"
    MultipleChoice = "több"
