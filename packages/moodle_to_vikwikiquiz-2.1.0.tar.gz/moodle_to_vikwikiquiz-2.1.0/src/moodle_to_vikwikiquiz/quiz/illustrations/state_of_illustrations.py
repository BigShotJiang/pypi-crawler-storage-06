from enum import Enum


class StateOfIllustrations(Enum):
    Nil = 0
    YesButUnavailable = 1
    YesAndAvailable = 2
