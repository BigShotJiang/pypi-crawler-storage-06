# -*- coding: utf-8 -*-

"""Top-level package for igv-reports."""

__author__ = """Jim Robinson"""
__email__ = 'igv-team@broadinstitute.org'
__version__ = '0.1.0'
