AssetId = int
default_asset_id = 0xFFFFFFFFFFFFFFFF
