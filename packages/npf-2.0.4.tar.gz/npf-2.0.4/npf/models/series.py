from typing import List, Tuple

Series = List[Tuple['Test','Build','Dataset']]