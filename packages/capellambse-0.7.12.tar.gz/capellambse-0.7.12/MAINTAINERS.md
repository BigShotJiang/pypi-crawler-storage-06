<!--
 ~ SPDX-FileCopyrightText: Copyright DB InfraGO AG
 ~ SPDX-License-Identifier: Apache-2.0
 -->

# Maintainers

The `capellambse` Python bindings are maintained by the following people:

- [Ernst Würger](mailto:ernst.wuerger@deutschebahn.com)
- [Jamil Raichouni](mailto:jamil.raichouni@deutschebahn.com)
- [Martin Lehmann](mailto:martin.lehmann@deutschebahn.com)
- [Moritz Weber](mailto:moritz.weber@deutschebahn.com)
- [Viktor Kravchenko](mailto:viktor.kravchenko@deutschebahn.com)
