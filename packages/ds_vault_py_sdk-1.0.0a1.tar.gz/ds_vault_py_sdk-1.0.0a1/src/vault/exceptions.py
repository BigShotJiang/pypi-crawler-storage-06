# src/dsvault/exceptions.py
class SecretNotFound(Exception):
    pass


class DecryptionFailed(Exception):
    pass
