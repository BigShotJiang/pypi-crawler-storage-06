def add_offset(augend: int, addend: int) -> int:
    return augend + addend
