"""A template Python module"""

__version__ = "0.1.0"
from .tdpxlsx import add_offset  # noqa
