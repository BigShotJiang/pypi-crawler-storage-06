from .yolo import YOLOX as Detector


__all__ = ['Detector']
