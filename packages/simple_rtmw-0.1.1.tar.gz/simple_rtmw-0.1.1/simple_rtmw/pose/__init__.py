from .rtmpose import RTMPose as PoseEstimator


__all__ = ['PoseEstimator']
