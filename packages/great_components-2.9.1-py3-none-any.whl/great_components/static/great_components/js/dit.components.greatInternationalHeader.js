$(document).ready(function() {
  dit.components.languageSelectorDropdown.init();
});
