
# used by core.helpers.RemoteIPAddressRetriver
IP_RETRIEVER_NAME_GOV_UK = 'govuk-paas'
IP_RETRIEVER_NAME_IPWARE = 'ipware'

# used by country selector in international header
COUNTRY_COOKIE_NAME = 'country'
