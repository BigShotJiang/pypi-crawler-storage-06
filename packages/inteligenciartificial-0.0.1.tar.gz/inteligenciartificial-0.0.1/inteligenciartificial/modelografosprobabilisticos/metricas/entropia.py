class Entropia:
    pass
