class RedBayesiana:
    pass
