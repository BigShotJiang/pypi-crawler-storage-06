class NaiveBayes:
    pass
