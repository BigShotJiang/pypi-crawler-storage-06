from __future__ import annotations

from fastapi import APIRouter, FastAPI

__all__ = ["APIRouter", "FastAPI"]


