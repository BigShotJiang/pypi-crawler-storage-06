import pipelines
from pipelines import imdb_pipeline

__all__ = [
    imdb_pipeline
] 