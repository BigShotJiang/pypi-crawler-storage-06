from enum import StrEnum


class Domain(StrEnum):
    ORGANIZATION = "organization"
    SYSTEM = "system"
