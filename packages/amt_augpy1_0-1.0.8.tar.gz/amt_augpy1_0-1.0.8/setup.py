"""
This file is kept for backwards compatibility with older pip versions.
All package configuration is now in pyproject.toml.
"""
#test
from setuptools import setup

setup()
