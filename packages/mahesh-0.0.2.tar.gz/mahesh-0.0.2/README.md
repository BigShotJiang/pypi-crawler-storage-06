# express-love ❤️

A simple Python package to express love to anyone 💖.

## Installation
```bash
pip install express-love
