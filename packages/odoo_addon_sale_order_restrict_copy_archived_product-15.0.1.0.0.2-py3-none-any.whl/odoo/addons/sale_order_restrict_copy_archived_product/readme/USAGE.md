To use this module, you need to:

1. Go to Sales / Orders
2. Select a Sale with archived products, or archive a product of a sale.
3. Click to the Action -> Duplicate button of the Sale Order form. A validation error message will be displayed showing the archived products.
