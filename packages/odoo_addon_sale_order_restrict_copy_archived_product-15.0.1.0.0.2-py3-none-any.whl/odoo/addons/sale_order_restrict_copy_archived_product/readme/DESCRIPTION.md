This module allows you to restrict duplication of sales order if they have archived products.
