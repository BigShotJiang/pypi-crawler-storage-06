#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from .login import create_protected_app
