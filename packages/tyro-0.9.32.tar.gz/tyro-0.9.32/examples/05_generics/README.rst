Generics
========

:mod:`tyro`'s understanding of Python's type system includes user-defined
parameterized types, which can reduce boilerplate and improve type safety.
