Basics
======

In these examples, we show basic examples of using :func:`tyro.cli`: functions,
dataclasses, supported annotations, and configuration.
