from apscheduler.schedulers.background import BackgroundScheduler

__all__ = ["scheduler_service"]


scheduler_service = BackgroundScheduler()
