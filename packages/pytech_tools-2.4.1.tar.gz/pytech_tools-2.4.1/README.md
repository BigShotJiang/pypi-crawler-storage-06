# PyTech Tools

## Description
This project aims to provide basic tools that may be useful in general purpose projects.

## Roadmap
You may find some new features coming in the [Issue section](https://gitlab.com/pytech-srl/resources/pytech-tools/-/issues)

## License

This project is licensed under the [GNU Affero General Public License v3](https://www.gnu.org/licenses/agpl-3.0.html).
See the [LICENSE](./LICENSE) file for more details.

## Authors and acknowledgment
This package is provided thanks to:

- Alessandro Grandi (PyTech srl)
