2022-07-01 Version: 1.0.0
- First Version.
2022-09-19 Version: 1.0.1
- fix README.md some errors.
2024-04-18 Version: 1.1.0
- add scan compressed files and scan URL files.
2024-09-13 Version: 1.1.1
- Supports global parameter configuration and STS Token.
2025-07-17 Version: 1.1.2
- Fix dependency package versions and add support for endpoint configuration.