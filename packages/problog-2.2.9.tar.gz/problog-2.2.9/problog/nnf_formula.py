import warnings

warnings.warn(
    "The class nnf_formula.NNF has been renamed to ddnnf_formula.DDNNF.  Please update your code!"
)
