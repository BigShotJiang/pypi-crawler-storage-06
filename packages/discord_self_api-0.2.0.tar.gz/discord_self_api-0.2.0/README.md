# Discord Selfbot API

⚠️ **WARNING**: Selfbots violate Discord's Terms of Service. Using selfbots may result in your account being terminated. This library is for educational purposes only. Use at your own risk.

A cross-platform Discord selfbot API wrapper that works on Termux and other platforms.

## Installation

```bash
pip install discord-selfbot-api