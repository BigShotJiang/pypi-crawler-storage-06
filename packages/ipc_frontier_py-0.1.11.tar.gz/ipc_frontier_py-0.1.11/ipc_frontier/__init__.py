"""ipc-frontier-py: Benchmarks comparing Python concurrency models for moving and processing NumPy arrays."""
