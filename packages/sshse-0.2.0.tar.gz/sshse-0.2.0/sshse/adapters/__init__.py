"""Adapters package for SSH client and I/O integrations."""
