"""Plugins package for sshse extensions."""
