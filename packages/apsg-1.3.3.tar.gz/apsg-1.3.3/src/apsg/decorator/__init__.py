# -*- coding: utf-8 -*-

from apsg.decorator._decorator import ensure_first_arg_same, ensure_arguments

__all__ = ("ensure_first_arg_same", "ensure_arguments")
