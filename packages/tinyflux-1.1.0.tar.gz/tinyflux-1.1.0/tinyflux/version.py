"""Version."""

__version__ = "1.1.0"  # pragma: no cover
