from sila2.discovery.browser import SilaDiscoveryBrowser

__all__ = ["SilaDiscoveryBrowser"]
