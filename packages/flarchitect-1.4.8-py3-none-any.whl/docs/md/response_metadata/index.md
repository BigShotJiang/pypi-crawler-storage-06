# Response Metadata

flarchitect can attach metadata to each response. Toggle fields individually to
balance observability with payload size.

## Sections

- [Common keys](common-keys.md)
