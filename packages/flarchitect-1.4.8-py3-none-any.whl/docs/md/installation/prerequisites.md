[← Back to Installation index](index.md)

# Prerequisites
Flarchitect supports Python 3.10 or newer. Ensure Python is available and up to date by checking the version:
```
$ python --version
```

