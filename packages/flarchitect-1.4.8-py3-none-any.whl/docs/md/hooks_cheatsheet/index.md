# Hooks & Plugins Cheatsheet

Quick reference for callbacks and plugin hooks: when they run, what they
receive, and what they should return.

## Sections

- [Lifecycle at a glance](lifecycle-at-a-glance.md)
- [Callback quick reference](callback-quick-reference.md)
- [Plugin hooks quick reference](plugin-hooks-quick-reference.md)
