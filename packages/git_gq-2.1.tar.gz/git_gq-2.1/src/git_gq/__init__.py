# the git-gq package initialization
