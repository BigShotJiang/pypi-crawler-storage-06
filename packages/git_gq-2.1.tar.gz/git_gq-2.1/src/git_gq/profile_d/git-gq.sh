_git_gq() { __gitcomp "$(git-gq commands)" "" "$cur"; }
