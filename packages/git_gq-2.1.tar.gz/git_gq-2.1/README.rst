git-gq
======

About
-----

A patch queue implementation for git.

Author
------

Goetz Pfeiffer <goetzpf@googlemail.com>

Documentation
-------------

https://goetzpf.github.io/git-gq

License
-------

git-gq is licensed under GNU GPL v.3.

