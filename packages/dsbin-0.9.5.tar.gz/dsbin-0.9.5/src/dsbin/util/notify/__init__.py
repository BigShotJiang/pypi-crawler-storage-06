from __future__ import annotations

from .macos import macos_notification
from .send_mail import MailSender
from .send_telegram import TelegramSender
