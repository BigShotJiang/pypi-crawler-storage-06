from __future__ import annotations

from dsbin.workcalc.plugin import DataSourcePlugin
from dsbin.workcalc.plugin_registry import PluginRegistry
