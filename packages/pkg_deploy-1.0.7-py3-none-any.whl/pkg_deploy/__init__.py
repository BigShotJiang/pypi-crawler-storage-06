__version__ = "1.0.7"

from .deploy import PackageDeploy