class SerializerFeatureData:
    pass

class SerializerInvoker:
    def __init__(self, name, manager, options, invokerType):
        pass
    def execute(self):
        pass
    def _generate(self):
        pass
