O menu de NF-e se encontra dentro do menu fiscal.
