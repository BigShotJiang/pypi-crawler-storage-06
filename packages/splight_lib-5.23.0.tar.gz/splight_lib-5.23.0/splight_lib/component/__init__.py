from splight_lib.component.abstract import SplightBaseComponent

__all__ = [
    SplightBaseComponent,
]
