This module adds the option in the web editor to include an image with
the corresponding link to open/download the linked files.
