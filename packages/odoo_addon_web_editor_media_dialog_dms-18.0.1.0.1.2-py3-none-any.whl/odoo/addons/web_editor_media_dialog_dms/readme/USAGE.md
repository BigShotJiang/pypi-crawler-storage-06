To use this module, we need:

1.  Navigate to a model that has an HTML field
2.  Edit the field
3.  Type /image to open the media dialog
4.  Select the DMS tab
5.  Select the DMS file to be added

You can also edit the selected file making a double click on the image
added to web editor.

If you want to share the file to a public user, you can do it by
selecting the option **Allow open to public users** which is located on
DMS tab of media dialog.
