from .core import clipcount  # core.py の関数をパッケージに公開

__all__ = ["clipcount"]
