"""Just a place to jot down ideas"""
