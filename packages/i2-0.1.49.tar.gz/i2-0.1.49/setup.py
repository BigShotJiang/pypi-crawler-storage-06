from setuptools import setup

setup()  # Note: Everything should be in the local setup.cfg
