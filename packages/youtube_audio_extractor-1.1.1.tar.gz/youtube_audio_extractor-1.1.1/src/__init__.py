"""YouTube Audio Extractor - A tool for extracting audio from YouTube videos and playlists."""

__version__ = "1.1.0"
__author__ = "YouTube Audio Extractor"
__description__ = "Extract audio from YouTube videos and playlists, convert to MP3 format"