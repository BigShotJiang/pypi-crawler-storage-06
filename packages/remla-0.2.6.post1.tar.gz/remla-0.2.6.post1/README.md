# Remla

Remla is a portmanteau of Remote Labs. It is used to control physics laboratory equipment over the internet.