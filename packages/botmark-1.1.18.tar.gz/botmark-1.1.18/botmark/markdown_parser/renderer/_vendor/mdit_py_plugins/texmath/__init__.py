from .index import texmath_plugin

__all__ = ("texmath_plugin",)
