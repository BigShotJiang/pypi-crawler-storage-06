export const DOCDB_POPUP = "peek-core-docdb-popup";
