=======================
Peek Document DB Plugin
=======================

This is a Peek Plugin that provides an online / offline storage for simple JSON
documents.

An example use of this is storing equipment details.