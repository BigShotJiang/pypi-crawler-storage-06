# License: BSD-3-Clause
# Copyright the MNE Qt Browser contributors.

from ._pg_figure import MNEQtBrowser  # noqa
