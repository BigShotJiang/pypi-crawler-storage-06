# Locales module for physicar deepracer cloud
