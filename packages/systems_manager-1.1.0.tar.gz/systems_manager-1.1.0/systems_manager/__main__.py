#!/usr/bin/python
# coding: utf-8
from systems_manager.systems_manager_mcp import systems_manager_mcp

if __name__ == "__main__":
    systems_manager_mcp()
