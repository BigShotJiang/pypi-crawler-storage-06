Sup Language Support
====================
Sup Language Support
====================

Basic syntax highlighting for SUP (`.sup`).

Install from VSIX:
```
code --install-extension sup-language-support-0.0.1.vsix
```

Syntax highlighting for `.sup` files.

Package
-------

Install Node.js, then:
```
npm i -g @vscode/vsce
cd vscode-extension
vsce package
```
This produces a `.vsix` that you can install in VS Code via Extensions → "Install from VSIX".

