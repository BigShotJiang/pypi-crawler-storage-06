## Code of Conduct

Be respectful and inclusive. Harassment and discrimination are not tolerated.

Report incidents to maintainers. Consequences for violations include warnings or bans.


