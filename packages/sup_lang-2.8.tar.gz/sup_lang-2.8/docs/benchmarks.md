## Benchmarks

High-level microbenchmarks to track performance over time. Automate in CI and publish deltas.

- Arithmetic loops and function calls
- List operations and string joins
- File IO and JSON parse/stringify

Planned: publish charts and gate regressions per commit.


