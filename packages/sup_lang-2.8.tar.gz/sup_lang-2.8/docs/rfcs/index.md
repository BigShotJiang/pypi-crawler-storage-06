## RFCs

Propose significant changes via RFCs. Start by copying `0000-template.md` and opening a PR for discussion.


