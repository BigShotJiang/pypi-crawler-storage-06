---
title: RFC Template
status: draft
authors: []
---

## Summary

One paragraph explaining the feature or change.

## Motivation

Why we need this and what problems it solves.

## Detailed design

Syntax, semantics, examples, edge cases.

## Drawbacks

Potential downsides.

## Alternatives

Other options considered.

## Unresolved questions

Follow-ups and open items.


