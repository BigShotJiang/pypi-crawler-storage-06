## Code of Conduct

We are committed to a welcoming, harassment‑free experience for everyone. Be respectful, assume good intent, and collaborate constructively.

Unacceptable behavior includes harassment, personal attacks, hate speech, trolling, and excessive disruption.

Report incidents privately via the process in `SECURITY.md`. Repeated violations may result in removal from the community.


