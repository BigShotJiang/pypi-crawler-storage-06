"""Tools for handling general bispectrum and threenorm computations."""

from .general import Bispectrum, Threenorm
