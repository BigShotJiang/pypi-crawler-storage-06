Installation
============

How do you get this thing working?