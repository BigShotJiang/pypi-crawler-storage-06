Examples
========

This is how you use `fgspectra`.