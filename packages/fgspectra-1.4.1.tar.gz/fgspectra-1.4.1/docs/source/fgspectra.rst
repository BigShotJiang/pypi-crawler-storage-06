fgspectra package
=================

Submodules
----------

fgspectra.cross module
----------------------

.. automodule:: fgspectra.cross
    :members:
    :undoc-members:
    :show-inheritance:

fgspectra.frequency module
--------------------------

.. automodule:: fgspectra.frequency
    :members:
    :undoc-members:
    :show-inheritance:

fgspectra.model module
----------------------

.. automodule:: fgspectra.model
    :members:
    :undoc-members:
    :show-inheritance:

fgspectra.power module
----------------------

.. automodule:: fgspectra.power
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: fgspectra
    :members:
    :undoc-members:
    :show-inheritance:
