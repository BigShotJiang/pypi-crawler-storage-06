"""argo-metadata-validator Python package."""
