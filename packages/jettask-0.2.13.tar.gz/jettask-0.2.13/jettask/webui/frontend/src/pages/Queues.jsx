import React from 'react';
import QueueMonitor from './QueueMonitor';

function Queues() {
  return (
    <div className="page-wrapper">
      <QueueMonitor />
    </div>
  );
}

export default Queues;