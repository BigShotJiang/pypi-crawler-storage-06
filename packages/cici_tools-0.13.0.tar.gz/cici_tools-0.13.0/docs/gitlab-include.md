# GitLab CI/CD Includes

cici supports rendering GitLab CI/CD include files. This is the mechanism in
GitLab that predated GitLab CI/CD Components for sharing CI/CD code between
projects.
