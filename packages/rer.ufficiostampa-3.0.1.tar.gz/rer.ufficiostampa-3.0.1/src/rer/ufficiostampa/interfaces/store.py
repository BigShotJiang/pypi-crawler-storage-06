from zope.interface import Interface


class ISubscriptionsStore(Interface):
    """Marker interface"""


class ISendHistoryStore(Interface):
    """Marker interface"""
