from setuptools import setup

setup(name="osbuild", version="2")
