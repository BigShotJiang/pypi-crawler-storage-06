# Copyright Contributors to the Packit project.
# SPDX-License-Identifier: MIT

from packit.utils.logging import set_logging

# debug logs from packit while testing
set_logging(level=10)
