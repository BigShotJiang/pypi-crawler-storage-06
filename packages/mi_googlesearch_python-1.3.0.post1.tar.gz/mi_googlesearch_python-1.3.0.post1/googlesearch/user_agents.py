import random

def get_useragent():
    """
    Lynx was deprecated 2025.9, so we using something else.
    """

    return f"AdsBot-Google (+http://www.google.com/adsbot.html)"