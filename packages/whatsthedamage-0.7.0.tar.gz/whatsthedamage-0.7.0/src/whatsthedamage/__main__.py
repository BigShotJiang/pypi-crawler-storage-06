if __name__ == "__main__":
    from whatsthedamage.controllers.cli import main_cli
    main_cli()
