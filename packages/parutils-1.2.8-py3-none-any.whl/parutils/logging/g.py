from . import Logger

logger: Logger = None
