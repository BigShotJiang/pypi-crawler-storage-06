CL = [
    "Log file initialised",
    "Python version:",
    "Test of like functions",
    "like simple ok",
    "like m ok",
    "like_list ok",
    "like_dict ok",
    "Test get_duration_string",
]
