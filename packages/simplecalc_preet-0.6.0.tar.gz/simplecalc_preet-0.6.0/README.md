# My Calculator

A simple Python package to perform basic arithmetic operations: add, subtract, multiply, divide.

## Installation

```bash
pip install mycalculator