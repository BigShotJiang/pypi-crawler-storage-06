Módulo base para modelos de la Agencia Tributaria Canaria.
