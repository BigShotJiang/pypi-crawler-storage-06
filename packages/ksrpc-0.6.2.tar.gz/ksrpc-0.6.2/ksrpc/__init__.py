from ksrpc._version import __version__
