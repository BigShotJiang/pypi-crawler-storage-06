import warnings

warnings.warn('此库仅供学习交流，请在数据提供方的授权范围内使用。请勿向第三方转发数据')
