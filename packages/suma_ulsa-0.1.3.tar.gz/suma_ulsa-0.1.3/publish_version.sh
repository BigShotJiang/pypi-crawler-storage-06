maturin build
maturin publish -r pypi