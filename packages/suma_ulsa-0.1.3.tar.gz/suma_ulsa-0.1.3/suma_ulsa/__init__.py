# suma_ulsa/__init__.py
from . import boolean_algebra
