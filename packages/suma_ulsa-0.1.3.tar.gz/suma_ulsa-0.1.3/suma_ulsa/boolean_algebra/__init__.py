# suma_ulsa/boolean_algebra/__init__.py
from . import generate_truth_table
