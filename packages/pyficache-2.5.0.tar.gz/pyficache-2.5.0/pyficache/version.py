# This file is needs to be multi-lingual in both Python and POSIX
# shell which "execfile" or "source" it respectively.

# This file should define a variable VERSION which we use as the
# package version number.

# fmt: off
__version__="2.5.0"  # noqa
