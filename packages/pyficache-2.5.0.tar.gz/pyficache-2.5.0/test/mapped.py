x = 1              # line 1
y = 2              # line 2
# a comment        # line 3
# another comment  # line 4
z = 4              # line 5
a = 5              # line 6
# Note: this file is used in testing line remappings
