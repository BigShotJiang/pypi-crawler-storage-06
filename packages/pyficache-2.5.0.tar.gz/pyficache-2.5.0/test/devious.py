# Some statements which may be hard to parse with a hacky parser
z = '''
Now is the time
'''
x = 1 \
  + 2
z = '''Now is the time
# another time'''  # ; a=5 # STILL HAVE A BUG HERE 
a = 1; b=2 
