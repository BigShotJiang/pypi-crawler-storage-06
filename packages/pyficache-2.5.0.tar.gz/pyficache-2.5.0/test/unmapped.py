x = 1; y = 2       # line 1
# a comment        # line 2
# another comment  # line 3
z = 4              # line 4
a = 5              # line 5
# Note: this file is used in testing line remappings
# this is what file looks before unmapping
