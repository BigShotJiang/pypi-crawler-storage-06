#!/usr/bin/env python
"""
setuptools setup (setup.py) for pyficache

This gets a bit of package info from __pkginfo__.py file
"""

# Get the required package information


from setuptools import setup

setup(packages=["pyficache"])
