"""Python client app for ICMD® API."""

from .core import ICMD

__all__ = ["ICMD"]
