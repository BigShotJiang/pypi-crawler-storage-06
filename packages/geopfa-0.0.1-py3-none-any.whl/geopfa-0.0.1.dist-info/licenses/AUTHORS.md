# Credits

This package was developed at the `Strategic Energy Analysis and Decision Sciences (SEADS)`
directorate at the `National Renewable Energy Laboratory (NREL)`.

* National Renewable Energy Laboratory

## Development Lead

* Nicole Taverna <nicole.taverna@nrel.gov>

## Contributors

* 

## Acknowledgements

* This package was based on the [template](https://github.com/castelao/NREL-pypackage-template) created by Gui Castelão and Paul Pinchuk.
