from port_ocean.cli.commands.main import cli_start


if __name__ == "__main__":
    cli_start()
