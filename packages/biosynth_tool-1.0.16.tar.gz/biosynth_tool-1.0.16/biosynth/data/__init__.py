"""
Data modules for BioSynth.
"""
