# Register new categories and units used from CaseDescription
from alfasim_sdk._internal.units import register_units

register_units()
