def test_smoke_test():
    """Smoke test to ensure the hook specs are importable."""
    import alfasim_sdk._internal.hook_specs  # noqa
    import alfasim_sdk._internal.hook_specs_gui  # noqa
