from mcp_pped import main
main()

