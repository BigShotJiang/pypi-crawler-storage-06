..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alizee Pace
- Bruno Cuc
- Esteban J. G. Gabancho
- Javier Martin Montull
- Jiri Kuncar
- Lars Holm Nielsen
- Leonardo Rossi
- Mihai Bivol
- Paulina Lach
- Samuele Kaplun
- Tibor Simko
