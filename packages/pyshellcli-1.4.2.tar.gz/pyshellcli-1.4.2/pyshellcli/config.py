current_terminal_layout = 5
