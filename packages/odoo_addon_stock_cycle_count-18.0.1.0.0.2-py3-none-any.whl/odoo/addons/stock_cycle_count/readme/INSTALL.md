To install this module, you need to:

- Download this module to your addons path.
- Install the module in your database.

## Recommendations

It is highly recommended to use this module in conjunction with:

- `stock_inventory_verification_request`: Adds the capability to request
  Slot Verifications.
- `stock_inventory_lockdown`: Lock down locations during inventories.
