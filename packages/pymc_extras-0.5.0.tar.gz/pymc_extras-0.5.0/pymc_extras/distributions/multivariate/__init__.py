from pymc_extras.distributions.multivariate.r2d2m2cp import R2D2M2CP

__all__ = ["R2D2M2CP"]
