import enum


class ColourEnum(enum.IntEnum):
    RED = 0
    GREEN = 1
    BLUE = 2
