from fastcs.controller import Controller


class TemperatureController(Controller):
    pass
