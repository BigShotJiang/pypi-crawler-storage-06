from enum import Enum

class Income():
    def __init__():
        pass
        

class IncomePhase(Enum):
    PREFINANCED = 1
    FINANCED    = 2
