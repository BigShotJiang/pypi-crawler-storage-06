# Copyright (C) 2025 Roberto Rossini <roberros@uio.no>
#
# SPDX-License-Identifier: MIT

import pathlib
import sys

sys.path.append(str(pathlib.Path(__file__).parent / "test_helpers"))
