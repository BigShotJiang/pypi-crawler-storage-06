# Copyright (C) 2024 Roberto Rossini <roberroso@uio.no>
#
# SPDX-License-Identifier: MIT

from importlib.metadata import version

__version__ = version("stripepy-hic")
