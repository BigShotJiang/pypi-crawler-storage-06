__version__ = "1.0.6"

from .deploy import PackageDeploy