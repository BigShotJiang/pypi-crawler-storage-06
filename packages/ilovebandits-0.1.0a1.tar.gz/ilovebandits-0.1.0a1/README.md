# ilovebandits
Advanced tools for multi-armed and contextual bandits
WIP (WORK IN PROGESS) PRE ALPHA VERSION
