"""
Kraken utilities

Common utilities for HTTP handling, logging, and other shared functionality.
"""

__all__ = []