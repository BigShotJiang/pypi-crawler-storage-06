API Reference
=============

.. toctree::
    :maxdepth: 1
    :glob:

    /api/*/*/index
