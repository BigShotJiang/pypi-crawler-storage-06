.. py:currentmodule:: rubin_scheduler.scheduler

.. _fbs-api-model-observatory:

Model Observatory
^^^^^^^^^^^^^^^^^

.. automodule:: rubin_scheduler.scheduler.model_observatory
    :imported-members:
    :members:
    :show-inheritance:
