.. py:currentmodule:: rubin_scheduler.scheduler

.. _fbs-api-example-scheduler:


Example Scheduler
^^^^^^^^^^^^^^^^^

.. automodule:: rubin_scheduler.scheduler.example
    :imported-members:
    :members:
    :show-inheritance:
