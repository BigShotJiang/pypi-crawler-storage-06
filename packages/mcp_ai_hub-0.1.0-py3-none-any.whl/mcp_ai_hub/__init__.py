"""MCP AI Hub - Unified AI provider access via LiteLM."""

__version__ = "0.1.0"
