from video_music_remover.cli import app

cli = app
