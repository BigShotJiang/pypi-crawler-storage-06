from vkbottle_types.codegen.methods.friends import *  # noqa: F403,F401
