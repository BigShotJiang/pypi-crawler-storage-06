from vkbottle_types.codegen.methods.newsfeed import *  # noqa: F403,F401
