from vkbottle_types.codegen.methods.auth import *  # noqa: F403,F401
