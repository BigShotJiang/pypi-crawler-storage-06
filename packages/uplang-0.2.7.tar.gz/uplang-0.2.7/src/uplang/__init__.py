"""
Uplang - A Minecraft mod language synchronization tool.
"""

"""
Uplang - A Minecraft mod language synchronization tool.
"""

from . import cli

def main():
    """Main entry point for the uplang command-line tool."""
    cli.cli()





if __name__ == "__main__":
    main()
