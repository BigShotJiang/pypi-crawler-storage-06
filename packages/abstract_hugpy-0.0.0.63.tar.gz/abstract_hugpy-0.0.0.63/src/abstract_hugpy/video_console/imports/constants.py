import os
REMOVE_PHRASES = ['Video Converter', 'eeso', 'Auseesott', 'Aeseesott', 'esoft']
VIDEOS_DIRECTORY = '/mnt/24T/hugging_face/videos'
REMOVE_PHRASES = ['Video Converter', 'eeso', 'Auseesott', 'Aeseesott', 'esoft']
TEXT_DIR = '/mnt/24T/shared_repository/text_dir'
os.makedirs(TEXT_DIR, exist_ok=True)
