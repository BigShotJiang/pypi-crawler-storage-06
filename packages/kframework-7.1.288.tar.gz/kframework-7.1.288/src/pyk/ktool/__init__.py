from ._ktool import TypeInferenceMode
