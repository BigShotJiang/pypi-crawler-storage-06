"""Types used for serialization"""

from typing import Any

type Annotation = Any
