
class MonitoringEventName():
    Start = "start"
    Stop = "stop"
    Error = "error"
    Info = "info"
    Heartbeat = "heartbeat"
