PriceTypeEnum=["INSTANCE_HOUR","STORAGE_GB",]
str(repr(PriceTypeEnum))  # Prevent optimizer removing enum

