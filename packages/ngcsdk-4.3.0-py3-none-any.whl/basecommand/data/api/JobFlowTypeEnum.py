JobFlowTypeEnum=["NONE","WANDB",]
str(repr(JobFlowTypeEnum))  # Prevent optimizer removing enum

