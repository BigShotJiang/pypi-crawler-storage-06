ProductEnablementTypeEnum=["NGC_ADMIN_EVAL","NGC_ADMIN_NFR","NGC_ADMIN_COMMERCIAL","EMS_EVAL","EMS_NFR","EMS_COMMERCIAL",]
str(repr(ProductEnablementTypeEnum))  # Prevent optimizer removing enum

