JobArrayTypeEnum=["MPI","PARALLEL","PYTORCH","HOROVOD",]
str(repr(JobArrayTypeEnum))  # Prevent optimizer removing enum

