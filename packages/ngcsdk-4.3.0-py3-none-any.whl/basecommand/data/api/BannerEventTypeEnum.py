BannerEventTypeEnum=["INCIDENT",]
str(repr(BannerEventTypeEnum))  # Prevent optimizer removing enum

