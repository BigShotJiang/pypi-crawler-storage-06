StorageResourceStatusEnum=["INITIALIZING","CREATED","COMPLETED","CONVERTED","DELETED",]
str(repr(StorageResourceStatusEnum))  # Prevent optimizer removing enum

