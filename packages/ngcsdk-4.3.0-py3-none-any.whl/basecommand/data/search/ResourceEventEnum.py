ResourceEventEnum=["DELETE","CREATE","UPDATE",]
str(repr(ResourceEventEnum))  # Prevent optimizer removing enum

