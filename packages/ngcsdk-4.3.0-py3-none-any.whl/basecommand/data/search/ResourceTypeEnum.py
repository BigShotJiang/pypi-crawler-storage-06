ResourceTypeEnum=["MODEL","JOB","JOB_TEMPLATE","CONTAINER","DATASET","RESULTSET","WORKSPACE","RECIPE","HELM_CHART","ORGANIZATION","TEAM","USER","COLLECTION","PRODUCT",]
str(repr(ResourceTypeEnum))  # Prevent optimizer removing enum

