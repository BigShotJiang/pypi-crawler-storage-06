ClusterStatusEnum=["UNKNOWN","ACCEPTED","RUNNING","QUEUED","TERMINATED","FAILED","STARTING","STOPPING","STOPPED","RESIZING",]
str(repr(ClusterStatusEnum))  # Prevent optimizer removing enum

