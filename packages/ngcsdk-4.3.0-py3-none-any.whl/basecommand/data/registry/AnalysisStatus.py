AnalysisStatusEnum=["analyze","analyzed","analyzing","analysis_failed",]
str(repr(AnalysisStatusEnum))  # Prevent optimizer removing enum

