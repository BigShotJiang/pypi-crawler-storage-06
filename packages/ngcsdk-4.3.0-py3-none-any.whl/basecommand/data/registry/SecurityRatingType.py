SecurityRatingTypeEnum=["AAA","AA","A","B","C",]
str(repr(SecurityRatingTypeEnum))  # Prevent optimizer removing enum

