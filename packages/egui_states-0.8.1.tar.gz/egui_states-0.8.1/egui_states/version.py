VERSION = "0.8.1"
__version__ = VERSION
