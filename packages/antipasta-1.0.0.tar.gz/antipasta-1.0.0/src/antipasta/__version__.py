"""Version information for antipasta."""

__version__ = "1.0.0"
__version_info__ = tuple(int(i) for i in __version__.split("."))
