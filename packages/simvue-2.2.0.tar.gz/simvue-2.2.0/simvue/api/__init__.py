"""
Simvue API
==========

Module contains methods for interacting with a Simvue server
including accessing/updating objects.

"""
