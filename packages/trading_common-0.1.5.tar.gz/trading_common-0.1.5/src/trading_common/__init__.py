"""
Common utilities for trading platform (Kafka/Postgres/outbox/inbox)
"""

__version__ = "0.1.0"
