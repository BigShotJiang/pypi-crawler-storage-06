# backwards compatibility
from pie_core.utils.hydra import resolve_target, resolve_type
