from dbt.adapters.fabric.relation_configs.policies import (
    FabricIncludePolicy,
    FabricQuotePolicy,
    FabricRelationType,
)
