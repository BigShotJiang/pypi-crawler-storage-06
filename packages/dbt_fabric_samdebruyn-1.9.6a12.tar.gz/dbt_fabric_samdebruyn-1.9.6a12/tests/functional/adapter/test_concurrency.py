from dbt.tests.adapter.concurrency.test_concurrency import BaseConcurrency


class TestConcurrency(BaseConcurrency):
    pass
