from dbt.tests.adapter.utils.test_intersect import BaseIntersect


class TestIntersectFabric(BaseIntersect):
    pass
