from dbt.tests.adapter.utils.test_length import BaseLength


class TestLengthFabric(BaseLength):
    pass
