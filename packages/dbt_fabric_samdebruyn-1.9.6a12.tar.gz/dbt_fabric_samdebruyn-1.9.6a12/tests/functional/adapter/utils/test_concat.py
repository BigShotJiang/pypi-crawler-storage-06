from dbt.tests.adapter.utils.test_concat import BaseConcat


class TestConcatFabric(BaseConcat):
    pass
