1.  Go to *Sales \> Orders \> Quotations*
2.  Create a new quotation.
3.  Set Delivery Date on a public holiday.
4.  Confirm the order.
5.  An exception will be displayed.
