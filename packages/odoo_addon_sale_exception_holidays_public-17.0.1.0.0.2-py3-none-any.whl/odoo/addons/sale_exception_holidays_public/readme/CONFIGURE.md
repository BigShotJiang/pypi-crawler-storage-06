1.  Go to *Settings \> Technical \> Exception Rules*.
2.  Activate the rule *Delivery Date is a public holiday*.
