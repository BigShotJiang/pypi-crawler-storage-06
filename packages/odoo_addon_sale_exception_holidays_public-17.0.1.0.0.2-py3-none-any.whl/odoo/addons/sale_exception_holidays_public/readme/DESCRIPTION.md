This module raises a sale exception if there is a commitment_date on the
SO and this date is a public holidays for the shipping partner address.
