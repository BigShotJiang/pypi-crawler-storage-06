The creation of this module to 16.0 was financially supported by
Camptocamp.
