.. PynFact! documentation master file, created by
   sphinx-quickstart on Fri Mar 13 17:05:00 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PynFact!'s documentation!
====================================

.. toctree::
    :maxdepth: 1
    :caption: Table of Contents:

    meta/README.rst
    meta/CHANGELOG.rst
    meta/TODO.rst
    userdoc/index.rst
    meta/LICENSE.rst
    src/modules.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
