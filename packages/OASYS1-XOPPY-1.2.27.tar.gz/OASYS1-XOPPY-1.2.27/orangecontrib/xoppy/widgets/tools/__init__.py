__author__ = 'srio'

NAME = "XOPPY: Tools"

ID = "orangecontrib.xoppy.widgets.tools"

DESCRIPTION = """Widgets for x-ray oriented programs under python (xoppy)"""

LONG_DESRIPTION = """
Miscellanea Tools

"""

ICON = "icons/xoppy_2.png"

BACKGROUND = "#FFD39F"

PRIORITY = 2003
