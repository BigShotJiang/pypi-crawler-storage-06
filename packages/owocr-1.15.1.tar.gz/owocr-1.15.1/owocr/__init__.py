from owocr.ocr import *
