from .known_alloy import register_alloy_known_alloy
from .resources import register_alloy_resources

__all__ = ["register_alloy_known_alloy", "register_alloy_resources"]
