from .tco import TailCall, tco

# fmt: off
__all__ = [
    "TailCall", "tco",  # tail call optimization
]
# fmt: on
