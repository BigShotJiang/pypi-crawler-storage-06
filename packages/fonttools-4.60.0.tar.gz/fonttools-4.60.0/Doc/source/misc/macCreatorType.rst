##############################################################
macCreatorType: Functions for working with Mac file attributes
##############################################################

.. currentmodule:: fontTools.misc.macCreatorType

.. rubric:: Overview:
   :heading-level: 2

Note: this module requires the `xattr <https://pypi.org/project/xattr/>`_
module to be installed in order to function correctly.

.. automodule:: fontTools.misc.macCreatorType
   :members:
   :undoc-members:
