###########################################
textTools: Tools for working with text data
###########################################

.. currentmodule:: fontTools.misc.textTools

.. automodule:: fontTools.misc.textTools
   :members:
   :undoc-members:
