#####################################################
timeTools: Tools for working with OpenType timestamps
#####################################################

.. currentmodule:: fontTools.misc.timeTools

.. automodule:: fontTools.misc.timeTools
   :members:
   :undoc-members:
