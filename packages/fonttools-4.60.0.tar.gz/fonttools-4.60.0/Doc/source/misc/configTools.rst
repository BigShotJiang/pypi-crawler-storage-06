############################################################
configTools: Tools for interfacing with Python configuration
############################################################

.. currentmodule:: fontTools.misc.configTools

.. automodule:: fontTools.misc.configTools
   :members:
   :undoc-members:
