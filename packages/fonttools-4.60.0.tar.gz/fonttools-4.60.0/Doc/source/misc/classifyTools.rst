###########################################
classifyTools: Tools for set classification
###########################################

.. currentmodule:: fontTools.misc.classifyTools

.. automodule:: fontTools.misc.classifyTools
   :members:
   :undoc-members:
