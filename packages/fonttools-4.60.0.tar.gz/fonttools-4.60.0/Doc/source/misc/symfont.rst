####################################################################
symfont: Tools for working with Beziers through symbolic mathematics
####################################################################

.. currentmodule:: fontTools.misc.symfont

Note also that :mod:`misc.symfont` supports some :doc:`optional </optional>`
external libraries.
    
.. automodule:: fontTools.misc.symfont
   :members:
   :undoc-members:
