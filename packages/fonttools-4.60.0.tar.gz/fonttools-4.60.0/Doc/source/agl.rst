######################################
agl: Interface to the Adobe Glyph List
######################################

.. rubric:: Overview:
   :heading-level: 2

.. automodule:: fontTools.agl
   :members: 
   :undoc-members:
   :member-order: bysource

    
    .. rubric:: Module members:
       :heading-level: 2
 
