###################################################
cli: Quadratic-to-cubic converter command-line tool
###################################################

.. rubric:: Overview:
   :heading-level: 2

.. automodule:: fontTools.qu2cu.cli
   :members:
   :undoc-members:
     
    .. rubric:: Module members:
       :heading-level: 2
