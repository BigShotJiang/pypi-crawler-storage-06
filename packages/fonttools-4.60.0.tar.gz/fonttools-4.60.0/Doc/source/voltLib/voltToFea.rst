#################################################
voltToFea: Convert MS VOLT to AFDKO feature files
#################################################

.. currentmodule:: fontTools.voltLib.voltToFea

.. automodule:: fontTools.voltLib.voltToFea
   :members:
   :undoc-members:
