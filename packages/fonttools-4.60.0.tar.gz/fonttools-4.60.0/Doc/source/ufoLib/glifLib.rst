#######################################
glifLib: Read and write UFO .glif files
#######################################

.. automodule:: fontTools.ufoLib.glifLib
   :members:
   :undoc-members:
