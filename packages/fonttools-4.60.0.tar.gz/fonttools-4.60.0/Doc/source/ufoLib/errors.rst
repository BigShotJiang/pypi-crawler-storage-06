###################################################
errors: Exceptions for handling UFO-specific errors
###################################################

.. automodule:: fontTools.ufoLib.errors
   :members:
   :undoc-members:
