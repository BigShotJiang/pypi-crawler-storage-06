#########################################
width: T2CharString glyph width optimizer
#########################################

.. automodule:: fontTools.cffLib.width
   :members: optimizeWidths, optimizeWidthsBruteforce
