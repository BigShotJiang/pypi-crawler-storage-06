``BASE``: Baseline table
------------------------

The ``BASE`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.B_A_S_E_
   :members:
   :undoc-members:

