``TTFA``: ttfautohint Parameter table
-----------------------------------------

The ``TTFA`` table is used by the ``ttfautohint`` hinting program.

.. automodule:: fontTools.ttLib.tables.T_T_F_A_
   :members:
   :undoc-members:

