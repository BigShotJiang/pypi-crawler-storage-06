``HVAR``: Horizontal Metrics Variations table
---------------------------------------------

The ``HVAR`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.H_V_A_R_
   :members:
   :undoc-members:
