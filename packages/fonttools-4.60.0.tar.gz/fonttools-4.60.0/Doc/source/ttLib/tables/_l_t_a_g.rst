``ltag``: Language Tag table
----------------------------

The ``ltag`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._l_t_a_g
   :members:
   :undoc-members:

