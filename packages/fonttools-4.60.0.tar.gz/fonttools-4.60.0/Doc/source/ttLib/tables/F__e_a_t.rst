``Feat``: Graphite Feature table
--------------------------------

The ``Feat`` table is a Graphite table.

.. automodule:: fontTools.ttLib.tables.F__e_a_t
   :members:
   :undoc-members:


