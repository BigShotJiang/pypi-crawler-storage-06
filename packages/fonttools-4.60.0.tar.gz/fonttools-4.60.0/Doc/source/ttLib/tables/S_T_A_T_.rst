``STAT``: Style Attributes table
--------------------------------

The ``STAT`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.S_T_A_T_
   :members:
   :undoc-members:
