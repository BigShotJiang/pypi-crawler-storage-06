``META``: SING Glyphlet Metadata table
--------------------------------------

The ``META`` table is an Adobe Glyphlets table.

.. automodule:: fontTools.ttLib.tables.M_E_T_A_
   :members:
   :undoc-members:
