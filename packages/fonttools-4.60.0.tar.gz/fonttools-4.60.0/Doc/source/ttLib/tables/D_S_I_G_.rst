``DSIG``: Digital Signature table
---------------------------------

The ``DSIG`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.D_S_I_G_
   :members:
   :undoc-members:

