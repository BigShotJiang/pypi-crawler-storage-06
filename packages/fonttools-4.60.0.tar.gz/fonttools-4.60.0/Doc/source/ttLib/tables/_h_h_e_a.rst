``hhea``: Horizontal Header table
---------------------------------

The ``hhea`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._h_h_e_a
   :members:
   :undoc-members:

