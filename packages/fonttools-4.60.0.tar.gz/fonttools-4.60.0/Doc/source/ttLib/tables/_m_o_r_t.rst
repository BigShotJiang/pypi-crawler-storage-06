``mort``: Glyph Metamorphosis Table
-----------------------------------

The ``mort`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._m_o_r_t
   :members:
   :undoc-members:


