``gcid``: Glyph ID to CID table
-------------------------------

The ``gcid`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._g_c_i_d
   :members:
   :undoc-members:
