``feat``: Feature name table
----------------------------

The ``feat`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._f_e_a_t
   :members:
   :undoc-members:
