``SVG``: SVG (Scalable Vector Graphics) table
---------------------------------------------

The ``SVG`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.S_V_G_
   :members:
   :undoc-members:

