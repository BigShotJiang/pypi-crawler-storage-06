``MVAR``: Metrics Variations table
----------------------------------

The ``MVAR`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables.M_V_A_R_
   :members:
   :undoc-members:
