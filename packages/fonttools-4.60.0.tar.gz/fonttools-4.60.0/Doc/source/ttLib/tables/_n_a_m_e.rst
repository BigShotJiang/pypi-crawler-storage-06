``name``: Naming table
----------------------

The ``name`` table is an OpenType table.

.. automodule:: fontTools.ttLib.tables._n_a_m_e
   :members:
   :undoc-members:

