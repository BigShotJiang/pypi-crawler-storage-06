``trak``: Tracking table
------------------------

The ``trak`` table is an Apple Advanced Typography (AAT) table.

.. automodule:: fontTools.ttLib.tables._t_r_a_k
   :members:
   :undoc-members:

