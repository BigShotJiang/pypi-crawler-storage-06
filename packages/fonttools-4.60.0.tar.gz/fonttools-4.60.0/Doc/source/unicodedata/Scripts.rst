#######
Scripts
#######

.. currentmodule:: fontTools.unicodedata.Scripts

.. automodule:: fontTools.unicodedata.Scripts
   :members:
   :undoc-members:

.. data:: fontTools.unicodedata.Scripts.NAMES

.. data:: fontTools.unicodedata.Scripts.RANGES

.. data:: fontTools.unicodedata.Scripts.VALUES


