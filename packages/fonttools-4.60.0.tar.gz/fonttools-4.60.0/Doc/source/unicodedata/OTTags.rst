######
OTTags
######

.. currentmodule:: fontTools.unicodedata.OTTags

.. automodule:: fontTools.unicodedata.OTTags
   :members:
   :undoc-members:

.. data:: fontTools.unicodedata.OTTags.DEFAULT_SCRIPT

.. data:: fontTools.unicodedata.OTTags.SCRIPT_EXCEPTIONS

.. data:: fontTools.unicodedata.OTTags.NEW_SCRIPT_TAGS

.. data:: fontTools.unicodedata.OTTags.NEW_SCRIPT_TAGS_REVERSED

