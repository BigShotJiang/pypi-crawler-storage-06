###############################################
afmLib: Read and write Adobe Font Metrics files
###############################################

.. rubric:: Overview:
   :heading-level: 2
		   
.. automodule:: fontTools.afmLib
   :members: 
   :undoc-members:


    .. rubric:: Module members:
       :heading-level: 2
 
