############################################
cff: Tools for subsetting CFF-flavored fonts
############################################

.. currentmodule:: fontTools.subset.cff

.. automodule:: fontTools.subset.cff
   :members:
   :undoc-members:
