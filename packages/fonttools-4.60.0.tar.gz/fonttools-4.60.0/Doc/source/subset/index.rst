########################################################
subset: Generate subsets of fonts or optimize file sizes
########################################################

.. currentmodule:: fontTools.subset

.. toctree::
   :maxdepth: 1

   cff

.. automodule:: fontTools.subset
   :members:
   :undoc-members:
