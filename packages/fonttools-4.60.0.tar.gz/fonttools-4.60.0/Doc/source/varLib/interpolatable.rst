##############
interpolatable
##############

Note also that :mod:`varLib.interpolatable` supports some :doc:`optional </optional>`
external libraries.

.. automodule:: fontTools.varLib.interpolatable
   :members:
   :undoc-members:
