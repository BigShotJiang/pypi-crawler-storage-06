####
plot
####

    Note also that :mod:`varLib.plot` supports some :doc:`optional </optional>`
    external libraries.
    
.. automodule:: fontTools.varLib.plot
   :members:
   :undoc-members:
