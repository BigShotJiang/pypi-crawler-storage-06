###########
featureVars
###########

.. automodule:: fontTools.varLib.featureVars
   :members:
   :undoc-members:
