######
models
######

.. automodule:: fontTools.varLib.models
   :members:
   :undoc-members:
