###
iup
###

.. automodule:: fontTools.varLib.iup
   :members:
   :undoc-members:
