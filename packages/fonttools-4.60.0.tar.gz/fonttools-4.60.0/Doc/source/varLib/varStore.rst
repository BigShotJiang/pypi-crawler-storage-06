########
varStore
########

.. automodule:: fontTools.varLib.varStore
   :members:
   :undoc-members:
