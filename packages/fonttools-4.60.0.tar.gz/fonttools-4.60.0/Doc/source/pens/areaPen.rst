#######
areaPen
#######

.. automodule:: fontTools.pens.areaPen
   :members:
   :undoc-members:
