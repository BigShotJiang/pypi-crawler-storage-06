########
cocoaPen
########

    Note also that :mod:`cocoaPen` supports some :doc:`optional </optional>`
    external libraries.

.. automodule:: fontTools.pens.cocoaPen
   :members:
   :undoc-members:
