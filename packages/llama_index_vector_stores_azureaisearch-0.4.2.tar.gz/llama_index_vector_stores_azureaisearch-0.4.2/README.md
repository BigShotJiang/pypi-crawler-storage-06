# LlamaIndex Vector_Stores Integration: Azure AI Search
