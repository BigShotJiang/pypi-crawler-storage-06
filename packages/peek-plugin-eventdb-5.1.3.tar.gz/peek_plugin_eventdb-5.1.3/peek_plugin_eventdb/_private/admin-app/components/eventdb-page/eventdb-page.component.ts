
import { Component, ChangeDetectionStrategy } from "@angular/core";

@Component({
    selector: "eventdb-admin",
    templateUrl: "eventdb-page.component.html",
    styleUrls: ["eventdb-page.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EventdbPageComponent {}