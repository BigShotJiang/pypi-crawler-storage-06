eventdbFilt = {"plugin": "peek_plugin_eventdb"}
eventdbTuplePrefix = "peek_plugin_eventdb."
eventdbObservableName = "peek_plugin_eventdb"
eventdbActionProcessorName = "peek_plugin_eventdb"
eventdbTupleOfflineServiceName = "peek_plugin_eventdb"
