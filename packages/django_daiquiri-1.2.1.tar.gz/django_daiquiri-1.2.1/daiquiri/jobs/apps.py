from django.apps import AppConfig


class JobsConfig(AppConfig):
    name = 'daiquiri.jobs'
    label = 'daiquiri_jobs'
    verbose_name = 'Jobs'
