"""Binary FlatBuffer schema resources (bfbs) packaged for runtime access.

This allows importlib.resources to locate FloatArray.bfbs under
'airbot_data_collection.airbot.schemas.airbot_fbs.bfbs'.
"""
