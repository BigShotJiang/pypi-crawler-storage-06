import numpy as np 

arr = np.array(["1", "2"])

print(arr)
print(arr.dtype)