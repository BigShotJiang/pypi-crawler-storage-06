swig -python -c++ -o htmc_wrap.cc htmc.i
