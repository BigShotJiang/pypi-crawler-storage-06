def temp_func():
    return "This is a temporary function."

def another_temp_func():
    return "This is another temporary function."