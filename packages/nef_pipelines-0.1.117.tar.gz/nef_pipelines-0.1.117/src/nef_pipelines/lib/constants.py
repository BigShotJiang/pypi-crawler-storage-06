NEF_PIPELINES = "NEFPipelines"

NEF_VERSION = "1.1"

NEF_META_DATA = "nef_nmr_meta_data"

NEF_UNKNOWN = "."

EXIT_ERROR = 1
