=====================
Venus Tempest Plugin
=====================

This is a venus tempest plugin package. Tests can be run as a tempest plugin
against any venus-enabled OpenStack cloud.

Please fill here a long description which must be at least 3 lines wrapped on
80 cols, so that distribution package maintainers can use it in their packages.
Note that this is a hard requirement.

* Free software: Apache license
* Documentation: https://docs.openstack.org/venus/latest
* Source: https://opendev.org/openstack/venus-tempest-plugin/
* Bugs: https://bugs.launchpad.net/openstack-venus

Features
--------

* TODO
