from .core import docPrint, flush_cache, docPrintFile, enableGitCommits

__version__ = "1.2.0"
__all__ = [
    "docPrint",
    "flush_cache",
    "docPrintFile",
    "enableGitCommits"
]