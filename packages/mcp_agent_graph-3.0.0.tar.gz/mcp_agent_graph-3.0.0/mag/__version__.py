"""MAG SDK版本信息"""

__version__ = "3.0.0"