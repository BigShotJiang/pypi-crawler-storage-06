"""
Prompt 服务模块
"""
from .prompt_manager import PromptManager

__all__ = ["PromptManager"]