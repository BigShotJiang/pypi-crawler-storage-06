from .entry import pyfcstmcli

if __name__ == '__main__':
    pyfcstmcli()
