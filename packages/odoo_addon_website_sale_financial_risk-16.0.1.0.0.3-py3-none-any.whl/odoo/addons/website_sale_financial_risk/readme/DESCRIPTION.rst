If a customer has sufficient credit, they can complete their purchase by paying with a 
specific payment method. In this case, the order is automatically confirmed.