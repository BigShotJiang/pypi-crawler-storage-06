Activate the ‘On credit’ payment provider and publish it on the website so that it is 
available in the order payment process.
Set a credit limit and configure financial risk settings as described in the 
account_financial_risk module.  
If the configuration has been set to display credit information on the portal, 
this information will also be displayed during the checkout process.
