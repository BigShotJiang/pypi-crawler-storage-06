Place an order in the online store. If you have credit available and the order 
amount does not exceed the available credit, you can place the order by selecting 
credit as the payment method.
