VERSION = "0.0.3"
__version__ = VERSION
APP_NAME = "Dr.Sai-UI"
