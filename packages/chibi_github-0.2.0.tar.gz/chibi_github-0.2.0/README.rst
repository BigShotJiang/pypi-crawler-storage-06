============
chibi_github
============


.. image:: https://img.shields.io/pypi/v/chibi_github.svg
        :target: https://pypi.python.org/pypi/chibi_github

.. image:: https://img.shields.io/travis/dem4ply/chibi_github.svg
        :target: https://travis-ci.org/dem4ply/chibi_github

.. image:: https://readthedocs.org/projects/chibi-github/badge/?version=latest
        :target: https://chibi-github.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




libreria para usar github


* Free software: WTFPL
* Documentation: https://chibi-github.readthedocs.io.


Features
--------

* TODO
