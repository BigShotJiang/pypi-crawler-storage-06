=======
History
=======

0.2.0 ( 2025-09-20 )
--------------------

* cambio de comportamiento a usar excepciones cuando no es 2xx

0.1.2 ( 2025-03-01 )
--------------------

* se cambio el token para usar Bearer y no Token

0.0.1 ( 2020-07-08 )
--------------------

* First release on PyPI.
