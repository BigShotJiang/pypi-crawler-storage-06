=====
Usage
=====

To use chibi_github in a project::

    import chibi_github
