from .hgq2 import trace_model

__all__ = ['trace_model']
