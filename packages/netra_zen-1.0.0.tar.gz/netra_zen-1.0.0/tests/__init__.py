"""
Test suite for Zen Claude Orchestrator

This module contains comprehensive tests for token transparency,
pricing compliance, and agent interface functionality.
"""