# JobQueues
Unified interface for submitting jobs to various queueing systems.

## Install

To get the latest PyPI release use:

```sh
pip install jobqueues
```

Or if you want the latest github version:

```sh
pip install git+https://github.com/acellera/jobqueues
```

or clone the git and install manually with

```sh
git clone https://github.com/acellera/jobqueues
cd jobqueues
pip install .
```
