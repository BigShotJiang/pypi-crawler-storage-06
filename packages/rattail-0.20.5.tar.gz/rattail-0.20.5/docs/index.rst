
Rattail
=======

Welcome to the Rattail project.

The documentation you are currently reading is for the Rattail core Python
package.  Some additional information is available on the `website`_.  Not
everything is documented yet, but we're getting there...

.. _website: https://rattailproject.org/

This documentation is split into the following primary sections:

.. toctree::
   :maxdepth: 1

   narr/index
   api/index
   glossary
   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
