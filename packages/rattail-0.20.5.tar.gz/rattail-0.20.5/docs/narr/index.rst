
Narrative
=========

This section aims to collect so-called "narrative" documentation, to explain
some of the concepts and other "what/why" things with which Rattail concerns
itself.

.. toctree::
   :maxdepth: 2

   config
   importers
   batches
   receiving/index
   email
   filemon
