
Product Receiving
=================

This section describes the "product receiving" features of Rattail.

.. note::

   This content is rather stale.  Please also see
   :doc:`rattail-manual:features/purchasing/receiving/index` in the
   Rattail Manual.

.. toctree::

   overview
   workflows
