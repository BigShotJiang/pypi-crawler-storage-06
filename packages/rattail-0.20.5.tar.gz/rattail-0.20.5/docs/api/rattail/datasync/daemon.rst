
``rattail.datasync.daemon``
===========================

.. automodule:: rattail.datasync.daemon
   :members:
