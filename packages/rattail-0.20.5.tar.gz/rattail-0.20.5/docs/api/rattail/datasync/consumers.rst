
``rattail.datasync.consumers``
==============================

.. automodule:: rattail.datasync.consumers

.. autoclass:: DataSyncConsumer
   :members:

.. autoclass:: DataSyncImportConsumer
   :members:

.. autoclass:: FromRattailConsumer

.. autoclass:: NullTestConsumer

.. autoclass:: ErrorTestConsumer
