
``rattail.datasync.config``
===========================

.. automodule:: rattail.datasync.config
   :members:
