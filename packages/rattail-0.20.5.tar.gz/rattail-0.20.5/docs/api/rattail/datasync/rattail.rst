
``rattail.datasync.rattail``
============================

.. automodule:: rattail.datasync.rattail
   :members:
