
``rattail.config``
==================

.. automodule:: rattail.config
   :members:
