
``rattail.db.config``
=====================

.. automodule:: rattail.db.config
   :members:
