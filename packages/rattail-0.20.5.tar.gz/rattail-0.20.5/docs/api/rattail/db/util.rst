.. -*- coding: utf-8 -*-

``rattail.db.util``
===================

.. automodule:: rattail.db.util
   :members:
