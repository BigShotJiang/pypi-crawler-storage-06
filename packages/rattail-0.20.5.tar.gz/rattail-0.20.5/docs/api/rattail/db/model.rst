
``rattail.db.model``
====================

.. automodule:: rattail.db.model
