
``rattail.db.model.labels``
===========================

.. automodule:: rattail.db.model.labels
  :members:
