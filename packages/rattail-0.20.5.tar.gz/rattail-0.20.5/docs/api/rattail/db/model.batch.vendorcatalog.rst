
``rattail.db.model.batch.vendorcatalog``
========================================

.. automodule:: rattail.db.model.batch.vendorcatalog
  :members:
