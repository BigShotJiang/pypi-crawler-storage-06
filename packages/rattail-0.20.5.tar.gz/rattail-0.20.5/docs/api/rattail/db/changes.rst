.. -*- coding: utf-8 -*-

``rattail.db.changes``
======================

.. automodule:: rattail.db.changes
   :members:
