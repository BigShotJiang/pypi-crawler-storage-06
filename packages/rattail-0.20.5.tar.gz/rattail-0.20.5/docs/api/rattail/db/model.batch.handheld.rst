
``rattail.db.model.batch.handheld``
===================================

.. automodule:: rattail.db.model.batch.handheld
  :members:
