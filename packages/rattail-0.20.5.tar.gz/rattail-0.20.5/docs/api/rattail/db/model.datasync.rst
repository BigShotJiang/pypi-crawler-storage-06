
``rattail.db.model.datasync``
=============================

.. automodule:: rattail.db.model.datasync
  :members:
