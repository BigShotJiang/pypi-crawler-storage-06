
``rattail.db.model.batch.purchase``
===================================

.. automodule:: rattail.db.model.batch.purchase
  :members:
