
``rattail.db.model.stores``
===========================

.. automodule:: rattail.db.model.stores
  :members:
