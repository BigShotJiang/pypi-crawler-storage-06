
``rattail.db.model.batch.labels``
=================================

.. automodule:: rattail.db.model.batch.labels
  :members:
