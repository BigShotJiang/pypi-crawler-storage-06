
``rattail.db.model.org``
========================

.. automodule:: rattail.db.model.org
  :members:
