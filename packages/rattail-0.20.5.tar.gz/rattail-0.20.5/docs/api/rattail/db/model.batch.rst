
``rattail.db.model.batch``
==========================

.. .. automodule:: rattail.db.model.batch

.. automodule:: rattail.db.model.batch.core

.. autoclass:: BatchMixin
  :members:

.. autoclass:: BaseFileBatchMixin
  :members:

.. autoclass:: FileBatchMixin
  :members:

.. autoclass:: BatchRowMixin
  :members:

.. autoclass:: ProductBatchRowMixin
  :members:
