
``rattail.db.model.customers``
==============================

.. automodule:: rattail.db.model.customers
  :members:
