
``rattail.db.model.batch.pricing``
==================================

.. automodule:: rattail.db.model.batch.pricing
  :members:
