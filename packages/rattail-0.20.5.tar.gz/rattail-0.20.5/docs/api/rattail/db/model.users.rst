
``rattail.db.model.users``
==========================

.. automodule:: rattail.db.model.users
  :members:
