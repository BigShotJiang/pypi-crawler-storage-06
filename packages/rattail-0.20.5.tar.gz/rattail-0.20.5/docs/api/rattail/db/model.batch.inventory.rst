
``rattail.db.model.batch.inventory``
====================================

.. automodule:: rattail.db.model.batch.inventory
  :members:
