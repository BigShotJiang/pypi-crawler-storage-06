
``rattail.db.model.batch.product``
==================================

.. automodule:: rattail.db.model.batch.product
  :members:
