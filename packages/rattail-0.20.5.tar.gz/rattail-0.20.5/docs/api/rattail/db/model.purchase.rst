
``rattail.db.model.purchase``
=============================

.. automodule:: rattail.db.model.purchase
  :members:
