
``rattail.db.model.products``
=============================

.. automodule:: rattail.db.model.products
  :members:
