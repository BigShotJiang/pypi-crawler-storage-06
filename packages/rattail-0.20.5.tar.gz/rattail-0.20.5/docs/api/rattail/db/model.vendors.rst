
``rattail.db.model.vendors``
============================

.. automodule:: rattail.db.model.vendors
  :members:
