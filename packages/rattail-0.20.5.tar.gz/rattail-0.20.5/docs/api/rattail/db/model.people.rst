
``rattail.db.model.people``
===========================

.. automodule:: rattail.db.model.people
  :members:
