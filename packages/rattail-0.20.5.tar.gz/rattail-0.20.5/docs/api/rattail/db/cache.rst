
``rattail.db.cache``
====================

.. automodule:: rattail.db.cache

.. autofunction:: cache_model
