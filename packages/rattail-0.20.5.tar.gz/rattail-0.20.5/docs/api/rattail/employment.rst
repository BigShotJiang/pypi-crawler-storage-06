
``rattail.employment``
======================

.. automodule:: rattail.employment
   :members:
