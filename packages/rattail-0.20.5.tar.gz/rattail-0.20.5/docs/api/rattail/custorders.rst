
``rattail.custorders``
======================

.. automodule:: rattail.custorders
   :members:
