.. -*- coding: utf-8 -*-

``rattail.files``
=================

.. automodule:: rattail.files
   :members:
