
``rattail.bouncer.handler``
===========================

.. automodule:: rattail.bouncer.handler
   :members:
