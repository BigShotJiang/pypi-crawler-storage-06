
``rattail.core``
================

.. automodule:: rattail.core
   :members:
