
``rattail.auth``
================

.. automodule:: rattail.auth
   :members:
