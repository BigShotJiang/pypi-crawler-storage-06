
``rattail.vendors.orders``
==========================

.. automodule:: rattail.vendors.orders
   :members:
