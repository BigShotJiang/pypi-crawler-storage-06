
``rattail.reporting``
=====================

.. automodule:: rattail.reporting
