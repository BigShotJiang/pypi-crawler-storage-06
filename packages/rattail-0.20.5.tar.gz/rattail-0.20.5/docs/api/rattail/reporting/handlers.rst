
``rattail.reporting.handlers``
==============================

.. automodule:: rattail.reporting.handlers

.. autoclass:: ReportHandler
   :members:

.. autofunction:: get_report_handler
