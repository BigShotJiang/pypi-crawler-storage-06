
``rattail.tailbone``
====================

.. automodule:: rattail.tailbone
   :members:
