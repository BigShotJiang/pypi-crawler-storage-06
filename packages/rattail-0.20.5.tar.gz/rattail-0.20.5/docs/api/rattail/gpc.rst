
``rattail.gpc``
===============

.. automodule:: rattail.gpc
   :members:
