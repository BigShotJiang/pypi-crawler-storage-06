.. -*- coding: utf-8 -*-

``rattail.filemon.actions``
===========================

.. automodule:: rattail.filemon.actions
   :members:
