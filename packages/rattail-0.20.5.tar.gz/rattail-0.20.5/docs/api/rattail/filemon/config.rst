
``rattail.filemon.config_``
===========================

.. automodule:: rattail.filemon.config_
   :members:
