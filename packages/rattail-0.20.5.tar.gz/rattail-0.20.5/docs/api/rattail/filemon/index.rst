.. -*- coding: utf-8 -*-

``rattail.filemon``
===================

.. automodule:: rattail.filemon

.. autoclass:: Action
