.. -*- coding: utf-8 -*-

``rattail.filemon.util``
========================

.. automodule:: rattail.filemon.util
   :members:
