
``rattail.labels``
==================

.. automodule:: rattail.labels
   :members:
