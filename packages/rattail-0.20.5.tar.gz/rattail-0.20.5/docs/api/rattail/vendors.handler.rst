
``rattail.vendors.handler``
===========================

.. automodule:: rattail.vendors.handler
   :members:
