
``rattail.util``
================

.. automodule:: rattail.util
   :members:
