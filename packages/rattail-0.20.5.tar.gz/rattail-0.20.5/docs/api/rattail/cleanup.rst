
``rattail.cleanup``
===================

.. automodule:: rattail.cleanup
   :members:
