.. -*- coding: utf-8 -*-

``rattail.csvutil``
===================

.. automodule:: rattail.csvutil
   :members:
