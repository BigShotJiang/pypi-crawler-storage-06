
``rattail.win32``
=================

.. automodule:: rattail.win32
   :members:
