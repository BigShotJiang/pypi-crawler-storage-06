
``rattail.excel``
=================

.. automodule:: rattail.excel
   :members:
