
``rattail.importing.postgresql``
================================

.. automodule:: rattail.importing.postgresql

.. autoclass:: BulkToPostgreSQL
   :members:
