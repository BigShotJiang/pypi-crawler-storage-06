
``rattail.importing.model``
===========================

.. automodule:: rattail.importing.model
   :members:
