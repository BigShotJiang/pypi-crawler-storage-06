
``rattail.logging``
===================

.. automodule:: rattail.logging
   :members:
