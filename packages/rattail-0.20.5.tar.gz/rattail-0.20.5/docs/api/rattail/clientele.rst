
``rattail.clientele``
=====================

.. automodule:: rattail.clientele
   :members:
