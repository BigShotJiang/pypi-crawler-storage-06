
``rattail.membership``
======================

.. automodule:: rattail.membership
   :members:
