
``rattail.commands.base``
=========================

.. automodule:: rattail.commands.base

   .. data:: rattail_typer

      This is a ``typer.Typer`` instance representing the top-level
      ``rattail`` command.  See the `Typer docs`_ for more info.

      .. _Typer docs: https://typer.tiangolo.com/
