
``rattail.enum``
================

.. automodule:: rattail.enum
