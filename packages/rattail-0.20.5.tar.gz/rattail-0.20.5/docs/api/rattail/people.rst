
``rattail.people``
==================

.. automodule:: rattail.people
   :members:
