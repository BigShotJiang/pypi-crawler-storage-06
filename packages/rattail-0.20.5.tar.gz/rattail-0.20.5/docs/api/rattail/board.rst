
``rattail.board``
=================

.. automodule:: rattail.board
   :members:
