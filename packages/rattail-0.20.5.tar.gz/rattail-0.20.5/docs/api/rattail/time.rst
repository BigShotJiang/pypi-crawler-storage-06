.. -*- coding: utf-8 -*-

``rattail.time``
================

.. automodule:: rattail.time
   :members:
