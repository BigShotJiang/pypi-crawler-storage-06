
``rattail.upgrades``
====================

.. automodule:: rattail.upgrades
   :members:
