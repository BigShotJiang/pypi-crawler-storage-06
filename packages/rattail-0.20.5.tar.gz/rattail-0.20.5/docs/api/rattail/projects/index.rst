
``rattail.projects``
====================

.. automodule:: rattail.projects
   :members:

.. toctree::
   :maxdepth: 1

   base
   handler
   rattail
