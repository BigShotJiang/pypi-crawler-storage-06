
``rattail.projects.handler``
============================

.. automodule:: rattail.projects.handler
   :members:
