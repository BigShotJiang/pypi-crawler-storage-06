
``rattail.projects.rattail``
============================

.. automodule:: rattail.projects.rattail
   :members:
