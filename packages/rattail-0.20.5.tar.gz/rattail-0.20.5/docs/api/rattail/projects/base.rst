
``rattail.projects.base``
=========================

.. automodule:: rattail.projects.base
   :members:
