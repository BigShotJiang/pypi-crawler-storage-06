
``rattail.app``
===============

.. automodule:: rattail.app
   :members:
