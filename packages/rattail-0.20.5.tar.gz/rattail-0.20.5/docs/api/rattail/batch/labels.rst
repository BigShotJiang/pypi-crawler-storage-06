
``rattail.batch.labels``
========================

.. automodule:: rattail.batch.labels
   :members:
