
``rattail.batch.custorder``
===========================

.. automodule:: rattail.batch.custorder
   :members:
