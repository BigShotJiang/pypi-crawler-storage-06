
``rattail.batch.vendorcatalog``
===============================

.. automodule:: rattail.batch.vendorcatalog
   :members:
