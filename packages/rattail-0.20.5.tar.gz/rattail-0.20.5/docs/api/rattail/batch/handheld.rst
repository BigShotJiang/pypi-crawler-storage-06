
``rattail.batch.handheld``
==========================

.. automodule:: rattail.batch.handheld
   :members:
