
``rattail.batch.product``
=========================

.. automodule:: rattail.batch.product
   :members:
