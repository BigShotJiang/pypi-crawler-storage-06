
``rattail.batch.pricing``
=========================

.. automodule:: rattail.batch.pricing
   :members:
