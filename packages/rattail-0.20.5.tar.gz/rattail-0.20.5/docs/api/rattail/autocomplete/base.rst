
``rattail.autocomplete.base``
=============================

.. automodule:: rattail.autocomplete.base
   :members:
