
``rattail.autocomplete.customers``
==================================

.. automodule:: rattail.autocomplete.customers
   :members:
