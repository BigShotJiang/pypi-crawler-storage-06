
``rattail.products``
====================

.. automodule:: rattail.products
   :members:
