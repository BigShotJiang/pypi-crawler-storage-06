
``rattail.trainwreck``
======================

.. automodule:: rattail.trainwreck
   :members:

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   handler
