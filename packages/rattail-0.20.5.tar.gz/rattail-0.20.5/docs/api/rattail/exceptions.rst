
``rattail.exceptions``
======================

.. automodule:: rattail.exceptions

.. autoclass:: RattailError

.. .. autoclass:: LabelPrintingError
.. 
.. .. autoclass:: PalmError
.. 
.. .. autoclass:: PalmClassicDatabaseTypelibNotFound
.. 
.. .. autoclass:: PalmConduitManagerNotFound
.. 
.. .. autoclass:: PalmConduitAlreadyRegistered
.. 
.. .. autoclass:: PalmConduitNotRegistered
