
``rattail.commands.make_appdir``
================================

.. automodule:: rattail.commands.make_appdir

   .. autofunction:: make_appdir

   .. program-output:: rattail make-appdir --help
