
``rattail``
===========

.. automodule:: rattail
