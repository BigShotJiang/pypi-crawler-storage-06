from .message import BaseMessageMin

__all__ = ("BaseMessageMin",)
