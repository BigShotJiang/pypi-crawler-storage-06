---
name: Other issues or proposals
about: Use this if no other option suits your needs and you want to fill a "normal" issue.
title: ''
labels: ''
assignees: ''

---
