"""
MCP (Model Context Protocol) server implementation for code quality scanning.
"""

from .server import mcp

__all__ = ["mcp"]