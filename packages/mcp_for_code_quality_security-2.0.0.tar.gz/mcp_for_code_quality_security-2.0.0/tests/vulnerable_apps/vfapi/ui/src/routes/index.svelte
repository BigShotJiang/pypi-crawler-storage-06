<h1>Welcome to Vulnerable FastAPI</h1>

<p>Vulnerable FastAPI, for practing <a href="https://owasp.org/www-project-top-ten/" target="_blank">OWASP Top 10:2021</a> vulnerabilities <a href="http://127.0.0.1:8888/docs"  target="_blank">/docs</a> or <a href="http://127.0.0.1:8888/redoc" target="_blank">/redoc</a> to see the documentation API endpoints.</p>

<p>Currently known vulnerabilities within the API: SQLi, NoSQLi.</p>
