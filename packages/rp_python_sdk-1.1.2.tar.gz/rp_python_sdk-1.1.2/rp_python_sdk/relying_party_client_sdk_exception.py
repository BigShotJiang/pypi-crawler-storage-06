class RelyingPartyClientSdkException(Exception):
    pass
