import logging

logger = logging.getLogger('relying_party_client_sdk')
