def get_version_info() -> str:
    return "1.1.2"  # Version number
