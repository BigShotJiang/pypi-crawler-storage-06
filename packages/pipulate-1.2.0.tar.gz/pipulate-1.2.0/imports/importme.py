print("I am run")

def foo():
    print("by being imported!")

if __name__ == '__main__':
    print("directly from python.")
