#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
def get_version():
    return '1.2.28'
