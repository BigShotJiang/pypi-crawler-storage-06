from .iconfont import IconFont


class FONTCLASSNAME(IconFont):
    _SPECNAME = 'FONTSPECNAME'
