Clock glossary
==============

This is a table with the metadata of the clocks available at the moment on `pyaging`, including additional implementation notes for each clock:

.. csv-table::
   :file: ../_static/clock_glossary.csv
   :header-rows: 1
   :class: sortable filterable