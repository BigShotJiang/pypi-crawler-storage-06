
.. image:: https://badge.fury.io/py/galaxy-config.svg
   :target: https://pypi.org/project/galaxy-config/


Overview
--------

The Galaxy_ config module.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
