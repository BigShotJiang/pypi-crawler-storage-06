"""CLI module - Command line tools"""

from pydhis2.cli.main import app

__all__ = ["app"]
