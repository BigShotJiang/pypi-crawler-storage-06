"""Main entry point for pydhis2 CLI"""

from pydhis2.cli.main import app

if __name__ == "__main__":
    app()
