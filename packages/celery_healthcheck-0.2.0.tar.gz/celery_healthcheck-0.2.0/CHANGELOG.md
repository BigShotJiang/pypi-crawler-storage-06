# [0.2.0](https://github.com/iloveitaly/celery-healthcheck/compare/v0.1.2...v0.2.0) (2025-09-21)


### Features

* healthcheck self worker only ([#14](https://github.com/iloveitaly/celery-healthcheck/issues/14)) ([233196b](https://github.com/iloveitaly/celery-healthcheck/commit/233196b725fed47adb6cf85b11af5e385e6ba9ef))



## [0.1.2](https://github.com/iloveitaly/celery-healthcheck/compare/v0.1.1...v0.1.2) (2025-06-25)


### Bug Fixes

* return JSONResponse with proper status for celery health ([7145d0e](https://github.com/iloveitaly/celery-healthcheck/commit/7145d0eeeee80b3b795d249aedb125916519dbe0))



## [0.1.1](https://github.com/iloveitaly/celery-healthcheck/compare/bab9210809baa244ab53a9d7177f906a2ff4bd30...v0.1.1) (2025-04-01)


### Bug Fixes

* ci should work now ([bab9210](https://github.com/iloveitaly/celery-healthcheck/commit/bab9210809baa244ab53a9d7177f906a2ff4bd30))
* circular import ([24fe4d1](https://github.com/iloveitaly/celery-healthcheck/commit/24fe4d19cc170a3de2f25a2774493a3ccece955e))
* remove cli script ([06d6544](https://github.com/iloveitaly/celery-healthcheck/commit/06d6544eef0c575a6e566b6c6fb2c06ce68a8f20))
* remove cli test ([e188243](https://github.com/iloveitaly/celery-healthcheck/commit/e188243064c7b86455e37dbbe0fc84a6aa975756))



