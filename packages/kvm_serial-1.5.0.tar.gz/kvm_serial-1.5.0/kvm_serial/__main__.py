from . import kvm

if __name__ == "__main__":
    kvm.main()
