"""Tests for FastAPI Radar."""
