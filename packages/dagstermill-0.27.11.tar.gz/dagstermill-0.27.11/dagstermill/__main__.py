from dagstermill.cli import main

main()
