# Werkbank - Model Context Protocol for Atomistic Simulations

Setup
-----
To connect the werkbank server to claude code at the current working directory, ensure `werkbank` is installed in the current working directory and then run:

```bash
bunx @anthropic-ai/claude-code mcp add werkbank -- uv run --project "$(pwd)" werkbank
bunx @anthropic-ai/claude-code
```
