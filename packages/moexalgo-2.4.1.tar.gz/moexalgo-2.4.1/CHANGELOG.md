# 2.4.1
- Добавлена поддержка облигаций
- Добавлена поддержка опционов

# 2.3.1
- Интеграция с сервисом исторических данных - ahdata.ru
- Поддержка вечных фьючерсов

# 2.1.1
Получение торговых данных MOEX по акциям, валюте и фьючерсам:
- акции: Real-time market data, HI2 (market concentration)
- фьючерсы: Real-time market data, HI2 (market concentration), FUTOI, SuperCandles
- Валюта: HI2 (market concentration), SuperCandles

Улучшения в интерфейсе и исправление ошибок:
- Получение исторических данных по истекшим фьючерсным контрактам
- Увекличен лимит получения данных. 50 000 строк за один торговый день
- поддержка авторизации через APIKEY data.moex.com
- получение online данных через websockets


# 1.1.1 
Получение торговых данных по акциям на MOEX:
- Справочник интрументов
- Торговая статистика
- Candles (Свечи)

- AlgoPack.TradeStats
- AlgoPack.OrderStats
- AlgoPack.OBStats# 0.2.0
Получение торговых данных MOEX по акциям, валюте и фьючерсам:
- акции: Real-time market data, HI2 (market concentration)
- фьючерсы: Real-time market data, HI2 (market concentration), FUTOI, SuperCandles
- Валюта: HI2 (market concentration), SuperCandles

Улучшения в интерфейсе и исправление ошибок


# 0.1.0 
Получение торговых данных по акциям на MOEX:
- Справочник интрументов
- Торговая статистика
- Candles (Свечи)

- AlgoPack.TradeStats
- AlgoPack.OrderStats
- AlgoPack.OBStats
