Cвеча
=======================

.. automodule:: moexalgo.models.common
   :members:
   :show-inheritance:
