"""Top-level package for Barril."""

__author__ = """ESSS"""
__email__ = "foss@esss.co"
