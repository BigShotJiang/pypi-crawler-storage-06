"""Version."""

__version__ = "1.0.1"  # pragma: no cover
