# JetHome ESPHome [![GitHub release](https://img.shields.io/github/release/jethome-iot/esphome.svg)](https://GitHub.com/jethome-iot/esphome/releases/)

This is the JetHome fork of [ESPHome](http://esphome.io). It provides custom components for JetHome devices and additional features, including support for dynamically generated entities.

---

[ESPHome Documentation](https://esphome.io) -- [Issues](https://github.com/jethome-iot/esphome/issues) -- [Feature requests](https://github.com/jethome-iot/esphome/issues)

