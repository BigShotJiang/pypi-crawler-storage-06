"""Plugin to supply KiCad with metadata."""
