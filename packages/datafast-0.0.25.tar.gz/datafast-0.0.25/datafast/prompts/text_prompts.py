DEFAULT_TEMPLATES = [
    """I need {num_samples} text examples written in \
{language_name} that could have been written in a {document_type} related to {topic}.
Make sure to properly format your response in valid JSON.
"""
]