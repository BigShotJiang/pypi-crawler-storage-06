Constructive operations
=======================

.. currentmodule:: shapely

.. autosummary::
   :toctree: reference/

{% for function in get_module_functions("constructive") %}
   {{ function }}
{% endfor %}
