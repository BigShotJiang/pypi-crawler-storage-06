STRtree
=======

.. autoclass:: shapely.STRtree
   :members:
