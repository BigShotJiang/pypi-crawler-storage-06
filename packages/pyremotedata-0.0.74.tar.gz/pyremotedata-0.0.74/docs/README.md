# Compile docs
```sh
# Make sure to be in the `docs` directory: `cd docs`
make -f Makefile clean && make -f Makefile html
```