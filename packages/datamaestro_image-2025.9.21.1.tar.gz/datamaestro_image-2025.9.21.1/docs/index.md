# Image-related datasets

This [datamaestro](https://github.com/bpiwowar/datamaestro) plugin covers image-related datasets.


The list of available datasets and usage instruction can be found in the [documentation](http://experimaestro.github.io/datamaestro_image/).
