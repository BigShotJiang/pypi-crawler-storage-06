[![CircleCI](https://circleci.com/gh/experimaestro/datamaestro_image.svg?style=svg)](https://circleci.com/gh/experimaestro/datamaestro) [![PyPI version](https://badge.fury.io/py/datamaestro-image.svg)](https://badge.fury.io/py/datamaestro-image)

# Image-related datasets

This [datamaestro](https://github.com/experimaestro/datamaestro) plugin covers image-related datasets.


The list of available datasets and usage instruction can be found in the [documentation](https://experimaestro.github.io/datamaestro_image/).

# Datasets

- [MNIST](http://yann.lecun.com/exdb/mnist/) `com.lecun.mnist`