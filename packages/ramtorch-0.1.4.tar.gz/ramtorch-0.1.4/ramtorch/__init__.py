from .modules.linear import Linear

__all__ = ["Linear"]
