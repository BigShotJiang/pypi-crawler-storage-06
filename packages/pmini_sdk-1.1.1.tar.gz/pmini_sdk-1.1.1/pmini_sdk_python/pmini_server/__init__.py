"""
PMini Server Package

A gRPC server for controlling PMini drones with background status text streaming.
"""

__version__ = "1.0.0"
__author__ = "PMini Team"
__email__ = "support@pmini.com"
