"""cli for the M library."""
