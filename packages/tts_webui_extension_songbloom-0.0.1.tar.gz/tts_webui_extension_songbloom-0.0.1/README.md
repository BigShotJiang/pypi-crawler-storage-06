# Songbloom

A template extension for [TTS WebUI](https://github.com/rsxdalv/tts-webui).

## Description

This is a template extension. Replace this content with your extension's description.

## Installation

```bash
pip install git+https://github.com/rsxdalv/tts_webui_extension.songbloom@main
```

## Usage

1. Install the extension
2. Restart TTS Generation WebUI
3. Navigate to the Songbloom tab

## Development

To run the extension standalone:

```bash
cd tts_webui_extension/songbloom
python main.py
```

## License

MIT License
