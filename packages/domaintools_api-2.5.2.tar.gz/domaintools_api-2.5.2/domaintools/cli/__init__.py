from domaintools.cli.main import dt_cli


def run():  # pragma: no cover
    """Main entry point of Domaintools CLI Wrapper."""
    dt_cli()
