"""DomainTools Official Python API"""

from domaintools._version import current
from domaintools.api import API

__version__ = current
