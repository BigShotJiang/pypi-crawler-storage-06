# Pattern
This is simple package tp print pattern

## Installation
Install using pip:

pip install Vijay_geometry_toolkit

from pattern import pyramid,right_angle,left_angle

# right angle

pyramid(5)


output

