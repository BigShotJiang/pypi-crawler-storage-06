__project__ = "pyCellPhenoX"
# These version placeholders are updated during build by poetry-dynamic-versioning
__version__ = "1.5.1"
__version_tuple__ = (1, 5, 1)
__license__ = "MIT License"
__author__ = "pyCellPhenoX Contributors"
