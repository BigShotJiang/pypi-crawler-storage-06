# purplepy

Extracts and sends tokens from Office processes on Windows.

## Usage

Install with pip (after publishing):
```
pip install purplepy
```
Run from command line:
```
purplepy
```

## Requirements
- Windows
- Python 3.7+
- Admin privileges (for process dump)

## Author
Your Name
