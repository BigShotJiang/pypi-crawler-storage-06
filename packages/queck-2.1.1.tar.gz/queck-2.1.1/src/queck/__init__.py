from .queck_models import Queck
from .quiz_models import Quiz

__all__ = [Queck, Quiz]
