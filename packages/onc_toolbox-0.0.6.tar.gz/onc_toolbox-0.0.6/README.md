# onc-toolbox

onc-toolbox is a community-supported collection of Python code and notebooks for exploring data from Ocean Networks Canada. 


## Installation

You can install `onc-toolbox` using pip:

```
pip install onc-toolbox
```

## Examples
You can find example notebooks in the [examples](https://github.com/IanTBlack/onc-toolbox/tree/main/examples) directory of onc-toolbox.