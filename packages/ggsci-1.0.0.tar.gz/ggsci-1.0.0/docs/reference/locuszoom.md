# LocusZoom

::: ggsci.palettes
    options:
      members:
        - pal_locuszoom
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_locuszoom
        - scale_colour_locuszoom
        - scale_fill_locuszoom
      show_root_heading: true
      show_source: false
