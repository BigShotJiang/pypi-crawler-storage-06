# Primer

::: ggsci.palettes
    options:
      members:
        - pal_primer
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_primer
        - scale_colour_primer
        - scale_fill_primer
      show_root_heading: true
      show_source: false
