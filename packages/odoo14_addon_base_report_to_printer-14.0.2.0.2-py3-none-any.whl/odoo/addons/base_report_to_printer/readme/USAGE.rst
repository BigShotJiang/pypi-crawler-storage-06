Guidelines for use:

 * To update the CUPS printers in *Settings > Printing > Update Printers
   from CUPS*
 * To print a report on a specific printer or tray, you can change
   these in *Settings > Printing > Reports* to define default behaviour.
 * To print a report on a specific printer and/or tray for a user, you can
   change these in *Settings > Printing > Reports* in
   *Specific actions per user*
 * Users may also select a default action, printer or tray in their preferences.

When no tray is configured for a report and a user, the
default tray setup on the CUPS server is used.
