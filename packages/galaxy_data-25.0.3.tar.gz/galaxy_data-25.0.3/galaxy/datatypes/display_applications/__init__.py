"""
Contains functionality of the newer XML defined external display applications (not hardcoded into datatype classes).
"""
