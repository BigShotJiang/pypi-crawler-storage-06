# Galaxy Database Schema Migrations

Starting with release 22.05, to manage its database migrations, Galaxy uses [Alembic](https://alembic.sqlalchemy.org).

For admin and development options, please see [Galaxy's documentation](https://docs.galaxyproject.org/en/master/admin/db_migration.html).
