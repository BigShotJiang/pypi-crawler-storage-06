"""Merge head revisions

Revision ID: 75348cfb3715
Revises: 9a5207190a4d, cbc46035eba0
Create Date: 2024-11-19 11:48:02.273303

"""

# revision identifiers, used by Alembic.
revision = "75348cfb3715"
down_revision = ("9a5207190a4d", "cbc46035eba0")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
