# coding=utf-8
from .._impl import (
    scout_savedviews_SavedViewService as SavedViewService,
)

__all__ = [
    'SavedViewService',
]

