import phlash.base as base

class Demes(base.Model):
    pass
