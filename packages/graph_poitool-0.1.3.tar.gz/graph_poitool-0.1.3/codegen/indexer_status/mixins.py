from typing import Optional


class LatestBlockMixin:
    @property
    def latest_block(self):
        if len(self.chains) > 0 and self.chains[0].latest_block:
            return self.chains[0].latest_block
        else:
            return None

    @property
    def latest_block_number(self) -> Optional[int]:
        if self.latest_block:
            return self.latest_block.number
        return None

    @property
    def chain_head_block(self):
        if len(self.chains) > 0 and self.chains[0].chain_head_block:
            return self.chains[0].chain_head_block
        else:
            return None

    @property
    def chain_head_block_number(self) -> Optional[int]:
        if self.chain_head_block:
            return self.chain_head_block.number
        return None

    @property
    def lag_blocks(self) -> Optional[int]:
        if self.chain_head_block and self.latest_block:
            return self.chain_head_block.number - self.latest_block.number
        return None

    @property
    def fatal_error_message(self) -> Optional[str]:
        if self.fatal_error:
            return self.fatal_error.message
        return None

    @property
    def fatal_error_deterministic(self) -> Optional[bool]:
        if self.fatal_error:
            return self.fatal_error.deterministic
        return None
