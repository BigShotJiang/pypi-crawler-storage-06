# ruff: noqa
from graph_poitool.clients.gql import BaseClient

# class BaseClient
