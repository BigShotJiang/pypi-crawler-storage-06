"""Abstract classes and functions for username management backends."""
