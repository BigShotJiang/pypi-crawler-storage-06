# PyEcoTrend-ista

[![PyPI version](https://badge.fury.io/py/pyecotrend-ista.svg)](https://badge.fury.io/py/pyecotrend-ista) [![Downloads](https://pepy.tech/badge/pyecotrend-ista)](https://pepy.tech/project/pyecotrend-ista) [![Downloads](https://pepy.tech/badge/pyecotrend-ista/month)](https://pepy.tech/project/pyecotrend-ista) [![Downloads](https://pepy.tech/badge/pyecotrend-ista/week)](https://pepy.tech/project/pyecotrend-ista)

[![GitHub issues](https://img.shields.io/github/issues/Ludy87/pyecotrend-ista?style=for-the-badge&logo=github)](https://github.com/Ludy87/pyecotrend-ista/issues)
[![GitHub forks](https://img.shields.io/github/forks/Ludy87/pyecotrend-ista?style=for-the-badge&logo=github)](https://github.com/Ludy87/pyecotrend-ista)
[![GitHub stars](https://img.shields.io/github/stars/Ludy87/pyecotrend-ista?style=for-the-badge&logo=github)](https://github.com/Ludy87/pyecotrend-ista)
[![GitHub license](https://img.shields.io/github/license/Ludy87/pyecotrend-ista?style=for-the-badge&logo=github)](https://github.com/Ludy87/pyecotrend-ista/blob/main/LICENSE)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg?style=for-the-badge&logo=code%20style-black)](https://github.com/psf/black)
![GitHub Release Date](https://img.shields.io/github/release-date/Ludy87/pyecotrend-ista?style=for-the-badge&logo=github)
[![codecov](https://codecov.io/github/Ludy87/pyecotrend-ista/branch/main/graph/badge.svg?token=BHU8J3OVRT)](https://codecov.io/github/Ludy87/pyecotrend-ista)

[!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/ludy87)

[✨ Wishlist from Amazon ✨](https://smile.amazon.de/registry/wishlist/2MX8QK8VE9MV1)

---
Unofficial python library for the pyecotrend-ista API

![EcoTrend-ista](https://github.com/Ludy87/pyecotrend-ista/blob/main/image/logo.png?raw=true)

::: pyecotrend_ista
    :docstring:
    :members:
