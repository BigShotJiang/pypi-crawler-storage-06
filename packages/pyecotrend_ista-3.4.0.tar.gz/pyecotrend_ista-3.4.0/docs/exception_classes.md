# Exceptions

::: pyecotrend_ista.exception_classes
    :docstring:
    :members:
