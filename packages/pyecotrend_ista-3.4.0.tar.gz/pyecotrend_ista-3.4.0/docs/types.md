# Types

::: pyecotrend_ista.types
    :docstring:
    :members:
