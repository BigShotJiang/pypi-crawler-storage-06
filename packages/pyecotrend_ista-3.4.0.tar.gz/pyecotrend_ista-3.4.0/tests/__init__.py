"""Tests for PyEcotrendIsta."""
