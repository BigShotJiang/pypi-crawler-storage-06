# Copyright 2025 © BeeAI a Series of LF Projects, LLC
# SPDX-License-Identifier: Apache-2.0

from importlib.metadata import version

__version__ = version("beeai-sdk")
