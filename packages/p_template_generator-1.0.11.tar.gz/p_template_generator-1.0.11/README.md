Template Python Tool

pip install p-template-generator -U -i https://pypi.python.org/simple