This is the list of copyright holders of precommit-recommendations.

For information on the license, see LICENSE.md.

* Dominic Kempf, 2023
