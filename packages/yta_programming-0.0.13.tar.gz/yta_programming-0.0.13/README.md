# Youtube Autonomous Programming add-on

The way to work internally with some of the functionalities we need. This code will interact directly with the code, so it should be used carefully by the developers.