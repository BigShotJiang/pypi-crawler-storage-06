from .process import start_process

# for backward compatibility (use start_process instead)
ProcessSpawner = start_process
