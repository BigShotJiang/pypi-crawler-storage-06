from .shueisha import MangaPlus

__version__ = '1.23.2'
__all__ = (__version__, 'MangaPlus')
