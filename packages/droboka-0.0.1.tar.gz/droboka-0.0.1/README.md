# Roboka

Roboka is a Python wrapper for the **Rubika Bot API**.

With this library you can easily create and manage your Rubika bots in Python.

can you read documents in site: https://rb-chat.ir 

or this github page: https://github.com/aliz17-web/roboka

# Installation
```bash
pip install roboka