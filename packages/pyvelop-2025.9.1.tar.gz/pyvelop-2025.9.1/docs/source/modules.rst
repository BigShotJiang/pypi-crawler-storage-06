Library Reference
=================

Mesh Object
-----------
.. automodule:: pyvelop.mesh
    :members:

Mesh Entity Objects
-------------------
.. automodule:: pyvelop.mesh_entity
    :members:
    :inherited-members:
    :show-inheritance:

Exceptions
----------
.. automodule:: pyvelop.exceptions
    :members:
    :show-inheritance:
