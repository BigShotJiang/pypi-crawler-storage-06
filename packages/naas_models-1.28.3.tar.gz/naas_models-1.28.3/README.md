# naas-models

Library containing all models used in the naas ecosystem. You can use this library to know how to talk to our micro services.