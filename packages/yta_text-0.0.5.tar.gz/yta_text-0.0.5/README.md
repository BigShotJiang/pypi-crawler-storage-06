# Youtube Autonomous Text handling add-on

The way to work with texts and strings to sanitize and parse.