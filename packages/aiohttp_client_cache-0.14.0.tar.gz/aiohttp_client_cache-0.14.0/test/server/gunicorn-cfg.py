bind = '0.0.0.0:8181'
workers = 1
accesslog = '-'
loglevel = 'info'
capture_output = True
enable_stdio_inheritance = True
