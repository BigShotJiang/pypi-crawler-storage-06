"""
PyFuncLink - Library to detect and handle links in GUI widgets
"""
from .core import linkify
