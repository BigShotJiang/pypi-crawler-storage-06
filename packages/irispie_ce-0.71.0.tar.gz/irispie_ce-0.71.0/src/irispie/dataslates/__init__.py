"""
Internal data representation
"""

from .main import Dataslate, Slatable

__all__ = (
    "Dataslate",
)

