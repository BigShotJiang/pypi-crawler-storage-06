Rights/Licenses of the test data in this directory
**************************************************

See the file "testdata/xml-data/test-data-systematic.xml" for detailed legal information.