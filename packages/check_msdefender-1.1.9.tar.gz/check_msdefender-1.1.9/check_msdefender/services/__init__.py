"""Services module for check_msdefender."""
