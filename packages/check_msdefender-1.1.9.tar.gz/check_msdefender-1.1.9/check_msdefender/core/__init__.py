"""Core functionality for check_msdefender."""
