AFLW2000-3D is a dataset of 2000 images that have been annotated with
image-level 68-point 3D facial landmarks. This dataset is typically used for
evaluation of 3D facial landmark detection models. The head poses are very
diverse and often hard to be detected by a cnn-based face detector. The 2D
landmarks are skipped in this dataset, since some of the data are not consistent
to 21 points, as the original paper mentioned.
