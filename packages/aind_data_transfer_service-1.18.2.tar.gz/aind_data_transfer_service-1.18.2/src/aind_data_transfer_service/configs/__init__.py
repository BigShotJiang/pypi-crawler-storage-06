"""Package to app configurations"""
