agent_mode=False
prompt_engineering=False
max_steps=30
hide_tools_order=True
default_bible="NET"
max_semantic_matches=15