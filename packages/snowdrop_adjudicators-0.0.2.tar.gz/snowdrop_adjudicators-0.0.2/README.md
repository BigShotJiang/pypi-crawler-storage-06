# snowdrop-adjudicators
Adjudicators for the Tangled game
