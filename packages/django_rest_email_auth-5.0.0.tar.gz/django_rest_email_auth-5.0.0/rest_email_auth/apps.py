from django.apps import AppConfig


class RestEmailAuthConfig(AppConfig):
    name = "rest_email_auth"
    default_auto_field = "django.db.models.AutoField"
