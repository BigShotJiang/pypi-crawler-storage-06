# MultiAgent Core

Foundation framework with intelligent directory management for multi-agent development.

## Installation

```bash
pip install multiagent-core
```

**Note:** On Ubuntu 24+ systems, you may need: `pip install multiagent-core --break-system-packages`

## Quick Start

**Installed after spec-kit creates your application with any AI assistant:**

```bash
# Basic spec-kit initialization
specify init my-project

# With specific AI assistant (recommended)
specify init my-project --ai claude
specify init my-project --ai cursor  
specify init my-project --ai windsurf
specify init my-project --ai copilot --script ps  # PowerShell support
specify init my-project --ai gemini --no-git     # Skip git init

# Advanced options
specify init --here --ai copilot                 # Initialize in current directory
specify init my-project --ai claude --debug      # Debug output
specify init my-project --ai claude --github-token ghp_token  # Corporate environments

# Then add multi-agent capabilities
cd my-project  # (or stay in current dir if using --here)
pip install multiagent-core
multiagent init

# Check installation status  
multiagent status

# Get comprehensive health check
multiagent doctor
```

## Example: Complete Setup

```bash
$ specify init my-project --ai copilot
$ cd my-project
$ pip install multiagent-core
$ multiagent init

# Interactive prompts:
# Existing git repository detected. Use existing repository? [Y/n]: y
# Create GitHub repository? [y/N]: y  
# Install git hooks for multi-agent workflow? [Y/n]: y
# ... framework enhances existing structure ...
```

## Post-Application Setup

When you run `multiagent init` in an **existing project**, you'll be prompted for:

1. **Git Repository**: "Existing git repository detected. Use existing repository?" (usually Yes)
2. **GitHub Integration**: "Create GitHub repository?" (if not already connected)  
3. **Git Hooks**: "Install git hooks for multi-agent workflow?" (recommended Yes)

The setup intelligently:
- ✅ **Detects existing structure** from spec-kit and preserves it
- ✅ **Injects agent templates** into existing `.claude/` directory
- ✅ **Adds workflows** to existing `.github/workflows/` 
- ✅ **Handles Docker** for consistent multi-agent environments
- ✅ **Merges configurations** without overwriting existing files

## Features

- **Post-Spec-Kit Integration**: Designed to enhance existing applications, not replace them
- **Intelligent Merging**: Preserves spec-kit structure while adding multi-agent capabilities
- **Template Injection**: Detects existing `.claude/` and `.github/` directories and enhances them
- **Foundation Pattern**: Single source of truth for Docker utilities across all components
- **Interactive Setup**: Simple yes/no prompts, no complex flags
- **Cross-Platform**: Automatic Docker detection and WSL/Windows path handling

## Architecture

**After spec-kit + multiagent-core installation:**

```
your-application/          # Created by spec-kit
├── src/                   # Your application code (spec-kit)
├── tests/                 # Your tests (spec-kit)
├── docs/                  # Your documentation (spec-kit)
├── .specify/              # Spec-kit configuration (preserved)
├── .multiagent/           # Multi-agent framework (added)
│   ├── core/              # Docker utilities, framework files
│   ├── config/            # Agent coordination configuration
│   ├── templates/         # Project templates
│   └── docs/              # Framework documentation
├── .github/workflows/     # Enhanced by multiagent-core
│   ├── ci.yml            # Your CI workflow (spec-kit, preserved)
│   ├── deploy.yml        # Your deployment (spec-kit, preserved)
│   └── copilot-integration.yml  # Added by multiagent-core
└── .claude/               # Enhanced by multiagent-core
    ├── project-context.md # Your project context (spec-kit, preserved)
    ├── claude-agents.md   # Agent templates (added)
    └── agent-coordination.md  # Multi-agent workflow (added)
```

## Integration with Spec-Kit AI Assistants

**Works seamlessly with any spec-kit AI choice:**

| Spec-Kit Init | Multiagent-Core Enhancement |
|---------------|----------------------------|
| `specify init --ai claude` | Adds Claude Code subagents, enhances existing setup |
| `specify init --ai copilot` | Adds Claude + Copilot orchestration workflows |
| `specify init --ai cursor` | Adds multi-agent capabilities to Cursor projects |
| `specify init --ai windsurf` | Enhances Windsurf projects with agent coordination |
| `specify init --ai gemini` | Adds Claude + Gemini large context workflows |

## Workflow

1. **Spec-kit** creates your application foundation with chosen AI assistant
2. **Multiagent-core** detects existing setup and adds orchestration capabilities  
3. **Other components** (devops, agentswarm, testing) extend functionality
4. **Everything works together** - original AI assistant + multi-agent coordination
