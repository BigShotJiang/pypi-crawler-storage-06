from __future__ import annotations

# No desktop modules are exposed by the localisation package.
def get_data():
    return []
