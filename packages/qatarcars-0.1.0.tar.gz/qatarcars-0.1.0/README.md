# qatarcars

A package containing data on Qatari cars for pedagogical purposes

## Installation

```bash
$ pip install qatarcars
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`qatarcars` was created by Peter Licari. It is licensed under the terms of the CC0 v1.0 Universal license.

## Credits

`qatarcars` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
