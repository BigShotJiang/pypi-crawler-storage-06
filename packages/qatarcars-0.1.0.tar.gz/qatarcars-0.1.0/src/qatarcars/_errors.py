from colorama import Fore, Style

df_assert_error = (Fore.RED + f"'dataframe_type' must be either 'polars' (or 'pl') or 'pandas' (or 'pd')" + Style.RESET_ALL)