Examples
********

.. toctree::
   :maxdepth: 1

   ./creating_and_working_with_grid_objects.ipynb
   ./subsetting_grid_objects_with_shape_files.ipynb

All shown examples are also available as ipython notebooks in ``pygeogrids/docs/examples``.
