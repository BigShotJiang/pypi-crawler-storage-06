# gobin/cli.py
from gobin.main import main


def run_cli():
    main()
