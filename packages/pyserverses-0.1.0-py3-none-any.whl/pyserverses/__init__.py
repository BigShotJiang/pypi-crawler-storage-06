# pyservers/__init__.py
from .server import PyServer
from .client import PyClient

__version__ = "0.1.0"
__author__ = "kote"