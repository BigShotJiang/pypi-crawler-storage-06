@llm
prompt: |
    generate examples of markdown tables, dont print them in code blocks, print them directly in your answer

@llm
prompt: |
    now generate examples of other markdown components, including mermaid diagramm, showcase all mermaid diagram types (using proper code block syntax), aad few  image examples layouting and features use http://127.0.0.1:8000/serve_image/?path=output/tutorial.png