from mcp_server_selenium import main

main()
