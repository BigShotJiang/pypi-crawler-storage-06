# streamlit-ollama

Utilities to easily integrate Ollama models within Streamlit apps.

## Installation

