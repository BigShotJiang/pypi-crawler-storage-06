class ProviderException(Exception):
    """Exception raised by repository providers (GitHub, GitLab, etc.)"""

    pass
