"""Test package for the Sequential Thinking MCP server."""
