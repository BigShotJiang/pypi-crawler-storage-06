# References

- **Introduction to Structural Thinking**: [https://youtu.be/pltG4aXy_cc?si=S5ygLuxIAHV6QDYK](https://youtu.be/pltG4aXy_cc?si=S5ygLuxIAHV6QDYK)
