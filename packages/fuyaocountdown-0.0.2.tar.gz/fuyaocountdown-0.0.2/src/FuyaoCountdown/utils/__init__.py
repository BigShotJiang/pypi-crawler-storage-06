"""
encoding:   -*- coding: utf-8 -*-
@Time           :  2025/9/16 0:25
@Project_Name   :  FuyaoCountdown
@Author         :  lhw
@File_Name      :  __init__.py.py

功能描述

实现步骤

"""
