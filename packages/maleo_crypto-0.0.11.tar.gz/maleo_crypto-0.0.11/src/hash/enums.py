from enum import StrEnum


class Mode(StrEnum):
    DIGEST = "digest"
    OBJECT = "object"
