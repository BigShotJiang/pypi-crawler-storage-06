class DataFrameHeaders:
    CONDITION_COLUMN_HEADER_PREFIX = "condition_"

    PROPERTY_COLUMN_HEADER_PREFIX = "properties."

    KEYWORDS_COLUMN_HEADER = "keywords"
