# Authentication
- You'll need to get your Firm ID from [BigTime](https://iq.bigtime.net) and create an api key there as well
- As of today (2025-09-03):
    - Your Firm ID is located under `My Company > My Company > Company Info` at the bottom of the popup window
    - The API Key(s) is (are) located under `My Company > Integrations > API Keys`
        - If you do not have an API Key, select `Add API Key` in the top right of the *apikeys* page