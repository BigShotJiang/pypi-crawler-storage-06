# System
- [ ] **GET** `/Status`