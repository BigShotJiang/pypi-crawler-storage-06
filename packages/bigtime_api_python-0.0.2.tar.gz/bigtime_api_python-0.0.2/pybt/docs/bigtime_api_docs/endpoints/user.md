# User
- [ ] **GET** `/Index`