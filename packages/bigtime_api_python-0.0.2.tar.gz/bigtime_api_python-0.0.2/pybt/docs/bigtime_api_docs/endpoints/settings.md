# Settings
- [ ] **GET** `/Vocabulary`
- [ ] **GET** `/Timesheet`
- [ ] **GET** `/Expense`
- [ ] **GET** `/DCAA`