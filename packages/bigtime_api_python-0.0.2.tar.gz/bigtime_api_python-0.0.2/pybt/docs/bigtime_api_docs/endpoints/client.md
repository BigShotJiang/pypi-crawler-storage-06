# Client
- [X] **GET** `/Index`
- [X] **GET** `/Detail`
- [ ] **POST** `/Detail`
- [X] **DEL** `/Detail`