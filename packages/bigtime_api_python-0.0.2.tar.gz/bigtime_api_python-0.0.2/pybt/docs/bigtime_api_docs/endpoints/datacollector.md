# DataCollector
- [ ] **POST** `/ScheduleDataCollection`