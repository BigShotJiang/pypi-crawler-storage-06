# Ping
- [ ] **GET** `/TxnStatus`
- [ ] **GET** `/SessionCount`
- [ ] **GET** `/Timesheets`