# Help
- [ ] **GET** `/Index`
- [ ] **GET** `/Ping`
- [ ] **GET** `/Naked`
- [ ] **POST** `/Login`
- [ ] **POST** `/Logout`
- [ ] **POST** `/FilePost`