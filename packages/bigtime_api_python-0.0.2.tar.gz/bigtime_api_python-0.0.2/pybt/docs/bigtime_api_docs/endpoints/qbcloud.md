# QBCloud
- [ ] **POST** `/Authorize`
- [ ] **POST** `/HookSync`
- [ ] **POST** `/HookWebUpdate`