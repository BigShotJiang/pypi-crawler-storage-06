# Zapier
- [ ] **POST** `/Subscribe`
- [ ] **DEL** `/Unsubscribe`