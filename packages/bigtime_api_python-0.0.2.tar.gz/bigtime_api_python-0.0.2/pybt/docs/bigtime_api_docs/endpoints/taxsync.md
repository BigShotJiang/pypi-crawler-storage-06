# TaxSync
- [ ] **POST** `/Status`