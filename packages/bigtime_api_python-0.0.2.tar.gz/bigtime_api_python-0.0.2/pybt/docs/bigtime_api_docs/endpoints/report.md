# Report
- [ ] **GET** `/Detail`
- [X] **GET** `/Data`
- [X] **POST** `/Data`