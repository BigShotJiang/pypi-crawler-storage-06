class Payment:
    def __init__(self, method):
        self._endpoint = "Payment"
        self._method = method
