# bigtime-api-python

A BigTime API wrapper for Python

## Docs

[See documentation here](bigtime-api-python/docs/)

## Contributing

If you find any bugs and/or errors, please [submit an issue](https://github.com/N3RM/bigtime-api-python/issues) or fork the repository
and submit a pull request with your updates.

## Examples

Coming soon
