from .jsoncompat import *

__doc__ = jsoncompat.__doc__
if hasattr(jsoncompat, "__all__"):
    __all__ = jsoncompat.__all__