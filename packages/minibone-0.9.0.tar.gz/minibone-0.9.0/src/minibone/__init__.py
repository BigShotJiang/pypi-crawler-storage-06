"""Minibone - Small boilerplate with tools for concurrent/parallel."""

__version__ = "0.9.0"
