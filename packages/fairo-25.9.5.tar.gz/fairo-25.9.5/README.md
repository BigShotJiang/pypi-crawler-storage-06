# Fairo SDK 

Fairo SDK for interfacing with Fairo SaaS platform. 

Please read our [documentation](https://fairo.readme.io/docs/) to get started.

For more information about Fairo, or to start a free trial, please visit our [website](http://www.fairo.ai).
