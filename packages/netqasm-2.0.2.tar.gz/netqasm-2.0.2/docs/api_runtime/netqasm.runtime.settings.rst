netqasm\.runtime\.settings
---------------------------

.. automodule:: netqasm.runtime.settings
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
