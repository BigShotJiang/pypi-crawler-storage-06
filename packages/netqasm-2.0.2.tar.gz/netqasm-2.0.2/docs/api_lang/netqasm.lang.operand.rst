netqasm\.lang\.operand
---------------------------

.. automodule:: netqasm.lang.operand
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
