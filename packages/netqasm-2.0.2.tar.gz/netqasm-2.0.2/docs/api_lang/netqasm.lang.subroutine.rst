netqasm\.lang\.subroutine
---------------------------

.. automodule:: netqasm.lang.subroutine
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
