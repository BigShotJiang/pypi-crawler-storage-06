Known issues
================

When using the SquidASM simulator, when the simulation of an application
finishes, you may see a warning coming from NetSquid saying ``WARNING: a [sic]
expression handler missing``. This seems to be a bug relating to NetSquid and is
outside the control of ``netqasm`` but should not impact the simulation of the
application.
