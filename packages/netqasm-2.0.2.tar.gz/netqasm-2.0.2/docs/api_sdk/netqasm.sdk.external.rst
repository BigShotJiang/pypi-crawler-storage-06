netqasm\.sdk\.external
---------------------------

.. automodule:: netqasm.sdk.external
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
