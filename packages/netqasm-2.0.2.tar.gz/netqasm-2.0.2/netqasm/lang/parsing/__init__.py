from .binary import deserialize
from .text import (
    get_current_registers,
    parse_address,
    parse_register,
    parse_text_subroutine,
)
