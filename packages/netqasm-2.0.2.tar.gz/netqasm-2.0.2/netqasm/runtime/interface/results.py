from typing import Any, Dict

# App results.
# Each key is one of the role names or `backend`.
# Values can be anything.
Results = Dict[str, Any]
