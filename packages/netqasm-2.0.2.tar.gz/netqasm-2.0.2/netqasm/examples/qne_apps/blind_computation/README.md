# Blind computation
