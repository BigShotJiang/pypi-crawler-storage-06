You can run the execute the netqasm code in the files in netqasm_files by running for example
```sh
netqasm execute netqasm_files/simple_measure.nqasm
```
