# This file is only needed for pip < 21.1

import setuptools

setuptools.setup()
