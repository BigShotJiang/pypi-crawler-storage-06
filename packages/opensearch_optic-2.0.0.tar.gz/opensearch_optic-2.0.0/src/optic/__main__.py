from optic.cli import cli

if __name__ == "__main__":
    # Entry point for optic
    cli()
