"""This module specifies the current Patroni version.

:var __version__: the current Patroni version.
"""
__version__ = '4.0.7'
