"""Subpackage for CLI command groups."""
