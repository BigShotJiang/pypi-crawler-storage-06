# Mintzy SDK

A Python SDK to access Mintzy's stock prediction API.

## Installation
```bash
pip install mintzy
