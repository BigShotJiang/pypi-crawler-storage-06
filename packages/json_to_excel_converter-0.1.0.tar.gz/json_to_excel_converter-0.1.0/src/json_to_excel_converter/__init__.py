from __future__ import annotations

__all__ = ["main"]

from .cli import main  # re-export for entry point
