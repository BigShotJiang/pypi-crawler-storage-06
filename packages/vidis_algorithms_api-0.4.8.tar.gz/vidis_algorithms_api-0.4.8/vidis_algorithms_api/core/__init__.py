from .Settings import Settings

settings = Settings()
