Examples
========


Basic example
-------------

.. literalinclude:: ../../samples/example.py
   :language: python
   :caption: example.py



Load config from a file
-----------------------

.. literalinclude:: ../../samples/config-file.py
   :language: python
   :caption: config-file.py
