import numpy as np
import json
import os
from fractions import Fraction


def _get_erk1():
    """Returns the Butcher tableau data for the 1st order Euler explicit scheme."""
    return {
        "A": [[0]],
        "B": [1],
        "C": [0],
        "order": 1,
        "a_stable": False
    }

def _get_erk2_midpoint():
    """Returns the Butcher tableau data for the 2nd explicit mid-point scheme."""
    return {
        "A": [[0.0, 0.0],
              [0.5, 0.0]],
        "B": [0.0, 1.0],
        "C": [0.0, 0.5],
        "order": 2,
        "a_stable": False
    }

def _get_erk4():
    """Returns the data for the classical RK4 scheme."""
    return {
        "A": [
            [0.0, 0.0, 0.0, 0.0],
            [0.5, 0.0, 0.0, 0.0],
            [0.0, 0.5, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0]
        ],
        "B": [1/6, 1/3, 1/3, 1/6],
        "C": [0.0, 0.5, 0.5, 1.0],
        "order": 4,
        "a_stable": False
    }


def _get_sdirk1():
    """Returns the Butcher tableau data for the 1st order Euler implicit scheme."""
    return {
        "A": [[1]],
        "B": [1],
        "C": [1],
        "order": 1,
        "a_stable": True
    }

def _get_sdirk2_midpoint():
    """Returns the butcher tableau data for the 2nd order 1 stage implicit mid-point scheme."""
    return {
        "A": [[0.5]],
        "B": [1.0],
        "C": [0.5],
        "order": 2,
        "a_stable": True
    }

def _get_sdirk43_crouzeix():
    """Returns the butcher tableau data for the 4th order 3 stages Crouzeix scheme."""
    gamma = 1/np.sqrt(3) *np.cos(np.pi / 18) + 1.0/2.0  # =  1.0685790213016289
    delta = 6*(2*gamma - 1)**2
    return {
        "A": [
            [gamma, 0.0, 0.0],
            [0.5-gamma, gamma, 0.0],
            [2*gamma, 1-4*gamma, gamma]
        ],
        "B": [1/delta, 1-2/delta, 1/delta],
        "C": [gamma, 0.5, 1-gamma],
        "order": 4,
        "a_stable": True
    }

def _get_cooper_verner():
    """Calculates the Cooper-Verner coefficients and returns them."""
    # Define coefficients
    sqrt21 = np.sqrt(21)
    
    a21 = 1/2
    a31 = 1/4; a32 = 1/4
    a41 = 1./7; a42 = (-7+3*sqrt21)/98; a43 = (21-5*sqrt21)/49
    a51 = (11-sqrt21)/84; a52=0; a53 = (18-4*sqrt21)/63; a54 = (21+sqrt21)/252
    a61 = (5-sqrt21)/48;  a62=0; a63 = (9-sqrt21)/36; a64 = (-231-14*sqrt21)/360; a65 = (63+7*sqrt21)/80
    a71 = (10+sqrt21)/42; a72=0; a73 = (-432-92*sqrt21)/315; a74=(633+145*sqrt21)/90; a75=(-504-115*sqrt21)/70; a76 = (63+13*sqrt21)/35
    a81 = 1./14; a82=0; a83=0; a84=0; a85 = (14+3*sqrt21)/126; a86=(13+3*sqrt21)/63; a87 = 1./9
    a91 = 1./32; a92=0; a93=0; a94=0; a95 = (91+21*sqrt21)/576; a96=11./72; a97=(-385+75*sqrt21)/1152; a98 = (63-13*sqrt21)/128
    a101= 1./14; a102=0;a103=0;a104=0;a105=1./9; a106=(-733+147*sqrt21)/2205; a107 = (515-111*sqrt21)/504; a108 = (-51+11*sqrt21)/56; a109 = (132-28*sqrt21)/245
    a111= 0; a112=0; a113=0; a114=0; a115=(-42-7*sqrt21)/18; a116 = (-18-28*sqrt21)/45; a117=(-273+53*sqrt21)/72; a118=(301-53*sqrt21)/72; a119=(28+28*sqrt21)/45; a1110=(49+7*sqrt21)/18
    b1 = 1/20; b2=0; b3=0; b4=0; b5=0; b6=0; b7=0; b8=49/180; b9=16/45; b10=49/180; b11=1/20
    c1=0; c2 = 1./2; c3=1./2; c4 = (7-sqrt21)/14; c5 = (7-sqrt21)/14; c6=1/2; c7=(7+sqrt21)/14; c8=(7+sqrt21)/14; c9=1./2; c10=(7-sqrt21)/14; c11=1
    A = [
        [   0,      0,    0,    0,    0,    0,    0,    0,    0,     0,   0 ],
        [ a21,      0,    0,    0,    0,    0,    0,    0,    0,     0,   0 ],
        [ a31,    a32,    0,    0,    0,    0,    0,    0,    0,     0,   0 ],
        [ a41,    a42,  a43,    0,    0,    0,    0,    0,    0,     0,   0 ],
        [ a51,    a52,  a53,  a54,    0,    0,    0,    0,    0,     0,   0 ],
        [ a61,    a62,  a63,  a64,  a65,    0,    0,    0,    0,     0,   0 ],
        [ a71,    a72,  a73,  a74,  a75,  a76,    0,    0,    0,     0,   0 ],
        [ a81,    a82,  a83,  a84,  a85,  a86,  a87,    0,    0,     0,   0 ],
        [ a91,    a92,  a93,  a94,  a95,  a96,  a97,  a98,    0,     0,   0 ],
        [ a101,  a102, a103, a104, a105, a106, a107, a108, a109,     0,   0 ],
        [ a111,  a112, a113, a114, a115, a116, a117, a118, a119, a1110,   0 ]
    ]
    B = [b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11]
    C = [c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11]

    return {
        "A": A,
        "B": B,
        "C": C,
        "order": 8,
        "a_stable": False
    }

def _get_euler_heun():
    """
    Embedded ERK: Euler-Heun method (Order 1/2, 2 stages)
    """
    A = [
            [0.0, 0.0],
            [1.0, 0.0]
        ]
    b = [0.5, 0.5]       # higher order solution (order 2)
    bh = [1.0, 0.0]      # lower order embedded solution (order 1)
    B = [b, bh]
    C = [0.0, 1.0]
    return {"A": A, "B": B, "C": C, "order": 2, "embedded_order": 1, "a_stable": False}

def _get_bogacki_shampine():
    """
    Embedded ERK: Bogacki–Shampine method (Order 3/4, 4 stages)
    """
    A = [
            [0.0, 0.0, 0.0, 0.0],
            [0.5, 0.0, 0.0, 0.0],
            [0.0, 3/4, 0.0, 0.0],
            [2/9, 1/3, 4/9, 0.0]  # Last row not used in A for this tableau
        ]
    b = [7/24, 1/4, 1/3, 1/8]     # order 4 solution
    bh = [2/9, 1/3, 4/9, 0.0]   # order 3 embedded solution
    B = [b, bh]
    C = [0.0, 0.5, 3/4, 1.0]
    return {"A": A, "B": B, "C": C, "order": 4, "embedded_order": 3, "a_stable": False}


def _get_fehlberg45():
    """
    Embedded ERK: Fehlberg 4(5) method (Order 4/5, 6 stages)
    """
    A = [
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [1/4, 0.0, 0.0, 0.0, 0.0, 0.0],
            [3/32,9/32, 0.0, 0.0, 0.0, 0.0],
            [1932/2197, -7200/2197, 7296/2197, 0.0, 0.0, 0.0],
            [439/216, -8, 3680/513, -845/4104, 0.0, 0.0],
            [-8/27, 2, -3544/2565, 1859/4104, -11/40, 0.0]
        ]
    b = [25/216, 0.0, 1408/2565, 2197/4104, -2/10, 0.0]       # order 4
    bh = [16/135, 0.0, 6656/12825, 28561/56430, -9/50, 2/55]  # order 5 embedded
    B = [b, bh]
    C = [0.0, 1/4, 3/8, 12/13, 1.0, 1/2]
    return {"A": A, "B": B, "C": C, "order": 5, "embedded_order": 4, "a_stable": False}

def _get_dopri5():
    """
    Embedded explicit Runge-Kutta: Dormand-Prince (Order 4/5, 7 stages)
    """
    A = [
        [0.0,         0.0,        0.0,        0.0,        0.0,         0.0,   0.0],
        [1/5,         0.0,        0.0,        0.0,        0.0,         0.0,   0.0],
        [3/40,        9/40,       0.0,        0.0,        0.0,         0.0,   0.0],
        [44/45,      -56/15,      32/9,       0.0,        0.0,         0.0,   0.0],
        [19372/6561, -25360/2187, 64448/6561, -212/729,   0.0,         0.0,   0.0],
        [9017/3168,  -355/33,     46732/5247, 49/176,     -5103/18656, 0.0,   0.0],
        [35/384,      0.0,        500/1113,   125/192,    -2187/6784,  11/84, 0.0],
    ]
    
    b = [35/384, 0.0, 500/1113, 125/192, -2187/6784, 11/84, 0.0]
    bh = [5179/57600, 0.0, 7571/16695, 393/640, -92097/339200, 187/2100, 1/40]
    B = [b, bh]

    C = [0.0, 1/5, 3/10, 4/5, 8/9, 1.0, 1.0]

    return {"A": A, "B": B, "C": C, "order": 5, "embedded_order": 4, "a_stable": False}

def _get_dorpri85():
    C = [0.0, 0.526001519587677318785587544488e-01, 0.789002279381515978178381316732e-01, 0.118350341907227396726757197510, 0.281649658092772603273242802490, 0.333333333333333333333333333333, 0.25, 0.307692307692307692307692307692, 0.651282051282051282051282051282, 0.6, 0.857142857142857142857142857142, 1.0, 1.0, 0.1, 0.2, 0.777777777777777777777777777778]
    N_STAGES = 12
    N_STAGE_EXTENDED = 16
    A = [[0.0]*N_STAGE_EXTENDED for _ in range(N_STAGE_EXTENDED)]
    A[1][0] = 5.26001519587677318785587544488e-2
    A[2][0] = 1.97250569845378994544595329183e-2; A[2][1] = 5.91751709536136983633785987549e-2
    A[3][0] = 2.95875854768068491816892993775e-2; A[3][2] = 8.87627564304205475450678981324e-2
    A[4][0] = 2.41365134159266685502369798665e-1; A[4][2] = -8.84549479328286085344864962717e-1; A[4][3] = 9.24834003261792003115737966543e-1
    A[5][0] = 3.7037037037037037037037037037e-2; A[5][3] = 1.70828608729473871279604482173e-1; A[5][4] = 1.25467687566822425016691814123e-1
    A[6][0] = 3.7109375e-2; A[6][3] = 1.70252211019544039314978060272e-1; A[6][4] = 6.02165389804559606850219397283e-2; A[6][5] = -1.7578125e-2
    A[7][0] = 3.70920001185047927108779319836e-2; A[7][3] = 1.70383925712239993810214054705e-1; A[7][4] = 1.07262030446373284651809199168e-1; A[7][5] = -1.53194377486244017527936158236e-2; A[7][6] = 8.27378916381402288758473766002e-3
    A[8][0] = 6.24110958716075717114429577812e-1; A[8][3] = -3.36089262944694129406857109825; A[8][4] = -8.68219346841726006818189891453e-1; A[8][5] = 2.75920996994467083049415600797e1; A[8][6] = 2.01540675504778934086186788979e1; A[8][7] = -4.34898841810699588477366255144e1
    A[9][0] = 4.77662536438264365890433908527e-1; A[9][3] = -2.48811461997166764192642586468; A[9][4] = -5.90290826836842996371446475743e-1; A[9][5] = 2.12300514481811942347288949897e1; A[9][6] = 1.52792336328824235832596922938e1; A[9][7] = -3.32882109689848629194453265587e1; A[9][8] = -2.03312017085086261358222928593e-2
    A[10][0] = -9.3714243008598732571704021658e-1; A[10][3] = 5.18637242884406370830023853209; A[10][4] = 1.09143734899672957818500254654; A[10][5] = -8.14978701074692612513997267357; A[10][6] = -1.85200656599969598641566180701e1; A[10][7] = 2.27394870993505042818970056734e1; A[10][8] = 2.49360555267965238987089396762; A[10][9] = -3.0467644718982195003823669022
    A[11][0] = 2.27331014751653820792359768449; A[11][3] = -1.05344954667372501984066689879e1; A[11][4] = -2.00087205822486249909675718444; A[11][5] = -1.79589318631187989172765950534e1; A[11][6] = 2.79488845294199600508499808837e1; A[11][7] = -2.85899827713502369474065508674; A[11][8] = -8.87285693353062954433549289258; A[11][9] = 1.23605671757943030647266201528e1; A[11][10] = 6.43392746015763530355970484046e-1
    A[12][0] = 5.42937341165687622380535766363e-2; A[12][5] = 4.45031289275240888144113950566; A[12][6] = 1.89151789931450038304281599044; A[12][7] = -5.8012039600105847814672114227; A[12][8] = 3.1116436695781989440891606237e-1; A[12][9] = -1.52160949662516078556178806805e-1; A[12][10] = 2.01365400804030348374776537501e-1; A[12][11] = 4.47106157277725905176885569043e-2
    A[13][0] = 5.61675022830479523392909219681e-2; A[13][6] = 2.53500210216624811088794765333e-1; A[13][7] = -2.46239037470802489917441475441e-1; A[13][8] = -1.24191423263816360469010140626e-1; A[13][9] = 1.5329179827876569731206322685e-1; A[13][10] = 8.20105229563468988491666602057e-3; A[13][11] = 7.56789766054569976138603589584e-3; A[13][12] = -8.298e-3
    A[14][0] = 3.18346481635021405060768473261e-2; A[14][5] = 2.83009096723667755288322961402e-2; A[14][6] = 5.35419883074385676223797384372e-2; A[14][7] = -5.49237485713909884646569340306e-2; A[14][10] = -1.08347328697249322858509316994e-4; A[14][11] = 3.82571090835658412954920192323e-4; A[14][12] = -3.40465008687404560802977114492e-4; A[14][13] = 1.41312443674632500278074618366e-1
    A[15][0] = -4.28896301583791923408573538692e-1; A[15][5] = -4.69762141536116384314449447206; A[15][6] = 7.68342119606259904184240953878; A[15][7] = 4.06898981839711007970213554331; A[15][8] = 3.56727187455281109270669543021e-1; A[15][12] = -1.39902416515901462129418009734e-3; A[15][13] = 2.9475147891527723389556272149; A[15][14] = -9.15095847217987001081870187138
    b = A[N_STAGES][:N_STAGES]
    # E3 = np.zeros(N_STAGES + 1)
    # E3[:-1] = B.copy()
    # E3[0] -= 0.244094488188976377952755905512
    # E3[8] -= 0.733846688281611857341361741547
    # E3[11] -= 0.220588235294117647058823529412e-1
    E5 = [0.0]*N_STAGES
    E5[0] = 0.1312004499419488073250102996e-1
    E5[5] = -0.1225156446376204440720569753e+1
    E5[6] = -0.4957589496572501915214079952
    E5[7] = 0.1664377182454986536961530415e+1
    E5[8] = -0.3503288487499736816886487290
    E5[9] = 0.3341791187130174790297318841
    E5[10] = 0.8192320648511571246570742613e-1
    E5[11] = -0.2235530786388629525884427845e-1
    bh5 = [b[i]-E5[i] for i in range(N_STAGES)]
    # bh3 = B - E3
    return {
        "A": [row[:N_STAGES] for row in A[:N_STAGES]],
        "B": [b, bh5],
        "C": C[:N_STAGES],
        "order": 8,
        "embedded_order": 5,
        "a_stable": False
    }


def _get_sdirk21_crouzeix_raviart():
    """
    Embedded SDIRK: Crouzeix-Raviart method (Order 1/2, 2 stages)
    A-stable.
    """
    
    gamma = 1 - 1.0/ np.sqrt(2)
    
    A = [
            [gamma, 0.0],
            [1.0 - gamma, gamma]
        ]
    
    b = [1-gamma, gamma] # Coefficients for the higher-order solution (Order 2)
    b_embedded = [1.0, 0.0]  # Coefficients for the lower-order embedded solution (Order 1)
    B = [b, b_embedded]
    C = [gamma, 1.0]
    
    return {"A": A, "B": B, "C": C, "order": 2, "embedded_order": 1, "a_stable": True}

def _get_sdirk_norsett_thomson_23():
    """
    Embedded SDIRK: Norsett & Thomson (Order 2/3, 3 stages)
    """
    A = [
        [5/6, 0.0, 0.0],
        [-61/108, 5/6, 0.0],
        [-23/183, -33/61, 5/6]
    ]
    b = [25/61, 36/61, 0.0] # Order 3 solution for step
    bh = [26/61, 324/671, 1/11] # Order 2 solution for prediction
    B = [b, bh]
    C = [5/6, 29/108, 1/6]
    return {"A": A, "B": B, "C": C, "order": 3, "embedded_order": 2, "a_stable": True}

def _get_sdirk_norsett_thomson_34():
    """Returns the data for the SDIRK scheme."""
    alpha = 5.0/6
    A = [
        [alpha, 0, 0, 0],
        [-15/26, alpha, 0, 0],
        [215/54, -130/27, alpha, 0],
        [4007/6075, -31031/24300, -133/2700, alpha]
    ]
    B = [
        [32/75, 169/300, 1/100, 0],
        [61/150, 2197/2100, 19/100, -9/14]
    ]
    C = [alpha, 10/39, 0, 1/6]
    return {
        "A": A,
        "B": B,
        "C": C,
        "order": 4,
        "embedded_order": 3,
        "a_stable": True
    }

def _get_sdirk_hairer_norsett_wanner_45():
    """
    Embedded SDIRK: Hairer, Norsett & Wanner (Order 4/5, 5 stages)
    """
    A = [
        [1/4, 0.0, 0.0, 0.0, 0.0],
        [1/2,    1/4, 0.0, 0.0, 0.0],
        [17/50, -1/25,    1/4, 0.0, 0.0],
        [371/1360, -137/2720, 15/544, 1/4, 0.0],
        [25/24, -49/48, 125/16, -85/12,    1/4]
    ]
    b = [25/24, -49/48, 125/16, -85/12, 1/4] # Order 5 solution for step
    bh = [59/48, -17/96, 225/32, -85/12, 0.0] 
    B = [b, bh]
    C = [1/4, 3/4, 11/20, 1/2, 1.0]
    return {"A": A, "B": B, "C": C, "order": 5, "embedded_order": 4, "a_stable": True, "l_stable": True}

def _get_esdirk6():

    A = [
            [Fraction(0, 1), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1)],
            [Fraction(5, 16), Fraction(5, 16), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1)],
            [Fraction(-6647797099592, 102714892273533), Fraction(-6647797099592, 102714892273533), Fraction(5, 16), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1)],
            [Fraction(-87265218833, 1399160431079), Fraction(-87265218833, 1399160431079), Fraction(3230569391728, 5191843160709), Fraction(5, 16), Fraction(0, 1), Fraction(0, 1), Fraction(0, 1)],
            [Fraction(-3742173976023, 7880396319491), Fraction(-4537732256035, 9784784042546), Fraction(32234033847818, 24636233068093), Fraction(1995418204833, 9606020544314), Fraction(5, 16), Fraction(0, 1), Fraction(0, 1)],
            [Fraction(-460973220726, 7579441323155), Fraction(-113988582459, 8174956167569), Fraction(-679076942985, 7531712581924), Fraction(1946214040135, 12392905069014), Fraction(-2507263458377, 16215886710685), Fraction(5, 16), Fraction(0, 1)],
            [Fraction(2429030329867, 4957732179206), Fraction(5124723475981, 12913403568538), Fraction(3612624980699, 11761071195830), Fraction(714493169479, 5549220584147), Fraction(-4586610949246, 13858427945825), Fraction(-4626134504839, 7500671962341), Fraction(5, 16)]
        ]

    b = [Fraction(541976983222, 5570117184863), Fraction(424517620289, 10281234581904), Fraction(3004784109584, 2968823999583), Fraction(-1080268266981, 2111416452515), Fraction(3198291424887, 7137915940442), Fraction(-6709580973937, 9894986011196), Fraction(4328230890552, 7324362344791)]
    bhat = [Fraction(23807813993, 6613359907661), Fraction(122567156372, 6231407414731), Fraction(5289947382915, 9624205771537), Fraction(-132784415823, 2592433009541), Fraction(2055455363695, 9863229933602), Fraction(-686952476184, 6416474135057), Fraction(2766631516579, 7339217152243)]

    # Convert to floats for numerical use
    A = [[float(x) for x in row] for row in A]
    b_float = [float(x) for x in b]
    bhat_float = [float(x) for x in bhat]
    B = [b_float, bhat_float]
    c1 = 0; c2 = 5./8; c3 = 5.*(2-np.sqrt(2))/16; c4 = 81./100; c5 = 89./100; c6 = 3./20; c7 = 11./16
    C = [c1,c2,c3,c4,c5,c6,c7]
    return {"A": A, "B": B, "C": C, "order": 6, "embedded_order": 4, "a_stable": True}

def available_butcher_table_data_to_json():
    """
    Collects data from all scheme functions and generates a single JSON file.
    """
    all_schemes = {
        "erk1": _get_erk1(),
        "erk2": _get_erk2_midpoint(),
        "erk4": _get_erk4(),
        "sdirk1": _get_sdirk1(),
        "sdirk2": _get_sdirk2_midpoint(),
        "sdirk4": _get_sdirk43_crouzeix(),
        "cooper_verner8": _get_cooper_verner(),
        "euler_heun21": _get_euler_heun(),
        "bogacki_shampine43": _get_bogacki_shampine(),
        "fehlberg54": _get_fehlberg45(),
        "dopri54": _get_dopri5(),
        "dopri85": _get_dorpri85(),
        "sdirk21": _get_sdirk21_crouzeix_raviart(),
        "sdirk32": _get_sdirk_norsett_thomson_23(),
        "sdirk43": _get_sdirk_norsett_thomson_34(),
        "sdirk54": _get_sdirk_hairer_norsett_wanner_45(),
        "esdirk64": _get_esdirk6()
    }

    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(script_dir, "tableaux_de_butcher_disponibles.json")

    with open(file_path, 'w') as f:
        json.dump(all_schemes, f, indent=4)
    
if __name__ == '__main__':
    available_butcher_table_data_to_json()