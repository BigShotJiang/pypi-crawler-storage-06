class SnowModel:
    def initialize(self):
        pass

    def albedo_aging(self):
        pass

    def compaction(self):
        pass

    def accumulation(self):
        pass

    def heat_conduction(self):
        pass

    def melt(self):
        pass

    def sublimation(self):
        pass

    def runoff(self):
        pass

    def update_layers(self):
        pass

    def update_properties(self):
        pass

    def add_snow(
        self,
        pos,
        ice_content,
        liquid_water_content=0,
        density=None,
        albedo=None,
    ):
        pass
