该接口服务，可通过已封装的Python SDK实现调用。使用方式如下：

## 安装

```bash
pip install gf_inst_client
```

## 使用示例

```python
from gf_inst_client import APIConfig, GFAPIClient, Condition

# API配置
config = APIConfig(
    app_id="your_app_id_here",
    key="your_key_here"
)

# 创建API客户端
client = GFAPIClient(config)

# 查询参数
secu_ids = ['000300.SH']
fields = ['secu_id', 'pric_open', 'pric_clos', 'trd_dt']
endpoint = "/dsp/ds/service/news/news_idx_mkt_quot_gfzh_nc" # 仅示例，实际调用路径及参数，请以本身接口文档为准
conditions = [
    Condition.in_list("secu_id", secu_ids),
    Condition.gt("trd_dt", '20250101')
]
orderFields = ['trd_dt,desc']

# 执行查询
result = client.query(endpoint, conditions, fields, orderFields, auto_paging=True, return_dataframe=True)
print(result)
```

## 条件构建器

提供了多种条件构建方法：

- `eq`: 等于
- `lt`: 小于
- `gt`: 大于
- `le`: 小于等于
- `ge`: 大于等于
- `begin_with`: 以...开始
- `end_with`: 以...结束
- `contain`: 包含
- `in_list`: 在列表中
- `between`: 在指定区间条件
- `or_conditions`: 或条件

## 条件构建器使用示例

`Condition` 类提供了多种条件构建方法，以下是每个方法的详细示例：

### 1. 等于条件 (eq)
```python
# 查询股票代码等于 000001.SZ 的数据
condition = Condition.eq("secu_id", "000001.SZ")
# 结果: "eq,secu_id,'000001.SZ'"
```

### 2. 小于条件 (lt)
```python
# 查询价格小于 10 的数据
condition = Condition.lt("price", 10)
# 结果: "lt,price,10"
```

### 3. 大于条件 (gt)
```python
# 查询日期大于 2024-01-01 的数据
condition = Condition.gt("trd_dt", "20240101")
# 结果: "gt,trd_dt,'20240101'"
```

### 4. 小于等于条件 (le)
```python
# 查询成交量小于等于 1000000 的数据
condition = Condition.le("volume", 1000000)
# 结果: "le,volume,1000000"
```

### 5. 大于等于条件 (ge)
```python
# 查询市值大于等于 1000000000 的数据
condition = Condition.ge("market_value", 1000000000)
# 结果: "ge,market_value,1000000000"
```

### 6. 以...开始条件 (begin_with)
```python
# 查询以 "沪" 开头的股票名称
condition = Condition.begin_with("stock_name", "沪")
# 结果: "beginWith,stock_name,'沪'"
```

### 7. 以...结束条件 (end_with)
```python
# 查询以 "银行" 结尾的股票名称
condition = Condition.end_with("stock_name", "银行")
# 结果: "endWith,stock_name,'银行'"
```

### 8. 包含条件 (contain)
```python
# 查询名称中包含 "科技" 的股票
condition = Condition.contain("stock_name", "科技")
# 结果: "contain,stock_name,'科技'"
```

### 9. 在列表中条件 (in_list)
```python
# 查询多个股票代码的数据
secu_ids = ["000001.SZ", "000002.SZ", "000003.SZ"]
condition = Condition.in_list("secu_id", secu_ids)
# 结果: "in,secu_id,'000001.SZ;000002.SZ;000003.SZ'"
```

### 11. 在指定区间条件 (between)
```python
# 查询日期范围在 20250101 和 20250601 之间的数据
condition = Condition.between("trd_dt", ['20250101','20250601'])
# 结果: "between,trd_dt,'20250101'#'20250601'"
```

### 12. 或条件 (or_conditions)
```python
# 查询沪深300或上证50的股票
condition1 = Condition.eq("index_code", "000300.SH")  # 沪深300
condition2 = Condition.eq("index_code", "000016.SH")  # 上证50
condition = Condition.or_conditions(condition1, condition2)
# 结果: "or,eq#index_code#'000300.SH',eq#index_code#'000016.SH'"
```

### 组合条件示例
```python
# 组合多个条件：查询 2024年1月1日 之后的 沪深300 成分股的数据
conditions = [
    Condition.gt("trd_dt", "20240101"),
    Condition.eq("index_code", "000300.SH")
]

result = client.query(
    endpoint="/your/endpoint",
    conditions=conditions,
    fields=["secu_id", "stock_name", "close_price"]
)
```

## 注意事项

- 条件值如果是字符串类型，会自动添加单引号
- 数值类型（整数、浮点数）不会添加引号
- 日期格式推荐使用 "YYYYMMDD" 格式
- 多个条件可以组合使用，形成一个条件列表
- 使用 `or_conditions` 时，内部的逗号会被替换为 '#' 符号

## 依赖要求

- Python >= 3.6
- requests >= 2.31.0
- pandas >= 2.0.0


