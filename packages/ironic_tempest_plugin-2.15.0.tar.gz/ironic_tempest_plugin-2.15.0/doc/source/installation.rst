============
Installation
============

At the command line::

    $ pip install ironic-tempest-plugin

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv ironic-tempest-plugin
    $ pip install ironic-tempest-plugin
