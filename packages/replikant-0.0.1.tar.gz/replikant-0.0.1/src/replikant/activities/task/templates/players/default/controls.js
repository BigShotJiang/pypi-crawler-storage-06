var audio = document.getElementById("sample");
var audio_source = document.getElementById("sample_src");
