# coding: utf8
# license : CeCILL-C


from flask_session import Session

session_manager: Session = Session()
