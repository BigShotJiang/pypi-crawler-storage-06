from replikant.main import main

main()
