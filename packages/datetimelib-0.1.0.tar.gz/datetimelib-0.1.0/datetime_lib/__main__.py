from .core import get_current_datetime

def main():
    print(get_current_datetime())

if __name__ == "__main__":
    main()
