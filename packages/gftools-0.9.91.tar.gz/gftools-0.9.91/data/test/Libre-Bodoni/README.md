Libre Bodoni Fonts
======================

## Current Status
- Version 1.001 is the latest stable version.
- Version 2.002 is an ongoing migration to Glyphs and Vietnamese extension, but is still a work in progress.

## Description

The Libre Bodoni fonts are based on the 19th century Morris Fuller Benton's ATF design, but specifically adapted for today's web requirements.

They are a perfect choice for everything related to elegance, style, luxury and fashion.

Libre Bodoni currently features four styles: Regular, Italic, Bold and Bold Italic.

## License

- Libre Bodoni is licensed under the SIL Open Font License v1.1 (<http://scripts.sil.org/OFL>)
- To view the copyright and specific terms and conditions please refer to [OFL.txt](https://github.com/impallari/Libre-Bodoni/blob/master/OFL.txt)

## Language Coverage

The Libre Bodoni Fonts covers all 104 Latin Languages: Afar, Afrikaans, Albanian, Azerbaijani, Basque, Belarusian, Bislama, Bosnian, Breton, Catalan, Chamorro, Chichewa, Comorian, Croatian, Czech, Danish, Dutch, English, Esperanto, Estonian, Faroese, Fijian, Filipino/Tagalog, Finnish, Flemish, French, Gaelic (Irish / Manx / Scottish), Gagauz, German, Gikuyu, Gilbertese/Kiribati, Greenlandic, Guarani, Haitian_Creole, Hawaiian, Hungarian, Icelandic, Igo/Igbo, Indonesian, Irish, Italian, Javanese, Kashubian, Kinyarwanda, Kirundi, Latin, Latvian, Lithuanian, Luba/Ciluba/Kasai, Luxembourgish, Malagasy, Malay, Maltese, Maori, Marquesan, Marshallese, Moldovan/Moldovian/Romanian, Montenegrin, Nauruan, Ndebele, Norwegian, Oromo, Palauan/Belauan, Polish, Portuguese, Quechua, Romanian, Romansh, Sami, Samoan, Sango, Serbian, Sesotho, Setswana/Sitswana/Tswana, Seychellois_Creole, SiSwati/Swati/Swazi, Silesian, Slovak, Slovenian, Somali, Sorbian, Sotho, Spanish, Swahili, Swedish, Tahitian, Tetum, Tok_Pisin, Tongan, Tsonga, Tswana, Tuareg/Berber, Turkish, Turkmen, Tuvaluan, Uzbek/Usbek, Wallisian, Walloon, Welsh, Xhosa, Yoruba, Zulu.

## Authors

[Pablo Impallari](http://www.impallari.com) and [Rodrigo Fuenzalida](http://www.rfuenzalida.com)
