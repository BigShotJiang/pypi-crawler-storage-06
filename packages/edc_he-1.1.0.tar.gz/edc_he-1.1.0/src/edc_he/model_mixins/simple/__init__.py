from .education_model_mixin import HealthEconomicsEducationModelMixin

__all__ = ["HealthEconomicsEducationModelMixin"]
