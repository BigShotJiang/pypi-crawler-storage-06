"""
    victron_ble2mqtt
    Emit MQTT events from victron-ble
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.7.2'
__author__ = 'Jens Diemer <git@jensdiemer.de>'
