from dialectical_framework.synthesist.domain.wheel_segment import WheelSegment

ALIAS_S_PLUS = "S+"
ALIAS_S_MINUS = "S-"


class Synthesis(WheelSegment): ...
