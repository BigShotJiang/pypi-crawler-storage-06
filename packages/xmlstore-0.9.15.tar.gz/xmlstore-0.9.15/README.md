xmlstore is a Python package for storing information in XML format
with extensible support for typing and schema validaton