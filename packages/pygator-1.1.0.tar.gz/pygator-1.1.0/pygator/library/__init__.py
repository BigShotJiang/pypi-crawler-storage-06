# my_package/__init__.py
# from pygator.module import *
# from ._version import __version__

# pygator/__init__.py
from .materials import *
