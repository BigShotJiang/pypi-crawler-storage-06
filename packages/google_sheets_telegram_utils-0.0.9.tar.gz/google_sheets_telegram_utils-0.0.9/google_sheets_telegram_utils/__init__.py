"""
google-sheets-telegram-utils.

A package with utils to work with google spreadsheet and telegram.
"""

__version__ = "0.0.6"
__author__ = 'Alexander Varkalov'

