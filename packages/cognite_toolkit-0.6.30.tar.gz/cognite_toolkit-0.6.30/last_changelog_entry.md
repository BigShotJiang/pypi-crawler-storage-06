## cdf 

### Fixed

- When running `cdf build` Toolkit no longer give warnings on extraction
pipelines for unused field sendNotification. For example: ` In
contacts[1] unused field: 'sendNotification'`

## templates

No changes.