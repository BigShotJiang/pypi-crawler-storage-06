"""
    cli-base-utilities
    Helpers to bild a CLI program
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.24.0'

__author__ = 'Jens Diemer <github@jensdiemer.de>'
