# Tyro CLI Shell Completion

Helper to setup shell completion for a Tyro based CLI program.

Currently only bash shell is supported.
Usage: Expand you Tyro CLI and call `setup_tyro_shell_completion()` from your program ;)