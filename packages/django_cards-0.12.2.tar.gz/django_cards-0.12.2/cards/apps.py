from django.apps import AppConfig


class ModalConfig(AppConfig):
    default_auto_field = 'django.db.models.AutoField'
    name = 'cards'
    verbose_name = 'Cards'
