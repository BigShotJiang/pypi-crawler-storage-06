# PyFuncLink

Library to automatically detect and make clickable links in Tkinter, CTk, ttk, PyQt5/6, PySide6, wxPython, and HTML widgets.
