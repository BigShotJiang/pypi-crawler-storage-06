"""Main command-line interface for the MindLogger export processing package."""

from .main import cli

if __name__ == "__main__":
    cli()
