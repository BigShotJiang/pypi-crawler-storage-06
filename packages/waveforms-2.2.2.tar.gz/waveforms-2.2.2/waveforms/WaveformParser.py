# Generated from Waveform.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,22,134,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,1,0,1,0,3,0,21,8,0,1,1,1,1,1,1,1,1,1,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,41,8,2,1,2,1,2,1,
        2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,5,2,55,8,2,10,2,12,2,58,9,
        2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,
        3,1,3,1,3,1,3,1,3,3,3,80,8,3,1,4,1,4,1,4,5,4,85,8,4,10,4,12,4,88,
        9,4,1,5,1,5,1,5,5,5,93,8,5,10,5,12,5,96,9,5,1,6,1,6,1,6,1,6,1,7,
        1,7,1,7,1,7,1,7,1,7,5,7,108,8,7,10,7,12,7,111,9,7,1,7,1,7,3,7,115,
        8,7,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,4,8,126,8,8,11,8,12,8,127,
        1,8,1,8,3,8,132,8,8,1,8,0,1,4,9,0,2,4,6,8,10,12,14,16,0,4,2,0,2,
        2,19,19,1,0,3,4,1,0,5,6,1,0,20,21,146,0,20,1,0,0,0,2,22,1,0,0,0,
        4,40,1,0,0,0,6,79,1,0,0,0,8,81,1,0,0,0,10,89,1,0,0,0,12,97,1,0,0,
        0,14,114,1,0,0,0,16,131,1,0,0,0,18,21,3,2,1,0,19,21,3,4,2,0,20,18,
        1,0,0,0,20,19,1,0,0,0,21,1,1,0,0,0,22,23,5,18,0,0,23,24,5,1,0,0,
        24,25,3,4,2,0,25,3,1,0,0,0,26,27,6,2,-1,0,27,28,5,7,0,0,28,29,3,
        4,2,0,29,30,5,8,0,0,30,41,1,0,0,0,31,32,5,6,0,0,32,41,3,4,2,8,33,
        41,3,6,3,0,34,41,5,17,0,0,35,41,5,12,0,0,36,41,5,16,0,0,37,41,3,
        14,7,0,38,41,3,16,8,0,39,41,5,18,0,0,40,26,1,0,0,0,40,31,1,0,0,0,
        40,33,1,0,0,0,40,34,1,0,0,0,40,35,1,0,0,0,40,36,1,0,0,0,40,37,1,
        0,0,0,40,38,1,0,0,0,40,39,1,0,0,0,41,56,1,0,0,0,42,43,10,13,0,0,
        43,44,7,0,0,0,44,55,3,4,2,14,45,46,10,12,0,0,46,47,7,1,0,0,47,55,
        3,4,2,13,48,49,10,11,0,0,49,50,7,2,0,0,50,55,3,4,2,12,51,52,10,10,
        0,0,52,53,7,3,0,0,53,55,3,4,2,11,54,42,1,0,0,0,54,45,1,0,0,0,54,
        48,1,0,0,0,54,51,1,0,0,0,55,58,1,0,0,0,56,54,1,0,0,0,56,57,1,0,0,
        0,57,5,1,0,0,0,58,56,1,0,0,0,59,60,5,18,0,0,60,61,5,7,0,0,61,80,
        5,8,0,0,62,63,5,18,0,0,63,64,5,7,0,0,64,65,3,8,4,0,65,66,5,8,0,0,
        66,80,1,0,0,0,67,68,5,18,0,0,68,69,5,7,0,0,69,70,3,10,5,0,70,71,
        5,8,0,0,71,80,1,0,0,0,72,73,5,18,0,0,73,74,5,7,0,0,74,75,3,8,4,0,
        75,76,5,9,0,0,76,77,3,10,5,0,77,78,5,8,0,0,78,80,1,0,0,0,79,59,1,
        0,0,0,79,62,1,0,0,0,79,67,1,0,0,0,79,72,1,0,0,0,80,7,1,0,0,0,81,
        86,3,4,2,0,82,83,5,9,0,0,83,85,3,4,2,0,84,82,1,0,0,0,85,88,1,0,0,
        0,86,84,1,0,0,0,86,87,1,0,0,0,87,9,1,0,0,0,88,86,1,0,0,0,89,94,3,
        12,6,0,90,91,5,9,0,0,91,93,3,12,6,0,92,90,1,0,0,0,93,96,1,0,0,0,
        94,92,1,0,0,0,94,95,1,0,0,0,95,11,1,0,0,0,96,94,1,0,0,0,97,98,5,
        18,0,0,98,99,5,1,0,0,99,100,3,4,2,0,100,13,1,0,0,0,101,102,5,10,
        0,0,102,115,5,11,0,0,103,104,5,10,0,0,104,109,3,4,2,0,105,106,5,
        9,0,0,106,108,3,4,2,0,107,105,1,0,0,0,108,111,1,0,0,0,109,107,1,
        0,0,0,109,110,1,0,0,0,110,112,1,0,0,0,111,109,1,0,0,0,112,113,5,
        11,0,0,113,115,1,0,0,0,114,101,1,0,0,0,114,103,1,0,0,0,115,15,1,
        0,0,0,116,117,5,7,0,0,117,118,3,4,2,0,118,119,5,9,0,0,119,120,5,
        8,0,0,120,132,1,0,0,0,121,122,5,7,0,0,122,125,3,4,2,0,123,124,5,
        9,0,0,124,126,3,4,2,0,125,123,1,0,0,0,126,127,1,0,0,0,127,125,1,
        0,0,0,127,128,1,0,0,0,128,129,1,0,0,0,129,130,5,8,0,0,130,132,1,
        0,0,0,131,116,1,0,0,0,131,121,1,0,0,0,132,17,1,0,0,0,11,20,40,54,
        56,79,86,94,109,114,127,131
    ]

class WaveformParser ( Parser ):

    grammarFileName = "Waveform.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "'^'", "'*'", "'/'", "'+'", "'-'", 
                     "'('", "')'", "','", "'['", "']'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'**'", "'<<'", "'>>'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "NUMBER", "REAL", "INT", "IMAG", "STRING", "CONSTANT", 
                      "ID", "POW", "LSHIFT", "RSHIFT", "WS" ]

    RULE_expr = 0
    RULE_assignment = 1
    RULE_expression = 2
    RULE_functionCall = 3
    RULE_args = 4
    RULE_kwargs = 5
    RULE_kwarg = 6
    RULE_list = 7
    RULE_tuple = 8

    ruleNames =  [ "expr", "assignment", "expression", "functionCall", "args", 
                   "kwargs", "kwarg", "list", "tuple" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    NUMBER=12
    REAL=13
    INT=14
    IMAG=15
    STRING=16
    CONSTANT=17
    ID=18
    POW=19
    LSHIFT=20
    RSHIFT=21
    WS=22

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assignment(self):
            return self.getTypedRuleContext(WaveformParser.AssignmentContext,0)


        def expression(self):
            return self.getTypedRuleContext(WaveformParser.ExpressionContext,0)


        def getRuleIndex(self):
            return WaveformParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)




    def expr(self):

        localctx = WaveformParser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_expr)
        try:
            self.state = 20
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 18
                self.assignment()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 19
                self.expression(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(WaveformParser.ID, 0)

        def expression(self):
            return self.getTypedRuleContext(WaveformParser.ExpressionContext,0)


        def getRuleIndex(self):
            return WaveformParser.RULE_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignment" ):
                listener.enterAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignment" ):
                listener.exitAssignment(self)




    def assignment(self):

        localctx = WaveformParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_assignment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 22
            self.match(WaveformParser.ID)
            self.state = 23
            self.match(WaveformParser.T__0)
            self.state = 24
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return WaveformParser.RULE_expression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class PowerExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(WaveformParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(WaveformParser.ExpressionContext,i)

        def POW(self):
            return self.getToken(WaveformParser.POW, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPowerExpression" ):
                listener.enterPowerExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPowerExpression" ):
                listener.exitPowerExpression(self)


    class ConstantExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CONSTANT(self):
            return self.getToken(WaveformParser.CONSTANT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstantExpression" ):
                listener.enterConstantExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstantExpression" ):
                listener.exitConstantExpression(self)


    class ListExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def list_(self):
            return self.getTypedRuleContext(WaveformParser.ListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListExpression" ):
                listener.enterListExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListExpression" ):
                listener.exitListExpression(self)


    class TupleExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def tuple_(self):
            return self.getTypedRuleContext(WaveformParser.TupleContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTupleExpression" ):
                listener.enterTupleExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTupleExpression" ):
                listener.exitTupleExpression(self)


    class NumberExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMBER(self):
            return self.getToken(WaveformParser.NUMBER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumberExpression" ):
                listener.enterNumberExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumberExpression" ):
                listener.exitNumberExpression(self)


    class ShiftExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(WaveformParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(WaveformParser.ExpressionContext,i)

        def LSHIFT(self):
            return self.getToken(WaveformParser.LSHIFT, 0)
        def RSHIFT(self):
            return self.getToken(WaveformParser.RSHIFT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShiftExpression" ):
                listener.enterShiftExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShiftExpression" ):
                listener.exitShiftExpression(self)


    class FunctionCallExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def functionCall(self):
            return self.getTypedRuleContext(WaveformParser.FunctionCallContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionCallExpression" ):
                listener.enterFunctionCallExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionCallExpression" ):
                listener.exitFunctionCallExpression(self)


    class IdentifierExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(WaveformParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifierExpression" ):
                listener.enterIdentifierExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifierExpression" ):
                listener.exitIdentifierExpression(self)


    class ParenthesesExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(WaveformParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParenthesesExpression" ):
                listener.enterParenthesesExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParenthesesExpression" ):
                listener.exitParenthesesExpression(self)


    class UnaryMinusExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(WaveformParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryMinusExpression" ):
                listener.enterUnaryMinusExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryMinusExpression" ):
                listener.exitUnaryMinusExpression(self)


    class MultiplyDivideExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(WaveformParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(WaveformParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplyDivideExpression" ):
                listener.enterMultiplyDivideExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplyDivideExpression" ):
                listener.exitMultiplyDivideExpression(self)


    class AddSubtractExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(WaveformParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(WaveformParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAddSubtractExpression" ):
                listener.enterAddSubtractExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAddSubtractExpression" ):
                listener.exitAddSubtractExpression(self)


    class StringExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(WaveformParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringExpression" ):
                listener.enterStringExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringExpression" ):
                listener.exitStringExpression(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = WaveformParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 4
        self.enterRecursionRule(localctx, 4, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 40
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                localctx = WaveformParser.ParenthesesExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 27
                self.match(WaveformParser.T__6)
                self.state = 28
                self.expression(0)
                self.state = 29
                self.match(WaveformParser.T__7)
                pass

            elif la_ == 2:
                localctx = WaveformParser.UnaryMinusExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 31
                self.match(WaveformParser.T__5)
                self.state = 32
                self.expression(8)
                pass

            elif la_ == 3:
                localctx = WaveformParser.FunctionCallExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 33
                self.functionCall()
                pass

            elif la_ == 4:
                localctx = WaveformParser.ConstantExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 34
                self.match(WaveformParser.CONSTANT)
                pass

            elif la_ == 5:
                localctx = WaveformParser.NumberExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 35
                self.match(WaveformParser.NUMBER)
                pass

            elif la_ == 6:
                localctx = WaveformParser.StringExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 36
                self.match(WaveformParser.STRING)
                pass

            elif la_ == 7:
                localctx = WaveformParser.ListExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 37
                self.list_()
                pass

            elif la_ == 8:
                localctx = WaveformParser.TupleExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 38
                self.tuple_()
                pass

            elif la_ == 9:
                localctx = WaveformParser.IdentifierExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 39
                self.match(WaveformParser.ID)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 56
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,3,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 54
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
                    if la_ == 1:
                        localctx = WaveformParser.PowerExpressionContext(self, WaveformParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 42
                        if not self.precpred(self._ctx, 13):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 13)")
                        self.state = 43
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==2 or _la==19):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 44
                        self.expression(14)
                        pass

                    elif la_ == 2:
                        localctx = WaveformParser.MultiplyDivideExpressionContext(self, WaveformParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 45
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 46
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==3 or _la==4):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 47
                        self.expression(13)
                        pass

                    elif la_ == 3:
                        localctx = WaveformParser.AddSubtractExpressionContext(self, WaveformParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 48
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 49
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==5 or _la==6):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 50
                        self.expression(12)
                        pass

                    elif la_ == 4:
                        localctx = WaveformParser.ShiftExpressionContext(self, WaveformParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 51
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 52
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==20 or _la==21):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 53
                        self.expression(11)
                        pass

             
                self.state = 58
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class FunctionCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return WaveformParser.RULE_functionCall

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ArgsFunctionContext(FunctionCallContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.FunctionCallContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(WaveformParser.ID, 0)
        def args(self):
            return self.getTypedRuleContext(WaveformParser.ArgsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgsFunction" ):
                listener.enterArgsFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgsFunction" ):
                listener.exitArgsFunction(self)


    class ArgsKwargsFunctionContext(FunctionCallContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.FunctionCallContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(WaveformParser.ID, 0)
        def args(self):
            return self.getTypedRuleContext(WaveformParser.ArgsContext,0)

        def kwargs(self):
            return self.getTypedRuleContext(WaveformParser.KwargsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgsKwargsFunction" ):
                listener.enterArgsKwargsFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgsKwargsFunction" ):
                listener.exitArgsKwargsFunction(self)


    class NoArgFunctionContext(FunctionCallContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.FunctionCallContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(WaveformParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNoArgFunction" ):
                listener.enterNoArgFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNoArgFunction" ):
                listener.exitNoArgFunction(self)


    class KwargsFunctionContext(FunctionCallContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a WaveformParser.FunctionCallContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(WaveformParser.ID, 0)
        def kwargs(self):
            return self.getTypedRuleContext(WaveformParser.KwargsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKwargsFunction" ):
                listener.enterKwargsFunction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKwargsFunction" ):
                listener.exitKwargsFunction(self)



    def functionCall(self):

        localctx = WaveformParser.FunctionCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_functionCall)
        try:
            self.state = 79
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                localctx = WaveformParser.NoArgFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 59
                self.match(WaveformParser.ID)
                self.state = 60
                self.match(WaveformParser.T__6)
                self.state = 61
                self.match(WaveformParser.T__7)
                pass

            elif la_ == 2:
                localctx = WaveformParser.ArgsFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 62
                self.match(WaveformParser.ID)
                self.state = 63
                self.match(WaveformParser.T__6)
                self.state = 64
                self.args()
                self.state = 65
                self.match(WaveformParser.T__7)
                pass

            elif la_ == 3:
                localctx = WaveformParser.KwargsFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 67
                self.match(WaveformParser.ID)
                self.state = 68
                self.match(WaveformParser.T__6)
                self.state = 69
                self.kwargs()
                self.state = 70
                self.match(WaveformParser.T__7)
                pass

            elif la_ == 4:
                localctx = WaveformParser.ArgsKwargsFunctionContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 72
                self.match(WaveformParser.ID)
                self.state = 73
                self.match(WaveformParser.T__6)
                self.state = 74
                self.args()
                self.state = 75
                self.match(WaveformParser.T__8)
                self.state = 76
                self.kwargs()
                self.state = 77
                self.match(WaveformParser.T__7)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(WaveformParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(WaveformParser.ExpressionContext,i)


        def getRuleIndex(self):
            return WaveformParser.RULE_args

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgs" ):
                listener.enterArgs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgs" ):
                listener.exitArgs(self)




    def args(self):

        localctx = WaveformParser.ArgsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_args)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 81
            self.expression(0)
            self.state = 86
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,5,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 82
                    self.match(WaveformParser.T__8)
                    self.state = 83
                    self.expression(0) 
                self.state = 88
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KwargsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kwarg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(WaveformParser.KwargContext)
            else:
                return self.getTypedRuleContext(WaveformParser.KwargContext,i)


        def getRuleIndex(self):
            return WaveformParser.RULE_kwargs

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKwargs" ):
                listener.enterKwargs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKwargs" ):
                listener.exitKwargs(self)




    def kwargs(self):

        localctx = WaveformParser.KwargsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_kwargs)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 89
            self.kwarg()
            self.state = 94
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==9:
                self.state = 90
                self.match(WaveformParser.T__8)
                self.state = 91
                self.kwarg()
                self.state = 96
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KwargContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(WaveformParser.ID, 0)

        def expression(self):
            return self.getTypedRuleContext(WaveformParser.ExpressionContext,0)


        def getRuleIndex(self):
            return WaveformParser.RULE_kwarg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKwarg" ):
                listener.enterKwarg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKwarg" ):
                listener.exitKwarg(self)




    def kwarg(self):

        localctx = WaveformParser.KwargContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_kwarg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 97
            self.match(WaveformParser.ID)
            self.state = 98
            self.match(WaveformParser.T__0)
            self.state = 99
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(WaveformParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(WaveformParser.ExpressionContext,i)


        def getRuleIndex(self):
            return WaveformParser.RULE_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterList" ):
                listener.enterList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitList" ):
                listener.exitList(self)




    def list_(self):

        localctx = WaveformParser.ListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_list)
        self._la = 0 # Token type
        try:
            self.state = 114
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 101
                self.match(WaveformParser.T__9)
                self.state = 102
                self.match(WaveformParser.T__10)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 103
                self.match(WaveformParser.T__9)
                self.state = 104
                self.expression(0)
                self.state = 109
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==9:
                    self.state = 105
                    self.match(WaveformParser.T__8)
                    self.state = 106
                    self.expression(0)
                    self.state = 111
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 112
                self.match(WaveformParser.T__10)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TupleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(WaveformParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(WaveformParser.ExpressionContext,i)


        def getRuleIndex(self):
            return WaveformParser.RULE_tuple

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTuple" ):
                listener.enterTuple(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTuple" ):
                listener.exitTuple(self)




    def tuple_(self):

        localctx = WaveformParser.TupleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_tuple)
        self._la = 0 # Token type
        try:
            self.state = 131
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 116
                self.match(WaveformParser.T__6)
                self.state = 117
                self.expression(0)
                self.state = 118
                self.match(WaveformParser.T__8)
                self.state = 119
                self.match(WaveformParser.T__7)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 121
                self.match(WaveformParser.T__6)
                self.state = 122
                self.expression(0)
                self.state = 125 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 123
                    self.match(WaveformParser.T__8)
                    self.state = 124
                    self.expression(0)
                    self.state = 127 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==9):
                        break

                self.state = 129
                self.match(WaveformParser.T__7)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[2] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 13)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 10)
         




