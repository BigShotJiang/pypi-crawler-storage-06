from .compute_container_pb2 import (
    MountPoint,
    ProxyConfiguration,
    ProxyConfigurationDomainAllowlist,
    ProxyConfigurationLiberal,
)
