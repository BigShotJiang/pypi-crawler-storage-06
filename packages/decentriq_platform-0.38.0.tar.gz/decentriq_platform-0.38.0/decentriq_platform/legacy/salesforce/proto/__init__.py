from .salesforce_pb2 import (
    Core,
    ExportRole,
    ImportRole,
    MarketingCloud,
    RawFile,
    SalesforceWorkerConfiguration,
    SingleFile,
    SinkInput,
    ZipFile,
)
