from .adform_dsp_pb2 import (
    AdformDspWorkerConfiguration,
    RawFile,
    SingleFile,
    SinkInput,
    ZipFile,
)

