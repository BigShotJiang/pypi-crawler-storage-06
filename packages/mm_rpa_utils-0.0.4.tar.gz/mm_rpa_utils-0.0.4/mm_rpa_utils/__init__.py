# __init__.py
from .funciones import *
