nima
~~~~

Here is the UML for the implementation class.
