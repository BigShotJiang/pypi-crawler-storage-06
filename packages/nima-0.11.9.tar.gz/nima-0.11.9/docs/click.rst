.. _cli:

Command-line tool
=================

.. contents::
   :local:

.. click:: nima.__main__:main
   :prog: nima
   :nested: full

.. click:: nima.__main__:bima
   :prog: bima
   :nested: full
