2.0.16 (2025-09-22)
~~~~~~~~~~~~~~~~~~~

* [FIX] Installation trouble
* [QUA] Test coverage 17% (3472: 2876+596) [0 TestPoints] - quality rating 13 (target 100)

2.0.15 (2025-08-28)
~~~~~~~~~~~~~~~~~~~

* [FIX] odoorc: integrated findpkg
* [FIX] clodoo.py
* [FIX] python 3.11

2.0.14 (2025-06-14)
~~~~~~~~~~~~~~~~~~~

* [IMP] odoorc: new option NOLINK
* [IMP] odoorc: Odoo 17.0 and 18.0
* [IMP] powerp is not more a default gitorg
* [FIX] License declaration compatible with pypi

2.0.13 (2024-08-22)
~~~~~~~~~~~~~~~~~~~

* [IMP] Depends on z0lib>=2.0.11

2.0.12 (2024-07-03)
~~~~~~~~~~~~~~~~~~~

* [FIX] Rpc with odoo < 10.0
* [IMP] It does no more depends on os0
* [IMP] Python 3.6 deprecated

2.0.11 (2024-03-31)
~~~~~~~~~~~~~~~~~~~

* [IMP] Parameters review
* [FIX] No file during pip install
* [FIX] Call with context Odoo 10.0+

2.0.10 (2024-03-26)
~~~~~~~~~~~~~~~~~~~

* [REF] Partial refactoring

2.0.9 (2024-02-02)
~~~~~~~~~~~~~~~~~~

* [IMP] odoorc improvements

2.0.8 (2023-11-16)
~~~~~~~~~~~~~~~~~~

* [FIX] Discard odoorpc 0.10 which does not work

2.0.7 (2023-09-26)
~~~~~~~~~~~~~~~~~~

* [FIX] Some fixes due old wrong code (id -> name)

2.0.6 (2023-07-10)
~~~~~~~~~~~~~~~~~~

* [IMP] Incorporated new pypi oerlib3
* [IMP] Discriminate http_port and xmlrpc_port to avoid mistake
* [IMP] New param IS_MULTI

2.0.5 (2023-05-08)
~~~~~~~~~~~~~~~~~~

* [FIX] clodoo.py: minor fixes
* [IMP] odoorc: odoo version 16.0

2.0.4 (2023-03-29)
~~~~~~~~~~~~~~~~~~

* [IMP] odoorc: minor improvements
* [IMP] odoorc: test for Odoo 16.0
* [IMP] transodoo.py: minor improvements

2.0.3 (2022-12-09)
~~~~~~~~~~~~~~~~~~

* [FIX] odoorc: GIT_BRANCH sometimes fails

2.0.2 (2022-10-20)
~~~~~~~~~~~~~~~~~~

* [FIX] odoorc: GITORGID and other value, sometimes are wrong

2.0.1.1 (2022-10-15)
~~~~~~~~~~~~~~~~~~~~

* [IMP] Minor improvements

2.0.1 (2022-10-12)
~~~~~~~~~~~~~~~~~~

* [IMP] stable version

2.0.0.3 (2022-10-06)
~~~~~~~~~~~~~~~~~~~~

* [IMP] odoorc: best virtual environment recognize
* [FIX] odoorc: SVCNAME

2.0.0.2 (2022-09-14)
~~~~~~~~~~~~~~~~~~~~

* [IMP] list_requirements.py: get data from setup.py od Odoo

2.0.0.1 (2022-09-06)
~~~~~~~~~~~~~~~~~~~~

* [IMP] list_requirements.py: new option -S for secure packages

2.0.0 (2022-08-10)
~~~~~~~~~~~~~~~~~~

* [REF] Stable version

