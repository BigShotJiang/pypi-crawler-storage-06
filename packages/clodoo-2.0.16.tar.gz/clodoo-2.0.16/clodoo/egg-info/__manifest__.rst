.. $set pg_requirements [(8170, "test10"),(8172, "test12"),(8168, "test8"),(8167, "test7"),(8174, "test14")]
