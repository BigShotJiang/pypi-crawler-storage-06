Translate Odoo entity name across versions.
