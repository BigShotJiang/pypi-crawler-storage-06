Just type into any related field, such as Customer on a Sale Order.
