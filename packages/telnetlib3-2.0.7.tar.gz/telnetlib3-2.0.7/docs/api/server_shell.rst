server_shell
------------

.. automodule:: telnetlib3.server_shell
   :members:
