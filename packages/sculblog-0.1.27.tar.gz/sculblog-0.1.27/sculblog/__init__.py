"""
Sculblog - Super Cool Utility Lightweight Blog
A minimalist blogging framework
"""

__version__ = "0.1.0"
