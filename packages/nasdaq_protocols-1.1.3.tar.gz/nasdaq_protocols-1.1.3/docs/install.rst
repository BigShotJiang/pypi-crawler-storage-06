.. _install-guide:

Installation
============

To use nasdaq-protocols, install it using pip:

.. code-block:: console

   $ pip install nasdaq-protocols