from .drive import TSingHuaDrive, download
from .drive import download as download_tsinghua

__all__ = ["TSingHuaDrive", "download", "download_tsinghua"]
