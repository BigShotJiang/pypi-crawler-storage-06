from .drive import OpenXLabDrive as OpenDataLabDrive
from .drive import OpenXLabDrive

__all__ = ["OpenXLabDrive", "OpenDataLabDrive"]
