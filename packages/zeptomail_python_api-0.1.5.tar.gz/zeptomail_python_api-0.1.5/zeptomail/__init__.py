from .client import ZeptoMail
from .errors import ZeptoMailError

__all__ = [
    "ZeptoMail",
    "ZeptoMailError"
]
