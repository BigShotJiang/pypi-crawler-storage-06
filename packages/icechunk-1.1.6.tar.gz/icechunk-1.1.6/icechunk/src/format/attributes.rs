#[derive(Debug, PartialEq)]
pub struct AttributesTable {}
