
from tau_trait.envs.telehealth.env import MockTelehealthDomainEnv as MockTelehealthDomainEnv
