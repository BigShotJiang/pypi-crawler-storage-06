MODEL_METHODS = [
    "classify",
    "binary_classify",
    "parse",
    "generate",
    "parse_force",
    "score",
]
