# Changelog

## 0.6.0 (2025-09-24)

Added Geocoding V2 API version support.

## 0.5.0 (2023-06-15)

Feature API can now query different resolutions of the data grid.

## 0.4.0 (2023-03-02)

Added Geocoding API covering Switzerland.

## 0.3.0 (2023-02-01)

Exposed grid_size in aggregation API.

## 0.2.0 (2023-01-17)

Added Aggregation API.

## 0.1.0 (2022-07-27)

First release of the package exposing the Feature API.
