FINANCIAL = [
    'Accounting and tax',
    'Insurance',
    'Mergers and acquisitions',
    'Opening bank accounts',
    'Raising capital',
    'Regulatory support',
]

MANAGEMENT_CONSULTING = [
    'Business development',
    'Commercial and pricing strategy',
    'Product safety regulation and compliance',
    'Risk consultation',
    'Strategy and long-term planning',
    'Workforce development',
]

HUMAN_RESOURCES = [
    'Employment and talent research',
    'Payroll',
    'Salary benchmarking and employee benefits',
    'Sourcing and hiring',
    'Staff management and progression',
    'Staff onboarding',
    'Succession planning',
]

LEGAL = [
    'Company incorporation',
    'Data protection and information assurance',
    'Employment',
    'Immigration',
    'Intellectual property',
    'Land use planning',
]

PUBLICITY = [
    'Advertising',
    'Branding',
    'Marketing',
    'Public affairs',
    'Public relations',
    'Social media',
    'Translation services',
]

BUSINESS_SUPPORT = [
    'Business relocation',
    'Facilities (such as WiFI or electricity)',
    'Planning consultants',
    'Staff and family relocation',
]
