"""
Factorama Python bindings

A Python interface to the Factorama C++ factor graph optimization library.
"""

from ._factorama import *

__version__ = "1.0.0"