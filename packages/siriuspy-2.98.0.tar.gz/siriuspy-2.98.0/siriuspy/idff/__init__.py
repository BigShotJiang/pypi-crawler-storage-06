"""High Level ID Feedforward subpackage."""

from .config import IDFFConfig
