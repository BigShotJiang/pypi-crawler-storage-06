"""Magnet subpackage."""
