"""Naming System subpackge."""

from .implementation import *

del implementation
