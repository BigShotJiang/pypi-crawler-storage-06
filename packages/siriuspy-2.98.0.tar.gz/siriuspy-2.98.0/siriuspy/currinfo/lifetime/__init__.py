"""CurrentInfo-Lifetime subpackage."""

from .main import SILifetimeApp
