"""Linac Diag subpackage."""
