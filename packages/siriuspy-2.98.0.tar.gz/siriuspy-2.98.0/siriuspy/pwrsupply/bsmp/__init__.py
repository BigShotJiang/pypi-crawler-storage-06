"""Subpackage with PS-specific BSMP objects."""
