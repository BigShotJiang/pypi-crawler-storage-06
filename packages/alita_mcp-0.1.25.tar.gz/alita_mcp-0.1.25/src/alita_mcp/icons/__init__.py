# Icons package for Alita MCP Client
# This file makes the icons directory a Python package so that
# the PNG files can be accessed as package resources when bundled.
