# Import the submodules with a local app to register them to the main app
import jobflow_remote.cli.admin
import jobflow_remote.cli.backup
import jobflow_remote.cli.batch
import jobflow_remote.cli.execution
import jobflow_remote.cli.flow
import jobflow_remote.cli.gui
import jobflow_remote.cli.job
import jobflow_remote.cli.project
import jobflow_remote.cli.runner
from jobflow_remote import SETTINGS
from jobflow_remote.cli import plugin
from jobflow_remote.cli.jf import app

if SETTINGS.cli_load_plugins:
    plugin.load_plugins()
