from importlib import metadata

__version__ = metadata.version("alexander-nikitin-thenvoi-plantstore-python-sdk")
