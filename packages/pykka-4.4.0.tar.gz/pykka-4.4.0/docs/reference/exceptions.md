# Exceptions

::: pykka.ActorDeadError

::: pykka.Timeout
