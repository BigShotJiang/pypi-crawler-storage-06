"""
Command line interfaces for nokta-ai
"""