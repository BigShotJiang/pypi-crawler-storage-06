"""
Gauth Application
=================
Author : Ankit Kumar ( ankit.kumar05@telusdigital.com )
"""
