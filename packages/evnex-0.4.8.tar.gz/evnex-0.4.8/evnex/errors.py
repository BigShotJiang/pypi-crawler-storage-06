class NotAuthorizedException(ValueError):
    pass
