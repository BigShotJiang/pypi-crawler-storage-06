from .chat import GladosChat
from .sarcasm import detect_sarcasm
