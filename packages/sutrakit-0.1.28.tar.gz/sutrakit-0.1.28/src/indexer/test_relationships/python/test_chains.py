text = "  hello world  "
result = text.strip().upper().replace("WORLD", "PYTHON")

nums = {1, 2, 3}
result = nums.union({4, 5}).difference({2})
