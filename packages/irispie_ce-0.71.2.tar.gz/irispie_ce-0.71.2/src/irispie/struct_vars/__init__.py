"""
Structural vector autoregression (StructVAR) moduls
"""


from .main import *
from .main import __all__ as main_all


__all__ = (
    *main_all,
)

