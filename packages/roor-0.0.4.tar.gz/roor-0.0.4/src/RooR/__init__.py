# -*- coding: utf-8 -*-
"""
RooR: A project to analyze the behavior of AI models in post-quantum cybersecurity.
"""

__version__ = "0.0.4"
