# Copyright (c) Alibaba, Inc. and its affiliates.
class MegatronModelType:
    gpt = 'gpt'

    qwen2_vl = 'qwen2_vl'
    qwen2_5_vl = 'qwen2_5_vl'
    qwen2_5_omni = 'qwen2_5_omni'
    ovis2_5 = 'ovis2_5'

    internvl3 = 'internvl3'
    glm4_5v = 'glm4_5v'
