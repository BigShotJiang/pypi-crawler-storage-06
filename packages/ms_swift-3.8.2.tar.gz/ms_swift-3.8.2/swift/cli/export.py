# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.llm import export_main

if __name__ == '__main__':
    export_main()
