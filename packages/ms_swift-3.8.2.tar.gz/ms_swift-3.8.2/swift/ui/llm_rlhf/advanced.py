# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.advanced import Advanced


class RLHFAdvanced(Advanced):

    group = 'llm_rlhf'
