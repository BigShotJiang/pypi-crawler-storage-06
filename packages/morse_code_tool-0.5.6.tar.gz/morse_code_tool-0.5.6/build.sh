#!/bin/sh

python3 -m build