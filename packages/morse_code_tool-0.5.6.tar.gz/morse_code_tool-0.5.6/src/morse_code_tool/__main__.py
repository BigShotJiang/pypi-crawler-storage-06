from morse_code_tool.morse import main
if __name__ == "__main__":
    main()