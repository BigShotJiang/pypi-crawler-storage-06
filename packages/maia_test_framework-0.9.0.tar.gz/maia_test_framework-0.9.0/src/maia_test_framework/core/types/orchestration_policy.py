from enum import Enum

class OrchestrationPolicy(Enum):
    IGNORE_MESSAGE = "ignore_message"
    ORCHESTRATION_AGENT = "orchestration_agent"
