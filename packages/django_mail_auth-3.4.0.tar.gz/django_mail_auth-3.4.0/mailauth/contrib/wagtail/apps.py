from django.apps import AppConfig


class MailAuthWagtail(AppConfig):
    name = "mailauth.contrib.wagtail"
    label = "mailauth_wagtail"
