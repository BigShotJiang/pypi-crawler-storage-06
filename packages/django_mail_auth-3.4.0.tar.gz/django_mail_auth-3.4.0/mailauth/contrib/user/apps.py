from django.apps import AppConfig


class AuthConfig(AppConfig):
    name = "mailauth.contrib.user"
    label = "mailauth_user"
