from django.apps import AppConfig


class MailAuthAdmin(AppConfig):
    name = "mailauth.contrib.admin"
    label = "mailauth_admin"
