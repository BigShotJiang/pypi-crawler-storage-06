# dbt MCP

This UI enables easier configuration of dbt MCP. Check out `package.json` and `Taskfile.yml` for usage.
