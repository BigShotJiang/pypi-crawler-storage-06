# mtv4d

A 4d data sdk.

- define a 4d data type and transform to frame-wise info.
- 4d data utils