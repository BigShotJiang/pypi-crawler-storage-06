"""Cog content generation tool.
http://nedbatchelder.com/code/cog

Copyright 2004-2024, Ned Batchelder.
"""

from .cogapp import Cog as Cog, CogUsageError as CogUsageError, main as main
