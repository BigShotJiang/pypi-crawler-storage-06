The source of the old Python Success Story about cog:
https://www.python.org/about/success/cog/
