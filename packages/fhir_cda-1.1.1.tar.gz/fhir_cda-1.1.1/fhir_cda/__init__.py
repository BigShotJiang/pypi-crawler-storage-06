from .core import Annotator

__title__ = "fhir_cda"
__version__ = "1.1.1"
__author__ = "Linkun Gao"
__license__ = "Apache-2.0"
__copyright__ = "Copyright 2024 ABI"

# Version synonym
VERSION = __version__