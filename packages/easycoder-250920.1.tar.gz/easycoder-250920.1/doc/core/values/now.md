# now

## Syntax:
`now`

## Examples:
`print now`

## Description:
Returns a numeric value comprising the current timestamp; the number of milliseconds since January 1, 1970.

Next: [position](position.md)  
Prev: [newline](newline.md)

[Back](../../README.md)
