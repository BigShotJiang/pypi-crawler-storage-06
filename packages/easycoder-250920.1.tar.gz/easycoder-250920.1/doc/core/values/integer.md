# integer

## Syntax:
`integer {variable}`

## Examples:
``print integer `12345` ``

## Description:
Converts the text value provided into an integer.

Next: [index](index.md)  
Prev: [json](json.md)

[Back](../../README.md)
