# today

## Syntax:
`today`

## Examples:
`print today`

## Description:
Returns a numeric value comprising the timestamp of midnight at the start of the current day. See also [now](now.md).

Next: [trim](trim.md)  
Prev: [timestamp](timestamp.md)

[Back](../../README.md)
