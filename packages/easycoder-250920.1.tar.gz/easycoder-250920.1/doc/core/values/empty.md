# empty

## Syntax:
`empty`

## Examples:
`put empty into MyString`

## Description:
Gets an empty string.

Next: [encode](encode.md)  
Prev: [elements](elements.md)

[Back](../../README.md)
