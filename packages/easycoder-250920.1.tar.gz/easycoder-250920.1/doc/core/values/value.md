# value

## Syntax:
`[the] value of {text}`

## Examples:
`print the value of TextValue`

## Description:
Returns the numeric value of the supplied data text item.

Next: [tab](tab.md)  
Prev: [sin](sin.md)

[Back](../../README.md)
