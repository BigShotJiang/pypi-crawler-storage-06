# return

## Syntax:
`return`
## Examples:
`return`

## Description:
Return from a subroutine. See [gosub](gosub.md).

Next: [run](run.md)  
Prev: [replace](replace.md)

[Back](../../README.md)
