# pop

## Syntax:
`pop {variable} from {stack}`
## Examples:
`pop SavedItem from DataStack`

## Description:
Pops the top value from the specified [stack](stack.md).

Next: [post](post.md)  
Prev: [open](open.md)

[Back](../../README.md)
