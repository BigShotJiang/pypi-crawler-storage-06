# save

## Syntax:
`save {value} to {filename}`

## Examples:
``save Data to `mydata.txt` ``  
`save Data to FileName`

## Description:
Saves data to a file. See also [load](load.md).

Next: [set](set.md)  
Prev: [run](run.md)

[Back](../../README.md)
