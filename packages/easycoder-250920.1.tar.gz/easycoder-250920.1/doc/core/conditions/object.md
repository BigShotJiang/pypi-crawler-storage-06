# object

## Syntax:
`{value} is [not] object`

## Examples:
`if Value is object stop`

## Description:
Tests if the value is an object. The inclusion of `[not]` negates the test.

Next: [odd](odd.md)  
Prev: [not](not.md)

[Back](../../README.md)
