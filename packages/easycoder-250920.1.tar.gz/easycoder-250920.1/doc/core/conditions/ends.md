# ends

## Syntax:
`{value} ends with {text}`

## Examples:
``if MyVariable ends with `#` stop` ``

## Description:
Tests if the given value ends with a given string.

Next: [even](even.md)  
Prev: [empty](empty.md)

[Back](../../README.md)
