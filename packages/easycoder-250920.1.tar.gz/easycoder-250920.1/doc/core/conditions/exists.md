# exists

## Syntax:
`{file path} exists`

## Examples:
`if MyFile exists stop`

## Description:
Tests if the named file exists.

Next: [greater](greater.md)  
Prev: [even](even.md)

[Back](../../README.md)
