#!/bin/python3

from easycoder import Program

Program('/home/graham/dev/easycoder/easycoder-py/test.ecs').start()
