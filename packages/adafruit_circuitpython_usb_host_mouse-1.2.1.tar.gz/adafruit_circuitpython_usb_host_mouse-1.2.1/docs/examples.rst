Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/usb_host_mouse_simpletest.py
    :caption: examples/usb_host_mouse_simpletest.py
    :linenos:
