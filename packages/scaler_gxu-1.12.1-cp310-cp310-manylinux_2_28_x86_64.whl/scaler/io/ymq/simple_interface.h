#pragma once

#include <future>
#include <memory>

#include "scaler/io/ymq/error.h"
#include "scaler/io/ymq/io_context.h"
#include "scaler/io/ymq/io_socket.h"

namespace scaler {
namespace ymq {

std::shared_ptr<IOSocket> syncCreateSocket(IOContext& context, IOSocketType type, std::string name);
void syncBindSocket(std::shared_ptr<IOSocket> socket, std::string address);
void syncConnectSocket(std::shared_ptr<IOSocket> socket, std::string address);

std::pair<Message, Error> syncRecvMessage(std::shared_ptr<IOSocket> socket);
std::expected<void, Error> syncSendMessage(std::shared_ptr<IOSocket> socket, Message message);

std::future<std::pair<Message, Error>> futureRecvMessage(std::shared_ptr<IOSocket> socket);
std::future<std::expected<void, Error>> futureSendMessage(std::shared_ptr<IOSocket> socket, Message message);

}  // namespace ymq
}  // namespace scaler
