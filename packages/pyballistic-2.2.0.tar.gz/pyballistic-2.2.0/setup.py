#!/usr/bin/env python

"""setup.py script for pyballistic library"""

from setuptools import setup

setup()
