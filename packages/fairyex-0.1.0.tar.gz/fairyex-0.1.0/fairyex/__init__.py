from .darktype import DarkSol
