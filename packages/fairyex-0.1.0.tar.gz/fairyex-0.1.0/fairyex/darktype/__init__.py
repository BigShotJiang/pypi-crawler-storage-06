from .darksys import DarkSys
from .darksol import DarkSol
