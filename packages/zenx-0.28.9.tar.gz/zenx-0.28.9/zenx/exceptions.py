
class DropItem(Exception):
    pass


class NoSessionAvailable(Exception):
    pass


class NoBlueprintAvailable(Exception):
    pass