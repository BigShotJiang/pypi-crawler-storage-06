from portion.portion import Portion


def main() -> None:
    Portion().run()


if __name__ == "__main__":
    main()
