"""SPS product ingestor"""

from functools import partial

# 3rd Party
import click
from pyiem.database import get_sqlalchemy_conn
from pyiem.nws.products.sps import parser
from pyiem.nws.ugc import UGCProvider

# Local
from pywwa import LOG, common
from pywwa.database import get_database, load_nwsli
from pywwa.ldm import bridge

NWSLI_DICT = {}


def real_process(ugc_dict, txn, raw):
    """Really process!"""
    if raw.find("$$") == -1:
        LOG.info("$$ was missing from this product")
        raw += "\r\r\n$$\r\r\n"
    prod = parser(
        raw,
        utcnow=common.utcnow(),
        ugc_provider=ugc_dict,
        nwsli_provider=NWSLI_DICT,
    )
    if common.dbwrite_enabled():
        prod.sql(txn)
    baseurl = common.SETTINGS.get("pywwa_product_url", "pywwa_product_url")
    jmsgs = prod.get_jabbers(baseurl)
    for mess, htmlmess, xtra in jmsgs:
        common.send_message(mess, htmlmess, xtra)
    if prod.warnings:
        common.email_error("\n\n".join(prod.warnings), prod.text)


@click.command(help=__doc__)
@common.init
def main(*args, **kwargs):
    """Go Main Go."""
    with get_sqlalchemy_conn("postgis") as conn:
        ugc_dict = UGCProvider(pgconn=conn)
    load_nwsli(NWSLI_DICT)
    func = partial(real_process, ugc_dict)
    bridge(func, dbpool=get_database("postgis"))
