"""Test spe_parser."""

# 3rd Party
import pytest
from pyiem.util import utc

# Local
import pywwa
from pywwa.testing import get_example_file
from pywwa.workflows import spe


@pytest.mark.parametrize("database", ["postgis"])
def test_processor(cursor):
    """Test basic parsing."""
    data = get_example_file("SPE.txt")
    pywwa.CTX["utcnow"] = utc(2011, 10, 31, 1, 16)
    spe.real_process(cursor, data)
