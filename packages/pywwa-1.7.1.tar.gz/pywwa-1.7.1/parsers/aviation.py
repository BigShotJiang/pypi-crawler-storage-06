"""Aviation Product Parser!"""

# Local
from pywwa.workflows.aviation import main

if __name__ == "__main__":
    # Go
    main()
