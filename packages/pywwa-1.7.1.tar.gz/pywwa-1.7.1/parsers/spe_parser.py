"""SPENES product ingestor"""

# Local
from pywwa.workflows.spe import main

if __name__ == "__main__":
    main()
