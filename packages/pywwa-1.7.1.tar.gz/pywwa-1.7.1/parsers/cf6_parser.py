"""Parse CF6 text products."""

# Local
from pywwa.workflows.cf6 import main

if __name__ == "__main__":
    # Do Stuff
    main()
