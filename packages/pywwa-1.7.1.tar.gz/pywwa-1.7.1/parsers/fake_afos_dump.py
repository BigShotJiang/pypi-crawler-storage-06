"""Dump some stuff without AFOS PILs"""

# Local
from pywwa.workflows.fake_afos_dump import main

if __name__ == "__main__":
    main()
