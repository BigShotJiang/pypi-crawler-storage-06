"""AFOS Dump."""

from pywwa.workflows.afos_dump import main

if __name__ == "__main__":
    main()
