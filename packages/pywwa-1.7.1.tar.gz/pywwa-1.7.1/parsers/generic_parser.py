"""Generic NWS Product Parser"""

# Local
from pywwa.workflows.generic import main

if __name__ == "__main__":
    main()
