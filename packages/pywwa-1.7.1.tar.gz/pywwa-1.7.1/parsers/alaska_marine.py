"""Alaska CWF/OFF Parser that generates Fake VTEC."""

# Local
from pywwa.workflows.alaska_marine import main

if __name__ == "__main__":
    # Go
    main()
