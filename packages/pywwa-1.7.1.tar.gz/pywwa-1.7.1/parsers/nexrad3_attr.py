"""Process and Archive the NEXRAD Level III NCR Attribute Table"""

# Local
from pywwa.workflows.nexrad3_attr import main

if __name__ == "__main__":
    main()
