"""
Chunk the MOS text data into easier to search values.
"""

# Local
from pywwa.workflows.split_mav import main

if __name__ == "__main__":
    main()
