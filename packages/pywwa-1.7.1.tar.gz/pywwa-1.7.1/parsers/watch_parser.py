"""SPC Watch Ingestor"""

# Local
from pywwa.workflows.watch import main

if __name__ == "__main__":
    main()
