"""ASOS Daily Summary Message Parser ingestor"""

# Local
from pywwa.workflows.dsm import main

if __name__ == "__main__":
    main()
