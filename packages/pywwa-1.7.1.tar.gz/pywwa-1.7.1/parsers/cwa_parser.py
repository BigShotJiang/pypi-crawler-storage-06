"""CWA Parser!"""

# Local
from pywwa.workflows.cwa import main

if __name__ == "__main__":
    # Go
    main()
