"""Parse FD text products."""

# Local
from pywwa.workflows.fd import main

if __name__ == "__main__":
    # Do Stuff
    main()
