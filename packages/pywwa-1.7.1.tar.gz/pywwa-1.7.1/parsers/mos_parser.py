"""MOS Data Ingestor, why not?"""

# Local
from pywwa.workflows.mos import main

if __name__ == "__main__":
    main()
