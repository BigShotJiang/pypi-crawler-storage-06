"""
Handle things that need emailed to me for my situational awareness.
"""

# Local
from pywwa.workflows.spammer import main

if __name__ == "__main__":
    main()
