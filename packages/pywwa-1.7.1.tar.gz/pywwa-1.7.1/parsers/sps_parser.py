"""SPS product ingestor"""

# Local
from pywwa.workflows.sps import main

if __name__ == "__main__":
    main()
