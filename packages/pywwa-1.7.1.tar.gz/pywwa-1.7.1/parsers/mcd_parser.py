"""
Support SPC's MCD product
Support WPC's FFG product
"""

# Local
from pywwa.workflows.mcd import main

if __name__ == "__main__":
    main()
