"""WPC Geo Products Parser!"""

# Local
from pywwa.workflows.ero import main

if __name__ == "__main__":
    main()
