"""XTEUS Parser!"""

# Local
from pywwa.workflows.xteus import main

if __name__ == "__main__":
    # Go
    main()
