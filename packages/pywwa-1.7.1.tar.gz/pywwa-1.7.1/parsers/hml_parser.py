"""HML parser!"""

# Local
from pywwa.workflows.hml import main

if __name__ == "__main__":
    main()
