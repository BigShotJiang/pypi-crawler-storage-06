"""SPC Geo Products Parser!"""

# Local
from pywwa.workflows.spc import main

if __name__ == "__main__":
    main()
