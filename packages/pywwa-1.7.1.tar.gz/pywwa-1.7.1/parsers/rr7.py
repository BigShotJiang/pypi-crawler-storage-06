"""Split RR7 products, for some reason!"""

# Local
from pywwa.workflows.rr7 import main

if __name__ == "__main__":
    main()
