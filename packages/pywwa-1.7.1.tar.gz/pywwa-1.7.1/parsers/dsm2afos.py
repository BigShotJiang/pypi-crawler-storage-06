"""Move DSM messages into the text database with the proper PIL."""

# Local
from pywwa.workflows.dsm2afos import main

if __name__ == "__main__":
    main()
