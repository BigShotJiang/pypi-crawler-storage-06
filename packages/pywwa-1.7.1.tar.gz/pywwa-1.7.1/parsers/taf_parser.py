"""NESDIS TAF Ingestor"""

# Local
from pywwa.workflows.taf import main

if __name__ == "__main__":
    main()
