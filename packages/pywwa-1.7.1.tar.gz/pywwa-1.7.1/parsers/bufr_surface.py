"""Process BUFR (^IS WMO header) data as it comes."""

# Local
from pywwa.workflows.bufr_surface import main

if __name__ == "__main__":
    main()
