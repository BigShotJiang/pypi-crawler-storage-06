"""G-AIRMET parser!"""

# Local
from pywwa.workflows.gairmet import main

if __name__ == "__main__":
    main()
