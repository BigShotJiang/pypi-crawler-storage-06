"""PIREP parser!"""

# Local
from pywwa.workflows.pirep import main

if __name__ == "__main__":
    main()
