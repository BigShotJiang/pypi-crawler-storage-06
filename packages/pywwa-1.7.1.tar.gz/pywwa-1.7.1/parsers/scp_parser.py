"""NESDIS SCP Ingestor"""

# Local
from pywwa.workflows.scp import main

if __name__ == "__main__":
    main()
