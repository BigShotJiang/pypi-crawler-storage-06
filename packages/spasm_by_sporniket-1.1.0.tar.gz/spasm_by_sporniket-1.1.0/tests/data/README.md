# Given data files

Files in this folder are expected to be used as _input_ for any test having such needs.

There is no recommended organization. It will start as a _little_ bunch of files, then, as the number of files grows, an organization WILL emerge to keep it sustainable.
