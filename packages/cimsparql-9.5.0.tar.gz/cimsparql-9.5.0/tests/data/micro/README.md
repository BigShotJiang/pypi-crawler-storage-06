# Model origin

Model taken from

MicroGrid/Type1_T1/CGMES_v2.4.15_MicroGridTestConfiguration_T1_Assembled_Complete_v2.zip
