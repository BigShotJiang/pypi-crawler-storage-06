"""
MultiSocks - A SOCKS proxy that aggregates multiple remote SOCKS proxies
"""

__version__ = "1.0.4"
