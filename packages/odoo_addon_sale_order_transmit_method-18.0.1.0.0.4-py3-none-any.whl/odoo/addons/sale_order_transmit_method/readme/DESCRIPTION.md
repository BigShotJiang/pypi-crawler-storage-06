Set transmit method (email, post, portal, ...) in sale order and
propagate it to invoices.
