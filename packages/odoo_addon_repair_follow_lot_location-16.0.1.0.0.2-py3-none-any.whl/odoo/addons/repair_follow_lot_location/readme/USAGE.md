1. Create a **Repair Order** and set the **Lot/Serial**
2. Check the box **Follow Lot Location**
3. As warehouse operations progress, do stock moves as usual
4. When the relevant moves are **Done**, the repair’s current location updates automatically
