In base module, the repair order current location is chosen manually by the user to
represent where the item to repair physically sits. When the product moves
between internal locations during the process, the field can become outdated.

This addon keeps the repair order location aligned with the *actual* internal
location of the linked lot/serial.