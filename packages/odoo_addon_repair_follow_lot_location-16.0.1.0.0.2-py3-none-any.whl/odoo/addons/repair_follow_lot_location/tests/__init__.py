from . import test_repair_follow_lot_location
