# thin alias (args still pass through)
from .diarizer.whisper_diar_wrapper import main as main

if __name__ == "__main__":
    main()
