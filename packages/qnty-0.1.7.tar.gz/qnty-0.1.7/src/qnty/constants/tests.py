# Test tolerances
TEST_PRECISION_TOLERANCE = 1e-6
"""Tolerance used in tests for validating calculated results."""

TEST_DIMENSION_TOLERANCE = 1e-10
"""Tolerance used in tests for dimensional signature comparisons."""
