from .impl.to_keyword import TOKeywordBase
from .impl.to_object import a


class TOKeyword(TOKeywordBase):
    keyword = a("")
    capacity = a("")
    motivation = a("")
    notes = a("")
