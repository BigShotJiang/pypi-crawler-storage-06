This module is a base for creating multi-steps wizards. It does nothing
by itself.
