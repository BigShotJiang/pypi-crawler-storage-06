def test_test():
    """
    Tests that testing works
    """
    assert True
