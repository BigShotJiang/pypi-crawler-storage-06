from .command import cmdline

cmdline()
