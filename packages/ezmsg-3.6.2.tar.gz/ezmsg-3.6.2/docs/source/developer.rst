Developer Info
==============

ezmsg developers will want to clone this repo locally then create an env with dependencies using `poetry install`.

Documentation
-------------

Documentation is built using Sphinx.

`poetry install --with docs`
`poetry run docs/make html`
