default_app_config = "salesman.checkout.apps.SalesmanCheckoutApp"
