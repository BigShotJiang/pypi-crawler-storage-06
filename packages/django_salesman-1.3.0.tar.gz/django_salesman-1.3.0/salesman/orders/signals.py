import django.dispatch

status_changed = django.dispatch.Signal()
