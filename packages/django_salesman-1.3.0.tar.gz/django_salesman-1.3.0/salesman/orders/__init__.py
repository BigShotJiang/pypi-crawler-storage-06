default_app_config = "salesman.orders.apps.SalesmanOrdersApp"
