default_app_config = "salesman.core.apps.SalesmanCoreApp"
