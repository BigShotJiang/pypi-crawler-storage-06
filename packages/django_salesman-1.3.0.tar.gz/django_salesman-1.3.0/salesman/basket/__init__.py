default_app_config = "salesman.basket.apps.SalesmanBasketApp"
