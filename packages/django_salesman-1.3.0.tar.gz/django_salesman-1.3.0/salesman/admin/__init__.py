default_app_config = "salesman.admin.apps.SalesmanAdminApp"
