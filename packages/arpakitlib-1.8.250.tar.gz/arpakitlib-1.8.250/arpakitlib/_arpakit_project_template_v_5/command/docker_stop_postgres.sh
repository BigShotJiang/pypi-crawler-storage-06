cd ..
source .env
sudo docker stop ${common_project_name}_postgres
