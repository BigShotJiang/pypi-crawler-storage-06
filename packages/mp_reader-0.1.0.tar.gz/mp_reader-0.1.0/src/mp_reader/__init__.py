"""
Memory profiler output reader module.

This module provides tools for loading and analyzing memory profiler output files.
"""