"""A tool to import Nginx logs into SQLite for easy querying."""

__version__ = "0.2.2"