__all__ = ("Interface",)


class Interface:
    pass
