# this module is for backward compatibility
from ..module_loader import ModuleFileLoader, ModuleLoader

__all__ = ("ModuleLoader", "ModuleFileLoader",)
