# this module is for backward compatibility
from ..scenario_result import AggregatedResult, ScenarioResult, ScenarioStatus

__all__ = ("ScenarioResult", "AggregatedResult", "ScenarioStatus",)
