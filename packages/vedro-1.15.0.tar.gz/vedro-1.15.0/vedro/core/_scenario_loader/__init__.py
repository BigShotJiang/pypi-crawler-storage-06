# this module is for backward compatibility
from ..scenario_loader import ScenarioFileLoader, ScenarioLoader

__all__ = ("ScenarioLoader", "ScenarioFileLoader",)
