# this module is for backward compatibility
from ..scenario_scheduler import MonotonicScenarioScheduler, ScenarioScheduler

__all__ = ("ScenarioScheduler", "MonotonicScenarioScheduler",)
