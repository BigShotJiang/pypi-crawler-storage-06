# this module is for backward compatibility
from ..config_loader import Config, ConfigFileLoader, ConfigLoader, ConfigType, Section

__all__ = ("Config", "Section", "ConfigType", "ConfigLoader", "ConfigFileLoader",)
