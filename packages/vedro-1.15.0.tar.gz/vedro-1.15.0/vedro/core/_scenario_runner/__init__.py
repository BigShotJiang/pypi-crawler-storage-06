# this module is for backward compatibility
from ..scenario_runner import MonotonicScenarioRunner, ScenarioRunner

__all__ = ("ScenarioRunner", "MonotonicScenarioRunner",)
