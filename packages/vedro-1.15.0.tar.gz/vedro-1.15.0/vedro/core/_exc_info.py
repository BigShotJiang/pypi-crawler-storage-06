# this module is for backward compatibility
from .exc_info import ExcInfo

__all__ = ("ExcInfo",)
