from ._version_command import VersionCommand

__all__ = ("VersionCommand",)
