# this module is for backward compatibility
from vedro.core.exc_info import TracebackFilter

__all__ = ("TracebackFilter",)
