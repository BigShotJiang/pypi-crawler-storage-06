# backward compatibility
from vedro.core.scenario_orderer import StableScenarioOrderer

__all__ = ("StableScenarioOrderer",)
