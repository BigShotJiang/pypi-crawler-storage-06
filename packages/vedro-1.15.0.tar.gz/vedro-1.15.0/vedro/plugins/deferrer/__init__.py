from ._deferrer import Deferrer, DeferrerPlugin, defer, defer_global

__all__ = ("Deferrer", "DeferrerPlugin", "defer", "defer_global",)
