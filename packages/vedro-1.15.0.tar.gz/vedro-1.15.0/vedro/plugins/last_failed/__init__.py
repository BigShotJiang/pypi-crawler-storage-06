from ._last_failed_plugin import LastFailed, LastFailedPlugin

__all__ = ("LastFailed", "LastFailedPlugin",)
