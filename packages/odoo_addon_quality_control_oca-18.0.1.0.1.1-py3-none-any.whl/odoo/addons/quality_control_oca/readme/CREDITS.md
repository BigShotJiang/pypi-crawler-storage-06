- Originally based on the old [nan_quality_control](https://github.com/NaN-tic/nan_quality_control) modules from
  NaN·tic.
