
class InstancesCapException(BaseException):

    def __init__(self):
        pass