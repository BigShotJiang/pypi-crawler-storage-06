_S = 0
_P = 1
_O = 2

FEDERATION_TAG_MARK = "_fed_"