_S = 0
_P = 1
_O = 2

POS_CLASSES = 0
POS_FEATURES_DIRECT = 1
POS_FEATURES_INVERSE = 2

_ONE_TO_MANY = "+"

RDF_TYPE_STR = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"