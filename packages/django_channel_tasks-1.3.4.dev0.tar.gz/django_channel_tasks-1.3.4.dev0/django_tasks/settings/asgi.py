from django_tasks.settings.base import *  # noqa


ROOT_URLCONF = 'django_tasks.asgi_url_conf'

ASGI_APPLICATION = 'django_tasks.routing.application'
