VERSION = (1, 1, '18')

__version__ = '.'.join(map(str, VERSION))


def version(): return __version__
