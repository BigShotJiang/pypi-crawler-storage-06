# bomiotconf.ini

---

### Identify Project Properties

- This controls whether the application is a plugin or project of bomiot
- If it is a project, you can use `bomiot market <project>` to download the project

```shell
[mode]
name = project
```