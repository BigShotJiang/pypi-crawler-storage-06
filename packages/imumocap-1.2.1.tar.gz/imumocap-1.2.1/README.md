[![Tags](https://img.shields.io/github/v/tag/xioTechnologies/IMU-Mocap.svg)](https://github.com/xioTechnologies/IMU-Mocap/tags/)
[![Build](https://img.shields.io/github/actions/workflow/status/xioTechnologies/IMU-Mocap/main.yml?branch=main)](https://github.com/xioTechnologies/IMU-Mocap/actions/workflows/main.yml)
[![Pypi](https://img.shields.io/pypi/v/imumocap.svg)](https://pypi.org/project/imumocap/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

# IMU-Mocap
