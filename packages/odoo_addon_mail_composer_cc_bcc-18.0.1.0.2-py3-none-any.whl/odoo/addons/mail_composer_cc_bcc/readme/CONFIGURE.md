In company form there are two fields to set default cc and bcc partners.

> ![res_company_form_default_cc_bcc](../static/img/res_company_form_default_cc_bcc.png)

In template form there are two fields to set cc and bcc emails.

> ![email_template_form_cc_bcc](../static/img/email_template_form_cc_bcc.png)
