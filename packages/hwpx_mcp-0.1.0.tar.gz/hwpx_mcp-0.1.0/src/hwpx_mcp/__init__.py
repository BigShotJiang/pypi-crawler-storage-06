"""python-hwpx 기반 Model Context Protocol 서버 패키지."""

__all__ = ["__version__"]

__version__ = "0.2.0"
