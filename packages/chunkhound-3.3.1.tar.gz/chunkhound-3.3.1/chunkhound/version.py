"""Single source of truth for ChunkHound version."""

__version__ = "3.3.1"
