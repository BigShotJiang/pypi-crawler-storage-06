::: harp.devices.rgbarray
