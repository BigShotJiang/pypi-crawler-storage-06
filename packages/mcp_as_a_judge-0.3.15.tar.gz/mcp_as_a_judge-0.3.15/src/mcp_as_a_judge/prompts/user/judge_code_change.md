Please review the following changes based on the unified Git diff below:

## User Requirements

{{ user_requirements }}

## File Path

{{ file_path }}

## Change Description

{{ change_description }}

## Proposed Changes (Unified Git Diff)

```
{{ code_change }}
```

## Previous Conversation History as JSON array
{{ conversation_history }}
