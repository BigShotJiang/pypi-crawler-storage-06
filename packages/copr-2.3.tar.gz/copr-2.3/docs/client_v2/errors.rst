.. warning::
    Client version 2 is obsolete, please use Client version 3 instead.


Error handling
==============

.. todo:: implement
