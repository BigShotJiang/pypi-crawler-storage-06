__all__ = ["hello"]

def hello():
    return "Hello from OneAngstrom!"
