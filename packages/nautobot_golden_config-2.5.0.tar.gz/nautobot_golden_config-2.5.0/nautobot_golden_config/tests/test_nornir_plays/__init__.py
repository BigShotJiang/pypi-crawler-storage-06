"""Unit tests for nautobot_golden_config nornir_plays."""
