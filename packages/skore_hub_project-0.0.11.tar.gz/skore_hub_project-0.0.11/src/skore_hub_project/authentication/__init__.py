"""Module to manage ``skore hub`` authentication."""
