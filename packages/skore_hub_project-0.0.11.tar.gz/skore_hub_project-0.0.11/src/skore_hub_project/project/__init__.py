"""Module definition of the ``skore`` hub project."""
