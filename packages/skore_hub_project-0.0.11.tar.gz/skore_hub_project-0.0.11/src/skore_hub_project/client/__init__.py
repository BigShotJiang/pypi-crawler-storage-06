"""Module implementing client to exchange with ``skore hub``."""
