# Needs to be re-written because wizard.multi.charts.accounts
# doesn't exist any more on v12
# from . import test_account_move_template
from . import test_account_move_template_options
