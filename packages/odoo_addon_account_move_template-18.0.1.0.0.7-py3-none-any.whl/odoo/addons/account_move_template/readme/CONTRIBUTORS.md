## Module Authors

- Davide Corio \<<davide.corio@agilebg.com>\>
- Lorenzo Battistini \<<lorenzo.battistini@agilebg.com>\>
- Paolo Chiara \<<p.chiara@isa.it>\>
- Franco Tampieri \<<franco.tampieri@agilebg.com>\>
- Alexis de Lattre \<<alexis.delattre@akretion.com>\> (full re-write for
  v12)

## Module Contributors

- Jalal ZAHID \<<j.zahid@auriumtechnologies.com>\> (port to v10)
- Alex Comba \<<alex.comba@agilebg.com>\> (Port to V8)
- Guewen Baconnier \<<guewen.baconnier@camptocamp.com>\>
- Raf Ven \<<raf.ven@dynapps.be>\> (port to v11)
- Jordi Ballester \<<jordi.ballester@forgeflow.com>\> (ForgeFlow)
- [Sygel](https://www.sygel.es):
  - Harald Panten \<<harald.panten@sygel.es>\>
  - Valentin Vinagre \<<valentin.vinagre@sygel.es>\>
  - Manuel Regidor \<<manuel.regidor@sygel.es>\>
- [Ecosoft](http://ecosoft.co.th):
  - Kitti U. \<<kittiu@ecosoft.co.th>\> (Add context overwrite)
- Abraham Anes \<<abrahamanes@gmail.com>\>
