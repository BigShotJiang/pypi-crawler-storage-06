# -*- coding: utf-8 -*-

from .handlers import LokiHandler
from .handlers import LokiQueueHandler

__all__ = ["LokiHandler", "LokiQueueHandler"]
__version__ = "0.3.1"
name = "logging_loki"
