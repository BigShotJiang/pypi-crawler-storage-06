# sage_setup: distribution = sagemath-rankwidth
