# Curso Fiap
A simple example library.
## Installation
```sh
pip install cursofiap
```
## Licença

MIT.
