# Changelog

## 0.1.1 - 2025-09-19
- Refine project documents (README.md and pyproject.toml).

## 0.1.0 - 2025-09-17
- First public release: HK toll computation, CLI, REST API server, adapter architecture, tests, and examples.
