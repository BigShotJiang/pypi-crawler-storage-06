.. include:: ../README.rst


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api
   testing
   changelog


====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
