from .collection.collection import Collection as Collection
from .rules.rule import Rule as Rule