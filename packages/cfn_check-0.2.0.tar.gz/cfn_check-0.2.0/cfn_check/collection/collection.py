class Collection:
    pass
