from ..types.barmerge import BarMerge

#
# Constants
#

gaps_off = BarMerge()
gaps_on = BarMerge()
lookahead_off = BarMerge()
lookahead_on = BarMerge()
