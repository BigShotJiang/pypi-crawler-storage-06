# cryoDRGN utility commands #

This folder contains the supporting commands that are installed as part of the cryoDRGN package, as well as any
associated auxiliary files.

See `cryodrgn.command_line` for how the contents of this folder are parsed as part of creating the cryoDRGN command
line interface upon installation of the package.

See also the `cryodrgn/commands/` folder for the main set of commands that are the other part of the cryoDRGN command
line interface.
