from .consumer import InternalConsumer as InternalConsumer
