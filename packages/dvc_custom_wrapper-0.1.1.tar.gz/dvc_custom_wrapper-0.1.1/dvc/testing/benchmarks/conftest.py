from .fixtures import *  # noqa: F403

pytest_plugins = ["dvc.testing.plugin"]
