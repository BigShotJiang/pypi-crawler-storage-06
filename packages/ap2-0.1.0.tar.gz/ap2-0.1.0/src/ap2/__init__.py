"""
A2A Store - A simple Python package
"""

__version__ = "0.1.0"
__author__ = "whillhill"
__email__ = "ooooofish@126.com"

from .hello import hello_world

__all__ = ["hello_world"]
