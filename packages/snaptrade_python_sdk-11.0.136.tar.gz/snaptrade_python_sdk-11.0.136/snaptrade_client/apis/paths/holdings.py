from snaptrade_client.paths.holdings.get import ApiForget


class Holdings(
    ApiForget,
):
    pass
