from snaptrade_client.paths.currencies.get import ApiForget


class Currencies(
    ApiForget,
):
    pass
