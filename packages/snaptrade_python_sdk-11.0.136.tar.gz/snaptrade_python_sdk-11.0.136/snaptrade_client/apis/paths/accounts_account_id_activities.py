from snaptrade_client.paths.accounts_account_id_activities.get import ApiForget


class AccountsAccountIdActivities(
    ApiForget,
):
    pass
