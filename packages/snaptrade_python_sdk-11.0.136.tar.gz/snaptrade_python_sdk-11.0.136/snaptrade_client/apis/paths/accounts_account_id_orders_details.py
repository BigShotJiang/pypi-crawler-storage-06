from snaptrade_client.paths.accounts_account_id_orders_details.post import ApiForpost


class AccountsAccountIdOrdersDetails(
    ApiForpost,
):
    pass
