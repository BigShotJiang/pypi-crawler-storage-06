from music_voicegen.music_voicegen import MusicVoiceGen

__version__ = "0.1.1"
