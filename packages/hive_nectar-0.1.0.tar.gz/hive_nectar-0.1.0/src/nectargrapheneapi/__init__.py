"""nectargrapheneapi."""

import sys

sys.modules[__name__] = __import__("nectarapi")
print("nectargrapheneapi is deprecated, use nectarapi instead!")
