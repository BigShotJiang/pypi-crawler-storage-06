from .jokes import get_joke, get_all_jokes, show_window
