_optima_vis_ - A visualization tool for neural network optimizers.
