..
    This file is part of Invenio.
    Copyright (C) 2015-2022 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

===================
 Invenio-Search-UI
===================

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-search-ui.svg
        :target: https://github.com/inveniosoftware/invenio-search-ui/blob/master/LICENSE

.. image:: https://github.com/inveniosoftware/invenio-search-ui/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-search-ui/actions

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-search-ui.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-search-ui

.. image:: https://img.shields.io/pypi/v/invenio-search-ui.svg
        :target: https://pypi.org/pypi/invenio-search-ui


UI for Invenio-Search.

Further documentation is available on
https://invenio-search-ui.readthedocs.io/
