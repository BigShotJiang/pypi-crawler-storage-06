
# rattail-harvest

Rattail is a retail software framework, released under the GNU General
Public License.

This package contains software interfaces for
[Harvest](https://www.getharvest.com/).

Please see the [Rattail Project](https://rattailproject.org/) for more
information.
