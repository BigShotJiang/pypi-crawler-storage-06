# -*- coding: utf-8; -*-

from importlib.metadata import version


__version__ = version('rattail-harvest')
