# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : __main__.py
# @Time     : 2023/11/16 17:26
from fastapix import main

if __name__ == '__main__':
    main()
