# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : __init__.py
# @Time     : 2023/11/16 16:37
__version__ = "0.12.0"

from uvicorn import run, main
