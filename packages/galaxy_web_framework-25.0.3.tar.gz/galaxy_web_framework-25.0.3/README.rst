
.. image:: https://badge.fury.io/py/galaxy-web-framework.svg
   :target: https://pypi.org/project/galaxy-web-framework/


Overview
--------

The Galaxy_ web framework.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
