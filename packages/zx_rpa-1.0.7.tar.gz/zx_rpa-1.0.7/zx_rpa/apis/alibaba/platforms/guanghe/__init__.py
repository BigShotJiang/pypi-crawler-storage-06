"""
光合平台封装
"""

from .client import GuangheClient

__all__ = ['GuangheClient']
