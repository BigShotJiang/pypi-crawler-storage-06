"""
DrissionPage通用工具封装
提供跨平台的浏览器自动化通用方法
"""

from .common_actions import CommonActions

__all__ = [
    'CommonActions',
]
