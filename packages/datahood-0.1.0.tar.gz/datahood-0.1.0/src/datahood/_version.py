"""Package version information for datahood.

This small module provides `__version__` so `datahood.__init__` can expose it
without importing build-time metadata.
"""

__version__ = "0.1.0"
