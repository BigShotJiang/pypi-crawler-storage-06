# SPDX-FileCopyrightText: 2025-present Maikel Mardjan <mike@bm-support.org>
#
# SPDX-License-Identifier: GPL-3.0-or-later
from . __about__ import __version__