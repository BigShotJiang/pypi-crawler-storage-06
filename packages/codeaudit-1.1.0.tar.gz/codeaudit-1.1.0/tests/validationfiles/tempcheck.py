import tempfile

temp_filename = tempfile.mktemp()
