""" Imputations for cross-sectional and time-series data.  """

__all__ = ["cs", "ts"]
