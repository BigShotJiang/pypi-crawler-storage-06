""" Missing data approaches that delete values.  """

from .complete_case import complete_case

__all__ = ["complete_case"]
