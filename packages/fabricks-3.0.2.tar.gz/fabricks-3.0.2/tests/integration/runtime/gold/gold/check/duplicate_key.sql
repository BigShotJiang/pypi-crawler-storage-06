select 1 as __key, 1 as id
union all
select 1 as __key, 2 as id
