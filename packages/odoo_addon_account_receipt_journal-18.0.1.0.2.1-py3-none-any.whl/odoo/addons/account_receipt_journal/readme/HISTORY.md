This module partially comes from module l10n_it_corrispettivi of
<https://github.com/OCA/l10n-italy> version 12.
