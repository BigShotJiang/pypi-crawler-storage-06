from packaging.version import Version

ENVD_VERSION_RECURSIVE_WATCH = Version("0.1.4")
