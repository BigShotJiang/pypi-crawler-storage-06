from ordeq_faiss.index import FaissIndex

__all__ = ("FaissIndex",)
