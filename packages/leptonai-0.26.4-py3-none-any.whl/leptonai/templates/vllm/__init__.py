# flake8: noqa
"""
vLLM implementation is actually in the first-class leptonai/photon/vllm folder.
"""

from leptonai.photon.vllm import vLLMPhoton as vLLM
