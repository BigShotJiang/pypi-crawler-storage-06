from .vllm import register_vllm_photon, vLLMPhoton  # noqa: F401


register_vllm_photon()
