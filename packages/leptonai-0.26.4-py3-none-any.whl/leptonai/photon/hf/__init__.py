from .hf import register_hf_photon


register_hf_photon()
