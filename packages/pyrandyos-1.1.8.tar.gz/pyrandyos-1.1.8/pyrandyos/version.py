# from importlib.metadata import version as metadata_version

# __version__ = metadata_version(__package__ or __name__)
__version__ = '1.1.8'
