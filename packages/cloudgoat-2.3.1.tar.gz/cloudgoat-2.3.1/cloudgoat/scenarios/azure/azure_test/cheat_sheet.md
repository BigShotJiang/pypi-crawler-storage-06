# [SCENARIO NAME] Walkthrough

## Summary

POC Azure Environment 

## Detailed Walkthrough

No walkthrough, this scenario is a POC for cloudgoat create on azure.
