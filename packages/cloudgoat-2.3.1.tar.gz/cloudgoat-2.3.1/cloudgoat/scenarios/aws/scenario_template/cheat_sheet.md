# [SCENARIO NAME] Walkthrough

## Summary

In this scenario, you are provided with.... You need to enumerate... Then, use the ... Finally, do this to get the final flag. 

## Detailed Walkthrough

The purpose of CloudGoat is to help people learn AWS Pentesting. Provide a detailed walkthrough for the scenario with this goal in mind. A good example to refer to is the walkthrough for the [SNS Secrets scenario](https://github.com/RhinoSecurityLabs/cloudgoat/blob/master/scenarios/sns_secrets/cheat_sheet.md)
