from local_tuya.contrib.config import FullDeviceConfig
