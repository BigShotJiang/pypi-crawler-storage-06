#!/usr/bin/env python3
"""
BUCT客户端演示
展示新的BUCTClient类的使用方法
"""

from buct_course import BUCTClient

client = BUCTClient()
client.run_interactive()