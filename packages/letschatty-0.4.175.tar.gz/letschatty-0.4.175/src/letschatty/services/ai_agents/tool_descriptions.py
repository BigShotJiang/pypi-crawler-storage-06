class ToolDescriptions:
    @staticmethod
    def assign_chat_to_ai_agent_itself() -> str:
        return