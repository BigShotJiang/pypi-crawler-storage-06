from enum import StrEnum

class DeletionType(StrEnum):
    LOGICAL = "logical"
    PHYSICAL = "physical"
