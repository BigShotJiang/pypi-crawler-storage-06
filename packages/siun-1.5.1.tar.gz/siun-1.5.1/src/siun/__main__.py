import sys

import siun

sys.exit(siun.main())
