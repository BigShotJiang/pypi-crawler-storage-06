"""SQLGuardian."""

__all__ = ["make_greeting"]

from ._sqlguardian import make_greeting
