"""MCP Server for Blarify Tools."""

from .server import main

__all__ = ["main"]