"""Blarify CLI module for command-line operations."""

__version__ = "1.0.0"