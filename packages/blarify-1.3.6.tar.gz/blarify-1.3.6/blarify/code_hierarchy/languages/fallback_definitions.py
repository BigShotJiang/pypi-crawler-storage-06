from .language_definitions import LanguageDefinitions


class FallbackDefinitions(LanguageDefinitions):
    def __init__(self) -> None:
        super().__init__()
