# time uv run arxiv2md https://arxiv.org/pdf/2105.04090 -d test/musemorphose -o test/musemorphose/output.md
# time uv run arxiv2md https://arxiv.org/pdf/2006.11239 -d test/ddpm -o test/ddpm/output.md
# time uv run arxiv2md https://arxiv.org/pdf/1911.00536 -d test/dialogpt -o test/dialogpt/output.md
# time uv run arxiv2md https://arxiv.org/pdf/1512.03385 -d test/resnet -o test/resnet/output.md
# time uv run arxiv2md https://arxiv.org/abs/2307.08621 -d test/retnet -o test/retnet/output.md
# time uv run arxiv2md https://arxiv.org/abs/2211.00895 -d test/pop2piano -o test/pop2piano/output.md
# time uv run arxiv2md https://arxiv.org/abs/2408.01551 -d test/picogen2 -o test/picogen2/output.md
# time uv run arxiv2md https://arxiv.org/pdf/2111.03017 -d test/mt3 -o test/mt3/output.md
# time uv run arxiv2md https://arxiv.org/pdf/2308.15930 -d test/llasm -o test/llasm/output.md
time uv run arxiv2md https://arxiv.org/abs/2105.14103 -d test/aft -o test/aft/output.md
time uv run arxiv2md https://arxiv.org/pdf/2002.05202 -d test/glu -o test/glu/output.md
time uv run arxiv2md https://arxiv.org/abs/1312.6114 -d test/vae -o test/vae/output.md
time uv run arxiv2md https://arxiv.org/pdf/1411.1784 -d test/cgan -o test/cgan/output.md
time uv run arxiv2md https://arxiv.org/pdf/1511.06434 -d test/dcgan -o test/dcgan/output.md
time uv run arxiv2md https://arxiv.org/pdf/1611.07004 -d test/p2p -o test/p2p/output.md
time uv run arxiv2md https://arxiv.org/abs/1607.06450 -d test/layernorm -o test/layernorm/output.md
time uv run arxiv2md https://arxiv.org/abs/2106.03157 -d test/rubik -o test/rubik/output.md
time uv run arxiv2md https://arxiv.org/pdf/1810.12247 -d test/wav2midi2wav -o test/wav2midi2wav/output.md
time uv run arxiv2md https://arxiv.org/pdf/1710.11153 -d test/onsetsframes -o test/onsetsframes/output.md
time uv run arxiv2md https://arxiv.org/pdf/2010.01815 -d test/relative -o test/relative/output.md
time uv run arxiv2md https://arxiv.org/abs/2002.00212 -d test/remi -o test/remi/output.md
time uv run arxiv2md https://arxiv.org/pdf/2101.02402 -d test/cp -o test/cp/output.md
time uv run arxiv2md https://arxiv.org/pdf/1607.08022 -d test/instancenorm -o test/instancenorm/output.md
time uv run arxiv2md https://arxiv.org/abs/1809.04281 -d test/musictransformer -o test/musictransformer/output.md

time uv run arxiv2md https://arxiv.org/pdf/1803.08494 -d test/groupnorm -o test/groupnorm/output.md
