"""Module providing __init__ functionality."""
from matrice.utils import dependencies_check
dependencies_check(["requests", "Pillow", "aiohttp"])
