## [0.1.15] - 2025-9-25
### Target
- Refact project class
- Sandbox and Task support auto destroy
### Changed
- XGAToolManager, DyaSandboxHelper, .env


## [0.1.14] - 2025-8-30
### Target
- First complete version is merged 

