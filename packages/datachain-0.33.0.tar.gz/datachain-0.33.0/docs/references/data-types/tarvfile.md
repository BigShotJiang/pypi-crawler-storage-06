# TarVFile

::: datachain.lib.file.TarVFile
