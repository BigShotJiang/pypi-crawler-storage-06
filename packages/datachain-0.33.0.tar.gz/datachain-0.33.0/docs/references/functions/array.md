# Array Functions

Functions for working with arrays and lists, including operations like distance calculations and array manipulation.

::: datachain.func.array
