This directoy stores test data and cases.


Tests Structure:
```text
./tests/
├── analysers     # analyser tests
├── apps          # example application tests
├── conftest.py   # test configuration
├── data          # necessary data for tests
├── finder        # RosettaFinder tests
├── integration   # integration tests
├── node          # run node tests
├── outputs       # output files from tests
├── README.md     # this README
├── shortcuts     # command-line shortcut tests
└── utils         # utility tests
```