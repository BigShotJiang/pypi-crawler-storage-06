# GitHub Workflow for Python

The main workflow file is ".github/workflows/CI.yml". This performs linting, testing, and publishing for Python packages.
It can also be triggered manually on a specific branch.
