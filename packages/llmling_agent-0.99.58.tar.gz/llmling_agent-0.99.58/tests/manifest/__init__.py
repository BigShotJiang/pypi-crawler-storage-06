"""Manifest tests."""
