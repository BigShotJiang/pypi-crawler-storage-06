"""Example of AI-Human interaction using agent capabilities."""

TITLE = "Human Interaction"
ICON = "octicon:person-16"
