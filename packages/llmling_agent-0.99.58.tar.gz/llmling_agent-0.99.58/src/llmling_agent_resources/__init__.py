"""Resource loading functionality."""
