"""Human input provider."""

from llmling_agent_providers.human.provider import HumanProvider

__all__ = ["HumanProvider"]
