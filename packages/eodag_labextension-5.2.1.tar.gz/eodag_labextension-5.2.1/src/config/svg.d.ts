/**
 * Copyright 2022 CS GROUP - France, http://www.c-s.fr
 * All rights reserved
 */

declare module '*.svg' {
  const value: string;
  export default value;
}
