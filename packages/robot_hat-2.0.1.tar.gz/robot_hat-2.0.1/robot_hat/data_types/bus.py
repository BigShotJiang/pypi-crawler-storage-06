from typing import Union

from robot_hat.interfaces.smbus_abc import SMBusABC

BusType = Union[int, SMBusABC]
