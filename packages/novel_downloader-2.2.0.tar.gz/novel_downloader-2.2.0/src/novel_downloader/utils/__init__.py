#!/usr/bin/env python3
"""
novel_downloader.utils
----------------------

A collection of helper functions and classes.
"""
