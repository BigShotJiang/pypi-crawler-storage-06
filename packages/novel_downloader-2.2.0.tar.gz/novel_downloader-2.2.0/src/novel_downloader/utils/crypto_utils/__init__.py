#!/usr/bin/env python3
"""
novel_downloader.utils.crypto_utils
-----------------------------------

Generic cryptographic utilities
"""
