## v0.1.1rc44 (September 17, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc43...v0.1.1rc44

### Bug Fixes

- memory management issues with readers and writers (#700) (by @Nishchith Shetty in [af77ed9](https://github.com/atlanhq/application-sdk/commit/af77ed9))
