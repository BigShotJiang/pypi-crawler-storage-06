# aiorum
Async Python framework for building bots and automating HTTP requests from flarum-based sites. Inspired by aiogram and designed with a similar approach.
