#  -------------------------------------------------------------------------
#  pyCGNS.VAL - Python package for CFD General Notation System - VALidater
#  See license.txt file in the root directory of this Python module source
#  -------------------------------------------------------------------------
#
__version__ = 0
__release__ = 5
__vid__ = "%d.%d" % (__version__, __release__)
#
