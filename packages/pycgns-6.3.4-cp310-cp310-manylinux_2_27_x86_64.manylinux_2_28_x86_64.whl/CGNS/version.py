
version = "6.3.4"
__version__ = version
full_version = version

git_revision = "c2b98650e96708ec141aaeb10581834047860dd0"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
