class DependencyConflict(Exception):
    """ A substream is selected when its parent isn't """
