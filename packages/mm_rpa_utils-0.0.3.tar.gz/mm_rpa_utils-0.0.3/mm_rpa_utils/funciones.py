def saludar(nombre: str) -> str:
    return f"Hola, {nombre}!"


def sumar(a: int, b: int) -> int:
    return a + b
