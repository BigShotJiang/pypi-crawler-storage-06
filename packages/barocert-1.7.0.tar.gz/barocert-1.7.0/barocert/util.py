
class String:
    
    @staticmethod
    def isNullorEmpty(string):
        return ((string == None) or (string == ""))