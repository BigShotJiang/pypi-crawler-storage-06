import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__),
                             os.path.join('runners',
                                          os.path.join('resources',
                                                       'site-packages'))))
