<h1 align="center">
  <img width="240px" src="imgs/toolr.png" alt="ToolR - AI Generated Logo"/>
</h1>

{!README.md!lines=5-100}
