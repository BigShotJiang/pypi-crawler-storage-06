"""Tests for the Context class."""
