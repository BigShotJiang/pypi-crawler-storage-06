"""
Filters that can be applied to each frame we
read from a video or audio stream, directly
managed by ffmpeg (so optimized).
"""