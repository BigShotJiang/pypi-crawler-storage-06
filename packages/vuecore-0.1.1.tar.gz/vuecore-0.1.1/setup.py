from setuptools import setup

setup(
    zip_safe=False,
)
