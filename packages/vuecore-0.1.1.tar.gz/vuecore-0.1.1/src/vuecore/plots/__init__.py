# vuecore/plots/__init__.py
from .plot_factory import create_plot

__all__ = ["create_plot"]
