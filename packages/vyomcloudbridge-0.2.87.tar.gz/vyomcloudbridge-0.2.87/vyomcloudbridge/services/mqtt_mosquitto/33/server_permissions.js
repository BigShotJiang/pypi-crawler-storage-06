// Allow
// iot:Publish
// arn:aws:iot:ap-south-1:<aws_account_id>:topic/*

// Allow
// iot:Receive
// arn:aws:iot:ap-south-1:<aws_account_id>:topic/*

// Allow
// iot:PublishRetain
// arn:aws:iot:ap-south-1:<aws_account_id>:topic/*


// Allow
// iot:Subscribe
// arn:aws:iot:ap-south-1:<aws_account_id>:topicfilter/*


// Allow
// iot:Connect
// arn:aws:iot:ap-south-1:<aws_account_id>:client/hqProd-*
// Allow
// iot:Connect
// arn:aws:iot:ap-south-1:<aws_account_id>:client/hqTest-*
// Allow
// iot:Connect
// arn:aws:iot:ap-south-1:<aws_account_id>:client/hqDev-*