"""
Version information.
Version number according to semantic versioning (https://semver.org/)
"""

__version__ = "0.1.0"
