Contributing
============

.. include:: ../../README.md
   :start-after: ## Contributing
   :end-before: ## Citation
   :parser: myst_parser.sphinx_