"""Data models for the simple port checker package."""
