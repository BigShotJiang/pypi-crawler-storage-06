"""Utility functions for the simple port checker package."""
