# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
from . import test_stock_barcodes
from . import test_stock_barcodes_new_lot
from . import test_stock_barcodes_picking
