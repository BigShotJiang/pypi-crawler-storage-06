# The root of the entire project
from music_melodicdevice.music_melodicdevice import Device

__version__ = "0.2.1"
