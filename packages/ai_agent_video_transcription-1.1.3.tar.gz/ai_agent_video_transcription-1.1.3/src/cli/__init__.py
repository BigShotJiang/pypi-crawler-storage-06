"""
CLI module for video transcription agent
"""

from .interactive_cli import InteractiveCLI

__all__ = ['InteractiveCLI']