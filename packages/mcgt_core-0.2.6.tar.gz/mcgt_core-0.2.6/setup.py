from setuptools import setup

# Ne redéclare *aucune* métadonnée ici : elles viennent de pyproject.toml ([project]).
# Laisser setup() “nu” évite les conflits (ex. python_requires).
if __name__ == "__main__":
    setup()
