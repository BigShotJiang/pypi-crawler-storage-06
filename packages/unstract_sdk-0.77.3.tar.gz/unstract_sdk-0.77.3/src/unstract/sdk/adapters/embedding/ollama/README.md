# Unstract Ollama Embedding Adapter

For official documentation on Ollama embeddings, please refer to https://ollama.com/blog/embedding-models

To use the Ollama embedding adapter in the local setup, the preferred model needs to be run locally. 

Ollama can also be run using the docker setup. Please refer to https://ollama.com/blog/ollama-is-now-available-as-an-official-docker-image
