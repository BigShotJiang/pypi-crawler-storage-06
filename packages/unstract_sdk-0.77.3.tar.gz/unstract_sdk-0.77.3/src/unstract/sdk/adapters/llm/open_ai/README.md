# Unstract OpenAI LLM Adapter
