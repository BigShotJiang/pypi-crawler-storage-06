__version__ = "v0.77.3"

def get_sdk_version() -> str:
    """Returns the SDK version."""
    return __version__
