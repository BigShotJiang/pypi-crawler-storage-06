Open a sales order and add an amount into the "Force Invoiced Quantity"
field. Amount to invoice will be adjusted accordingly. This field is
optional so you can hide it if you don't need it.
