default_app_config = 'directory_healthcheck.apps.HealthCheckConfig'
