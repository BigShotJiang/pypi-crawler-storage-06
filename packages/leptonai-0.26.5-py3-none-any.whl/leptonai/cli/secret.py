"""
Secret is a module that provides a way to manage secrets on a workspace.
"""

import click

from rich.table import Table

from .util import (
    console,
    check,
    click_group,
)
from leptonai.config import LEPTON_RESERVED_ENV_NAMES
from ..api.v2.client import APIClient
from ..api.v1.types.common import LeptonVisibility
from ..api.v1.types.secret import SecretItem


@click_group()
def secret():
    """
    Manage secrets on the DGX Cloud Lepton.

    Secrets are like environmental variables, but the actual value never leaves
    the cloud environment. Secrets can be used to store sensitive information
    like API keys and passwords, which one does not want to accidentally leak
    into display output. Secret names starting with `LEPTON_` or `lepton_` are
    reserved for system use, and cannot be used by the user.

    The secret commands allow you to create, list, and remove secrets on the
    DGX Cloud Lepton.
    """
    pass


@secret.command()
@click.option("--name", "-n", help="Secret name", multiple=True)
@click.option("--value", "-v", help="Secret value", multiple=True)
@click.option(
    "--public-key",
    is_flag=True,
    help="Make the secret public (default is private).",
    default=False,
)
def create(name, value, public_key):
    """
    Creates secrets with the given name and value. The name and value can be
    specified multiple times to create multiple secrets, e.g.:
    `lep secret create -n SECRET1 -v VALUE1 -n SECRET2 -v VALUE2`
    """
    check(len(name), "No secret name given.")
    check(len(name) == len(value), "Number of names and values must be the same.")
    for n in name:
        check(
            n not in LEPTON_RESERVED_ENV_NAMES,
            "You have used a reserved secret name that is "
            f"used by Lepton internally: {n}. Please use a different name. "
            "Here is a list of all reserved environment variable names:\n"
            f"{LEPTON_RESERVED_ENV_NAMES}",
        )
    client = APIClient()
    existing_secrets = client.secret.list_all()

    if existing_secrets:
        existing_names = {s.name for s in existing_secrets}
        for n in name:
            check(
                n not in existing_names,
                f"Secret with name [red]{n}[/] already exists. Please use a"
                " different name or remove the existing secret with `lep secret"
                " remove` first.",
            )

    secret_item_list = []
    for cur_name, cur_value in zip(name, value):
        visibility = LeptonVisibility.PUBLIC if public_key else LeptonVisibility.PRIVATE
        secret_item_list.append(
            SecretItem(name=cur_name, value=cur_value, visibility=visibility)
        )

    client.secret.create(secret_item_list)
    console.print(
        f"Secret created successfully: [green]{'[/], [green]'.join(name)}[/]."
    )


@secret.command(name="list")
def list_command():
    """
    Lists all secrets in the current workspace. Note that the secret values are
    always hidden.
    """
    client = APIClient()
    secrets = client.secret.list_all()
    secrets.sort(key=lambda s: s.name)
    table = Table(title="Secrets", show_lines=True)
    table.add_column("Name")
    table.add_column("Tags")
    table.add_column("Owner")
    table.add_column("Visibility")
    for s in secrets:
        tags = ",".join(s.tags) if s.tags else ""
        owner = s.owner or ""
        visibility = s.visibility.value if getattr(s, "visibility", None) else ""
        table.add_row(s.name, tags, owner, visibility)
    console.print(table)


@secret.command()
@click.option("--name", "-n", help="Secret name", required=True)
def remove(name):
    """
    Removes the secret with the given name.
    """
    client = APIClient()
    existing_secrets = client.secret.list_all()
    existing_names = {s.name for s in existing_secrets}
    if not existing_secrets or name not in existing_names:
        console.print(f"[yellow]⚠ Secret [bold]{name}[/] does not exist.[/]")
        return

    client.secret.delete(name)
    console.print(f"Secret [green]{name}[/] deleted successfully.")


def add_command(cli_group):
    cli_group.add_command(secret)
