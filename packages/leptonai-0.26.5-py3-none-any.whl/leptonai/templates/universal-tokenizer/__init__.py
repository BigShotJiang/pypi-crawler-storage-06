# flakes8: noqa
"""
The universal tokenizer photon is available on the Lepton AI platform. This is a stub to store the README file for the photon.
"""

_photon_name = "universal_tokenizer"
