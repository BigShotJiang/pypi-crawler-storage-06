Extensible Reddit admin bot
