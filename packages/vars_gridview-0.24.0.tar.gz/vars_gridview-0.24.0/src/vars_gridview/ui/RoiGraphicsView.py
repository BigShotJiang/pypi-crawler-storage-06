from PyQt6.QtWidgets import QGraphicsView


class RoiGraphicsView(QGraphicsView):
    pass
