=====
Usage
=====

To use roman_snpit_utils in a project::

    import snpit_utils

Usage of the class is documented in the :ref:`API documentation<api>`.
