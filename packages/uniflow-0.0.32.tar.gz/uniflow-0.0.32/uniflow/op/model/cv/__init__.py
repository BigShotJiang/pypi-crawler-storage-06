"""Computer Vision (CV) Model Server."""

from uniflow.op.model.cv.model_server import *  # noqa: F401, F403
