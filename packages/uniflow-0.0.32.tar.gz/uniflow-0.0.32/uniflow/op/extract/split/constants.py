""" Splitter Constants """

PARAGRAPH_SPLITTER = "ParagraphSplitter"
MARKDOWN_HEADER_SPLITTER = "MarkdownHeaderSplitter"
RECURSIVE_CHARACTER_SPLITTER = "RecursiveCharacterSplitter"
