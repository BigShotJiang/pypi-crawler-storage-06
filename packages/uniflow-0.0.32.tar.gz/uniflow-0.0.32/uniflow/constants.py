"""Flow constants."""

ROOT_NAME = "root"
OUTPUT_NAME = "output"

# Flow Types
EXTRACT = "extract"
TRANSFORM = "transform"
RATER = "rater"
