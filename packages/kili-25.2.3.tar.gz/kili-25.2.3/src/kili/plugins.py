"""Develop Plugins for Kili."""

from kili.services.plugins.model import PluginCore

__all__ = ["PluginCore"]
