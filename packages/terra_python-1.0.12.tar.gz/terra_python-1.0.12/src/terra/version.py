from importlib import metadata

__version__ = metadata.version("terra-python")
