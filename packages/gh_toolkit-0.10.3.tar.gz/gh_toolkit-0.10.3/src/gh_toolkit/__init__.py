"""GitHub Toolkit - Repository portfolio management and presentation toolkit."""

__version__ = "0.9.0"
__author__ = "Michael Borck"
__email__ = "michael.borck@curtin.edu.au"
