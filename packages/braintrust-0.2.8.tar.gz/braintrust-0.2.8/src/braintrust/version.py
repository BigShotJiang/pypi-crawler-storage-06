VERSION = "0.2.8"

# this will be templated during the build
GIT_COMMIT = "3548dc0a4e272b21330ceefe9c8c63517941c034"
