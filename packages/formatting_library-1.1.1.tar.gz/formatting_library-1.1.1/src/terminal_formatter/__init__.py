from .core import (
    # Classes
    RGB,
    ColorFuncs,
    Terminal,
    TextFormatter,
    PrintOptions,
    Printer,
    ImprovedColors,
    ImageRenderer,
    CBuilder,
    
    # Aliases
    clear_screen,
    set_cursor_position,
    scroll_cursor,
    replace_current_line,
    replace_line,
    rainbow_text,
    align,
    substitute,
    slow_print,
    ccb_gen,
    rgb_fore,
    rgb_back,
    formatted,
    img_to_ascii,
    
    # Variables
    IMAGE_CHARACTER,
    RESET,
    RAINBOW_COLORS,
    COLORS,
)

__version__ = "1.1.1"
__author__ = "Kundaliel"
__email__ = "kundaliel.official@gmail.com"