# Package version
__version__ = "1.0.32"

# from . import main as NsgOrcFx
from .main import *
from . import main as NsgOrcFx
from .fatigue import FatigueAnalysis