from .qdrant_fast_embed import QdrantFastEmbedM

metadata = {
    "name": QdrantFastEmbedM.__name__,
    "version": "1.0.0",
    "adapter": QdrantFastEmbedM,
    "description": "QdrantFastEmbed embedding adapter",
    "is_active": False,
}
