from .palm import PaLM

metadata = {
    "name": PaLM.__name__,
    "version": "1.0.0",
    "adapter": PaLM,
    "description": "PaLM embedding adapter",
    "is_active": True,
}
