from .bedrock import Bedrock

metadata = {
    "name": Bedrock.__name__,
    "version": "1.0.0",
    "adapter": Bedrock,
    "description": "Bedrock embedding adapter",
    "is_active": True,
}
