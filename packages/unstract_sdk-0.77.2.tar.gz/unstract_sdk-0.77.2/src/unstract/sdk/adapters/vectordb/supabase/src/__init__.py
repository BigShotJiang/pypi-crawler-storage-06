from .supabase import Supabase

metadata = {
    "name": Supabase.__name__,
    "version": "1.0.0",
    "adapter": Supabase,
    "description": "Supabase VectorDB adapter",
    "is_active": False,
}
