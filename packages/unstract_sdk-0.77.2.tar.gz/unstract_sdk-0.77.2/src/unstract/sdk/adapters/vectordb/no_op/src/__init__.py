from unstract.sdk.adapters.vectordb.no_op.src.no_op_vectordb import NoOpVectorDB

metadata = {
    "name": NoOpVectorDB.__name__,
    "version": "1.0.0",
    "adapter": NoOpVectorDB,
    "description": "NoOpVectorDB",
    "is_active": True,
}
