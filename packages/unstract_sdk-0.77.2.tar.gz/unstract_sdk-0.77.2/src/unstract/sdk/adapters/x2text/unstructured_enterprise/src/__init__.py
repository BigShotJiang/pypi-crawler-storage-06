from .unstructured_enterprise import UnstructuredEnterprise

metadata = {
    "name": UnstructuredEnterprise.__name__,
    "version": "1.0.0",
    "adapter": UnstructuredEnterprise,
    "description": "UnstructuredIO X2Text adapter",
    "is_active": True,
}
