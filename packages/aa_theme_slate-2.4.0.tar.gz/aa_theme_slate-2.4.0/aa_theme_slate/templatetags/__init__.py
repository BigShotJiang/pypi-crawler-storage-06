"""
Initialize the template tags.

This module is used to define and register custom template tags
for use in Django templates.
"""
