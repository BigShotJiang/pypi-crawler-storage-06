"""
Init file for the Alliance Auth Slate theme
"""
