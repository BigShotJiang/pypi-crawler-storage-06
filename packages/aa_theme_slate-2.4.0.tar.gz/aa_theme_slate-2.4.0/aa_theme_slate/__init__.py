"""
Initialize the app
"""

__version__ = "2.4.0"
__title__ = 'Bootstrap Theme "Slate" for Alliance Auth'
