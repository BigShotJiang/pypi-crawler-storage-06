.. mdinclude:: ../README.md

Table of contents
=================

.. toctree::
   :maxdepth: 2
   :titlesonly:

   examples
   settings
   reference/index
   translations
   development