Examples
========

You can have a look to the BiSO example.
It contains all the plots used to produce the BiSO.
BiSO stands for "Bilan de la Science Ouverte" (Open Science Report).

.. toctree::
   :maxdepth: 1

   notebooks/biso
