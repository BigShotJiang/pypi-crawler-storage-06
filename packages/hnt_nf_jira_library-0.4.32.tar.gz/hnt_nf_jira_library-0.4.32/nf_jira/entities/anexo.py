from pydantic import BaseModel

class Anexo (BaseModel):
    path: str
    filename: str