from pydantic import BaseModel

class SinteseMiro(BaseModel):
    CFOP: str