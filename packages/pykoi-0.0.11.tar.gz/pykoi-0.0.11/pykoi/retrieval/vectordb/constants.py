from enum import Enum


class VectorDbName(Enum):
    CHROMA = "chroma"
    EPSILLA = "epsilla"
