from .pypuz import Puzzle
