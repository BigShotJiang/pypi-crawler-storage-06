class Mw2MhdMsProfileConvertor:
    def convert():
        raise NotImplementedError()
