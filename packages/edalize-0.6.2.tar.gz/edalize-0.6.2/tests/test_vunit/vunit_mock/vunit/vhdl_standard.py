from unittest.mock import MagicMock


class VHDL(MagicMock):
    @staticmethod
    def standard(std):
        pass
