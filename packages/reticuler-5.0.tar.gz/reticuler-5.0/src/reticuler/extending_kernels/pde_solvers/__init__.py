from .freefem import *
from .freefem_thinfingers import *
from .freefem_thickfingers import *
