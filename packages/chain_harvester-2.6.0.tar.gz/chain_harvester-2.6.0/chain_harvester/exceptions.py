class ChainException(Exception):
    pass
