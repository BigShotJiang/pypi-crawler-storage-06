def log(x):
    match(x):
        case 1:
            return 0
        
def exp(x, y):
    return x**y

def area(radius):
    match(radius):
        case 1:
            return pi
        
def sqrt(Number):
    return Number**(1/2)

pi = 3.14
log1 = log(1)
e = 2.71828
light = 299792458
h = 6.626*exp(10, -34)
G = 6.674*exp(10, -11)
Avogadro = 6.022*exp(10, 23)
circle_area_with_R1 = area(1)
echarge = 1.602*exp(10,-19)
i = "SquareRoot(-1)"
iSquare = -1
print(h)

