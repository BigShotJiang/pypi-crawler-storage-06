from constants import values as vals #as vals part is your choice
#then
print(f"{vals.pi} {vals.h} {vals.e}")