__all__ = ("TriangleMesh",)

from differt_core import _differt_core

TriangleMesh = _differt_core.geometry.triangle_mesh.TriangleMesh
