[← Back to API Documentation index](index.md)

# Accessing the spec
The canonical JSON schema is served under the docs path at `/docs/apispec.json`
and is configurable via `API_DOCS_SPEC_ROUTE`. The legacy top‑level path
`/openapi.json` (`API_SPEC_ROUTE`) now redirects to the docs JSON and will be
removed in a future release.

