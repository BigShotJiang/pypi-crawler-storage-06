[← Back to Installation index](index.md)

# Set up a virtual environment
Using a virtual environment keeps your project's dependencies tidy. Create and activate one:
```
$ python -m venv .venv
$ source .venv/bin/activate  # On Windows use: .venv\\Scripts\\activate
```

