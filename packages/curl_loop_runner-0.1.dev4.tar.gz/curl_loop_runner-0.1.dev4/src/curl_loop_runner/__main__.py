"""Entry point for running the package as a module."""

from .gui import main

if __name__ == "__main__":
    main()