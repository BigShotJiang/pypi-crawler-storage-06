# -*- coding: utf-8 -*-
"""jsonbourne.dev"""

from __future__ import annotations
