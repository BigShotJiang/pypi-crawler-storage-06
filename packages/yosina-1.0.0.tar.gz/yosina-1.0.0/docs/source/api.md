# API Reference

## High-level interface

```{eval-rst}
.. automodule:: yosina
   :members: TransliterationRecipe, make_transliterator
```

## Character object

```{eval-rst}
.. automodule:: yosina.chars
    :members:
```

