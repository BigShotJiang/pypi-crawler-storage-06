"""
Constants module for EGRC Core.

This module provides all constants used throughout the EGRC platform.
"""

from .constants import *
