#!/bin/env python3
# -*- coding:utf-8 -*-
"""
    定义celery异步函数的公共调用接口
    Add By :e4ting 2023-03-10 14:35:41
"""

from .cloud import Cloud,Linsener,Reporter
