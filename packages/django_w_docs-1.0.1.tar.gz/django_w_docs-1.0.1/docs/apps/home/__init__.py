"""Home & Detail pages"""
