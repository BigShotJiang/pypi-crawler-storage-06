"""Django Docs Content Management System"""
