"""CLI module for the Scout SDK."""

from .cli import main, ScoutCLI

__all__ = ["main", "ScoutCLI"]
