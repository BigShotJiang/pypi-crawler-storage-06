# coding=utf-8
from .._impl import (
    scout_assets_AssetService as AssetService,
)

__all__ = [
    'AssetService',
]

