from .discrete import diff
__al__ = ['diff']
