COMMAND_OPEN_PYPI_PAGE = "command/openPypiPage"
COMMAND_UPDATE_MD5SUM = "command/updateMD5sum"
COMMAND_START_PROFILING = "command/startProfiling"
COMMAND_STOP_PROFILING = "command/stopProfiling"
