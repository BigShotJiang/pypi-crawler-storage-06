__all__ = ()


URL_LENGTH_MAX = 2048
