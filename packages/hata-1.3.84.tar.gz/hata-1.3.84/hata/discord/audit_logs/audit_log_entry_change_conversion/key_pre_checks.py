__all__ = ()

from ...utils import is_id as key_pre_check_id
