"""Alerting system package."""
