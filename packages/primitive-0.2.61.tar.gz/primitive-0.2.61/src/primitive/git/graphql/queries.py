github_app_token_query = """
query githubAppToken{
    githubAppToken {
        token
    }
}
"""
