"""Embeddings module for lumen-anndata."""
