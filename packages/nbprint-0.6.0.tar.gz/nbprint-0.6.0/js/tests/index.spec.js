import { test, expect } from "@playwright/test";

test.describe("Basic tests", () => {
  test("exists", async ({ page }) => {});
});
