from .format import h1, h2, h3, h4, h5, hr, newpage, p, plot
from .image import image
from .ipython import *
