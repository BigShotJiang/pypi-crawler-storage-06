from nbprint.config.base import BaseModel


class _BaseCss(BaseModel):
    important: bool = False
