|pypi| |actions| |codecov| |downloads|

edc PHQ9
--------

Classes for PHQ9 (Patient Health Questionnaire)


.. |pypi| image:: https://img.shields.io/pypi/v/edc-phq9.svg
    :target: https://pypi.python.org/pypi/edc-phq9

.. |actions| image:: https://github.com/clinicedc/edc-phq9/actions/workflows/build.yml/badge.svg
  :target: https://github.com/clinicedc/edc-phq9/actions/workflows/build.yml

.. |codecov| image:: https://codecov.io/gh/clinicedc/edc-phq9/branch/develop/graph/badge.svg
  :target: https://codecov.io/gh/clinicedc/edc-phq9

.. |downloads| image:: https://pepy.tech/badge/edc-phq9
   :target: https://pepy.tech/project/edc-phq9
