"""Top-level of library designed to ease use of Selenium targetting Galaxy.

galaxy_selenium is purposes being designed to depend on Python selenium,
six, pyyaml, and optional pyvirtualdisplay but not galaxy-lib (or any of Galaxy
or Galaxy's test stuff) currently.
"""
