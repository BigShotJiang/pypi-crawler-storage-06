import glfw

type GLFWwindowPtr = glfw._GLFWwindow

__all__ = ["glfw", "GLFWwindowPtr"]
