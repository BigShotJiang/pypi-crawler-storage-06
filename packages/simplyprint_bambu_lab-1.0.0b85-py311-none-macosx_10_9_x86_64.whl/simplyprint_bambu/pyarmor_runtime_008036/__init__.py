# Pyarmor 9.0.8 (ci), 008036, 2025-09-24T19:41:39.300316
from .pyarmor_runtime import __pyarmor__
