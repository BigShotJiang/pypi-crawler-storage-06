# fusio
Input file conversions to popular file formats in fusion research
