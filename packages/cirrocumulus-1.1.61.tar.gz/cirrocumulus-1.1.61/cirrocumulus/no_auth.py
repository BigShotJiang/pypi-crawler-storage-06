class NoAuth:
    def auth(self):
        return {"email": ""}
