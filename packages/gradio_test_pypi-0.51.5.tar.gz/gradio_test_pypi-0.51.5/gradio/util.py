class Math:
    def add(self, a, b):
        return a + b
    def subtract(self, a, b):
        return a - b