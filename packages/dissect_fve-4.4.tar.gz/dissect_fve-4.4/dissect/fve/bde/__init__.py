from dissect.fve.bde.bde import BDE, is_bde_volume

__all__ = [
    "BDE",
    "is_bde_volume",
]
