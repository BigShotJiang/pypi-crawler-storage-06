from dissect.fve.exceptions import Error

__all__ = [
    "Error",
]
