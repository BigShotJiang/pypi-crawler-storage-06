class Error(Exception):
    pass


class InvalidHeaderError(Error):
    pass
