==========
User Guide
==========

The Inbox plugin provides many features to the mobile device.

From the users perspective, the Inbox plugin provides the user with task and message
notifications, and an list of performed activities.
