Installation
============

You can install Python CWT with pip:

.. code-block:: console

    $ pip install cwt
