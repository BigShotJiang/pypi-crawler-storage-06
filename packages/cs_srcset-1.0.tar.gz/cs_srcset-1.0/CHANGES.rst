Changelog
=========


1.0 (2025-09-24)
----------------

- Initial release.
  [codesyntax]
