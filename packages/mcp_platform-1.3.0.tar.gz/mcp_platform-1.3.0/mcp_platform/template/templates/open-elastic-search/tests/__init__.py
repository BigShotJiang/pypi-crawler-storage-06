"""
Test package for Elasticsearch MCP Server template.
"""
