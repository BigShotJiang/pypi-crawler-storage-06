"""
Elasticsearch MCP Server Template

This template provides integration with Elasticsearch using the official Elasticsearch MCP server.
"""

__version__ = "1.0.0"
