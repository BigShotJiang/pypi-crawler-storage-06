# Trino MCP Server Template Tests
