#!/bin/bash
# Print all the arguments as echo and finally run 'python server.py' without any arguments

echo "This is just a demo of how arguments are passed: $@"
python server.py
