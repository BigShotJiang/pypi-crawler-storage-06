"""
Test suite for PostgreSQL MCP Server Template.

This module contains comprehensive tests for the PostgreSQL MCP server
including configuration validation, tool functionality, and integration tests.
"""
