#!/usr/bin/env python3
"""
Test package initialization for Zendesk MCP Server tests.
"""

# This file makes the tests directory a Python package
# allowing for relative imports and proper test discovery

__version__ = "1.0.0"
