# BigQuery MCP Server Tests
"""
Test suite for the BigQuery MCP Server template.

This module provides comprehensive testing for all BigQuery MCP server functionality
including configuration, authentication, access controls, and query execution.
"""
