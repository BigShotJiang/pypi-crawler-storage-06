SERVER_REQUEST_TOTAL = "server_request_total"
RELY_SERVER_REQUEST = "rely_server_request"
SERVER_REQUEST_TIME = "server_request_time"
SERVER_REQUEST_TIME_MICROSECONDS = "server_request_time_microseconds"

SERVER_APPID_REQUEST_TIME = "server_appid_request_time"
RELY_SERVER_REQUEST_TIME = "rely_server_request_time"
SERVER_CONC = "server_conc"
RELY_SERVER_CONC = "rely_server_conc"


SERVER_REQUEST_DESC = "服务入口错误数"
RELY_SERVER_REQUEST_DESC = "服务出口错误数"
SERVER_REQUEST_TIME_DESC = "服务入口性能"
RELY_SERVER_REQUEST_TIME_DESC = "服务出口性能"
SERVER_CONC_DESC = "服务入口并发数"
RELY_SERVER_CONC_DESC = "服务出口并发数"
