from common.otlp.args.metric import OtlpMetricArgs
from common.otlp.args.sid import OtlpSidArgs
from common.otlp.args.trace import OtlpTraceArgs

global_otlp_metric_args = OtlpMetricArgs()
global_otlp_trace_args = OtlpTraceArgs()
global_otlp_sid_args = OtlpSidArgs()
