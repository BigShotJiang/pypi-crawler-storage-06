"""Real-time updates module."""

from .cdc_manager import CDCManager

__all__ = ['CDCManager']