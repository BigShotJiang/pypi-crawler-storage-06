"""
Environment Wrappers and Adapters.

This package contains various environment wrappers that modify or extend the behavior of
reinforcement learning environments for specific use cases.
"""
