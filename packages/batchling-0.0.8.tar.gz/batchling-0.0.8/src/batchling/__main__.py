from batchling.cli.main import app

app(prog_name="batchling")
