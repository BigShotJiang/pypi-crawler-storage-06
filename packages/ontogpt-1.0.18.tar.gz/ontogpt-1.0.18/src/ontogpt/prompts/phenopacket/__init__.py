from pathlib import Path

PHENOPACKET_PROMPT_DIR_PATH = Path(__file__).parent
DEFAULT_PHENOPACKET_PROMPT = PHENOPACKET_PROMPT_DIR_PATH / "phenopacket.jinja2"
