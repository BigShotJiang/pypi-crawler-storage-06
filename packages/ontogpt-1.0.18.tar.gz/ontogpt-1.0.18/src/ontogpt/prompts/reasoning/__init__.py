from pathlib import Path

REASONING_PROMPT_DIR_PATH = Path(__file__).parent
DEFAULT_REASONING_PROMPT = REASONING_PROMPT_DIR_PATH / "reasoning.jinja2"
