## ::: xmllib.LinkResource

    options:
        members_order: source
