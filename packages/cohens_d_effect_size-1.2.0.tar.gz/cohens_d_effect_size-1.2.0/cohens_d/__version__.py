"""Version information for cohens_d package."""

__version__ = "1.2.0"
__author__ = "Dawit L. Gulta"
__email__ = "dawit.lambebo@gmail.com"
__description__ = "A Python package for calculating Cohen's d effect size"