"""ASTODOJO: Intelligent TODO scanner for Python codebases."""

__version__ = "0.1.0"
__author__ = "Sean McDonald"
__email__ = ""

from .core import ASTODOJO

__all__ = ["ASTODOJO", "__version__", "__author__", "__email__"]
