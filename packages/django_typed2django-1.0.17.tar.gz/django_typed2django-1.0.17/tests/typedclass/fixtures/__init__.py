# Fixtures for typedclass tests
