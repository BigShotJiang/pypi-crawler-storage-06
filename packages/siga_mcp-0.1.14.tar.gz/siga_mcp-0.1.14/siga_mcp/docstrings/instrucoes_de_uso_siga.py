def docs() -> str:
    return """
    **IMPORTANTE**Antes de chamar outra função, chame esta para obter as instruções de uso do SIGA.
"""
