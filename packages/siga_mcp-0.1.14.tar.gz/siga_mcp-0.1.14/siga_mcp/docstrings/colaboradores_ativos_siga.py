def docs() -> str:
    return """Retorna a lista de colaboradores ativos."""
