def main():
    print("Hello from 2!")


if __name__ == "__main__":
    main()
