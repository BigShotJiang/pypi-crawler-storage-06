from greenlang.data.emission_factors import EmissionFactors

__all__ = ["EmissionFactors"]
