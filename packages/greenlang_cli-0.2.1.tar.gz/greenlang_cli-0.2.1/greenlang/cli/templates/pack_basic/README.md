# {{PACK_NAME}}

{{PACK_DESCRIPTION}}

## Quick Start

1. Install the pack:
   ```bash
   gl pack install {{PACK_NAME}}
   ```

2. Run the pipeline:
   ```bash
   gl run gl.yaml
   ```

## Documentation

See [CARD.md](CARD.md) for detailed documentation.

## License

MIT