"""
GreenLang Runtime - Execution engines
"""

from .executor import Executor

__all__ = ["Executor"]
