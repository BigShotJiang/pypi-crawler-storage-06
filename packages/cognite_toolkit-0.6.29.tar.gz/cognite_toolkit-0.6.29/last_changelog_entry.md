## cdf 

### Improved

- When running the `cdf purge space` command, the user will now get an
extra warning.

## templates

No changes.