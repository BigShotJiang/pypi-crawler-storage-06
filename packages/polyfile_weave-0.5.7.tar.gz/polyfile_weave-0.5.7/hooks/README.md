# Default Git Hooks for PolyFile Development

To enable these hooks, developers must run this after cloning the repo:
```bash
$ git config core.hooksPath ./hooks
```
