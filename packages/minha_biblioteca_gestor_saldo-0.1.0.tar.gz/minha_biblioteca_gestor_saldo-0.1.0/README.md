# Minha biblioteca

Esta Biblioteca foi criada durante a formação UFCD 10794

Oferece função para gestão de saldo.

# Instalação

pip install minha-biblioteca-gestor-saldo