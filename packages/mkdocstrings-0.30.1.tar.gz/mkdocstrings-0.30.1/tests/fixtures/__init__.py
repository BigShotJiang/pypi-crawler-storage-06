"""Some fixtures for tests."""
