"""Deprecated. Import from `mkdocstrings` directly."""

# YORE: Bump 1: Remove file.
