# Copyright (c) Fredrik Andersson, 2023
# All rights reserved

"""The digsim exception base"""


class DigsimException(Exception):
    """The digsim exception base class"""
