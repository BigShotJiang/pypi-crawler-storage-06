"""aipype: A modular AI agent framework with declarative pipeline-based task orchestration."""

__version__ = "0.1.0a1.post2"

# Core framework exports
from .framework.pipeline_agent import PipelineAgent, TaskExecutionPlan
from .framework.base_task import BaseTask
from .framework.task_result import (
    TaskResult,
    TaskStatus,
    wrap_legacy_result,
    unwrap_to_legacy,
)
from .framework.task_context import TaskContext
from .framework.task_dependencies import (
    TaskDependency,
    DependencyType,
    DependencyResolver,
    create_required_dependency,
    create_optional_dependency,
    extract_urls_from_results,
    combine_article_content,
    format_search_query,
)
from .framework.llm_task import LLMTask
from .framework.search_task import SearchTask
from .framework.conditional_task import (
    ConditionalTask,
    threshold_condition,
    contains_condition,
    list_size_condition,
    success_rate_condition,
    quality_gate_condition,
    log_action,
    increment_counter_action,
    set_flag_action,
)
from .framework.transform_task import (
    TransformTask,
    extract_field_from_list,
    combine_text_fields,
    filter_by_condition,
    aggregate_numeric_field,
    format_as_markdown_list,
)
from .framework.tools import (
    tool,
    ToolMetadata,
    ToolSchemaGenerator,
    search_with_content,
)
from .framework.tool_registry import ToolRegistry
from .framework.tool_executor import ToolExecutor

# Tasklib exports
from .framework.tasklib.web.batch_article_summarize_task import (
    BatchArticleSummarizeTask,
)
from .framework.tasklib.io.file_save_task import FileSaveTask
from .framework.tasklib.web.url_fetch_task import URLFetchTask
from .framework.tasklib.media.extract_audio_from_video_task import (
    ExtractAudioFromVideoTask,
)
from .framework.tasklib.media.audio_transcript_task import AudioTranscriptTask

# Utils exports
from .framework.utils.common import (
    setup_logger,
    timestamp,
    safe_dict_get,
    flatten_list,
    validate_required_fields,
)
from .framework.utils.base_searcher import SearchResult, SearchResponse, BaseSearcher
from .framework.utils.serper_searcher import SerperSearcher
from .framework.utils.url_fetcher import fetch_main_text, fetch_url, URLFetcher
from .framework.utils.display import print_header, print_message_box

__all__ = [
    # Core framework
    "PipelineAgent",
    "TaskExecutionPlan",
    "BaseTask",
    "TaskResult",
    "TaskStatus",
    "wrap_legacy_result",
    "unwrap_to_legacy",
    "TaskContext",
    "TaskDependency",
    "DependencyType",
    "DependencyResolver",
    "create_required_dependency",
    "create_optional_dependency",
    "extract_urls_from_results",
    "combine_article_content",
    "format_search_query",
    "LLMTask",
    "SearchTask",
    "ConditionalTask",
    "threshold_condition",
    "contains_condition",
    "list_size_condition",
    "success_rate_condition",
    "quality_gate_condition",
    "log_action",
    "increment_counter_action",
    "set_flag_action",
    "TransformTask",
    "extract_field_from_list",
    "combine_text_fields",
    "filter_by_condition",
    "aggregate_numeric_field",
    "format_as_markdown_list",
    # Tool system
    "tool",
    "ToolMetadata",
    "ToolSchemaGenerator",
    "search_with_content",
    "ToolRegistry",
    "ToolExecutor",
    # Tasklib
    "BatchArticleSummarizeTask",
    "FileSaveTask",
    "URLFetchTask",
    "ExtractAudioFromVideoTask",
    "AudioTranscriptTask",
    # Utils
    "setup_logger",
    "timestamp",
    "safe_dict_get",
    "flatten_list",
    "validate_required_fields",
    "SearchResult",
    "SearchResponse",
    "BaseSearcher",
    "SerperSearcher",
    "fetch_main_text",
    "fetch_url",
    "URLFetcher",
    "print_header",
    "print_message_box",
]
