## Sample {{num}}

| Input                | Output                |
|----------------------|-----------------------|
| <pre>{{input}}</pre> | <pre>{{output}}</pre> |