
Changelog
---------

V1.0.6: Oxford, 17 September 2025
+++++++++++++++++++++++++++++++++

- Created by Michele Cappellari.

