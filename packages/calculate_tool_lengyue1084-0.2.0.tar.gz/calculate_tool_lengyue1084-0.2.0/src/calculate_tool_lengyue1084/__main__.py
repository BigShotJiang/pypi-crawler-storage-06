from calculate_tool_lengyue1084 import main

main()