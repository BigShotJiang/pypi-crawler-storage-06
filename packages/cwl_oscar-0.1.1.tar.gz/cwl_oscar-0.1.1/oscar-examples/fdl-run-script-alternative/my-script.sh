#!/bin/bash

MY_MESSAGE="Hello from your environment variable"
echo "Message: $MY_MESSAGE"
