date

/app/cwl-oscar \
 --oscar-endpoint https://oscar-grnet.intertwin.fedcloud.eu \
 --oscar-username oscar

 sleep 20

 date
 