# backwards compatibility
from pie_core.utils.dictionary import flatten_dict_s as flatten_dict
from pie_core.utils.dictionary import list_of_dicts2dict_of_lists
