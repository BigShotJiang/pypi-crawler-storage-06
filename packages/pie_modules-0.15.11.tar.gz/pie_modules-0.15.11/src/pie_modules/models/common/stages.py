TRAINING = "train"
VALIDATION = "val"
TESTING = "test"
