"""Version information for DevKitX package."""

__version__ = "1.0.1"