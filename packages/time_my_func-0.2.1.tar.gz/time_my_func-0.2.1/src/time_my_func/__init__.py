from .decorator import set_enabled, timeit

__all__ = ["timeit", "set_enabled"]
__version__ = "0.1.0"
