# Frontend assets for streamlit-folium
