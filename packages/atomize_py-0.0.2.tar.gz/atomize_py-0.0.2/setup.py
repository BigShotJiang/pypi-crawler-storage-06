import setuptools

with open("readme.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="Atomize", 
    version="0.0.2",
    author="Atomize Developers",
    author_email="anatoly.melnikov@tomo.nsc.ru",
    description="A modular software for working with scientific devices and combining them into unified multifunctional setup",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Anatoly1010/Atomize",
    packages=setuptools.find_packages(),
    license="MIT",
    keywords=["automation", "measurement", "instrument control", "experimental script", "graph", "scientific instruments", "industrial instruments"],
    classifiers = [
    "Programming Language :: Python :: 3",
    "Intended Audience :: Science/Research",
    "License :: OSI Approved :: MIT License",
    "Operating System :: MacOS",
    "Operating System :: Microsoft :: Windows",
    "Operating System :: POSIX",
    "Operating System :: Unix",
    "Topic :: Scientific/Engineering",
    ],
    python_requires='>=3.9',
)