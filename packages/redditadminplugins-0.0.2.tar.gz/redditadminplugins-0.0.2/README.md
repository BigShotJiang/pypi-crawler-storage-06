Miscellaneous custom plugins for redditadmin bot.
