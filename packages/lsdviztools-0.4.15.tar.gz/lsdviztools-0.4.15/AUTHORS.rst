=======
Credits
=======

Development Lead
----------------

* Simon Marius Mudd <simon.m.mudd@ed.ac.uk>

Contributors
------------

* Fiona Clubb
* Boris Gailleton 
* Martin Hurst
* Declan Valters
