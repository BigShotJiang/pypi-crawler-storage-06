# Robot Soccer Kit

![Robots](/docs/imgs/cover-2022.jpg)

## Presentation

* [YouTube demonstration video](https://www.youtube.com/watch?v=4NFXbaom7YQ)
* [Documentation](https://robot-soccer-kit.github.io)

## License

<a rel="license" href="http://creativecommons.org/licenses/by-nc/2.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc/2.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc/2.0/">Creative Commons Attribution-NonCommercial 2.0 Generic License</a>.
