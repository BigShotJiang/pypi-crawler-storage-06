
const React = window.React;

// Provide the automatic‐JSX-runtime functions
export const jsx = React.createElement;
export const jsxs = React.createElement;
export const Fragment = React.Fragment;
