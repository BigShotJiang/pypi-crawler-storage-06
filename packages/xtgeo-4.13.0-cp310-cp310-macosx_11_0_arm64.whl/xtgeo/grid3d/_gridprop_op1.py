"""Various grid property operations"""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Literal, Optional, Tuple, Union

import numpy as np

import xtgeo
from xtgeo import _cxtgeo
from xtgeo.common import XTGeoDialog, null_logger
from xtgeo.grid3d import _gridprop_lowlevel as gl

xtg = XTGeoDialog()
logger = null_logger(__name__)

if TYPE_CHECKING:
    from xtgeo.grid3d import Grid, GridProperty
    from xtgeo.xyz import Polygons

_CoordOrValue = Union[float, int]
_XYCoordinate = Tuple[_CoordOrValue, _CoordOrValue]
_XYCoordList = List[List[List[_XYCoordinate]]]
_ValueList = List[List[_CoordOrValue]]
XYValueLists = Tuple[_XYCoordList, _ValueList]


def _validate_cast_range(values: np.ndarray, target_dtype: np.dtype) -> None:
    """Validate that values fit in target dtype range."""
    if np.issubdtype(target_dtype, np.integer):
        info = np.iinfo(target_dtype)
        min_val, max_val = info.min, info.max

        # Check actual value ranges
        actual_min = np.nanmin(values)
        actual_max = np.nanmax(values)

        if actual_min < min_val or actual_max > max_val:
            raise ValueError(
                f"Values [{actual_min}, {actual_max}] exceed {target_dtype} "
                f"range [{min_val}, {max_val}]"
            )
    elif np.issubdtype(target_dtype, np.floating):
        info = np.finfo(target_dtype)
        # Check for overflow/underflow
        if np.any(np.abs(values[np.isfinite(values)]) > info.max):
            raise ValueError(f"Values too large for {target_dtype}")


def discrete_to_continuous(self: GridProperty) -> None:
    """Convert from discrete to continuous values."""
    if not self.isdiscrete:
        logger.debug("No need to convert, already continuous")
        return

    logger.debug("Converting to continuous ...")
    val = self._values.copy()
    val = val.astype(np.float64)
    self._values = val
    self._isdiscrete = False
    self._codes = {}
    self.roxar_dtype = np.float32


def continuous_to_discrete(self) -> None:
    """Convert from continuous to discrete values."""
    if self.isdiscrete:
        logger.debug("No need to convert, already discrete")
        return

    logger.debug("Converting to discrete ...")
    val = self._values.copy()

    # Validate finite values only
    finite_vals = (
        val[np.isfinite(val)]
        if not isinstance(val, np.ma.MaskedArray)
        else val.compressed()
    )
    if len(finite_vals) > 0:
        _validate_cast_range(finite_vals, np.int32)

    # Round and cast, suppressing the NaN warning
    val = np.round(val)
    with np.errstate(invalid="ignore"):
        val = val.astype(np.int32)

    self._values = val
    self._isdiscrete = True

    self._codes = {
        v: str(v)
        for v in np.ma.unique(val)
        if np.isfinite(v) and not isinstance(v, np.ma.core.MaskedConstant)
    }
    self.roxar_dtype = np.uint16


def get_xy_value_lists(
    self: GridProperty,
    grid: Optional[Grid | GridProperty] = None,
    mask: Optional[bool] = None,
) -> XYValueLists:
    """Get values for webportal format

    Two cells:
    [[[(x1,y1), (x2,y2), (x3,y3), (x4,y4)],
    [(x5,y5), (x6,y6), (x7,y7), (x8,y8)]]]

    If mask is True then inactive cells are ommited from the lists,
    else the active cells corners will be present while the property
    will have a -999 value.

    """
    if grid is None:
        raise RuntimeError("Missing grid object")

    if not isinstance(grid, xtgeo.grid3d.Grid):
        raise RuntimeError("The input grid is not a XTGeo Grid instance")

    if not isinstance(self, xtgeo.grid3d.GridProperty):
        raise RuntimeError("The property is not a XTGeo GridProperty instance")

    clist = grid.get_xyz_corners()
    actnum = grid.get_actnum()

    # set value 0 if actnum is 0 to facilitate later operations
    if mask:
        for cli in clist:
            cli.values[actnum.values == 0] = 0

    # now some numpy operations (coffee?, any?)
    xy0 = np.column_stack((clist[0].values1d, clist[1].values1d))
    xy1 = np.column_stack((clist[3].values1d, clist[4].values1d))
    xy2 = np.column_stack((clist[6].values1d, clist[7].values1d))
    xy3 = np.column_stack((clist[9].values1d, clist[10].values1d))

    xyc = np.column_stack((xy0, xy1, xy2, xy3))
    xyc = xyc.reshape(grid.nlay, grid.ncol * grid.nrow, 4, 2)

    coordlist = xyc.tolist()

    # remove cells that are undefined ("marked" as coordinate [0, 0] if mask)
    coordlist = [
        [[tuple(xy) for xy in cell if xy[0] > 0] for cell in lay] for lay in coordlist
    ]

    coordlist = [[cell for cell in lay if len(cell) > 1] for lay in coordlist]

    pval = self.values1d.reshape((grid.nlay, grid.ncol * grid.nrow))
    valuelist = pval.tolist(fill_value=-999.0)
    if mask:
        valuelist = [[val for val in lay if val != -999.0] for lay in valuelist]

    return coordlist, valuelist


def operation_polygons(
    self: GridProperty,
    poly: Polygons,
    value: float | int,
    opname: Literal["add", "sub", "mul", "div", "set"] = "add",
    inside: bool = True,
) -> None:
    """A generic function for doing operations restricted to inside
    or outside polygon(s).

    """
    grid = self.geometry
    grid._set_xtgformat1()

    if not isinstance(poly, xtgeo.xyz.Polygons):
        raise ValueError("The poly input is not a Polygons instance")

    # make a copy of the array which is used a "filter" or "proxy"
    # value will be 1 inside polygons, 0 outside. Undef cells are kept as is
    dtype = self.dtype

    proxy = self.copy()
    proxy.discrete_to_continuous()

    proxy.values *= 0.0
    cvals = gl.update_carray(proxy)

    idgroups = poly.get_dataframe(copy=False).groupby(poly.pname)

    for id_, grp in idgroups:
        xcor = grp[poly.xname].values
        ycor = grp[poly.yname].values

        ier = _cxtgeo.grd3d_setval_poly(
            xcor,
            ycor,
            self.ncol,
            self.nrow,
            self.nlay,
            grid._coordsv,
            grid._zcornsv,
            grid._actnumsv,
            cvals,
            1,
        )
        if ier == -9:
            logger.warning(f"Polygon no {id_ + 1} is not closed")

    gl.update_values_from_carray(proxy, cvals, np.float64, delete=True)

    if opname == "add":
        tmp = self.values.copy() + value
    elif opname == "sub":
        tmp = self.values.copy() - value
    elif opname == "mul":
        tmp = self.values.copy() * value
    elif opname == "div":
        # Dividing a map of zero is always a hazzle; try to obtain 0.0
        # as result in these cases
        if np.isclose(value, 0.0):
            xtg.warn(
                "Dividing a surface with value or surface with zero "
                "elements; may get unexpected results, try to "
                "achieve zero values as result!"
            )
        with np.errstate(divide="ignore", invalid="ignore"):
            this = np.ma.filled(self.values, fill_value=1.0)
            that = np.ma.filled(value, fill_value=1.0)
            mask = np.ma.getmaskarray(self.values)
            tmp = np.true_divide(this, that)
            tmp = np.where(np.isinf(tmp), 0, tmp)
            tmp = np.nan_to_num(tmp)
            tmp = np.ma.array(tmp, mask=mask)

    elif opname == "set":
        tmp = self.values.copy() * 0 + value

    # convert tmp back to correct dtype
    tmp = tmp.astype(dtype)

    mask = proxy.values == 1 if inside else proxy.values == 0

    self.values[mask] = tmp[mask]


def refine(
    self: GridProperty,
    refine_col: int | list[int],
    refine_row: int | list[int],
    refine_layer: int | list[int],
) -> None:
    """
    Refines the grid property values along specified columns, rows, and layers.
    This method increases the resolution of the grid property by repeating
    the values along the specified axes. The number of repetitions for each
    axis can be provided as either an integer or a list of integers.
    Args:
        refine_col (int | list[int]): Number of times to repeat values along the
            column axis. Can be a single integer or a list of integers specifying
            repetitions for each column.
        refine_row (int | list[int]): Number of times to repeat values along the row
            axis. Can be a single integer or a list of integers specifying
            repetitions for each row.
        refine_layer (int | list[int]): Number of times to repeat values along the
            layer axis. Can be a single integer or a list of integers
            specifying repetitions for each layer.
    Returns:
        None: The method updates the internal grid property values in place.
    """
    mask = np.ma.getmaskarray(self._values)
    values = self._values.data
    for i, val in enumerate([refine_col, refine_row, refine_layer]):
        values = np.repeat(values, val, axis=i)
        mask = np.repeat(mask, val, axis=i)
    self._values = np.ma.array(values, mask=mask)
