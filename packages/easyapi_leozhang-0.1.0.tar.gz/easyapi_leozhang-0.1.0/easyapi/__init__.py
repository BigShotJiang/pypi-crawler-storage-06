from .core import EasyAPI

api = EasyAPI()
run = api.run
