## cdf 

### Added

- [alpha] The `cdf purge instances` command now supports a new argument
`instance-list` that enables deleting individual instances.

## templates

No changes.