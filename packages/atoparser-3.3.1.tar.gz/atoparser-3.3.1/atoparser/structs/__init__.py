"""Libraries for storing Atop structs based on the version."""
