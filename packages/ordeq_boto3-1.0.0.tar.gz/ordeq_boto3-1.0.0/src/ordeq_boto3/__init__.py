from ordeq_boto3.s3_object import S3Object

__all__ = ("S3Object",)
