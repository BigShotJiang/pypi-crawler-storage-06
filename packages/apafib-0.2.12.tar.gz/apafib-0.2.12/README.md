# apafib

Package for GEI APA course, mainly for fetching datasets for the laboratory
sessions and problems list

