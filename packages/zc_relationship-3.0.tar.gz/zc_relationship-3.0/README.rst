Zope 3 relationship index.  Precursor to zc.relation.
