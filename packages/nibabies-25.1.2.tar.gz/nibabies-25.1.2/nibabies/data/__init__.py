from acres import Loader

load = Loader(__package__)
