from acres import Loader

load_data = Loader(__package__)

DERIV_SKELETON = load_data('full-derivatives.yml')
