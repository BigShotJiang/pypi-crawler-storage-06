# UnsetPropertyMode

The behavior if the property key to unset does not exist. - SKIP (default): skip the property to unset - FAIL: fail the entire operation 

## Enum

* `SKIP` (value: `'SKIP'`)

* `FAIL` (value: `'FAIL'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


