
from .simulated import make_correlated_data

__all__ = ['make_correlated_data']
