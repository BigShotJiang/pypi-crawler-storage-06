from benchopt.cli import benchopt

if __name__ == '__main__':
    benchopt()
