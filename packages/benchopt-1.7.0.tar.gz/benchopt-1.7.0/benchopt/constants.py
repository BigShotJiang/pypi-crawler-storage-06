PLOT_KINDS = {
    'objective_curve': 'plot_objective_curve',
    'suboptimality_curve': 'plot_suboptimality_curve',
    'relative_suboptimality_curve': 'plot_relative_suboptimality_curve',
    'bar_chart': 'plot_bar_chart',
    'boxplot': 'plot_boxplot'
}
