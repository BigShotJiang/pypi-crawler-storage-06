.. _benchmark_workflow:


Benchmark workflow
==================


.. toctree::
    :maxdepth: 2

    run_benchmark
    write_benchmark
    visualize_benchmark
    manage_benchmark_results
    config_benchopt
