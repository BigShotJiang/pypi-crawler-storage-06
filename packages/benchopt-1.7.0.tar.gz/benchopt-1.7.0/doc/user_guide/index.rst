.. _user_guide:


User guide
==========


.. toctree::
    :maxdepth: 1

    API_ref
    CLI_ref
    advanced
    ml_benchmark
    performance_curves
    tweak_datasets
