.. raw:: html

    <br/>

{{ fullname | escape | underline}}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. _sphx_glr_backreferences_{{ fullname }}:

.. minigallery:: Examples
    :add-heading: Minigallery using this function
    :heading-level: ^
