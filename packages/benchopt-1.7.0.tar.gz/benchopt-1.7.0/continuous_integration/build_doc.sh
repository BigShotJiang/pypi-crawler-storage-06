pwd
pip install -e .

cd doc
make html
