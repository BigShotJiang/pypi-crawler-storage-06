from .client import Client
from .endpoints import *

Client.aio = True
