from .object import Object
from .slots import Slots
from .string import String
from .word import Word
# from .Number import Number
# from .TimeInterval import TimeInterval
# from .Time import Time
