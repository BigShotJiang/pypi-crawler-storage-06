from pydatalab.mongo import create_default_indices

create_default_indices()
