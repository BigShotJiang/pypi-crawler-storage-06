# Samples

::: pydatalab.models.samples
    options:
        inherited_members: true
        summary:
          attributes: true
          functions: false
          modules: false
