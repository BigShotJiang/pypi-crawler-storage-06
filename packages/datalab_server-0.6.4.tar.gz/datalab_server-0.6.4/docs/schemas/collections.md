# Collections

::: pydatalab.models.collections
    options:
        inherited_members: true
        summary:
          attributes: true
          functions: false
          modules: false
        filters:  # override default filters to include collections
          - "!^_[^_]"
          - "!__json_encoder__$"
          - "!__all__$"
          - "!__config__$"
          - "!^Config$"
