title: NMR
::: pydatalab.apps.nmr
