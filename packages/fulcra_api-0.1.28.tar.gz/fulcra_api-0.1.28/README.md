# Fulcra Dynamics Python Client Library

This is a Python library to simplify calling [Fulcra Dynamics](https://fulcradynamics.com/) APIs.

For a guide to installation, getting started, and an API reference, view the [documentation site](https://fulcradynamics.github.io/fulcra-api-python/).


## Bugs / Feature Requests

Please report any bugs or feature requests using [GitHub issues](https://github.com/fulcradynamics/fulcra-api-python).
