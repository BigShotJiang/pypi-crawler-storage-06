//! Basic arithmetic pipelines

pub(crate) mod average;
pub(crate) mod real;
pub(crate) mod sqrt;
