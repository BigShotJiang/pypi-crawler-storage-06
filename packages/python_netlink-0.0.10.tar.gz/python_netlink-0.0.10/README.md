# Netlink
[![Netlink](https://github.com/kinnay/netlink/workflows/Release/badge.svg)](https://github.com/kinnay/netlink/actions/workflows/main.yaml) 

This package provides an asynchronous implementation of the Linux netlink protocol, including basic support for nl80211.

This package can be installed using `pip3 install python-netlink`.

Documentation is available [here](https://netlink.readthedocs.io).
