def version():
    return '0.5.2'

if __name__ == "__main__":
    print(version())
