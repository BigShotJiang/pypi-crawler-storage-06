# Package tockloader.exceptions Documentation

## Class ChannelAddressErrorException
Raised when a particular channel to a board cannot support the request
operation, likely due to the specific address.


## Class TockLoaderException
Raised when Tockloader detects an issue.

