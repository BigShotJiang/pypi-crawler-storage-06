"""
Tockloader is a tool for installing Tock applications.
"""

from ._version import __version__
