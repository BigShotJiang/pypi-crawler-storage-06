"""
Izumi - A reproduction of some concepts from Scala's Izumi Project and distage Dependency Injection
"""

__version__ = "0.1.1"
