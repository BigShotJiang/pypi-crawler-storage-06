from udata_search_service.app import create_app

application = create_app()
