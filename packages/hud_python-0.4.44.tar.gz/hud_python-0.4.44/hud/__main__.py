"""Allow running CLI with python -m hud."""

from __future__ import annotations

from hud.cli import main

if __name__ == "__main__":
    main()
