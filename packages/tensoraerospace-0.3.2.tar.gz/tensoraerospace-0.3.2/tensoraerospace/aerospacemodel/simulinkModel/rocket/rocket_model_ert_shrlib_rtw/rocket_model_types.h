/*
 * File: rocket_model_types.h
 *
 * Code generated for Simulink model 'rocket_model'.
 *
 * Model version                  : 1.26
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Sun Dec 11 09:48:41 2022
 *
 * Target selection: ert_shrlib.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_rocket_model_types_h_
#define RTW_HEADER_rocket_model_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_rocket_model_T RT_MODEL_rocket_model_T;

#endif                                 /* RTW_HEADER_rocket_model_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
