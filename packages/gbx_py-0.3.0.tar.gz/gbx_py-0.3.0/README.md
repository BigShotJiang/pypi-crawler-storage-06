# gbx-py

![PyPI version](https://img.shields.io/pypi/v/gbx-py.svg)
[![Documentation Status](https://readthedocs.org/projects/gbx-py/badge/?version=latest)](https://gbx-py.readthedocs.io/en/latest/?version=latest)

Read and write GBX files for Trackmania.

-   PyPI package: https://pypi.org/project/gbx-py/
-   Free software: MIT License
-   Documentation: https://gbx-py.readthedocs.io.

## Features

-   TODO

## Getting start

`py -m pip install gbx-py`

## Dev

Install and build locally

`py -m pip install -e .`

### Deploy

```
bump2version --current-version 0.3.0 patch setup.py # major/minor
git push
git push --tags
```
