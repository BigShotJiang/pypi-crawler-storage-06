# History

## 0.3.0 (2025-09-20)

-   First release on PyPI.
