Fit curve
=============

.. automodule:: src.cvsim.fit_curve
   :members: