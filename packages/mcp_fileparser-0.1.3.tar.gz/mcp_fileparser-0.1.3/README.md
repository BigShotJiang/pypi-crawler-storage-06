# MCP File Parser

[![PyPI version](https://badge.fury.io/py/mcp-fileparser.svg)](https://badge.fury.io/py/mcp-fileparser)

A file parser using Kimi AI. However, all of this is free.

## Installation

```bash
pip install mcp-fileparser
```

## Usage

### As a Python Library

1.  **Set up your environment variables.**

    Create a `.env` file in your project root and add your Kimi API key:

    ```
    KIMI_API_KEY="your_api_key"
    ```

2.  **Use the `parse_file` function.**

    ```python
    from mcp_fileparser import parse_file

    content = parse_file("/path/to/your/file.xlsx")
    print(content)
    ```

### As an MCP Server

This package can also be used as an MCP (Model Context Protocol) server, providing file parsing capabilities to MCP clients.

#### Installation

1.  **Install the package:**

    ```bash
    pip install mcp-fileparser
    ```

2.  **Set up your environment variables:**

    Create a `.env` file in your project root and add your Kimi API key:

    ```
    KIMI_API_KEY="your_api_key"
    ```

#### Configuration

Add the MCP server to your MCP client configuration. For example, in Claude Desktop or other MCP-compatible clients:

```json
{
  "mcpServers": {
    "mcp-fileparser": {
      "command": "npx",
      "args": [
        "--from",
        "mcp-fileparser",
        "parse_file"
      ],
      "env": {
        "KIMI_API_KEY": "your_api_key"
      }
    }
  }
}
```

#### Available Tools

Once connected, the MCP server provides the following tool:

- **`parse_file`**: Parse a file and extract its content using Kimi AI
  - **Parameters**: 
    - `fpath` (string): The path to the file you want to parse
  - **Returns**: The extracted content as a string

#### Example Usage

In an MCP-compatible client, you can use the `parse_file` tool like this:

```python
# Example of how the tool would be called by an MCP client
result = await client.call_tool("parse_file", {
  "fpath": "/path/to/your/document.pdf"
})
print(result.content)
```

#### Supported File Types

The file parser supports various file types including:
- PDF documents
- Word documents (.docx)
- Excel spreadsheets (.xlsx)
- Text files (.txt)
- And many other formats supported by Kimi AI

#### Running the Server Manually

You can also run the MCP server manually for testing:

```bash
# Set your API key
export KIMI_API_KEY="your_api_key"

# Run the server
fileparser
```

The server will start and listen for MCP connections via stdio transport.

## License

This project is licensed under the MIT License.
