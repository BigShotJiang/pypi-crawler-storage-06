# FineSQL

🚀 **FineSQL** – Library for interacting with SQLite database from Python code, with Python objects.

## Installation
```bash
pip install finesql
```