from ._IDice import IDice

from ._NDice import NDice
from ._Dice6 import Dice6
from ._Dice8 import Dice8
from ._Dice12 import Dice12
