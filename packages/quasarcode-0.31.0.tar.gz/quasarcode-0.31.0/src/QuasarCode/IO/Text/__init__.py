from ._console import Console
from ._console import OldConsole# Depreciated!!!
from ._stopwatch import Stopwatch

print_info = Console.print_info
print_verbose_info = Console.print_verbose_info
print_warning = Console.print_warning
print_verbose_warning = Console.print_verbose_warning
print_error = Console.print_error
print_verbose_error = Console.print_verbose_error
print_debug = Console.print_debug
print_verbose_debug = Console.print_verbose_debug
