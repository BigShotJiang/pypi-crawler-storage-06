#import unittest
import pytest


import QuasarCode

class TestClass_general(object):

    def test_default(self):
        assert True
