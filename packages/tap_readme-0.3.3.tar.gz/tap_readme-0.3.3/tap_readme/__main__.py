"""Tap executable."""

from __future__ import annotations

from tap_readme.tap import TapReadMe

TapReadMe.cli()
