"""Python package for the tap-readme CLI."""

from __future__ import annotations
