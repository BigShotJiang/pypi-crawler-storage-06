from bitmovin_api_sdk.analytics.ads.queries.stddev.stddev_api import StddevApi
