from bitmovin_api_sdk.analytics.queries.stddev.stddev_api import StddevApi
