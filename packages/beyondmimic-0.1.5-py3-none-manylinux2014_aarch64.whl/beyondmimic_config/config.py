motion_frame={
    'stand2squat':1150
}