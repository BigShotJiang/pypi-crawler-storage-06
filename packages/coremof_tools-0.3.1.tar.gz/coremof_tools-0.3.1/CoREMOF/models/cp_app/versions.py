# -*- coding: utf-8 -*-

"""Version information."""

VERSION = '0.0.1-dev'
