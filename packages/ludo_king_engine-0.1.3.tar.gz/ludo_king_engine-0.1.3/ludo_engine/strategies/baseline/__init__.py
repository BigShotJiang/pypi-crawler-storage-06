"""
Baseline Strategies - Simple strategy implementations.
"""

from ludo_engine.strategies.baseline.random_strategy import RandomStrategy

__all__ = ["RandomStrategy"]
