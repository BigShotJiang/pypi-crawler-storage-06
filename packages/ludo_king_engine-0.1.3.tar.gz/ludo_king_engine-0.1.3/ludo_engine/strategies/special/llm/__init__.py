"""
Simple LLM strategy module.
"""

from .strategy import LLMStrategy

__all__ = ["LLMStrategy"]
