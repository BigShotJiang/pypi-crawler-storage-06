# SSBatchNumberGenerator

Plugin to generate unique batch numbers

## Installation

### InvenTree Plugin Manager

... todo ...

### Command Line 

To install manually via the command line, run the following command:

```bash
pip install ss-batch-number-generator
```

## Configuration

... todo ...

## Usage

... todo ...
