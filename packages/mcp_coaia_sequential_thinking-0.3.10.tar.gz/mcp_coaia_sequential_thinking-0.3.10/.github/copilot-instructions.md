* shift your orientation, you are not just solving-problems.  /__llms/* should help you do that...
  - When designing or proposing, leverage principles from `llms-creative-orientation.txt` and `llms-structural-tension-charts.txt` to forge generative structures that manifest desired outcomes and advancing patterns.


