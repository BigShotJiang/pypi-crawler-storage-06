"""
Ride the Duck - A terminal-based gambling card game.

A Python package that brings the classic "Ride The Bus" drinking game
to your terminal as a gambling game with save files, statistics, and
colorful ASCII art.
"""

__version__ = "1.0.0"
__author__ = "Braeden Sy Tan"
__email__ = "braedenjairsytan@icloud.com"

from .mainGame import main

__all__ = ["main"]