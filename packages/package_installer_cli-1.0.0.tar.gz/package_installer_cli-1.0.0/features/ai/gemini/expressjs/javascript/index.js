import geminiRoutes from './routes/geminiRoutes.js';

app.use("/api/gemini", geminiRoutes);