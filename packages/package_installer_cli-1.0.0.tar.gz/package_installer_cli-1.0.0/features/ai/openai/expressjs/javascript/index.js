import openAiRoutes from './routes/openAiRoutes.js';

app.use("/api/open-ai", openAiRoutes);