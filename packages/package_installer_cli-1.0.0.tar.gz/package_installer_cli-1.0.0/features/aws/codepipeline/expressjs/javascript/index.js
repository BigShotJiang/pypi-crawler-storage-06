
import codePipelineRoutes from './routes/codePipelineRoutes.js';

app.use("/api/codepipeline",codePipelineRoutes)