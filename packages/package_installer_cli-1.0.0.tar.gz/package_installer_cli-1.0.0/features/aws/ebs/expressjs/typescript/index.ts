
import awsEbsRoutes from './routes/awsEbsRoutes';

app.use("/api/ebs",awsEbsRoutes)