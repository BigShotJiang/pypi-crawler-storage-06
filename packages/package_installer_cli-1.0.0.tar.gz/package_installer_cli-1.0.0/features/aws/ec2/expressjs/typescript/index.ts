
import awsEc2Routes from './routes/awsEc2Routes';

app.use("/api/ec2", awsEc2Routes)