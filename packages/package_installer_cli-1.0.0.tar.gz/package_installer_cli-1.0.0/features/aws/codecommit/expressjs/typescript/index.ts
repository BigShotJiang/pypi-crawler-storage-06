
import codeCommitRoutes from './routes/codeCommitRoutes';

app.use("/api/codecommit",codeCommitRoutes)