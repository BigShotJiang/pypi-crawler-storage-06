graphDbFilt = {"plugin": "peek_plugin_graphdb"}
graphDbTuplePrefix = "peek_plugin_graphdb."
graphDbObservableName = "peek_plugin_graphdb"
graphDbActionProcessorName = "peek_plugin_graphdb"
graphDbTupleOfflineServiceName = "peek_plugin_graphdb"
