"""
Lark Sheet MCP

A Model Context Protocol server for accessing Feishu/Lark spreadsheet data.
"""

__version__ = "1.0.0"
__author__ = "Lupin"
