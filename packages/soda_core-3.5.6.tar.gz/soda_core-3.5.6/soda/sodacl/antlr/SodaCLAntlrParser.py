# Generated from /Users/jarek/git/soda-core/soda/core/soda/sodacl/antlr/SodaCLAntlr.g4 by ANTLR 4.11.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,61,399,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,1,0,1,0,1,0,1,0,1,0,1,0,
        3,0,95,8,0,1,1,1,1,1,1,1,1,3,1,101,8,1,1,1,1,1,1,1,1,1,3,1,107,8,
        1,1,1,1,1,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,3,1,4,1,4,1,4,1,5,1,5,1,
        5,1,6,1,6,1,6,1,6,1,6,3,6,130,8,6,1,6,1,6,1,6,1,6,3,6,136,8,6,1,
        6,1,6,1,7,1,7,1,7,3,7,143,8,7,1,7,1,7,1,7,1,7,3,7,149,8,7,3,7,151,
        8,7,1,7,1,7,1,8,1,8,1,8,1,8,1,9,1,9,1,9,1,9,1,9,3,9,164,8,9,1,9,
        3,9,167,8,9,1,9,1,9,1,9,1,10,1,10,1,10,1,10,1,10,1,10,1,10,3,10,
        179,8,10,1,11,1,11,1,12,1,12,1,13,1,13,1,13,1,14,1,14,1,15,1,15,
        1,16,1,16,3,16,194,8,16,1,17,1,17,1,18,1,18,1,18,1,18,1,18,5,18,
        203,8,18,10,18,12,18,206,9,18,1,18,1,18,1,19,1,19,3,19,212,8,19,
        1,20,1,20,3,20,216,8,20,1,21,1,21,3,21,220,8,21,1,21,1,21,1,21,3,
        21,225,8,21,1,21,1,21,1,21,1,21,1,21,1,21,3,21,233,8,21,1,22,1,22,
        1,22,1,22,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,4,23,248,
        8,23,11,23,12,23,249,1,23,1,23,1,24,1,24,1,25,1,25,1,26,1,26,1,27,
        1,27,3,27,262,8,27,1,27,3,27,265,8,27,1,27,1,27,3,27,269,8,27,1,
        28,4,28,272,8,28,11,28,12,28,273,1,29,1,29,1,29,1,29,1,29,1,29,1,
        29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,5,29,293,8,
        29,10,29,12,29,296,9,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,
        1,29,1,29,1,29,5,29,309,8,29,10,29,12,29,312,9,29,1,29,1,29,3,29,
        316,8,29,1,30,1,30,1,30,1,30,3,30,322,8,30,1,30,1,30,1,31,1,31,1,
        32,1,32,1,33,1,33,1,33,1,33,1,33,3,33,335,8,33,1,34,1,34,1,34,1,
        34,1,34,3,34,342,8,34,1,34,1,34,1,35,1,35,1,36,1,36,1,36,1,36,1,
        36,1,36,1,36,1,37,1,37,1,37,1,37,1,37,1,38,1,38,1,38,1,38,1,38,1,
        38,1,38,1,38,1,38,1,38,3,38,370,8,38,1,39,1,39,1,39,1,39,1,39,1,
        40,3,40,378,8,40,1,40,1,40,1,41,1,41,1,41,1,41,3,41,386,8,41,1,41,
        3,41,389,8,41,1,41,1,41,3,41,393,8,41,1,42,1,42,1,43,1,43,1,43,0,
        0,44,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,
        44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,
        0,8,1,0,31,33,2,0,34,34,38,38,2,0,35,35,39,39,1,0,26,28,2,0,46,46,
        49,49,1,0,44,50,1,0,42,43,2,0,31,33,55,58,399,0,94,1,0,0,0,2,96,
        1,0,0,0,4,110,1,0,0,0,6,115,1,0,0,0,8,118,1,0,0,0,10,121,1,0,0,0,
        12,124,1,0,0,0,14,142,1,0,0,0,16,154,1,0,0,0,18,158,1,0,0,0,20,178,
        1,0,0,0,22,180,1,0,0,0,24,182,1,0,0,0,26,184,1,0,0,0,28,187,1,0,
        0,0,30,189,1,0,0,0,32,191,1,0,0,0,34,195,1,0,0,0,36,197,1,0,0,0,
        38,211,1,0,0,0,40,215,1,0,0,0,42,219,1,0,0,0,44,234,1,0,0,0,46,247,
        1,0,0,0,48,253,1,0,0,0,50,255,1,0,0,0,52,257,1,0,0,0,54,268,1,0,
        0,0,56,271,1,0,0,0,58,315,1,0,0,0,60,317,1,0,0,0,62,325,1,0,0,0,
        64,327,1,0,0,0,66,334,1,0,0,0,68,336,1,0,0,0,70,345,1,0,0,0,72,347,
        1,0,0,0,74,354,1,0,0,0,76,369,1,0,0,0,78,371,1,0,0,0,80,377,1,0,
        0,0,82,392,1,0,0,0,84,394,1,0,0,0,86,396,1,0,0,0,88,95,3,8,4,0,89,
        95,3,12,6,0,90,95,3,14,7,0,91,95,3,58,29,0,92,95,3,2,1,0,93,95,3,
        10,5,0,94,88,1,0,0,0,94,89,1,0,0,0,94,90,1,0,0,0,94,91,1,0,0,0,94,
        92,1,0,0,0,94,93,1,0,0,0,95,1,1,0,0,0,96,97,5,1,0,0,97,98,5,61,0,
        0,98,100,3,86,43,0,99,101,3,4,2,0,100,99,1,0,0,0,100,101,1,0,0,0,
        101,106,1,0,0,0,102,103,5,61,0,0,103,104,5,49,0,0,104,105,5,61,0,
        0,105,107,3,56,28,0,106,102,1,0,0,0,106,107,1,0,0,0,107,108,1,0,
        0,0,108,109,5,0,0,1,109,3,1,0,0,0,110,111,5,61,0,0,111,112,5,2,0,
        0,112,113,5,61,0,0,113,114,3,86,43,0,114,5,1,0,0,0,115,116,5,61,
        0,0,116,117,5,26,0,0,117,7,1,0,0,0,118,119,5,3,0,0,119,120,5,0,0,
        1,120,9,1,0,0,0,121,122,5,4,0,0,122,123,5,0,0,1,123,11,1,0,0,0,124,
        125,5,5,0,0,125,126,5,61,0,0,126,129,3,86,43,0,127,128,5,61,0,0,
        128,130,3,70,35,0,129,127,1,0,0,0,129,130,1,0,0,0,130,135,1,0,0,
        0,131,132,5,61,0,0,132,133,5,25,0,0,133,134,5,61,0,0,134,136,3,86,
        43,0,135,131,1,0,0,0,135,136,1,0,0,0,136,137,1,0,0,0,137,138,5,0,
        0,1,138,13,1,0,0,0,139,143,3,18,9,0,140,143,3,28,14,0,141,143,3,
        30,15,0,142,139,1,0,0,0,142,140,1,0,0,0,142,141,1,0,0,0,142,143,
        1,0,0,0,143,144,1,0,0,0,144,150,3,32,16,0,145,148,5,61,0,0,146,149,
        3,40,20,0,147,149,3,16,8,0,148,146,1,0,0,0,148,147,1,0,0,0,149,151,
        1,0,0,0,150,145,1,0,0,0,150,151,1,0,0,0,151,152,1,0,0,0,152,153,
        5,0,0,1,153,15,1,0,0,0,154,155,5,49,0,0,155,156,5,61,0,0,156,157,
        5,6,0,0,157,17,1,0,0,0,158,159,5,29,0,0,159,163,5,61,0,0,160,161,
        3,20,10,0,161,162,5,61,0,0,162,164,1,0,0,0,163,160,1,0,0,0,163,164,
        1,0,0,0,164,166,1,0,0,0,165,167,3,26,13,0,166,165,1,0,0,0,166,167,
        1,0,0,0,167,168,1,0,0,0,168,169,5,21,0,0,169,170,5,61,0,0,170,19,
        1,0,0,0,171,172,3,22,11,0,172,173,5,61,0,0,173,174,5,30,0,0,174,
        175,5,61,0,0,175,176,3,84,42,0,176,179,1,0,0,0,177,179,3,24,12,0,
        178,171,1,0,0,0,178,177,1,0,0,0,179,21,1,0,0,0,180,181,7,0,0,0,181,
        23,1,0,0,0,182,183,5,7,0,0,183,25,1,0,0,0,184,185,5,8,0,0,185,186,
        5,61,0,0,186,27,1,0,0,0,187,188,5,9,0,0,188,29,1,0,0,0,189,190,5,
        10,0,0,190,31,1,0,0,0,191,193,3,34,17,0,192,194,3,36,18,0,193,192,
        1,0,0,0,193,194,1,0,0,0,194,33,1,0,0,0,195,196,3,86,43,0,196,35,
        1,0,0,0,197,198,5,38,0,0,198,204,3,38,19,0,199,200,5,40,0,0,200,
        201,5,61,0,0,201,203,3,38,19,0,202,199,1,0,0,0,203,206,1,0,0,0,204,
        202,1,0,0,0,204,205,1,0,0,0,205,207,1,0,0,0,206,204,1,0,0,0,207,
        208,5,39,0,0,208,37,1,0,0,0,209,212,3,80,40,0,210,212,3,86,43,0,
        211,209,1,0,0,0,211,210,1,0,0,0,212,39,1,0,0,0,213,216,3,44,22,0,
        214,216,3,42,21,0,215,213,1,0,0,0,215,214,1,0,0,0,216,41,1,0,0,0,
        217,218,5,24,0,0,218,220,5,61,0,0,219,217,1,0,0,0,219,220,1,0,0,
        0,220,221,1,0,0,0,221,222,5,23,0,0,222,224,5,61,0,0,223,225,7,1,
        0,0,224,223,1,0,0,0,224,225,1,0,0,0,225,226,1,0,0,0,226,227,3,54,
        27,0,227,228,5,61,0,0,228,229,5,22,0,0,229,230,5,61,0,0,230,232,
        3,54,27,0,231,233,7,2,0,0,232,231,1,0,0,0,232,233,1,0,0,0,233,43,
        1,0,0,0,234,235,3,52,26,0,235,236,5,61,0,0,236,237,3,54,27,0,237,
        45,1,0,0,0,238,239,3,48,24,0,239,240,5,61,0,0,240,241,3,50,25,0,
        241,242,5,61,0,0,242,243,3,54,27,0,243,244,5,61,0,0,244,245,3,50,
        25,0,245,246,5,61,0,0,246,248,1,0,0,0,247,238,1,0,0,0,248,249,1,
        0,0,0,249,247,1,0,0,0,249,250,1,0,0,0,250,251,1,0,0,0,251,252,3,
        48,24,0,252,47,1,0,0,0,253,254,7,3,0,0,254,49,1,0,0,0,255,256,7,
        4,0,0,256,51,1,0,0,0,257,258,7,5,0,0,258,53,1,0,0,0,259,264,3,80,
        40,0,260,262,5,61,0,0,261,260,1,0,0,0,261,262,1,0,0,0,262,263,1,
        0,0,0,263,265,5,41,0,0,264,261,1,0,0,0,264,265,1,0,0,0,265,269,1,
        0,0,0,266,269,3,56,28,0,267,269,5,57,0,0,268,259,1,0,0,0,268,266,
        1,0,0,0,268,267,1,0,0,0,269,55,1,0,0,0,270,272,5,51,0,0,271,270,
        1,0,0,0,272,273,1,0,0,0,273,271,1,0,0,0,273,274,1,0,0,0,274,57,1,
        0,0,0,275,276,5,11,0,0,276,277,5,61,0,0,277,278,3,62,31,0,278,279,
        5,61,0,0,279,280,3,60,30,0,280,281,5,61,0,0,281,282,3,86,43,0,282,
        283,5,61,0,0,283,284,3,64,32,0,284,316,1,0,0,0,285,286,5,11,0,0,
        286,287,5,61,0,0,287,288,5,38,0,0,288,294,3,62,31,0,289,290,5,40,
        0,0,290,291,5,61,0,0,291,293,3,62,31,0,292,289,1,0,0,0,293,296,1,
        0,0,0,294,292,1,0,0,0,294,295,1,0,0,0,295,297,1,0,0,0,296,294,1,
        0,0,0,297,298,5,39,0,0,298,299,5,61,0,0,299,300,3,60,30,0,300,301,
        5,61,0,0,301,302,3,86,43,0,302,303,5,61,0,0,303,304,5,38,0,0,304,
        310,3,64,32,0,305,306,5,40,0,0,306,307,5,61,0,0,307,309,3,64,32,
        0,308,305,1,0,0,0,309,312,1,0,0,0,310,308,1,0,0,0,310,311,1,0,0,
        0,311,313,1,0,0,0,312,310,1,0,0,0,313,314,5,39,0,0,314,316,1,0,0,
        0,315,275,1,0,0,0,315,285,1,0,0,0,316,59,1,0,0,0,317,318,5,12,0,
        0,318,321,5,61,0,0,319,320,5,24,0,0,320,322,5,61,0,0,321,319,1,0,
        0,0,321,322,1,0,0,0,322,323,1,0,0,0,323,324,5,13,0,0,324,61,1,0,
        0,0,325,326,3,86,43,0,326,63,1,0,0,0,327,328,3,86,43,0,328,65,1,
        0,0,0,329,335,3,68,34,0,330,335,3,74,37,0,331,335,3,72,36,0,332,
        335,3,76,38,0,333,335,3,78,39,0,334,329,1,0,0,0,334,330,1,0,0,0,
        334,331,1,0,0,0,334,332,1,0,0,0,334,333,1,0,0,0,335,67,1,0,0,0,336,
        337,5,14,0,0,337,338,5,61,0,0,338,341,3,86,43,0,339,340,5,61,0,0,
        340,342,3,70,35,0,341,339,1,0,0,0,341,342,1,0,0,0,342,343,1,0,0,
        0,343,344,5,0,0,1,344,69,1,0,0,0,345,346,3,86,43,0,346,71,1,0,0,
        0,347,348,5,15,0,0,348,349,5,61,0,0,349,350,3,86,43,0,350,351,5,
        61,0,0,351,352,3,70,35,0,352,353,5,0,0,1,353,73,1,0,0,0,354,355,
        5,16,0,0,355,356,5,61,0,0,356,357,3,86,43,0,357,358,5,0,0,1,358,
        75,1,0,0,0,359,360,5,17,0,0,360,361,5,61,0,0,361,362,3,86,43,0,362,
        363,5,0,0,1,363,370,1,0,0,0,364,365,5,18,0,0,365,366,5,61,0,0,366,
        367,3,86,43,0,367,368,5,0,0,1,368,370,1,0,0,0,369,359,1,0,0,0,369,
        364,1,0,0,0,370,77,1,0,0,0,371,372,5,19,0,0,372,373,5,61,0,0,373,
        374,3,86,43,0,374,375,5,0,0,1,375,79,1,0,0,0,376,378,7,6,0,0,377,
        376,1,0,0,0,377,378,1,0,0,0,378,379,1,0,0,0,379,380,3,82,41,0,380,
        81,1,0,0,0,381,393,3,84,42,0,382,383,5,60,0,0,383,385,5,20,0,0,384,
        386,5,60,0,0,385,384,1,0,0,0,385,386,1,0,0,0,386,393,1,0,0,0,387,
        389,5,60,0,0,388,387,1,0,0,0,388,389,1,0,0,0,389,390,1,0,0,0,390,
        391,5,20,0,0,391,393,5,60,0,0,392,381,1,0,0,0,392,382,1,0,0,0,392,
        388,1,0,0,0,393,83,1,0,0,0,394,395,5,60,0,0,395,85,1,0,0,0,396,397,
        7,7,0,0,397,87,1,0,0,0,34,94,100,106,129,135,142,148,150,163,166,
        178,193,204,211,215,219,224,232,249,261,264,268,273,294,310,315,
        321,334,341,369,377,385,388,392
    ]

class SodaCLAntlrParser ( Parser ):

    grammarFileName = "SodaCLAntlr.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'freshness using'", "'with'", "'failed rows'", 
                     "'group by'", "'row_count same as'", "'default'", "'same day last week'", 
                     "'percent'", "'anomaly score for '", "'anomaly detection for '", 
                     "'values in'", "'must'", "'exist in'", "'checks for'", 
                     "'filter'", "'configurations for'", "'for each dataset'", 
                     "'for each table'", "'for each column'", "'.'", "'for'", 
                     "'and'", "'between'", "'not'", "'in'", "'warn'", "'fail'", 
                     "'pass'", "'change'", "'last'", "'avg'", "'min'", "'max'", 
                     "'['", "']'", "'{'", "'}'", "'('", "')'", "','", "'%'", 
                     "'+'", "'-'", "'!='", "'<>'", "'<='", "'>='", "'='", 
                     "'<'", "'>'", "<INVALID>", "'d'", "'h'", "'m'", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "' '" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "FOR", "AND", "BETWEEN", "NOT", "IN", 
                      "WARN", "FAIL", "PASS", "CHANGE", "LAST", "AVG", "MIN", 
                      "MAX", "SQUARE_LEFT", "SQUARE_RIGHT", "CURLY_LEFT", 
                      "CURLY_RIGHT", "ROUND_LEFT", "ROUND_RIGHT", "COMMA", 
                      "PERCENT", "PLUS", "MINUS", "NOT_EQUAL", "NOT_EQUAL_SQL", 
                      "LTE", "GTE", "EQUAL", "LT", "GT", "TIMEUNIT", "DAY", 
                      "HOUR", "MINUTE", "IDENTIFIER_DOUBLE_QUOTE", "IDENTIFIER_BACKTICK", 
                      "IDENTIFIER_UNQUOTED", "IDENTIFIER_SQUARE_BRACKETS", 
                      "STRING", "DIGITS", "S" ]

    RULE_check = 0
    RULE_freshness_check = 1
    RULE_freshness_variable = 2
    RULE_warn_qualifier = 3
    RULE_failed_rows_check = 4
    RULE_group_by_check = 5
    RULE_row_count_comparison_check = 6
    RULE_metric_check = 7
    RULE_default_anomaly_threshold = 8
    RULE_change_over_time = 9
    RULE_change_over_time_config = 10
    RULE_change_aggregation = 11
    RULE_same_day_last_week = 12
    RULE_percent = 13
    RULE_anomaly_score = 14
    RULE_anomaly_detection = 15
    RULE_metric = 16
    RULE_metric_name = 17
    RULE_metric_args = 18
    RULE_metric_arg = 19
    RULE_threshold = 20
    RULE_between_threshold = 21
    RULE_comparator_threshold = 22
    RULE_zones_threshold = 23
    RULE_outcome = 24
    RULE_zone_comparator = 25
    RULE_comparator = 26
    RULE_threshold_value = 27
    RULE_freshness_threshold_value = 28
    RULE_reference_check = 29
    RULE_reference_must_exist = 30
    RULE_source_column_name = 31
    RULE_target_column_name = 32
    RULE_section_header = 33
    RULE_table_checks_header = 34
    RULE_partition_name = 35
    RULE_table_filter_header = 36
    RULE_column_configurations_header = 37
    RULE_checks_for_each_dataset_header = 38
    RULE_checks_for_each_column_header = 39
    RULE_signed_number = 40
    RULE_number = 41
    RULE_integer = 42
    RULE_identifier = 43

    ruleNames =  [ "check", "freshness_check", "freshness_variable", "warn_qualifier", 
                   "failed_rows_check", "group_by_check", "row_count_comparison_check", 
                   "metric_check", "default_anomaly_threshold", "change_over_time", 
                   "change_over_time_config", "change_aggregation", "same_day_last_week", 
                   "percent", "anomaly_score", "anomaly_detection", "metric", 
                   "metric_name", "metric_args", "metric_arg", "threshold", 
                   "between_threshold", "comparator_threshold", "zones_threshold", 
                   "outcome", "zone_comparator", "comparator", "threshold_value", 
                   "freshness_threshold_value", "reference_check", "reference_must_exist", 
                   "source_column_name", "target_column_name", "section_header", 
                   "table_checks_header", "partition_name", "table_filter_header", 
                   "column_configurations_header", "checks_for_each_dataset_header", 
                   "checks_for_each_column_header", "signed_number", "number", 
                   "integer", "identifier" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    FOR=21
    AND=22
    BETWEEN=23
    NOT=24
    IN=25
    WARN=26
    FAIL=27
    PASS=28
    CHANGE=29
    LAST=30
    AVG=31
    MIN=32
    MAX=33
    SQUARE_LEFT=34
    SQUARE_RIGHT=35
    CURLY_LEFT=36
    CURLY_RIGHT=37
    ROUND_LEFT=38
    ROUND_RIGHT=39
    COMMA=40
    PERCENT=41
    PLUS=42
    MINUS=43
    NOT_EQUAL=44
    NOT_EQUAL_SQL=45
    LTE=46
    GTE=47
    EQUAL=48
    LT=49
    GT=50
    TIMEUNIT=51
    DAY=52
    HOUR=53
    MINUTE=54
    IDENTIFIER_DOUBLE_QUOTE=55
    IDENTIFIER_BACKTICK=56
    IDENTIFIER_UNQUOTED=57
    IDENTIFIER_SQUARE_BRACKETS=58
    STRING=59
    DIGITS=60
    S=61

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.11.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class CheckContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def failed_rows_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Failed_rows_checkContext,0)


        def row_count_comparison_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Row_count_comparison_checkContext,0)


        def metric_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Metric_checkContext,0)


        def reference_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Reference_checkContext,0)


        def freshness_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Freshness_checkContext,0)


        def group_by_check(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Group_by_checkContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCheck" ):
                listener.enterCheck(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCheck" ):
                listener.exitCheck(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCheck" ):
                return visitor.visitCheck(self)
            else:
                return visitor.visitChildren(self)




    def check(self):

        localctx = SodaCLAntlrParser.CheckContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_check)
        try:
            self.state = 94
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3]:
                self.enterOuterAlt(localctx, 1)
                self.state = 88
                self.failed_rows_check()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 89
                self.row_count_comparison_check()
                pass
            elif token in [9, 10, 29, 31, 32, 33, 55, 56, 57, 58]:
                self.enterOuterAlt(localctx, 3)
                self.state = 90
                self.metric_check()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 4)
                self.state = 91
                self.reference_check()
                pass
            elif token in [1]:
                self.enterOuterAlt(localctx, 5)
                self.state = 92
                self.freshness_check()
                pass
            elif token in [4]:
                self.enterOuterAlt(localctx, 6)
                self.state = 93
                self.group_by_check()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Freshness_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def freshness_variable(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Freshness_variableContext,0)


        def LT(self):
            return self.getToken(SodaCLAntlrParser.LT, 0)

        def freshness_threshold_value(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Freshness_threshold_valueContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_freshness_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFreshness_check" ):
                listener.enterFreshness_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFreshness_check" ):
                listener.exitFreshness_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFreshness_check" ):
                return visitor.visitFreshness_check(self)
            else:
                return visitor.visitChildren(self)




    def freshness_check(self):

        localctx = SodaCLAntlrParser.Freshness_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_freshness_check)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self.match(SodaCLAntlrParser.T__0)
            self.state = 97
            self.match(SodaCLAntlrParser.S)
            self.state = 98
            self.identifier()
            self.state = 100
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.state = 99
                self.freshness_variable()


            self.state = 106
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==61:
                self.state = 102
                self.match(SodaCLAntlrParser.S)
                self.state = 103
                self.match(SodaCLAntlrParser.LT)
                self.state = 104
                self.match(SodaCLAntlrParser.S)
                self.state = 105
                self.freshness_threshold_value()


            self.state = 108
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Freshness_variableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_freshness_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFreshness_variable" ):
                listener.enterFreshness_variable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFreshness_variable" ):
                listener.exitFreshness_variable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFreshness_variable" ):
                return visitor.visitFreshness_variable(self)
            else:
                return visitor.visitChildren(self)




    def freshness_variable(self):

        localctx = SodaCLAntlrParser.Freshness_variableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_freshness_variable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 110
            self.match(SodaCLAntlrParser.S)
            self.state = 111
            self.match(SodaCLAntlrParser.T__1)
            self.state = 112
            self.match(SodaCLAntlrParser.S)
            self.state = 113
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Warn_qualifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def WARN(self):
            return self.getToken(SodaCLAntlrParser.WARN, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_warn_qualifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWarn_qualifier" ):
                listener.enterWarn_qualifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWarn_qualifier" ):
                listener.exitWarn_qualifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWarn_qualifier" ):
                return visitor.visitWarn_qualifier(self)
            else:
                return visitor.visitChildren(self)




    def warn_qualifier(self):

        localctx = SodaCLAntlrParser.Warn_qualifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_warn_qualifier)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 115
            self.match(SodaCLAntlrParser.S)
            self.state = 116
            self.match(SodaCLAntlrParser.WARN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Failed_rows_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_failed_rows_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFailed_rows_check" ):
                listener.enterFailed_rows_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFailed_rows_check" ):
                listener.exitFailed_rows_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFailed_rows_check" ):
                return visitor.visitFailed_rows_check(self)
            else:
                return visitor.visitChildren(self)




    def failed_rows_check(self):

        localctx = SodaCLAntlrParser.Failed_rows_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_failed_rows_check)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 118
            self.match(SodaCLAntlrParser.T__2)
            self.state = 119
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Group_by_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_group_by_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroup_by_check" ):
                listener.enterGroup_by_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroup_by_check" ):
                listener.exitGroup_by_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGroup_by_check" ):
                return visitor.visitGroup_by_check(self)
            else:
                return visitor.visitChildren(self)




    def group_by_check(self):

        localctx = SodaCLAntlrParser.Group_by_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_group_by_check)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 121
            self.match(SodaCLAntlrParser.T__3)
            self.state = 122
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Row_count_comparison_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,i)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def partition_name(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Partition_nameContext,0)


        def IN(self):
            return self.getToken(SodaCLAntlrParser.IN, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_row_count_comparison_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRow_count_comparison_check" ):
                listener.enterRow_count_comparison_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRow_count_comparison_check" ):
                listener.exitRow_count_comparison_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRow_count_comparison_check" ):
                return visitor.visitRow_count_comparison_check(self)
            else:
                return visitor.visitChildren(self)




    def row_count_comparison_check(self):

        localctx = SodaCLAntlrParser.Row_count_comparison_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_row_count_comparison_check)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 124
            self.match(SodaCLAntlrParser.T__4)
            self.state = 125
            self.match(SodaCLAntlrParser.S)
            self.state = 126
            self.identifier()
            self.state = 129
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.state = 127
                self.match(SodaCLAntlrParser.S)
                self.state = 128
                self.partition_name()


            self.state = 135
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==61:
                self.state = 131
                self.match(SodaCLAntlrParser.S)
                self.state = 132
                self.match(SodaCLAntlrParser.IN)
                self.state = 133
                self.match(SodaCLAntlrParser.S)
                self.state = 134
                self.identifier()


            self.state = 137
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Metric_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def metric(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.MetricContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def change_over_time(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Change_over_timeContext,0)


        def anomaly_score(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Anomaly_scoreContext,0)


        def anomaly_detection(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Anomaly_detectionContext,0)


        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def threshold(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.ThresholdContext,0)


        def default_anomaly_threshold(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Default_anomaly_thresholdContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric_check" ):
                listener.enterMetric_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric_check" ):
                listener.exitMetric_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric_check" ):
                return visitor.visitMetric_check(self)
            else:
                return visitor.visitChildren(self)




    def metric_check(self):

        localctx = SodaCLAntlrParser.Metric_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_metric_check)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 142
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [29]:
                self.state = 139
                self.change_over_time()
                pass
            elif token in [9]:
                self.state = 140
                self.anomaly_score()
                pass
            elif token in [10]:
                self.state = 141
                self.anomaly_detection()
                pass
            elif token in [31, 32, 33, 55, 56, 57, 58]:
                pass
            else:
                pass
            self.state = 144
            self.metric()
            self.state = 150
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==61:
                self.state = 145
                self.match(SodaCLAntlrParser.S)
                self.state = 148
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                if la_ == 1:
                    self.state = 146
                    self.threshold()
                    pass

                elif la_ == 2:
                    self.state = 147
                    self.default_anomaly_threshold()
                    pass




            self.state = 152
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Default_anomaly_thresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LT(self):
            return self.getToken(SodaCLAntlrParser.LT, 0)

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_default_anomaly_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefault_anomaly_threshold" ):
                listener.enterDefault_anomaly_threshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefault_anomaly_threshold" ):
                listener.exitDefault_anomaly_threshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefault_anomaly_threshold" ):
                return visitor.visitDefault_anomaly_threshold(self)
            else:
                return visitor.visitChildren(self)




    def default_anomaly_threshold(self):

        localctx = SodaCLAntlrParser.Default_anomaly_thresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_default_anomaly_threshold)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 154
            self.match(SodaCLAntlrParser.LT)
            self.state = 155
            self.match(SodaCLAntlrParser.S)
            self.state = 156
            self.match(SodaCLAntlrParser.T__5)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Change_over_timeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHANGE(self):
            return self.getToken(SodaCLAntlrParser.CHANGE, 0)

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def FOR(self):
            return self.getToken(SodaCLAntlrParser.FOR, 0)

        def change_over_time_config(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Change_over_time_configContext,0)


        def percent(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.PercentContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_change_over_time

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChange_over_time" ):
                listener.enterChange_over_time(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChange_over_time" ):
                listener.exitChange_over_time(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChange_over_time" ):
                return visitor.visitChange_over_time(self)
            else:
                return visitor.visitChildren(self)




    def change_over_time(self):

        localctx = SodaCLAntlrParser.Change_over_timeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_change_over_time)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.match(SodaCLAntlrParser.CHANGE)
            self.state = 159
            self.match(SodaCLAntlrParser.S)
            self.state = 163
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if ((_la) & ~0x3f) == 0 and ((1 << _la) & 15032385664) != 0:
                self.state = 160
                self.change_over_time_config()
                self.state = 161
                self.match(SodaCLAntlrParser.S)


            self.state = 166
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==8:
                self.state = 165
                self.percent()


            self.state = 168
            self.match(SodaCLAntlrParser.FOR)
            self.state = 169
            self.match(SodaCLAntlrParser.S)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Change_over_time_configContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def change_aggregation(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Change_aggregationContext,0)


        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def LAST(self):
            return self.getToken(SodaCLAntlrParser.LAST, 0)

        def integer(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IntegerContext,0)


        def same_day_last_week(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Same_day_last_weekContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_change_over_time_config

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChange_over_time_config" ):
                listener.enterChange_over_time_config(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChange_over_time_config" ):
                listener.exitChange_over_time_config(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChange_over_time_config" ):
                return visitor.visitChange_over_time_config(self)
            else:
                return visitor.visitChildren(self)




    def change_over_time_config(self):

        localctx = SodaCLAntlrParser.Change_over_time_configContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_change_over_time_config)
        try:
            self.state = 178
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [31, 32, 33]:
                self.enterOuterAlt(localctx, 1)
                self.state = 171
                self.change_aggregation()
                self.state = 172
                self.match(SodaCLAntlrParser.S)
                self.state = 173
                self.match(SodaCLAntlrParser.LAST)
                self.state = 174
                self.match(SodaCLAntlrParser.S)
                self.state = 175
                self.integer()
                pass
            elif token in [7]:
                self.enterOuterAlt(localctx, 2)
                self.state = 177
                self.same_day_last_week()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Change_aggregationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AVG(self):
            return self.getToken(SodaCLAntlrParser.AVG, 0)

        def MIN(self):
            return self.getToken(SodaCLAntlrParser.MIN, 0)

        def MAX(self):
            return self.getToken(SodaCLAntlrParser.MAX, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_change_aggregation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChange_aggregation" ):
                listener.enterChange_aggregation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChange_aggregation" ):
                listener.exitChange_aggregation(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChange_aggregation" ):
                return visitor.visitChange_aggregation(self)
            else:
                return visitor.visitChildren(self)




    def change_aggregation(self):

        localctx = SodaCLAntlrParser.Change_aggregationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_change_aggregation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 180
            _la = self._input.LA(1)
            if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 15032385536) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Same_day_last_weekContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_same_day_last_week

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSame_day_last_week" ):
                listener.enterSame_day_last_week(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSame_day_last_week" ):
                listener.exitSame_day_last_week(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSame_day_last_week" ):
                return visitor.visitSame_day_last_week(self)
            else:
                return visitor.visitChildren(self)




    def same_day_last_week(self):

        localctx = SodaCLAntlrParser.Same_day_last_weekContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_same_day_last_week)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 182
            self.match(SodaCLAntlrParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PercentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_percent

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPercent" ):
                listener.enterPercent(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPercent" ):
                listener.exitPercent(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPercent" ):
                return visitor.visitPercent(self)
            else:
                return visitor.visitChildren(self)




    def percent(self):

        localctx = SodaCLAntlrParser.PercentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_percent)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 184
            self.match(SodaCLAntlrParser.T__7)
            self.state = 185
            self.match(SodaCLAntlrParser.S)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Anomaly_scoreContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_anomaly_score

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAnomaly_score" ):
                listener.enterAnomaly_score(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAnomaly_score" ):
                listener.exitAnomaly_score(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAnomaly_score" ):
                return visitor.visitAnomaly_score(self)
            else:
                return visitor.visitChildren(self)




    def anomaly_score(self):

        localctx = SodaCLAntlrParser.Anomaly_scoreContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_anomaly_score)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 187
            self.match(SodaCLAntlrParser.T__8)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Anomaly_detectionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_anomaly_detection

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAnomaly_detection" ):
                listener.enterAnomaly_detection(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAnomaly_detection" ):
                listener.exitAnomaly_detection(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAnomaly_detection" ):
                return visitor.visitAnomaly_detection(self)
            else:
                return visitor.visitChildren(self)




    def anomaly_detection(self):

        localctx = SodaCLAntlrParser.Anomaly_detectionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_anomaly_detection)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 189
            self.match(SodaCLAntlrParser.T__9)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MetricContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def metric_name(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Metric_nameContext,0)


        def metric_args(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Metric_argsContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric" ):
                listener.enterMetric(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric" ):
                listener.exitMetric(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric" ):
                return visitor.visitMetric(self)
            else:
                return visitor.visitChildren(self)




    def metric(self):

        localctx = SodaCLAntlrParser.MetricContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_metric)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            self.metric_name()
            self.state = 193
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==38:
                self.state = 192
                self.metric_args()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Metric_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric_name" ):
                listener.enterMetric_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric_name" ):
                listener.exitMetric_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric_name" ):
                return visitor.visitMetric_name(self)
            else:
                return visitor.visitChildren(self)




    def metric_name(self):

        localctx = SodaCLAntlrParser.Metric_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_metric_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 195
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Metric_argsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ROUND_LEFT(self):
            return self.getToken(SodaCLAntlrParser.ROUND_LEFT, 0)

        def metric_arg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Metric_argContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Metric_argContext,i)


        def ROUND_RIGHT(self):
            return self.getToken(SodaCLAntlrParser.ROUND_RIGHT, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.COMMA)
            else:
                return self.getToken(SodaCLAntlrParser.COMMA, i)

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric_args

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric_args" ):
                listener.enterMetric_args(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric_args" ):
                listener.exitMetric_args(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric_args" ):
                return visitor.visitMetric_args(self)
            else:
                return visitor.visitChildren(self)




    def metric_args(self):

        localctx = SodaCLAntlrParser.Metric_argsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_metric_args)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 197
            self.match(SodaCLAntlrParser.ROUND_LEFT)
            self.state = 198
            self.metric_arg()
            self.state = 204
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==40:
                self.state = 199
                self.match(SodaCLAntlrParser.COMMA)
                self.state = 200
                self.match(SodaCLAntlrParser.S)
                self.state = 201
                self.metric_arg()
                self.state = 206
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 207
            self.match(SodaCLAntlrParser.ROUND_RIGHT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Metric_argContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def signed_number(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Signed_numberContext,0)


        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_metric_arg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetric_arg" ):
                listener.enterMetric_arg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetric_arg" ):
                listener.exitMetric_arg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetric_arg" ):
                return visitor.visitMetric_arg(self)
            else:
                return visitor.visitChildren(self)




    def metric_arg(self):

        localctx = SodaCLAntlrParser.Metric_argContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_metric_arg)
        try:
            self.state = 211
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [20, 42, 43, 60]:
                self.enterOuterAlt(localctx, 1)
                self.state = 209
                self.signed_number()
                pass
            elif token in [31, 32, 33, 55, 56, 57, 58]:
                self.enterOuterAlt(localctx, 2)
                self.state = 210
                self.identifier()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ThresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comparator_threshold(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Comparator_thresholdContext,0)


        def between_threshold(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Between_thresholdContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterThreshold" ):
                listener.enterThreshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitThreshold" ):
                listener.exitThreshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitThreshold" ):
                return visitor.visitThreshold(self)
            else:
                return visitor.visitChildren(self)




    def threshold(self):

        localctx = SodaCLAntlrParser.ThresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_threshold)
        try:
            self.state = 215
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [44, 45, 46, 47, 48, 49, 50]:
                self.enterOuterAlt(localctx, 1)
                self.state = 213
                self.comparator_threshold()
                pass
            elif token in [23, 24]:
                self.enterOuterAlt(localctx, 2)
                self.state = 214
                self.between_threshold()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Between_thresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BETWEEN(self):
            return self.getToken(SodaCLAntlrParser.BETWEEN, 0)

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def threshold_value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Threshold_valueContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Threshold_valueContext,i)


        def AND(self):
            return self.getToken(SodaCLAntlrParser.AND, 0)

        def NOT(self):
            return self.getToken(SodaCLAntlrParser.NOT, 0)

        def SQUARE_LEFT(self):
            return self.getToken(SodaCLAntlrParser.SQUARE_LEFT, 0)

        def ROUND_LEFT(self):
            return self.getToken(SodaCLAntlrParser.ROUND_LEFT, 0)

        def SQUARE_RIGHT(self):
            return self.getToken(SodaCLAntlrParser.SQUARE_RIGHT, 0)

        def ROUND_RIGHT(self):
            return self.getToken(SodaCLAntlrParser.ROUND_RIGHT, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_between_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBetween_threshold" ):
                listener.enterBetween_threshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBetween_threshold" ):
                listener.exitBetween_threshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBetween_threshold" ):
                return visitor.visitBetween_threshold(self)
            else:
                return visitor.visitChildren(self)




    def between_threshold(self):

        localctx = SodaCLAntlrParser.Between_thresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_between_threshold)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 219
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 217
                self.match(SodaCLAntlrParser.NOT)
                self.state = 218
                self.match(SodaCLAntlrParser.S)


            self.state = 221
            self.match(SodaCLAntlrParser.BETWEEN)
            self.state = 222
            self.match(SodaCLAntlrParser.S)
            self.state = 224
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==34 or _la==38:
                self.state = 223
                _la = self._input.LA(1)
                if not(_la==34 or _la==38):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 226
            self.threshold_value()
            self.state = 227
            self.match(SodaCLAntlrParser.S)
            self.state = 228
            self.match(SodaCLAntlrParser.AND)
            self.state = 229
            self.match(SodaCLAntlrParser.S)
            self.state = 230
            self.threshold_value()
            self.state = 232
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35 or _la==39:
                self.state = 231
                _la = self._input.LA(1)
                if not(_la==35 or _la==39):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Comparator_thresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comparator(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.ComparatorContext,0)


        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def threshold_value(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Threshold_valueContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_comparator_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparator_threshold" ):
                listener.enterComparator_threshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparator_threshold" ):
                listener.exitComparator_threshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparator_threshold" ):
                return visitor.visitComparator_threshold(self)
            else:
                return visitor.visitChildren(self)




    def comparator_threshold(self):

        localctx = SodaCLAntlrParser.Comparator_thresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_comparator_threshold)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 234
            self.comparator()
            self.state = 235
            self.match(SodaCLAntlrParser.S)
            self.state = 236
            self.threshold_value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Zones_thresholdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def outcome(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.OutcomeContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.OutcomeContext,i)


        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def zone_comparator(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Zone_comparatorContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Zone_comparatorContext,i)


        def threshold_value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Threshold_valueContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Threshold_valueContext,i)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_zones_threshold

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterZones_threshold" ):
                listener.enterZones_threshold(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitZones_threshold" ):
                listener.exitZones_threshold(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitZones_threshold" ):
                return visitor.visitZones_threshold(self)
            else:
                return visitor.visitChildren(self)




    def zones_threshold(self):

        localctx = SodaCLAntlrParser.Zones_thresholdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_zones_threshold)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 247 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 238
                    self.outcome()
                    self.state = 239
                    self.match(SodaCLAntlrParser.S)
                    self.state = 240
                    self.zone_comparator()
                    self.state = 241
                    self.match(SodaCLAntlrParser.S)
                    self.state = 242
                    self.threshold_value()
                    self.state = 243
                    self.match(SodaCLAntlrParser.S)
                    self.state = 244
                    self.zone_comparator()
                    self.state = 245
                    self.match(SodaCLAntlrParser.S)

                else:
                    raise NoViableAltException(self)
                self.state = 249 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,18,self._ctx)

            self.state = 251
            self.outcome()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OutcomeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WARN(self):
            return self.getToken(SodaCLAntlrParser.WARN, 0)

        def FAIL(self):
            return self.getToken(SodaCLAntlrParser.FAIL, 0)

        def PASS(self):
            return self.getToken(SodaCLAntlrParser.PASS, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_outcome

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOutcome" ):
                listener.enterOutcome(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOutcome" ):
                listener.exitOutcome(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOutcome" ):
                return visitor.visitOutcome(self)
            else:
                return visitor.visitChildren(self)




    def outcome(self):

        localctx = SodaCLAntlrParser.OutcomeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_outcome)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 253
            _la = self._input.LA(1)
            if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 469762048) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Zone_comparatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LT(self):
            return self.getToken(SodaCLAntlrParser.LT, 0)

        def LTE(self):
            return self.getToken(SodaCLAntlrParser.LTE, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_zone_comparator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterZone_comparator" ):
                listener.enterZone_comparator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitZone_comparator" ):
                listener.exitZone_comparator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitZone_comparator" ):
                return visitor.visitZone_comparator(self)
            else:
                return visitor.visitChildren(self)




    def zone_comparator(self):

        localctx = SodaCLAntlrParser.Zone_comparatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_zone_comparator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 255
            _la = self._input.LA(1)
            if not(_la==46 or _la==49):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LT(self):
            return self.getToken(SodaCLAntlrParser.LT, 0)

        def LTE(self):
            return self.getToken(SodaCLAntlrParser.LTE, 0)

        def EQUAL(self):
            return self.getToken(SodaCLAntlrParser.EQUAL, 0)

        def GTE(self):
            return self.getToken(SodaCLAntlrParser.GTE, 0)

        def GT(self):
            return self.getToken(SodaCLAntlrParser.GT, 0)

        def NOT_EQUAL(self):
            return self.getToken(SodaCLAntlrParser.NOT_EQUAL, 0)

        def NOT_EQUAL_SQL(self):
            return self.getToken(SodaCLAntlrParser.NOT_EQUAL_SQL, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_comparator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparator" ):
                listener.enterComparator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparator" ):
                listener.exitComparator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparator" ):
                return visitor.visitComparator(self)
            else:
                return visitor.visitChildren(self)




    def comparator(self):

        localctx = SodaCLAntlrParser.ComparatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_comparator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 257
            _la = self._input.LA(1)
            if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 2234207627640832) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Threshold_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def signed_number(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Signed_numberContext,0)


        def PERCENT(self):
            return self.getToken(SodaCLAntlrParser.PERCENT, 0)

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def freshness_threshold_value(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Freshness_threshold_valueContext,0)


        def IDENTIFIER_UNQUOTED(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_UNQUOTED, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_threshold_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterThreshold_value" ):
                listener.enterThreshold_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitThreshold_value" ):
                listener.exitThreshold_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitThreshold_value" ):
                return visitor.visitThreshold_value(self)
            else:
                return visitor.visitChildren(self)




    def threshold_value(self):

        localctx = SodaCLAntlrParser.Threshold_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_threshold_value)
        self._la = 0 # Token type
        try:
            self.state = 268
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [20, 42, 43, 60]:
                self.enterOuterAlt(localctx, 1)
                self.state = 259
                self.signed_number()
                self.state = 264
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
                if la_ == 1:
                    self.state = 261
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==61:
                        self.state = 260
                        self.match(SodaCLAntlrParser.S)


                    self.state = 263
                    self.match(SodaCLAntlrParser.PERCENT)


                pass
            elif token in [51]:
                self.enterOuterAlt(localctx, 2)
                self.state = 266
                self.freshness_threshold_value()
                pass
            elif token in [57]:
                self.enterOuterAlt(localctx, 3)
                self.state = 267
                self.match(SodaCLAntlrParser.IDENTIFIER_UNQUOTED)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Freshness_threshold_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TIMEUNIT(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.TIMEUNIT)
            else:
                return self.getToken(SodaCLAntlrParser.TIMEUNIT, i)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_freshness_threshold_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFreshness_threshold_value" ):
                listener.enterFreshness_threshold_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFreshness_threshold_value" ):
                listener.exitFreshness_threshold_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFreshness_threshold_value" ):
                return visitor.visitFreshness_threshold_value(self)
            else:
                return visitor.visitChildren(self)




    def freshness_threshold_value(self):

        localctx = SodaCLAntlrParser.Freshness_threshold_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_freshness_threshold_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 271 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 270
                self.match(SodaCLAntlrParser.TIMEUNIT)
                self.state = 273 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==51):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Reference_checkContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def source_column_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Source_column_nameContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Source_column_nameContext,i)


        def reference_must_exist(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Reference_must_existContext,0)


        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def target_column_name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SodaCLAntlrParser.Target_column_nameContext)
            else:
                return self.getTypedRuleContext(SodaCLAntlrParser.Target_column_nameContext,i)


        def ROUND_LEFT(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.ROUND_LEFT)
            else:
                return self.getToken(SodaCLAntlrParser.ROUND_LEFT, i)

        def ROUND_RIGHT(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.ROUND_RIGHT)
            else:
                return self.getToken(SodaCLAntlrParser.ROUND_RIGHT, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.COMMA)
            else:
                return self.getToken(SodaCLAntlrParser.COMMA, i)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_reference_check

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReference_check" ):
                listener.enterReference_check(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReference_check" ):
                listener.exitReference_check(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReference_check" ):
                return visitor.visitReference_check(self)
            else:
                return visitor.visitChildren(self)




    def reference_check(self):

        localctx = SodaCLAntlrParser.Reference_checkContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_reference_check)
        self._la = 0 # Token type
        try:
            self.state = 315
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 275
                self.match(SodaCLAntlrParser.T__10)
                self.state = 276
                self.match(SodaCLAntlrParser.S)
                self.state = 277
                self.source_column_name()
                self.state = 278
                self.match(SodaCLAntlrParser.S)
                self.state = 279
                self.reference_must_exist()
                self.state = 280
                self.match(SodaCLAntlrParser.S)
                self.state = 281
                self.identifier()
                self.state = 282
                self.match(SodaCLAntlrParser.S)
                self.state = 283
                self.target_column_name()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 285
                self.match(SodaCLAntlrParser.T__10)
                self.state = 286
                self.match(SodaCLAntlrParser.S)
                self.state = 287
                self.match(SodaCLAntlrParser.ROUND_LEFT)
                self.state = 288
                self.source_column_name()
                self.state = 294
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==40:
                    self.state = 289
                    self.match(SodaCLAntlrParser.COMMA)
                    self.state = 290
                    self.match(SodaCLAntlrParser.S)
                    self.state = 291
                    self.source_column_name()
                    self.state = 296
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 297
                self.match(SodaCLAntlrParser.ROUND_RIGHT)
                self.state = 298
                self.match(SodaCLAntlrParser.S)
                self.state = 299
                self.reference_must_exist()
                self.state = 300
                self.match(SodaCLAntlrParser.S)
                self.state = 301
                self.identifier()
                self.state = 302
                self.match(SodaCLAntlrParser.S)
                self.state = 303
                self.match(SodaCLAntlrParser.ROUND_LEFT)
                self.state = 304
                self.target_column_name()
                self.state = 310
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==40:
                    self.state = 305
                    self.match(SodaCLAntlrParser.COMMA)
                    self.state = 306
                    self.match(SodaCLAntlrParser.S)
                    self.state = 307
                    self.target_column_name()
                    self.state = 312
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 313
                self.match(SodaCLAntlrParser.ROUND_RIGHT)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Reference_must_existContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def NOT(self):
            return self.getToken(SodaCLAntlrParser.NOT, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_reference_must_exist

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReference_must_exist" ):
                listener.enterReference_must_exist(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReference_must_exist" ):
                listener.exitReference_must_exist(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReference_must_exist" ):
                return visitor.visitReference_must_exist(self)
            else:
                return visitor.visitChildren(self)




    def reference_must_exist(self):

        localctx = SodaCLAntlrParser.Reference_must_existContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_reference_must_exist)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 317
            self.match(SodaCLAntlrParser.T__11)
            self.state = 318
            self.match(SodaCLAntlrParser.S)
            self.state = 321
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 319
                self.match(SodaCLAntlrParser.NOT)
                self.state = 320
                self.match(SodaCLAntlrParser.S)


            self.state = 323
            self.match(SodaCLAntlrParser.T__12)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Source_column_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_source_column_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSource_column_name" ):
                listener.enterSource_column_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSource_column_name" ):
                listener.exitSource_column_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSource_column_name" ):
                return visitor.visitSource_column_name(self)
            else:
                return visitor.visitChildren(self)




    def source_column_name(self):

        localctx = SodaCLAntlrParser.Source_column_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_source_column_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 325
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Target_column_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_target_column_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTarget_column_name" ):
                listener.enterTarget_column_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTarget_column_name" ):
                listener.exitTarget_column_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTarget_column_name" ):
                return visitor.visitTarget_column_name(self)
            else:
                return visitor.visitChildren(self)




    def target_column_name(self):

        localctx = SodaCLAntlrParser.Target_column_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_target_column_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 327
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Section_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def table_checks_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Table_checks_headerContext,0)


        def column_configurations_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Column_configurations_headerContext,0)


        def table_filter_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Table_filter_headerContext,0)


        def checks_for_each_dataset_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Checks_for_each_dataset_headerContext,0)


        def checks_for_each_column_header(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Checks_for_each_column_headerContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_section_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSection_header" ):
                listener.enterSection_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSection_header" ):
                listener.exitSection_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSection_header" ):
                return visitor.visitSection_header(self)
            else:
                return visitor.visitChildren(self)




    def section_header(self):

        localctx = SodaCLAntlrParser.Section_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_section_header)
        try:
            self.state = 334
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [14]:
                self.enterOuterAlt(localctx, 1)
                self.state = 329
                self.table_checks_header()
                pass
            elif token in [16]:
                self.enterOuterAlt(localctx, 2)
                self.state = 330
                self.column_configurations_header()
                pass
            elif token in [15]:
                self.enterOuterAlt(localctx, 3)
                self.state = 331
                self.table_filter_header()
                pass
            elif token in [17, 18]:
                self.enterOuterAlt(localctx, 4)
                self.state = 332
                self.checks_for_each_dataset_header()
                pass
            elif token in [19]:
                self.enterOuterAlt(localctx, 5)
                self.state = 333
                self.checks_for_each_column_header()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Table_checks_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def partition_name(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Partition_nameContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_table_checks_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTable_checks_header" ):
                listener.enterTable_checks_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTable_checks_header" ):
                listener.exitTable_checks_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTable_checks_header" ):
                return visitor.visitTable_checks_header(self)
            else:
                return visitor.visitChildren(self)




    def table_checks_header(self):

        localctx = SodaCLAntlrParser.Table_checks_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_table_checks_header)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 336
            self.match(SodaCLAntlrParser.T__13)
            self.state = 337
            self.match(SodaCLAntlrParser.S)
            self.state = 338
            self.identifier()
            self.state = 341
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==61:
                self.state = 339
                self.match(SodaCLAntlrParser.S)
                self.state = 340
                self.partition_name()


            self.state = 343
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Partition_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_partition_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPartition_name" ):
                listener.enterPartition_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPartition_name" ):
                listener.exitPartition_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPartition_name" ):
                return visitor.visitPartition_name(self)
            else:
                return visitor.visitChildren(self)




    def partition_name(self):

        localctx = SodaCLAntlrParser.Partition_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_partition_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 345
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Table_filter_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.S)
            else:
                return self.getToken(SodaCLAntlrParser.S, i)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def partition_name(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.Partition_nameContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_table_filter_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTable_filter_header" ):
                listener.enterTable_filter_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTable_filter_header" ):
                listener.exitTable_filter_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTable_filter_header" ):
                return visitor.visitTable_filter_header(self)
            else:
                return visitor.visitChildren(self)




    def table_filter_header(self):

        localctx = SodaCLAntlrParser.Table_filter_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_table_filter_header)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 347
            self.match(SodaCLAntlrParser.T__14)
            self.state = 348
            self.match(SodaCLAntlrParser.S)
            self.state = 349
            self.identifier()
            self.state = 350
            self.match(SodaCLAntlrParser.S)
            self.state = 351
            self.partition_name()
            self.state = 352
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Column_configurations_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_column_configurations_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterColumn_configurations_header" ):
                listener.enterColumn_configurations_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitColumn_configurations_header" ):
                listener.exitColumn_configurations_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitColumn_configurations_header" ):
                return visitor.visitColumn_configurations_header(self)
            else:
                return visitor.visitChildren(self)




    def column_configurations_header(self):

        localctx = SodaCLAntlrParser.Column_configurations_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_column_configurations_header)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 354
            self.match(SodaCLAntlrParser.T__15)
            self.state = 355
            self.match(SodaCLAntlrParser.S)
            self.state = 356
            self.identifier()
            self.state = 357
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Checks_for_each_dataset_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_checks_for_each_dataset_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChecks_for_each_dataset_header" ):
                listener.enterChecks_for_each_dataset_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChecks_for_each_dataset_header" ):
                listener.exitChecks_for_each_dataset_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChecks_for_each_dataset_header" ):
                return visitor.visitChecks_for_each_dataset_header(self)
            else:
                return visitor.visitChildren(self)




    def checks_for_each_dataset_header(self):

        localctx = SodaCLAntlrParser.Checks_for_each_dataset_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_checks_for_each_dataset_header)
        try:
            self.state = 369
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [17]:
                self.enterOuterAlt(localctx, 1)
                self.state = 359
                self.match(SodaCLAntlrParser.T__16)
                self.state = 360
                self.match(SodaCLAntlrParser.S)
                self.state = 361
                self.identifier()
                self.state = 362
                self.match(SodaCLAntlrParser.EOF)
                pass
            elif token in [18]:
                self.enterOuterAlt(localctx, 2)
                self.state = 364
                self.match(SodaCLAntlrParser.T__17)
                self.state = 365
                self.match(SodaCLAntlrParser.S)
                self.state = 366
                self.identifier()
                self.state = 367
                self.match(SodaCLAntlrParser.EOF)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Checks_for_each_column_headerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def S(self):
            return self.getToken(SodaCLAntlrParser.S, 0)

        def identifier(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IdentifierContext,0)


        def EOF(self):
            return self.getToken(SodaCLAntlrParser.EOF, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_checks_for_each_column_header

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterChecks_for_each_column_header" ):
                listener.enterChecks_for_each_column_header(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitChecks_for_each_column_header" ):
                listener.exitChecks_for_each_column_header(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitChecks_for_each_column_header" ):
                return visitor.visitChecks_for_each_column_header(self)
            else:
                return visitor.visitChildren(self)




    def checks_for_each_column_header(self):

        localctx = SodaCLAntlrParser.Checks_for_each_column_headerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_checks_for_each_column_header)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 371
            self.match(SodaCLAntlrParser.T__18)
            self.state = 372
            self.match(SodaCLAntlrParser.S)
            self.state = 373
            self.identifier()
            self.state = 374
            self.match(SodaCLAntlrParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Signed_numberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.NumberContext,0)


        def PLUS(self):
            return self.getToken(SodaCLAntlrParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(SodaCLAntlrParser.MINUS, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_signed_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSigned_number" ):
                listener.enterSigned_number(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSigned_number" ):
                listener.exitSigned_number(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSigned_number" ):
                return visitor.visitSigned_number(self)
            else:
                return visitor.visitChildren(self)




    def signed_number(self):

        localctx = SodaCLAntlrParser.Signed_numberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_signed_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 377
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==42 or _la==43:
                self.state = 376
                _la = self._input.LA(1)
                if not(_la==42 or _la==43):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 379
            self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def integer(self):
            return self.getTypedRuleContext(SodaCLAntlrParser.IntegerContext,0)


        def DIGITS(self, i:int=None):
            if i is None:
                return self.getTokens(SodaCLAntlrParser.DIGITS)
            else:
                return self.getToken(SodaCLAntlrParser.DIGITS, i)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)




    def number(self):

        localctx = SodaCLAntlrParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.state = 392
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 381
                self.integer()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 382
                self.match(SodaCLAntlrParser.DIGITS)
                self.state = 383
                self.match(SodaCLAntlrParser.T__19)
                self.state = 385
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==60:
                    self.state = 384
                    self.match(SodaCLAntlrParser.DIGITS)


                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 388
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==60:
                    self.state = 387
                    self.match(SodaCLAntlrParser.DIGITS)


                self.state = 390
                self.match(SodaCLAntlrParser.T__19)
                self.state = 391
                self.match(SodaCLAntlrParser.DIGITS)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntegerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DIGITS(self):
            return self.getToken(SodaCLAntlrParser.DIGITS, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_integer

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInteger" ):
                listener.enterInteger(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInteger" ):
                listener.exitInteger(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInteger" ):
                return visitor.visitInteger(self)
            else:
                return visitor.visitChildren(self)




    def integer(self):

        localctx = SodaCLAntlrParser.IntegerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_integer)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 394
            self.match(SodaCLAntlrParser.DIGITS)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER_UNQUOTED(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_UNQUOTED, 0)

        def IDENTIFIER_DOUBLE_QUOTE(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_DOUBLE_QUOTE, 0)

        def IDENTIFIER_BACKTICK(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_BACKTICK, 0)

        def IDENTIFIER_SQUARE_BRACKETS(self):
            return self.getToken(SodaCLAntlrParser.IDENTIFIER_SQUARE_BRACKETS, 0)

        def MIN(self):
            return self.getToken(SodaCLAntlrParser.MIN, 0)

        def MAX(self):
            return self.getToken(SodaCLAntlrParser.MAX, 0)

        def AVG(self):
            return self.getToken(SodaCLAntlrParser.AVG, 0)

        def getRuleIndex(self):
            return SodaCLAntlrParser.RULE_identifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier" ):
                listener.enterIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier" ):
                listener.exitIdentifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifier" ):
                return visitor.visitIdentifier(self)
            else:
                return visitor.visitChildren(self)




    def identifier(self):

        localctx = SodaCLAntlrParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_identifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 396
            _la = self._input.LA(1)
            if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 540431970316845056) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





