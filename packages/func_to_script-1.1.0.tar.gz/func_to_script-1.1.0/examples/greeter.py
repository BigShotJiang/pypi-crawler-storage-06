from examples.say_hello_script import say_hello


def main():
    say_hello(print_message=True)


if __name__ == "__main__":
    main()
