from func_to_script.core import script
from func_to_script.config_loader import load_config_from_yaml

from . import _version
__version__ = _version.get_versions()['version']
