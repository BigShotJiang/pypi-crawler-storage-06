============
Installation
============

Install using `pip` with::

    pip install pybedlite

Or install using `mamba` with::

    mamba install -c conda-forge -c bioconda pybedlite
