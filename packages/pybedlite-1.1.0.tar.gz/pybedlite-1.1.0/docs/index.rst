=========
pybedlite
=========


:Date: |today|
:Version: |version|

Documentation Contents
======================

.. toctree::
   :maxdepth: 2

   api.rst
   installation.rst

