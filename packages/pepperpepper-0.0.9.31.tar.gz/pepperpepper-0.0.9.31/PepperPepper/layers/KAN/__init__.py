# KAN 包
# 功能：包含自定义的KAN神经网络层或模块。
# 子模块/文件：



from .KANLinear import KANLinear

__all__ = ['KANLinear']











