# from .datasets import TestSetLoader, TrainSetLoader, TestSetLoaderV2, TrainSetLoaderV2, TestSetLoaderV3, TrainSetLoaderV3
#
# __all__ = ['TestSetLoader', 'TrainSetLoader', 'TestSetLoaderV2', 'TrainSetLoaderV2', 'TestSetLoaderV3', 'TrainSetLoaderV3']

from .datasets import DataSetLoader

__all__ = ['DataSetLoader']