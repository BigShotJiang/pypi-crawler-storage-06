import setuptools


setuptools.setup(
    name="PepperPepper",
    version="0.0.9.31",
    python_requires='>=3.7',
    author="Aohua Li",
    author_email="liah24@mails.jlu.edu.cn",
    description="It is a Deeplearning package to foster developed by Aohua Li",
    url="",
    packages=setuptools.find_packages(),
    zip_safe=True,
    # install_requires=requirements,
)











