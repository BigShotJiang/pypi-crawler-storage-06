# Paper

## Diagram

- publish https://lucid.app/lucidchart/78d834bb-4394-4bc9-826f-c8ff95205578/view
- editable share: https://lucid.app/lucidchart/78d834bb-4394-4bc9-826f-c8ff95205578/edit?viewport_loc=2505%2C1325%2C6165%2C4146%2C0_0&invitationId=inv_d20a2bb9-0fe2-4e5a-b18b-a4a5fc34dfa6