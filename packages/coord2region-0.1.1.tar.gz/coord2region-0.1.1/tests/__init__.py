"""Test suite for the Coord2Region package.

This package aggregates unit tests that verify coordinate-to-region
mapping utilities and related file handling functionality.
"""