# Developer Guide

For information on contributing to Coord2Region, see the [Contributing guide](CONTRIBUTING.md).
