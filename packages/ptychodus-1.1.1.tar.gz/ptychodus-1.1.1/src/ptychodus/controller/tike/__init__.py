from .core import TikeViewControllerFactory

__all__ = [
    'TikeViewControllerFactory',
]
