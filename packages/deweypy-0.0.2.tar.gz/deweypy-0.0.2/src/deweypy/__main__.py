from __future__ import annotations

from .main import app

app()
