"""
Tests package for AutoWaterQualityModeler
"""