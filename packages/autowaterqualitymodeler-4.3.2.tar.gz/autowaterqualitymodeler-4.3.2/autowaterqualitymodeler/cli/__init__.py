"""
命令行接口模块
"""

from .commands import main

__all__ = ['main']