# zutil

[![PyPI version fury.io](https://badge.fury.io/py/zutil.svg)](https://pypi.python.org/pypi/zutil/)

Note: This library sets Paraview compatibility to version >= 5.4
