# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._f1_score import F1ScoreEvaluator

__all__ = [
    "F1ScoreEvaluator",
]
