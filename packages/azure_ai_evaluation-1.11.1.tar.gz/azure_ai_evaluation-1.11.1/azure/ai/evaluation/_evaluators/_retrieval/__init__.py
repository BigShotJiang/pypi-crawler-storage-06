# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._retrieval import RetrievalEvaluator

__all__ = [
    "RetrievalEvaluator",
]
