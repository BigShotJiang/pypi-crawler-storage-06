=====
Usage
=====

To use Shoestring Assembler in a project::

    import shoestring_assembler
