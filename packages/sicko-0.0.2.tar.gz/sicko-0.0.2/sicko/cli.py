"""
Sicko CLI
"""


def main() -> None:
    """
    entrypoint
    """
    print("sicko works!")
