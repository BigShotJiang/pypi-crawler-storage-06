# sicko-py

sicko mode python developer experience
