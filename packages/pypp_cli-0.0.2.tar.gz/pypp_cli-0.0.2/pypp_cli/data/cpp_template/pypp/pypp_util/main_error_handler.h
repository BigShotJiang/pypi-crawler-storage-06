#pragma once

namespace pypp {

void handle_fatal_exception();

} // namespace pypp