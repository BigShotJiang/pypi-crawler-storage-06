#pragma once

#include "py_str.h"

namespace pypp {
PyStr res_dir();
} // namespace pypp