from ..file import File


class RubyFile(File): ...
