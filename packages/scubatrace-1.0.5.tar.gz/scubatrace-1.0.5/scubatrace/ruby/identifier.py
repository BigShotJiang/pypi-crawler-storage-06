from ..identifier import Identifier


class RubyIdentifier(Identifier): ...
