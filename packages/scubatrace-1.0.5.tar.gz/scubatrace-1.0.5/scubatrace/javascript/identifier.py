from ..identifier import Identifier


class JavaScriptIdentifier(Identifier): ...
