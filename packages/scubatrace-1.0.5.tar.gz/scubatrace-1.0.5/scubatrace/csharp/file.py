from ..file import File


class CSharpFile(File): ...
