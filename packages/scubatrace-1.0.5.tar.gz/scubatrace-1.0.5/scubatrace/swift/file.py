from ..file import File


class SwiftFile(File): ...
