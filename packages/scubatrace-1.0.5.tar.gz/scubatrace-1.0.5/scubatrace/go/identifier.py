from ..identifier import Identifier


class GoIdentifier(Identifier): ...
