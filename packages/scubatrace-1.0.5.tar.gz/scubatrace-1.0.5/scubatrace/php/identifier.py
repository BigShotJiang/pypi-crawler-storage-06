from ..identifier import Identifier


class PHPIdentifier(Identifier): ...
