from ..identifier import Identifier


class RustIdentifier(Identifier): ...
