from snowflake.cli._plugins.spcs.image_repository.image_repository_entity_model import (
    ImageRepositoryEntityModel,
)
from snowflake.cli.api.entities.common import EntityBase


class ImageRepositoryEntity(EntityBase[ImageRepositoryEntityModel]):
    pass
