=====
Usage
=====

To use chibi_requests in a project::

    import chibi_requests
