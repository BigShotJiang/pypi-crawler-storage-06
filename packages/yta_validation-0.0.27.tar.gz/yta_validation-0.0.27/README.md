# Youtube Autonomous Validation add-on

The way to validate the python parameters and arguments.