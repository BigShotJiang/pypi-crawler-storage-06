API
===

.. autosummary::
        :toctree: generated

        spinenet
        spinenet.io
        spinenet.SpineNet
