﻿spinenet.SpineNet
=================

.. currentmodule:: spinenet

.. autoclass:: SpineNet

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SpineNet.__init__
      ~SpineNet.detect_vb
      ~SpineNet.get_ivds_from_vert_dicts
      ~SpineNet.grade_ivds
   
   

   
   
   