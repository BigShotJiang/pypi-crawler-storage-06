# brightdata/scrapers/instagram/__init__.py
from .scraper import InstagramScraper   # ← adjust the filename if needed

__all__ = ["InstagramScraper"]
