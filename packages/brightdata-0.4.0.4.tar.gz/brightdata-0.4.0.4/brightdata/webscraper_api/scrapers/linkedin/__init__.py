# brightdata/scrapers/linkedin/__init__.py
from .scraper import LinkedInScraper   # ← adjust the filename if needed

__all__ = ["LinkedInScraper"]
