# brightdata/scrapers/digikey/__init__.py
from .scraper import DigikeyScraper   # ← adjust the filename if needed

__all__ = ["DigikeyScraper"]
