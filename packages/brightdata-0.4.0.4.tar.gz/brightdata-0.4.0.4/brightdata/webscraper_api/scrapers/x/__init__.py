# brightdata/scrapers/x/__init__.py
from .scraper import XScraper   # ← adjust the filename if needed

__all__ = ["XScraper"]
