"""
Configuration management for DeepBridge.
"""

from deepbridge.config.settings import DistillationConfig

__all__ = ["DistillationConfig"]