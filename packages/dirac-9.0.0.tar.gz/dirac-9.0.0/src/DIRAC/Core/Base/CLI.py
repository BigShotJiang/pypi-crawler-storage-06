########################################################################
# File :   CLI.py
# Author : Andrei Tsaregorodtsev
########################################################################

""" CLI is the base class for all the DIRAC consoles ( CLIs ). It contains
    several utilities and signal handlers of general purpose.
"""

import cmd
import sys
import os
import signal

from DIRAC import gLogger

gColors = {"red": 1, "green": 2, "yellow": 3, "blue": 4}


def colorEnabled():
    return os.environ.get("TERM") in ("xterm", "xterm-color")


def colorize(text, color):
    """Return colorized text"""
    if not colorEnabled():
        return text

    startCode = "\033[;3"
    endCode = "\033[0m"
    if isinstance(color, int):
        return f"{startCode}{color}m{text}{endCode}"
    try:
        return f"{startCode}{gColors[color]}m{text}{endCode}"
    except Exception:
        return text


class CLI(cmd.Cmd):
    def __init__(self):
        cmd.Cmd.__init__(self)
        self.indentSpace = 20
        self._initSignals()

    def _handleSignal(self, sig, frame):
        print("\nReceived signal", sig, ", exiting ...")
        self.do_quit(self)

    def _initSignals(self):
        """
        Registers signal handlers
        """
        for sigNum in (signal.SIGINT, signal.SIGQUIT, signal.SIGKILL, signal.SIGTERM):
            try:
                signal.signal(sigNum, self._handleSignal)
            except Exception:
                pass

    def _errMsg(self, errMsg):
        """
        Print out a colorized error log message

        :param str errMsg: error message string
        :return: nothing
        """
        gLogger.error(f"{colorize('[ERROR]', 'red')} {errMsg}")

    def emptyline(self):
        pass

    def do_exit(self, args):
        """Exit the shell.

        usage: exit
        """
        self.do_quit(self)

    def do_quit(self, args):
        """Exit the shell.

        usage: quit
        """
        gLogger.notice("")
        sys.exit(0)

    def do_EOF(self, args):
        """Handler for EOF ( Ctrl D ) signal - perform quit"""
        self.do_quit(args)

    def do_execfile(self, args):
        """Execute a series of CLI commands from a given file

        usage:

          execfile <filename>
        """

        argss = args.split()
        fname = argss[0]
        if not os.path.exists(fname):
            print(f"Error: File not found {fname}")
            return
        with open(fname) as input_cmd:
            contents = input_cmd.readlines()
        for line in contents:
            try:
                gLogger.notice(f"\n--> Executing {line}\n")
                self.onecmd(line)
            except Exception as error:
                self._errMsg(str(error))
                break
        return

    def printPair(self, key, value, separator=":"):
        valueList = value.split("\n")
        print(f"{key}{' ' * (self.indentSpace - len(key))}{separator} {valueList[0].strip()}")
        for valueLine in valueList[1:-1]:
            print(f"{' ' * self.indentSpace}  {valueLine.strip()}")

    def do_help(self, args):
        """
        Shows help information
            Usage: help <command>
            If no command is specified all commands are shown
        """
        if len(args) == 0:
            print("\nAvailable commands:\n")
            attrList = sorted(dir(self))
            for attribute in attrList:
                if attribute.startswith("do_"):
                    self.printPair(attribute[3:], getattr(self, attribute).__doc__)
                    print("")
        else:
            command = args.split()[0].strip()
            try:
                obj = getattr(self, f"do_{command}")
            except Exception:
                print(f"There's no such {command} command")
                return
            self.printPair(command, obj.__doc__[1:])
