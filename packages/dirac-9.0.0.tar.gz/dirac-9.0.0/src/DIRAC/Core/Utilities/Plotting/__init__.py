from DIRAC.Core.Utilities.Plotting.DataCache import DataCache

gDataCache = DataCache()
