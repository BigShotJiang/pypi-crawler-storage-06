"""
   DIRAC.DataManagementSystem.Agent package
"""
