Command line reference
======================

.. click:: fromager.__main__:main
  :prog: fromager
  :nested: full
