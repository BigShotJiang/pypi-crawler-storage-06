# Lazygit Code of Conduct

Be nice, or face the wrath of the maintainer.
