# lazygit-py

https://github.com/jesseduffield/lazygit

**lazygit** is a simple terminal UI for git commands. see original [repository](https://github.com/jesseduffield/lazygit) for more information.

![image](https://github.com/jesseduffield/lazygit/blob/assets/demo/commit_and_push-compressed.gif?raw=true)

This is a python wrapper that can be installed with pip.

## install

```sh
pip install lazygit-py
```
