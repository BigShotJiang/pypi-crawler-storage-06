# Installation

Installation covers Prerequisites, Set up a virtual environment, Install Flarchitect.

## Sections

- [Prerequisites](prerequisites.md)
- [Set up a virtual environment](set-up-a-virtual-environment.md)
- [Install Flarchitect](install-flarchitect.md)
- [Verify the installation](verify-the-installation.md)
