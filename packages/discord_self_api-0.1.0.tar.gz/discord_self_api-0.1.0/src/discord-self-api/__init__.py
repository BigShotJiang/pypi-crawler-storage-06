"""
discord.py-selfbot - A cross-platform Discord selfbot API wrapper that works on Termux and other platforms.

WARNING: Selfbots violate Discord's Terms of Service. Use at your own risk.
"""

from .client import Client
from .models import User, Message, Channel, Guild

__version__ = "0.1.0"
__author__ = "Zombie"
__license__ = "MIT"

__all__ = ['Client', 'User', 'Message', 'Channel', 'Guild']