"""Configuration subpackage (YAML configs included as package data)."""

