"""VampPrior components for BioBatchNet models."""

