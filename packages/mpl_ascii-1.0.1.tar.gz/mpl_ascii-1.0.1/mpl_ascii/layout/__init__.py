"""
Figures out where things should go on the screen by converting coordinates into the space used for rendering.
"""