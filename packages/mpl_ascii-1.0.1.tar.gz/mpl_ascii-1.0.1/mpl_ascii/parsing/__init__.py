"""
Takes a figure from Matplotlib and breaks it down into a format this system can understand and work with.
"""