"""
Describes everything that could appear in the final image — like points, lines, and axes — and how they're connected.
"""