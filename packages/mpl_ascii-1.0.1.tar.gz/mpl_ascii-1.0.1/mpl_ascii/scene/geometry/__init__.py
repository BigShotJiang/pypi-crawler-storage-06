"""
Handles the basic math for working with positions, sizes, and transformations in 2D space.
"""