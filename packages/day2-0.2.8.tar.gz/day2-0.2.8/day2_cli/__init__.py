"""MontyCloud DAY2 CLI."""

from day2_cli.cli import main

__all__ = ["main"]
