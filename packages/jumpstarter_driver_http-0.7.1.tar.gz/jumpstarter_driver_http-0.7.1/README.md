# HTTP driver

`jumpstarter-driver-http` provides functionality for HTTP communication.

## Installation

```{code-block} console
:substitutions:
$ pip3 install --extra-index-url {{index_url}} jumpstarter-driver-http
```

## Configuration

Example configuration:

```yaml
export:
  http:
    type: jumpstarter_driver_http.driver.HttpServer
    config:
      # Add required config parameters here
```

## API Reference

Add API documentation here.
