1.  Go to Invoicing/Accounting \> Configuration \> Settings.
2.  On the fields "Initiating Party Issuer" and "Initiating Party
    Identifier", in the section *SEPA/PAIN*, you can fill the
    corresponding identifiers.

If your country requires several identifiers (like Spain), you must:

1.  Go to *Invoicing/Accounting \> Configuration \> Settings*.
2.  On the section *SEPA/PAIN*, check the mark "Multiple identifiers".
3.  Now go to *Invoicing/Accounting \> Configuration \> Management \>
    Payment Methods*.
4.  Create or activate a payment method for your specific bank.
5.  Fill the specific identifiers on the fields *Initiating Party
    Identifier* and *Initiating Party Issuer*.
