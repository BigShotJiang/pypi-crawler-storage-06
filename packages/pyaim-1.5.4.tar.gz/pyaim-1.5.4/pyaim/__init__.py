"""
Main module
This metafile includes all the functionality that will be exposed
when you install this module
"""

from .aimcp import CLIPasswordSDK
from .aimccp import CCPPasswordREST
