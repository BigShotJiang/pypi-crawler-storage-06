/* SPDX-FileCopyrightText: © 2022-2024 Decompollaborate */
/* SPDX-License-Identifier: MIT */

/* Automatically generated. DO NOT MODIFY */

#ifndef InstrSuffix_enum_h_automatic
#define InstrSuffix_enum_h_automatic

typedef enum RabbitizerInstrSuffix {
    RABINSTRSUFFIX_ALL_NONE,
    RABINSTRSUFFIX_R5900_xyzw,
    RABINSTRSUFFIX_ALL_MAX,
} RabbitizerInstrSuffix;

#endif
