/* SPDX-FileCopyrightText: © 2022-2024 Decompollaborate */
/* SPDX-License-Identifier: MIT */

#ifndef RABBITIZER_ACCESS_TYPE_H
#define RABBITIZER_ACCESS_TYPE_H
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "generated/AccessType_enum.h"

#ifdef __cplusplus
}
#endif

#endif
