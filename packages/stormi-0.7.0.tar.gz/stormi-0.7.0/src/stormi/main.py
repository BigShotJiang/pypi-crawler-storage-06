def main() -> None:
    print("stormi cli entrypoint")
