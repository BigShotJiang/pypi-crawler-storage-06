"""
There gathered all mixins with methods.
Each mixin responsible for `Steam Community` part (market, trade offers, login process, etc.)
"""
