"""`Aiosteampy` package extensions place of residence"""
