import setuptools

if __name__ == '__main__':
    setuptools.setup(
        name='deepconf',
        version='0.1.0',
        description='Enhanced LLM wrapper with DeepConf capabilities',
        author='Yichao',
        author_email='fuyichao2000@gmail.com',
        packages=['deepconf']
    )