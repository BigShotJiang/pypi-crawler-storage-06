"""The sportsfeatures main module."""

__VERSION__ = "0.0.111"
