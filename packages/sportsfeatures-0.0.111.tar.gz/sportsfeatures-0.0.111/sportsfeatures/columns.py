"""A collection of constants relating to dataframe columns."""

DELIMITER = "_"
NEWS_COLUMN = "news"
