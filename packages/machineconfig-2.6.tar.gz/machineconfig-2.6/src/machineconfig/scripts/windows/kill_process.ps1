uv run --python 3.13 --with machineconfig  python -c "from machineconfig.utils.procs import ProcessManager; ProcessManager().choose_and_kill()"
