uv run --python 3.13 --with machineconfig python -m machineconfig.scripts.python.start_terminals $args
