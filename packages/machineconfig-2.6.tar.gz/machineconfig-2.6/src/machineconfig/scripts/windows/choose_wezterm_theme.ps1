uv run --python 3.13 --with machineconfig python -m fire machineconfig.scripts.python.choose_wezterm_theme main2 $args[0]
