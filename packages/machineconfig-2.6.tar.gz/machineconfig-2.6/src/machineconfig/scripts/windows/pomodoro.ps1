uv run --python 3.13 --with machineconfig  -m fire machineconfig.scripts.python.pomodoro pomodoro $args
