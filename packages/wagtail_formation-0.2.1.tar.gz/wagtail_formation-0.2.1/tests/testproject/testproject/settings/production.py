from .base import *  # noqa: F401, F403

DEBUG = False  # noqa: F811
