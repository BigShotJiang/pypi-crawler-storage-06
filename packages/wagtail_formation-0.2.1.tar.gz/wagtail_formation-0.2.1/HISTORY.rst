=======
History
=======

0.2.1 (2025-09-19)
------------------

* update cryptography dependency
* update generic chooser dependency
* support wagtail 7

0.2.0 (2025-04-17)
------------------

* remove support for third-party modeladmin package in favor of wagtail functionality
* official support for wagtail>=6.0
* drop support for python <3.10

0.1.11 (2024-06-26)
-------------------

* use third party modeladmin package
* better filefield support

0.1.10 (2024-02-19)
-------------------

* add feature to optionally disable reusable form creation from chooser

0.1.9 (2023-11-21)
------------------

* add form_submitted to context

0.1.8 (2023-11-21)
------------------

* update default form valid and invalid methods

0.1.7 (2023-09-18)
------------------

* pass request object to form_(in)valid

0.1.6 (2023-08-07)
------------------

* enforce management of migrations to developer using the package

0.1.5 (2023-07-21)
------------------

* clean methods for fields and forms
* support file input field blocks
* support success_url-like page loads

0.1.4 (2023-07-11)
------------------

* use_json_field fix

0.1.3 (2023-03-21)
------------------

* fix package dir

0.1.2 (2023-03-21)
------------------

* fix manifest

0.1.1 (2023-03-17)
------------------

* Testing and some refactoring

0.1.0 (2023-03-06)
------------------

* First release on PyPI.
