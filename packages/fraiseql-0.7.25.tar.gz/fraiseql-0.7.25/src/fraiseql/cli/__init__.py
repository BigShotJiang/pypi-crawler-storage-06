"""FraiseQL CLI - Command-line interface for FraiseQL framework."""

from .main import main

__all__ = ["main"]
