# pms-tensorrt

tensorrt로 inference를 하기 위해 사용하는 라이브러리 입니다.

## Install

```bash
pip install pms-tensorrt
```

## Setting

* 이 library는 tensorrt를 설치해주지 않습니다. tensorrt가 설치된 환경이 필요합니다.
* 필요한 tensorrt 버전은 [./pms_tensorrt/__init__.py](./pms_tensorrt/__init__.py) 파일의 내부를 참조해주세요.
