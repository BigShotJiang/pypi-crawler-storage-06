from pms_tensorrt._const import *


class TensorMode(Enum):
    NONE = 0
    INPUT = 1
    OUTPUT = 2
