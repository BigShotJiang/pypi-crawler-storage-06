# SPDX-FileCopyrightText: UL Research Institutes
# SPDX-License-Identifier: Apache-2.0


class ComponentNotFoundError(Exception):
    pass
