from setuptools import setup, find_packages

setup(
    name="tkmapx",
    version="1.0.0",
    description="A Tkinter-based Python package for creating and visualizing simple maps with nodes and paths.",
    author="Nebula Company",
    url="https://github.com/Krishna-Developer5000/tkmap",
    packages=find_packages(),
    install_requires=[],  # no external deps (tkinter is stdlib)
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries",
        "Topic :: Scientific/Engineering :: Visualization",
    ],
    python_requires=">=3.8",
)
