"""WFX CLI module for serving flows."""

from wfx.cli.commands import serve_command

__all__ = ["serve_command"]
