"""This means `python -m pydantic_ai` should run the CLI."""

from ._cli import cli_exit

if __name__ == '__main__':
    cli_exit()
