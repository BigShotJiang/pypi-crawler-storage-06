from .places_utils import get_places_data

# add function to the __all__ list for public API
__all__ = ['get_places_data']
