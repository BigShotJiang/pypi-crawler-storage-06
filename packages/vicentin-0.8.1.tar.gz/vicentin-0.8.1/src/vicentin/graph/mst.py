def prim():
    pass


def kruskal():
    pass
