# mocap-converter

[![PyPI - Version](https://img.shields.io/pypi/v/mocap-converter.svg)](https://pypi.org/project/mocap-converter)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/mocap-converter.svg)](https://pypi.org/project/mocap-converter)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install mocap-converter
```

## License

`mocap-converter` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
