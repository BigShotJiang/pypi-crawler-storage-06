from . import __version__


def print_version():
    print(f"faceclustering version: {__version__}")


if __name__ == "__main__":
    print_version()
