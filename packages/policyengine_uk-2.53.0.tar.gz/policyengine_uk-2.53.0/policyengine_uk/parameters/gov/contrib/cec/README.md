# Citizens' Economic Council

Includes parameters developed for the Citizens' Economic Council (CEC) project administered by King's College London.