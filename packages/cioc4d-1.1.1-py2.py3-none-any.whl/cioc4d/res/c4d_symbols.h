enum
{
    _SENTINEL_
}

