from .search_data import _Search


def _init_search():
    global search
    search = _Search()

_init_search()





