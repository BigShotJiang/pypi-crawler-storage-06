from pyspark.sql import DataFrame


def read_excel(path: str) -> DataFrame:
    raise NotImplementedError()
