# Databricks notebook source
from databricks.sdk.runtime import dbutils

# COMMAND ----------

dbutils.notebook.exit(value="exit (0)")  # type: ignore
