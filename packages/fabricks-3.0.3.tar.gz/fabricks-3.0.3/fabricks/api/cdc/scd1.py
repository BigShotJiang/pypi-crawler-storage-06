from fabricks.cdc.scd1 import SCD1

__all__ = ["SCD1"]
