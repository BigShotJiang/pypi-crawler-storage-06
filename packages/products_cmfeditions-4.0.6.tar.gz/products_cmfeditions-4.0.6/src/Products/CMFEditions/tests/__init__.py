"""\
Unit test package for CMFEditions
"""
