README for Radioactiveshrimp package!
