"""Test private helpers for Cutesy."""
