"""Processors for attribute strings."""

from .types import BaseAttributeProcessor

__all__ = ["BaseAttributeProcessor"]
