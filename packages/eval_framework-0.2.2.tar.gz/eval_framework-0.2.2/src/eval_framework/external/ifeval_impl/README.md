IFEval implementation here is taken 1:1 (besides some minuscule details, like adding Swedish to `LANGUAGE_CODES`)
from [lm-evaluation-harness](https://github.com/EleutherAI/lm-evaluation-harness/tree/main/lm_eval/tasks/ifeval) as of Dec 19 2024.
The original repository is https://github.com/google-research/google-research/tree/master/instruction_following_eval .

This code doesn't have to be unit-tested.
