from .saudi_regions import SaudiRegions
from .data_models import Region, City, District

