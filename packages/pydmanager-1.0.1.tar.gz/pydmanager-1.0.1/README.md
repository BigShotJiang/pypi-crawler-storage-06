# PyDM — Python Dependency Manager

[![Python Version](https://img.shields.io/pypi/pyversions/pydm.svg)](https://pypi.org/project/pydm/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

PyDM is a modern Python project manager that simplifies dependency management, script execution, and project construction with an intuitive command-line interface.

## Key Features

- 🚀 Easy project initialization with `pydm init`
- 📦 Dependency management with `pypackage.json`
- 🛠️ Create standalone executables with PyInstaller
- 📝 Project configuration with `pyproject.toml` (PEP 621) for module-type projects
- 🔧 Run scripts with `pydm run`
- 🌍 Global mode for system-wide tool installation
- ⚡ Fast and efficient dependency resolution
- 🔍 Security audit for dependencies
- 📊 Outdated dependencies visualization
- 🎛️ Advanced `pyproject.toml` customization for module projects

## Requisitos

- Python 3.9 o superior
- pip (incluido con Python)

## Instalación

```bash
pip install pydm
```

## Quick Start Guide

### Create a New Project

```bash
# Initialize a new application project
pydm init my-app --type app

# Or initialize a new module project
pydm init my-module --type module

# Navigate to the project directory
cd my-app
```

### Advanced pyproject.toml Configuration (Module Projects Only)

For module-type projects, you can customize the generated `pyproject.toml` in two ways:

1. **Structured Format**: Define sections using JSON keys in `[section]` format
2. **Raw Format**: Provide direct TOML content in the `_raw` field

Example `pypackage.json` with custom pyproject configuration:

```json
{
  "type": "module",
  "name": "my-module",
  "version": "0.1.0",
  "pyproject": {
    "[project.scripts]": {
      "my-command": "my_module.cli:main",
      "another-command": "my_module.other:cli"
    },
    "[tool.black]": {
      "line-length": 100,
      "target-version": ["py39"]
    },
    "[tool.mypy]": {
      "python_version": "3.9",
      "strict": true
    },
    "_raw": "# Direct TOML content here\n[tool.poetry]\nname = \"my-package\"\nversion = \"0.1.0\"\ndescription = \"My package description\"\n"
  }
}
```

When you run `pydm convert --to toml`, this will generate a `pyproject.toml` file with all the custom configurations merged together.

### Manage Dependencies

```bash
# Add dependencies
pydm add requests pytest

# Añadir dependencias de desarrollo
pydm add --dev black flake8

# Instalar dependencias
pydm install

# Actualizar dependencias
pydm update

# Eliminar dependencias
pydm remove nombre-del-paquete
```

### Ejecutar scripts

Añade scripts a `pypackage.json`:
```json
{
  "scripts": {
    "iniciar": "python main.py",
    "probar": "pytest",
    "formatear": "black ."
  }
}
```

Ejecuta los scripts con:
```bash
pydm run iniciar
pydm run probar
pydm run formatear
```

### Construir ejecutables independientes (solo para proyectos de aplicación)

Añade la configuración de compilación a `pypackage.json`:
```json
{
  "executable": {
    "target": "main.py",
    "parameters": ["--onefile"],
    "output": "dist/ejecutable"
  }
}
```

Construye el ejecutable:
```bash
pydm build
```

## Estructura del proyecto

### Proyectos de aplicación (`type: "app"` en pypackage.json)
- Estructura de proyecto simple
- Enfoque en la creación de ejecutables independientes
- Sin `pyproject.toml` por defecto (puede habilitarse con `"pyprojectUse": true`)
- Ideal para aplicaciones de usuario final

### Proyectos de módulo (`type: "module"` en pypackage.json)
- Estructura de paquete Python
- Incluye `pyproject.toml` para metadatos del paquete
- Soporta puntos de entrada (entry points) y scripts de consola
- Ideal para bibliotecas y paquetes reutilizables

## Comandos disponibles

### Inicialización y configuración
- `pydm init [NOMBRE] --type {app|module}`: Crea un nuevo proyecto
- `pydm install [-e|--editable] [--global]`: Instala dependencias del proyecto

### Gestión de dependencias
- `pydm add [PAQUETE]... [--dev] [--global]`: Añade paquetes al proyecto
- `pydm remove [PAQUETE]... [--global]`: Elimina paquetes del proyecto
- `pydm update [PAQUETE]... [--global]`: Actualiza paquetes
- `pydm outdated`: Muestra paquetes desactualizados
- `pydm audit [--json] [--extended]`: Audita vulnerabilidades de seguridad
- `pydm list`: Lista paquetes instalados
- `pydm why PAQUETE`: Muestra por qué está instalado un paquete

### Construcción y publicación
- `pydm build`: Construye el proyecto (ejecutable o paquete)
- `pydm publish [--repository NOMBRE]`: Publica el paquete en PyPI

### Ejecución
- `pydm run SCRIPT`: Ejecuta un script definido en pypackage.json
- `pydm version`: Muestra la versión de PyDM

### Utilidad pydx
PyDM incluye una utilidad `pydx` para ejecutar herramientas Python con salida enriquecida:

```bash
# Ejecutar black con salida mejorada
pydx black .

# Ejecutar un módulo como script
pydx -m http.server 8000

# Ejecutar tests con pytest
pydx -m pytest tests/
```

## pypackage.json

El archivo `pypackage.json` es el archivo de configuración principal de PyDM. Aquí tienes un ejemplo completo:

```json
{
  "type": "app",
  "name": "mi-proyecto",
  "version": "0.1.0",
  "description": "Una descripción de mi proyecto",
  "authors": [{"name": "Tu Nombre"}],
  "license": "MIT",
  "dependencies": {
    "requests": "^2.31.0"
  },
  "devDependencies": {
    "pytest": "^8.0.0",
    "black": "^24.0.0"
  },
  "scripts": {
    "start": "python main.py",
    "test": "pytest"
  },
  "executable": {
    "target": "main.py",
    "parameters": ["--onefile"],
    "output": "dist/ejecutable"
  },
  "useGlobalDeps": false,
  "pyprojectUse": false
}
```

## Uso avanzado

### Modo global
Puedes instalar paquetes globalmente con la bandera `--global`:

```bash
# Instalar un paquete globalmente
pydm add -g black

# Listar paquetes globales
pydm list --global
```

### Variables de entorno
PyDM respeta las siguientes variables de entorno:
- `PYDM_VERBOSE`: Activa el modo detallado (equivalente a `--logs`)
- `PYDM_GLOBAL_DEPS`: Usa dependencias globales (equivalente a `--global`)

## Contribuir

¡Las contribuciones son bienvenidas! Por favor, lee nuestra guía de contribución antes de enviar pull requests.

## Licencia

Este proyecto está licenciado bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para más detalles.

## Agradecimientos

- A la comunidad de Python por su increíble ecosistema
- Proyectos que nos inspiran: npm, pip, pipenv, poetry
- A todos los contribuyentes que ayudan a mejorar PyDM
