## v0.1.1rc46 (September 18, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc45...v0.1.1rc46

### Bug Fixes

- Fix semaphore implementation to allow multiple batching without getting into max_concurrent_activities issue (#725) (by @Mustafa in [2a66f13](https://github.com/atlanhq/application-sdk/commit/2a66f13))
