from setuptools import setup

# See setup.cfg
setup()
