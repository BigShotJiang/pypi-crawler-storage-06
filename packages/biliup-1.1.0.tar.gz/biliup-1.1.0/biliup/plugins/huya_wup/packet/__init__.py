
from .getCdnTokenInfo import (
    HuyaGetCdnTokenReq,
    HuyaGetCdnTokenRsp
)

__all__ = ['HuyaGetCdnTokenReq', 'HuyaGetCdnTokenRsp']

