"""Tests for blog.articles.models"""

from django.test import TestCase


# Create your tests here.
class BlogArticleTests(TestCase):
    """BlogArticle model tests"""

    def setUp(self) -> None:
        """Setup before tests"""

        return super().setUp()
