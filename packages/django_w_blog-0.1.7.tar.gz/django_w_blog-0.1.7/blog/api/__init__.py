"""Django Blog APIs"""
