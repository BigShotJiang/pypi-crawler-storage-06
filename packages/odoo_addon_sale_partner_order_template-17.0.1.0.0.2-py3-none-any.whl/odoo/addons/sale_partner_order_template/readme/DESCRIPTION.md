This module allows you to configure an order template per customer.
