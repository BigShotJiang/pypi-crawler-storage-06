# supertable/config/cli.py
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Optional

# -----------------------
# Helpers / lazy imports
# -----------------------

def try_import(name: str):
    try:
        return __import__(name)
    except Exception as e:
        print(f"[WARN] Optional dependency '{name}' is not installed: {e}", file=sys.stderr)
        return None

def _norm_bool(val: str | bool) -> bool:
    if isinstance(val, bool):
        return val
    return str(val).strip().lower() in {"1", "true", "yes", "y", "on"}

def write_env_file(path: Path, kv: dict[str, str]) -> None:
    lines = []
    for k, v in kv.items():
        v_str = "" if v is None else str(v)
        if any(ch in v_str for ch in [' ', '#', '"', "'"]):
            v_str = '"' + v_str.replace('"', '\\"') + '"'
        lines.append(f"{k}={v_str}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

# -----------------------
# Validators
# -----------------------

def validate_redis(redis_url: Optional[str], host: str, port: int, db: int, password: Optional[str], ssl: bool) -> tuple[bool, str]:
    redis = try_import("redis")
    if redis is None:
        return False, "redis client not installed"
    try:
        client = redis.from_url(redis_url) if redis_url else redis.Redis(
            host=host, port=port, db=db, password=(password or None), ssl=ssl
        )
        ok = client.ping()
        return bool(ok), "OK" if ok else "PING returned False"
    except Exception as e:
        return False, f"Redis validation failed: {e}"

def validate_s3_or_minio(aws_key: str, aws_secret: str, region: str, endpoint_url: str, force_path_style: bool, storage: str) -> tuple[bool, str]:
    boto3 = try_import("boto3")
    if boto3 is None:
        return False, "boto3 not installed"

    # Prefer STS for AWS; for MinIO (or any custom endpoint) fall back to S3 ListBuckets
    try:
        if endpoint_url or storage == "MINIO":
            s3 = boto3.client(
                "s3",
                aws_access_key_id=aws_key or None,
                aws_secret_access_key=aws_secret or None,
                region_name=region or None,
                endpoint_url=endpoint_url or None,
                config=boto3.session.Config(s3={"addressing_style": "path" if force_path_style else "virtual"}),
            )
            # cheap call; requires listing permission (MinIO root user has it)
            s3.list_buckets()
            return True, "OK (S3/MinIO list_buckets)"
        else:
            sts = boto3.client(
                "sts",
                aws_access_key_id=aws_key or None,
                aws_secret_access_key=aws_secret or None,
                region_name=region or None,
            )
            ident = sts.get_caller_identity()
            return True, f"OK (AWS STS: Account={ident.get('Account','?')})"
    except Exception as e:
        return False, f"S3/MinIO validation failed: {e}"

def validate_azure(account: str, key: str, conn_str: str, sas: str, endpoint: str) -> tuple[bool, str]:
    az = try_import("azure.storage.blob")
    if az is None:
        return False, "azure-storage-blob not installed"
    try:
        from azure.storage.blob import BlobServiceClient
        client = None
        if conn_str:
            client = BlobServiceClient.from_connection_string(conn_str)
        else:
            url = endpoint or (f"https://{account}.blob.core.windows.net" if account else None)
            if not url:
                return False, "missing account or endpoint"
            if key:
                client = BlobServiceClient(account_url=url, credential=key)
            elif sas:
                if not sas.startswith("?"):
                    sas = "?" + sas
                client = BlobServiceClient(account_url=url + sas)
            else:
                ident = try_import("azure.identity")
                if not ident:
                    return False, "no credential provided (key/sas/connection string/AAD)"
                from azure.identity import DefaultAzureCredential
                client = BlobServiceClient(account_url=url, credential=DefaultAzureCredential())
        client.get_service_properties()
        return True, "OK"
    except Exception as e:
        return False, f"Azure validation failed: {e}"

def validate_gcp(project: str, creds_path: str) -> tuple[bool, str]:
    gcs = try_import("google.cloud.storage")
    if gcs is None:
        return False, "google-cloud-storage not installed"
    try:
        from google.cloud import storage
        client: storage.Client
        if creds_path:
            # Allow raw JSON content too (path OR JSON string)
            if Path(creds_path).exists():
                from google.oauth2 import service_account
                creds = service_account.Credentials.from_service_account_file(creds_path)
                client = storage.Client(project=project or creds.project_id, credentials=creds)
            else:
                # try parsing as JSON string
                info = json.loads(creds_path)
                from google.oauth2 import service_account
                creds = service_account.Credentials.from_service_account_info(info)
                client = storage.Client(project=project or creds.project_id, credentials=creds)
        else:
            # ADC (env GOOGLE_APPLICATION_CREDENTIALS or metadata)
            client = storage.Client(project=project or None)

        # Cheap call; may require permissions. If unauthorized, give a helpful error.
        _ = next(client.list_buckets(page_size=1), None)
        return True, "OK"
    except Exception as e:
        return False, f"GCP validation failed: {e}"

# -----------------------
# CLI
# -----------------------

def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(
        prog="supertable config",
        description="Initialize and validate SuperTable environment for LOCAL, S3, MINIO, AZURE, or GCP, plus Redis.",
    )
    p.add_argument("--storage", default="S3", choices=["LOCAL", "S3", "MINIO", "AZURE", "GCP"],
                   help="Storage backend to configure (default: S3).")
    p.add_argument("--write", metavar="FILE", default=".env",
                   help="Where to write env file (default: .env). Use '-' to print shell exports.")
    p.add_argument("--no-validate", action="store_true", help="Skip live connectivity checks.")

    # LOCAL
    p.add_argument("--local-home",
                   default=os.getenv("SUPERTABLE_HOME", str(Path.home() / "supertable")),
                   help="Local workspace path for STORAGE_TYPE=LOCAL; writes SUPERTABLE_HOME.")
    p.add_argument("--create-local-home", action="store_true",
                   help="Create the --local-home directory if it doesn't exist.")
    p.add_argument("--redis-with-local", action="store_true",
                   help="Also configure & validate Redis when STORAGE_TYPE=LOCAL (optional).")

    # S3 / MinIO (AWS style)
    p.add_argument("--aws-access-key-id", default=os.getenv("AWS_ACCESS_KEY_ID", ""))
    p.add_argument("--aws-secret-access-key", default=os.getenv("AWS_SECRET_ACCESS_KEY", ""))
    p.add_argument("--aws-region", default=os.getenv("AWS_DEFAULT_REGION", "eu-central-1"))
    p.add_argument("--aws-endpoint-url", default=os.getenv("AWS_S3_ENDPOINT_URL", ""),  # for MinIO/custom S3
                   help="Custom S3 endpoint (e.g., http://localhost:9000 for MinIO).")
    p.add_argument("--aws-force-path-style",
                   default=os.getenv("AWS_S3_FORCE_PATH_STYLE", "false"),
                   help="true/false. For MinIO or path-style only setups.")

    # Azure
    p.add_argument("--azure-account", default=os.getenv("AZURE_STORAGE_ACCOUNT", ""))
    p.add_argument("--azure-key", default=os.getenv("AZURE_STORAGE_KEY", ""))
    p.add_argument("--azure-sas", default=os.getenv("AZURE_SAS_TOKEN", ""))
    p.add_argument("--azure-connection-string", default=os.getenv("AZURE_STORAGE_CONNECTION_STRING", ""))
    p.add_argument("--azure-endpoint", default=os.getenv("AZURE_BLOB_ENDPOINT", ""))

    # GCP
    p.add_argument("--gcp-project", default=os.getenv("GCP_PROJECT", ""))
    p.add_argument("--gcp-credentials", default=os.getenv("GOOGLE_APPLICATION_CREDENTIALS", ""),
                   help="Path to service-account JSON, or raw JSON string. If empty, uses ADC.")

    # Redis (locking for non-LOCAL; optional for LOCAL via --redis-with-local)
    p.add_argument("--redis-url", default=os.getenv("REDIS_URL", ""))
    p.add_argument("--redis-host", default=os.getenv("REDIS_HOST", "localhost"))
    p.add_argument("--redis-port", type=int, default=int(os.getenv("REDIS_PORT", "6379")))
    p.add_argument("--redis-db", type=int, default=int(os.getenv("REDIS_DB", "0")))
    p.add_argument("--redis-password", default=os.getenv("REDIS_PASSWORD", ""))
    p.add_argument("--redis-ssl", action="store_true", default=_norm_bool(os.getenv("REDIS_SSL", "false")))

    args = p.parse_args(argv)
    storage = args.storage.upper()

    # What to include
    need_aws = storage in {"S3", "MINIO"}
    need_azure = storage == "AZURE"
    need_gcp = storage == "GCP"
    need_redis = (storage != "LOCAL") or args.redis_with_local

    # Assemble env
    kv: dict[str, str] = {"STORAGE_TYPE": storage}

    # LOCAL
    if storage == "LOCAL":
        kv["SUPERTABLE_HOME"] = args.local_home
        if args.create_local_home:
            try:
                Path(args.local_home).mkdir(parents=True, exist_ok=True)
                print(f"[OK] Ensured local directory: {Path(args.local_home).resolve()}")
            except Exception as e:
                print(f"[WARN] Could not create local directory '{args.local_home}': {e}", file=sys.stderr)

    # AWS / MinIO
    if need_aws:
        kv.update({
            "AWS_ACCESS_KEY_ID": args.aws-access_key_id if False else args.aws_access_key_id,
            "AWS_SECRET_ACCESS_KEY": args.aws_secret_access_key,
            "AWS_DEFAULT_REGION": args.aws_region,
        })
        if args.aws_endpoint_url:
            kv["AWS_S3_ENDPOINT_URL"] = args.aws_endpoint_url
        if args.aws_force_path_style:
            kv["AWS_S3_FORCE_PATH_STYLE"] = "true" if _norm_bool(args.aws_force_path_style) else "false"

    # Azure
    if need_azure:
        if args.azure_connection_string:
            kv["AZURE_STORAGE_CONNECTION_STRING"] = args.azure_connection_string
        else:
            if args.azure_account:  kv["AZURE_STORAGE_ACCOUNT"] = args.azure_account
            if args.azure_key:      kv["AZURE_STORAGE_KEY"] = args.azure_key
            if args.azure_sas:      kv["AZURE_SAS_TOKEN"] = args.azure_sas
            if args.azure_endpoint: kv["AZURE_BLOB_ENDPOINT"] = args.azure_endpoint

    # GCP
    if need_gcp:
        if args.gcp_project:
            kv["GCP_PROJECT"] = args.gcp_project
        if args.gcp_credentials:
            # If path exists, set GOOGLE_APPLICATION_CREDENTIALS; else keep raw JSON in GCP_SA_JSON
            if Path(args.gcp_credentials).exists():
                kv["GOOGLE_APPLICATION_CREDENTIALS"] = args.gcp_credentials
            else:
                kv["GCP_SA_JSON"] = args.gcp_credentials  # optional pathless mode supported by our validator

    # Redis (used for all non-LOCAL; optional on LOCAL)
    if need_redis:
        if args.redis_url:
            kv["REDIS_URL"] = args.redis_url
        else:
            kv.update({
                "REDIS_HOST": args.redis_host,
                "REDIS_PORT": str(args.redis_port),
                "REDIS_DB": str(args.redis_db),
                "REDIS_PASSWORD": args.redis_password,
                "REDIS_SSL": "true" if args.redis_ssl else "false",
            })

    # -----------------------
    # Validation
    # -----------------------
    ok_all = True

    if not args.no_validate:
        # Redis
        if need_redis:
            ok_r, msg_r = validate_redis(
                kv.get("REDIS_URL", ""), kv.get("REDIS_HOST", "localhost"),
                int(kv.get("REDIS_PORT", "6379")), int(kv.get("REDIS_DB", "0")),
                kv.get("REDIS_PASSWORD", "") or None, _norm_bool(kv.get("REDIS_SSL", "false"))
            )
            print(f"[INFO] Redis validation: {msg_r}")
            ok_all = ok_all and ok_r

        # S3/MinIO
        if need_aws:
            ok_a, msg_a = validate_s3_or_minio(
                kv.get("AWS_ACCESS_KEY_ID", ""), kv.get("AWS_SECRET_ACCESS_KEY", ""),
                kv.get("AWS_DEFAULT_REGION", ""), kv.get("AWS_S3_ENDPOINT_URL", ""),
                _norm_bool(kv.get("AWS_S3_FORCE_PATH_STYLE", "false")), storage
            )
            print(f"[INFO] {storage} validation: {msg_a}")
            ok_all = ok_all and ok_a

        # Azure
        if need_azure:
            ok_z, msg_z = validate_azure(
                kv.get("AZURE_STORAGE_ACCOUNT",""), kv.get("AZURE_STORAGE_KEY",""),
                kv.get("AZURE_STORAGE_CONNECTION_STRING",""), kv.get("AZURE_SAS_TOKEN",""),
                kv.get("AZURE_BLOB_ENDPOINT",""),
            )
            print(f"[INFO] AZURE validation: {msg_z}")
            ok_all = ok_all and ok_z

        # GCP
        if need_gcp:
            # If raw JSON is present, write a temp file path into GOOGLE_APPLICATION_CREDENTIALS?
            # We don't force that; validator can consume raw JSON directly.
            creds = kv.get("GOOGLE_APPLICATION_CREDENTIALS", kv.get("GCP_SA_JSON", ""))
            ok_g, msg_g = validate_gcp(kv.get("GCP_PROJECT", ""), creds)
            print(f"[INFO] GCP validation: {msg_g}")
            ok_all = ok_all and ok_g

    # Summaries
    print(f"[INFO] STORAGE_TYPE={storage}")
    if storage == "LOCAL":
        print(f"[INFO] SUPERTABLE_HOME={kv['SUPERTABLE_HOME']}")

    # -----------------------
    # Output
    # -----------------------
    if args.write == "-":
        for k, v in kv.items():
            print(f"export {k}={v}")
    else:
        dest = Path(args.write)
        write_env_file(dest, kv)
        print(f"[OK] Wrote {dest.resolve()}")

    return 0 if ok_all or args.no_validate else 2

if __name__ == "__main__":
    raise SystemExit(main())
