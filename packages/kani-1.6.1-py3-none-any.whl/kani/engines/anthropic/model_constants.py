CONTEXT_SIZES_BY_PREFIX = [
    ("claude-opus-4", 200000),
    ("claude-sonnet-4", 200000),
    ("claude-3", 200000),
    ("claude-2.1", 200000),
    ("", 200000),
]
