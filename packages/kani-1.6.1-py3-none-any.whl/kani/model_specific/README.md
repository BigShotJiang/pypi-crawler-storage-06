This directory contains hand-written implementations of prompting pipelines and parsers for some models.
In most cases, you can use HuggingEngine to automatically load chat templates for these models instead.

These will automatically be loaded when necessary in the HuggingEngine.

> [!WARN]
> The stability of the APIs in this submodule are subject to change on **minor** patches.
