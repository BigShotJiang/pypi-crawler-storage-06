"""The :mod:`~virtual_ecosystem.example_data` module contains an example data set for
testing out Virtual Ecosystem.
"""  # noqa: D205
