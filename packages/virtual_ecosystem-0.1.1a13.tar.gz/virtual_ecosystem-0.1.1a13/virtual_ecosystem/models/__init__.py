"""A module providing the different model components of the Virtual Ecosystem."""
