"""A minimal model for testing."""

from virtual_ecosystem.models.testing.testing_model import TestingModel  # noqa: F401
