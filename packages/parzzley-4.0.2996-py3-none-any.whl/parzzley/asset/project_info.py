homepage_url = 'https://pseudopolis.eu/pino/parzzley'
version = '4.0.2996'
