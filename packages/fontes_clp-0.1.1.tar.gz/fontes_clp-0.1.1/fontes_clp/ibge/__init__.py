from . import populacao

from .populacao import IBGEPopulacao

__all__ = [
    "IBGEPopulacao",
    "populacao",
]

