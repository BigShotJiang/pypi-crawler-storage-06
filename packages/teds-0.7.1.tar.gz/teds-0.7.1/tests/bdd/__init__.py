"""BDD tests for TeDS functionality."""
