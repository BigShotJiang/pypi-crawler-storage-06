from .square import square, USING_CYTHON

__all__ = ["square", "USING_CYTHON"]
