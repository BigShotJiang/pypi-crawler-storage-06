# koegelbrunf


A tiny example package that exposes `square(n)` and prefers a Cython fast path
with a pure-Python fallback. Requires Python 3.11+.


## Install
```bash
pip install koegelbrunf