# docling-hierarchical-pdf

[![Release](https://img.shields.io/github/v/release/krrome/docling-hierarchical-pdf)](https://img.shields.io/github/v/release/krrome/docling-hierarchical-pdf)
[![Build status](https://img.shields.io/github/actions/workflow/status/krrome/docling-hierarchical-pdf/main.yml?branch=main)](https://github.com/krrome/docling-hierarchical-pdf/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/krrome/docling-hierarchical-pdf)](https://img.shields.io/github/commit-activity/m/krrome/docling-hierarchical-pdf)
[![License](https://img.shields.io/github/license/krrome/docling-hierarchical-pdf)](https://img.shields.io/github/license/krrome/docling-hierarchical-pdf)

This package enables inference of header hierarchy in the docling PDF parsing pipeline.
