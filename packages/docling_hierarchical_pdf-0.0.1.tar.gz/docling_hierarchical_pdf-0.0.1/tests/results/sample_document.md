## Some kind of text document

1. Introduction

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consequat tincidunt tempor.

## 1.1 Background

Praesent venenatis leo vel nibh tincidunt, nec iaculis est dictum. Integer ac purus at mi volutpat feugiat.

- 1.2 Purpose

Nunc rhoncus, risus ut pretium hendrerit, ipsum nulla lobortis augue, nec vestibulum magna turpis sit amet erat.

## 2. Main Content

Aliquam erat volutpat. Morbi interdum, eros eget venenatis euismod, velit sapien tristique risus, ac tincidunt massa lorem nec felis.

### 2.1 Section One

Phasellus ullamcorper nunc a lacus imperdiet, at luctus sem euismod. Integer feugiat commodo orci.

- 2.1.1 Subsection

Duis porttitor magna ut urna efficitur, ac sollicitudin odio volutpat. Suspendisse potenti.

- 2.1.2 Another Subsection

Sed vestibulum porta sem, eu egestas nulla gravida vel. Morbi feugiat vulputate odio sed placerat.

### 2.2 Section Two

Vivamus venenatis magna at metus imperdiet consequat. Ut semper risus nec odio ultrices gravida.

## 3. Conclusion

In hac habitasse platea dictumst. Sed pretium, felis ac dignissim dictum, lectus erat pharetra quam, vel ullamcorper est lorem vitae ligula.
