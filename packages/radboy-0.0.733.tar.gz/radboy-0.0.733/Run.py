#!/usr/bin/env python3
from radboy import RecordMyCodes as rmc
rmc.quikRn()
