from .core import stalin_sort

__all__ = ["stalin_sort"]