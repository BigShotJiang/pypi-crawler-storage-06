from aiocache_dynamodb.dynamodb import DynamoDBCache

__all__ = ["DynamoDBCache"]
