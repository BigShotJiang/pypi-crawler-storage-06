# Results

```{eval-rst}
.. autoclass:: iesopt.Results
    :members: 
```
