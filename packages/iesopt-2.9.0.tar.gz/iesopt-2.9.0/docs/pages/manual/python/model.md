# Model

```{eval-rst}
.. autoclass:: iesopt.Model
    :members:

.. autoclass:: iesopt.model.ModelStatus()
    :members:
    :undoc-members:
```
