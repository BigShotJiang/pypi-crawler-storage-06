# Extracting results

:::{toctree}
:maxdepth: 2

Part I <../notebooks/custom_results_1>
Part II <../notebooks/custom_results_2>
:::
