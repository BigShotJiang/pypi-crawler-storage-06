from .image import add_image
from .paragraph import add_paragraph
from .table import set_cell, set_cell_border, set_three_line_border
from .text import add_text
