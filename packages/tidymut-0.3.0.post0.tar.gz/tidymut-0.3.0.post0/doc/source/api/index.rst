.. doc/source/api/index.rst

API Reference
=============

.. autosummary::
   :toctree: generated
   :recursive:

   tidymut.cleaners
   tidymut.core
   tidymut.utils