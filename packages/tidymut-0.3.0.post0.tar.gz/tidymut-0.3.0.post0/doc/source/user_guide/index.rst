.. doc/source/user_guide/index.rst

User Guide
==========

.. toctree::
   :maxdepth: 2

   cleaners