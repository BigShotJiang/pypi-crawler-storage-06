.. tidymut documentation master file, created by
   sphinx-quickstart on Fri Sep 19 11:06:52 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
.. doc/source/index.rst

tidymut documentation
=====================

tidymut: A comprehensive Python package for processing and 
analyzing biological sequence data with advanced mutation analysis capabilities.

.. toctree::
   :maxdepth: 2

   user_guide/index
   api/index