# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [HEAD] - 2025-06-26

### Contributors

A total of 1 people contributed to this release. People with a "+" by their names contributed a patch for the first time.

- YukunR

**Full Changelog**: [b0518b2c91432fa750babf87593b37d93ed07e0a..HEAD](https://github.com/xulab-research/TidyMut/compare/b0518b2c91432fa750babf87593b37d93ed07e0a..v0.1.0b1) 

### Version

Note: version 0.0.0 was an internal development artifact.
