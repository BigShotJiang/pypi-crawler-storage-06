from bafser import OperationsBase


class Operations(OperationsBase):
    upload_img = ("upload_img", "Add image")
