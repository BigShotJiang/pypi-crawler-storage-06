from pathlib import Path

workdir = Path(__file__).parent
