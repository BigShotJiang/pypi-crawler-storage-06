================================
External Complementary Libraries
================================

Testing data can be found here: https://github.com/hydrologie/xhydro-testdata

A LSTM module can be found here: https://github.com/hydrologie/xhydro-lstm. It is not included in this package to avoid dependencies on `tensorflow`.
