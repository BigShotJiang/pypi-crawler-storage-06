"""Optimal Interpolation module."""

from . import compare_result, optimal_interpolation_fun
from .optimal_interpolation_fun import execute_interpolation as execute
