"""Frequency analysis module."""

from . import local, regional, uncertainties
