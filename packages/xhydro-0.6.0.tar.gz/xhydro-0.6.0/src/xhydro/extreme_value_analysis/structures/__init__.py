"""Python and Julia structures used in the extreme value analysis and their conversion rules."""
