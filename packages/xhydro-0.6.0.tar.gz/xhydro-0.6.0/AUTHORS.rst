=======
Credits
=======

Development Lead
----------------

* Thomas-Charles Fortier Filion <tcff_hydro@outlook.com> `@TC-FF <https://github.com/TC-FF>`_

Co-Developers
-------------

* Trevor James Smith <smith.trevorj@ouranos.ca> `@Zeitsperre <https://github.com/Zeitsperre>`_
* Gabriel Rondeau-Genesse <rondeau-genesse.gabriel@ouranos.ca> `@RondeauG <https://github.com/RondeauG>`_
* Sébastien Langlois `@sebastienlanglois <https://github.com/sebastienlanglois>`_
* Julián Ospina `@ospinajulian <https://github.com/ospinajulian>`_
* Kamil Maarite `@Sci-pio <https://github.com/Sci-pio>`_

Contributors
------------

* Richard Arsenault `@richardarsenault <https://github.com/richardarsenault>`_
* Francis Gravel `@mayetea <https://github.com/mayetea>`_
* Louise Arnal `@lou-a <https://github.com/lou-a>`_
* Essi Parent `@essicolo <https://github.com/essicolo>`_
