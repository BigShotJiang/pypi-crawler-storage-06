# simple_calculator_ahmad

حاسبة بسيطة لسطر الأوامر مكتوبة بالبايثون (جمع، طرح، ضرب، قسمة).

التشغيل محلياً:
- python -m simple_calculator_ahmad.cli

بعد التثبيت:
- simple-calculator

المؤلف: أحمد الماخذي
