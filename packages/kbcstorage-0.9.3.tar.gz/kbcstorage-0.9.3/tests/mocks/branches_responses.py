branches_metadata_response = [
    {
        "id": "93670",
        "key": "KBC.projectDescription",
        "value": "Testing project one",
        "timestamp": "2023-05-31T17:52:18+0200"
    }
]
