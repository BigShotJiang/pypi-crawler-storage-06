"""Turns FHIR data into de-identified & aggregated records"""

__version__ = "3.6.0"
