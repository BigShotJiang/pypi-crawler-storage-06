# Widget module for physicar deepracer cloud
