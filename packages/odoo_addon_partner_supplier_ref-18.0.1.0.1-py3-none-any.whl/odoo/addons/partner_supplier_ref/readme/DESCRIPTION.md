This module adds a supplier reference field to specify the supplier reference of the
contact.
