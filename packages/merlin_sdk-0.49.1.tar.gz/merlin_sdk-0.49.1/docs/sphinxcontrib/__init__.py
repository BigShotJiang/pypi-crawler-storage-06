# -*- coding: utf-8 -*-
# This is free and unencumbered software released into the public domain.

__import__('pkg_resources').declare_namespace(__name__)