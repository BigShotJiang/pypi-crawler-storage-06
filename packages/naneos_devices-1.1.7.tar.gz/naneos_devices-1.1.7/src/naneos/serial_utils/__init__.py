from naneos.serial_utils.list_serial_ports import list_serial_ports

__all__ = ["list_serial_ports"]
