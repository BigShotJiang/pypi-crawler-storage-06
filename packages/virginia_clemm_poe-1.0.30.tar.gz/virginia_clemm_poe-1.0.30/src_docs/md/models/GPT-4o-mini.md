# [GPT-4o-mini](https://poe.com/GPT-4o-mini){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Initial Points Cost | 10+ points |
| Input | 5 points/1k tokens |
| Output (Text) | 18 points/1k tokens |
| Cache Discount | 50% discount oncached chat |

**Last Checked:** 2025-09-20 12:14:27.322286


## Bot Information

**Creator:** @openai

**Description:** This intelligent small model from OpenAI is significantly smarter, cheaper, and just as fast as GPT-3.5 Turbo.

**Extra:** Powered by OpenAI: gpt-4o-mini-2024-07-18. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `GPT-4o-mini`

**Object Type:** model

**Created:** 1721338046069

**Owned By:** poe

**Root:** GPT-4o-mini
