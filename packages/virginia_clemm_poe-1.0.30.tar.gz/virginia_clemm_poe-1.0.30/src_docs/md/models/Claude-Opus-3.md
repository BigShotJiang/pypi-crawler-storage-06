# [Claude-Opus-3](https://poe.com/Claude-Opus-3){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Initial Points Cost | 1804+ points |
| Input | 468 points/1k tokens |
| Output (Text) | 2000 points/1k tokens |
| Cache Discount | 90% discount oncached chat |

**Last Checked:** 2025-09-20 12:05:08.233804


## Bot Information

**Creator:** @anthropic

**Description:** Anthropic's Claude Opus 3 can handle complex analysis, longer tasks with multiple steps, and higher-order math and coding tasks. Supports 200k tokens of context (approximately 150k English words).

**Extra:** Powered by Anthropic: claude-3-opus-20240229. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Claude-Opus-3`

**Object Type:** model

**Created:** 1709574492024

**Owned By:** poe

**Root:** Claude-Opus-3
