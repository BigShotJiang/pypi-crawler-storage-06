# [GPT-4-Classic-0314](https://poe.com/GPT-4-Classic-0314){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Initial Points Cost | 844+ points |
| Input | 900 points/1k tokens |
| Output (Text) | 1800 points/1k tokens |

**Last Checked:** 2025-09-20 12:13:26.904810


## Bot Information

**Creator:** @openai

**Description:** OpenAI's GPT-4 model. Powered by gpt-4-0314 (non-Turbo) for text input and gpt-4o for image input. For most use cases, https://poe.com/GPT-4o will perform significantly better.

**Extra:** Powered by OpenAI: gpt-4-0314. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `GPT-4-Classic-0314`

**Object Type:** model

**Created:** 1724707714433

**Owned By:** poe

**Root:** GPT-4-Classic-0314
