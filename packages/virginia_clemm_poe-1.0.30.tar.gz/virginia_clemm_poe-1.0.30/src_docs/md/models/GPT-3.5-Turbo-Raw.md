# [GPT-3.5-Turbo-Raw](https://poe.com/GPT-3.5-Turbo-Raw){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Input Text | 15 points/1k tokens |
| Input Image | Variable |
| Initial Points Cost | 16+ points |
| Output (Text) | 45 points/1k tokens |

**Last Checked:** 2025-09-20 12:13:12.455404


## Bot Information

**Creator:** @openai

**Description:** Powered by gpt-3.5-turbo without a system prompt.

**Extra:** Powered by OpenAI: gpt-3.5-turbo-0125. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `GPT-3.5-Turbo-Raw`

**Object Type:** model

**Created:** 1695849978857

**Owned By:** poe

**Root:** GPT-3.5-Turbo-Raw
