# [FLUX-Krea](https://poe.com/FLUX-Krea){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Image Output | 709 points / message |
| Initial Points Cost | 709 points |

**Last Checked:** 2025-09-20 12:10:13.098503


## Bot Information

**Creator:** @fal

**Description:** FLUX-Krea is a version of FLUX Dev tuned for superior aesthetics. Use "--aspect" to select an aspect ratio (e.g --aspect 1:1). Valid aspect ratios are 16:9, 4:3, 1:1, 3:4, 9:16.  Send an image to have this model reimagine/regenerate it via FLUX Krea Redux.

**Extra:** Powered by a server managed by @fal. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `FLUX-Krea`

**Object Type:** model

**Created:** 1753991501514

**Owned By:** poe

**Root:** FLUX-Krea
