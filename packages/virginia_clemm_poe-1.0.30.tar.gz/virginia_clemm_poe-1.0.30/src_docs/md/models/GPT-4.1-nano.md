# [GPT-4.1-nano](https://poe.com/GPT-4.1-nano){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Initial Points Cost | 7+ points |
| Input | 3 points/1k tokens |
| Output (Text) | 12 points/1k tokens |
| Cache Discount | 75% discount oncached chat |

**Last Checked:** 2025-09-20 12:13:57.372824


## Bot Information

**Creator:** @openai

**Description:** GPT-4.1 nano is an extremely fast and cheap model, ideal for text/vision summarization/categorization tasks. Supports native vision and 1M input tokens of context.

**Extra:** Powered by OpenAI: gpt-4.1-nano-2025-04-14. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `GPT-4.1-nano`

**Object Type:** model

**Created:** 1744675276376

**Owned By:** poe

**Root:** GPT-4.1-nano
