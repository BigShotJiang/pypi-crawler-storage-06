"""Rect module."""
from PyQt6 import QtCore  # type: ignore[import]


class Rect(QtCore.QRect):
    """Rect class."""

    pass
