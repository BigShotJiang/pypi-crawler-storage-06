"""Qdatetime module."""
from PyQt6 import QtCore  # type: ignore[import]


class QDateTime(QtCore.QDateTime):
    """QDateTime class."""

    pass
