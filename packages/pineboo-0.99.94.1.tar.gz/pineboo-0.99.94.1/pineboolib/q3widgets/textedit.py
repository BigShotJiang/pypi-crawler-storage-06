"""Textedit module."""
from pineboolib.q3widgets import qtextedit


class TextEdit(qtextedit.QTextEdit):
    """TextEdit class."""

    pass
