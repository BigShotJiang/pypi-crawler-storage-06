"""Timeedit module."""
from pineboolib.q3widgets import qtimeedit


class TimeEdit(qtimeedit.QTimeEdit):
    """TimeEdit class."""

    pass
