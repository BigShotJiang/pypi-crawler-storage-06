"""Qspinbox module."""
from PyQt6 import QtWidgets  # type: ignore[import]


class QSpinBox(QtWidgets.QSpinBox):
    """QSpinBox class."""

    pass
