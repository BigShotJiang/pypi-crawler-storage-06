"""
Qt3 UI emulation module.

Selection of widgets that emulate behavior from Qt3/Eneboo.
"""
