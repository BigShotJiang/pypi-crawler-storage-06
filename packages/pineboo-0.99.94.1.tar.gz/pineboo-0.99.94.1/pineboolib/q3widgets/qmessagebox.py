"""Qmessagebox module."""
from pineboolib.q3widgets import messagebox


class QMessageBox(messagebox.MessageBox):
    """QMessageBox class."""

    pass
