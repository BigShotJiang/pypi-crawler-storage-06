"""Line module."""

from pineboolib.q3widgets import qline


class Line(qline.QLine):
    """Line class."""

    pass
