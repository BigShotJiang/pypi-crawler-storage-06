"""Qdataview module."""
from pineboolib.q3widgets import qwidget


class QDataView(qwidget.QWidget):
    """QDataView class."""

    pass
