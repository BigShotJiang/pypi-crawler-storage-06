"""Combobox module."""

from pineboolib.q3widgets import qcombobox


class ComboBox(qcombobox.QComboBox):
    """ComboBox class."""

    pass
