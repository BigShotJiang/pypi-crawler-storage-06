"""Qlayout module."""
from pineboolib.q3widgets import qwidget


class QLayoutWidget(qwidget.QWidget):
    """QLayoutWidget class."""

    pass
