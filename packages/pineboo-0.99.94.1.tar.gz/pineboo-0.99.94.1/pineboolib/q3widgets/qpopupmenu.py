"""QPopupmenu module."""

from PyQt6 import QtWidgets  # type: ignore[import]


class QPopupMenu(QtWidgets.QMenu):
    """QPopupMenu class."""

    pass
