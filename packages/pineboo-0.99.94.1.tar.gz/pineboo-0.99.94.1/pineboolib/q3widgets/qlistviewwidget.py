"""Qlistviewwidget module."""
from PyQt6 import QtWidgets  # type: ignore[import]


class QListViewWidget(QtWidgets.QListWidget):
    """QListViewWidget class."""

    pass
