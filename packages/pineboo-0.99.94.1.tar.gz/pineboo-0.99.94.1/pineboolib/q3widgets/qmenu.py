"""Qmenu module."""
from PyQt6 import QtWidgets  # type: ignore[import]


class QMenu(QtWidgets.QMenu):
    """QMenu class."""

    pass
