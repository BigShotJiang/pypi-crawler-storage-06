"""Pixmap module."""
from PyQt6 import QtGui  # type: ignore[import]


class Pixmap(QtGui.QPixmap):
    """Pixmap class."""

    pass
