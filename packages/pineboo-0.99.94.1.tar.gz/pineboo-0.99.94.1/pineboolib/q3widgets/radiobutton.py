"""Radiobutton module."""
# -*- coding: utf-8 -*-

from pineboolib.q3widgets.qradiobutton import QRadioButton


class RadioButton(QRadioButton):
    """RadioButton class."""

    pass
