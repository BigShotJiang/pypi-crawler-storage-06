"""Size module."""
from PyQt6 import QtCore  # type: ignore[import]


class Size(QtCore.QSize):
    """Size class."""

    pass
