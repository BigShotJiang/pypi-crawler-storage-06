"""
Import dgi_schema to interface package.
"""
from pineboolib.plugins.dgi import dgi_schema as dgi_schema_module  # pragma: no cover

dgi_schema = dgi_schema_module.DgiSchema  # pragma: no cover # pylint: disable=invalid-name
