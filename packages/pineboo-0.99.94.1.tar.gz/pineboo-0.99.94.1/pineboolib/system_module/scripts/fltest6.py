"""Fltest6 module."""


class Prueba(object):
    """Class Prueba."""

    pass


public_class = "Prueba"  # pylint: disable=invalid-name
