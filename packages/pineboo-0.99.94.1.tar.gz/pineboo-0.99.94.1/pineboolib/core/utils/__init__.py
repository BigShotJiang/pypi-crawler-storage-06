"""
Package which holds core utilities.

Those are assorted utilities that don't depend on other Pineboo code
"""
