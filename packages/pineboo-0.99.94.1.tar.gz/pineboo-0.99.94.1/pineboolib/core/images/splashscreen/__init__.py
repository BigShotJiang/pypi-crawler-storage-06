"""Splashsreen package."""
