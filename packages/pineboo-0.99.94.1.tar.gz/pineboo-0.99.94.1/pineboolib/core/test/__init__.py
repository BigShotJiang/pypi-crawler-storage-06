"""
Tests for core.
"""
