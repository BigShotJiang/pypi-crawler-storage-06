"""
QSA Package.

Includes all sort of functions and classes for QS script compatibility.

"""
