"""
Only contains QSA tree. Don't touch!!.
"""
