"""
Packager package to manage .abanq and .eneboopkg packages.

Extract and generate files to distribute the modules.
"""
