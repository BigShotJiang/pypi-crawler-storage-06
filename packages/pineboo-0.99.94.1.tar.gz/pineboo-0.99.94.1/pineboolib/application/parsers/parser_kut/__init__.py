"""
Kugar Parser package.

Generates a PDF for now.
"""
