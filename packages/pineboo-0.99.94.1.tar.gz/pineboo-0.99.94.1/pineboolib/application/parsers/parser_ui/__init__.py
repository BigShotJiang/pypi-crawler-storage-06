"""
Qt3 UI Parser Module.

Module for reading old Qt3 Eneboo files and create Qt5 UI on the fly.
"""
