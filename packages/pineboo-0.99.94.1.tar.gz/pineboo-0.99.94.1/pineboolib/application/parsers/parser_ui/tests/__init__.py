"""
Tests for qt3ui package.
"""
