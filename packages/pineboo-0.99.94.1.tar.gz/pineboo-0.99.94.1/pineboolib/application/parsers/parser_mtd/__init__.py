"""
SqlAlchemy helpers for parsing MTD files.
"""
