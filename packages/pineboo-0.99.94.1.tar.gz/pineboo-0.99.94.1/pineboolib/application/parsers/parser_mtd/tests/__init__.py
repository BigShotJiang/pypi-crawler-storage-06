"""Test mtdparser package."""
