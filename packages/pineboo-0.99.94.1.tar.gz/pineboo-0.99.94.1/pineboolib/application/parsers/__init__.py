"""
Collection of parsers for reading Eneboo-compatible projects.
"""
