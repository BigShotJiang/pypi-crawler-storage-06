"""Staticloader ui module."""
