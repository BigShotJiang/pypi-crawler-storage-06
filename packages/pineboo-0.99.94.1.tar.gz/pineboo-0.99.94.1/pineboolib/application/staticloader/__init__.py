"""Staticloader package."""
