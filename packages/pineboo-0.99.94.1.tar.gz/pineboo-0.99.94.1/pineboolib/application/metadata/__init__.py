"""
Metadata package to manage fields, tables , relations and much more.

This package contains all the functions and classes to manage the application metadata.
"""
