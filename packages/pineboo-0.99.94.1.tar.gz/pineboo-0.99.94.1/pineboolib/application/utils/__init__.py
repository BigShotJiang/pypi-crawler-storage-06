"""
Utils package contains utilities needed for the application layer and higher.

The upper layers rely on these utilities to perform common functions, necessary for operation.
"""
