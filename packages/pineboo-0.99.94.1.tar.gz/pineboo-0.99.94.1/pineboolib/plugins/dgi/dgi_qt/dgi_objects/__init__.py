"""DGI_QT_OBJECTS package."""
