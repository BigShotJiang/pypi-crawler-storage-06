"""
Tests for sql plugins.
"""
