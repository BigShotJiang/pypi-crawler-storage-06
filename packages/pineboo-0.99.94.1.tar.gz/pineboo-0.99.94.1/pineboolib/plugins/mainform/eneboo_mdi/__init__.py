"""
Module for Eneboo MDI mainForm.

Creates the UI for the main application.
"""
