"""
Module for Eneboo mainForm.

Creates the UI for the main application.
"""
