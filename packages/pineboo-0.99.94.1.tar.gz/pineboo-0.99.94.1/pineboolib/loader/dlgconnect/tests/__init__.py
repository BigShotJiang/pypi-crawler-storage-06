"""
DlgConnect Package.

Connect dialog for pineboo.
"""
