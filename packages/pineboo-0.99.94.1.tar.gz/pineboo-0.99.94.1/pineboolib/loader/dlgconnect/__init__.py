"""dlgconnect package."""

from pineboolib.loader.dlgconnect.dlgconnect import DlgConnect  # noqa: F401
