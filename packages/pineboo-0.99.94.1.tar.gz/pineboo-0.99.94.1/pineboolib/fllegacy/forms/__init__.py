"""
Module for fllegacy forms.

Creates the UI's for fllegacy.
"""
