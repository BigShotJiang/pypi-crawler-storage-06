"""
FLLegacy Package.

These modules provide the necessary API to emulate the operation of Abanq / Eneboo.
"""
