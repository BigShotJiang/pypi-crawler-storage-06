"""FLJasperEngine module."""

from PyQt6 import QtCore  # type: ignore[import]


class FLJasperEngine(QtCore.QObject):
    """FLJasperEngine class."""

    pass
