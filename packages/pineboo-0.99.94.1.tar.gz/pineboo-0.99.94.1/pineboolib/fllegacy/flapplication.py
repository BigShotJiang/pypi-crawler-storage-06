"""FLApplication Module."""

from pineboolib.application import pnapplication


class FLApplication(pnapplication.PNApplication):
    """FLApplication Class."""

    pass
