"""Flsqlcursor module."""
from pineboolib.application.database import pnsqlcursor


class FLSqlCursor(pnsqlcursor.PNSqlCursor):
    """FLSqlCursor class."""

    pass
