"""Fljasperviewer module."""


class FLJasperViewer(object):
    """FLJasperViewer class."""

    pass
