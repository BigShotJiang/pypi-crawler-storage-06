# -*- coding: utf-8 -*-
"""
AQSmtpClient Module.

This class provides utilities to use a Smtp client.
"""

from pineboolib.fllegacy.flsmtpclient import FLSmtpClient


class AQSmtpClient(FLSmtpClient):
    """AQSmtpClient Class."""

    pass
