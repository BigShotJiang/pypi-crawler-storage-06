# -*- coding: utf-8 -*-
"""
AQSql Module.

Use the resources of pineboolib.application.database.pnsqlquery.PNSqlQuery.
"""

from pineboolib.application.database.pnsqlquery import PNSqlQuery


class AQSqlQuery(PNSqlQuery):
    """AQSql Class."""

    pass
