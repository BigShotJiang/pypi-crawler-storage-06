# -*- coding: utf-8 -*-
"""
AQSqlCursor Module.

Use the resources of pineboolib.application.database.pnsqlcursor.PNSqlCursor.
"""

from pineboolib.application.database import pnsqlcursor


class AQSqlCursor(pnsqlcursor.PNSqlCursor):
    """AQSqlCursor Class."""

    pass
