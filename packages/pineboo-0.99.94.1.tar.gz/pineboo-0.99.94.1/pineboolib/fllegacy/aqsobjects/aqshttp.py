"""AQSHttp module."""

from pineboolib.q3widgets import qhttp


class AQSHttp(qhttp.QHttp):
    """AQSHttp class."""

    pass


class AQSHttpRequestHeader(qhttp.QHttpRequestHeader):
    """AQSHttpRequestHeader class."""

    pass


class AQSHttpResponseHeader(qhttp.QHttpResponseHeader):
    """AQSHttpRequestHeader class."""

    pass
