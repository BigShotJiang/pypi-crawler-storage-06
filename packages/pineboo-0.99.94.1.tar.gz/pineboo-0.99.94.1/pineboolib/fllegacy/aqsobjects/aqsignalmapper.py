"""AQSignalmapper module."""

from PyQt6 import QtCore  # type: ignore[import]


class AQSignalMapper(QtCore.QSignalMapper):
    """AQSignalmapper class."""

    pass
