"""
Provides AQS type objects used in FLLegacy packages and QSA package.
"""
