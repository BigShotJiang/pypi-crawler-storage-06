"""Flsqlquery module."""
from pineboolib.application.database import pnsqlquery


class FLSqlQuery(pnsqlquery.PNSqlQuery):
    """FLSqlQuery class."""

    pass
