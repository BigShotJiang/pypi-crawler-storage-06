"""Flparamaterquey module."""
from pineboolib.application.database.pnparameterquery import PNParameterQuery


class FLParameterQuery(PNParameterQuery):
    """FLParameterQuery class."""

    pass
