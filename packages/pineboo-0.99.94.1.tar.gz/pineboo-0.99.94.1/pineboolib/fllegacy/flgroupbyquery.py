"""FLGroupByQuery Module."""
from pineboolib.application.database.pngroupbyquery import PNGroupByQuery


class FLGroupByQuery(PNGroupByQuery):
    """FLGroupByQuery Class."""

    pass
