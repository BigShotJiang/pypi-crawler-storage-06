/** @file py_func.cpp
 *
 *  Function table containing the functions used in the Sage - Pynac
 *  interface.
 *  */
#include "py_funcs.h"

namespace GiNaC {
  struct py_funcs_struct py_funcs;
}
