from payme.classes.client import Payme # noqa
