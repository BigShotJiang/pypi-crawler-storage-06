"""
init all payme exceptions
"""
from .general import * # noqa
from .webhook import * # noqa
