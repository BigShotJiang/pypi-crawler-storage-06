from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ......models.advanced_error import AdvancedError

class MigrateDefinitionRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/2/things/{thingId}/migrateDefinition
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new MigrateDefinitionRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/2/things/{thingId}/migrateDefinition{?dry%2Drun*}", path_parameters)
    
    async def post(self,body: bytes, request_configuration: Optional[RequestConfiguration[MigrateDefinitionRequestBuilderPostQueryParameters]] = None) -> Optional[bytes]:
        """
        Updates the definition of the specified thing by providing a new definition URL along with an optional migration payload.The request body allows specifying:- A new Thing definition URL.- A migration payload containing updates to attributes and features.- Patch conditions to ensure consistent updates.- Whether properties should be initialized if missing.If the `dry-run` query parameter or header is set to `true`, the request will return the calculated migration result without applying any changes.### Example:```json{  "thingDefinitionUrl": "https://example.com/new-thing-definition.json",  "migrationPayload": {    "attributes": {      "manufacturer": "New Corp"    },    "features": {      "sensor": {        "properties": {          "status": {            "temperature": {              "value": 25.0            }          }        }      }    }  },  "patchConditions": {    "thing:/features/sensor": "not(exists(/features/sensor))"  },  "initializeMissingPropertiesFromDefaults": true}```
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: bytes
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        from ......models.advanced_error import AdvancedError

        error_mapping: dict[str, type[ParsableFactory]] = {
            "400": AdvancedError,
            "401": AdvancedError,
            "404": AdvancedError,
            "412": AdvancedError,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        return await self.request_adapter.send_primitive_async(request_info, "bytes", error_mapping)
    
    def to_post_request_information(self,body: UntypedNode, request_configuration: Optional[RequestConfiguration[MigrateDefinitionRequestBuilderPostQueryParameters]] = None) -> RequestInformation:
        """
        Updates the definition of the specified thing by providing a new definition URL along with an optional migration payload.The request body allows specifying:- A new Thing definition URL.- A migration payload containing updates to attributes and features.- Patch conditions to ensure consistent updates.- Whether properties should be initialized if missing.If the `dry-run` query parameter or header is set to `true`, the request will return the calculated migration result without applying any changes.### Example:```json{  "thingDefinitionUrl": "https://example.com/new-thing-definition.json",  "migrationPayload": {    "attributes": {      "manufacturer": "New Corp"    },    "features": {      "sensor": {        "properties": {          "status": {            "temperature": {              "value": 25.0            }          }        }      }    }  },  "patchConditions": {    "thing:/features/sensor": "not(exists(/features/sensor))"  },  "initializeMissingPropertiesFromDefaults": true}```
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_scalar(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> MigrateDefinitionRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: MigrateDefinitionRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return MigrateDefinitionRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class MigrateDefinitionRequestBuilderPostQueryParameters():
        """
        Updates the definition of the specified thing by providing a new definition URL along with an optional migration payload.The request body allows specifying:- A new Thing definition URL.- A migration payload containing updates to attributes and features.- Patch conditions to ensure consistent updates.- Whether properties should be initialized if missing.If the `dry-run` query parameter or header is set to `true`, the request will return the calculated migration result without applying any changes.### Example:```json{  "thingDefinitionUrl": "https://example.com/new-thing-definition.json",  "migrationPayload": {    "attributes": {      "manufacturer": "New Corp"    },    "features": {      "sensor": {        "properties": {          "status": {            "temperature": {              "value": 25.0            }          }        }      }    }  },  "patchConditions": {    "thing:/features/sensor": "not(exists(/features/sensor))"  },  "initializeMissingPropertiesFromDefaults": true}```
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "dry_run":
                return "dry%2Drun"
            return original_name
        
        # If set to `true`, performs a dry-run and returns the migration result without applying changes.
        dry_run: Optional[bool] = None

    
    @dataclass
    class MigrateDefinitionRequestBuilderPostRequestConfiguration(RequestConfiguration[MigrateDefinitionRequestBuilderPostQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

