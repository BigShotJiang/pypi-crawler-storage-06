from enum import Enum

class LogLevel(str, Enum):
    Success = "success",
    Failure = "failure",

