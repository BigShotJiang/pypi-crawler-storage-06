__author__ = "Kapil Sachdeva"
__application__ = "ditto-client"
__version__ = "0.1.0"
