"""Prerendering to accommodate template languages."""

from .types import BasePreprocessor

__all__ = ["BasePreprocessor"]
