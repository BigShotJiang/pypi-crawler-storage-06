"""Class-ordering processors for attribute strings."""

__all__ = ["BaseClassOrderingAttributeProcessor"]
