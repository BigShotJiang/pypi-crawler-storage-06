
# MaxNumberLib
مكتبة لإيجاد أكبر رقم في قائمة أو مجموعة من الأعداد.

## CMD
MaxNumberLib 3 9 1 5

## Python
from max_number import find_max
numbers = [3, 9, 1, 5]
print(find_max(numbers)) # 9

