""" Test for clear cache. Doesn't need anything here"""
