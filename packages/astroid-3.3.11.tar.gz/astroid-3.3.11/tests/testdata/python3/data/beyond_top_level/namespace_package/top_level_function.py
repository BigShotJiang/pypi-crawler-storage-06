from .lower_level.helper_function import plugin_message


def do_something():
    return plugin_message("called by do_something")
