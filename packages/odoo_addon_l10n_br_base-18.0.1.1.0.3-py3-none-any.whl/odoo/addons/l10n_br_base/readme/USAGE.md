Após ter o endereço da empresa configurado, no cadastro do parceiro você
encotrar os campos CNPJ, CPF, IE, RG e os campos de endereço formatado
para o Brasil. Caso você tenha apenas o módulo base instalado, você pode
instalar o módulo Contact para acessar o cadastro de parceiros.
