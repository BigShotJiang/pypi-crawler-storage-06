from .ImageFolder import ImageFolder
from .CIFAR10 import CIFAR10