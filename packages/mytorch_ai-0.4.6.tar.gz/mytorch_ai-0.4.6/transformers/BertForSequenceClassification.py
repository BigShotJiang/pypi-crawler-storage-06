###############################################################################
# Copyright (c) 2024 MyTorch Systems Inc. All rights reserved.
###############################################################################

'''
This is a factory class that can be used to instantiate a Bert model for sequence classification from a pretrained model.
'''

from transformers.PreTrainedModel import PreTrainedModel
from proxies.mytransformers.HuggingFaceModel_proxy import HuggingFaceModelProxy

class BertForSequenceClassification(PreTrainedModel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @classmethod
    def _get_model_uuid(cls, pretrained_model_name_or_path, *args, **kwargs):
        return HuggingFaceModelProxy().getBertModelForSequenceClassification(pretrained_model_name_or_path, *args, **kwargs)
