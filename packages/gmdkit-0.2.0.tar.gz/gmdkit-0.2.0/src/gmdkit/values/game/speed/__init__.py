# All values are in units per second
SLOW = 0.7 * 5.98000200 * 60
NORMAL = 0.9 * 5.77000189 * 60
FAST = 1.1 * 5.87000200 * 60
VERY_FAST = 1.3 * 5.77000189 * 60
SUPER_FAST = 1.6 * 5.77000189 * 60
