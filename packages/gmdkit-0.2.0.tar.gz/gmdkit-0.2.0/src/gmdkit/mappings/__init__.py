__all__ = ["color_id","color_prop","obj_id","lvl_prop","obj_prop"]

from gmdkit.mappings import obj_id
from gmdkit.mappings import lvl_prop
from gmdkit.mappings import obj_prop
from gmdkit.mappings import color_id
from gmdkit.mappings import  color_prop