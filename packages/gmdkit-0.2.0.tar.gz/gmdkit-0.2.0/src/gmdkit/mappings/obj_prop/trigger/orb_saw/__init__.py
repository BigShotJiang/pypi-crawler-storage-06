ROTATION_SPEED = 97
from . import disable
