from merlin.models.load import Merlin

__all__ = ["Merlin"]