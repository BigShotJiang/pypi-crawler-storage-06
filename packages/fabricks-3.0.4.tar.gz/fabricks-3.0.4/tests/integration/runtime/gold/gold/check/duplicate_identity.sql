select 1 as __identity, 1 as id
union all
select 1 as __identity, 2 as id
