from typing import Literal

IOModes = Literal["overwrite", "append"]
