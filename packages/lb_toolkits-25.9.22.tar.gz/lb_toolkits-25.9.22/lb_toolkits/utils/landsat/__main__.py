import sys

from lb_toolkits.utils.landsat import cli as main

sys.exit(main())
