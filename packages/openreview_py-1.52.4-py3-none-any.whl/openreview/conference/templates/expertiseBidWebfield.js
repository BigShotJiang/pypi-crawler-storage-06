// Webfield component

var CONFERENCE_ID = '';
return {
  component: 'ExpertiseConsole',
  properties: {
    venueId: CONFERENCE_ID,
    apiVersion: 1
  }
}