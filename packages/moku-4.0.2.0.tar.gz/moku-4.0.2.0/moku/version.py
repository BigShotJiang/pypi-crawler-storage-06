SUPPORTED_PROXY_VERSION = 2.0  # Proxy 2.0 first appeared in MokuOS 4.0.1
COMPAT_MOKUOS = ">=4.0.1"  # For now this is only used for the error message, the proxy version is used for the compatibility check
COMPAT_MOKUCLI = ">=4.0.1"  # Used to enforce mokucli compatibility
