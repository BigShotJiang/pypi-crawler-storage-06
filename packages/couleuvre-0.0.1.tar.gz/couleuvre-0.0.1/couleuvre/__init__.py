from couleuvre.main import server  # noqa: F401
