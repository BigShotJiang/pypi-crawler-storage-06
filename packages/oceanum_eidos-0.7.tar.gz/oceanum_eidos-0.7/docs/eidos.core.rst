eidos.core package
==================

Submodules
----------

eidos.core.dataspec module
--------------------------

.. automodule:: eidos.core.dataspec
   :members:
   :undoc-members:
   :show-inheritance:

eidos.core.node module
----------------------

.. automodule:: eidos.core.node
   :members:
   :undoc-members:
   :show-inheritance:

eidos.core.root module
----------------------

.. automodule:: eidos.core.root
   :members:
   :undoc-members:
   :show-inheritance:

eidos.core.state module
-----------------------

.. automodule:: eidos.core.state
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: eidos.core
   :members:
   :undoc-members:
   :show-inheritance:
