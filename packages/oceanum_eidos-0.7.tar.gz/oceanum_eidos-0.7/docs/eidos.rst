eidos package
=============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   eidos
   eidos.nodes

Submodules
----------

eidos.base module
-----------------

.. automodule:: eidos.base
   :members:
   :undoc-members:
   :show-inheritance:

eidos.features module
---------------------

.. automodule:: eidos.features
   :members:
   :undoc-members:
   :show-inheritance:

eidos.oceanql module
--------------------

.. automodule:: eidos.oceanql
   :members:
   :undoc-members:
   :show-inheritance:

eidos.vegaspec module
---------------------

.. automodule:: eidos.vegaspec
   :members:
   :undoc-members:
   :show-inheritance:

eidos.version module
--------------------

.. automodule:: eidos.version
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: eidos
   :members:
   :undoc-members:
   :show-inheritance:
