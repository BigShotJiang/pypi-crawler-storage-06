# eidos-python

These are the python bindings for EIDOS. This repo is a submodule of the oceanum library and is not intended to be used by itself.
