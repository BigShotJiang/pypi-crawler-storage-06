class EidosError(Exception):
    """Base class for eidos exceptions."""


class EidosSpecError(EidosError):
    """Base class for eidos spec exceptions."""
