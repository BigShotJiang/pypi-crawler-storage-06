.. autoclass:: core.rule_engine.ResultAggregation
   :private-members:
   :undoc-members:

.. autoclass:: core.rule_engine.RuleEngine
   :members:
   :special-members: __init__, __call__
   :private-members:
   :undoc-members:

.. autoclass:: core.rule_engine.RuleEngineFactory
   :members:
   :special-members: __init__, __call__
   :private-members:
   :undoc-members: