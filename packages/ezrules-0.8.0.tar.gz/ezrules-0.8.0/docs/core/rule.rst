.. autoclass:: core.rule.Rule
   :members:
   :special-members: __init__, __call__
   :private-members:
   :undoc-members: