.. _executor_api:

Business logic executor API
===========================