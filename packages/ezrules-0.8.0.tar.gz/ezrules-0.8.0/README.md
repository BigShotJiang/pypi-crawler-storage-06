# ezrules

Welcome to an open-source transaction monitoring engine! This product is designed to simplify the definition and management of business rules while also offering a scalable infrastructure for rule execution and backtesting.

Read the [quick start guide](https://github.com/sofeikov/ezrules/wiki/Quick-start) to get started.