'Text mode instances of ProgramHandle for every executable, with dash translated to underscore e.g. `from lagoon.text import pkg_config` for `pkg-config`.'
__import__('lagoon.scan')
