'Commands with an underscore already in their name, text mode.'
__import__('lagoon.scan')
