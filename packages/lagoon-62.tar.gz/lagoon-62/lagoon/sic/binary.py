'Commands with an underscore already in their name, binary mode.'
__import__('lagoon.scan')
