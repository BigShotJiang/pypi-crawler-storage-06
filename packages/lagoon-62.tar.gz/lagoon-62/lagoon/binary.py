'Like lagoon.text module but ProgramHandle objects are in binary mode.'
__import__('lagoon.scan')
