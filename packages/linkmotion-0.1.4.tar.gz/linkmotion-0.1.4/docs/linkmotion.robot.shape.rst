linkmotion.robot.shape package
==============================

Submodules
----------

linkmotion.robot.shape.base module
----------------------------------

.. automodule:: linkmotion.robot.shape.base
   :members:
   :show-inheritance:
   :undoc-members:

linkmotion.robot.shape.box module
---------------------------------

.. automodule:: linkmotion.robot.shape.box
   :members:
   :show-inheritance:
   :undoc-members:

linkmotion.robot.shape.capsule module
-------------------------------------

.. automodule:: linkmotion.robot.shape.capsule
   :members:
   :show-inheritance:
   :undoc-members:

linkmotion.robot.shape.cone module
----------------------------------

.. automodule:: linkmotion.robot.shape.cone
   :members:
   :show-inheritance:
   :undoc-members:

linkmotion.robot.shape.convex module
------------------------------------

.. automodule:: linkmotion.robot.shape.convex
   :members:
   :show-inheritance:
   :undoc-members:

linkmotion.robot.shape.cylinder module
--------------------------------------

.. automodule:: linkmotion.robot.shape.cylinder
   :members:
   :show-inheritance:
   :undoc-members:

linkmotion.robot.shape.mesh module
----------------------------------

.. automodule:: linkmotion.robot.shape.mesh
   :members:
   :show-inheritance:
   :undoc-members:

linkmotion.robot.shape.sphere module
------------------------------------

.. automodule:: linkmotion.robot.shape.sphere
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: linkmotion.robot.shape
   :members:
   :show-inheritance:
   :undoc-members:
