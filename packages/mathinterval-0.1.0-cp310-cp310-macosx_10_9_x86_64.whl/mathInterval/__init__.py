from .mathInterval import *
from .mathInterval import __doc__
