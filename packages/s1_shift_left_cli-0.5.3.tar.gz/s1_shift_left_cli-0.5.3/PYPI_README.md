# SentinelOne CNS CLI
SentinelOne CNS is an extension of our vision to shift-left security with SentinelOne. It is the newest edition to the toolset that will help to keep our customer’s cloud infrastructure safe from external threats and ensure the highest quality standard for security while writing and deploying code.

## LICENSE
For licensing information, please visit [this link](https://gist.github.com/github-deployments/095443a36187f59a0c107e32a3e77d4d).