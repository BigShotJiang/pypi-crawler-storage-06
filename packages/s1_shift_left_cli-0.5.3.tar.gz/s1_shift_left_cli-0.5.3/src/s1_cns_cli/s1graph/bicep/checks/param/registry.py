from s1_cns_cli.s1graph.bicep.checks.param.base_registry import Registry

registry = Registry()
