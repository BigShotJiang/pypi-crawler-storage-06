from __future__ import annotations
from typing import Any

from s1_cns_cli.s1graph.circleci_pipelines.base_circleci_pipelines_check import BaseCircleCIPipelinesCheck
from s1_cns_cli.s1graph.common.models.enums import CheckResult
from s1_cns_cli.s1graph.yaml_doc.enums import BlockType


class DetectImageUsage(BaseCircleCIPipelinesCheck):
    def __init__(self) -> None:
        name = "Detecting image usages in circleci pipelines"
        id = "CKV_CIRCLECIPIPELINES_8"
        super().__init__(
            name=name,
            id=id,
            block_type=BlockType.ARRAY,
            supported_entities=(
                "executors.*.docker[].{image: image, __startline__: __startline__, __endline__:__endline__}",
                "jobs.*.docker[].{image: image, __startline__: __startline__, __endline__:__endline__}",
            )
        )

    def scan_conf(self, conf: dict[str, Any]) -> tuple[CheckResult, dict[str, Any]]:
        return CheckResult.PASSED, conf


check = DetectImageUsage()
