# flake8: noqa
terms = [
    "\$*CIRCLE_PR_REPONAME*",
    "\$*CIRCLE_PR_USERNAME*",
    "\$*CIRCLE_PULL_REQUESTS*",
    "\$*CIRCLE_TAG*",
    "\$*CIRCLE_BRANCH*"
]
