# SPARKS
## **S**oftware for **P**olymerization **A**nd **R**eaction **K**inetic **S**imulations

