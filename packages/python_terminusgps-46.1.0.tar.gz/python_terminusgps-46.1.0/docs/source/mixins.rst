Mixins
======

.. autoclass:: terminusgps.mixins.HtmxTemplateResponseMixin
    :members:
