"""
Fixtures for PyTgGram tests
"""
