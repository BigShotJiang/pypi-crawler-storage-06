# Telegram API utilities and helpers
