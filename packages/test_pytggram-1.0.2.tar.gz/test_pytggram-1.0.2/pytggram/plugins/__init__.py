# Plugin system for PyTgGram
# Plugins can be developed as separate packages and imported here

__all__ = []  # List of available plugins
