from safelz4._cli._entry import main

__all__ = ["main"]
