from safelz4._cli._entry import main


def run():
    import sys as _sys

    _sys.exit(main())


if __name__ == "__main__":
    run()
