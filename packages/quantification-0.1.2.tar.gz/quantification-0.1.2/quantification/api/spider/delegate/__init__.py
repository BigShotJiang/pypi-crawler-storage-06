from .baidu_index import BaiduIndexDelegate
