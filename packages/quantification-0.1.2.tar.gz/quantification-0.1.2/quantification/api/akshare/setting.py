from pydantic import BaseModel


class AkShareSetting(BaseModel):
    ...
