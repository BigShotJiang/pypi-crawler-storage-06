from quantification import SingleTrader


class SimpleTrader(SingleTrader):
    ...


__all__ = ['SimpleTrader']
