from .trader import AFactorTrader
