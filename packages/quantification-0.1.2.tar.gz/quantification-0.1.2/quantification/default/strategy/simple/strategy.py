from quantification import BaseStrategy


class SimpleStrategy(BaseStrategy):
    ...


__all__ = ['SimpleStrategy']
