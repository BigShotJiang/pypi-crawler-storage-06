# -*- coding: utf-8; -*-

from tailbone import auth as mod
