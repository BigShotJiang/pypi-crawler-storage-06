
``tailbone.api.batch.core``
===========================

.. automodule:: tailbone.api.batch.core

.. autoclass:: APIBatchMixin

.. autoclass:: APIBatchView

.. autoclass:: APIBatchRowView

   .. autoattribute:: editable

   .. autoattribute:: supports_quick_entry
