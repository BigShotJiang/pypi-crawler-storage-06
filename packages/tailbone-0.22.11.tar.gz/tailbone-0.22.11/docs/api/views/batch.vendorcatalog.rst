
``tailbone.views.batch.vendorcatalog``
======================================

.. automodule:: tailbone.views.batch.vendorcatalog

.. autoclass:: VendorCatalogsView
   :members:

.. autofunction:: includeme
