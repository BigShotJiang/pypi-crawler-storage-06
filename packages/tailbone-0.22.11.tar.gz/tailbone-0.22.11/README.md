
# Tailbone

Tailbone is an extensible web application based on Rattail.  It provides a
"back-office network environment" (BONE) for use in managing retail data.

Please see Rattail's [home page](http://rattailproject.org/) for more
information.
