[Usage instructions](https://oca.github.io/OpenUpgrade/analyse.html)
