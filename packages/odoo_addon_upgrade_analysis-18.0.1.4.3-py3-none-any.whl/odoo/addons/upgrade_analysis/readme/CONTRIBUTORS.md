- Stefan Rijnhart \<<stefan@opener.amsterdam>\>
- Holger Brunn \<<hbrunn@therp.nl>\>
- Ferdinand Gassauer \<<gass@cc-l-12.chircar.at>\>
- Florent Xicluna \<<florent.xicluna@gmail.com>\>
- Miquel Raïch \<<miquel.raich@forgeflow.com>\>
- Sylvain LE GAL \<<https://twitter.com/legalsylvain>\>
- [Tecnativa](https://www.tecnativa.com):

  > - Pedro M. Baeza
  > - Sergio Teruel
