- Log removed modules in the module that owned them (#468)
- Detect renamed many2many tables (#213)
- Make sure that the `migration_analysis.txt` file is always generated
  in all cases. (See:
  <https://github.com/OCA/OpenUpgrade/pull/3209#issuecomment-1157449981>)
