from . import odoo_patch
from . import models
from . import wizards
from . import blacklist
from . import compare
from . import upgrade_log
