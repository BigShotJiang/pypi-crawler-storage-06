from . import addons
from . import odoo
from . import odoo_patch
