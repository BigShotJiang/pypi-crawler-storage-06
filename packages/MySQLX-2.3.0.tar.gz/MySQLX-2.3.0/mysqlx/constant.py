from sqlexecx.constant import CACHE_SIZE

SQL_CACHE_SIZE = CACHE_SIZE << 1

MODULE = 'MySQLX'

DYNAMIC_REGEX = '{%|{{|}}|%}'
