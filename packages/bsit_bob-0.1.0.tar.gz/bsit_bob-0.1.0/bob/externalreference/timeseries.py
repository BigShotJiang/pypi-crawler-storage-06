from ..core import P223, ExternalReference

_namespace = P223


class NiagaraORDReference(ExternalReference):
    _class_iri = None


class TimeSeriesReference(ExternalReference):
    _class_iri = None
