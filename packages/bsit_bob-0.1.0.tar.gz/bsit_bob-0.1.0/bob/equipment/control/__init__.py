# Controller
from ...connections.controlsignal import (
    ModulationSignalInletConnectionPoint as AnalogInput,
)
from ...connections.controlsignal import (
    ModulationSignalOutletConnectionPoint as AnalogOutput,
)
from ...connections.controlsignal import OnOffSignalInletConnectionPoint as BinaryInput
from ...connections.controlsignal import (
    OnOffSignalOutletConnectionPoint as BinaryOutput,
)
