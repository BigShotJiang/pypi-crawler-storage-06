from .sensor import Sensor, split_kwargs
