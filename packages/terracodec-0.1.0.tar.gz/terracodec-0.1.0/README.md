# TerraCodec
TerraCodec: Compressing Earth Observations

WORK IN PROGRESS.
