from mcp-client import main
main()
