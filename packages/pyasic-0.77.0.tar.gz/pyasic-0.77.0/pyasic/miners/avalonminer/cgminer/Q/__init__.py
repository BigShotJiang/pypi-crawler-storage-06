from .Q import CGMinerAvalonQHome
