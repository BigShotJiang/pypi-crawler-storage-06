from dlt.common.exceptions import DltException


class RuntimeException(DltException):
    pass
