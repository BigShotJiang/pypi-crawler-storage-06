
.. image:: https://badge.fury.io/py/galaxy-job-execution.svg
   :target: https://pypi.org/project/galaxy-job-execution/


Overview
--------

The Galaxy_ job execution runtime module.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
