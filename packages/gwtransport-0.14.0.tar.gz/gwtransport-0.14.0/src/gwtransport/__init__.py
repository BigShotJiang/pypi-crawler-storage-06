"""gwtransport: A Python package for solving one-dimensional groundwater transport problems."""

import importlib.metadata as m

__version__ = m.version("gwtransport")
