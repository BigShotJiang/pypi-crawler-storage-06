"""APaper models module."""

from .paper import Paper, read_pdf

__all__ = ["Paper", "read_pdf"]