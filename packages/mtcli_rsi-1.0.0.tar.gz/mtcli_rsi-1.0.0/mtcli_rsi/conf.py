digitos = 0
stop_loss = 150
take_profit = 300
symbol = WINV25
