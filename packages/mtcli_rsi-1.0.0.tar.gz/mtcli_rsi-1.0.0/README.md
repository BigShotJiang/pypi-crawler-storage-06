# mtcli-rsi
  
Plugin mtcli que calcula o indicador RSI.
    
---
  
## Instalação
  
```cmd
git clone git@github.com:vfranca/mtcli-rsi.git
cd mtcli-rsi
pip install .
```
