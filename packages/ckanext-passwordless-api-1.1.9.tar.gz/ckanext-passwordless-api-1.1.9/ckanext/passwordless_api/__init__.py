"""Plugin ckanext-passwordless_api."""
