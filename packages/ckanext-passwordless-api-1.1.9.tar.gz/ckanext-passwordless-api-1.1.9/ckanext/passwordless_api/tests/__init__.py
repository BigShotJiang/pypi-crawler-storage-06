"""Tests for ckanext-passwordless_api plugin."""
