"""
Core functionality modules for SpeechShift
"""
