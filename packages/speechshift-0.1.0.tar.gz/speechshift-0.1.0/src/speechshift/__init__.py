"""
SpeechShift - A speech-to-text application for Arch Linux + Hyprland
"""

__version__ = "0.1.0"
__author__ = "Bharat Kalluri"
__email__ = "kalluribharat@gmail.com"
