# Copyright (c) 2017-2022, NVIDIA CORPORATION.  All rights reserved.

"""EULA for TAO DEPLOY."""
