- Enric Tobella
- Olga Marco

- [Tecnativa](https://tecnativa.com)
  - Carlos Roca
