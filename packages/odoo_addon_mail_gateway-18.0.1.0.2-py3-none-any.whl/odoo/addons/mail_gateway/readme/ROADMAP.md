1. Make possible to schedule gateway messages.
