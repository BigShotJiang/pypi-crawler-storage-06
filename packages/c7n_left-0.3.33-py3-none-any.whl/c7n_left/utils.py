# Copyright The Cloud Custodian Authors.
# SPDX-License-Identifier: Apache-2.0
#


SEVERITY_LEVELS = {"critical": 0, "high": 10, "medium": 20, "low": 30, "unknown": 40}
