# Reemote 

Reemote is a Python API for task automation, configuration management and application deployment.

Visit [reemote.org](https://reemote.org/).

# Example

![Screenshot](docs/source/gui/Screenshot_20250921_203424.png)

![Screenshot](docs/source/gui/Screenshot_20250921_203907.png)

![Screenshot](docs/source/gui/Screenshot_20250921_204117.png)

![Screenshot](docs/source/gui/Screenshot_20250921_204130.png)

![Screenshot](docs/source/gui/Screenshot_20250921_204140.png)


# Installation

Install from PyPI 

```bash
pip install reemote
```
