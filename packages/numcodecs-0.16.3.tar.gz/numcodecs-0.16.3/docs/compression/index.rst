Compression codecs
------------------

.. toctree::
    :maxdepth: 2

    blosc
    bz2
    gzip
    lzma
    lz4
    pcodec
    zfpy
    zlib
    zstd
