Other codecs
------------


.. toctree::
    :maxdepth: 2

    json
    pickles
    msgpacks
    vlen
