Shuffle
=======
.. automodule:: numcodecs.shuffle

.. autoclass:: Shuffle

    .. autoattribute:: codec_id
    .. automethod:: encode
    .. automethod:: decode
