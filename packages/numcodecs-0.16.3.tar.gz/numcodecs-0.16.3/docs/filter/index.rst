Filter codecs
-------------

.. toctree::
    :maxdepth: 2

    delta
    fixedscaleoffset
    quantize
    bitround
    packbits
    categorize
    astype
    shuffle
