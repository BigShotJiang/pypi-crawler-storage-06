AsType
======
.. automodule:: numcodecs.astype

.. autoclass:: AsType

    .. autoattribute:: codec_id
    .. automethod:: encode
    .. automethod:: decode
    .. automethod:: get_config
    .. automethod:: from_config
