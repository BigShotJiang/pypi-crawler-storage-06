Contributing
============

Please see the [project documentation](https://numcodecs.readthedocs.io/en/stable/contributing.html) for information about contributing to NumCodecs.
