
default_states = ['initialized', 'configued', 'started', 'running', 'stopping', 'stopped']
