from .qna_routes import register_qna_fastapi_routes
from .base import create_fastapi_app
from .vac_routes import VACRoutesFastAPI, VACRequest