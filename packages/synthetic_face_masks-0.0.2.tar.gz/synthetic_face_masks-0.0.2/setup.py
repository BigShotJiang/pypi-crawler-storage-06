#!/usr/bin/env python3
"""
Minimal setup.py for backward compatibility.
All configuration is now in pyproject.toml.
"""

from setuptools import setup

# All configuration is now in pyproject.toml
setup()
