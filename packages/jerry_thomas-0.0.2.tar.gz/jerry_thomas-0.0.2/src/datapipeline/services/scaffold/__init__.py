"""Scaffold service package: domain, source, plugin, templates."""

