The :ref:`/spec/plans/finish` step plugins implement actions to be
performed after the test execution has been completed. These can
be useful for finishing tasks such as an additional guest cleanup
or uploading specific logs to an external server.
