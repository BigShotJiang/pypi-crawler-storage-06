.. _/plugins/test-checks/internal:

Internal Checks
---------------

Some checks are internal-only, perform mandatory actions, and cannot be
selected or disabled by user in test metadata. Names of such checks
begin with ``internal/`` prefix.
