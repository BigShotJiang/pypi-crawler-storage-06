tmt-report-result /direct/good PASS
tmt-report-result /direct/skip SKIP
