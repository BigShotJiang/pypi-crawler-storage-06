#!/bin/bash

echo "A simple test for importing target run having a single line"
