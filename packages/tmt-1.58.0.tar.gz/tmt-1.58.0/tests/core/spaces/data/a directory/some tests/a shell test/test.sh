#!/bin/bash
echo "Everything's fine!"
