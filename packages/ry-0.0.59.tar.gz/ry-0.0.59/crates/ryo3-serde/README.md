# `ryo3-serde`

python + `serde` crate.

`serde`:

- [crates.io](https://crates.io/crates/serde)
- [docs.rs](https://docs.rs/serde)
