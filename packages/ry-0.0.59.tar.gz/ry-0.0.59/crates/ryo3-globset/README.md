# `ryo3-globset`

ryo3-wrapper for `globset` crate

[//]: # "<GENERATED>"

## Ref:

- docs.rs: [https://docs.rs/globset](https://docs.rs/globset)
- crates: [https://crates.io/crates/globset](https://crates.io/crates/globset)

[//]: # "</GENERATED>"
