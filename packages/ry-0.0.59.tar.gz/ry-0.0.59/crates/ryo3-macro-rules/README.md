# `ryo3-macro-rules`

internal macros
