.. _understanding_vortexpy:

=======================
Understanding VortexPy
=======================

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    introducing_vortexpy.rst
    defer_util/IndexDeferUtil.rst

