"""Code for exposing Polars Cloud functionality to the CLI."""

from polars_cloud.cli.main import cli

__all__ = ["cli"]
