"""Configuration module for pdf_form_field."""


from .main import main

if __name__ == "__main__":
    main()
