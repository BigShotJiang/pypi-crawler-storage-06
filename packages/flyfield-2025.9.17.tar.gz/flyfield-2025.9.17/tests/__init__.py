"""
Test package initialization for flyfield.

This module marks the tests package and can be used for test
package-level fixtures or initialization if needed.
"""
