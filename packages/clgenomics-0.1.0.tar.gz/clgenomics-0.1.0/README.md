# clgenomics
Continual learning for genomics AI
