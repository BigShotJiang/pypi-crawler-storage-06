"""Yahoo platform implementation"""

from .client import YahooClient

__all__ = ['YahooClient']