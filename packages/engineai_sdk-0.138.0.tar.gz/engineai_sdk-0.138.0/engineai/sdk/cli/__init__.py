"""CLI for platform SDK."""
