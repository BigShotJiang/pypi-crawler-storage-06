"""Spec for Select widget."""

from .select import Select

__all__ = ["Select"]
