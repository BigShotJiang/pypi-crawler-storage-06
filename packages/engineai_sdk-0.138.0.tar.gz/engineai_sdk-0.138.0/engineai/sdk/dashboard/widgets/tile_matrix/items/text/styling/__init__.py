"""Specs for Tile Matrix text item stylings."""
