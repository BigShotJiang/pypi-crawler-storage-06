"""Specs for Sankey Series widget."""
