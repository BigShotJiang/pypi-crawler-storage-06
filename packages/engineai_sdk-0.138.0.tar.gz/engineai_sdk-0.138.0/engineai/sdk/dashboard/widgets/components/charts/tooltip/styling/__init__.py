"""Spec for tooltip styling components."""
