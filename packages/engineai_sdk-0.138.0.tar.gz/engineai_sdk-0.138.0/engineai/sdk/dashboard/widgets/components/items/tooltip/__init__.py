"""Tooltip components for chart widgets."""
