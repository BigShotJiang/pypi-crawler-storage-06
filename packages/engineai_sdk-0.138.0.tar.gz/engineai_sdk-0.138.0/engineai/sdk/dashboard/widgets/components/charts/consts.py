"""Constants for data dependency ids used by different widgets."""

BANDS_DEPENDENCY = "__BANDS_DEPENDENCY__"
LINES_DEPENDENCY = "__LINES_DEPENDENCY__"
