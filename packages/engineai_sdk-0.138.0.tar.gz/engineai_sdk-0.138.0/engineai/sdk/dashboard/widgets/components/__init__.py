"""Specs for components of widgets."""
