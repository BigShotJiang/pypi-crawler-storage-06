"""Specs for axis shared by different chart widgets."""
