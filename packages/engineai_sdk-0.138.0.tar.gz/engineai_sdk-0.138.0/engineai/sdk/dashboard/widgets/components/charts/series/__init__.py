"""Series Base Class."""
