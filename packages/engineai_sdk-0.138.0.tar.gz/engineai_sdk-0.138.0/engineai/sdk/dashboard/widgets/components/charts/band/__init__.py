"""Specs for AxisBand."""
