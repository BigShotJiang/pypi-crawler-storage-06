"""Country tooltip item styling typings."""

from .flag import CountryTooltipItemStylingFlag

CountryTooltipItemStyling = CountryTooltipItemStylingFlag
