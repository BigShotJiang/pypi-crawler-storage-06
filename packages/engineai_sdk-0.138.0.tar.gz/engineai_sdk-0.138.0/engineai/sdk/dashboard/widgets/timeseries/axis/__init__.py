"""Specs for axis of a Timeseries widget."""
