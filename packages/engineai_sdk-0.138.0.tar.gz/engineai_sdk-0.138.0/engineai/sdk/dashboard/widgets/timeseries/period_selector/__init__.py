"""Specs for period selector of a timeseries widget."""
