"""Specs for axis of a Categorical widget."""
