"""Specs for series in a Cartesian chart."""
