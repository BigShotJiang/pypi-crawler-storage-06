"""Specs for series in a Shape series."""
