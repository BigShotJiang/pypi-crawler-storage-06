"""Map Styling resources."""
