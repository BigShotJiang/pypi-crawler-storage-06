"""Layout components for dashboard headers, chips, and labels."""
