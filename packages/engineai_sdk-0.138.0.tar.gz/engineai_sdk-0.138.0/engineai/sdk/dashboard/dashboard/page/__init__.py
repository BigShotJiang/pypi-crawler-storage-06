"""Specs for Dashboard Route classes."""
