"""Specs for DuckDB Connector Dependency."""

from .duck_db_connector import DuckDBConnectorDependency

__all__ = ["DuckDBConnectorDependency"]
