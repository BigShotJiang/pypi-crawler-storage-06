"""Spec for Styling resources."""

from .icons import Icons

__all__ = [
    # .icons
    "Icons",
]
