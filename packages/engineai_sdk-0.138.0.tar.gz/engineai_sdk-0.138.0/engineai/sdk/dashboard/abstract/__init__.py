"""Abstract classes."""

from .selectable_widgets import AbstractSelectWidget

__all__ = [
    "AbstractSelectWidget",
]
