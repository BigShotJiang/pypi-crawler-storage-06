# "minimal fork" of tof-control
Forked of https://github.com/GAPS-Collab/tof-control

* only necessary libraries
* removes everything else, e.g. tui components


