from .similarity import SimilarityClassifier

__all__ = [
    "SimilarityClassifier",
]
