"""BERTopic-based grouper for clustering devices."""

from .bertopic_grouper import BERTopicGrouper

__all__ = ["BERTopicGrouper"]
