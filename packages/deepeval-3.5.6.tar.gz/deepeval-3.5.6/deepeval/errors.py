class MissingTestCaseParamsError(Exception):
    pass


class MismatchedTestCaseInputsError(Exception):
    pass
