from django.apps import AppConfig


class Admin2FaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_admin_2fa_plus"
