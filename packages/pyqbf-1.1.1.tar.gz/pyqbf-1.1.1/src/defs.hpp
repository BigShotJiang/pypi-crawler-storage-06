#pragma once

namespace pyqbf {
using literal = int;
using LitVector = std::vector<int>;
}

