//Needed for the global variables declared in the main.cpp file
//sets the necessary default values for those options
int verbose=0;
int use_blocking=1;
int use_pure=1; 
int use_universal_reduction=0; 