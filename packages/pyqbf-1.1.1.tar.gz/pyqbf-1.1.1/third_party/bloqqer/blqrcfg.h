#ifndef blqrcfg_h_INCLUDED
#define blqrcfg_h_INCLUDED
#define BLQR_ID "8660cb92fefe93bf9a8565b34f956dc918db650c"
#define BLQR_VERSION "037"
#define BLQR_CFLAGS "-Wall -DNLOG -DNDEBUG -O3"
#endif
