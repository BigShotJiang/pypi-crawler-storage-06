#include "blqrcfg.h"

const char * blqr_id () { return BLQR_ID; }
const char * blqr_version () { return BLQR_VERSION; }
const char * blqr_cflags () { return BLQR_CFLAGS; }
