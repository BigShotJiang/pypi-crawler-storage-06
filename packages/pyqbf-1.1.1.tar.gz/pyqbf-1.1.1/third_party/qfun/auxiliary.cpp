/*
 * File:  auxiliary.cpp
 * Author:  mikolas
 * Created on:  Mon Sep 4 15:26:08 WEST 2017
 * Copyright (C) 2017, Mikolas Janota
 */
#include "auxiliary.h"
