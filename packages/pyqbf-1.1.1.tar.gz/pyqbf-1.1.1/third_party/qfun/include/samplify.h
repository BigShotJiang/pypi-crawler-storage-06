/*
 * File:  samplify.h
 * Author:  mikolas
 * Created on:  23 Feb 2017 17:57:16
 * Copyright (C) 2017, Mikolas Janota
 */
#ifndef SAMPLIFY_H_8399
#define SAMPLIFY_H_8399
#endif /* SAMPLIFY_H_8399 */
