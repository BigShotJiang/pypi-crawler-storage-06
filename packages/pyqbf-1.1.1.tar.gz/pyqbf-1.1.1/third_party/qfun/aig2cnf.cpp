/*
 * File:  aig2cnf.cpp
 * Author:  mikolas
 * Created on:  15 Jan 2017 16:28:04
 * Copyright (C) 2017, Mikolas Janota
 */
#include "aig2cnf.h"
