/*
 * File:  samplify.cpp
 * Author:  mikolas
 * Created on:  23 Feb 2017 17:57:09
 * Copyright (C) 2017, Mikolas Janota
 */
#include"samplify.h"

void run() {
    //const auto ef = encoder(f);
}
