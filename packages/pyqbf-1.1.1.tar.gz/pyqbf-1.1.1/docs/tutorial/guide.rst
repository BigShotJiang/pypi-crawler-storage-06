Tutorial
=========

.. toctree::
   :maxdepth: 1
   :caption: Base Features

   load_formulas
   modify_prefix
   modify_matrix
   solving

.. toctree::
   :maxdepth: 1
   :caption: Advanced Features

   incr_solving