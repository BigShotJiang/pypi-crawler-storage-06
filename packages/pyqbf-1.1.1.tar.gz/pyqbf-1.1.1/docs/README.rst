PyQBF
=====

**PyQBF** is a Python library trying to simplify the usage of QBF solvers.