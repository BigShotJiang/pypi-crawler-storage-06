from .cli import CliDatabase

CliDatabase().main()
