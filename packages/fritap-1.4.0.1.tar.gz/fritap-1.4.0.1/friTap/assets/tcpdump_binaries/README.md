# Precompiled tcpdump binaries

## ARM based Android devices
The precompiled tcpdump version for ARM and ARM64 are taken from [androidtcpdump.com](https://www.androidtcpdump.com/android-tcpdump/downloads)

## x86 based Android devices
The precompiled tcpdump version for x86 and x86-64 are taken from [github.com/extremecoders-re](https://github.com/extremecoders-re/tcpdump-android-builds/releases)


## ARM based iOS devices
Currently you have to install tcpdump to your iPhone on your own 
