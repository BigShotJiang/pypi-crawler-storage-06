"""
Edge TTS引擎模块
"""

from .tts import EdgeTTS

__all__ = ["EdgeTTS"]
