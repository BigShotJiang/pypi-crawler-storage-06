from .base import BaseTTS


__all__ = ["BaseTTS"]
