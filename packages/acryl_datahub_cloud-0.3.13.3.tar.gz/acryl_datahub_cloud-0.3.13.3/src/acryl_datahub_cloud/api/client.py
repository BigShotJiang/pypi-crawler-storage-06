from datahub.ingestion.graph.client import DataHubGraph


# Add other graph mixins here when applicable
class AcrylGraph(DataHubGraph):
    pass
