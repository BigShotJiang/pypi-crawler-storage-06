"""Version of zcatalyst SDK"""

__version__ = '1.0.2'
