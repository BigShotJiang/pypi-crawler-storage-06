from __future__ import annotations

# Depending on ur config, VSCode might indicate this is not being used. It is.
from .runner import main
from .client import TwooterClient
from .config import Config
