from __future__ import annotations

from metricflow_semantics.test_helpers.config_helpers import DirectoryPathAnchor

NON_SM_MANIFEST_ANCHOR = DirectoryPathAnchor()
