from __future__ import annotations

from metricflow_semantics.test_helpers.config_helpers import DirectoryPathAnchor

CYCLIC_JOIN_MANIFEST_ANCHOR = DirectoryPathAnchor()
