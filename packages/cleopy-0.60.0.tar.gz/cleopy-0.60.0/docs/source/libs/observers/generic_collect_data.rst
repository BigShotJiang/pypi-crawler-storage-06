Generic Collect Data
====================

Header file: ``<libs/observers/generic_collect_data.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/observers/generic_collect_data.hpp>`_

.. doxygenstruct:: XarrayAndViews
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenclass:: GenericCollectData
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:
