from __future__ import annotations

# Do not forget that, as otherwise diracx won't find your DBs
__all__ = ("sql",)

from . import sql
