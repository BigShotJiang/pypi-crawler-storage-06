TODO

how to mechanically create the extension (reference to gubbins)
