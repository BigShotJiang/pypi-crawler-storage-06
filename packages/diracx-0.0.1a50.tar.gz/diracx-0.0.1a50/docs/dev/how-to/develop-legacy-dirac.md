# How to develop legacy DIRAC (or other packages)

It's often useful to be able to develop the code for both DiracX (or a third party package) at the same.
