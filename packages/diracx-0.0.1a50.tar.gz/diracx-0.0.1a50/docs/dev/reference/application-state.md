# TODO

whatever is a singletin

- engine context
- config source
- etc

Dependency injection mechanism

- dependency injections (in a service you do this, in a task you do this)
