CONFIG = {
    "name": "Filter",
    "short_description": "The Filter application will filter the results of the analysis.",
    "long_description": "The Filter application will filter the results of the analysis. You can use a list or regular expression to filter the concept that re returned.",  # noqa: E501
}
