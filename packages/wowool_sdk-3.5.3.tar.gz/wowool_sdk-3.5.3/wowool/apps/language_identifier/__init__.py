from wowool.native.core.language_identifier import LanguageIdentifier  # noqa: F401
from wowool.apps.language_identifier.app_id import APP_ID  # noqa: F401
