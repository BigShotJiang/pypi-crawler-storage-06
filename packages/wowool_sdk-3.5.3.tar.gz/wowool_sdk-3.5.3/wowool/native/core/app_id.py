# Note: Use underscores and keep items sorted
# flake8: noqa: E501
from wowool.document.analysis.text_analysis import APP_ID as APP_ID_WOWOOL_ANALYSIS

APP_ID_WOWOOL_LANGUAGE_IDENTIFIER = "wowool_language_identifier"
APP_ID_WOWOOL_DOMAIN = "wowool_domain"
APP_ID_WOWOOL_COMPILER = "wowool_compiler"
APP_ID_WOWOOL_FILTER = "wowool_filter"
