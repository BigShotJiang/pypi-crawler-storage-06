from .main import MUSIC_SUFFIXES
from .main import main as lrc_play

__all__ = ["MUSIC_SUFFIXES", "lrc_play"]
