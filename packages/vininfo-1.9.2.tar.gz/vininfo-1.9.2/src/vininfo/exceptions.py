
class VininfoException(Exception):
    """Base exception."""


class ValidationError(VininfoException):
    """Data validation exception."""
