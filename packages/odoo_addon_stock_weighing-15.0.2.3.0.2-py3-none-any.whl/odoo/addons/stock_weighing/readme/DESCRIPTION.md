A shopfloor assistant for weighing on stock operations.
