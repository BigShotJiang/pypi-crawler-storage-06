Some bussiness must weigh their operations in order to process them. For example in
fresh product factories where the demand could not fit the exact a amount of delivered
product and that depends on the final operation weight.
