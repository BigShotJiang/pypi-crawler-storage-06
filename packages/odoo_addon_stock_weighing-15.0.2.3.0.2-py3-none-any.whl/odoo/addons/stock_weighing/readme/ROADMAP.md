- This PR should be https://github.com/odoo/odoo/pull/161042 merged in order to reload
  the kanban view properly after each action. Otherwise we should reimplement the whole
  core method in our override.
