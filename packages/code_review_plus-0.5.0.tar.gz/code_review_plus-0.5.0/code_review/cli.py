import click


@click.group()
def cli() -> None:
    """A simple command-line tool for git operations."""
    pass
