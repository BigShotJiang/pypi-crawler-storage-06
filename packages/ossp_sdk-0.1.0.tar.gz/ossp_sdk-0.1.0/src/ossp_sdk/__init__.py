"""OSSP Python SDK package."""

from .client import OSSPClient

__all__ = ["OSSPClient"]
__version__ = "0.1.0"
