"""
Package purpose: defining known plotters for an EppicCalculator.
"""

from .eppic_plotter_manager import EppicPlotterManager
