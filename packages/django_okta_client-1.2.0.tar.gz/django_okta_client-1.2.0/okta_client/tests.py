#python
"""
Tests for the Okta Client.
"""

from django.test import TestCase

# Create your tests here.
