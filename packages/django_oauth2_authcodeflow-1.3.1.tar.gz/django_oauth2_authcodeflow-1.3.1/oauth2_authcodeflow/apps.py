from django.apps import AppConfig


class Oauth2AuthcodeflowConfig(AppConfig):
    name = 'oauth2_authcodeflow'
