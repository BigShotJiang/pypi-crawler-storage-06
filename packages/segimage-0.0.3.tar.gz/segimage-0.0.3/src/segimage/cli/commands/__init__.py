"""CLI commands for segimage."""


