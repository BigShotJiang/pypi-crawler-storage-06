from pyschare.search_data import _Search

def search():
    new_instance= _Search()
    return new_instance

search()