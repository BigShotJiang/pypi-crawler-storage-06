import JobsData from "../components/JobsData";

export default function Jobs() {

  return (
    <div className='flex w-screen h-screen p-2 flex-col'>
      <JobsData />
    </div>
  );
}
