collect_ignore = ["cysignals-CSI-helper.py"]
