This is an open-source project maintained by the SageMath community.

The [Code of Conduct](https://github.com/sagemath/sage/blob/develop/CODE_OF_CONDUCT.md)
of the Sage community applies.
