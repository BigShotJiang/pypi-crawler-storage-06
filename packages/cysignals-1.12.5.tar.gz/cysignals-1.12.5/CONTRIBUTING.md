This is an open-source project maintained by the SageMath community.

Contributions of all sorts are heartily welcomed.

See https://github.com/sagemath/sage/blob/develop/CONTRIBUTING.md for general
guidance on how to contribute.

Open issues or submit pull requests at https://github.com/sagemath/cysignals
and join https://groups.google.com/group/sage-devel to discuss.
