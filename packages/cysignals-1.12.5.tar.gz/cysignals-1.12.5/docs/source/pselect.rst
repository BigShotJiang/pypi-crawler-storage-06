.. highlight:: python

.. automodule:: cysignals.pselect
    :members:
    :special-members: __enter__, __exit__
