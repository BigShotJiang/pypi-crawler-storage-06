.. highlight:: python

.. automodule:: cysignals.pysignals
    :members:
