from ._fastgraphFPMS import Graph

__all__ = ["Graph"]
__version__ = "0.1.1"