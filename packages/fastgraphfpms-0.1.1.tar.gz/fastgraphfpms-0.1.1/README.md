# fastgraphFPMS

Librairie Python codé en C pour le cours de graph et d'optimisation combinatoire.

Pour installer la librairie : pip install fastgraphFPMS