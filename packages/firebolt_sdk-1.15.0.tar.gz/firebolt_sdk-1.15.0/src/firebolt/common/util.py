# Prevent backward compatibility errors related to new module structure
from firebolt.utils.util import *  # NOQA
