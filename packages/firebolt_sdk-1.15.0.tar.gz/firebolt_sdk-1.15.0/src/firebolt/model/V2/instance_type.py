from enum import Enum


class InstanceType(Enum):
    S = "S"
    M = "M"
    L = "L"
    XL = "XL"
