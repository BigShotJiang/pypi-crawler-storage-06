# Temporary fix for airflow-provider-firebolt
class Engine:
    pass
