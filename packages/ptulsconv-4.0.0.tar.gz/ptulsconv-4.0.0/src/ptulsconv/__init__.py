"""
Parse and convert Pro Tools text exports
"""

__copyright__ = "ptulsconv (c) 2025 Jamie Hardt. All rights reserved."
