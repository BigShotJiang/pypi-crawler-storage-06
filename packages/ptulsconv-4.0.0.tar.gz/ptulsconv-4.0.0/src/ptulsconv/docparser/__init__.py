"""
Docparser module
"""

from .pt_doc_parser import parse_document
