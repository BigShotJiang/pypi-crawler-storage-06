# import ffmpeg # ffmpeg-python

# TODO: Implement movie export

# def create_movie(event):
#     start = event['Movie.Start_Offset_Seconds']
#     duration = event['PT.Clip.Finish_Seconds'] -
# event['PT.Clip.Start_Seconds']
#     input_movie = event['Movie.Filename']
#     print("Will make movie starting at {}, dur {} from movie {}"
#          .format(start, duration, input_movie))
#
#
# def export_movies(events):
#     for event in events:
#         create_movie(event)
