# TODO: Complete Recordist Log

def output_report(records):
    # order by start

    pass
