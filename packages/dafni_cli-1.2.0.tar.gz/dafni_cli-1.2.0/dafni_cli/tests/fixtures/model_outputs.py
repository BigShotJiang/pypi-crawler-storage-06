TEST_MODEL_OUTPUTS: dict = {
    "datasets": [
        {
            "name": "example_dataset.csv",
            "type": "CSV",
            "description": "",
        },
    ]
}
