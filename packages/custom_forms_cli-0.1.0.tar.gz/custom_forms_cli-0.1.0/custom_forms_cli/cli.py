# custom_forms_cli/custom_forms_cli/cli.py

from custom_forms_cli.automate import app

if __name__ == "__main__":
    app()