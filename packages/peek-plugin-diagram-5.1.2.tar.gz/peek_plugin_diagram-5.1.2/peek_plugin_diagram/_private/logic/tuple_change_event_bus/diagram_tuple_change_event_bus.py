from vortex.event_bus.TupleChangeEventBus import TupleChangeEventBus

plDiagramTupleChangeEventBus = TupleChangeEventBus()
