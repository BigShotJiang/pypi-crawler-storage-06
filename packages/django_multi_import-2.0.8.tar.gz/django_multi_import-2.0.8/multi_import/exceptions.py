class InvalidDatasetError(Exception):
    pass


class InvalidFileError(Exception):
    pass
