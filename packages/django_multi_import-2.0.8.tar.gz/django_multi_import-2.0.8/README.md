# django-multi-import

Import/export multi Django resources together atomically.

## Usage

You can run the tests with via::

    python setup.py test

or::

    python runtests.py
