"""The DPO7AX commands module.

THIS FILE IS AUTO-GENERATED, IT SHOULD NOT BE MANUALLY MODIFIED.

Please report an issue if one is found.
"""

from typing import Dict, Optional

from tm_devices.driver_mixins.device_control.pi_control import PIControl
from tm_devices.helpers import ReadOnlyCachedProperty as cached_property  # noqa: N813

from .gen_7iy04z_dpolpdmso.actonevent import Actonevent
from .gen_7iy04z_dpolpdmso.afg import Afg
from .gen_7iy04z_dpolpdmso.alias import Alias
from .gen_7iy04z_dpolpdmso.application import Application
from .gen_7iy04z_dpolpdmso.autosaveuitimeout import Autosaveuitimeout
from .gen_7iy04z_dpolpdmso.autoset import Autoset
from .gen_7iy04z_dpolpdmso.busy import Busy
from .gen_7iy04z_dpolpdmso.calibrate import Calibrate
from .gen_7iy04z_dpolpdmso.calibration import Cal
from .gen_7iy04z_dpolpdmso.callouts import Callouts
from .gen_7iy04z_dpolpdmso.curvestream import Curvestream
from .gen_7iy04z_dpolpdmso.customtable import Customtable
from .gen_7iy04z_dpolpdmso.dese import Dese
from .gen_7iy04z_dpolpdmso.diggrp import DiggrpItem
from .gen_7iy04z_dpolpdmso.ethernet import Ethernet
from .gen_7iy04z_dpolpdmso.event import Event
from .gen_7iy04z_dpolpdmso.evmsg import Evmsg
from .gen_7iy04z_dpolpdmso.evqty import Evqty
from .gen_7iy04z_dpolpdmso.eyemask import Eyemask
from .gen_7iy04z_dpolpdmso.filesystem import Filesystem
from .gen_7iy04z_dpolpdmso.header import Header
from .gen_7iy04z_dpolpdmso.hostprocessor import Hostprocessor
from .gen_7iy04z_dpolpdmso.hsinterface import Hsinterface
from .gen_7iy04z_dpolpdmso.license import License
from .gen_7iy04z_dpolpdmso.lock import Lock
from .gen_7iy04z_dpolpdmso.mainwindow import Mainwindow
from .gen_7iy04z_dpolpdmso.mask import Mask
from .gen_7iy04z_dpolpdmso.matharbflt import MatharbfltItem
from .gen_7iy04z_dpolpdmso.miscellaneous import Ddt, Lrn
from .gen_7iy04z_dpolpdmso.pilogger import Pilogger
from .gen_7iy04z_dpolpdmso.recall import Recall
from .gen_7iy04z_dpolpdmso.ref import Ref
from .gen_7iy04z_dpolpdmso.rem import Rem
from .gen_7iy04z_dpolpdmso.saveon import Saveon
from .gen_7iy04z_dpolpdmso.saveonevent import Saveonevent
from .gen_7iy04z_dpolpdmso.searchtable import Searchtable
from .gen_7iy04z_dpolpdmso.select import Select
from .gen_7iy04z_dpolpdmso.set import Set
from .gen_7iy04z_dpolpdmso.socketserver import Socketserver
from .gen_7iy04z_dpolpdmso.status_and_error import Ese, Opc, Rst
from .gen_7iy04z_dpolpdmso.time import Time
from .gen_7iy04z_dpolpdmso.touchscreen import Touchscreen
from .gen_7iy04z_dpolpdmso.unlock import Unlock
from .gen_7iy04z_dpolpdmso.verbose import Verbose
from .gen_7iy04z_dpolpdmso.vertical import Vertical
from .gen_7iy04z_dpolpdmso.visual import Visual
from .gen_7iy04z_dpolpdmso.wfmoutpre import Wfmoutpre
from .gen_7mgf9c_dpolpdmso.connected import Connected
from .gen_7mgf9c_dpolpdmso.usbdevice import Usbdevice
from .gen_7mgf9c_dpolpdmso.vxi import Vxi
from .gen_7nicld_dpolpdmdomso.clear import Clear
from .gen_8mnybb_dpodsalpdmdomso.newpass import Newpass
from .gen_8mnybb_dpodsalpdmdomso.password import Password
from .gen_8mnybb_dpodsalpdmdomso.teksecure import Teksecure
from .gen_8n7m9m_afgawgdpodsalpdmdomso.miscellaneous import Trg
from .gen_22bw6e_dpo.acquire import Acquire
from .gen_22bw6e_dpo.auxin import Auxin
from .gen_22bw6e_dpo.auxout import Auxout
from .gen_22bw6e_dpo.bus import Bus
from .gen_22bw6e_dpo.ch import Channel
from .gen_22bw6e_dpo.data import Data
from .gen_22bw6e_dpo.diag import Diag
from .gen_22bw6e_dpo.display import Display
from .gen_22bw6e_dpo.fpanel import Fpanel
from .gen_22bw6e_dpo.histogram import Histogram
from .gen_22bw6e_dpo.horizontal import Horizontal
from .gen_22bw6e_dpo.math import Math
from .gen_22bw6e_dpo.measurement import Measurement
from .gen_22bw6e_dpo.peakstable import Peakstable
from .gen_22bw6e_dpo.plot import Plot
from .gen_22bw6e_dpo.rosc import Rosc
from .gen_22bw6e_dpo.save import Save
from .gen_22bw6e_dpo.search import Search
from .gen_22bw6e_dpo.security import Security
from .gen_22bw6e_dpo.sv import Sv
from .gen_22bw6e_dpo.trigger import Trigger
from .gen_gln9hu_dpolpdmdomsotekscopepc.pause import Pause
from .gen_gokm3g_dpolpdmsotekscopepc.ref import RefItem
from .gen_gqpvc0_dpolpdmsotekscopepc.autosavepitimeout import Autosavepitimeout
from .gen_gqpvc0_dpolpdmsotekscopepc.bustable import Bustable
from .gen_gqpvc0_dpolpdmsotekscopepc.configuration import Configuration
from .gen_gqpvc0_dpolpdmsotekscopepc.date import Date
from .gen_gqpvc0_dpolpdmsotekscopepc.meastable import Meastable
from .gen_gqpvc0_dpolpdmsotekscopepc.undo import Undo
from .gen_grm6e3_dpolpdmdomsotekscopepc.totaluptime import Totaluptime
from .gen_gthlnl_afgawgdpodsalpdmdomsotekscopepc.status_and_error import Opt
from .gen_gz3vfu_afgawgdpodsalpdmdomsotekscopepc.miscellaneous import Idn, Tst
from .gen_gz3vfu_afgawgdpodsalpdmdomsotekscopepc.status_and_error import Cls, Esr, Stb, Wai
from .gen_gz6oku_awgdpodsalpdmdomsotekscopepc.status_and_error import Sre
from .gen_gz835c_dpodsalpdmdomsotekscopepc.allev import Allev
from .gen_gz835c_dpodsalpdmdomsotekscopepc.factory import Factory
from .gen_gz835c_dpodsalpdmdomsotekscopepc.id import Id
from .gen_gz835c_dpodsalpdmdomsotekscopepc.status_and_error import Psc, Pud
from .gen_gz835c_dpodsalpdmdomsotekscopepc.wavfrm import Wavfrm
from .helpers import DefaultDictPassKeyToFactory


# pylint: disable=too-few-public-methods
class DPO7AXCommandConstants:
    """The DPO7AX command argument constants.

    This provides access to all the string constants which can be used as arguments for DPO7AX
    commands.
    """

    A = "A"
    ABC = "ABC"
    ABCB = "ABCB"
    ABORT = "ABORT"
    # ABORT = "ABORt"
    # ABORT = "ABOrt"
    ABSOLUTE = "ABSOLUTE"  # ABSolute
    ACBC = "ACBC"
    ACCEPTS = "ACCEPTS"  # ACCepts
    ACCM = "ACCM"
    ACK = "ACK"
    ACKMISS = "ACKMISS"
    ACQ = "ACQ"
    ADD = "ADD"
    ADDR10 = "ADDR10"
    ADDR32 = "ADDR32"
    ADDR64 = "ADDR64"
    ADDR7 = "ADDR7"
    ADDRANDDATA = "ADDRANDDATA"
    ADDRESS = "ADDRESS"  # ADDRess
    ADH = "ADH"
    ADS = "ADS"
    ADVANCED = "ADVANCED"  # ADVanced
    AF = "AF"
    AFI = "AFI"
    AFREQUENCIES = "AFREQUENCIES"  # AFREQuencies
    AL1 = "AL1"
    ALARMSEARCH = "ALARMSEARCH"  # ALARMSEARch
    ALL = "ALL"
    ALLBITS = "ALLBITS"  # ALLBits
    ALWAYS = "ALWAYS"
    AN = "AN"
    ANALOG = "ANALOG"
    AND = "AND"
    ANY = "ANY"
    # ANY = "Any"
    ANYERROR = "ANYERROR"  # ANYERRor
    AOPERATION = "AOPERATION"
    APASS = "APASS"  # APASs
    APPLY = "APPLY"
    APPPWR = "APPPWR"
    APPPWRSUM = "APPPWRSUM"
    APRD = "APRD"
    APRW = "APRW"
    APWR = "APWR"
    ARBITRARY = "ARBITRARY"  # ARBitrary
    ARINC429 = "ARINC429"
    ARMATRIGB = "ARMATRIGB"  # ARMAtrigb
    ARMW = "ARMW"
    ARROW = "ARROW"
    ASCII = "ASCII"
    # ASCII = "ASCIi"
    # ASCII = "ASCii"
    ASIC = "ASIC"
    ATQBCOMP = "ATQBCOMP"
    ATQBPROP = "ATQBPROP"
    ATRREQ = "ATRREQ"  # ATRReq
    ATRRES = "ATRRES"  # ATRRes
    ATTRIB = "ATTRIB"
    AUDIO = "AUDIO"  # AUDio
    AUTHCRYPTO = "AUTHCRYPTO"  # AUTHCRYPto
    AUTHENTICATE = "AUTHENTICATE"  # AUTHenticate
    AUTO = "AUTO"
    AUTOMATIC = "AUTOMATIC"  # AUTOmatic
    AUTOSET = "AUTOSET"  # AUTOset
    AUXILIARY = "AUXILIARY"  # AUXiliary
    AVERAGE = "AVERAGE"  # AVErage
    B = "B"
    BACA = "BACA"
    BACKWARD = "BACKWARD"  # BACKWard
    BADDR = "BADDR"  # BADDr
    BADGE = "BADGE"
    BASIC = "BASIC"  # BASic
    BDIFFBP = "BDIFFBP"
    BEACON = "BEACON"  # BEACon
    BESSELCUSTOM = "BESSELCUSTOM"  # BESSelCUSTom
    BINARY = "BINARY"
    # BINARY = "BINary"
    BITS = "BITS"
    BITSTUFFING = "BITSTUFFING"  # BITSTUFFing
    BLACKMANHARRIS = "BLACKMANHARRIS"  # BLACkmanharris
    BLOCKID = "BLOCKID"  # BLOCkid
    BM = "BM"
    BMP = "BMP"
    BMSGEND = "BMSGEND"  # BMSGEnd
    BN = "BN"
    BOOKMARK = "BOOKMARK"
    BOTH = "BOTH"
    BPASS = "BPASS"  # BPASs
    BRD = "BRD"
    BROADCAST = "BROADCAST"  # BROadcast
    BRW = "BRW"
    BSTOP = "BSTOP"  # BSTop
    BURST = "BURST"  # BURSt
    BUS = "BUS"
    # BUS = "Bus"
    BUSANDWAVEFORM = "BUSANDWAVEFORM"
    BUSTURNAROUND = "BUSTURNAROUND"  # BUSTURNAROUnd
    BUSY = "BUSY"
    BUTTERWORTH = "BUTTERWORTH"  # BUTTerworth
    BWR = "BWR"
    BYTE = "BYTE"  # BYTe
    CAN = "CAN"
    CAN2X = "CAN2X"
    CAN2X_FDISO_XL = "CAN2X_FDISO_XL"
    CANH = "CANH"
    CANL = "CANL"
    CAN_XL = "CAN_XL"
    CAS = "CAS"
    CDATA = "CDATA"  # CDATa
    CDOTS = "CDOTS"  # CDOTs
    CHALLENGE = "CHALLENGE"  # CHALlenge
    CHANNEL = "CHANNEL"  # CHANnel
    CHARACTER = "CHARACTER"  # CHARacter
    CHEBYONE = "CHEBYONE"  # CHEBYONe
    CHEBYTWO = "CHEBYTWO"  # CHEBYTWo
    CHECKSUM = "CHECKSUM"
    # CHECKSUM = "CHecksum"
    CHINDEPENDENT = "CHINDEPENDENT"  # CHINDependent
    CIRCULATING = "CIRCULATING"  # CIRCulating
    CLEAR = "CLEAR"
    # CLEAR = "CLEar"
    CLOCK = "CLOCK"
    CLOCKEDGE = "CLOCKEDGE"  # ClockEdge
    CMD = "CMD"
    CMDCODE = "CMDCODE"  # CMDCODe
    CMDOPCODE = "CMDOPCODE"  # CMDOPCODe
    CN = "CN"
    CNT = "CNT"
    COM = "COM"
    COMM = "COMM"
    COMMAND = "COMMAND"
    # COMMAND = "COMMand"
    COMMONMODE = "COMMONMODE"
    COMPATTERN = "COMPATTERN"  # COMPATTern
    COMPLETE = "COMPLETE"  # COMPlete
    COMPLETION = "COMPLETION"
    COMPRESSION = "COMPRESSION"  # COMPression
    CONFIG = "CONFIG"
    CONFIGURE = "CONFIGURE"  # CONFigure
    CONNECT = "CONNECT"  # CONNect
    CONSTANTCLOCK = "CONSTANTCLOCK"
    CONTINUOUS = "CONTINUOUS"  # CONTinuous
    CONTROL = "CONTROL"
    # CONTROL = "CONTRol"
    # CONTROL = "CONTrol"
    CONTROLCH = "CONTROLCH"
    CONTROLCHAR = "CONTROLCHAR"
    CONTROLCODE = "CONTROLCODE"  # CONTROLCODe
    CONTROLMESSAGE = "CONTROLMESSAGE"  # CONTROLMESSage
    COUNTER = "COUNTER"  # COUNter
    CP1 = "CP1"
    CP3 = "CP3"
    CP4 = "CP4"
    CP56 = "CP56"
    CP78 = "CP78"
    CR = "CR"
    CRC = "CRC"
    CRC16 = "CRC16"
    CRC32 = "CRC32"
    CRC5 = "CRC5"
    CRCERROR = "CRCERROR"  # CRCERRor
    CRCHEADER = "CRCHEADER"  # CRCHeader
    CRCTRAILER = "CRCTRAILER"  # CRCTrailer
    CRCTYPES = "CRCTYPES"  # CRCTYPes
    CSI = "CSI"
    CSPLIT = "CSPLIT"
    CURSOR = "CURSOR"  # CURsor
    CUSTOM = "CUSTOM"
    # CUSTOM = "CUSTom"
    # CUSTOM = "custom"
    CYCLE = "CYCLE"
    CYCLECOUNT = "CYCLECOUNT"  # CYCLEcount
    CYCLETYPE = "CYCLETYPE"  # CYCLETYPe
    DADDR = "DADDR"  # DADDr
    DAH = "DAH"
    DAS = "DAS"
    DATA = "DATA"
    # DATA = "DATa"
    DATAGRAM = "DATAGRAM"  # DATagram
    DATAPACKET = "DATAPACKET"  # DATAPacket
    DBM = "DBM"
    DC = "DC"
    DCP1W2 = "DCP1W2"
    DCPWR = "DCPWR"
    DDATA = "DDATA"  # DDATa
    DECIMAL = "DECIMAL"
    DEFAULTSETUP = "DEFAULTSETUP"  # DEFaultsetup
    DEFECT = "DEFECT"  # DEFect
    DEFER = "DEFER"  # DEFer
    DEFGRPA = "DEFGRPA"  # DEFGRPa
    DEPREQ = "DEPREQ"  # DEPReq
    DEPRES = "DEPRES"  # DEPRes
    DETAIL = "DETAIL"  # DETail
    DEVERROR = "DEVERROR"  # DEVERRor
    DEVICE = "DEVICE"  # DEVice
    DEVICEADDR = "DEVICEADDR"
    DEVICECHIRP = "DEVICECHIRP"  # DEVICEChirp
    DEVICEDESCMASTERREAD = "DEVICEDESCMASTERREAD"  # DEVICEDESCMASTERREAd
    DEVICEDESCSLAVEREAD = "DEVICEDESCSLAVEREAD"  # DEVICEDESCSLAVEREAd
    DEVICETYPE = "DEVICETYPE"  # DEVICETYPe
    DEVNOTIF = "DEVNOTIF"  # DEVNOTif
    DIFF = "DIFF"
    DIFFERENTIAL = "DIFFERENTIAL"
    # DIFFERENTIAL = "DIFFerential"
    DIFFERENTIATOR = "DIFFERENTIATOR"  # DIFFerentiator
    DIREC = "DIREC"  # DIRec
    DISABLED = "DISABLED"  # DISabled
    DISCMODE = "DISCMODE"  # DISCMODe
    DISCRETE = "DISCRETE"  # DISCrete
    DISLAVE = "DISLAVE"  # DISLave
    DISPARITY = "DISPARITY"  # DISParity
    DIVIDE = "DIVIDE"  # DIVide
    DL1 = "DL1"
    DLC = "DLC"
    DLSLAVE = "DLSLAVE"  # DLSLave
    DMSGEND = "DMSGEND"  # DMSGEnd
    DONTCARE = "DONTCARE"  # DONTcare
    DONTINCLUDE = "DONTINCLUDE"  # DONTInclude
    DOTSONLY = "DOTSONLY"  # DOTsonly
    DOUBLE = "DOUBLE"
    DP = "DP"
    DPMAUTOSET = "DPMAUTOSET"  # DPMAutoset
    DPMPRESET = "DPMPRESET"  # DPMPReset
    DPPABORT = "DPPABORT"
    DPPEND = "DPPEND"
    DPPSTART = "DPPSTART"
    DQ0 = "DQ0"
    DRA = "DRA"
    DRB = "DRB"
    DSI = "DSI"
    DSLREQ = "DSLREQ"  # DSLReq
    DSLRES = "DSLRES"  # DSLRes
    DUAL = "DUAL"
    DYNAMIC = "DYNAMIC"
    # DYNAMIC = "DYNAMic"
    EBIT = "EBIT"
    ECATHEADERLENGTH = "ECATHEADERLENGTH"  # ECATHEADERLENGth
    ECC = "ECC"
    ECUDATA = "ECUDATA"  # ECUDATa
    ECUSENSOR = "ECUSENSOR"  # ECUSENSor
    EDB = "EDB"
    EDGE = "EDGE"
    EEP = "EEP"
    EFFICIENCY = "EFFICIENCY"  # EFFiciency
    EIEOS = "EIEOS"
    EIGHT = "EIGHT"  # EIGHt
    EIGHTBIT = "EIGHTBIT"
    EIOS = "EIOS"
    EITHER = "EITHER"
    # EITHER = "EITHer"
    # EITHER = "EITher"
    ELLIPTICAL = "ELLIPTICAL"  # ELLiptical
    END = "END"
    ENDOFPACKET = "ENDOFPACKET"  # ENDOFPACKet
    ENDXFER = "ENDXFER"
    ENEND = "ENEND"
    ENET100 = "ENET100"
    ENET1000 = "ENET1000"
    ENGINEERING = "ENGINEERING"  # ENGineering
    ENSLAVE = "ENSLAVE"  # ENSLave
    ENTASX = "ENTASX"  # ENTasx
    ENTERSWINDOW = "ENTERSWINDOW"  # ENTERSWindow
    ENTRDYA = "ENTRDYA"  # ENTRDya
    ENTRTSTMODE = "ENTRTSTMODE"  # ENTRTSTMode
    ENVELOPE = "ENVELOPE"  # ENVelope
    EOC = "EOC"
    EOF = "EOF"
    EOP = "EOP"
    # EOP = "EOp"
    EOS = "EOS"
    EOT = "EOT"
    EOTPDATA = "EOTPDATA"  # EOTPDATa
    EOW = "EOW"
    EPF = "EPF"
    EQUAL = "EQUAL"  # EQual
    EQUALS = "EQUALS"  # Equals
    ERDY = "ERDY"
    ERR8B10B = "ERR8B10B"
    ERROR = "ERROR"  # ERROr
    # ERROR = "ERRor"
    ERRORS = "ERRORS"  # ERRors
    ERRSERVICEDATA = "ERRSERVICEDATA"  # ERRSERVICEDATa
    ESC = "ESC"
    ESCAPEMODE = "ESCAPEMODE"  # ESCAPEMODe
    ESD = "ESD"
    ESDERR = "ESDERR"
    ESDJAB = "ESDJAB"
    ESDOK = "ESDOK"
    ETHERNET = "ETHERNET"  # ETHernet
    EUSB = "EUSB"
    EVENTS = "EVENTS"
    EVERY = "EVERY"
    EXECUTE = "EXECUTE"
    # EXECUTE = "EXECute"
    EXGETMBSSTATUS = "EXGETMBSSTATUS"  # EXGETMBSSTATus
    EXGETSYSTINFO = "EXGETSYSTINFO"  # EXGETSYSTINFo
    EXITSWINDOW = "EXITSWINDOW"  # EXITSWindow
    EXLOCKBLOCK = "EXLOCKBLOCK"  # EXLOCKBLOCk
    EXPLICITCLOCK = "EXPLICITCLOCK"
    EXRDMBLOCK = "EXRDMBLOCK"  # EXRDMBLOCk
    EXRDSBLOCK = "EXRDSBLOCK"  # EXRDSBLOCk
    EXTDLC = "EXTDLC"
    EXTENDED = "EXTENDED"
    # EXTENDED = "EXTENDed"
    # EXTENDED = "EXTended"
    EXTIME = "EXTIME"  # EXTime
    EXTREGREAD = "EXTREGREAD"  # EXTREGREAd
    EXTREGWRITE = "EXTREGWRITE"  # EXTREGWRIte
    EXWRSBLOCK = "EXWRSBLOCK"  # EXWRSBLOCk
    EYEHISTOGRAM = "EYEHISTOGRAM"  # EYEhistogram
    FACHANNEL = "FACHANNEL"  # FACHANnel
    FADD = "FADD"
    FAIL = "FAIL"
    FALL = "FALL"
    FALLING = "FALLING"
    # FALLING = "FALLing"
    # FALLING = "FALling"
    FALSE = "FALSE"  # FALSe
    # FALSE = "False"
    # FALSE = "false"
    FAST = "FAST"
    # FAST = "FAst"
    FASTER = "FASTER"  # FASTer
    FASTERTHAN = "FASTERTHAN"  # FASTERthan
    FATAL = "FATAL"  # FATal
    FBD1 = "FBD1"
    FBD2 = "FBD2"
    FBD3 = "FBD3"
    FC1063 = "FC1063"
    FC133 = "FC133"
    FC2125 = "FC2125"
    FC266 = "FC266"
    FC4250 = "FC4250"
    FC531 = "FC531"
    FC8500 = "FC8500"
    FCDATA = "FCDATA"  # FCData
    FCDFIRST = "FCDFIRST"  # FCDFirst
    FCDTWO = "FCDTWO"  # FCDTwo
    FCRC = "FCRC"
    FCS = "FCS"
    FCSERROR = "FCSERROR"  # FCSERRor
    # FCSERROR = "FCSError"
    FCT = "FCT"
    FDBITS = "FDBITS"
    FDISO = "FDISO"
    FDNONISO = "FDNONISO"
    FEXRDMBLOCKS = "FEXRDMBLOCKS"  # FEXRDMBLOCks
    FFREQUENCY = "FFREQUENCY"  # FFREQuency
    FFT = "FFT"
    FIBRECHANNEL = "FIBRECHANNEL"  # FIBREchannel
    FIFTEEN = "FIFTEEN"  # FIFTeen
    FIFTY = "FIFTY"
    # FIFTY = "FIFty"
    FILTER = "FILTER"
    FIRST = "FIRST"
    FIVE = "FIVE"  # FIVe
    FIVEHUNDRED = "FIVEHUNDRED"  # FIVEHundred
    FIXED = "FIXED"
    # FIXED = "FIXed"
    FLASHERASE = "FLASHERASE"  # FLASHERASe
    FLASHREAD = "FLASHREAD"
    FLASHWRITE = "FLASHWRITE"  # FLASHWRITe
    FLATNESS = "FLATNESS"
    FLATTOP2 = "FLATTOP2"  # FLATtop2
    FLEXRAY = "FLEXRAY"
    FLSUCCESSDATA = "FLSUCCESSDATA"  # FLSUCCESSDATa
    FLSUCCESSNODATA = "FLSUCCESSNODATA"  # FLSUCCESSNODATa
    FLUNSUCCESSNODATA = "FLUNSUCCESSNODATA"  # FLUNSUCCESSNODATa
    FORCE = "FORCE"  # FORCe
    FORCETRIG = "FORCETRIG"  # FORCetrig
    FORMERROR = "FORMERROR"  # FORMERRor
    FORWARD = "FORWARD"  # FORWard
    # FORWARD = "forward"
    FOUR = "FOUR"
    FOURBIT = "FOURBIT"
    FOURTEENTEN = "FOURTEENTEN"  # FOURTEENten
    FP = "FP"
    FPBINARY = "FPBINARY"  # FPBinary
    FPRD = "FPRD"
    FPRW = "FPRW"
    FPWR = "FPWR"
    FRAME = "FRAME"  # FRAMe
    # FRAME = "FRame"
    FRAMEID = "FRAMEID"
    FRAMELENGTH = "FRAMELENGTH"  # FRAMELENgth
    FRAMEREJ = "FRAMEREJ"
    FRAMES = "FRAMES"  # FRAMes
    FRAMETYPE = "FRAMETYPE"  # FRAMEType
    # FRAMETYPE = "FRAMEtype"
    FRDMBLOCK = "FRDMBLOCK"  # FRDMBLOCk
    FREQUENCY = "FREQUENCY"
    # FREQUENCY = "FREQuency"
    FRMW = "FRMW"
    FTS = "FTS"
    FULL = "FULL"
    FULLSCREEN = "FULLSCREEN"  # FULLScreen
    FULLSPEED = "FULLSPEED"
    FUNCTIONCODE = "FUNCTIONCODE"  # FUNCTIONCODe
    FW1394BS1600B = "FW1394BS1600B"
    FW1394BS400B = "FW1394BS400B"
    FW1394BS800B = "FW1394BS800B"
    GAP = "GAP"
    GAUSSIAN = "GAUSSIAN"  # GAUSsian
    GE = "GE"  # ge
    GET = "GET"
    GETBUSCH = "GETBUSCH"  # GETBusch
    GETCAPS = "GETCAPS"
    GETCONFIG = "GETCONFIG"  # GETCONFig
    GETDEVCH = "GETDEVCH"  # GETDevch
    GETFLASHNP = "GETFLASHNP"
    GETMBSECSYSTEM = "GETMBSECSYSTEM"  # GETMBSECSYSTem
    GETMRDL = "GETMRDL"  # GETMRdl
    GETMWRL = "GETMWRL"  # GETMWrl
    GETNP = "GETNP"
    GETOOB = "GETOOB"
    GETPC = "GETPC"
    GETPRID = "GETPRID"  # GETPrid
    GETREG = "GETREG"  # GETReg
    GETREGPKTALERT = "GETREGPKTALERT"  # GETREGPKTALERt
    # GETREGPKTALERT = "GETRegpktalert"
    GETREGPKTBAD = "GETREGPKTBAD"
    # GETREGPKTBAD = "GETRegpktbad"
    GETREGPKTRECENT = "GETREGPKTRECENT"  # GETREGPKTRECent
    # GETREGPKTRECENT = "GETRegpktrecent"
    GETREGTESTCFG = "GETREGTESTCFG"
    # GETREGTESTCFG = "GETRegtestcfg"
    GETREGVENDOR = "GETREGVENDOR"  # GETREGVENDor
    # GETREGVENDOR = "GETRegvendor"
    GETREGVREVENT = "GETREGVREVENT"  # GETREGVREVENt
    # GETREGVREVENT = "GETRegvrevent"
    GETSLAVE = "GETSLAVE"  # GETSlave
    GETSTATUS = "GETSTATUS"  # GETSTATus
    GETSYSTEMINFO = "GETSYSTEMINFO"  # GETSYSTEMINFo
    GETVWIRE = "GETVWIRE"  # GETVWIRe
    GETXTIME = "GETXTIME"  # GETXTime
    GLOBAL = "GLOBAL"  # GLOBal
    GRATICULE = "GRATICULE"
    GREATERTHAN = "GREATERTHAN"  # GREATERthan
    H = "H"
    HAMMING = "HAMMING"  # HAMMing
    HANDSHAKEPACKET = "HANDSHAKEPACKET"  # HANDSHAKEPacket
    HANNING = "HANNING"  # HANNing
    HASH = "HASH"
    HBARS = "HBARS"  # HBArs
    HDRCAPABILITY = "HDRCAPABILITY"  # HDRCapability
    HDREXIT = "HDREXIT"  # HDRExit
    HDRRESTART = "HDRRESTART"  # HDRRestart
    HEADER = "HEADER"  # HEADer
    HEX = "HEX"
    HEXAGON = "HEXAGON"  # HEXAgon
    HFREJ = "HFREJ"  # HFRej
    HI = "HI"
    HIGH = "HIGH"
    HIGHRES = "HIGHRES"
    HIGHZ = "HIGHZ"
    HILBERT = "HILBERT"  # HILBert
    HISTOGRAM = "HISTOGRAM"  # HISTogram
    HLTA = "HLTA"  # HLTa
    HLTB = "HLTB"
    HORIZONTAL = "HORIZONTAL"  # HORizontal
    HORIZONTALSCALE = "HORIZONTALSCALE"  # HORIZontalscale
    HORZPOS = "HORZPOS"
    HORZSCALE = "HORZSCALE"  # HORZScale
    HOSTADDR = "HOSTADDR"
    HOSTCHIRP = "HOSTCHIRP"  # HOSTChirp
    HOTJOIN = "HOTJOIN"  # HOTJoin
    HPASS = "HPASS"  # HPASs
    HPSTART = "HPSTART"
    HS = "HS"
    HUNDRED = "HUNDRED"  # HUNdred
    HUNDREDBASET1 = "HUNDREDBASET1"
    HUNDREDBASETX = "HUNDREDBASETX"
    I2C = "I2C"
    I2S = "I2S"
    I3C = "I3C"
    IBA2500 = "IBA2500"
    IBA_GEN2 = "IBA_GEN2"
    IBS = "IBS"
    ICMP = "ICMP"
    IDANDDATA = "IDANDDATA"
    IDENTIFIER = "IDENTIFIER"  # IDEntifier
    # IDENTIFIER = "IDentifier"
    IDLE = "IDLE"
    # IDLE = "IDLe"
    IDX = "IDX"
    IEEE = "IEEE"  # ieee
    IN = "IN"
    INCLUDE = "INCLUDE"  # INCLude
    INDEPENDENT = "INDEPENDENT"
    INDEX = "INDEX"  # INDex
    INFINITE = "INFINITE"  # INFInite
    INFORMATION = "INFORMATION"  # INFormation
    INFPERSIST = "INFPERSIST"  # INFPersist
    INIT = "INIT"
    INPUT = "INPUT"
    INPWR = "INPWR"
    INPWRSUM = "INPWRSUM"
    INRANGE = "INRANGE"  # INrange
    # INRANGE = "Inrange"
    INSIDEGREATER = "INSIDEGREATER"  # INSIDEGreater
    INSIDERANGE = "INSIDERANGE"  # INSIDErange
    INVALID = "INVALID"
    # INVALID = "INVALid"
    INVENTORY = "INVENTORY"  # INVentory
    INVERT = "INVERT"  # INVert
    INVERTED = "INVERTED"  # INVERTed
    # INVERTED = "INVErted"
    # INVERTED = "INVerted"
    IO = "IO"
    IPDATA = "IPDATA"  # IPData
    IPHEADER = "IPHEADER"  # IPHEADer
    # IPHEADER = "IPHeader"
    IPV4 = "IPV4"
    IPV6 = "IPV6"
    IRMS = "IRMS"
    IRQ = "IRQ"
    ISOALL = "ISOALL"
    ISOEND = "ISOEND"
    ISOMID = "ISOMID"
    ISOSTART = "ISOSTART"
    ITP = "ITP"
    JPG = "JPG"
    KAISERBESSEL = "KAISERBESSEL"  # KAISerbessel
    KCODE = "KCODE"  # KCODe
    KEYUPDATE = "KEYUPDATE"  # KEYUPDate
    L = "L"
    LABEL = "LABEL"  # LABel
    LABELANDDATA = "LABELANDDATA"
    LATCH = "LATCH"  # LATCh
    LCHANNEL = "LCHANNEL"  # LCHannel
    LCSTART = "LCSTART"
    LEFT = "LEFT"  # LEFt
    LEN = "LEN"
    LENGTH = "LENGTH"  # LENGth
    LESSEQUAL = "LESSEQUAL"  # LESSEQual
    LESSTHAN = "LESSTHAN"  # LESSthan
    LF = "LF"
    LFREJ = "LFREJ"  # LFRej
    LIN = "LIN"
    LINE = "LINE"
    LINEAR = "LINEAR"
    # LINEAR = "LINEAr"
    # LINEAR = "LINear"
    LJ = "LJ"
    LMP = "LMP"
    LOCAL = "LOCAL"
    LOCKAFI = "LOCKAFI"
    LOCKBLOCK = "LOCKBLOCK"  # LOCKBLOCk
    LOCKDSFID = "LOCKDSFID"
    LOG = "LOG"
    LOGIC = "LOGIC"  # LOGIc
    LOGICAL = "LOGICAL"  # LOGical
    LONG = "LONG"
    LONGEXTREGREAD = "LONGEXTREGREAD"  # LONGEXTREGREAd
    LONGEXTREGWRITE = "LONGEXTREGWRITE"  # LONGEXTREGWRIte
    LOW = "LOW"
    LOWSPEED = "LOWSPEED"
    LP = "LP"
    LPASS = "LPASS"  # LPASs
    LPDT = "LPDT"
    LRD = "LRD"
    LRW = "LRW"
    LSB = "LSB"
    LSLAVE = "LSLAVE"  # LSLave
    LTR = "LTR"
    LWR = "LWR"
    MACADDRESS = "MACADDRESS"  # MACADDRess
    MACLENGTH = "MACLENGTH"  # MACLENgth
    MAGNITUDE = "MAGNITUDE"
    MAILBOX = "MAILBOX"
    # MAILBOX = "MAILbox"
    MAILBOXHEADER = "MAILBOXHEADER"  # MAILBOXHEADer
    MANCHESTER = "MANCHESTER"  # MANChester
    MANUAL = "MANUAL"
    # MANUAL = "MANual"
    MASTER = "MASTER"  # MASTer
    MASTERREAD = "MASTERREAD"  # MASTERREAd
    MASTERWRITE = "MASTERWRITE"  # MASTERWRIte
    MATCHROM = "MATCHROM"
    MATH = "MATH"  # MATh
    MAXIMUM = "MAXIMUM"  # MAXimum
    MCTP = "MCTP"
    MDATA = "MDATA"
    MDATASPEED = "MDATASPEED"  # MDATASpeed
    MDIO = "MDIO"
    MEAN = "MEAN"
    MEANHISTOGRAM = "MEANHISTOGRAM"  # MEANhistogram
    MEDIAN = "MEDIAN"  # MEDian
    MEDIUM = "MEDIUM"  # MEDium
    MEMORY = "MEMORY"
    MEMRD32 = "MEMRD32"
    MEMRD64 = "MEMRD64"
    MEMRDWR32 = "MEMRDWR32"
    MEMRDWR64 = "MEMRDWR64"
    MEMWR32 = "MEMWR32"
    MEMWR64 = "MEMWR64"
    MESSAGE = "MESSAGE"
    # MESSAGE = "MESSage"
    MHITS = "MHITS"  # MHITs
    MID = "MID"
    MIL1553B = "MIL1553B"
    MINMAX = "MINMAX"  # MINMax
    MISO = "MISO"  # MISo
    MISODATA = "MISODATA"  # MISOdata
    MIXED = "MIXED"
    # MIXED = "MIXed"
    MIXEDASCII = "MIXEDASCII"
    MIXEDHEX = "MIXEDHEX"
    MLANE = "MLANE"  # MLANe
    MMARGIN = "MMARGIN"  # MMARgin
    MODE = "MODE"
    # MODE = "MODe"
    MODEHISTOGRAM = "MODEHISTOGRAM"  # MODEhistogram
    MOREEQUA = "MOREEQUA"  # MOREEQua
    MOREEQUAL = "MOREEQUAL"  # MOREEQual
    MORETHAN = "MORETHAN"  # MOREthan
    MOSI = "MOSI"  # MOSi
    MOSIDATA = "MOSIDATA"  # MOSIdata
    MOVEABLE = "MOVEABLE"
    MPAYLOAD = "MPAYLOAD"  # MPAYload
    MSB = "MSB"
    MSGWITHDATA = "MSGWITHDATA"  # MSGWITHDATa
    MULTIPLY = "MULTIPLY"  # MULTiply
    NACK = "NACK"
    NAK = "NAK"
    NAND = "NAND"  # NANd
    NATIVE = "NATIVE"  # NATive
    NEGATIVE = "NEGATIVE"  # NEGAtive
    # NEGATIVE = "NEGative"
    NETMN = "NETMN"
    NETWORKVARIABLE = "NETWORKVARIABLE"  # NETWORKVARiable
    NETWORKVARIABLES = "NETWORKVARIABLES"  # NETWORKVARiables
    NEXT = "NEXT"  # NEXt
    NFC14443A = "NFC14443A"
    NFC14443B = "NFC14443B"
    NFC15693 = "NFC15693"
    NFCFELICA = "NFCFELICA"  # NFCFELica
    NIBBLE = "NIBBLE"  # NIBBLe
    NINE = "NINE"  # NINe
    NO = "NO"
    NOCARE = "NOCARE"
    NOISEREJ = "NOISEREJ"  # NOISErej
    NOMINAL = "NOMINAL"  # NOMinal
    NONFATAL = "NONFATAL"  # NONFATal
    NONTRANSITION = "NONTRANSITION"  # NONTRANsition
    NOP = "NOP"
    NOPARITY = "NOPARITY"  # NOPARity
    NOR = "NOR"
    NORESPONSE = "NORESPONSE"  # NORESPonse
    NORMAL = "NORMAL"  # NORMal
    # NORMAL = "NORmal"
    NOSTATION = "NOSTATION"  # NOSTATion
    NOTE = "NOTE"
    NOTEQUAL = "NOTEQUAL"  # NOTEQual
    NOTEQUALS = "NOTEQUALS"  # NOTEQuals
    NRDY = "NRDY"
    NTIMES = "NTIMES"
    NULL = "NULL"
    # NULL = "NULl"
    NULLFRDYNAMIC = "NULLFRDYNAMIC"  # NULLFRDynamic
    NULLFRSTATIC = "NULLFRSTATIC"  # NULLFRStatic
    NUMACQS = "NUMACQS"  # NUMACQs
    NUMERICORDER = "NUMERICORDER"  # NUMERICORDer
    NVDATA = "NVDATA"  # NVDATa
    NVHEADER = "NVHEADER"  # NVHEADer
    NVLEN = "NVLEN"
    NWVARIABLEDATA = "NWVARIABLEDATA"  # NWVariabledata
    NYET = "NYET"
    OC1 = "OC1"
    OC12 = "OC12"
    OC3 = "OC3"
    OC48 = "OC48"
    OCCURS = "OCCURS"
    OFF = "OFF"
    OFFSET = "OFFSET"  # OFFSet
    ON = "ON"
    ONCE = "ONCE"
    ONE = "ONE"
    ONEPAIRI = "ONEPAIRI"
    ONEPAIRV = "ONEPAIRV"
    ONEPAIRVI = "ONEPAIRVI"
    ONFAIL = "ONFAIL"
    OOBCHANNEL = "OOBCHANNEL"  # OOBCHANnel
    OOBSMBUS = "OOBSMBUS"
    OPCODEERROR = "OPCODEERROR"  # OPCODEERRor
    OPPOSITEAS = "OPPOSITEAS"  # OPPositeas
    OPTIONAL = "OPTIONAL"  # OPTional
    OPTIONALPARAM = "OPTIONALPARAM"  # OPTIONALPARam
    OR = "OR"
    ORDSET = "ORDSET"
    OSET = "OSET"
    OUT = "OUT"
    OUTPUT = "OUTPUT"
    OUTPWR = "OUTPWR"
    OUTPWRSUM = "OUTPWRSUM"
    OUTRANGE = "OUTRANGE"  # OUTrange
    OUTSIDE = "OUTSIDE"  # OUTside
    OUTSIDEGREATER = "OUTSIDEGREATER"  # OUTSIDEGreater
    OUTSIDERANGE = "OUTSIDERANGE"  # OUTSIDErange
    OVERDRIVE = "OVERDRIVE"  # OVErdrive
    OVERLAY = "OVERLAY"  # OVErlay
    OVERLOAD = "OVERLOAD"  # OVERLoad
    P1W2V1I1 = "P1W2V1I1"
    P1W3V2I2 = "P1W3V2I2"
    P3W3 = "P3W3"
    P3W3V2I2 = "P3W3V2I2"
    P3W3V3I3 = "P3W3V3I3"
    PACKET = "PACKET"
    # PACKET = "PACKet"
    PACKETOFFDATA = "PACKETOFFDATA"  # packetOffData
    PACKETS = "PACKETS"  # PACKets
    PARALLEL = "PARALLEL"  # PARallel
    PARAMETRIC = "PARAMETRIC"  # PARAmetric
    PARITY = "PARITY"  # PARity
    PARITYERROR = "PARITYERROR"  # PARItyerror
    PAUSE = "PAUSE"
    PAYLOAD = "PAYLOAD"  # PAYLoad
    # PAYLOAD = "PAYload"
    PCIE = "PCIE"
    PCIEXPRESS = "PCIEXPRESS"  # PCIExpress
    PCIE_GEN1 = "PCIE_GEN1"
    PCIE_GEN2 = "PCIE_GEN2"
    PCIE_GEN3 = "PCIE_GEN3"
    PCRC = "PCRC"
    PDU = "PDU"
    PEAKDETECT = "PEAKDETECT"  # PEAKdetect
    PEC = "PEC"
    PERCENT = "PERCENT"  # PERCent
    PERICHANNEL = "PERICHANNEL"  # PERICHANnel
    PERIOD = "PERIOD"
    PERSOURCE = "PERSOURCE"  # PERSource
    PHASE = "PHASE"
    PHASEONE = "PHASEONE"
    PHASETHREE = "PHASETHREE"
    PHASETWO = "PHASETWO"
    PHYSICALADDRESS = "PHYSICALADDRESS"  # PHYSICALADDRess
    PID = "PID"
    PING = "PING"
    PINGRSP = "PINGRSP"
    PIXELNUMBER = "PIXELNUMBER"  # PIXELNUMBer
    PIXELVALUE = "PIXELVALUE"  # PIXELVALue
    PIXMAP = "PIXMAP"  # PIXmap
    PLL = "PLL"
    PNG = "PNG"
    POLLINGLONG = "POLLINGLONG"
    POLLINGNORMAL = "POLLINGNORMAL"  # POLLINGNORMal
    PORTCAP = "PORTCAP"
    PORTCFG = "PORTCFG"
    PORTCONFIGURATION = "PORTCONFIGURATION"  # PORTConfiguration
    PORTRESET = "PORTRESET"  # PORTReset
    PORTRSP = "PORTRSP"
    POSITION = "POSITION"  # POSition
    POSITIVE = "POSITIVE"  # POSITIVe
    # POSITIVE = "POSitive"
    POST = "POST"
    PREAMBLE = "PREAMBLE"  # PREamble
    PRECISE = "PRECISE"
    PRECTM = "PRECTM"
    PREFIX = "PREFIX"
    PRESENCE = "PRESENCE"  # PREsence
    PREV = "PREV"  # PREv
    PRIORITY = "PRIORITY"  # PRIority
    PROPRIETARY = "PROPRIETARY"  # PROPrietary
    PROTOCOL = "PROTOCOL"  # PROTocol
    PSLREQ = "PSLREQ"  # PSLReq
    PSLRES = "PSLRES"  # PSLRes
    PTYPE = "PTYPE"  # PTYPe
    PUBHEADER = "PUBHEADER"  # PUBHEADer
    PULSEWIDTH = "PULSEWIDTH"  # PULSEWIDTh
    # PULSEWIDTH = "PULSEWidth"
    PUPI = "PUPI"  # PUPi
    PUTFLASHC = "PUTFLASHC"
    PUTIORDSHORT = "PUTIORDSHORT"  # PUTIORDSHORt
    PUTIOWRSHORT = "PUTIOWRSHORT"  # PUTIOWRSHORt
    PUTMEMRD32SHORT = "PUTMEMRD32SHORT"  # PUTMEMRD32SHORt
    PUTMEMWR32SHORT = "PUTMEMWR32SHORT"  # PUTMEMWR32SHORt
    PUTNP = "PUTNP"
    PUTOOB = "PUTOOB"
    PUTPC = "PUTPC"
    PUTVWIRE = "PUTVWIRE"  # PUTVWIRe
    Q = "Q"
    QTAG = "QTAG"
    RANDOM = "RANDOM"
    # RANDOM = "RANDom"
    RAP = "RAP"
    RAPDATA = "RAPDATA"  # RAPDATa
    RATE100K = "RATE100K"
    RATE10K = "RATE10K"
    RATE10M = "RATE10M"
    RATE115K = "RATE115K"
    RATE11M = "RATE11M"
    RATE125K = "RATE125K"
    RATE12M = "RATE12M"
    RATE13M = "RATE13M"
    RATE14M = "RATE14M"
    RATE153K = "RATE153K"
    RATE15M = "RATE15M"
    RATE16M = "RATE16M"
    RATE189K = "RATE189K"
    RATE19K = "RATE19K"
    RATE1K = "RATE1K"
    RATE1M = "RATE1M"
    RATE20K = "RATE20K"
    RATE250K = "RATE250K"
    RATE25K = "RATE25K"
    RATE2K = "RATE2K"
    RATE2M = "RATE2M"
    RATE300 = "RATE300"
    RATE31K = "RATE31K"
    RATE33K = "RATE33K"
    RATE38K = "RATE38K"
    RATE3M = "RATE3M"
    RATE400K = "RATE400K"
    RATE4K = "RATE4K"
    RATE4M = "RATE4M"
    RATE500K = "RATE500K"
    RATE50K = "RATE50K"
    RATE5M = "RATE5M"
    RATE62K = "RATE62K"
    RATE68K = "RATE68K"
    RATE6M = "RATE6M"
    RATE7M = "RATE7M"
    RATE800K = "RATE800K"
    RATE83K = "RATE83K"
    RATE8M = "RATE8M"
    RATE921K = "RATE921K"
    RATE92K = "RATE92K"
    RATE9K = "RATE9K"
    RATE9M = "RATE9M"
    RC = "RC"
    RCHANNEL = "RCHANNEL"  # RCHannel
    RDATA = "RDATA"  # RDATa
    RDMBLOCK = "RDMBLOCK"  # RDMBLOCk
    RDSBLOCK = "RDSBLOCK"  # RDSBLOCk
    READ = "READ"
    READBUFFER = "READBUFFER"  # READBUFFer
    READROM = "READROM"
    READY = "READY"  # READy
    RECORD = "RECORD"
    RECORDLENGTH = "RECORDLENGTH"  # RECORDLength
    RECTANGLE = "RECTANGLE"
    # RECTANGLE = "RECTangle"
    RECTANGULAR = "RECTANGULAR"  # RECTangular
    REF = "REF"
    REG0WRITE = "REG0WRITE"  # REG0WRIte
    REGADDRTESTCONFG = "REGADDRTESTCONFG"  # REGAddrtestconfg
    REGADDRVENDOR = "REGADDRVENDOR"  # REGAddrvendor
    REGDATATESTCONFG = "REGDATATESTCONFG"  # REGDatatestconfg
    REGDATAVENDOR = "REGDATAVENDOR"  # REGDatavendor
    REGISTERADDRESS = "REGISTERADDRESS"  # REGISTERADDRess
    REGREAD = "REGREAD"  # REGREAd
    REGWRITE = "REGWRITE"  # REGWRIte
    REJ = "REJ"
    REJECT = "REJECT"  # REJect
    REJECTS = "REJECTS"  # REJects
    REMOTE = "REMOTE"  # REMote
    REPEATERHOST = "REPEATERHOST"  # REPEATERHOSt
    REPEATERPERIPHERAL = "REPEATERPERIPHERAL"
    REPEATING = "REPEATING"  # REPeating
    REPEATSTART = "REPEATSTART"  # REPEATSTARt
    # REPEATSTART = "REPEATStart"
    # REPEATSTART = "REPEATstart"
    REPWR = "REPWR"
    REPWRSUM = "REPWRSUM"
    REQA = "REQA"  # REQa
    REQB = "REQB"
    REQDISCONNECT = "REQDISCONNECT"  # REQDISConnect
    REQSETINIT = "REQSETINIT"
    RESERVED = "RESERVED"  # RESERVed
    # RESERVED = "RESERved"
    # RESERVED = "REServed"
    RESET = "RESET"
    # RESET = "RESet"
    RESETTRIGGER = "RESETTRIGGER"  # RESETTRIGger
    RESOLUTION = "RESOLUTION"  # RESOlution
    RESPCODE = "RESPCODE"  # RESPCODe
    RESPONSE = "RESPONSE"
    # RESPONSE = "RESPonse"
    RESPONSECODE = "RESPONSECODE"  # RESPONSECODe
    RESPONSEHEADER = "RESPONSEHEADER"  # RESPONSEHEADer
    RESPONSENOHEADER = "RESPONSENOHEADER"  # RESPONSENOHEADer
    RESUME = "RESUME"
    REVERSE = "REVERSE"  # reverse
    RFU = "RFU"
    RFVSTIME = "RFVSTIME"  # RFvsTime
    RI = "RI"
    RIBINARY = "RIBINARY"  # RIBinary
    RIGHT = "RIGHT"  # RIGht
    RIO125 = "RIO125"
    RIO250 = "RIO250"
    RIO3125 = "RIO3125"
    RISE = "RISE"
    # RISE = "RISe"
    RISING = "RISING"
    # RISING = "RISing"
    RJ = "RJ"
    RLSREQ = "RLSREQ"  # RLSReq
    RLSRES = "RLSRES"  # RLSRes
    RMS = "RMS"
    RNR = "RNR"
    ROTATION = "ROTATION"
    RP = "RP"
    RPBINARY = "RPBINARY"  # RPBinary
    RR = "RR"
    RRC = "RRC"
    RS232C = "RS232C"
    RSTACT = "RSTACT"
    RSTDYA = "RSTDYA"  # RSTDya
    RSTGRPA = "RSTGRPA"  # RSTGRPa
    RSTTOREADY = "RSTTOREADY"  # RSTTOREADy
    RUNSTOP = "RUNSTOP"  # RUNSTop
    RUNT = "RUNT"
    # RUNT = "RUNt"
    RX = "RX"
    RXDATA = "RXDATA"  # RXData
    SAK = "SAK"
    SAME = "SAME"
    SAMEAS = "SAMEAS"  # SAMEas
    SAMPLE = "SAMPLE"  # SAMple
    SAS12_NOSSC = "SAS12_NOSSC"
    SAS12_SSC = "SAS12_SSC"
    SAS15_NOSSC = "SAS15_NOSSC"
    SAS15_SSC = "SAS15_SSC"
    SAS3_NOSSC = "SAS3_NOSSC"
    SAS3_SSC = "SAS3_SSC"
    SAS6_NOSSC = "SAS6_NOSSC"
    SAS6_SSC = "SAS6_SSC"
    SATA_GEN1 = "SATA_GEN1"
    SATA_GEN2 = "SATA_GEN2"
    SATA_GEN3 = "SATA_GEN3"
    SBC = "SBC"
    SCIENTIFIC = "SCIENTIFIC"  # SCIentific
    SCRAMBLING = "SCRAMBLING"  # SCRambling
    SCREEN = "SCREEN"
    # SCREEN = "SCReen"
    SDATA = "SDATA"  # SDATa
    SDIDATA = "SDIDATA"
    SDIDATASSM = "SDIDATASSM"
    SDP = "SDP"
    SDRBROADCAST = "SDRBROADCAST"  # SDRBroadcast
    SDRDIRECT = "SDRDIRECT"  # SDRDirect
    SDS = "SDS"
    SDT = "SDT"
    SEARCH1 = "SEARCH1"
    SEARCHROM = "SEARCHROM"
    SEARCHTOTRIGGER = "SEARCHTOTRIGGER"  # SEARCHtotrigger
    SEC = "SEC"
    SECURECRYPTO = "SECURECRYPTO"  # SECURECRYPto
    SEGMENTS = "SEGMENTS"  # SEGments
    SELECT14443A = "SELECT14443A"
    SELECT15693SET = "SELECT15693SET"
    SENSORADDRESS = "SENSORADDRESS"  # SENSORADDRess
    SENSORECU = "SENSORECU"
    SENSORSTATUS = "SENSORSTATUS"  # SENSORSTATus
    SENT = "SENT"
    SEQUENCE = "SEQUENCE"  # SEQuence
    SEQUENTIAL = "SEQUENTIAL"
    SERVICEDATA = "SERVICEDATA"  # SERVICEDATa
    SERVICEMODE = "SERVICEMODE"  # SERVICEMODe
    SET = "SET"
    SETAASA = "SETAASA"  # SETaasa
    SETBRT = "SETBRT"  # SETBrt
    SETBUSCON = "SETBUSCON"
    SETCONFIG = "SETCONFIG"  # SETCONFig
    SETDECAY = "SETDECAY"  # SETDecay
    SETDYA = "SETDYA"  # SETDya
    SETEXT = "SETEXT"  # SEText
    SETFAST = "SETFAST"  # SETFast
    SETGRPA = "SETGRPA"  # SETGRPa
    SETHOLD = "SETHOLD"  # SETHold
    SETLEVEL = "SETLEVEL"  # SETLevel
    SETLF = "SETLF"
    SETMRDL = "SETMRDL"  # SETMrdl
    SETMWRL = "SETMWRL"  # SETMwrl
    SETNDYA = "SETNDYA"  # SETNdya
    SETPS = "SETPS"
    # SETPS = "SETPs"
    SETREGADDR = "SETREGADDR"
    # SETREGADDR = "SETRegaddr"
    SETREGADDRTESTCONFG = "SETREGADDRTESTCONFG"  # SETREGADDRTESTCONFg
    SETREGADDRVENDOR = "SETREGADDRVENDOR"  # SETREGADDRVENDor
    SETREGDATA = "SETREGDATA"  # SETREGDATa
    # SETREGDATA = "SETRegdata"
    SETREGDATATESTCONFG = "SETREGDATATESTCONFG"  # SETREGDATATESTCONFg
    SETREGDATAVENDOR = "SETREGDATAVENDOR"  # SETREGDATAVENDor
    SETSLOW = "SETSLOW"  # SETSlow
    SETTO50 = "SETTO50"
    SETUP = "SETUP"
    SETVIDDECAY = "SETVIDDECAY"  # SETVIDDECay
    SETVIDFAST = "SETVIDFAST"
    SETVIDSLOW = "SETVIDSLOW"
    SETWP = "SETWP"
    # SETWP = "SETWp"
    SEVEN = "SEVEN"  # SEVEn
    SFD = "SFD"
    SFPBINARY = "SFPBINARY"  # SFPbinary
    SHORT = "SHORT"  # SHORt
    SHP = "SHP"
    SHUTDOWN = "SHUTDOWN"  # SHUTdown
    SIGNAL = "SIGNAL"
    SINC = "SINC"
    SINGLE = "SINGLE"
    # SINGLE = "SINGLe"
    # SINGLE = "SINGle"
    SINGLESEQ = "SINGLESEQ"  # SINGleseq
    SINX = "SINX"
    SIX = "SIX"
    SIXBIT = "SIXBIT"
    SIXTEENEIGHT = "SIXTEENEIGHT"  # SIXTEENeight
    SIXTYFOURBIT = "SIXTYFOURBIT"
    SKIPROM = "SKIPROM"
    SKP = "SKP"
    SLAVE = "SLAVE"  # SLAVe
    SLAVEADDRESS = "SLAVEADDRESS"  # SLAVEADDRess
    SLC = "SLC"
    SLEEP = "SLEEP"
    # SLEEP = "SLEep"
    SLOTMARKER = "SLOTMARKER"
    SLOW = "SLOW"
    SLOWER = "SLOWER"  # SLOWer
    SLOWERTHAN = "SLOWERTHAN"  # SLOWERthan
    SNAP = "SNAP"  # SNAp
    SNRM = "SNRM"
    SNRME = "SNRME"
    SOC = "SOC"
    SOF = "SOF"
    SOS = "SOS"
    SOSD = "SOSD"
    SOT = "SOT"
    SOW = "SOW"
    SPACE = "SPACE"  # SPace
    SPAYLOAD = "SPAYLOAD"  # SPAYload
    SPECIALPACKET = "SPECIALPACKET"  # SPECIALPacket
    SPECTRAL = "SPECTRAL"
    SPECTRALBUJ = "SPECTRALBUJ"
    SPI = "SPI"
    SPLIT = "SPLIT"
    # SPLIT = "SPLit"
    SPMI = "SPMI"
    SRIBINARY = "SRIBINARY"  # SRIbinary
    SRPBINARY = "SRPBINARY"  # SRPbinary
    SS = "SS"
    SSC = "SSC"
    SSD = "SSD"
    SSPLIT = "SSPLIT"
    STACKED = "STACKED"  # STAcked
    STALL = "STALL"
    # STALL = "STALl"
    STANDARD = "STANDARD"  # STAndard
    # STANDARD = "STandard"
    START = "START"
    # START = "STARt"
    # START = "Start"
    STARTBIT = "STARTBIT"
    STARTCONDITION = "STARTCONDITION"  # STARTCONDition
    STARTOFFRAME = "STARTOFFRAME"  # STARTofframe
    STARTPACKET = "STARTPACKET"  # STARTPACKet
    STARTUP = "STARTUP"  # STARTup
    STARTUPNOSYNC = "STARTUPNOSYNC"  # STARTupnosync
    STATIC = "STATIC"
    # STATIC = "STATic"
    STATIONADDR = "STATIONADDR"  # STATIONADDr
    STATUS = "STATUS"  # STATus
    STAYQUIET = "STAYQUIET"  # STAYQUIet
    STAYSHIGH = "STAYSHIGH"  # STAYSHigh
    STAYSLOW = "STAYSLOW"  # STAYSLow
    STEPRESPONSE = "STEPRESPONSE"
    STOP = "STOP"
    # STOP = "STop"
    # STOP = "Stop"
    SUB = "SUB"
    SUBTRACT = "SUBTRACT"  # SUBtract
    SUCCESSDATA = "SUCCESSDATA"  # SUCCESSDATa
    SUCCESSNODATA = "SUCCESSNODATA"  # SUCCESSNODATa
    SUPERVISORY = "SUPERVISORY"  # SUPervisory
    SUSPEND = "SUSPEND"
    SVID = "SVID"
    SWAP = "SWAP"
    SYMB = "SYMB"
    SYMBOL = "SYMBOL"  # SYMBol
    # SYMBOL = "Symbol"
    SYMBOLS = "SYMBOLS"  # SYMbols
    SYNC = "SYNC"
    SYNCBITS = "SYNCBITS"
    SYNCFIELD = "SYNCFIELD"  # SYNCfield
    SYNCFRAME = "SYNCFRAME"  # SYNCFrame
    SYSTEM = "SYSTEM"
    TA = "TA"
    TB = "TB"
    TBIT = "TBIT"
    TCI = "TCI"
    TCP = "TCP"
    TCPHEADER = "TCPHEADER"  # TCPHeader
    TDATA = "TDATA"  # TDATa
    TDM = "TDM"
    TDMCHANNEL = "TDMCHANNEL"  # TDMChannel
    TENBASET = "TENBASET"
    TENNINETY = "TENNINETY"  # TENNinety
    TEST = "TEST"
    TESTMODE = "TESTMODE"  # TESTMODe
    # TESTMODE = "TESTmode"
    THITS = "THITS"  # THITs
    THREE = "THREE"
    # THREE = "THRee"
    TIME = "TIME"  # TIMe
    TIMECODE = "TIMECODE"  # TIMECODe
    TIMEOUT = "TIMEOUT"  # TIMEOut
    TOGGLE = "TOGGLE"
    TOKENPACKET = "TOKENPACKET"  # TOKENPacket
    TOLERANCES = "TOLERANCES"  # TOLerances
    TOOTHGAP = "TOOTHGAP"
    TOTALEFFICIENCY = "TOTALEFFICIENCY"  # TOTALEFFiciency
    TOUCHSCREEN = "TOUCHSCREEN"  # TOUCHSCReen
    TP = "TP"
    TRACK = "TRACK"
    TRAILER = "TRAILER"  # TRAiler
    TRANSFERBUSOWNERSHIP = "TRANSFERBUSOWNERSHIP"  # TRANSferbusownership
    TRANSITION = "TRANSITION"  # TRANSition
    # TRANSITION = "TRANsition"
    TRAPEZOID = "TRAPEZOID"  # TRAPezoid
    TRIANGLE = "TRIANGLE"  # TRIAngle
    TRIGGERTOSEARCH = "TRIGGERTOSEARCH"  # TRIGgertosearch
    TRIGMODE = "TRIGMODE"  # TRIGMode
    TRIGSLOPE = "TRIGSLOPE"  # TRIGSlope
    TRPWR = "TRPWR"
    TRPWRSUM = "TRPWRSUM"
    TRR = "TRR"
    TRUE = "TRUE"  # TRUe
    # TRUE = "True"
    # TRUE = "true"
    TSEQ = "TSEQ"
    TWELVETWELVE = "TWELVETWELVE"  # TWELVEtwelve
    TWENTYBIT = "TWENTYBIT"
    TWENTYEIGHTY = "TWENTYEIGHTY"  # TWENtyeighty
    TWENTYFIVE = "TWENTYFIVE"  # TWENtyfive
    TWO = "TWO"
    TWOBIT = "TWOBIT"
    TWOFIFTY = "TWOFIFTY"  # TWOFifty
    TWOTHOUSAND = "TWOTHOUSAND"  # TWOThousand
    TX = "TX"
    TXDATA = "TXDATA"  # TXData
    TXRX = "TXRX"
    TYPE = "TYPE"  # TYPe
    U2IT = "U2IT"
    UACK = "UACK"
    UDIDDATA = "UDIDDATA"  # UDIDDATa
    UDP = "UDP"
    UDPIP = "UDPIP"
    UDPIPHEADER = "UDPIPHEADER"  # UDPIPHEADer
    UI = "UI"
    UID = "UID"
    ULPS = "ULPS"
    UNEQUAL = "UNEQUAL"  # UNEQual
    # UNEQUAL = "UNEqual"
    UNIQUE = "UNIQUE"  # UNIQue
    UNLOCKED = "UNLOCKED"  # UNLocked
    UNNUMBERED = "UNNUMBERED"  # UNNumbered
    UNSUCCESSNODATA = "UNSUCCESSNODATA"  # UNSUCCESSNODATa
    UP = "UP"
    USB = "USB"
    USB3 = "USB3"
    USB31G1 = "USB31G1"
    USB32G1 = "USB32G1"
    USB32G2 = "USB32G2"
    USB3O = "USB3O"
    USBTMC = "USBTMC"  # USBTmc
    USER = "USER"
    V1X = "V1X"
    V2X = "V2X"
    VARPERSIST = "VARPERSIST"  # VARpersist
    VBARS = "VBARS"  # VBArs
    VCID = "VCID"
    VDEVTEST = "VDEVTEST"
    VECTOR = "VECTOR"  # VECtor
    VECTORS = "VECTORS"  # VECtors
    VERTICAL = "VERTICAL"  # VERTical
    VERTPOS = "VERTPOS"
    VERTSCALE = "VERTSCALE"
    VISIBILITY = "VISIBILITY"  # VISIBility
    VRMS = "VRMS"
    VWCHANNEL = "VWCHANNEL"  # VWCHANnel
    WAIT = "WAIT"
    WAKEUP = "WAKEUP"  # WAKEup
    # WAKEUP = "WAKeup"
    WAVEFORM = "WAVEFORM"
    # WAVEFORM = "WAVEform"
    WAVEVIEW1 = "WAVEVIEW1"
    WIDTH = "WIDTH"  # WIDth
    WINDOW = "WINDOW"  # WINdow
    WITHIN = "WITHIN"  # WIThin
    WKC = "WKC"
    WORD = "WORD"
    # WORD = "Word"
    WRITE = "WRITE"
    # WRITE = "WRITe"
    WRITEAFI = "WRITEAFI"
    WRITEDSFID = "WRITEDSFID"
    WRMBLOCK = "WRMBLOCK"  # WRMBLOCk
    WRSBLOCK = "WRSBLOCK"  # WRSBLOCk
    WUPA = "WUPA"  # WUPa
    WUPB = "WUPB"
    WUPREQ = "WUPREQ"  # WUPReq
    WUPRES = "WUPRES"  # WUPRes
    X = "X"
    XAUI = "XAUI"
    XAUI_GEN2 = "XAUI_GEN2"
    XFF = "XFF"
    XID = "XID"
    XLDATA = "XLDATA"  # xldata
    XLFORMERROR = "XLFORMERROR"  # xlFormError
    XN = "XN"
    XYZY = "XYZY"
    XZYZ = "XZYZ"
    YES = "YES"
    YN = "YN"
    YXZX = "YXZX"
    ZERO = "ZERO"  # ZERo
    ZN = "ZN"
    ZOOM = "ZOOM"


#  pylint: disable=too-many-instance-attributes,too-many-public-methods
class DPO7AXCommands:
    """The DPO7AX commands.

    This provides access to all the commands for the DPO7AX device. See the documentation of each
    property for more usage information.

    Properties:
        - ``.acquire``: The ``ACQuire`` command.
        - ``.actonevent``: The ``ACTONEVent`` command tree.
        - ``.afg``: The ``AFG`` command tree.
        - ``.alias``: The ``ALIas`` command.
        - ``.allev``: The ``ALLEv`` command.
        - ``.application``: The ``APPLication`` command tree.
        - ``.autosavepitimeout``: The ``AUTOSAVEPITIMEOUT`` command.
        - ``.autosaveuitimeout``: The ``AUTOSAVEUITIMEOUT`` command.
        - ``.autoset``: The ``AUTOSet`` command.
        - ``.auxin``: The ``AUXIn`` command tree.
        - ``.auxout``: The ``AUXout`` command tree.
        - ``.bus``: The ``BUS`` command tree.
        - ``.bustable``: The ``BUSTABle`` command tree.
        - ``.busy``: The ``BUSY`` command.
        - ``.cal``: The ``*CAL`` command.
        - ``.calibrate``: The ``CALibrate`` command.
        - ``.callouts``: The ``CALLOUTS`` command tree.
        - ``.ch``: The ``CH<x>`` command.
        - ``.clear``: The ``CLEAR`` command.
        - ``.cls``: The ``*CLS`` command.
        - ``.configuration``: The ``CONFIGuration`` command tree.
        - ``.connected``: The ``CONNected`` command tree.
        - ``.curvestream``: The ``CURVEStream`` command.
        - ``.customtable``: The ``CUSTOMTABle`` command tree.
        - ``.data``: The ``DATa`` command.
        - ``.date``: The ``DATE`` command.
        - ``.ddt``: The ``*DDT`` command.
        - ``.dese``: The ``DESE`` command.
        - ``.diag``: The ``DIAg`` command tree.
        - ``.diggrp``: The ``DIGGRP<x>`` command tree.
        - ``.display``: The ``DISplay`` command.
        - ``.ese``: The ``*ESE`` command.
        - ``.esr``: The ``*ESR`` command.
        - ``.ethernet``: The ``ETHERnet`` command tree.
        - ``.event``: The ``EVENT`` command.
        - ``.evmsg``: The ``EVMsg`` command.
        - ``.evqty``: The ``EVQty`` command.
        - ``.eyemask``: The ``EYEMASK`` command tree.
        - ``.factory``: The ``FACtory`` command.
        - ``.filesystem``: The ``FILESystem`` command.
        - ``.fpanel``: The ``FPAnel`` command tree.
        - ``.header``: The ``HEADer`` command.
        - ``.histogram``: The ``HISTogram`` command tree.
        - ``.horizontal``: The ``HORizontal`` command.
        - ``.hostprocessor``: The ``HOSTProcessor`` command.
        - ``.hsinterface``: The ``HSInterface`` command tree.
        - ``.id``: The ``ID`` command.
        - ``.idn``: The ``*IDN`` command.
        - ``.license``: The ``LICense`` command.
        - ``.lock``: The ``LOCk`` command.
        - ``.lrn``: The ``*LRN`` command.
        - ``.mainwindow``: The ``MAINWindow`` command tree.
        - ``.mask``: The ``MASK`` command tree.
        - ``.math``: The ``MATH`` command tree.
        - ``.matharbflt``: The ``MATHArbflt<x>`` command tree.
        - ``.meastable``: The ``MEASTABle`` command tree.
        - ``.measurement``: The ``MEASUrement`` command.
        - ``.newpass``: The ``NEWpass`` command.
        - ``.opc``: The ``*OPC`` command.
        - ``.opt``: The ``*OPT`` command.
        - ``.password``: The ``PASSWord`` command.
        - ``.pause``: The ``PAUSe`` command.
        - ``.peakstable``: The ``PEAKSTABle`` command tree.
        - ``.pilogger``: The ``PILOGger`` command tree.
        - ``.plot``: The ``PLOT`` command tree.
        - ``.psc``: The ``*PSC`` command.
        - ``.pud``: The ``*PUD`` command.
        - ``.recall``: The ``RECAll`` command tree.
        - ``.ref``: The ``REF`` command tree.
        - ``.refx``: The ``REF<x>`` command tree.
        - ``.rem``: The ``REM`` command.
        - ``.rosc``: The ``ROSc`` command tree.
        - ``.rst``: The ``*RST`` command.
        - ``.save``: The ``SAVe`` command tree.
        - ``.saveon``: The ``SAVEON`` command tree.
        - ``.saveonevent``: The ``SAVEONEVent`` command tree.
        - ``.search``: The ``SEARCH`` command tree.
        - ``.searchtable``: The ``SEARCHTABle`` command tree.
        - ``.security``: The ``SECurity`` command tree.
        - ``.select``: The ``SELect`` command tree.
        - ``.set``: The ``SET`` command.
        - ``.socketserver``: The ``SOCKETServer`` command tree.
        - ``.sre``: The ``*SRE`` command.
        - ``.stb``: The ``*STB`` command.
        - ``.sv``: The ``SV`` command tree.
        - ``.teksecure``: The ``TEKSecure`` command.
        - ``.time``: The ``TIMe`` command.
        - ``.totaluptime``: The ``TOTaluptime`` command.
        - ``.touchscreen``: The ``TOUCHSCReen`` command tree.
        - ``.trg``: The ``*TRG`` command.
        - ``.trigger``: The ``TRIGger`` command.
        - ``.tst``: The ``*TST`` command.
        - ``.undo``: The ``UNDO`` command.
        - ``.unlock``: The ``UNLock`` command.
        - ``.usbdevice``: The ``USBDevice`` command tree.
        - ``.verbose``: The ``VERBose`` command.
        - ``.vertical``: The ``VERTical`` command tree.
        - ``.visual``: The ``VISual`` command tree.
        - ``.vxi``: The ``VXI`` command tree.
        - ``.wai``: The ``*WAI`` command.
        - ``.wavfrm``: The ``WAVFrm`` command.
        - ``.wfmoutpre``: The ``WFMOutpre`` command.
    """

    # pylint: disable=too-many-statements
    def __init__(self, device: Optional[PIControl] = None) -> None:  # noqa: PLR0915
        self._acquire = Acquire(device)
        self._actonevent = Actonevent(device)
        self._afg = Afg(device)
        self._alias = Alias(device)
        self._allev = Allev(device)
        self._application = Application(device)
        self._autosavepitimeout = Autosavepitimeout(device)
        self._autosaveuitimeout = Autosaveuitimeout(device)
        self._autoset = Autoset(device)
        self._auxin = Auxin(device)
        self._auxout = Auxout(device)
        self._bus = Bus(device)
        self._bustable = Bustable(device)
        self._busy = Busy(device)
        self._cal = Cal(device)
        self._calibrate = Calibrate(device)
        self._callouts = Callouts(device)
        self._ch: Dict[int, Channel] = DefaultDictPassKeyToFactory(
            lambda x: Channel(device, f"CH{x}")
        )
        self._clear = Clear(device)
        self._cls = Cls(device)
        self._configuration = Configuration(device)
        self._connected = Connected(device)
        self._curvestream = Curvestream(device)
        self._customtable = Customtable(device)
        self._data = Data(device)
        self._date = Date(device)
        self._ddt = Ddt(device)
        self._dese = Dese(device)
        self._diag = Diag(device)
        self._diggrp: Dict[int, DiggrpItem] = DefaultDictPassKeyToFactory(
            lambda x: DiggrpItem(device, f"DIGGRP{x}")
        )
        self._display = Display(device)
        self._ese = Ese(device)
        self._esr = Esr(device)
        self._ethernet = Ethernet(device)
        self._event = Event(device)
        self._evmsg = Evmsg(device)
        self._evqty = Evqty(device)
        self._eyemask = Eyemask(device)
        self._factory = Factory(device)
        self._filesystem = Filesystem(device)
        self._fpanel = Fpanel(device)
        self._header = Header(device)
        self._histogram = Histogram(device)
        self._horizontal = Horizontal(device)
        self._hostprocessor = Hostprocessor(device)
        self._hsinterface = Hsinterface(device)
        self._id = Id(device)
        self._idn = Idn(device)
        self._license = License(device)
        self._lock = Lock(device)
        self._lrn = Lrn(device)
        self._mainwindow = Mainwindow(device)
        self._mask = Mask(device)
        self._math = Math(device)
        self._matharbflt: Dict[int, MatharbfltItem] = DefaultDictPassKeyToFactory(
            lambda x: MatharbfltItem(device, f"MATHArbflt{x}")
        )
        self._meastable = Meastable(device)
        self._measurement = Measurement(device)
        self._newpass = Newpass(device)
        self._opc = Opc(device)
        self._opt = Opt(device)
        self._password = Password(device)
        self._pause = Pause(device)
        self._peakstable = Peakstable(device)
        self._pilogger = Pilogger(device)
        self._plot = Plot(device)
        self._psc = Psc(device)
        self._pud = Pud(device)
        self._recall = Recall(device)
        self._ref = Ref(device)
        self._refx: Dict[int, RefItem] = DefaultDictPassKeyToFactory(
            lambda x: RefItem(device, f"REF{x}")
        )
        self._rem = Rem(device)
        self._rosc = Rosc(device)
        self._rst = Rst(device)
        self._save = Save(device)
        self._saveon = Saveon(device)
        self._saveonevent = Saveonevent(device)
        self._search = Search(device)
        self._searchtable = Searchtable(device)
        self._security = Security(device)
        self._select = Select(device)
        self._set = Set(device)
        self._socketserver = Socketserver(device)
        self._sre = Sre(device)
        self._stb = Stb(device)
        self._sv = Sv(device)
        self._teksecure = Teksecure(device)
        self._time = Time(device)
        self._totaluptime = Totaluptime(device)
        self._touchscreen = Touchscreen(device)
        self._trg = Trg(device)
        self._trigger = Trigger(device)
        self._tst = Tst(device)
        self._undo = Undo(device)
        self._unlock = Unlock(device)
        self._usbdevice = Usbdevice(device)
        self._verbose = Verbose(device)
        self._vertical = Vertical(device)
        self._visual = Visual(device)
        self._vxi = Vxi(device)
        self._wai = Wai(device)
        self._wavfrm = Wavfrm(device)
        self._wfmoutpre = Wfmoutpre(device)

    @property
    def acquire(self) -> Acquire:
        """Return the ``ACQuire`` command.

        Description:
            - Queries the current acquisition state.

        Usage:
            - Using the ``.query()`` method will send the ``ACQuire?`` query.
            - Using the ``.verify(value)`` method will send the ``ACQuire?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - ACQuire?
            ```

        Sub-properties:
            - ``.fastaverage``: The ``ACQuire:FASTAVerage`` command tree.
            - ``.maxsamplerate``: The ``ACQuire:MAXSamplerate`` command.
            - ``.mode``: The ``ACQuire:MODe`` command.
            - ``.numacq``: The ``ACQuire:NUMACq`` command.
            - ``.numavg``: The ``ACQuire:NUMAVg`` command.
            - ``.numframesacquired``: The ``ACQuire:NUMFRAMESACQuired`` command.
            - ``.sequence``: The ``ACQuire:SEQuence`` command tree.
            - ``.state``: The ``ACQuire:STATE`` command.
            - ``.stopafter``: The ``ACQuire:STOPAfter`` command.
        """
        return self._acquire

    @property
    def actonevent(self) -> Actonevent:
        """Return the ``ACTONEVent`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``ACTONEVent?`` query.
            - Using the ``.verify(value)`` method will send the ``ACTONEVent?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.enable``: The ``ACTONEVent:ENable`` command.
            - ``.limitcount``: The ``ACTONEVent:LIMITCount`` command.
            - ``.limit``: The ``ACTONEVent:LIMit`` command.
            - ``.maskfail``: The ``ACTONEVent:MASKFail`` command tree.
            - ``.maskhit``: The ``ACTONEVent:MASKHit`` command tree.
            - ``.maskpass``: The ``ACTONEVent:MASKPass`` command tree.
            - ``.measurement``: The ``ACTONEVent:MEASUrement`` command tree.
            - ``.search``: The ``ACTONEVent:SEARCH`` command tree.
            - ``.trigger``: The ``ACTONEVent:TRIGger`` command tree.
        """
        return self._actonevent

    @property
    def afg(self) -> Afg:
        """Return the ``AFG`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``AFG?`` query.
            - Using the ``.verify(value)`` method will send the ``AFG?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.amplitude``: The ``AFG:AMPLitude`` command.
            - ``.arbitrary``: The ``AFG:ARBitrary`` command tree.
            - ``.burst``: The ``AFG:BURSt`` command tree.
            - ``.frequency``: The ``AFG:FREQuency`` command.
            - ``.function``: The ``AFG:FUNCtion`` command.
            - ``.highlevel``: The ``AFG:HIGHLevel`` command.
            - ``.lowlevel``: The ``AFG:LOWLevel`` command.
            - ``.noiseadd``: The ``AFG:NOISEAdd`` command tree.
            - ``.offset``: The ``AFG:OFFSet`` command.
            - ``.output``: The ``AFG:OUTPut`` command tree.
            - ``.period``: The ``AFG:PERIod`` command.
            - ``.pulse``: The ``AFG:PULse`` command tree.
            - ``.ramp``: The ``AFG:RAMP`` command tree.
            - ``.square``: The ``AFG:SQUare`` command tree.
        """
        return self._afg

    @property
    def alias(self) -> Alias:
        """Return the ``ALIas`` command.

        Description:
            - This command sets or queries the state of alias functionality, and it is identical to
              the ``ALIAS:STATE`` command.

        Usage:
            - Using the ``.query()`` method will send the ``ALIas?`` query.
            - Using the ``.verify(value)`` method will send the ``ALIas?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``ALIas value`` command.

        SCPI Syntax:
            ```
            - ALIas {ON|OFF|<NR1>}
            - ALIas?
            ```

        Info:
            - ``OFF`` turns Alias expansion off.
            - ``ON`` turns Alias expansion on. When a defined alias is received, the specified
              command sequence is substituted for the alias and executed.
            - ``<NR1> = 0`` disables Alias mode; any other value enables Alias mode.

        Sub-properties:
            - ``.catalog``: The ``ALIas:CATalog`` command.
            - ``.define``: The ``ALIas:DEFine`` command.
            - ``.delete``: The ``ALIas:DELEte`` command.
            - ``.state``: The ``ALIas:STATE`` command.
        """
        return self._alias

    @property
    def allev(self) -> Allev:
        """Return the ``ALLEv`` command.

        Description:
            - This query-only command prompts the instrument to return all events and their messages
              (delimited by commas), and removes the returned events from the Event Queue. Use the
              ``*ESR?`` query to enable the events to be returned. This command is similar to
              repeatedly sending ``*EVMsg?`` queries to the instrument.

        Usage:
            - Using the ``.query()`` method will send the ``ALLEv?`` query.
            - Using the ``.verify(value)`` method will send the ``ALLEv?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - ALLEv?
            ```
        """
        return self._allev

    @property
    def application(self) -> Application:
        """Return the ``APPLication`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``APPLication?`` query.
            - Using the ``.verify(value)`` method will send the ``APPLication?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.activate``: The ``APPLication:ACTivate`` command.
        """
        return self._application

    @property
    def autosavepitimeout(self) -> Autosavepitimeout:
        """Return the ``AUTOSAVEPITIMEOUT`` command.

        Description:
            - This command sets or queries the idle time from the programmable interface before
              auto-save occurs.

        Usage:
            - Using the ``.query()`` method will send the ``AUTOSAVEPITIMEOUT?`` query.
            - Using the ``.verify(value)`` method will send the ``AUTOSAVEPITIMEOUT?`` query and
              raise an AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``AUTOSAVEPITIMEOUT value`` command.

        SCPI Syntax:
            ```
            - AUTOSAVEPITIMEOUT <NR1>
            - AUTOSAVEPITIMEOUT?
            ```

        Info:
            - ``<NR1>`` sets the timeout time.
        """
        return self._autosavepitimeout

    @property
    def autosaveuitimeout(self) -> Autosaveuitimeout:
        """Return the ``AUTOSAVEUITIMEOUT`` command.

        Description:
            - This command sets or queries the idle time from the user interface before auto-save
              occurs.

        Usage:
            - Using the ``.query()`` method will send the ``AUTOSAVEUITIMEOUT?`` query.
            - Using the ``.verify(value)`` method will send the ``AUTOSAVEUITIMEOUT?`` query and
              raise an AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``AUTOSAVEUITIMEOUT value`` command.

        SCPI Syntax:
            ```
            - AUTOSAVEUITIMEOUT <NR1>
            - AUTOSAVEUITIMEOUT?
            ```

        Info:
            - ``<NR1>`` sets the timeout time.
        """
        return self._autosaveuitimeout

    @property
    def autoset(self) -> Autoset:
        """Return the ``AUTOSet`` command.

        Description:
            - This command (no query format) sets the vertical, horizontal, and trigger controls of
              the instrument to automatically acquire and display the selected waveform.

        Usage:
            - Using the ``.write(value)`` method will send the ``AUTOSet value`` command.

        SCPI Syntax:
            ```
            - AUTOSet EXECute
            ```

        Info:
            - ``EXECute`` autosets the displayed waveform; this is equivalent to pressing the
              frontpanel Autoset button.

        Sub-properties:
            - ``.acquisition``: The ``AUTOSet:ACQuisition`` command tree.
            - ``.enable``: The ``AUTOSet:ENAble`` command.
            - ``.horizontal``: The ``AUTOSet:HORizontal`` command tree.
            - ``.trigger``: The ``AUTOSet:TRIGger`` command tree.
            - ``.vertical``: The ``AUTOSet:VERTical`` command tree.
        """
        return self._autoset

    @property
    def auxin(self) -> Auxin:
        """Return the ``AUXIn`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``AUXIn?`` query.
            - Using the ``.verify(value)`` method will send the ``AUXIn?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.probe``: The ``AUXIn:PRObe`` command tree.
            - ``.vterm``: The ``AUXIn:VTERM`` command tree.
        """
        return self._auxin

    @property
    def auxout(self) -> Auxout:
        """Return the ``AUXout`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``AUXout?`` query.
            - Using the ``.verify(value)`` method will send the ``AUXout?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.edge``: The ``AUXout:EDGE`` command.
            - ``.lowlatency``: The ``AUXout:LOWLatency`` command.
        """
        return self._auxout

    @property
    def bus(self) -> Bus:
        """Return the ``BUS`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``BUS?`` query.
            - Using the ``.verify(value)`` method will send the ``BUS?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``BUS:ADDNew`` command.
            - ``.b``: The ``BUS:B<x>`` command tree.
            - ``.delete``: The ``BUS:DELete`` command.
            - ``.list``: The ``BUS:LIST`` command.
        """
        return self._bus

    @property
    def bustable(self) -> Bustable:
        """Return the ``BUSTABle`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``BUSTABle?`` query.
            - Using the ``.verify(value)`` method will send the ``BUSTABle?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``BUSTABle:ADDNew`` command.
            - ``.delete``: The ``BUSTABle:DELete`` command.
            - ``.list``: The ``BUSTABle:LIST`` command.
        """
        return self._bustable

    @property
    def busy(self) -> Busy:
        """Return the ``BUSY`` command.

        Description:
            - This query-only command returns the status of the instrument. This command allows you
              to synchronize the operation of the instrument with your application program.

        Usage:
            - Using the ``.query()`` method will send the ``BUSY?`` query.
            - Using the ``.verify(value)`` method will send the ``BUSY?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - BUSY?
            ```

        Info:
            - ``<NR1> = 0`` means that the instrument is not busy processing a command whose
              execution time is extensive.
            - ``<NR1> = 1`` means that the instrument is busy processing Commands that Generate an
              OPC Message.
        """
        return self._busy

    @property
    def cal(self) -> Cal:
        """Return the ``*CAL`` command.

        Description:
            - This query-only command starts signal path calibration (SPC) and returns the status
              upon completion. Note: When running SPC through the remote interface, calibration
              status cannot be obtained until after the SPC completes. SPC takes approximately 15
              minutes per channel which means a total of 2 hours on an 8-channel model. Any remote
              command that performs an action on the instrument is also disabled until the SPC is
              complete.

        Usage:
            - Using the ``.query()`` method will send the ``*CAL?`` query.
            - Using the ``.verify(value)`` method will send the ``*CAL?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - *CAL?
            ```
        """
        return self._cal

    @property
    def calibrate(self) -> Calibrate:
        """Return the ``CALibrate`` command.

        Description:
            - This query returns the status of signal path calibration. Note: When running SPC
              through the remote interface, calibration status cannot be obtained until after the
              SPC completes, which can take several minutes.

        Usage:
            - Using the ``.query()`` method will send the ``CALibrate?`` query.
            - Using the ``.verify(value)`` method will send the ``CALibrate?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - CALibrate?
            ```

        Sub-properties:
            - ``.internal``: The ``CALibrate:INTERNal`` command.
            - ``.pwrupstatus``: The ``CALibrate:PWRUpstatus`` command.
        """
        return self._calibrate

    @property
    def callouts(self) -> Callouts:
        """Return the ``CALLOUTS`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``CALLOUTS?`` query.
            - Using the ``.verify(value)`` method will send the ``CALLOUTS?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``CALLOUTS:ADDNew`` command.
            - ``.callout``: The ``CALLOUTS:CALLOUT<x>`` command tree.
            - ``.delete``: The ``CALLOUTS:DELete`` command.
        """
        return self._callouts

    @property
    def ch(self) -> Dict[int, Channel]:
        """Return the ``CH<x>`` command.

        Description:
            - This query-only command returns the vertical parameters for the specified channel. The
              channel is specified by x.

        Usage:
            - Using the ``.query()`` method will send the ``CH<x>?`` query.
            - Using the ``.verify(value)`` method will send the ``CH<x>?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - CH<x>?
            ```

        Sub-properties:
            - ``.bandwidth``: The ``CH<x>:BANdwidth`` command.
            - ``.clipping``: The ``CH<x>:CLIPping`` command.
            - ``.coupling``: The ``CH<x>:COUPling`` command.
            - ``.deskew``: The ``CH<x>:DESKew`` command.
            - ``.ditherrange``: The ``CH<x>:DITHERrange`` command.
            - ``.invert``: The ``CH<x>:INVert`` command.
            - ``.label``: The ``CH<x>:LABel`` command tree.
            - ``.offset``: The ``CH<x>:OFFSet`` command.
            - ``.position``: The ``CH<x>:POSition`` command.
            - ``.probecontrol``: The ``CH<x>:PROBECOntrol`` command.
            - ``.probecal``: The ``CH<x>:PROBECal`` command.
            - ``.probefunc``: The ``CH<x>:PROBEFunc`` command tree.
            - ``.probetype``: The ``CH<x>:PROBETYPE`` command.
            - ``.probe``: The ``CH<x>:PRObe`` command.
            - ``.qchannel``: The ``CH<x>:QCHannel`` command.
            - ``.scaleratio``: The ``CH<x>:SCALERATio`` command.
            - ``.scale``: The ``CH<x>:SCAle`` command.
            - ``.termination``: The ``CH<x>:TERmination`` command.
            - ``.vterm``: The ``CH<x>:VTERm`` command tree.
        """
        return self._ch

    @property
    def clear(self) -> Clear:
        """Return the ``CLEAR`` command.

        Description:
            - This command clears acquisitions, measurements, and waveforms.

        Usage:
            - Using the ``.write()`` method will send the ``CLEAR`` command.

        SCPI Syntax:
            ```
            - CLEAR
            ```
        """
        return self._clear

    @property
    def cls(self) -> Cls:
        """Return the ``*CLS`` command.

        Description:
            - This command (no query form) clears the following: Event Queue Standard Event Status
              Register Status Byte Register (except the MAV bit) If the ``*CLS`` command immediately
              follows an <EOI>, the Output Queue and MAV bit (Status Byte Register bit 4) are also
              cleared. MAV indicates that information is in the output queue. The device clear (DCL)
              control message will clear the output queue and thus MAV. ``*CLS`` does not clear the
              output queue or MAV. ``*CLS`` can suppress a Service Request that is to be generated
              by an ``*OPC``. This will happen if a single sequence acquisition operation is still
              being processed when the ``*CLS`` command is executed.

        Usage:
            - Using the ``.write()`` method will send the ``*CLS`` command.

        SCPI Syntax:
            ```
            - *CLS
            ```
        """
        return self._cls

    @property
    def configuration(self) -> Configuration:
        """Return the ``CONFIGuration`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``CONFIGuration?`` query.
            - Using the ``.verify(value)`` method will send the ``CONFIGuration?`` query and raise
              an AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.analog``: The ``CONFIGuration:ANALOg`` command tree.
        """
        return self._configuration

    @property
    def connected(self) -> Connected:
        """Return the ``CONNected`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``CONNected?`` query.
            - Using the ``.verify(value)`` method will send the ``CONNected?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.requested``: The ``CONNected:REQUested`` command tree.
            - ``.status``: The ``CONNected:STATus`` command.
            - ``.usage``: The ``CONNected:USAGe`` command tree.
        """
        return self._connected

    @property
    def curvestream(self) -> Curvestream:
        """Return the ``CURVEStream`` command.

        Description:
            - This query-only command continuously transfers waveform data from the instrument as it
              is acquired. This command puts the instrument into a streaming data mode, allowing the
              controller to receive waveform records as fast as they are acquired. Use the
              ``DATa:SOUrce`` command to specify the waveform sources. The command supports all the
              same data formatting options as the CURVe? command. Control of the instrument through
              the user interface or other external clients is not allowed while in streaming data
              mode. The GPIB controller must take the instrument out of this streaming data mode to
              terminate the query and allow other input sources to resume communication with the
              instrument. The following options are available to transition out of streaming data
              mode: Send a device clear over the bus Send another command or query to the instrument
              Turning the waveform screen display mode off (``:DISplay:WAVEform OFF``) may increase
              waveform throughput during streaming mode. Using a data encoding of SRIbinary
              (``DATa:ENCdg SRIbinary``) may also increase the waveform throughput since that is the
              raw native data format of the oscilloscope. While in streaming data mode, two extreme
              conditions can occur. If the waveform records are being acquired slowly (high
              resolution), configure the controller for a long time-out threshold, as the data is
              not sent out until each complete record is acquired. If the waveform records are being
              acquired rapidly (low resolution), and the controller is not reading the data off the
              bus fast enough, the trigger rate is slowed to allow each waveform to be sent
              sequentially Note:. Curve data is transferred from the instrument asynchronously
              and,depending upon the length of the curve record, such transfers can require
              severalseconds to complete. During this time, the instrument will not respond to
              usercontrols. You can interrupt these asynchronous data transfers by sending adevice
              clear message to the instrument or by interrupting the query with anothercommand or
              query. Verify that curve data is completely transferred.

        Usage:
            - Using the ``.query()`` method will send the ``CURVEStream?`` query.
            - Using the ``.verify(value)`` method will send the ``CURVEStream?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - CURVEStream?
            ```
        """
        return self._curvestream

    @property
    def customtable(self) -> Customtable:
        """Return the ``CUSTOMTABle`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``CUSTOMTABle?`` query.
            - Using the ``.verify(value)`` method will send the ``CUSTOMTABle?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``CUSTOMTABle:ADDNew`` command.
            - ``.delete``: The ``CUSTOMTABle:DELete`` command.
            - ``.list``: The ``CUSTOMTABle:LIST`` command.
        """
        return self._customtable

    @property
    def data(self) -> Data:
        """Return the ``DATa`` command.

        Description:
            - This command sets or queries the format and location of the waveform data that is
              transferred with the CURVe? command.

        Usage:
            - Using the ``.query()`` method will send the ``DATa?`` query.
            - Using the ``.verify(value)`` method will send the ``DATa?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``DATa value`` command.

        SCPI Syntax:
            ```
            - DATa {INIT|SNAp}
            - DATa?
            ```

        Info:
            - ``INIT`` initializes the waveform data parameters to their factory defaults except for
              ``DATa:STOP``, which isset to the current acquisition record length.
            - ``SNAp`` Sets ``DATa:STARt`` and ``DATa:STOP`` to match the current waveform cursor
              positions of WAVEVIEW1 CURSOR1 if these waveform cursors are currently on. If these
              waveform cursors are not on when the ``DATa SNAp`` command is sent, it is silently
              ignored and ``DATa:STARt`` and ``:STOP`` remain unchanged.

        Sub-properties:
            - ``.encdg``: The ``DATa:ENCdg`` command.
            - ``.mode``: The ``DATa:MODe`` command.
            - ``.resample``: The ``DATa:RESample`` command.
            - ``.source``: The ``DATa:SOUrce`` command.
            - ``.start``: The ``DATa:STARt`` command.
            - ``.stop``: The ``DATa:STOP`` command.
            - ``.width``: The ``DATa:WIDth`` command.
        """
        return self._data

    @property
    def date(self) -> Date:
        """Return the ``DATE`` command.

        Description:
            - This command queries the date that the instrument displays.

        Usage:
            - Using the ``.query()`` method will send the ``DATE?`` query.
            - Using the ``.verify(value)`` method will send the ``DATE?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - DATE?
            ```
        """
        return self._date

    @property
    def ddt(self) -> Ddt:
        """Return the ``*DDT`` command.

        Description:
            - This command allows you to specify a command or a list of commands that are executed
              when the instrument receives a ``*TRG`` command. Define Device Trigger (``*DDT``) is a
              special alias that the ``*TRG`` command uses.

        Usage:
            - Using the ``.query()`` method will send the ``*DDT?`` query.
            - Using the ``.verify(value)`` method will send the ``*DDT?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``*DDT value`` command.

        SCPI Syntax:
            ```
            - *DDT {<Block>|<QString>}
            - *DDT?
            ```

        Info:
            - ``<Block>`` is a complete sequence of program messages. The messages can contain only
              valid commands that must be separated by semicolons and must follow all rules for
              concatenating commands. The sequence must be less than or equal to 80characters. The
              format of this argument is always returned as a query.
            - ``<QString>`` is a complete sequence of program messages. The messages can contain
              only valid commands that must be separated by semicolons and must follow all rules for
              concatenating commands. The sequence must be less than or equal to 80 characters.
        """
        return self._ddt

    @property
    def dese(self) -> Dese:
        """Return the ``DESE`` command.

        Description:
            - This command sets and queries the bits in the Device Event Status Enable Register
              (DESER). The DESER is the mask that determines whether events are reported to the
              Standard Event Status Register (SESR), and entered into the Event Queue. For a more
              detailed discussion of the use of these registers, see Registers. Note: Setting the
              DESER and ESER to the same value allows only those codes to be entered into the Event
              Queue and summarized on the ESB bit (bit 5) of the Status Byte Register. Use the
              ``*ESE`` command to set the ESER.

        Usage:
            - Using the ``.query()`` method will send the ``DESE?`` query.
            - Using the ``.verify(value)`` method will send the ``DESE?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``DESE value`` command.

        SCPI Syntax:
            ```
            - DESE <NR1>
            - DESE?
            ```

        Info:
            - ``<NR1>`` The binary bits of the DESER are set according to this value, which ranges
              from 1 through 255. For example, ``DESE 209`` sets the DESER to the binary value
              11010001 (that is, the most significant bit in the register is set to 1, the next most
              significant bit to 1, the next bit to 0, etc.).
            - ``DESER`` is all bits set if ``*PSC`` is 1. If ``*PSC`` is 0, the DESER maintains the
              previous power cycle value through the current power cycle.
        """
        return self._dese

    @property
    def diag(self) -> Diag:
        """Return the ``DIAg`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``DIAg?`` query.
            - Using the ``.verify(value)`` method will send the ``DIAg?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.loop``: The ``DIAg:LOOP`` command tree.
            - ``.mode``: The ``DIAg:MODe`` command.
            - ``.result``: The ``DIAg:RESUlt`` command.
            - ``.select``: The ``DIAg:SELect`` command.
            - ``.state``: The ``DIAg:STATE`` command.
        """
        return self._diag

    @property
    def diggrp(self) -> Dict[int, DiggrpItem]:
        """Return the ``DIGGRP<x>`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``DIGGRP<x>?`` query.
            - Using the ``.verify(value)`` method will send the ``DIGGRP<x>?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Info:
            - ``DIGGRP<x>`` is the channel number.

        Sub-properties:
            - ``.d``: The ``DIGGRP<x>:D<x>`` command tree.
        """
        return self._diggrp

    @property
    def display(self) -> Display:
        """Return the ``DISplay`` command.

        Description:
            - This query-only command returns the current Display settings.

        Usage:
            - Using the ``.query()`` method will send the ``DISplay?`` query.
            - Using the ``.verify(value)`` method will send the ``DISplay?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - DISplay?
            ```

        Sub-properties:
            - ``.colors``: The ``DISplay:COLors`` command.
            - ``.global``: The ``DISplay:GLObal`` command tree.
            - ``.intensity``: The ``DISplay:INTENSITy`` command.
            - ``.mathfftview1``: The ``DISplay:MATHFFTView1`` command tree.
            - ``.persistence``: The ``DISplay:PERSistence`` command.
            - ``.plotview1``: The ``DISplay:PLOTView1`` command tree.
            - ``.reffftview``: The ``DISplay:REFFFTView<x>`` command tree.
            - ``.select``: The ``DISplay:SELect`` command tree.
            - ``.varpersist``: The ``DISplay:VARpersist`` command.
            - ``.waveview``: The ``DISplay:WAVEView`` command tree.
            - ``.waveview1``: The ``DISplay:WAVEView1`` command tree.
            - ``.waveform``: The ``DISplay:WAVEform`` command.
            - ``.ch``: The ``DISplay:CH<x>`` command tree.
            - ``.math``: The ``DISplay:MATH<x>`` command tree.
            - ``.ref``: The ``DISplay:REF<x>`` command tree.
        """
        return self._display

    @property
    def ese(self) -> Ese:
        """Return the ``*ESE`` command.

        Description:
            - This command sets and queries the bits in the Event Status Enable Register (ESER). The
              ESER prevents events from being reported to the Status Byte Register (STB). For a more
              detailed discussion of the use of these registers, see Registers. Note: Setting the
              DESER and the ESER to the same values allows only those codes to be entered into the
              Event Queue and summarized on the ESB bit (bit 5) of the Status Byte Register. Use the
              DESE command to set the DESER.

        Usage:
            - Using the ``.query()`` method will send the ``*ESE?`` query.
            - Using the ``.verify(value)`` method will send the ``*ESE?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``*ESE value`` command.

        SCPI Syntax:
            ```
            - *ESE <NR1>
            - *ESE?
            ```

        Info:
            - ``<NR1>`` specifies the binary bits of the ESER according to this value, which ranges
              from 0 through 255. The power-on default for the ESER is 0 if ``*PSC`` is 1. If
              ``*PSC`` is 0, the ESER maintains the previous power cycle value through the current
              power cycle.
        """
        return self._ese

    @property
    def esr(self) -> Esr:
        """Return the ``*ESR`` command.

        Description:
            - This query-only command returns the contents of the Standard Event Status Register
              (SESR). ``*ESR?`` also clears the SESR (since reading the SESR clears it). For a more
              detailed discussion of the use of these registers, see Registers.

        Usage:
            - Using the ``.query()`` method will send the ``*ESR?`` query.
            - Using the ``.verify(value)`` method will send the ``*ESR?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - *ESR?
            ```
        """
        return self._esr

    @property
    def ethernet(self) -> Ethernet:
        """Return the ``ETHERnet`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``ETHERnet?`` query.
            - Using the ``.verify(value)`` method will send the ``ETHERnet?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.dhcpbootp``: The ``ETHERnet:DHCPbootp`` command.
            - ``.dns``: The ``ETHERnet:DNS`` command tree.
            - ``.domainname``: The ``ETHERnet:DOMAINname`` command.
            - ``.enet``: The ``ETHERnet:ENET`` command tree.
            - ``.gateway``: The ``ETHERnet:GATEWay`` command tree.
            - ``.ipaddress``: The ``ETHERnet:IPADDress`` command.
            - ``.lxi``: The ``ETHERnet:LXI`` command tree.
            - ``.name``: The ``ETHERnet:NAME`` command.
            - ``.networkconfig``: The ``ETHERnet:NETWORKCONFig`` command.
            - ``.ping``: The ``ETHERnet:PING`` command.
            - ``.subnetmask``: The ``ETHERnet:SUBNETMask`` command.
        """
        return self._ethernet

    @property
    def event(self) -> Event:
        """Return the ``EVENT`` command.

        Description:
            - This query-only command returns an event code from the Event Queue that provides
              information about the results of the last ``*ESR?`` read. ``EVENT?`` also removes the
              returned value from the Event Queue.

        Usage:
            - Using the ``.query()`` method will send the ``EVENT?`` query.
            - Using the ``.verify(value)`` method will send the ``EVENT?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - EVENT?
            ```
        """
        return self._event

    @property
    def evmsg(self) -> Evmsg:
        """Return the ``EVMsg`` command.

        Description:
            - This query-only command removes a single event code from the Event Queue that is
              associated with the results of the last ``*ESR?`` read and returns the event code with
              an explanatory message. For more information, see Event Handling.

        Usage:
            - Using the ``.query()`` method will send the ``EVMsg?`` query.
            - Using the ``.verify(value)`` method will send the ``EVMsg?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - EVMsg?
            ```
        """
        return self._evmsg

    @property
    def evqty(self) -> Evqty:
        """Return the ``EVQty`` command.

        Description:
            - This query-only command returns the number of events that are enabled in the queue.
              This is useful when using the ALLEv? query, since it lets you know exactly how many
              events will be returned.

        Usage:
            - Using the ``.query()`` method will send the ``EVQty?`` query.
            - Using the ``.verify(value)`` method will send the ``EVQty?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - EVQty?
            ```
        """
        return self._evqty

    @property
    def eyemask(self) -> Eyemask:
        """Return the ``EYEMASK`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``EYEMASK?`` query.
            - Using the ``.verify(value)`` method will send the ``EYEMASK?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.mask``: The ``EYEMASK:MASK<x>`` command tree.
        """
        return self._eyemask

    @property
    def factory(self) -> Factory:
        """Return the ``FACtory`` command.

        Description:
            - This command (no query form) resets the instrument to its factory default settings.
              This command is equivalent to pressing the DEFAULT SETUP button located on the
              instrument front panel or selecting Default Setup from the File menu. This command
              Performs the following in addition to what is done for the ``*RST`` command: Clears
              any pending OPC operations. Resets the following IEEE488.2 registers: ``*ESE 0``
              (Event Status Enable Register) ``*SRE 0`` (Service Request Enable Register) DESE 255
              (Device Event Status Enable Register) ``*PSC 1`` (Power-on Status Clear Flag) Deletes
              all defined aliases. Enables command headers (``:HEADer 1``).

        Usage:
            - Using the ``.write()`` method will send the ``FACtory`` command.

        SCPI Syntax:
            ```
            - FACtory
            ```
        """
        return self._factory

    @property
    def filesystem(self) -> Filesystem:
        """Return the ``FILESystem`` command.

        Description:
            - This query-only command returns the directory listing of the current working
              directory. This query is the same as the ``FILESystem:DIR?`` query.

        Usage:
            - Using the ``.query()`` method will send the ``FILESystem?`` query.
            - Using the ``.verify(value)`` method will send the ``FILESystem?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - FILESystem?
            ```

        Sub-properties:
            - ``.copy``: The ``FILESystem:COPy`` command.
            - ``.cwd``: The ``FILESystem:CWD`` command.
            - ``.delete``: The ``FILESystem:DELEte`` command.
            - ``.dir``: The ``FILESystem:DIR`` command.
            - ``.homedir``: The ``FILESystem:HOMEDir`` command.
            - ``.ldir``: The ``FILESystem:LDIR`` command.
            - ``.mkdir``: The ``FILESystem:MKDir`` command.
            - ``.mount``: The ``FILESystem:MOUNT`` command tree.
            - ``.readfile``: The ``FILESystem:READFile`` command.
            - ``.rename``: The ``FILESystem:REName`` command.
            - ``.rmdir``: The ``FILESystem:RMDir`` command.
            - ``.tekdrive``: The ``FILESystem:TEKDrive`` command tree.
            - ``.unmount``: The ``FILESystem:UNMOUNT`` command tree.
            - ``.writefile``: The ``FILESystem:WRITEFile`` command.
        """
        return self._filesystem

    @property
    def fpanel(self) -> Fpanel:
        """Return the ``FPAnel`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``FPAnel?`` query.
            - Using the ``.verify(value)`` method will send the ``FPAnel?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.press``: The ``FPAnel:PRESS`` command.
            - ``.turn``: The ``FPAnel:TURN`` command.
        """
        return self._fpanel

    @property
    def header(self) -> Header:
        """Return the ``HEADer`` command.

        Description:
            - This command sets or queries the Response Header Enable State that causes the
              instrument to either include or omit headers on query responses. Whether the long or
              short form of header keywords and enumerations are returned is dependent upon the
              state of ``:VERBose``. Note: This command does not affect IEEE Std 488.2-1987 Common
              Commands (those starting with an asterisk); these commands never return headers.

        Usage:
            - Using the ``.query()`` method will send the ``HEADer?`` query.
            - Using the ``.verify(value)`` method will send the ``HEADer?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``HEADer value`` command.

        SCPI Syntax:
            ```
            - HEADer {ON|OFF|<NR1>}
            - HEADer?
            ```

        Info:
            - ``<NR1>`` = 0 sets the Response Header Enable State to false; any other value sets
              this state to true.
            - ``OFF`` sets the Response Header Enable State to false. This causes the instrument to
              omit headers on query responses, so that only the argument is returned.
            - ``ON`` sets the Response Header Enable State to true. This causes the instrument to
              include headers on applicable query responses. You can then use the query response as
              a command.
        """
        return self._header

    @property
    def histogram(self) -> Histogram:
        """Return the ``HISTogram`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``HISTogram?`` query.
            - Using the ``.verify(value)`` method will send the ``HISTogram?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``HISTogram:ADDNew`` command.
            - ``.deleteall``: The ``HISTogram:DELETEALL`` command.
            - ``.delete``: The ``HISTogram:DELete`` command.
            - ``.histogram``: The ``HISTogram:HISTogram<x>`` command tree.
            - ``.list``: The ``HISTogram:LIST`` command.
        """
        return self._histogram

    @property
    def horizontal(self) -> Horizontal:
        """Return the ``HORizontal`` command.

        Description:
            - Queries the current horizontal settings.

        Usage:
            - Using the ``.query()`` method will send the ``HORizontal?`` query.
            - Using the ``.verify(value)`` method will send the ``HORizontal?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - HORizontal?
            ```

        Sub-properties:
            - ``.acqduration``: The ``HORizontal:ACQDURATION`` command.
            - ``.delay``: The ``HORizontal:DELay`` command tree.
            - ``.divisions``: The ``HORizontal:DIVisions`` command.
            - ``.main``: The ``HORizontal:MAIn`` command tree.
            - ``.mode``: The ``HORizontal:MODe`` command.
            - ``.position``: The ``HORizontal:POSition`` command.
            - ``.previewstate``: The ``HORizontal:PREViewstate`` command.
            - ``.recordlength``: The ``HORizontal:RECOrdlength`` command.
            - ``.roll``: The ``HORizontal:ROLL`` command.
            - ``.samplerate``: The ``HORizontal:SAMPLERate`` command.
            - ``.scale``: The ``HORizontal:SCAle`` command.
        """
        return self._horizontal

    @property
    def hostprocessor(self) -> Hostprocessor:
        """Return the ``HOSTProcessor`` command.

        Description:
            - This command queries the host processor that the instrument displays.

        Usage:
            - Using the ``.query()`` method will send the ``HOSTProcessor?`` query.
            - Using the ``.verify(value)`` method will send the ``HOSTProcessor?`` query and raise
              an AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - HOSTProcessor?
            ```
        """
        return self._hostprocessor

    @property
    def hsinterface(self) -> Hsinterface:
        """Return the ``HSInterface`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``HSInterface?`` query.
            - Using the ``.verify(value)`` method will send the ``HSInterface?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.port``: The ``HSInterface:PORT`` command.
            - ``.state``: The ``HSInterface:STATe`` command.
            - ``.timeout``: The ``HSInterface:TIMeout`` command.
        """
        return self._hsinterface

    @property
    def id(self) -> Id:
        """Return the ``ID`` command.

        Description:
            - This query-only command returns identifying information about the instrument and
              related firmware similar to that returned by the ``*IDN?`` IEEE488.2 common query but
              does not include the instrument serial number.

        Usage:
            - Using the ``.query()`` method will send the ``ID?`` query.
            - Using the ``.verify(value)`` method will send the ``ID?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - ID?
            ```
        """
        return self._id

    @property
    def idn(self) -> Idn:
        """Return the ``*IDN`` command.

        Description:
            - This query-only command returns the instrument identification code.

        Usage:
            - Using the ``.query()`` method will send the ``*IDN?`` query.
            - Using the ``.verify(value)`` method will send the ``*IDN?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - *IDN?
            ```
        """
        return self._idn

    @property
    def license(self) -> License:
        """Return the ``LICense`` command.

        Description:
            - This query-only command returns all license parameters.

        Usage:
            - Using the ``.query()`` method will send the ``LICense?`` query.
            - Using the ``.verify(value)`` method will send the ``LICense?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - LICense?
            ```

        Sub-properties:
            - ``.appid``: The ``LICense:APPID`` command.
            - ``.count``: The ``LICense:COUNt`` command.
            - ``.error``: The ``LICense:ERRor`` command.
            - ``.gmt``: The ``LICense:GMT`` command.
            - ``.hid``: The ``LICense:HID`` command.
            - ``.install``: The ``LICense:INSTall`` command.
            - ``.item``: The ``LICense:ITEM`` command.
            - ``.list``: The ``LICense:LIST`` command.
            - ``.uninstall``: The ``LICense:UNINSTALL`` command.
            - ``.validate``: The ``LICense:VALidate`` command.
        """
        return self._license

    @property
    def lock(self) -> Lock:
        """Return the ``LOCk`` command.

        Description:
            - This command enables or disables the touch screen and all front panel buttons and
              knobs. There is no front panel equivalent. When the front panel is locked, the front
              panel commands will not work and will not generate error events. You can work around a
              locked front panel, by using the appropriate programmatic interface commands, instead
              of the front-panel commands. For example, to set the trigger level to 50%, you could
              use ``TRIGger:A SETLevel``. To force a trigger, you could use TRIGger FORCe.

        Usage:
            - Using the ``.query()`` method will send the ``LOCk?`` query.
            - Using the ``.verify(value)`` method will send the ``LOCk?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``LOCk value`` command.

        SCPI Syntax:
            ```
            - LOCk {ALL|NONe}
            - LOCk?
            ```

        Info:
            - ``ALL`` disables all front panel controls and the touch screen.
            - ``NONe`` enables all front panel controls and the touch screen. The UNLock ALL command
              only unlocks the front panel controls.
            - ``LOCk NONe`` command has no effect. For more information, see the ANSI/IEEE Std
              488.1-1987 Standard Digital Interface for Programmable Instrumentation, section 2.8.3
              on RL State Descriptions.
        """
        return self._lock

    @property
    def lrn(self) -> Lrn:
        """Return the ``*LRN`` command.

        Description:
            - This query-only command returns the commands that list the instrument settings,
              allowing you to record or 'learn' the current instrument settings. You can use these
              commands to return the instrument to the state it was in when you made the ``*LRN?``
              query. This command is identical to the SET? command.

        Usage:
            - Using the ``.query()`` method will send the ``*LRN?`` query.
            - Using the ``.verify(value)`` method will send the ``*LRN?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - *LRN?
            ```

        Info:
            - ``<QString>`` is the license nomenclature.
        """
        return self._lrn

    @property
    def mainwindow(self) -> Mainwindow:
        """Return the ``MAINWindow`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``MAINWindow?`` query.
            - Using the ``.verify(value)`` method will send the ``MAINWindow?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.badge``: The ``MAINWindow:BADGe`` command tree.
            - ``.fontsize``: The ``MAINWindow:FONTSize`` command.
            - ``.rrbdisplaystate``: The ``MAINWindow:RRBDisplaystate`` command.
            - ``.rrbi``: The ``MAINWindow:RRBI`` command.
        """
        return self._mainwindow

    @property
    def mask(self) -> Mask:
        """Return the ``MASK`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``MASK?`` query.
            - Using the ``.verify(value)`` method will send the ``MASK?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.delete``: The ``MASK:DELete`` command.
            - ``.mask``: The ``MASK:MASK<x>`` command tree.
            - ``.test``: The ``MASK:TESt`` command tree.
        """
        return self._mask

    @property
    def math(self) -> Math:
        """Return the ``MATH`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``MATH?`` query.
            - Using the ``.verify(value)`` method will send the ``MATH?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``MATH:ADDNew`` command.
            - ``.delete``: The ``MATH:DELete`` command.
            - ``.list``: The ``MATH:LIST`` command.
            - ``.math``: The ``MATH:MATH<x>`` command tree.
        """
        return self._math

    @property
    def matharbflt(self) -> Dict[int, MatharbfltItem]:
        """Return the ``MATHArbflt<x>`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``MATHArbflt<x>?`` query.
            - Using the ``.verify(value)`` method will send the ``MATHArbflt<x>?`` query and raise
              an AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.filepath``: The ``MATHArbflt<x>:FILepath`` command.
        """
        return self._matharbflt

    @property
    def meastable(self) -> Meastable:
        """Return the ``MEASTABle`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``MEASTABle?`` query.
            - Using the ``.verify(value)`` method will send the ``MEASTABle?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``MEASTABle:ADDNew`` command.
            - ``.delete``: The ``MEASTABle:DELETE`` command.
        """
        return self._meastable

    @property
    def measurement(self) -> Measurement:
        """Return the ``MEASUrement`` command.

        Description:
            - This query-only command returns all measurement parameters.

        Usage:
            - Using the ``.query()`` method will send the ``MEASUrement?`` query.
            - Using the ``.verify(value)`` method will send the ``MEASUrement?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - MEASUrement?
            ```

        Sub-properties:
            - ``.addmeas``: The ``MEASUrement:ADDMEAS`` command.
            - ``.addnew``: The ``MEASUrement:ADDNew`` command.
            - ``.annotate``: The ``MEASUrement:ANNOTate`` command.
            - ``.autoset``: The ``MEASUrement:AUTOset`` command.
            - ``.ch``: The ``MEASUrement:CH<x>`` command tree.
            - ``.clockrecovery``: The ``MEASUrement:CLOCKRecovery`` command tree.
            - ``.ddjmethod``: The ``MEASUrement:DDJMethod`` command.
            - ``.deleteall``: The ``MEASUrement:DELETEALL`` command.
            - ``.delete``: The ``MEASUrement:DELete`` command.
            - ``.diracmodel``: The ``MEASUrement:DIRacmodel`` command.
            - ``.displayunits``: The ``MEASUrement:DISPLAYUnits`` command.
            - ``.edge``: The ``MEASUrement:EDGE<x>`` command.
            - ``.enablepjitter``: The ``MEASUrement:ENABLEPjitter`` command.
            - ``.filters``: The ``MEASUrement:FILTers`` command tree.
            - ``.gating``: The ``MEASUrement:GATing`` command.
            - ``.highlevel``: The ``MEASUrement:HIGHLEVel`` command tree.
            - ``.interp``: The ``MEASUrement:INTERp`` command.
            - ``.jittermodel``: The ``MEASUrement:JITTermodel`` command.
            - ``.list``: The ``MEASUrement:LIST`` command.
            - ``.lockrj``: The ``MEASUrement:LOCKRJ`` command.
            - ``.lockrjvalue``: The ``MEASUrement:LOCKRJValue`` command.
            - ``.math``: The ``MEASUrement:MATH<x>`` command tree.
            - ``.meas``: The ``MEASUrement:MEAS<x>`` command tree.
            - ``.measrange``: The ``MEASUrement:MEASRange`` command tree.
            - ``.mech``: The ``MEASUrement:MECH`` command tree.
            - ``.minui``: The ``MEASUrement:MINUI`` command.
            - ``.population``: The ``MEASUrement:POPUlation`` command tree.
            - ``.ref``: The ``MEASUrement:REF<x>`` command tree.
            - ``.reflevels``: The ``MEASUrement:REFLevels`` command tree.
            - ``.statistics``: The ``MEASUrement:STATIstics`` command tree.
        """
        return self._measurement

    @property
    def newpass(self) -> Newpass:
        """Return the ``NEWpass`` command.

        Description:
            - This command (no query form) changes the password that enables access to password
              protected data. The PASSWord command must be successfully executed before using this
              command or an execution error will be generated.

        Usage:
            - Using the ``.write(value)`` method will send the ``NEWpass value`` command.

        SCPI Syntax:
            ```
            - NEWpass <QString>
            ```

        Info:
            - ``<QString>`` is the new password, which can contain up to 10 characters.
        """
        return self._newpass

    @property
    def opc(self) -> Opc:
        """Return the ``*OPC`` command.

        Description:
            - This command generates the operation complete message in the Standard Event Status
              Register (SESR) when all pending commands that generate an OPC message are complete.
              The ``*OPC?`` query places the ASCII character '1' into the output queue when all such
              OPC commands are complete. The ``*OPC?`` response is not available to read until all
              pending operations finish. For a complete discussion of the use of these registers and
              the output queue, see Registers and Queues. The ``*OPC`` command allows you to
              synchronize the operation of the instrument with your application program. For more
              information, see Synchronization Methods. Refer to the Oscilloscope operations that
              can generate OPC table for a list of commands that generate an OPC message. (See Table
              3-3.)

        Usage:
            - Using the ``.query()`` method will send the ``*OPC?`` query.
            - Using the ``.verify(value)`` method will send the ``*OPC?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write()`` method will send the ``*OPC`` command.

        SCPI Syntax:
            ```
            - *OPC
            - *OPC?
            ```
        """
        return self._opc

    @property
    def opt(self) -> Opt:
        """Return the ``*OPT`` command.

        Description:
            - This query-only command returns a comma separated list of installed options as an
              arbitrary ASCII string (no quotes) of the form:
              ``<optionCode>:<optionDescription>``,``<optionCode>:<optionDescription>``... The last
              section of each entry (the text following the last hyphen) indicates the license type.
              If no options are found, NONE is returned.

        Usage:
            - Using the ``.query()`` method will send the ``*OPT?`` query.
            - Using the ``.verify(value)`` method will send the ``*OPT?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - *OPT?
            ```
        """
        return self._opt

    @property
    def password(self) -> Password:
        """Return the ``PASSWord`` command.

        Description:
            - This command (no query form) enables the ``*PUD`` and NEWpass set commands. Sending
              ``PASSWord`` without any arguments disables these same commands. Once the password is
              successfully entered, the ``*PUD`` and NEWpass commands are enabled until the
              instrument is powered off, or until the FACtory command, the ``PASSWord`` command with
              no arguments, or the ``*RST`` command is issued. To change the password, you must
              first enter the valid password with the ``PASSWord`` command and then change to your
              new password with the NEWpass command. Remember that the password is case sensitive.

        Usage:
            - Using the ``.write(value)`` method will send the ``PASSWord value`` command.

        SCPI Syntax:
            ```
            - PASSWord <QString>
            ```

        Info:
            - ``<QString>`` is the password, which can contain up to 10 characters. The factory
              default password is 'XYZZY' and is always valid.
        """
        return self._password

    @property
    def pause(self) -> Pause:
        """Return the ``PAUSe`` command.

        Description:
            - This command causes the interface to pause the specified number of seconds before
              processing any other commands.

        Usage:
            - Using the ``.write(value)`` method will send the ``PAUSe value`` command.

        SCPI Syntax:
            ```
            - PAUSe <NR3>
            ```

        Info:
            - ``<NR3>`` is the specified number of seconds the interface is to pause before
              processing any other commands. The pause time is specified as a floating point value
              in seconds and must be > 0.0 and ≥1800.0.
        """
        return self._pause

    @property
    def peakstable(self) -> Peakstable:
        """Return the ``PEAKSTABle`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``PEAKSTABle?`` query.
            - Using the ``.verify(value)`` method will send the ``PEAKSTABle?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.table``: The ``PEAKSTABle:TABle<x>`` command tree.
        """
        return self._peakstable

    @property
    def pilogger(self) -> Pilogger:
        """Return the ``PILOGger`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``PILOGger?`` query.
            - Using the ``.verify(value)`` method will send the ``PILOGger?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.filename``: The ``PILOGger:FILEName`` command.
            - ``.state``: The ``PILOGger:STATE`` command.
        """
        return self._pilogger

    @property
    def plot(self) -> Plot:
        """Return the ``PLOT`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``PLOT?`` query.
            - Using the ``.verify(value)`` method will send the ``PLOT?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``PLOT:ADDNew`` command.
            - ``.delete``: The ``PLOT:DELete`` command.
            - ``.list``: The ``PLOT:LIST`` command.
            - ``.plot``: The ``PLOT:PLOT<x>`` command tree.
        """
        return self._plot

    @property
    def psc(self) -> Psc:
        """Return the ``*PSC`` command.

        Description:
            - This command sets and queries the power-on status flag that controls the automatic
              power-on handling of the DESER, SRER, and ESER registers. When ``*PSC`` is true, the
              DESER register is set to 255 and the SRER and ESER registers are set to 0 at power-on.
              When ``*PSC`` is false, the current values in the DESER, SRER, and ESER registers are
              preserved in nonvolatile memory when power is shut off and are restored at power-on.

        Usage:
            - Using the ``.query()`` method will send the ``*PSC?`` query.
            - Using the ``.verify(value)`` method will send the ``*PSC?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``*PSC value`` command.

        SCPI Syntax:
            ```
            - *PSC {ON|OFF|<NR1>}
            - *PSC?
            ```

        Info:
            - ``<NR1>`` = 0 sets the power-on status clear flag to false, disables the power-on
              clear and allows the instrument to possibly assert SRQ after power-on; any other value
              sets the power-on status clear flag to true, enabling the power-on status clear and
              prevents any SRQ assertion after power on.
            - ``OFF`` sets the power-on status clear flag to false, disables the power-on clear and
              allows the instrument to possibly assert SRQ after power-on.
            - ``ON`` sets the power-on status clear flag to true, enabling the power-on status clear
              and prevents any SRQ assertion after power on.
        """
        return self._psc

    @property
    def pud(self) -> Pud:
        """Return the ``*PUD`` command.

        Description:
            - This command sets or queries a string of Protected User Data. This data is protected
              by the PASSWord command. You can modify it only by first entering the correct
              password. This password is not necessary to query the data.

        Usage:
            - Using the ``.query()`` method will send the ``*PUD?`` query.
            - Using the ``.verify(value)`` method will send the ``*PUD?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``*PUD value`` command.

        SCPI Syntax:
            ```
            - *PUD {<Block>|<QString>}
            - *PUD?
            ```

        Info:
            - ``<Block>`` is a block containing up to 100 characters.
            - ``<QString>`` is a string containing up to 100 characters.
        """
        return self._pud

    @property
    def recall(self) -> Recall:
        """Return the ``RECAll`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``RECAll?`` query.
            - Using the ``.verify(value)`` method will send the ``RECAll?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.mask``: The ``RECAll:MASK`` command.
            - ``.session``: The ``RECAll:SESsion`` command.
            - ``.setup``: The ``RECAll:SETUp`` command.
            - ``.waveform``: The ``RECAll:WAVEform`` command.
        """
        return self._recall

    @property
    def ref(self) -> Ref:
        """Return the ``REF`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``REF?`` query.
            - Using the ``.verify(value)`` method will send the ``REF?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``REF:ADDNew`` command.
            - ``.delete``: The ``REF:DELete`` command.
            - ``.list``: The ``REF:LIST`` command.
            - ``.ref``: The ``REF:REF<x>`` command tree.
        """
        return self._ref

    @property
    def refx(self) -> Dict[int, RefItem]:
        """Return the ``REF<x>`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``REF<x>?`` query.
            - Using the ``.verify(value)`` method will send the ``REF<x>?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.d``: The ``REF<x>_D<x>`` command tree.
            - ``.dall``: The ``REF<x>_DALL`` command tree.
        """
        return self._refx

    @property
    def rem(self) -> Rem:
        """Return the ``REM`` command.

        Description:
            - This command (no query form) embeds a comment within programs as a means of internally
              documenting the programs. This is how to embed comments in a.set file. The instrument
              ignores these embedded comment lines.

        Usage:
            - Using the ``.write(value)`` method will send the ``REM value`` command.

        SCPI Syntax:
            ```
            - REM <QString>
            ```

        Info:
            - ``<QString>`` is a string that can contain a maximum of 80 characters.
        """
        return self._rem

    @property
    def rosc(self) -> Rosc:
        """Return the ``ROSc`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``ROSc?`` query.
            - Using the ``.verify(value)`` method will send the ``ROSc?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.source``: The ``ROSc:SOUrce`` command.
            - ``.state``: The ``ROSc:STATE`` command.
        """
        return self._rosc

    @property
    def rst(self) -> Rst:
        """Return the ``*RST`` command.

        Description:
            - This command (no query form) resets the instrument to the factory default settings.
              This command does the following: Recalls the default instrument setup. Clears the
              current ``*DDT`` command. Disables aliases (``:ALIAS:STATE 0``). Disables the user
              password (for the ``*PUD`` command). The ``*RST`` command does not change the
              following: The current working directory (: ``FILESystem:CWD`` command). The state of
              command headers (: HEADer command). The state of keyword and enumeration verbosity (:
              VERBose command). The Power-on Status Clear Flag ( ``*PSC`` command). The Event Status
              Enable Register ( ``*ESE`` command). The Service Request Enable Register ( ``*SRE``
              command). The Event Status Enable Register ( ``*ESE`` command). The Service Request
              Enable Register ( ``*SRE`` command). The Device Event Status Enable Register ( DESE
              command). The user password for protected user data (: PASSWord command). The content
              of protected user data ( ``*PUD`` command). The enabled state of the socket server (:
              ``SOCKETServer:ENAble`` command). The socket server port number (:
              ``SOCKETServer:PORT`` command). The socket server protocol (:
              ``SOCKETServer:PROTOCol`` command). The USBTMC port configuration (:
              ``USBDevice:CONFigure`` command). The destination reference waveform or file path for
              the : CURVe command (: ``DATa:DESTination`` command). The source waveform for the :
              CURVe? or : WAVFrm? queries (: ``DATa:SOUrce`` command). The source waveform for the :
              CURVe? or : WAVFrm? queries (: ``DATa:SOUrce`` command). The waveform data encoding
              for the : CURVe command or query or the : WAVFrm? query (: ``DATa:ENCdg`` command).
              The starting point for : CURVe? queries (: ``DATa:STARt`` command). The ending point
              for : CURVe? queries (: ``DATa:STOP`` command). All settings associated the : WFMInpre
              commands. All user settable settings associated with the WFMOutpre commands. ``*RST``
              only resets the programmable interface settings, it does not change the user interface
              settings.

        Usage:
            - Using the ``.write()`` method will send the ``*RST`` command.

        SCPI Syntax:
            ```
            - *RST
            ```
        """
        return self._rst

    @property
    def save(self) -> Save:
        """Return the ``SAVe`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``SAVe?`` query.
            - Using the ``.verify(value)`` method will send the ``SAVe?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.eventtable``: The ``SAVe:EVENTtable`` command tree.
            - ``.image``: The ``SAVe:IMAGe`` command.
            - ``.mask``: The ``SAVe:MASK`` command.
            - ``.report``: The ``SAVe:REPOrt`` command tree.
            - ``.session``: The ``SAVe:SESsion`` command.
            - ``.setup``: The ``SAVe:SETUp`` command.
            - ``.waveform``: The ``SAVe:WAVEform`` command.
        """
        return self._save

    @property
    def saveon(self) -> Saveon:
        """Return the ``SAVEON`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``SAVEON?`` query.
            - Using the ``.verify(value)`` method will send the ``SAVEON?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.file``: The ``SAVEON:FILE`` command tree.
            - ``.image``: The ``SAVEON:IMAGe`` command.
            - ``.trigger``: The ``SAVEON:TRIGger`` command.
            - ``.waveform``: The ``SAVEON:WAVEform`` command.
        """
        return self._saveon

    @property
    def saveonevent(self) -> Saveonevent:
        """Return the ``SAVEONEVent`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``SAVEONEVent?`` query.
            - Using the ``.verify(value)`` method will send the ``SAVEONEVent?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.filedest``: The ``SAVEONEVent:FILEDest`` command.
            - ``.filename``: The ``SAVEONEVent:FILEName`` command.
            - ``.image``: The ``SAVEONEVent:IMAGe`` command tree.
            - ``.waveform``: The ``SAVEONEVent:WAVEform`` command tree.
        """
        return self._saveonevent

    @property
    def search(self) -> Search:
        """Return the ``SEARCH`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``SEARCH?`` query.
            - Using the ``.verify(value)`` method will send the ``SEARCH?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``SEARCH:ADDNew`` command.
            - ``.deleteall``: The ``SEARCH:DELETEALL`` command.
            - ``.delete``: The ``SEARCH:DELete`` command.
            - ``.list``: The ``SEARCH:LIST`` command.
            - ``.search``: The ``SEARCH:SEARCH<x>`` command tree.
            - ``.selected``: The ``SEARCH:SELected`` command.
        """
        return self._search

    @property
    def searchtable(self) -> Searchtable:
        """Return the ``SEARCHTABle`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``SEARCHTABle?`` query.
            - Using the ``.verify(value)`` method will send the ``SEARCHTABle?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.addnew``: The ``SEARCHTABle:ADDNew`` command.
            - ``.delete``: The ``SEARCHTABle:DELete`` command.
            - ``.list``: The ``SEARCHTABle:list`` command.
        """
        return self._searchtable

    @property
    def security(self) -> Security:
        """Return the ``SECurity`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``SECurity?`` query.
            - Using the ``.verify(value)`` method will send the ``SECurity?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.logger``: The ``SECurity:LOGger`` command tree.
        """
        return self._security

    @property
    def select(self) -> Select:
        """Return the ``SELect`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``SELect?`` query.
            - Using the ``.verify(value)`` method will send the ``SELect?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.ch``: The ``SELect:CH<x>`` command.
        """
        return self._select

    @property
    def set_(self) -> Set:
        """Return the ``SET`` command.

        Description:
            - This query-only command returns the commands that list the instrument settings, except
              for configuration information for the calibration values. You can use these commands
              to return the instrument to the state it was in when you made the ``SET?`` query. The
              ``SET?`` query always returns command headers, regardless of the setting of the HEADer
              command. This is because the returned commands are intended to be sent back to the
              instrument as a command string. The VERBose command can still be used to specify
              whether the returned headers should be abbreviated or full-length. This command is
              identical to the ``*LRN?`` command.

        Usage:
            - Using the ``.query()`` method will send the ``SET?`` query.
            - Using the ``.verify(value)`` method will send the ``SET?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - SET?
            ```
        """
        return self._set

    @property
    def socketserver(self) -> Socketserver:
        """Return the ``SOCKETServer`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``SOCKETServer?`` query.
            - Using the ``.verify(value)`` method will send the ``SOCKETServer?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.enable``: The ``SOCKETServer:ENAble`` command.
            - ``.port``: The ``SOCKETServer:PORT`` command.
            - ``.protocol``: The ``SOCKETServer:PROTOCol`` command.
        """
        return self._socketserver

    @property
    def sre(self) -> Sre:
        """Return the ``*SRE`` command.

        Description:
            - The ``*SRE`` (Service Request Enable) command sets and queries the bits in the Service
              Request Enable Register. For more information, refer to Registers.

        Usage:
            - Using the ``.query()`` method will send the ``*SRE?`` query.
            - Using the ``.verify(value)`` method will send the ``*SRE?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``*SRE value`` command.

        SCPI Syntax:
            ```
            - *SRE <NR1>
            - *SRE?
            ```

        Info:
            - ``<NR1>`` is a value in the range from 0 through 255. The binary bits of the SRER are
              set according to this value. Using an out-of-range value causes an execution error.
              The power-on default for SRER is 0 if ``*PSC`` is 1. If ``*PSC`` is 0, the SRER
              maintains the previous power cycle value through the current power cycle.
        """
        return self._sre

    @property
    def stb(self) -> Stb:
        """Return the ``*STB`` command.

        Description:
            - The ``*STB?`` (Read Status Byte) query returns the contents of the Status Byte
              Register (SBR) using the Master Summary Status (MSS) bit. For more information, refer
              to Registers.

        Usage:
            - Using the ``.query()`` method will send the ``*STB?`` query.
            - Using the ``.verify(value)`` method will send the ``*STB?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - *STB?
            ```
        """
        return self._stb

    @property
    def sv(self) -> Sv:
        """Return the ``SV`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``SV?`` query.
            - Using the ``.verify(value)`` method will send the ``SV?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.window``: The ``SV:WINDOW`` command.
        """
        return self._sv

    @property
    def teksecure(self) -> Teksecure:
        """Return the ``TEKSecure`` command.

        Description:
            - This command initializes, for the current user, both waveform and setup memories,
              overwriting any previously stored data. Equivalent to invoking Teksecure from the
              Utility menu. This is a time-consuming operation (3 to 5 minutes) and the instrument
              is inoperable until the TekSecure operation is complete.

        Usage:
            - Using the ``.write()`` method will send the ``TEKSecure`` command.

        SCPI Syntax:
            ```
            - TEKSecure
            ```
        """
        return self._teksecure

    @property
    def time(self) -> Time:
        """Return the ``TIMe`` command.

        Description:
            - This command sets the time in the form ``hh:mm:ss`` where hh refers to a two-digit
              hour number, mm refers to a two-digit minute number from 01 to 60, and ss refers to a
              two-digit second number from 01 to 60.

        Usage:
            - Using the ``.query()`` method will send the ``TIMe?`` query.
            - Using the ``.verify(value)`` method will send the ``TIMe?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``TIMe value`` command.

        SCPI Syntax:
            ```
            - TIMe <QString>
            - TIMe?
            ```

        Info:
            - ``<QString>`` is a quoted string representing the desired time.

        Sub-properties:
            - ``.zone``: The ``TIMe:ZONe`` command.
        """
        return self._time

    @property
    def totaluptime(self) -> Totaluptime:
        """Return the ``TOTaluptime`` command.

        Description:
            - Total number of hours the instrument has been turned on since the NV memory was last
              programmed, usually during the initial manufacturing process.

        Usage:
            - Using the ``.query()`` method will send the ``TOTaluptime?`` query.
            - Using the ``.verify(value)`` method will send the ``TOTaluptime?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - TOTaluptime?
            ```
        """
        return self._totaluptime

    @property
    def touchscreen(self) -> Touchscreen:
        """Return the ``TOUCHSCReen`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``TOUCHSCReen?`` query.
            - Using the ``.verify(value)`` method will send the ``TOUCHSCReen?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.calibrate``: The ``TOUCHSCReen:CALibrate`` command.
            - ``.state``: The ``TOUCHSCReen:STATe`` command.
        """
        return self._touchscreen

    @property
    def trg(self) -> Trg:
        """Return the ``*TRG`` command.

        Description:
            - Performs a group execute trigger on commands defined by ``*DDT``.

        Usage:
            - Using the ``.write()`` method will send the ``*TRG`` command.

        SCPI Syntax:
            ```
            - *TRG
            ```
        """
        return self._trg

    @property
    def trigger(self) -> Trigger:
        """Return the ``TRIGger`` command.

        Description:
            - This command forces a trigger event to occur. The query returns the current trigger
              parameters for the instrument.

        Usage:
            - Using the ``.query()`` method will send the ``TRIGger?`` query.
            - Using the ``.verify(value)`` method will send the ``TRIGger?`` query and raise an
              AssertionError if the returned value does not match ``value``.
            - Using the ``.write(value)`` method will send the ``TRIGger value`` command.

        SCPI Syntax:
            ```
            - TRIGger FORCe
            - TRIGger?
            ```

        Info:
            - ``FORCe`` creates a trigger event. If ``TRIGger:STATE`` is set to READy, the
              acquisition will complete. Otherwise, this command will be ignored. This is equivalent
              to pressing the Force button on the front panel.

        Sub-properties:
            - ``.a``: The ``TRIGger:A`` command tree.
            - ``.auxlevel``: The ``TRIGger:AUXLevel`` command.
            - ``.b``: The ``TRIGger:B`` command tree.
            - ``.counter``: The ``TRIGger:COUnter`` command tree.
            - ``.hysteresis``: The ``TRIGger:HYSTeresis`` command tree.
            - ``.state``: The ``TRIGger:STATE`` command.
            - ``.status``: The ``TRIGger:STATUs`` command.
        """
        return self._trigger

    @property
    def tst(self) -> Tst:
        """Return the ``*TST`` command.

        Description:
            - Tests (self-test) the interface and returns a 0.

        Usage:
            - Using the ``.query()`` method will send the ``*TST?`` query.
            - Using the ``.verify(value)`` method will send the ``*TST?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - *TST?
            ```
        """
        return self._tst

    @property
    def undo(self) -> Undo:
        """Return the ``UNDO`` command.

        Description:
            - Reverts the instrument settings to a state before the previous command or user
              interface action.

        Usage:
            - Using the ``.write()`` method will send the ``UNDO`` command.

        SCPI Syntax:
            ```
            - UNDO
            ```
        """
        return self._undo

    @property
    def unlock(self) -> Unlock:
        """Return the ``UNLock`` command.

        Description:
            - This command (no query form) unlocks the front panel controls only. To unlock the
              front panel controls and the touch screen use the LOCk NONe command. The command
              ``TOUCHSCReen:STATE ON`` enables the touch screen only. Note: If the instrument is in
              the Remote With Lockout State (RWLS), the ``UNLock`` command has no effect. For more
              information, see the ANSI-IEEE Std 488.1-1987Standard Digital Interface for
              Programmable Instrumentation, section 2.8.3 on RL State Descriptions.

        Usage:
            - Using the ``.write(value)`` method will send the ``UNLock value`` command.

        SCPI Syntax:
            ```
            - UNLock ALL
            ```

        Info:
            - ``ALL`` specifies that all front panel buttons and knobs are unlocked.
        """
        return self._unlock

    @property
    def usbdevice(self) -> Usbdevice:
        """Return the ``USBDevice`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``USBDevice?`` query.
            - Using the ``.verify(value)`` method will send the ``USBDevice?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.configure``: The ``USBDevice:CONFigure`` command.
        """
        return self._usbdevice

    @property
    def verbose(self) -> Verbose:
        """Return the ``VERBose`` command.

        Description:
            - This command sets or queries the Verbose state that controls the length of keywords on
              query responses. Keywords can be both headers and arguments.

        Usage:
            - Using the ``.write(value)`` method will send the ``VERBose value`` command.

        SCPI Syntax:
            ```
            - VERBose {ON|OFF|<NR1>}
            ```

        Info:
            - ``<NR1>`` = 0 disables Verbose, any other value enables Verbose.
            - ``OFF`` sets the Verbose state to false, which returns minimum-length keywords for
              applicable setting queries.
            - ``ON`` sets the Verbose state to true, which returns full-length keywords for
              applicable setting queries.
            - ``0`` returns minimum-length keywords for applicable setting queries; any other value
              returns full-length keywords.
        """
        return self._verbose

    @property
    def vertical(self) -> Vertical:
        """Return the ``VERTical`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``VERTical?`` query.
            - Using the ``.verify(value)`` method will send the ``VERTical?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.deskew``: The ``VERTical:DESKew`` command tree.
        """
        return self._vertical

    @property
    def visual(self) -> Visual:
        """Return the ``VISual`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``VISual?`` query.
            - Using the ``.verify(value)`` method will send the ``VISual?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.area``: The ``VISual:AREA<x>`` command tree.
            - ``.deleteall``: The ``VISual:DELETEALL`` command.
            - ``.enable``: The ``VISual:ENAble`` command.
            - ``.equation``: The ``VISual:EQUation`` command.
            - ``.showareas``: The ``VISual:SHOWAReas`` command.
            - ``.showcriteria``: The ``VISual:SHOWCRiteria`` command.
            - ``.showequation``: The ``VISual:SHOWEQuation`` command.
        """
        return self._visual

    @property
    def vxi(self) -> Vxi:
        """Return the ``VXI`` command tree.

        Usage:
            - Using the ``.query()`` method will send the ``VXI?`` query.
            - Using the ``.verify(value)`` method will send the ``VXI?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        Sub-properties:
            - ``.enable``: The ``VXI:ENAble`` command.
            - ``.port``: The ``VXI:PORT`` command tree.
        """
        return self._vxi

    @property
    def wai(self) -> Wai:
        """Return the ``*WAI`` command.

        Description:
            - The ``*WAI`` (Wait) command (no query form) prevents the instrument from executing
              further commands or queries until all pending commands that generate an OPC message
              are complete. This command allows you to synchronize the operation of the instrument
              with your application program. For more information, refer to Synchronization Methods.

        Usage:
            - Using the ``.write()`` method will send the ``*WAI`` command.

        SCPI Syntax:
            ```
            - *WAI
            ```
        """
        return self._wai

    @property
    def wavfrm(self) -> Wavfrm:
        """Return the ``WAVFrm`` command.

        Description:
            - This query-only command provides the Tektronix standard waveform query which returns
              the waveform preamble followed by the waveform data for the source specified by
              ``:DATa:SOUrce`` using the ``:DATa`` settings for encoding, width, and so forth.

        Usage:
            - Using the ``.query()`` method will send the ``WAVFrm?`` query.
            - Using the ``.verify(value)`` method will send the ``WAVFrm?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - WAVFrm?
            ```
        """
        return self._wavfrm

    @property
    def wfmoutpre(self) -> Wfmoutpre:
        """Return the ``WFMOutpre`` command.

        Description:
            - This query-only command queries the waveform formatting data for the waveform
              specified by the ``DATa:SOUrce`` command. The preamble components are considered to be
              of two types; formatting and interpretation. The formatting components are: ENCdg,
              ``BN_Fmt``, ``BYT_Or``, ``BYT_Nr``, ``BIT_Nr``. The interpretation components are
              derived from the ``DATa:SOUrce`` specified waveform.

        Usage:
            - Using the ``.query()`` method will send the ``WFMOutpre?`` query.
            - Using the ``.verify(value)`` method will send the ``WFMOutpre?`` query and raise an
              AssertionError if the returned value does not match ``value``.

        SCPI Syntax:
            ```
            - WFMOutpre?
            ```

        Sub-properties:
            - ``.asc_fmt``: The ``WFMOutpre:ASC_Fmt`` command.
            - ``.bit_nr``: The ``WFMOutpre:BIT_Nr`` command.
            - ``.bn_fmt``: The ``WFMOutpre:BN_Fmt`` command.
            - ``.byt_nr``: The ``WFMOutpre:BYT_Nr`` command.
            - ``.byt_or``: The ``WFMOutpre:BYT_Or`` command.
            - ``.centerfrequency``: The ``WFMOutpre:CENTERFREQuency`` command.
            - ``.domain``: The ``WFMOutpre:DOMain`` command.
            - ``.encdg``: The ``WFMOutpre:ENCdg`` command.
            - ``.nr_pt``: The ``WFMOutpre:NR_Pt`` command.
            - ``.pt_fmt``: The ``WFMOutpre:PT_Fmt`` command.
            - ``.pt_order``: The ``WFMOutpre:PT_ORder`` command.
            - ``.pt_off``: The ``WFMOutpre:PT_Off`` command.
            - ``.resample``: The ``WFMOutpre:RESample`` command.
            - ``.span``: The ``WFMOutpre:SPAN`` command.
            - ``.wfid``: The ``WFMOutpre:WFId`` command.
            - ``.wfmtype``: The ``WFMOutpre:WFMTYPe`` command.
            - ``.xincr``: The ``WFMOutpre:XINcr`` command.
            - ``.xunit``: The ``WFMOutpre:XUNit`` command.
            - ``.xzero``: The ``WFMOutpre:XZEro`` command.
            - ``.ymult``: The ``WFMOutpre:YMUlt`` command.
            - ``.yoff``: The ``WFMOutpre:YOFf`` command.
            - ``.yunit``: The ``WFMOutpre:YUNit`` command.
            - ``.yzero``: The ``WFMOutpre:YZEro`` command.
        """
        return self._wfmoutpre


class DPO7AXMixin:
    """A mixin that provides access to the DPO7AX commands and constants.

    Properties:
        - ``.command_argument_constants``: The DPO7AX command argument constants.
        - ``.commands``: The DPO7AX commands.
    """

    @cached_property
    def command_argument_constants(self) -> DPO7AXCommandConstants:  # pylint: disable=no-self-use
        """Return the DPO7AX command argument constants.

        This provides access to all the string constants which can be used as arguments for DPO7AX
        commands.
        """
        return DPO7AXCommandConstants()

    @cached_property
    def commands(self) -> DPO7AXCommands:
        """Return the DPO7AX commands.

        This provides access to all the commands for the DPO7AX device. See the documentation of
        each sub-property for more usage information.

        Sub-properties:
            - ``.acquire``: The ``ACQuire`` command.
            - ``.actonevent``: The ``ACTONEVent`` command tree.
            - ``.afg``: The ``AFG`` command tree.
            - ``.alias``: The ``ALIas`` command.
            - ``.allev``: The ``ALLEv`` command.
            - ``.application``: The ``APPLication`` command tree.
            - ``.autosavepitimeout``: The ``AUTOSAVEPITIMEOUT`` command.
            - ``.autosaveuitimeout``: The ``AUTOSAVEUITIMEOUT`` command.
            - ``.autoset``: The ``AUTOSet`` command.
            - ``.auxin``: The ``AUXIn`` command tree.
            - ``.auxout``: The ``AUXout`` command tree.
            - ``.bus``: The ``BUS`` command tree.
            - ``.bustable``: The ``BUSTABle`` command tree.
            - ``.busy``: The ``BUSY`` command.
            - ``.cal``: The ``*CAL`` command.
            - ``.calibrate``: The ``CALibrate`` command.
            - ``.callouts``: The ``CALLOUTS`` command tree.
            - ``.ch``: The ``CH<x>`` command.
            - ``.clear``: The ``CLEAR`` command.
            - ``.cls``: The ``*CLS`` command.
            - ``.configuration``: The ``CONFIGuration`` command tree.
            - ``.connected``: The ``CONNected`` command tree.
            - ``.curvestream``: The ``CURVEStream`` command.
            - ``.customtable``: The ``CUSTOMTABle`` command tree.
            - ``.data``: The ``DATa`` command.
            - ``.date``: The ``DATE`` command.
            - ``.ddt``: The ``*DDT`` command.
            - ``.dese``: The ``DESE`` command.
            - ``.diag``: The ``DIAg`` command tree.
            - ``.diggrp``: The ``DIGGRP<x>`` command tree.
            - ``.display``: The ``DISplay`` command.
            - ``.ese``: The ``*ESE`` command.
            - ``.esr``: The ``*ESR`` command.
            - ``.ethernet``: The ``ETHERnet`` command tree.
            - ``.event``: The ``EVENT`` command.
            - ``.evmsg``: The ``EVMsg`` command.
            - ``.evqty``: The ``EVQty`` command.
            - ``.eyemask``: The ``EYEMASK`` command tree.
            - ``.factory``: The ``FACtory`` command.
            - ``.filesystem``: The ``FILESystem`` command.
            - ``.fpanel``: The ``FPAnel`` command tree.
            - ``.header``: The ``HEADer`` command.
            - ``.histogram``: The ``HISTogram`` command tree.
            - ``.horizontal``: The ``HORizontal`` command.
            - ``.hostprocessor``: The ``HOSTProcessor`` command.
            - ``.hsinterface``: The ``HSInterface`` command tree.
            - ``.id``: The ``ID`` command.
            - ``.idn``: The ``*IDN`` command.
            - ``.license``: The ``LICense`` command.
            - ``.lock``: The ``LOCk`` command.
            - ``.lrn``: The ``*LRN`` command.
            - ``.mainwindow``: The ``MAINWindow`` command tree.
            - ``.mask``: The ``MASK`` command tree.
            - ``.math``: The ``MATH`` command tree.
            - ``.matharbflt``: The ``MATHArbflt<x>`` command tree.
            - ``.meastable``: The ``MEASTABle`` command tree.
            - ``.measurement``: The ``MEASUrement`` command.
            - ``.newpass``: The ``NEWpass`` command.
            - ``.opc``: The ``*OPC`` command.
            - ``.opt``: The ``*OPT`` command.
            - ``.password``: The ``PASSWord`` command.
            - ``.pause``: The ``PAUSe`` command.
            - ``.peakstable``: The ``PEAKSTABle`` command tree.
            - ``.pilogger``: The ``PILOGger`` command tree.
            - ``.plot``: The ``PLOT`` command tree.
            - ``.psc``: The ``*PSC`` command.
            - ``.pud``: The ``*PUD`` command.
            - ``.recall``: The ``RECAll`` command tree.
            - ``.ref``: The ``REF`` command tree.
            - ``.refx``: The ``REF<x>`` command tree.
            - ``.rem``: The ``REM`` command.
            - ``.rosc``: The ``ROSc`` command tree.
            - ``.rst``: The ``*RST`` command.
            - ``.save``: The ``SAVe`` command tree.
            - ``.saveon``: The ``SAVEON`` command tree.
            - ``.saveonevent``: The ``SAVEONEVent`` command tree.
            - ``.search``: The ``SEARCH`` command tree.
            - ``.searchtable``: The ``SEARCHTABle`` command tree.
            - ``.security``: The ``SECurity`` command tree.
            - ``.select``: The ``SELect`` command tree.
            - ``.set``: The ``SET`` command.
            - ``.socketserver``: The ``SOCKETServer`` command tree.
            - ``.sre``: The ``*SRE`` command.
            - ``.stb``: The ``*STB`` command.
            - ``.sv``: The ``SV`` command tree.
            - ``.teksecure``: The ``TEKSecure`` command.
            - ``.time``: The ``TIMe`` command.
            - ``.totaluptime``: The ``TOTaluptime`` command.
            - ``.touchscreen``: The ``TOUCHSCReen`` command tree.
            - ``.trg``: The ``*TRG`` command.
            - ``.trigger``: The ``TRIGger`` command.
            - ``.tst``: The ``*TST`` command.
            - ``.undo``: The ``UNDO`` command.
            - ``.unlock``: The ``UNLock`` command.
            - ``.usbdevice``: The ``USBDevice`` command tree.
            - ``.verbose``: The ``VERBose`` command.
            - ``.vertical``: The ``VERTical`` command tree.
            - ``.visual``: The ``VISual`` command tree.
            - ``.vxi``: The ``VXI`` command tree.
            - ``.wai``: The ``*WAI`` command.
            - ``.wavfrm``: The ``WAVFrm`` command.
            - ``.wfmoutpre``: The ``WFMOutpre`` command.
        """
        device = self if isinstance(self, PIControl) else None
        return DPO7AXCommands(device)
