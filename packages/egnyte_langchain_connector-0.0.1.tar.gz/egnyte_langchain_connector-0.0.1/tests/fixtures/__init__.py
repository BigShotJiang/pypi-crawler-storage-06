"""Test fixtures for egnyte-retriever tests."""
