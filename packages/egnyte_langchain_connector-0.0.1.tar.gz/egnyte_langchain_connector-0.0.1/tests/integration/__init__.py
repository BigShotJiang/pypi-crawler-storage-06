"""Integration tests for egnyte-retriever."""
