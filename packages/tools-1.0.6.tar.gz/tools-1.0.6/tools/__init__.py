
__version__ = "1.0.6"
from .tools import *
from . import os

'''
For third-party packages, import manually by something like:
import tools.pytorch
import tools.pytorch as tpytorch
import tools.pytorch as tpt
import tools.pytorch as Tpt
'''

# TODO: make animator in plot/
