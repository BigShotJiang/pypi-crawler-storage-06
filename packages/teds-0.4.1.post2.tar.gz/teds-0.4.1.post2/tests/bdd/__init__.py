"""BDD tests for TeDS generate functionality."""
