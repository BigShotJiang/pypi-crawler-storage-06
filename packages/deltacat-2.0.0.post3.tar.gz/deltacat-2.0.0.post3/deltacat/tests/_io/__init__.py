# NOTE - this module is renamed because it is shadowing the stdlib io module when running tests in Pycharm
