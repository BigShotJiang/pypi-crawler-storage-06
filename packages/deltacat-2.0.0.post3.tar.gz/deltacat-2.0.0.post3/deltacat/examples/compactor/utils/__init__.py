# Common utilities for DeltaCAT compactor examples
