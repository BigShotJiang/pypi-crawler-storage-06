"""Daft integration package for DeltaCAT.

This package provides integration between DeltaCAT and Daft.
"""
