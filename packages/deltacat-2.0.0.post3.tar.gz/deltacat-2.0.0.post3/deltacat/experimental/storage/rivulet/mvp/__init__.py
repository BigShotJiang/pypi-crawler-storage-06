"""
These classes are temporary for our super scrappy MVP. I chose to make this Mvp package to make it explicit what interfaces need to be replaced later

In particular all the IO will use in memory python lists/dicts for the MVP
"""
