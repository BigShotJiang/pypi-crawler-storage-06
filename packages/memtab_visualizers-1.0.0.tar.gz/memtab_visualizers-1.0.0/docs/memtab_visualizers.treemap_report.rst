memtab\_visualizers.treemap\_report module
==========================================

.. automodule:: memtab_visualizers.treemap_report
   :members:
   :undoc-members:
   :show-inheritance:
