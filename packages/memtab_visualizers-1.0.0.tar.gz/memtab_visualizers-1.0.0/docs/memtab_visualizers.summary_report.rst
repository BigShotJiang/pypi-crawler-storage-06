memtab\_visualizers.summary\_report module
==========================================

.. automodule:: memtab_visualizers.summary_report
   :members:
   :undoc-members:
   :show-inheritance:
