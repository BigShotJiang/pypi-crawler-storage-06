memtab\_visualizers.category\_memmap\_report module
===================================================

.. automodule:: memtab_visualizers.category_memmap_report
   :members:
   :undoc-members:
   :show-inheritance:
