memtab\_visualizers.excel\_report module
========================================

.. automodule:: memtab_visualizers.excel_report
   :members:
   :undoc-members:
   :show-inheritance:
