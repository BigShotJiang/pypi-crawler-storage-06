from hydron.main import main

def test_main():
    main()
