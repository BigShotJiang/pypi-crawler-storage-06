import logging

kxyLogger = logging.getLogger('kxy.framework')
kxyLogger.setLevel(logging.INFO)