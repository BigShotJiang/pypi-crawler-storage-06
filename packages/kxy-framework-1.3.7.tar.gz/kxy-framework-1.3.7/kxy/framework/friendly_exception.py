class FriendlyException(Exception):
    pass

class NoPermissionException(Exception):
    pass
class NoLoginException(Exception):
    pass

class VersionMaxException(Exception):
    pass


class ScriptException(Exception):
    pass


class TagExistException(Exception):
    pass
