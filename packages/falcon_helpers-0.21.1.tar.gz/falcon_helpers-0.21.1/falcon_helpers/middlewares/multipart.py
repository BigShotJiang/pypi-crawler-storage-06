from falcon_multipart.middleware import MultipartMiddleware


class MultipartMiddleware(MultipartMiddleware):
    pass
