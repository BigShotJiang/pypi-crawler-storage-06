uharfbuzz documentation
=======================

.. include:: ../../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   reference
