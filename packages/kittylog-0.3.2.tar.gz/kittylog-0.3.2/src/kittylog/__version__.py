"""Version information for kittylog."""

__version__ = "0.3.2"
