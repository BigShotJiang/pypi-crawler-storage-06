# Pretty Simple Logging for Python

Simple Python logging. Easy to use and pretty.
It's just CLI messages for now.
[Hosted on PyPI](https://pypi.org/project/prettysimplelogging)

## Install
```
pip install prettysimplelogging
```

## Usage
```
from betterlogging import Message as msg
msg('hello world').print()
```
