# Remember to bump the version when you decide to release a new version
VERSION = "1.0.7"