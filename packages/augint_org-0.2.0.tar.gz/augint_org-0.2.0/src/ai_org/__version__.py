"""Version information for augint-org."""

__version__ = "0.1.0"
