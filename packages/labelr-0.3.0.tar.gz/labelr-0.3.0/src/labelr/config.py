LABEL_STUDIO_DEFAULT_URL = "https://annotate.openfoodfacts.org"
