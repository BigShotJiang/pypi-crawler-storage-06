# README

## Development

```bash
bash install_dev.sh
```

## Build

```sh
python -m pip install --upgrade build

bash build.sh
```
