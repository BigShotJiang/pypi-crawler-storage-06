from enum import StrEnum


class Format(StrEnum):
    BYTES = "bytes"
    STRING = "string"
