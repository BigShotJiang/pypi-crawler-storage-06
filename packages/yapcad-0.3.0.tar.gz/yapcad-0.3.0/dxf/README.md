# **yapCAD** DXF Example Output
A collection of DXF files produced by [yapCAD examples](../examples/README.md)

This is a collection of DXF example files so that you can see the type
of output **yapCAD** produces without having to install and run the
code yourself.  You will need a DXF file viewer to see these drawings.
