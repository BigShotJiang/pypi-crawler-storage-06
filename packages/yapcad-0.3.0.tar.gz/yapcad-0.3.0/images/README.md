# **yapCAD** Example Image Output
A collection of image files produced from [yapCAD examples](../examples/README.md)

This is a collection of image files so that you can see the type of
output **yapCAD** produces without having to install and run the code
yourself.  These are all unedited screen grabs (with the exceptoin of
yapCadSplash.png, which is a composite) resulting from viewing example
DXF files in the [qCad](https://www.qcad.org/en/) CAD editor.
