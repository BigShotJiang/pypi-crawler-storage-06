from .base import KittyCadBaseModel


class SetGridScale(KittyCadBaseModel):
    """The response from the 'SetGridScale'."""
