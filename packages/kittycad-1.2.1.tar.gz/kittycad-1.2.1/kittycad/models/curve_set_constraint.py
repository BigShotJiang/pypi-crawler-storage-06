from .base import KittyCadBaseModel


class CurveSetConstraint(KittyCadBaseModel):
    """The response from the `CurveSetConstraint` endpoint."""
