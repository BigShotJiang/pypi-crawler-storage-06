class MondayAPIError(Exception):
    """Excepción para errores de la API de Monday.com."""
    pass
