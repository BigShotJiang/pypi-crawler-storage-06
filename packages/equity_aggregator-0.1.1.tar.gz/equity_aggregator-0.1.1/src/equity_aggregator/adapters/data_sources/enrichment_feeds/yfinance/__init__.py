# yfinance/__init__.py

from .feed import open_yfinance_feed

__all__ = ["open_yfinance_feed"]
