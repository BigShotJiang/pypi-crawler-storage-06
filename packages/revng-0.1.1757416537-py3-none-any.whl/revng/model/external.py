#
# This file is distributed under the MIT License. See LICENSE.md for details.
#

from revng.model.metaaddress import MetaAddress

__all__ = ["MetaAddress"]
