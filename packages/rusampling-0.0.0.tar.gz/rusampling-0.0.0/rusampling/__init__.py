'''
RUSampling package. Visit https://lynnejewson.github.io/rusampling.com/ for more information.
'''

__all__ = [
    'ru'
]