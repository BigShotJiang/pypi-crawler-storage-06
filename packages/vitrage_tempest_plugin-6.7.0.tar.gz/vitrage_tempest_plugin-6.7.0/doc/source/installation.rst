============
Installation
============

Tempest automatically discovers installed plugins. That's why you just need
to install the Python packages that contains the Vitrage Tempest plugin in
the same environment where Tempest is installed.

At the command line::

    $ git clone https://opendev.org/openstack/vitrage-tempest-plugin
    $ cd vitrage-tempest-plugin/
    $ pip install vitrage-tempest-plugin
