======================
Vitrage Tempest Plugin
======================

Tempest plugin for Vitrage Project

It contains the tempest plugin for the functional testing of Vitrage Project.

* Free software: Apache license
* Documentation: https://docs.openstack.org/vitrage/latest/
* Release notes: https://docs.openstack.org/releasenotes/vitrage/
* Source: https://opendev.org/openstack/vitrage-tempest-plugin
* Stories and Bugs: https://storyboard.openstack.org/#!/project/openstack/vitrage-tempest-plugin
