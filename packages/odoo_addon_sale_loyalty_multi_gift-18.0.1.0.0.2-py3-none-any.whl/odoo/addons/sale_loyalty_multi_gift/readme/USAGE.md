Once configured, apply the programs as usual to get the expected
rewards.
