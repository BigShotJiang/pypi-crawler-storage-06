Configure the promotion as told in `loyalty_multi_gift` readme.
