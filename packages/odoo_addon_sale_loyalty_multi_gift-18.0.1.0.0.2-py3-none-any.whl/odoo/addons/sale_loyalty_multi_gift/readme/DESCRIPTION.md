This module allows to define multiple reward products on promotions on
sale orders.
