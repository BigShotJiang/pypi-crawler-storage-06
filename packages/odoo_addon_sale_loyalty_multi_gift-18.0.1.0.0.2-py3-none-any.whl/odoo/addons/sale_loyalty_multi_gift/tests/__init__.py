from . import test_sale_loyalty_multi_gift
