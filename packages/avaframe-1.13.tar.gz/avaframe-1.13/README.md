**The AvaFrame documentation is hosted on ReadTheDocs: http://docs.avaframe.org**

All details about installation, running etc can be found there.

### Tests

[<img src="https://readthedocs.org/projects/avaframe/badge/?version=latest">](http://docs.avaframe.org/en/latest/)

[![Maintainability](https://qlty.sh/badges/61301001-b02c-4706-9603-bc0bb1269b58/maintainability.svg)](https://qlty.sh/gh/avaframe/projects/AvaFrame)

[![Code Coverage](https://qlty.sh/badges/61301001-b02c-4706-9603-bc0bb1269b58/test_coverage.svg)](https://qlty.sh/gh/avaframe/projects/AvaFrame)

### License

Licensed with [![European Public License EUPL](https://img.shields.io/badge/license-EUPL-green.png)](https://git.avaframe.org/AvaFrame/AvaFrame/src/branch/master/LICENSE.txt)

### To cite

[![DOI](https://zenodo.org/badge/281922740.svg)](https://zenodo.org/badge/latestdoi/281922740)
