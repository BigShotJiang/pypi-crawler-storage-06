---
name: com1DFA Dev Topic
about: For all com1DFApy develompent topics
title: topic [com1DFAdev]
labels: com1DFAdev
assignees: ''

---

**Description of topic** 

**Related AvaFrame functions**

**Related C-code files/functions/linenumbers
