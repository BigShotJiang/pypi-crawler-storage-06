"""Tools for generating reports """
