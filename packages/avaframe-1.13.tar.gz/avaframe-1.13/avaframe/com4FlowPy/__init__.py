#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''Flow-Py model: statistical approach for gravitational mass flows'''
