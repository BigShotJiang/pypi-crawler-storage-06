# com8MoTPSA

This is the initial development / prototype stage of including control of MoTPSA in AvaFrame.

For now you need a compiled binary, available from ???

This binary needs to live in the avaframe/com8MoTPSA directory
