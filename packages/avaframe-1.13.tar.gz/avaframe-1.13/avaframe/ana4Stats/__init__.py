"""Tools for statistical analysis of simulation results """
