"""Code for ana3AIMEC analysis module"""
