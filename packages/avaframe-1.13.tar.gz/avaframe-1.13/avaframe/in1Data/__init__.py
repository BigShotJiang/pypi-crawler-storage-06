""" Tools for fetching or generating input data """
