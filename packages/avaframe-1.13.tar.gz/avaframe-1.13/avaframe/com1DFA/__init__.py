"""Dense flow avalanche kernel (Python/cython)"""
