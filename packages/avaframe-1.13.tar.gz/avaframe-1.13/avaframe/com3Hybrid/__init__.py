#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''Hybrid modelling: combining DFA simulation and statistical approaches'''
