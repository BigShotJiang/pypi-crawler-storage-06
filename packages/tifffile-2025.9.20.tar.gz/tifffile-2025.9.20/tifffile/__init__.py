# tifffile/__init__.py

from .tifffile import *
from .tifffile import __all__, __doc__, __version__, main
