## Publisher
Use template method pattern to design `Publisher` class

- `BluesPublisher` abstract class
- `BluesBriefPublisher` concreate class
- `BluesArticlePublisher` concreate class
- `BluesGalleryPublisher` concreate class
- `BluesQAPublisher` concreate class