## visitor
管理proxy特有功能，使用visitor模式

简化element结构，`BluesProxyChrome`接受`Visitor`对象实现功能