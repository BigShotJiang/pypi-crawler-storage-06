# One Logger Open Telemetry (OTEL) extension

This project contains extensions to enable using OTEL as a backend for One Logger library.
