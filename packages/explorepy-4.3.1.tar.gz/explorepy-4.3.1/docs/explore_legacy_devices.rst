============
Legacy device and explorepy support
============

Starting from explorepy 4.0.0, latest version of explorepy will only support Explore Pro devices, meaning users will not be able to use legacy devices with explorepy 4.0.0 and onwards.
If you want to install explorepy for legacy devices, please use the following command for windows and linux.
   .. code-block:: bash

      pip install explorepy==3.2.1

To install explorepy 3.2.1 in Mac, please contact support@mentalab.com.
