
Authors
=======


* Salman Rahman - `salman@mentalab.com <mailto:salman@mentalab.com>`_
* Andrea Escartin
* Sonja Stefani -  `sonja@mentalab.com <mailto:sonja@mentalab.com>`_
* Mohamad Atayi
* Masoome Fazelian
* Alex Platt
