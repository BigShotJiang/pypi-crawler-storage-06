# 如何使用
pip install daniel_eos

# 可以用的包
upload_file
AsyncHttpClient
RedisManager
json_response
error_response 
CODES