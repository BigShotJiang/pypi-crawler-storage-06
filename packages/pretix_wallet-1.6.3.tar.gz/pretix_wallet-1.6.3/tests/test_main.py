def test_empty():
    # put your first tests here
    assert 1 + 1 == 2
