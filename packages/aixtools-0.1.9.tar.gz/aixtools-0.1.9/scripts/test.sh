#!/bin/bash -eu
set -o pipefail

# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

# Install required dependencies
echo "Installing test dependencies..."
uv pip install pytest pytest-asyncio pytest-mock pytest-cov

# Ensure .env exists
touch .env

# Add the project root to PYTHONPATH so imports work correctly
export PYTHONPATH="${PROJECT_DIR}:${PYTHONPATH:-}"

# Check if a specific test is provided as parameter
if [ $# -eq 1 ]; then
    # Run specific test without coverage
    echo "Running specific test: $1"
    pytest "$1" -v
else
    # Run all tests using pytest with coverage
    echo "Running tests with coverage..."
    pytest tests/ -v --cov=aixtools --cov-report=term-missing
    
    # Generate HTML coverage report
    # pytest tests/ --cov=aixtools --cov-report=html
fi
