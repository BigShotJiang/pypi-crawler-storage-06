# src/bloodhound_cli/__init__.py
from .main import BloodHoundACEAnalyzer
__version__ = "0.1.0"