from .tiny_di_container import TinyDIContainer

__all__ = [
    "TinyDIContainer",
]
