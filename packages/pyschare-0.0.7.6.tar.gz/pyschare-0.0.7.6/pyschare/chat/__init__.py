# init file for gemini_chat subpackage in pyschare 

from .gemini_chat import get_gemini_chat

gemini_chat = get_gemini_chat()

__all__ = ['gemini_chat']
