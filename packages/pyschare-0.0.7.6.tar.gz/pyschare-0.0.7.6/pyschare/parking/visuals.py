from .interactive_plots import _Visuals

def visuals():
    new_visuals = _Visuals()
    return new_visuals

visuals()