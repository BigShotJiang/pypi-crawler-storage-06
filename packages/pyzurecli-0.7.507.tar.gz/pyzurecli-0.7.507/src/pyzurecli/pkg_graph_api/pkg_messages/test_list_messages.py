# from . import list_received_messages_from_person
#
#
# class DummyGraphAPI:
#     pass
#
# def test_list_received_messages_from_person():
#     foo = list_received_messages_from_person(DummyGraphAPI, "foo.bar@foobar.com")
#     assert isinstance(foo, dict) == True