-- missing option
alter server s;
