-- simple
drop role s;

-- full
drop role if exists a, b, c;
drop role if exists a, b, c;

