-- simple
alter large object 12345 owner to u;

-- current_role
alter large object 12345 owner to current_role;

