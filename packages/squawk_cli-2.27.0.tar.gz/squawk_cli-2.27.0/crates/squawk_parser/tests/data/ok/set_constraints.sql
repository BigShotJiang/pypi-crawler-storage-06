-- docs
set constraints all deferred;

set constraints all immediate;

set constraints foo, bar, a.b immediate;

set constraints bar immediate;

