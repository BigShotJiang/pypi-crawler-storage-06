drop trigger tr on t;

drop trigger tr on bar.t;

drop trigger if exists tr on t;

drop trigger if exists tr on t cascade;

drop trigger tr on t restrict;

