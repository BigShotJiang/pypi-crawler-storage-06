-- pg_docs
reset some_config_param;
reset all;

reset foo.bar.buzz;
reset time zone;
reset transaction isolation level;
reset session authorization;
