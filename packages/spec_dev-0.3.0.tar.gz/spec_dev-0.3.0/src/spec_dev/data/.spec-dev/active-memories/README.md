# Task Memory Archive

Store completed task memories in this folder using the `T-XXX-memory.md` naming
pattern. A fresh template lives at `.spec-dev/templates/memories/task-memory-template.md`
and the CLI command `spec-dev memory` can scaffold new entries automatically.
