# NFR Budget Appendix — Optional

| Category | Target / Budget | Measurement Strategy | Owner |
|----------|-----------------|----------------------|-------|
| Performance | | | |
| Reliability | | | |
| Security / Privacy | | | |
| Accessibility | | | |

Notes:
- Capture how you will test or observe each target.
- Flag trade-offs or compensating controls if you cannot meet a budget immediately.
