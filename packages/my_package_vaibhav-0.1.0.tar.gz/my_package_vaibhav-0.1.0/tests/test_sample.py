def test_addition():
    assert 2 + 2 == 4