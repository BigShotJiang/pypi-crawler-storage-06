import os

DATADIR = os.path.join(os.path.dirname(__file__), 'melt_fraction_data')
