# create-browser-app (Python)

The fastest way to start building with Stagehand, the AI-powered browser automation framework.

## Quick Start

```bash
uvx create-browser-app
```

## What You Get

- Pre-configured Stagehand project
- Environment setup for Browserbase
- Ready-to-run example code
- All dependencies included