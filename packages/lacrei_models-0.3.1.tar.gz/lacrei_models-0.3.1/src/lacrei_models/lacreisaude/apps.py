from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class LacreisaudeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "lacrei_models.lacreisaude"
    label = "lacrei_models_lacreisaude"
    verbose_name = _("Lacrei Saúde")

    def ready(self):
        from watson import search as watson
        from .models import Professional

        # aqui é direto, sem `.search`
        watson.register(Professional)
