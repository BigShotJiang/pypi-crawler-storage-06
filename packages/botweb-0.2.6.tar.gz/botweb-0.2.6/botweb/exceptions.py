class EmptyValue(Exception):
    ...


class EmptyCookies(Exception):
    ...


class NotFound(Exception):
    ...


class TokenNotFound(Exception):
    ...


class PrefixEnvNotSet(Exception):
    ...
