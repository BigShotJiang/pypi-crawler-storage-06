"""
Collections of power system entity models.
"""
