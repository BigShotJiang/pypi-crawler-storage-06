"""
Extended functionality, e.g., network import, node factories, cost allocation, etc.
"""
