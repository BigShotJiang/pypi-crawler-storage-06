"""
Configuration classes for different RL algorithms
"""
