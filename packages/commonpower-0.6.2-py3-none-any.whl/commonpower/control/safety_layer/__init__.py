"""
Safety layers for RL controllers.
"""
