"""
Functionality related to controllers and safety.
"""
