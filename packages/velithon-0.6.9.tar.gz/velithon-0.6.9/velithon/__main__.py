"""Entry point for python -m velithon."""

from velithon.cli import cli

if __name__ == '__main__':
    cli()
