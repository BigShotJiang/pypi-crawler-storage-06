[← Back to Quick Start index](index.md)

# Spin up the app
Run the development server to expose the generated routes.
```
if __name__ == "__main__":
    app.run(debug=True)
```
Launching the server makes the automatically generated API available.

