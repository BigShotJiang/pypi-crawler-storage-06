from .commandline.main import main

main()
