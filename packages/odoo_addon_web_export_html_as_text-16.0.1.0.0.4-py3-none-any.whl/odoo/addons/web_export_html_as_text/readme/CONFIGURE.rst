To export HTML fields as plain text:

- Open any list view.
- Select the records, then click Export under the Action menu.
- Enable "Export HTML as text" in the export dialog.

Note: This setting will apply to all HTML fields exported in the current export dialog.
