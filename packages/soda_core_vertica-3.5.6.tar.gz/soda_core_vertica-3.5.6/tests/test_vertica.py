def test_vertica():
    pass
