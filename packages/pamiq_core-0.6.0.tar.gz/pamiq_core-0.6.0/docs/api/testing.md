::: pamiq_core.testing.connect_components
::: pamiq_core.testing.ConnectedComponents
::: pamiq_core.testing.create_mock_models
::: pamiq_core.testing.create_mock_buffer
