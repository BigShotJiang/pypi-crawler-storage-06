::: pamiq_core.console.WebApiServer
::: pamiq_core.console.WebApiClient
::: pamiq_core.console.SystemStatus
::: pamiq_core.console.Console
