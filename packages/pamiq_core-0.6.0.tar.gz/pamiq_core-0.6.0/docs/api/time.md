::: pamiq_core.time
