::: pamiq_core.launcher.LaunchConfig
::: pamiq_core.launcher.launch
