::: pamiq_core.model.InferenceModel
::: pamiq_core.model.TrainingModel
