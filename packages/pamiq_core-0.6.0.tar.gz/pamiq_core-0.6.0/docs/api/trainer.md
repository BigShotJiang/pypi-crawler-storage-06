::: pamiq_core.trainer.Trainer
