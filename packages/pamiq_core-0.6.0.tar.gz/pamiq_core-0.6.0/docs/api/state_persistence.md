::: pamiq_core.state_persistence.PersistentStateMixin
::: pamiq_core.state_persistence.StateStore
::: pamiq_core.state_persistence.PeriodicSaveCondition
::: pamiq_core.state_persistence.StatesKeeper
::: pamiq_core.state_persistence.LatestStatesKeeper
