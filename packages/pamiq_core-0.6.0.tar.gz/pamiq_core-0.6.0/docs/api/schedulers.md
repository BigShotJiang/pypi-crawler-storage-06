::: pamiq_core.utils.schedulers.Scheduler
::: pamiq_core.utils.schedulers.TimeIntervalScheduler
::: pamiq_core.utils.schedulers.StepIntervalScheduler
