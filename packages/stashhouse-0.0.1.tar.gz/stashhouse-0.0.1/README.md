🏠 stashhouse
=============

stashhouse is a framework for centrally collecting files to enable rapid file transfers. The framework is designed with 
a plugin system to enable the inclusion of additional file transfer protocols while working to minimize the overhead 
required for file transfers.