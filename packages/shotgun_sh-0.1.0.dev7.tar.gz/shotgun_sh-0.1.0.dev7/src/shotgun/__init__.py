"""Shotgun CLI package."""

__version__ = "0.1.0.dev2"
