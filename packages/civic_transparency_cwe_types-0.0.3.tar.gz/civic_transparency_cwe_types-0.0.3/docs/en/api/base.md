# Base Types

::: ci.transparency.cwe.types.base_result
::: ci.transparency.cwe.types.base_result_loading
::: ci.transparency.cwe.types.base_result_validation
    options:
      show_source: false
      show_signature: true
      group_by_category: true
      filters:
        - "!^_"
