# Standards Types

::: ci.transparency.cwe.types.standards_error_format
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.standards_error_loading
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.standards_error_validation
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.standards_error_validation_mapping
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.standards_result_analysis_mapping
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.standards_result_extraction
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.standards_result_loading
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.standards_result_validation
    options:
      show_root_heading: true
      show_source: false
