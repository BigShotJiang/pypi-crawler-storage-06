# CWE Types

::: ci.transparency.cwe.types.cwe_error_loading
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.cwe_error_validation
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.cwe_result_loading
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.cwe_result_validation
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.cwe_result_validation_relationship
    options:
      show_root_heading: true
      show_source: false
