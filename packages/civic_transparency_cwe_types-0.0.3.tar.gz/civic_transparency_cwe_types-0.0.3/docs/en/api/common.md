# Common Types

::: ci.transparency.cwe.types.common_result_loading_batch
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.common_result_validation_multiphase
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.common_result_validation_phase
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.common_result_validation_phase
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.common_result_validation_multiphase
    options:
      show_root_heading: true
      show_source: false
