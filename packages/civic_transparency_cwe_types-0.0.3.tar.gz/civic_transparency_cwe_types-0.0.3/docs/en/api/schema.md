# Schema Types

::: ci.transparency.cwe.types.schema_error_freeze
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.schema_error_loading
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.schema_error_validation
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.schema_result_loading
    options:
      show_root_heading: true
      show_source: false

::: ci.transparency.cwe.types.schema_result_validation
    options:
      show_root_heading: true
      show_source: false
