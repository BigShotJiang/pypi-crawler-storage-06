"""Civic Transparency CWE types package."""
