"""Civic Transparency CWE package."""
