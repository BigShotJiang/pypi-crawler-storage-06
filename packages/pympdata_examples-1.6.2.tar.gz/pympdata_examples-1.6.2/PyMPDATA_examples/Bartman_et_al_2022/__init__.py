"""
This example is based on the paper:
[Bartman et al. 2022](https://doi.org/10.21105/joss.03896).

fig_X.ipynb:
.. include:: ./fig_X.ipynb.badges.md
"""
