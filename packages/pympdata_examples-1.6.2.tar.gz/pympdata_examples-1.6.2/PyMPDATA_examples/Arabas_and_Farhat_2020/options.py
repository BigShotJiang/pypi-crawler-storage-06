OPTIONS = {
    "n_iters": 2,
    "infinite_gauge": True,
    "nonoscillatory": True,
    "divergent_flow": True,
    "third_order_terms": True,
    "non_zero_mu_coeff": True,
}
