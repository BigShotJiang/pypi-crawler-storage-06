from ._version import __version__
from .core import PPCA  # noqa: F401

__all__ = ["PPCA", "__version__"]
