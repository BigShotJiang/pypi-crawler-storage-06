## Create a service

First you need to be registred on 'Postfinance eBill service
\<<https://www.postfinance.ch/en/business/products/accounts-receivable-solutions/e-bill-invoice-issuer.html>\>'
To create a service go to Accounting - Configuration - Payments -
Postfinance eBill Service

## Configure a customer and create his contract

The contracts specific to Postfinance e-billing are located in
Accounting - Customers - eBill Postfinance Contract Create a contract
for a customer with his PayerId and make sure that the contract is
active by being in Open state with valid start/end dates.

Set Customer Invoice Transmission Method on the customer to Postfinance.
