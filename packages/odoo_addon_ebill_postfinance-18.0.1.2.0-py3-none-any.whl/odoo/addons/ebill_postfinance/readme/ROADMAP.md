ToDo

- Add option to import the contract subscription (csv)
- Add the download of this csv from web service, but what is the
  endpoint ?

Nice to have

- Add a link to the failed job in the chatter message.
- Add an action on partner to create a ebilling contract.
