from . import std, subpar
from .document import Document

__all__ = ['std', 'subpar', 'Document']
