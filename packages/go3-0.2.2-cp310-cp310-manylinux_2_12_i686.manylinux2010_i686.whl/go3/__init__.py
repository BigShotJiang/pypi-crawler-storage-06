from .go3 import *

__doc__ = go3.__doc__
if hasattr(go3, "__all__"):
    __all__ = go3.__all__