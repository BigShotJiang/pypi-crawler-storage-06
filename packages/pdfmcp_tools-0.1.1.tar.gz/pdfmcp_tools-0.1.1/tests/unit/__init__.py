"""Unit tests for PDF Reader MCP server."""
