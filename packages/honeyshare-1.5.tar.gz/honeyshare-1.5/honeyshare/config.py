import os


HOSTNAME = "honeyshare.live"
API_BASE = "honey"
HEADER = "HoneyShare-Key"

KEY = os.getenv("HONEYSHARE_KEY")
