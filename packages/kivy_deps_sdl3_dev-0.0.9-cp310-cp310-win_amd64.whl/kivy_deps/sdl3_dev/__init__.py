
"""The following code is required to make the dependency binaries available to
kivy when it imports this package.
"""
__version__ = '0.0.9'

