"""Config parsing for RDMC"""
