# hangman_ashraf

لعبة الرجل المشنوق (Hangman) بسيطة مكتوبة بالبايثون وباللغة العربية.

التشغيل محلياً:
- python -m hangman_ashraf

بعد التثبيت:
- hangman-ashraf

المؤلف: أشرف عبدالملك
