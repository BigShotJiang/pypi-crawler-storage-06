"""
MAICA Illuminator (Backend) library.
Always call init() before actually using!
"""
from .maica_starter import check_params as init





