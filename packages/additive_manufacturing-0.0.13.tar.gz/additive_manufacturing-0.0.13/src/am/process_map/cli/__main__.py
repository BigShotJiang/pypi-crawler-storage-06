import typer

app = typer.Typer(
    name="Process Map",
    help="Process Map Management",
    add_completion=False,
    no_args_is_help=True,
)

