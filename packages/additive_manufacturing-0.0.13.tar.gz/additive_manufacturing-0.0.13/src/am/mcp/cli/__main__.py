import typer

app = typer.Typer(
    name = "mcp",
    help = "Model Context Protocol (MCP) Managment",
    add_completion = False,
    no_args_is_help = True,
)

