from feeluown.consts import DATA_DIR


COOKIES_FILE = DATA_DIR + '/qqmusic_cookies.json'
USER_PW_FILE = DATA_DIR + '/qm_user_pw.json'
USERS_INFO_FILE = DATA_DIR + '/qm_users_info.json'
