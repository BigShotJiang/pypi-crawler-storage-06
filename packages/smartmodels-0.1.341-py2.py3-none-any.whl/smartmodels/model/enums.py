from syncmodels.model import Enum
