To configure this module, you need to:

- Create or edit your categories to set skills
- Create or edit your workers to set their skills and skill levels
- Create or edit your territories to set their field service workers
- Create or edit your locations to set their territories
