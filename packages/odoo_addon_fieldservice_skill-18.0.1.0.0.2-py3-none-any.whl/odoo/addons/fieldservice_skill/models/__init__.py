# Copyright (C) 2018, Open Source Integrators
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import fsm_person_skill
from . import fsm_person
from . import fsm_category
from . import fsm_order
from . import fsm_template
from . import hr_skill
