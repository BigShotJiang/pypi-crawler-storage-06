INTERVAL_VERSION = "0"


def is_internal_enabled():
    return int(INTERVAL_VERSION)
