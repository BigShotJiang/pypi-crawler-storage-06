INTERVAL_VERSION = "__RECIS_INTERNAL_VERSION__"


def is_internal_enabled():
    return int(INTERVAL_VERSION)
