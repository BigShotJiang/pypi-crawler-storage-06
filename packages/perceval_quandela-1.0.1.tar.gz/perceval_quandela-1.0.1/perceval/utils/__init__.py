# MIT License
#
# Copyright (c) 2022 Quandela
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# As a special exception, the copyright holders of exqalibur library give you
# permission to combine exqalibur with code included in the standard release of
# Perceval under the MIT license (or modified versions of such code). You may
# copy and distribute such a combined system following the terms of the MIT
# license for both exqalibur and Perceval. This exception for the usage of
# exqalibur is limited to the python bindings used by Perceval.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from .matrix import Matrix, MatrixN, MatrixS, matrix_double
from .format import simple_float, simple_complex, format_parameters
from .parameter import Parameter, P, Expression, E
from .mlstr import mlstr
from .states import BasicState, FockState, NoisyFockState, AnnotatedFockState, Annotation, StateVector, SVDistribution,\
    BSDistribution, BSCount, BSSamples, allstate_array, allstate_iterator, anonymize_annotations,\
    max_photon_state_iterator, filter_distribution_photon_count
from .logical_state import LogicalState, generate_all_logical_states
from .polarization import Polarization, convert_polarized_state, build_spatial_output_states
from .postselect import PostSelect, post_select_distribution, post_select_statevector
from ._random import random_seed
from .globals import global_params
from .conversion import samples_to_sample_count, samples_to_probs, sample_count_to_samples, sample_count_to_probs,\
    probs_to_samples, probs_to_sample_count
from .stategenerator import StateGenerator
from ._enums import Encoding, InterferometerShape, FileFormat, ModeType
from .persistent_data import PersistentData
from .metadata import PMetadata
from .density_matrix import DensityMatrix
from .noise_model import NoiseModel
from .logging import get_logger, use_perceval_logger, use_python_logger, LoggerConfig, deprecated
from .progress_cb import partial_progress_callable
from .dist_metrics import tvd_dist, kl_divergence
