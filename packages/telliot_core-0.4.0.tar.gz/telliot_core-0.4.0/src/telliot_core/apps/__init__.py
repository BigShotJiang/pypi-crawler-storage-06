"""telliot_core.apps module"""
