"""
"""
from clamfig import Serializable


class Base(Serializable):
    """Project-wide serializable model"""

    pass
