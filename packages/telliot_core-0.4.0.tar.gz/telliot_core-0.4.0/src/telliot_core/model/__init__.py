"""telliot_core.model"""
