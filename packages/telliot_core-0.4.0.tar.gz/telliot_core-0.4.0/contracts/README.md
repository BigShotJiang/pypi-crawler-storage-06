These contracts are deployed to a local Ganache blockchain using eth-brownie, then accessed in tests.
