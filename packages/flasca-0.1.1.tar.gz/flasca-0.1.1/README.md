# Flasca

Flask scaffolder

## Components:

- package manager: uv
