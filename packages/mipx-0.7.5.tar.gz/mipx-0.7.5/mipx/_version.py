#         .__
#   _____ |__|________  ___
#  /     \|  \____ \  \/  /
# |  Y Y  \  |  |_> >    <
# |__|_|  /__|   __/__/\_ \
#       \/   |__|        \/
__title__ = "mipx"
__description__ = "Python (Mixed-Integer Linear Programming Constraint Programming) Optimization Tools"
__version__ = "0.7.5"
__author__ = "luyi"
__author_email__ = "2662017230@qq.com"

__copyright__ = "Copyright 2024 luyi"
