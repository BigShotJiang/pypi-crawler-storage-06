```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 1

notebooks/getting-started

api.md

notebooks/concatenation

notebooks/alignment

changelog.md
contributing.md
references.md
```
