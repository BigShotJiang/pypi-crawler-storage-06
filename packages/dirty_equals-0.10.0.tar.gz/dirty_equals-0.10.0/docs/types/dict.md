# Dictionary Types

::: dirty_equals.IsDict

::: dirty_equals.IsPartialDict

::: dirty_equals.IsIgnoreDict

::: dirty_equals.IsStrictDict
