# Boolean Types

::: dirty_equals.IsTrueLike

::: dirty_equals.IsFalseLike
