# Other Types

::: dirty_equals.FunctionCheck

::: dirty_equals.IsInstance

::: dirty_equals.IsJson

::: dirty_equals.IsUUID

::: dirty_equals.AnyThing

::: dirty_equals.IsOneOf

::: dirty_equals.IsUrl

::: dirty_equals.IsHash

::: dirty_equals.IsIP

::: dirty_equals.IsDataclassType

::: dirty_equals.IsDataclass

::: dirty_equals.IsPartialDataclass

::: dirty_equals.IsStrictDataclass

::: dirty_equals.IsEnum
