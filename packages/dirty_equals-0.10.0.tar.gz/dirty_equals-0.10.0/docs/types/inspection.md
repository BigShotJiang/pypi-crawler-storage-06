# Type Inspection

::: dirty_equals.IsInstance

::: dirty_equals.HasName

::: dirty_equals.HasRepr

::: dirty_equals.HasAttributes
