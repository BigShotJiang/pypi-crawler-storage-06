This module allows to define mail settings for events. By default the
emails scheduler has been deactivated. You can create mail scheduler
templates for events and select one by default in event settings.
