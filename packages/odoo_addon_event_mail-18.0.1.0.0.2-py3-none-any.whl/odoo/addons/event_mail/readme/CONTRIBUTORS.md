- [Tecnativa](https://www.tecnativa.com):

  > - Sergio Teruel
  > - David Vidal
  > - Ernesto Tejeda
  > - Stefan Ungureanu
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia
