To use this module, you need to:

1.  Go to *Events \> Configuration \> Mail Templates* and create all
    templates that you need.
2.  Go to *Events \> Settings* and select the default template in
    "Template Mail Scheduler" field.
3.  Go to *Events \> Events* and create one. All mails schedulers has
    been created. Also you can select other template in "Mail Template
    Scheduler" field on "Communication" tab.
