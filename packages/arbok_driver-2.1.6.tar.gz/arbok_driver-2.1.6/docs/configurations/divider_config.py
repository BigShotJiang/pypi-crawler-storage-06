
divider_config = {
    'gate_1': {
        'division': 1,
    },
    'gate_2': {
        'division': 2,
    },
    'gate_2': {
        'division': 2.5,
    },
    'readout_element': {
        'division': 1
    }
}
