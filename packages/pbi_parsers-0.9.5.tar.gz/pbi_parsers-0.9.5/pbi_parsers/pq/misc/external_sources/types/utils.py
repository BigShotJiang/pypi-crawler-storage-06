PATHLIKE_FUNCTIONS = {"AzureStorage.BlobContents", "File.Contents", "Web.Contents"}
