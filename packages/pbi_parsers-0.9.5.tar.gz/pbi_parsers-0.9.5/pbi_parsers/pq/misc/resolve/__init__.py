from .resolve import resolve_references

__all__ = ["resolve_references"]
