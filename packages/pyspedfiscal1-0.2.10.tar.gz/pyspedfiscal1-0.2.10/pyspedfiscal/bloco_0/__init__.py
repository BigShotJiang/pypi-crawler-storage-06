from .core import Bloco0

__all__ = ['Bloco0']
