CHANGELOG
=========

1.0.0a12 (unreleased)
---------------------

- Getting result from self.attribute_users in the validate users.
  [nilbacardit26]


1.0.0a11 (2021-01-15)
---------------------

- Fixing Cache bug
  [bloodbare]


1.0.0a10 (2021-01-15)
---------------------

- Allow testing import.
  [bloodbare]


1.0.0a9 (2020-11-27)
--------------------

- Fixing bug on upgrade.
  [bloodbare]


1.0.0a8 (2020-11-27)
--------------------

- Support for Name storage.
  [bloodbare]


1.0.0a7 (2020-11-24)
--------------------

- Fixing reset password API.
  [bloodbare]


1.0.0a6 (2020-11-18)
--------------------

- Fixing login LDAP search API.
  [bloodbare]


1.0.0a5 (2020-11-18)
--------------------

- Allowing settings password on 2nd phase
  [bloodbare]


1.0.0a4 (2020-11-16)
--------------------

- Fix LDAP Auth.
  [bloodbare]


1.0.0a3 (2020-11-15)
--------------------

- Fix LDAP Search.
  [bloodbare]


1.0.0a2 (2020-11-11)
--------------------

- Nothing changed yet.


1.0.0a1 (2020-11-08)
--------------------

- Initial commit
  [bloodbare]
