pytest_plugins = [
    'pytest_docker_fixtures',
    'guillotina.tests.fixtures',
    'guillotina_ldap.tests.fixtures',
]