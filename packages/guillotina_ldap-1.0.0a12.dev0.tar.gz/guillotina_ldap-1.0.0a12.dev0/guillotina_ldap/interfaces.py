from guillotina.async_util import IAsyncUtility

class ILDAPUsers(IAsyncUtility):
    pass