# Hyperflask Users

Authentication and user management for Hyperflask

[Read documentation](https://hyperflask.dev/guides/users)

## Status

This extensions is still work in progress.

The following is missing:

- SSO logins
- Email validation
