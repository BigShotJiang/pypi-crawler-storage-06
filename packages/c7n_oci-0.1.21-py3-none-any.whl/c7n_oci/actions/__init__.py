# Copyright The Cloud Custodian Authors.
# SPDX-License-Identifier: Apache-2.0

# Base Action file which has the implementation related to OCI functionality
from .base import OCIBaseAction
