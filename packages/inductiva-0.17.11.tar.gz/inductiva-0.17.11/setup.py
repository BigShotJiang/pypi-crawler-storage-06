"""Setup file."""
from setuptools import setup

setup()
