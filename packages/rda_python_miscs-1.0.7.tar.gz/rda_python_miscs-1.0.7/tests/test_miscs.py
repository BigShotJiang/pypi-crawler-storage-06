# test_miscs.py

import pytest

def test_miscs():
   pass
