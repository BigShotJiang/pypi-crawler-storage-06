"""FastAPI server for Docler document conversion library."""

__version__ = "0.1.0"
