"""AI Chunker."""

from docler.chunkers.ai_chunker.chunker import AIChunker

__all__ = ["AIChunker"]
