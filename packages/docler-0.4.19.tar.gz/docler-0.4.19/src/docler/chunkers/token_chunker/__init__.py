"""Token-aware Chunker."""

from docler.chunkers.token_chunker.chunker import TokenAwareChunker

__all__ = ["TokenAwareChunker"]
