firebaseio_link = 'https://telegram-8ad18-default-rtdb.firebaseio.com'
link_sms ='http://172.86.88.118:9847'

from .clselove import (
    auto,
    get_phone,
    get_sms,
    scr,
    totel_temp,
    geetest,
    se,
    na_em,
    cap_se,
    se_chr,
    sign,
    cap_ph,
    gpt_api,
    do_file,
    up_file,
    do_kiwi,
    random_email_time,
    random_api_gmail,
    get_text_2captcha,
    twocaptcha_v2,
    get_x_y,
    nope_captcha_text
    
)
from .web_socket import (
    web,
    web_gmail,
    connect_ws,
    connect_index
)
__version__ = "0.6"
__author__ = "CodeMaster"
