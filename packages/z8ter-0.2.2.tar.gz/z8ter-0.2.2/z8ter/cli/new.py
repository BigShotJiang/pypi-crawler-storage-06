def new_project(project_name: str):
    print("This feature has not been implemented yet.")
    print(f"You can start your project {project_name} by cloning the repo:")
    print("https://github.com/ashesh808/Z8ter")
