class PolyswarmArtifactException(Exception):
    pass


class DecodeError(PolyswarmArtifactException):
    pass
