REQUIRED_ASSETS = {
    'appLauncherIcon' : 'launcher_icon.svg',
    #'appLauncherBackground' : 'launcher_background.svg',
    'appSplashscreen' : 'splashscreen.svg',
}