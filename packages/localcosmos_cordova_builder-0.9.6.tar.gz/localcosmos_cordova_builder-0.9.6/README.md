# localcosmos-cordova-builder
required environment variable: LOCALCOSMOS_CORDOVA_BUILDER_WORKDIR

## using python3 virtualenv

add

export LOCALCOSMOS_CORDOVA_BUILDER_WORKDIR=/path/to/workdir

to venv/bin/activate
