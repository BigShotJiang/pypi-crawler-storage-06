from ..LaiaBaseModel.LaiaBaseModel import LaiaBaseModel

class Role(LaiaBaseModel):
    name: str
