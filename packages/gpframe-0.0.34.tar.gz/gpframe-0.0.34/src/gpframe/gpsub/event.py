from gpframe.contracts.protocols import gpsub as _gpsub

Context = _gpsub.event.Context
