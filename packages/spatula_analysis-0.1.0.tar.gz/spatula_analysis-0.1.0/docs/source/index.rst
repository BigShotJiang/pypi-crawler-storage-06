================================
Welcome to spatula documentation
================================

.. include:: ../../readme.rst

Table of Contents
=================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   installation
   theory
   tutorials
   api
   contributing
   credits
   changelog
   citing
   references

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
