API
---

.. rubric:: Overview

.. py:currentmodule:: spatula

.. autosummary::
    :nosignatures:

    BOOSOP
    PGOP

.. rubric:: Details

.. automodule:: spatula
    :members: PGOP, BOOSOP

.. rubric:: Modules

.. toctree::
   :maxdepth: 1

   module-optimize
   module-util
