==========
References
==========

.. It's necessary to have a file that creates the bibliography that is
   processed by Sphinx AFTER all of the :cite: commands have been parsed. To
   fix this, we create this dummy file that comes as late as possible and
   import the bibliography here.

.. bibliography:: ref.bib
