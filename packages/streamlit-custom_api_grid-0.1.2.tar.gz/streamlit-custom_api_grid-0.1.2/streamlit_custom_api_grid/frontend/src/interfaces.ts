export interface IOlympicData {
  honey: string;
  $honey: number;
  Symbol: string;
}