AutoTestHeartbeatMaxMissedSetting
=================================

.. currentmodule:: codegrade.models.auto_test_heartbeat_max_missed_setting

.. autoclass:: AutoTestHeartbeatMaxMissedSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
