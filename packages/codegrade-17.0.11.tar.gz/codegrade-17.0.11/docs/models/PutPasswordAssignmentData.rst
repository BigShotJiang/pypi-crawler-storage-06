PutPasswordAssignmentData
=========================

.. currentmodule:: codegrade.models.put_password_assignment_data

.. autoclass:: PutPasswordAssignmentData
   :members: password
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
