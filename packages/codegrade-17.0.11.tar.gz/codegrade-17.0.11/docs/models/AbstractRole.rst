AbstractRole
============

.. currentmodule:: codegrade.models.abstract_role

.. autoclass:: AbstractRole
   :members: id, name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
