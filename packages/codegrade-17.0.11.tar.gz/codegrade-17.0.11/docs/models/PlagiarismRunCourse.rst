PlagiarismRunCourse
===================

.. currentmodule:: codegrade.models.plagiarism_run_course

.. autoclass:: PlagiarismRunCourse
   :members: id, name, virtual, created_at
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
