IOTestStepLog
=============

.. currentmodule:: codegrade.models.io_test_step_log

.. autoclass:: IOTestStepLog
   :members: stdout, stderr, exit_code, time_spend, started_at, achieved_points
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
