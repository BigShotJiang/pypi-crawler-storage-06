AssignmentTimeframes
====================

.. currentmodule:: codegrade.models.assignment_timeframes

.. autoclass:: AssignmentTimeframes
   :members: general, sections
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
