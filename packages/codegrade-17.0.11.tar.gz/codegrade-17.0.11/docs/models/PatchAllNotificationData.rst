PatchAllNotificationData
========================

.. currentmodule:: codegrade.models.patch_all_notification_data

.. autoclass:: PatchAllNotificationData
   :members: notifications
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
