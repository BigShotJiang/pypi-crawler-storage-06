CreateAutoTestData
==================

.. currentmodule:: codegrade.models.create_auto_test_data

.. autoclass:: CreateAutoTestData
   :members: json, fixture
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
