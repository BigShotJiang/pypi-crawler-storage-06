CreateInlineCommentData
=======================

.. currentmodule:: codegrade.models.create_comment_data

.. autoclass:: CreateInlineCommentData
   :members: file_id, line
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
