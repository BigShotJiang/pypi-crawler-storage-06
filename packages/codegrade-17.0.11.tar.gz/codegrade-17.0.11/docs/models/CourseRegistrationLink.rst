CourseRegistrationLink
======================

.. currentmodule:: codegrade.models.course_registration_link

.. autoclass:: CourseRegistrationLink
   :members: id, expiration_date, role, allow_register
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
