AssignmentRestrictionSetPassword
================================

.. currentmodule:: codegrade.models.assignment_restriction_set_password

.. autoclass:: AssignmentRestrictionSetPassword
   :members: tag
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
