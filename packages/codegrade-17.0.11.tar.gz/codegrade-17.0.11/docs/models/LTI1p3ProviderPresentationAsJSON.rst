LTI1p3ProviderPresentationAsJSON
================================

.. currentmodule:: codegrade.models.lti1p3_provider_presentation_as_json

.. autoclass:: LTI1p3ProviderPresentationAsJSON
   :members: preferred_frame_height
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
