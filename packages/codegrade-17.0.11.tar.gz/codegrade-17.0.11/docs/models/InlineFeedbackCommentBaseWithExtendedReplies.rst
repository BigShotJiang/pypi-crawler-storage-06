InlineFeedbackCommentBaseWithExtendedReplies
============================================

.. currentmodule:: codegrade.models.inline_feedback_comment_base_with_extended_replies

.. autoclass:: InlineFeedbackCommentBaseWithExtendedReplies
   :members: 
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
