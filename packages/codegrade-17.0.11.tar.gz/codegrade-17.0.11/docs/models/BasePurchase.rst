BasePurchase
============

.. currentmodule:: codegrade.models.base_purchase

.. autoclass:: BasePurchase
   :members: id, state, success_at, updated_at, short_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
