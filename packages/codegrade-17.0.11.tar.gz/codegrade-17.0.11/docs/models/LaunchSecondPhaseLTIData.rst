LaunchSecondPhaseLTIData
========================

.. currentmodule:: codegrade.models.launch_second_phase_lti_data

.. autoclass:: LaunchSecondPhaseLTIData
   :members: blob_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
