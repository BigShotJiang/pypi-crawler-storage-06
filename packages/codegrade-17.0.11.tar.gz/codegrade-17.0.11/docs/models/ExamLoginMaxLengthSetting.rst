ExamLoginMaxLengthSetting
=========================

.. currentmodule:: codegrade.models.exam_login_max_length_setting

.. autoclass:: ExamLoginMaxLengthSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
