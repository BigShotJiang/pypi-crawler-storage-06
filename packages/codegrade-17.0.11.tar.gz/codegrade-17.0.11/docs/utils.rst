CodeGrade Utils
===============


.. currentmodule:: codegrade.utils

.. _codegrade-utils-maybe-input:
.. autofunction:: codegrade.utils.maybe_input

.. _codegrade-utils-select-from-list:
.. autofunction:: codegrade.utils.select_from_list

.. _codegrade-utils-value-or-exit:
.. autofunction:: codegrade.utils.value_or_exit
