#!/usr/bin/env python3

from . extract import run

if __name__ == '__main__':
    run()

