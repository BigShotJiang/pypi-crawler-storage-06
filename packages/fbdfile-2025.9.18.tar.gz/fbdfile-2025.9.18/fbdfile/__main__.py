# fbdfile/__main__.py

"""Fbdfile package command line script."""

import sys

from .fbdfile import main

sys.exit(main())
