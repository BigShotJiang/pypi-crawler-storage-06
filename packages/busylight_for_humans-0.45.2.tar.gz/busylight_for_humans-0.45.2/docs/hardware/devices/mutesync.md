![Busylight Project Logo][1]

## MuteSync MuteSync

### Physical Description

#### MuteSync

### USB Device Info

### Device Operation

### Command Format

#### Turning the Light On

#### Turning the Light Off

### Observations


[0]: mutesync url
[1]: ../assets/Unstacked-Logo-Light.png
[S]: pyserial project url
