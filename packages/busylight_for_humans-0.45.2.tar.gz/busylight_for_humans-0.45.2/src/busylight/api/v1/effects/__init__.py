"""Effects API Module"""
