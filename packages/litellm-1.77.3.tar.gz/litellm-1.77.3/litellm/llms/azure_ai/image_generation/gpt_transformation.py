from litellm.llms.openai.image_generation import GPTImageGenerationConfig


class AzureFoundryGPTImageGenerationConfig(GPTImageGenerationConfig):
    """
    Azure gpt-image-1 image generation config
    """

    pass
