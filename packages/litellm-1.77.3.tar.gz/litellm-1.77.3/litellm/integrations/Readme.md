# Integrations

This folder contains logging integrations for litellm

eg. logging to Datadog, Langfuse, Prometheus, s3, GCS Bucket, etc.