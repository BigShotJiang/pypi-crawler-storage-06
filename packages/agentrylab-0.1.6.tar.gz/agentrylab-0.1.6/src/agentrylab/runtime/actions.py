from __future__ import annotations

"""Action constants used by moderator nodes and the engine."""

CONTINUE = "CONTINUE"
STOP = "STOP"
STEP_BACK = "STEP_BACK"

