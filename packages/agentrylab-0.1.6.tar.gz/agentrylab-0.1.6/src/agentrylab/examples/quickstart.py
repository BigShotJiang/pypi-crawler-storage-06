# Quickstart example
# init_lab("presets/debates.yaml").start(max_iters=3)
