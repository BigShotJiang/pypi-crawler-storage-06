from enum import Enum


class Zone(Enum):
    """Geographic cluster location"""

    EU = "EU"
    US = "US"
