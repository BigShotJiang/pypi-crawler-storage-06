import argparse

# CLI парсер утилиты