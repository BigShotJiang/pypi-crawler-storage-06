"""Stripe integration app."""
