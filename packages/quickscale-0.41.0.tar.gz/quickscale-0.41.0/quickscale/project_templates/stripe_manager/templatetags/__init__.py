"""Template tags for Stripe integration."""

# Template tag initialization
