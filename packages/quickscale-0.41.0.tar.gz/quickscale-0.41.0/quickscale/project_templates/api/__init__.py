"""API application for QuickScale AI services."""
