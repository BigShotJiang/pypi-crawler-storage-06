"""Initial migration for public app."""
from typing import List

from django.db import migrations


class Migration(migrations.Migration):
    """Initial empty migration."""

    initial = True

    dependencies: List[str] = [
    ]

    operations: List = [
    ]
