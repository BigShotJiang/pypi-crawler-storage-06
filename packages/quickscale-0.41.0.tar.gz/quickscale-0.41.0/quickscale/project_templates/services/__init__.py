"""Services app for managing AI service integrations."""
