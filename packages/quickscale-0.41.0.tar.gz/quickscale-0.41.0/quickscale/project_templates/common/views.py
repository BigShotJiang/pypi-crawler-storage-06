"""Common views shared across multiple apps."""

# Add views below that are used by multiple apps
