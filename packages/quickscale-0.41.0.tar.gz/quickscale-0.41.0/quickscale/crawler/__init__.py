"""Webscraper module for crawling QuickScale applications with login capabilities."""
