"""Configuration management for QuickScale."""
