#define HTS_VERSION_TEXT "1.21-34-gb14fffb4"
