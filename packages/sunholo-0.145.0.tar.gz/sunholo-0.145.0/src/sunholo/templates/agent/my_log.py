from sunholo.custom_logging import setup_logging

log = setup_logging("sunholo")
