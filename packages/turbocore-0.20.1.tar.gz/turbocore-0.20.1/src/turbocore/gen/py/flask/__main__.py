from turbocore.gen.py.flask import main


if __name__ == "__main__":
    main()
