This module allows having different product variant names than the name
of their template.
