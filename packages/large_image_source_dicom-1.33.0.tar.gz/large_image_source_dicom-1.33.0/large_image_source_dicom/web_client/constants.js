import { AssetstoreType } from '@girder/core/constants';

AssetstoreType.DICOMWEB = 'dicomweb';
