"""Docsmaker - A modular Python package for generating static documentation sites from Markdown files."""

__version__ = "0.1.0"
__author__ = "Othmane BLIAL"
__description__ = "Generate static documentation sites from Markdown files with theming and plugins."