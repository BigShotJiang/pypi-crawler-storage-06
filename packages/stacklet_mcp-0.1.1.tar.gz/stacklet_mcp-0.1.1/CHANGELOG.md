## 0.1.1 - 2025-09-23

- Add `README.md` to `pyproject.toml` metadata.

## 0.1.0 - 2025-09-23

- First release.
- Provide AssetDB tools for managing and running SQL queries (both saved and ad-hoc).
- Provide Platform tools for interacting with the GraphQL API.
- Provide tools for accessing the official documentation.
