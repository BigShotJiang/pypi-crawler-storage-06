# LICENSE HEADER MANAGED BY add-license-header
#
# Copyright (c) 2025 Stacklet, Inc.
#

"""Entry point for running the server from the package."""

from .mcp import main


main()
