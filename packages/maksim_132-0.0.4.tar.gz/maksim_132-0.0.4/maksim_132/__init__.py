from .main import Maksim132

# Создаем экземпляр класса с именем maksim_132
maksim_132 = Maksim132()