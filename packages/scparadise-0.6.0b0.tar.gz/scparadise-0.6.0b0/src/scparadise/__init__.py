from scparadise import scadam, sceve, scnoah

__version__ = "0.6.0_beta"