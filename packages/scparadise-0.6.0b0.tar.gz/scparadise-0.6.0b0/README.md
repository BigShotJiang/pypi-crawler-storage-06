# scParadize
Tunable highly accurate multi-class cell type annotation and surface protein abundance prediction in single cell RNA-seq data.
