"""Version information for Doctra."""
__version__ = '0.4.0'
