EXCLUDE_LABELS = {"figure", "chart", "table"}

# Where to store cropped images, per label
IMAGE_SUBDIRS = {
    "figure": "figures",
    "chart":  "charts",
    "table":  "tables",
}