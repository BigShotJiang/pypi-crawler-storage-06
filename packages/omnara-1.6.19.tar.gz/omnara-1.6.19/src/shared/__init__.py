# Shared package initialization
