"""FastAPI server for Agent Dashboard."""
