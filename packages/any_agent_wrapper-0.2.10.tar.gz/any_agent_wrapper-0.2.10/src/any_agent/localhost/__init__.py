"""Localhost development components for Any Agent framework."""
