"""Core framework detection and adaptation logic."""
