"""FastAPI interface and REST API implementations."""
