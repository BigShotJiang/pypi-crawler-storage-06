a = 3
b = "hello"
c = a**2

__all__ = ["b", "c"]
