from . import estados

from .sexo import Sexo
from .estados import Estado

__all__ = [
    "Sexo",
    "Estado",
    "sexo",
    "estados",
]

