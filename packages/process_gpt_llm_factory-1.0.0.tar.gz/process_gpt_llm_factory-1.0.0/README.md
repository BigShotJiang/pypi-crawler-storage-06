# LLM Factory

[![PyPI version](https://badge.fury.io/py/llm-factory.svg)](https://badge.fury.io/py/llm-factory)
[![Python Support](https://img.shields.io/pypi/pyversions/llm-factory.svg)](https://pypi.org/project/llm-factory/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

통합 LLM 팩토리 라이브러리 - 다양한 LLM 제공자를 통합된 인터페이스로 사용할 수 있게 해주는 Python 라이브러리입니다.

## 주요 기능

- **다중 LLM 제공자 지원**: OpenAI, Azure OpenAI, Anthropic, Ollama
- **환경변수 기반 설정**: 코드 변경 없이 LLM 제공자 변경 가능
- **일관된 API**: 모든 제공자에 대해 동일한 인터페이스 제공
- **유연한 설정**: 모델명, 온도, 스트리밍 등 다양한 옵션 지원
- **Embedding 지원**: 텍스트 임베딩 생성 기능 포함

## 설치

```bash
pip install llm-factory
```

## 빠른 시작

### 1. 환경변수 설정

`.env` 파일에 다음 환경변수들을 설정하세요:

```bash
# LLM Provider 설정 (필수)
LLM_PROVIDER=openai  # openai, azure, anthropic, ollama 중 선택

# OpenAI 설정
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_MODEL=gpt-4o

# Azure OpenAI 설정
AZURE_API_KEY=your_azure_api_key_here
AZURE_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_DEPLOYMENT=your_deployment_name
AZURE_MODEL=gpt-4o
AZURE_API_VERSION=2024-06-01-preview

# Anthropic 설정
ANTHROPIC_API_KEY=your_anthropic_api_key_here
ANTHROPIC_MODEL=claude-3-sonnet-20240229

# Ollama 설정
OLLAMA_MODEL=llama3
OLLAMA_BASE_URL=http://localhost:11434
```

### 2. 기본 사용법

```python
from llm_factory import create_llm, create_embedding

# 환경변수에 설정된 제공자와 모델 사용
llm = create_llm()

# 특정 제공자 지정
llm = create_llm(provider="openai")

# 특정 모델과 옵션 지정
llm = create_llm(
    model="gpt-4o",
    temperature=0.7,
    streaming=True
)

# Embedding 생성
embedding = create_embedding()
```

### 3. LangChain과 함께 사용

```python
from llm_factory import create_llm, create_embedding
from langchain.prompts import PromptTemplate
from langchain.schema.output_parser import StrOutputParser

# LLM 생성
llm = create_llm()

# Embedding 생성
embedding = create_embedding()

# 프롬프트 템플릿 생성
prompt = PromptTemplate.from_template("다음 텍스트를 요약해주세요: {text}")

# 체인 생성
chain = prompt | llm | StrOutputParser()

# 실행
result = chain.invoke({"text": "긴 텍스트 내용..."})

# Embedding 사용
embedding_vector = await embedding.aembed_query("텍스트 내용")
```

## 지원되는 LLM 제공자

### 1. OpenAI
- **모델**: gpt-4o, gpt-4o-mini, gpt-3.5-turbo 등
- **필수 환경변수**: `OPENAI_API_KEY`
- **선택적 환경변수**: `OPENAI_MODEL`

### 2. Azure OpenAI
- **모델**: gpt-4o, gpt-4o-mini, gpt-3.5-turbo 등
- **필수 환경변수**: `AZURE_API_KEY`, `AZURE_ENDPOINT`, `AZURE_DEPLOYMENT`
- **선택적 환경변수**: `AZURE_MODEL`, `AZURE_API_VERSION`

### 3. Anthropic
- **모델**: claude-3-sonnet-20240229, claude-3-haiku-20240307 등
- **필수 환경변수**: `ANTHROPIC_API_KEY`
- **선택적 환경변수**: `ANTHROPIC_MODEL`

### 4. Ollama
- **모델**: llama3, llama2, mistral 등
- **필수 환경변수**: 없음 (기본값 사용)
- **선택적 환경변수**: `OLLAMA_MODEL`, `OLLAMA_BASE_URL`

## API 참조

### LLM 생성 함수

```python
from llm_factory import (
    create_llm,
    create_openai_llm,
    create_azure_llm,
    create_anthropic_llm,
    create_ollama_llm
)

# 기본 LLM 생성 (환경변수 기반)
llm = create_llm()

# 특정 제공자 LLM 생성
openai_llm = create_openai_llm(model="gpt-4o", temperature=0.5)
azure_llm = create_azure_llm(model="gpt-4o")
anthropic_llm = create_anthropic_llm(model="claude-3-sonnet-20240229")
ollama_llm = create_ollama_llm(model="llama3")
```

### Embedding 생성 함수

```python
from llm_factory import (
    create_embedding,
    create_openai_embedding,
    create_azure_embedding
)

# 기본 Embedding 생성 (환경변수 기반)
embedding = create_embedding()

# 특정 제공자 Embedding 생성
openai_embedding = create_openai_embedding(model="text-embedding-3-large")
azure_embedding = create_azure_embedding(model="text-embedding-3-large")
```

## 마이그레이션 가이드

기존 코드에서 직접 LLM을 생성하던 방식을 LLM Factory로 변경하는 방법:

### Before (기존 방식)
```python
from langchain_openai import ChatOpenAI

model = ChatOpenAI(model="gpt-4o", streaming=True, temperature=0)
```

### After (LLM Factory 사용)
```python
from llm_factory import create_llm

model = create_llm(temperature=0)
```

## 개발 환경 설정

```bash
# 저장소 클론
git clone https://github.com/yourusername/llm-factory.git
cd llm-factory

# 개발 의존성 설치
pip install -e ".[dev]"

# 테스트 실행
pytest

# 코드 포맷팅
black llm_factory/
isort llm_factory/

# 린팅
flake8 llm_factory/
mypy llm_factory/
```

## 기여하기

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 라이선스

이 프로젝트는 MIT 라이선스 하에 배포됩니다. 자세한 내용은 `LICENSE` 파일을 참조하세요.

## 연락처

- 프로젝트 링크: [https://github.com/yourusername/llm-factory](https://github.com/yourusername/llm-factory)
- 이메일: your.email@example.com

## 감사의 말

- [LangChain](https://github.com/langchain-ai/langchain) - 강력한 LLM 프레임워크
- [OpenAI](https://openai.com/) - GPT 모델 제공
- [Anthropic](https://www.anthropic.com/) - Claude 모델 제공
- [Ollama](https://ollama.ai/) - 로컬 LLM 실행 환경
