"""Docker container generation and management."""
