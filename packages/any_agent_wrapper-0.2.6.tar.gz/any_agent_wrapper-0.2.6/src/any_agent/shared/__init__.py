"""Shared modules for Any Agent framework pipelines."""
