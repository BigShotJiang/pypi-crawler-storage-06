"""Entry point for python -m any_agent command."""

from .cli import main

if __name__ == "__main__":
    main()
