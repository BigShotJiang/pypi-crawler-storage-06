This module extends the functionality of batch operations in Odoo to support the direct
creation of batches or waves from batches and to allow you to plan Batches and Waves with a single
click based on the grouping rules defined in the operation type. It also provides smart
buttons to easily access the Waves and Batches linked to the original Batch, improving
traceability and efficiency in warehouse operations.
