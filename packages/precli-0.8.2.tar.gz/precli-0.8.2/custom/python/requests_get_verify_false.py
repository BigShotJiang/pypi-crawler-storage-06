import requests


requests.get("https://localhost", verify=False)
