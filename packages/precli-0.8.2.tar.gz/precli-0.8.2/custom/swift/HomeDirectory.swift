
let path = NSHomeDirectory() + "/.ssh/config"
