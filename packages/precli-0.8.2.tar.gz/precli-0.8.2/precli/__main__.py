#!/usr/bin/env python
# Copyright 2024 Secure Sauce LLC
# SPDX-License-Identifier: BUSL-1.1
from precli.cli import main


main.main()
