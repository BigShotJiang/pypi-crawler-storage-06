---
id: JAV005
title: javax.servlet.http — insecure cookie
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/JAV005
---

::: precli.rules.java.stdlib.javax_servlet_http_insecure_cookie
