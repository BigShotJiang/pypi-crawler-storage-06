---
id: JAV006
title: java.net — insecure cookie
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/JAV006
---

::: precli.rules.java.stdlib.java_net_insecure_cookie
