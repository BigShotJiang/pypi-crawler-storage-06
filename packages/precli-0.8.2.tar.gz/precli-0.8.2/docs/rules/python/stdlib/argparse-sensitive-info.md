---
id: PY027
title: argparse — sensitive info
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY027
---

::: precli.rules.python.stdlib.argparse_sensitive_info
