---
id: PY017
title: ssl — unverified context
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY017
---

::: precli.rules.python.stdlib.ssl_create_unverified_context
