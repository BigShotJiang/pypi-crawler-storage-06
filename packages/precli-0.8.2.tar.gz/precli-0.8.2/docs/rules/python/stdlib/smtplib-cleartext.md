---
id: PY016
title: smtplib — cleartext
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY016
---

::: precli.rules.python.stdlib.smtplib_cleartext
