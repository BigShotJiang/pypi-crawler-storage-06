---
id: PY014
title: poplib — cleartext
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY014
---

::: precli.rules.python.stdlib.poplib_cleartext
