---
id: PY023
title: imaplib — unverified context
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY023
---

::: precli.rules.python.stdlib.imaplib_unverified_context
