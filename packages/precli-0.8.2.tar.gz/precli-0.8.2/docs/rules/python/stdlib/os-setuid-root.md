---
id: PY038
title: os — unnecessary privileges
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY038
---

::: precli.rules.python.stdlib.os_setuid_root
