---
id: PY043
title: poplib — no timeout
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY043
---

::: precli.rules.python.stdlib.poplib_no_timeout
