---
id: PY017
title: ssl — create unverified context
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY017
---

::: precli.rules.python.stdlib.crypt_weak_hash
