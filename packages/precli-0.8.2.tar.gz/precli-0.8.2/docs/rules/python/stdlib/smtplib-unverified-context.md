---
id: PY026
title: smtplib — unverified context
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY026
---

::: precli.rules.python.stdlib.smtplib_unverified_context
