---
id: PY046
title: ssl — no timeout
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY046
---

::: precli.rules.python.stdlib.ssl_no_timeout
