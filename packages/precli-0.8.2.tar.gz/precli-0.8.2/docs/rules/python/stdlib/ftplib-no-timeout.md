---
id: PY045
title: ftplib — no timeout
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY045
---

::: precli.rules.python.stdlib.ftplib_no_timeout
