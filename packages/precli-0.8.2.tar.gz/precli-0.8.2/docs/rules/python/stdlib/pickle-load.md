---
id: PY013
title: pickle — load
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY013
---

::: precli.rules.python.stdlib.pickle_load
