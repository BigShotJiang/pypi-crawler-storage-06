---
id: PY011
title: marshal — load
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY011
---

::: precli.rules.python.stdlib.marshal_load
