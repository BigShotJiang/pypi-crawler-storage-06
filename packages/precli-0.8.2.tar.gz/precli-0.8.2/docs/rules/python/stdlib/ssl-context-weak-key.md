---
id: PY019
title: ssl — weak key
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY019
---

::: precli.rules.python.stdlib.ssl_context_weak_key
