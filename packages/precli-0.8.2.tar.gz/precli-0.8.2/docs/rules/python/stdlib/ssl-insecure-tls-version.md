---
id: PY018
title: ssl — insecure tls version
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY018
---

::: precli.rules.python.stdlib.ssl_insecure_tls_version
