---
id: PY015
title: shelve — open
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/PY015
---

::: precli.rules.python.stdlib.shelve_open
