---
id: GO003
title: crypto — weak key
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/GO003
---

::: precli.rules.go.stdlib.crypto_weak_key
