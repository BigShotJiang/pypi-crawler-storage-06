---
id: GO007
title: net/http — no timeout
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/GO007
---

::: precli.rules.go.stdlib.net_http_no_timeout
