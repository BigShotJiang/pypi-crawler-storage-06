---
id: GO004
title: syscall — unnecessary privileges
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/GO004
---

::: precli.rules.go.stdlib.syscall_setuid_root
