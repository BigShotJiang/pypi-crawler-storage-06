---
id: GO002
title: crypto — weak hash
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/GO002
---

::: precli.rules.go.stdlib.crypto_weak_hash
