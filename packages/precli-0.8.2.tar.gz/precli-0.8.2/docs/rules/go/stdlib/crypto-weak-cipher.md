---
id: GO001
title: crypto — weak cipher
hide_title: true
pagination_prev: null
pagination_next: null
slug: /rules/GO001
---

::: precli.rules.go.stdlib.crypto_weak_cipher
