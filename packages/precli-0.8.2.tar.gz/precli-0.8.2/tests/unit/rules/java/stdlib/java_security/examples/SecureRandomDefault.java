// level: NONE
import java.security.*;


public class SecureRandomDefault {
    public static void main(String[] args) {
        SecureRandom sr = new SecureRandom();
    }
}
