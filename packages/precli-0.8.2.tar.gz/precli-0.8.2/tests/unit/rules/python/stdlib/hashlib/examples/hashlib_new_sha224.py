# level: NONE
import hashlib


hashlib.new("sha224")
