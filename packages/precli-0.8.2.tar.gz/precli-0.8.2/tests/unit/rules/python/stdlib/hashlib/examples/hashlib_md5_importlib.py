# level: ERROR
# start_line: 10
# end_line: 10
# start_column: 8
# end_column: 11
import importlib


hashlib = importlib.import_module("hashlib")
hashlib.md5()
