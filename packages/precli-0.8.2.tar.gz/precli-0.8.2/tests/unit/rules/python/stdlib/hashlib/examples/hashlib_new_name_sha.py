# level: ERROR
# start_line: 9
# end_line: 9
# start_column: 17
# end_column: 22
import hashlib


hashlib.new(name="sha")
