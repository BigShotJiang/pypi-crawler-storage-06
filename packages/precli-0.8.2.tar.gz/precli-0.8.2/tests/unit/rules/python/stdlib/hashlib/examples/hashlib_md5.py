# level: ERROR
# start_line: 9
# end_line: 9
# start_column: 8
# end_column: 11
import hashlib


hashlib.md5()
