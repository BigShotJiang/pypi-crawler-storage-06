# level: NONE
import hashlib


hashlib.sha(usedforsecurity=False)
