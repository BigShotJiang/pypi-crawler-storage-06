# level: NONE
import crypt


crypt.crypt("asdfasdfasdfasdf", salt=crypt.METHOD_SHA512)
