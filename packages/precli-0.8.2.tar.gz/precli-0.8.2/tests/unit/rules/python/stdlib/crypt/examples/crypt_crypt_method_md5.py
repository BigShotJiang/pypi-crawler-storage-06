# level: WARNING
# start_line: 9
# end_line: 9
# start_column: 0
# end_column: 11
import crypt


crypt.crypt("password", salt=crypt.METHOD_MD5)
