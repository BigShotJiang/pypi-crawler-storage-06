import hashlib


hashlib.md5()  # type: ... # suppress: PY004 # noqa: E501 ; pylint: disable=line-too-long
