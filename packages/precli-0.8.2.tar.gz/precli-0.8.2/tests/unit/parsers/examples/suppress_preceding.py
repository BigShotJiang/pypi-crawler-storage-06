import hashlib


# suppress: PY004
hashlib.md5()
