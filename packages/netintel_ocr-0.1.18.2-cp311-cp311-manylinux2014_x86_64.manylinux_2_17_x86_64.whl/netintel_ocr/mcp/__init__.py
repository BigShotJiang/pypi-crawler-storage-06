"""
NetIntel-OCR MCP Server Module
Model Context Protocol server for read-only data access
"""

__version__ = "0.1.13"