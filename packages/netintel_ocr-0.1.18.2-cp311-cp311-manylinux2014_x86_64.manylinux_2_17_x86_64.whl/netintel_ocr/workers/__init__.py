"""
Worker processes for NetIntel-OCR
"""

try:
    from ..__version__ import __version__
except ImportError:
    __version__ = "0.1.17.1"