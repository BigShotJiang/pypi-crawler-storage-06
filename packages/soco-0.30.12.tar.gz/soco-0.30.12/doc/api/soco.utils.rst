soco.utils module
=================

.. automodule:: soco.utils
    :member-order: bysource
    :members:
