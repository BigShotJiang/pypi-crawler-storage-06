soco.plugins.wimp module
========================

.. automodule:: soco.plugins.wimp
    :member-order: bysource
    :members:
