soco.xml module
===============

.. automodule:: soco.xml
    :member-order: bysource
    :members:
