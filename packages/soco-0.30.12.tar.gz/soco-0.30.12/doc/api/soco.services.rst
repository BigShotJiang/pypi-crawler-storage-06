soco.services module
====================

.. automodule:: soco.services
    :member-order: bysource
    :members:
