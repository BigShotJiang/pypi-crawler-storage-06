soco.plugins package
====================

Submodules
----------

.. toctree::

   soco.plugins.example
   soco.plugins.spotify
   soco.plugins.wimp
   soco.plugins.sharelink
   soco.plugins.plex

Module contents
---------------

.. automodule:: soco.plugins
    :member-order: bysource
    :members:
