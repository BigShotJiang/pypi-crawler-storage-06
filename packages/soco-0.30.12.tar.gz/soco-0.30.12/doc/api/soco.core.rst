soco.core module
================

.. automodule:: soco.core
    :member-order: bysource
    :members:
