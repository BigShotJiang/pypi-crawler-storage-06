tunein.py will play a radio preset from the TuneIn service on your Sonos system.

For a great example of a command line Sonos contoller using SoCo, see
https://github.com/SoCo/socos