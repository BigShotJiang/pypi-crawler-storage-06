class OdbResultPlot:
    """
    用于绘制结果图像
    """