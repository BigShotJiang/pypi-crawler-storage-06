"""Image processing functionality."""
