"""Metadata extraction."""
