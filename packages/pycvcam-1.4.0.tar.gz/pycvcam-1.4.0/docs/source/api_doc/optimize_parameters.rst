pycvcam.optimize.optimize_parameters
=============================================

.. autofunction:: pycvcam.optimize.optimize_parameters.optimize_parameters