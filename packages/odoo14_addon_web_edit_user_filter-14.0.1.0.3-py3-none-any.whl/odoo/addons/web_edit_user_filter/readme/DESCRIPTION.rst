In standard Odoo you can edit user filters via the debug module.
The problem is that normal users often don't have access to this menu therefore can't adjust filters once they're saved.
This module makes this feature available for normal users with a user friendly interface.
It also adds the ability to adjust facets (a single part of the filter).
