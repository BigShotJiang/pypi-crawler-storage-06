Edit a favourite filter:

#. Go to a list or kanban view;
#. open the advanced search options;
#. open the 'Favorites' menu;
#. Select a filter and click on the star icon of the filter name
#. click on the pencil icon to start editing the filter.

.. image:: /web_edit_user_filter/static/description/select_facet.png
   :alt: Select Facet

Edit a facet:

#. Click on the facet;
#. a menu is now shown which allows you to remove values from the facet;
#. to cancel removal you can click outside the popover.

.. image:: /web_edit_user_filter/static/description/edit_facet.png
   :alt: Edit Facet
