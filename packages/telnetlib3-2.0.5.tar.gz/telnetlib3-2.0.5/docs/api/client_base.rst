client_base
-----------

.. automodule:: telnetlib3.client_base
   :members:
