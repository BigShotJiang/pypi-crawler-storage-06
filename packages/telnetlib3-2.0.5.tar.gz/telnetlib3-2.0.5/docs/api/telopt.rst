telopt
------

.. automodule:: telnetlib3.telopt
   :members:
