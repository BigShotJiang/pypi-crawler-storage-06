stream_reader
-------------

.. automodule:: telnetlib3.stream_reader
   :members:
