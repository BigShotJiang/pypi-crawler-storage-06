"""Context and dataset information for Point Topic MCP."""
