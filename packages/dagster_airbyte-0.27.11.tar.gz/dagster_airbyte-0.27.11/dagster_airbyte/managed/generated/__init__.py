from dagster_airbyte.managed.generated import (
    destinations as destinations,
    sources as sources,
)
