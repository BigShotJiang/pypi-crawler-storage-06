"""MCP Agent Cloud app status."""

from .main import get_app_status

__all__ = ["get_app_status"]
