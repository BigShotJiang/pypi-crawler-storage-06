# django-ansible-base

## What is it?
Django-ansible-base is exactly what it says it is. A base for any Ansible application which will leverage Django.

## Documentation

Docs for django-ansible-base features can be found in the [docs](docs) directory.

Information about the test_app and how to start/use it can be found in [test_app/README.md](test_app/README.md)
