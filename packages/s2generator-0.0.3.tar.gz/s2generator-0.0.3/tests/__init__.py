# -*- coding: utf-8 -*-
"""
Created on 2025/09/22 16:02:13
@author: Whenxuan Wang
@email: wwhenxuan@gmail.com
@url: https://github.com/wwhenxuan/S2Generator
"""