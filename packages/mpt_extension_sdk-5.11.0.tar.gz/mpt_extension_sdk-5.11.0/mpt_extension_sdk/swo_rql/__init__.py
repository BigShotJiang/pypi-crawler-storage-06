from mpt_extension_sdk.swo_rql.query_builder import RQLQuery

R = RQLQuery

__all__ = ["R", "RQLQuery"]
