"""A general purpose AstroWISP based photometry pipeline."""
