# asr_screen_shear
Python screen sharing package with automatic dependency installation