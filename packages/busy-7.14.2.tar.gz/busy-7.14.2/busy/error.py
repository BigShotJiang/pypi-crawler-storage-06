class BusyError(Exception):
    pass
