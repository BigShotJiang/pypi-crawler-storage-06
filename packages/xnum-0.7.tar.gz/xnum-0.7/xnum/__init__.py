# -*- coding: utf-8 -*-
"""XNum modules."""
from .params import XNUM_VERSION, NumeralSystem
from .functions import convert

__version__ = XNUM_VERSION
