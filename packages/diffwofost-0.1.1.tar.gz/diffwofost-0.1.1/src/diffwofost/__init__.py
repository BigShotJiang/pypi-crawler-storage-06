"""Documentation about diffwofost."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__author__ = ""
__email__ = ""
__version__ = "0.1.0"
