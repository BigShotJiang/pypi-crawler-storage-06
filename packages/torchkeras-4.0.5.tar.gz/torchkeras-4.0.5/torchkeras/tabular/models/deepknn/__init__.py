from .config import DeepKNNConfig
from .deepknn_model import DeepKNNModel

__all__ = ["DeepKNNConfig",  "DeepKNNModel"]
