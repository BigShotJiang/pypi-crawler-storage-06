from pathlib import Path


THEME_CSS_DIR = Path(__file__).parent / "theme/css"
