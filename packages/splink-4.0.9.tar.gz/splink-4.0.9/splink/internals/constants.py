LEVEL_NOT_OBSERVED_TEXT = "level not observed in training dataset"
