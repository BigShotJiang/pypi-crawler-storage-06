from splink.internals.postgres.database_api import PostgresAPI

__all__ = ["PostgresAPI"]
