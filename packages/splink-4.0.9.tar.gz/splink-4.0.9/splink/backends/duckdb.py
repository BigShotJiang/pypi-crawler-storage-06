from splink.internals.duckdb.database_api import DuckDBAPI

__all__ = ["DuckDBAPI"]
