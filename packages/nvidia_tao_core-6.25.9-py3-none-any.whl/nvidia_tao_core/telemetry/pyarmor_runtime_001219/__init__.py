# Pyarmor 8.5.8 (basic), 001219, 2025-09-18T12:58:28.576291
from .pyarmor_runtime import __pyarmor__
