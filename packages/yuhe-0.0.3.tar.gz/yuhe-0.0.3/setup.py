from setuptools import find_packages, setup

setup(
    name="yuhe",
    packages=find_packages(),
)
