


VIDEO_MIN_OPACITY = 0.0
"""
The opacity that makes a moviepy video
pixel transparent, which is `0.0`.
"""
VIDEO_MAX_OPACITY = 1.0
"""
The opacity that makes a moviepy video
pixel opaque, which is `1.0`.
"""