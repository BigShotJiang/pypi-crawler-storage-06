# shipswamy

**shipswamy** is a simple Python package to generate two types of long programs:
- Machine Learning (ML) programs
- Generative AI (GenAI) programs

## Installation

```bash
pip install shipswamy