def not_valid_user():
    return {
        "status": "Failed",
        "data": "User not Valid"
    }


def not_logged_in_user():
    return {
        "status": "Failed",
        "data": "User not LoggedIn"
    }
