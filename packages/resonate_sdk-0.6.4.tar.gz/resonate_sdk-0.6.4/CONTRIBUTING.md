# Contribute to the Resonate Python SDK

Please [open a Github Issue](https://github.com/resonatehq/resonate-sdk-py/issues) prior to submitting a Pull Request.

Join the #resonate-engineering channel in the [community Discord](https://www.resonatehq.io/discord) to discuss your changes.
