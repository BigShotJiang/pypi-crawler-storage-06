from __future__ import annotations

from .tag import TagRouter

__all__ = ["TagRouter"]
