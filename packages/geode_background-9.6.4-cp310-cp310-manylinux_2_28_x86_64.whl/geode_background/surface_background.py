#
# Copyright (c) 2019 - 2025 Geode-solutions. All rights reserved.
#

import opengeode
import geode_common

from .lib64.geode_background_py_surface import *
BackgroundSurfaceLibrary.initialize()
