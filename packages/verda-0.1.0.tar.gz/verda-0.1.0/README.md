Reserved package name for an upcoming tool.
