def render_table(*args, **kwargs):
    return ''
