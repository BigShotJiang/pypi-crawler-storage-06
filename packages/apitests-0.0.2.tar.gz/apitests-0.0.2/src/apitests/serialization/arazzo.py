def build_workflows(*args, **kwargs):
    return ''
