"""MyPet - A simple CLI tool for pet commands."""

__version__ = "0.0.2"
