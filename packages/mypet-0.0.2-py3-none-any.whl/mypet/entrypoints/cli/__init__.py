"""CLI entry point for the mypet package."""
