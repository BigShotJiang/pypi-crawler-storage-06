"""Entry points for the mypet package."""
