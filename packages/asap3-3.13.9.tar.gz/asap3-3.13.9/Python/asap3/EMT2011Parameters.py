"Compatibility with old scripts using EMT2011."

from asap3.EMT2013Parameters import PtY_parameters
from asap3.EMT2013Parameters import EMT2013_experimental_parameters as EMT2011_parameters
