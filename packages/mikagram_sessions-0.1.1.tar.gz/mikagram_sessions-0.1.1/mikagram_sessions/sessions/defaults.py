from mikagram_sessions.constants import ApiApplications


DEFAULT_DC = 1
DEFAULT_AUTH_KEY = None
DEFAULT_SERVER_ADDRESS = "149.154.175.53"
DEFAULT_SERVER_PORT = 443
DEFAULT_API_ID = ApiApplications.WinBeta.api_id  # desktop client
DEFAULT_APP_HASH = ApiApplications.WinBeta.api_hash  # desktop client
