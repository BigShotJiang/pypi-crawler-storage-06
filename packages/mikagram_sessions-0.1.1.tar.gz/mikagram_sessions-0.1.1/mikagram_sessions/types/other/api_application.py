from dataclasses import dataclass


@dataclass
class ApiApplication:
    api_id: int
    api_hash: str

