from mikagram_sessions.types import ApiApplication


class ApiApplications():
    DesktopExample = ApiApplication(17349, "344583e45741c457fe1862106095a5eb")
    XAndroid = ApiApplication(21724, "3e0cb5efcd52300aec5994fdfc5bdc16")
    Web = ApiApplication(2496, "8da85b0d5bfe62527e5b244c209159c3")
    TDLibExample = ApiApplication(94575, "a3406de8d171bb422bb6ddf3bbd800e2")
    MessengerCLI = ApiApplication(2899, "36722c72256a24c1225de00eb6a1ca74")
    PlusMessenger = ApiApplication(16623, "8c9dbfe58437d1739540f5d53c72ae4b")
    Swift = ApiApplication(10840, "33c45224029d59cb3ad0c16134215aeb")
    MacOsBeta = ApiApplication(2834, "68875f756c9b437a8b916ca3de215815")
    UnknownBeta = ApiApplication(9, "3975f648bb682ee889f35483bc618d1c")
    WinBeta = ApiApplication(2040, "b18441a1ff607e10a989891a5462e627")
