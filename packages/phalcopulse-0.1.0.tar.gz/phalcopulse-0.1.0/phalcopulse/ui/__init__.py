# This file promotes widget classes to the 'ui' namespace for easier access.

from .widgets import Label, Button, Checkbox, Slider, TextInput, ToggleSwitch
