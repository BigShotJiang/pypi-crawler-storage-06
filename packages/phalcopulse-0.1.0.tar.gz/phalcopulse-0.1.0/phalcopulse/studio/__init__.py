# Optional addition to phalcopulse/studio/__init__.py
from .application import PhalcoPulseStudio
