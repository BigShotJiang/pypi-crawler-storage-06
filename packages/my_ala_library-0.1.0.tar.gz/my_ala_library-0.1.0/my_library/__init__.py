
def say_hello():
    print("Hello from my library!")
