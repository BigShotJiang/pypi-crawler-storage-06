"""Core proxy implementation for invisible object wrapping."""

from __future__ import annotations

__all__ = ["InvisibleProxy"]


class InvisibleProxy:
    pass
