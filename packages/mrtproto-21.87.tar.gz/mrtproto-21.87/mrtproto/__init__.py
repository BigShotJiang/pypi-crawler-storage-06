__version__ = "21.87"
proto_sha1 = "76cc14e98f707c3aebdcf8ab54638a81042932fc"
proto_conan_version = "v21"
