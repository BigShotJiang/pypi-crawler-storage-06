from xproject.xlogger import get_logger


class Notifier:
    logger = get_logger()
