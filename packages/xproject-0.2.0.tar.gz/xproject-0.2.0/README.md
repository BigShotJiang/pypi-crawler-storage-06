# xproject

#### scripts

##### generate_init_py

~~~shell
poetry run generate_init_py src/xproject

or

generate_init_py src/xproject
~~~

##### render_handler_py

~~~shell
poetry run render_handler_py handler.py

or

render_handler_py handler.py
~~~

##### render_task_py

~~~shell
poetry run render_task_py task.py

or

render_task_py task.py
~~~
