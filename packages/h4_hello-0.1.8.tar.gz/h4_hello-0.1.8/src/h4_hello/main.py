from h4_hello.hello import hello


def main() -> None:
    print(hello())


if __name__ == "__main__":
    main()
