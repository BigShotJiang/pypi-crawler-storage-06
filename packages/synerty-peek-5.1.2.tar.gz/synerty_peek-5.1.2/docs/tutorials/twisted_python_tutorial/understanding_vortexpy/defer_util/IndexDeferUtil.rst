.. _defer_util:

=======================
Understanding DeferUtil
=======================

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    defer_util.rst
    defer_to_thread_wrap_with_logger.rst
    maybe_deferred_wrap.rst
    ensure_deferred_wrap.rst
    non_concurrent_method.rst
    vertex_log_failure.rst
    thread_checks.rst

