"""
Integration tests for ReqSmith.
"""