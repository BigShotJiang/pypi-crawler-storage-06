"""
Configuration management module for ReqSmith
"""