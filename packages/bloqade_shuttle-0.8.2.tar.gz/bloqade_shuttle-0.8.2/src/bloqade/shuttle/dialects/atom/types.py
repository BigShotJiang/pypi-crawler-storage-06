from kirin import types


class Atom:
    pass


AtomType = types.PyClass(Atom)
