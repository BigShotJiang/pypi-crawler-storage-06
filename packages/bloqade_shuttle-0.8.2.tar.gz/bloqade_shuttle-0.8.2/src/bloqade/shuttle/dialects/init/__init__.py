from . import runtime as runtime
from ._dialect import dialect as dialect
from ._interface import fill as fill
from .stmts import Fill as Fill
