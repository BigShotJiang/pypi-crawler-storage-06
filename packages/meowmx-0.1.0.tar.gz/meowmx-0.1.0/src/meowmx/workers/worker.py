# from dataclasses import dataclass
# import typing as t


# # class Worker:

# #     pass


# # @dataclass

# # def _load_worker(worker: str) -> Worker:

# # def create_worker(name: str, category: str) -> Worker:
# #     pass
