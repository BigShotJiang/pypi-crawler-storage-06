"""
py2jupyter - Конвертер Python ↔ Jupyter Notebook

Двунаправленный конвертер между Python файлами и Jupyter ноутбуками
с поддержкой markdown комментариев и умным структурированием кода.
"""

__version__ = "0.3.0"
__author__ = "Artem Antonov"
__description__ = "Конвертер Python ↔ Jupyter Notebook"
