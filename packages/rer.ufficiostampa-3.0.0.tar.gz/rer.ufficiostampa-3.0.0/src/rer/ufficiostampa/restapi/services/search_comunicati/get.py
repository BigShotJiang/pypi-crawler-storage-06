from plone.restapi.services.search.get import SearchGet


class SearchComunicatiGet(SearchGet):
    """ """
