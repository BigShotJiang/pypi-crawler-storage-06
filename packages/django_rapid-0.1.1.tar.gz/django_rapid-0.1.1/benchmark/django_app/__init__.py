"""Django app for benchmarking."""
