from __future__ import annotations

def main() -> None:
    print("parastat: command-line interface placeholder")
