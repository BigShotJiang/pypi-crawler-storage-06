from llama_index.readers.mongodb.base import SimpleMongoReader

__all__ = ["SimpleMongoReader"]
