"""MCP工具评估助手服务器入口"""

from .main import main

if __name__ == "__main__":
    main()