#!/usr/bin/env python
# coding: utf-8
#
# Licensed under MIT
#

import setuptools
setuptools.setup(setup_requires=['pbr'], python_requires='>=3.6', pbr=True)
