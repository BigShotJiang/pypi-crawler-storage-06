# coding: utf-8
#

import warnings
from uiautomator2.xpath import *

warnings.simplefilter("always", DeprecationWarning)

warnings.warn("use \"import uiautomator2.xpath as xpath\" instead",
              DeprecationWarning, 1)
