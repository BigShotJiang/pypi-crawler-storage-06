# uiautomator2 xpath extension

Documents has moved to [../../XPATH.md](../../XPATH.md)
