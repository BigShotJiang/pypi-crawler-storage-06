Documentation in <https://github.com/openatx/uiautomator2>
