"""Cloudnetpy-QC version."""

MAJOR = 1
MINOR = 27
PATCH = 1
__version__ = f"{MAJOR}.{MINOR}.{PATCH}"
