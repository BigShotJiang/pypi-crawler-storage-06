"""
The new functional interface.
"""
