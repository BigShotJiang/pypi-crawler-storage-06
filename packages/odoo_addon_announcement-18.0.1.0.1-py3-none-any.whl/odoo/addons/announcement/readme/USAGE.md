When a user in the scope of active announcements logs in, those will
popup. The user has to mark them as read to continue working. If the
announcement is set during the user session, the announcement will be
eventually prompted in the top bar on the right part. The user click on
the unread announcements icon (a speaker) and the announcements will
popup for the user to check them.

Users can go *Discuss \> Announcements* to check current and past
announcements. Announcement managers can also track which users have
read the announcement.
