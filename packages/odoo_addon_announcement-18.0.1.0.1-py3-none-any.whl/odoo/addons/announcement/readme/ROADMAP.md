- It could be integrated in Discuss app to review past announcements.
- Log other information like geolocation, IP, browser agent, etc when
  marking announcement as read.
