This module adds popup announcements in the backend for targeted
internal users. Those announcements can contain rich format and a user
read log is kept for everyone.
