from .exception_handler import drf_json_exception_handler

__all__ = ["drf_json_exception_handler"]
