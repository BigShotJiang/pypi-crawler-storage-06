===============
Release History
===============

Initial Release, v0.1.0 (2021-10-22)
------------------------------------

- Initial release implementing Github Actions CI and basic tests.
