============
Installation
============

At the command line::

    $ pip install smi_analysis
