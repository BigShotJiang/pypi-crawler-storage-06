=====
Usage
=====

Start by importing SMI_analysis.

.. code-block:: python

    import smi_analysis
