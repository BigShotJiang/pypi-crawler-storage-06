from .resolver import WidPathResolver

__all__ = ["WidPathResolver"]
