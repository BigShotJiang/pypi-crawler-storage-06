# Space Defender

لعبة بسيطة مكتوبة بالبايثون باستخدام Tkinter.

التشغيل:
- محلياً: `python -m space_defender`
- بعد التثبيت: `space-defender`

المؤلف: حمزة صلاح
