"""
Sources
"""

NAME = "Tools"

DESCRIPTION = "Tools."

BACKGROUND = "#b9d47a"

ICON = "icons/utility.png"

PRIORITY = 1010