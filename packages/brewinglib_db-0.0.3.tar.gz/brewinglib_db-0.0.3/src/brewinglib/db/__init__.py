"""Database helper package."""

from .database import Database as Database

__all__ = ["Database"]
