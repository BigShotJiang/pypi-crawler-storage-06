# encoding: utf-8
CLI_URL = "https://cli.cloud.tencent.com/sso"
SITE = "intl"
DEFAULT_LANG = "en-US"
