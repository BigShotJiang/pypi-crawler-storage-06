"""OpenBB MCP Server App Module."""
