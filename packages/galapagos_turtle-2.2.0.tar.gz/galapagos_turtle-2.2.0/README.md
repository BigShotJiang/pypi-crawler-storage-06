# galapagos
python package for codehs that makes Tracy the turtle better 
i just made this for highschool idk