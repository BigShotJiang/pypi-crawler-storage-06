.. automodule:: vivarium_cluster_tools.psimulate.worker.core
