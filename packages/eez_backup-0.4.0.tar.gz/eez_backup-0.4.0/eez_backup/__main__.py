#!/usr/bin/env python3
import sys

from eez_backup.cli import cli

if __name__ == "__main__":
    sys.exit(cli())
