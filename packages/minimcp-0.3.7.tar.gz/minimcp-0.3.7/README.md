# MiniMCP POC

This is a proof-of-concept for experimentation only. Not intended for public use.
