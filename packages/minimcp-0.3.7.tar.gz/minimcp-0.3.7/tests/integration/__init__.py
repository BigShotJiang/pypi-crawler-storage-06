"""Integration tests for MiniMCP."""
