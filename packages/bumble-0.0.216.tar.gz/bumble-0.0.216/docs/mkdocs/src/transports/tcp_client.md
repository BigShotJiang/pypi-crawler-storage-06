TCP CLIENT TRANSPORT
====================

The TCP Client transport uses an outgoing TCP connection to a host:port address.

## Moniker
The moniker syntax for a TCP client transport is: `tcp-client:<remote-host>:<remote-port>`

!!! example
    `tcp-client:127.0.0.1:9001`
    Connects to port 9001 on the local host
