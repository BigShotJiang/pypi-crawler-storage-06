# 0.2.0

- Code-gen company ID table
- Unstable support for extended advertisements
- CLI tools for downloading Realtek firmware
- PDL-generated types for HCI commands

# 0.1.0

- Initial release
