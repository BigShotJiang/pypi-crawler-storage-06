"""APaper utilities module."""

from .pdf_reader import read_pdf

__all__ = ["read_pdf"]