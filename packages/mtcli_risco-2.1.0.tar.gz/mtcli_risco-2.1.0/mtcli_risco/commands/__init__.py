from .checar import checar
from .monitorar import monitorar
