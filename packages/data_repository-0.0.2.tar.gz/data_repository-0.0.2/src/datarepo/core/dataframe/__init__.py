from datarepo.core.dataframe.frame import NlkDataFrame

__all__ = [
    "NlkDataFrame",
]
