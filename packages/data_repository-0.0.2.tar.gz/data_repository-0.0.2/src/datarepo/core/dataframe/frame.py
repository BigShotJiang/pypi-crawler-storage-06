import polars as pl


NlkDataFrame = pl.LazyFrame
