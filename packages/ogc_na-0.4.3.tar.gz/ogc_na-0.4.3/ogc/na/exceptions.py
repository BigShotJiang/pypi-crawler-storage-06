class ContextLoadError(IOError):
    pass


class SchemaLoadError(IOError):
    pass
