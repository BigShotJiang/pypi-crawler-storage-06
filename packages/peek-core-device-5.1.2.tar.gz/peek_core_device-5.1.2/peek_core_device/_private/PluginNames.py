deviceFilt = {"plugin": "peek_core_device"}
deviceTuplePrefix = "peek_core_device."
deviceObservableName = "peek_core_device"
deviceActionProcessorName = "peek_core_device"
deviceTupleOfflineServiceName = "peek_core_device"
