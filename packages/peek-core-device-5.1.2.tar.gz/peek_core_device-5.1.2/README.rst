=================
Device Management
=================

This is a core peek module that manages the client device enrolments and updates.

