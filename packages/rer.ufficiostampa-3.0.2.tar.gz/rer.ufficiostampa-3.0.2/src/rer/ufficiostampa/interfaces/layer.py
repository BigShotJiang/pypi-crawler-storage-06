from zope.publisher.interfaces.browser import IDefaultBrowserLayer


class IRerUfficiostampaLayer(IDefaultBrowserLayer):
    """Marker interface that defines a browser layer."""
