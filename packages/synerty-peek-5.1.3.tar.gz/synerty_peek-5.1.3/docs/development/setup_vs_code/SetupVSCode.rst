.. _setup_vs_code_ide:

=================
Setup VS Code IDE
=================

#.  Visual Studio Code,

    :Download: `<https://code.visualstudio.com>`_

    Add PATH to environment variables ::

        "C:\Program Files (x86)\Microsoft VS Code\bin"

