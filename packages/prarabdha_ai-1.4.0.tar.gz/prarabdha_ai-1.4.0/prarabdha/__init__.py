"""
Prarabdha - A CLI tool for scaffolding backend services.
"""

__version__ = "1.0.0"
__author__ = "Prarabdha"
__email__ = "prarabdha@example.com"
