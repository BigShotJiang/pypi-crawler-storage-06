# Database sources

::: viadot.sources.azure_data_lake.AzureDataLake

::: viadot.sources.azure_sql.AzureSQL

::: viadot.sources.databricks.Databricks

::: viadot.sources._duckdb.DuckDB

::: viadot.sources.redshift_spectrum.RedshiftSpectrum

::: viadot.sources.s3.S3

::: viadot.sources.sap_bw.SAPBW

::: viadot.sources.sap_rfc.SAPRFC

::: viadot.sources.base.Source

::: viadot.sources.base.SQL

::: viadot.sources.sqlite.SQLite

::: viadot.sources.sql_server.SQLServer

::: viadot.sources._trino.Trino
