class InvalidActionError(RuntimeError):
    pass
