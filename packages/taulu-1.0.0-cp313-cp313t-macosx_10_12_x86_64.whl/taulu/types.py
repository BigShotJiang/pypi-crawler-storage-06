from typing import Tuple

Point = Tuple[int, int]
PointFloat = Tuple[float, float]
