# azadcal

A simple calculator package for python.

## Installation

```bash
pip install Swatantracal
```
