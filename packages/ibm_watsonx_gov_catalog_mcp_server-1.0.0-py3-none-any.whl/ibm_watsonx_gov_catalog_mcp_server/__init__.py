from .server import run_gov_catalog_mcp_server

def main():
    """Run the MCP server."""
    run_gov_catalog_mcp_server()