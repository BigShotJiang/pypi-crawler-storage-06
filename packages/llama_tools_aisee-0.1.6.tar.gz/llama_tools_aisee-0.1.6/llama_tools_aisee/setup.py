entry_points = {
    'console_scripts':[
        'llama-tools-aisee= llama_tools_aisee.__main__:main'
    ]
    }