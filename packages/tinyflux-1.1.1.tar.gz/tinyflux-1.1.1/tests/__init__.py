"""Tests for TinyFlux.

TinyFlux uses pyTest.

Test fixtures and configuration are found in tests/conftest.py.
"""
