"""Version."""

__version__ = "1.1.1"  # pragma: no cover
