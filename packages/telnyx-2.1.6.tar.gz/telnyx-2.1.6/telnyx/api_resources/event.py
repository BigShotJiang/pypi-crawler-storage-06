from __future__ import absolute_import, division, print_function

from telnyx.api_resources.abstract.api_resource import APIResource


class Event(APIResource):
    OBJECT_NAME = "event"
