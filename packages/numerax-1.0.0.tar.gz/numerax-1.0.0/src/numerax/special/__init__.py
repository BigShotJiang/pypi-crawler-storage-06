from ._erf_and_fresnel import erfcinv
from ._gamma import gammap_inverse

__all__ = ["erfcinv", "gammap_inverse"]
