# Numerax

::: numerax
    options:
      show_source: false
      heading_level: 1