# Utilities

::: numerax.utils
    options:
      show_source: false
      heading_level: 2