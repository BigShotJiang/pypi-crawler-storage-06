This extension will register your current Jupyter instance as an execution environment with nbgallery.  That enables the "Run in Jupyter" button in nbgallery to launch notebooks into this Jupyter environment.

This extension will also download and apply any preferences you've saved in nbgallery via the _Preferences_ menu in the NBGallery Menu extension.
