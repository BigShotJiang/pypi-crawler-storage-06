This extension will automatically download your _Starred_ and _Recently Executed_ notebooks from nbgallery when you first visit the Jupyter tree page.  This can be helpful to recreate your workspace if your Jupyter environment is not persistent.

![Auto-downloaded folders](autodownload.png)
