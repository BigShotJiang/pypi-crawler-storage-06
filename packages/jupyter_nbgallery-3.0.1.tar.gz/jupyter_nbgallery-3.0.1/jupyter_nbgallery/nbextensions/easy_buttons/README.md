This extension adds convenience buttons to the active cell to perform common actions such as *Run*, *Insert Below*, *Delete*, etc.  Even if this extension is enabled, you can also turn off Easy Buttons from the *Preferences* menu added by the NBGallery Menu extension.

![Easy buttons](easy_buttons.png)
