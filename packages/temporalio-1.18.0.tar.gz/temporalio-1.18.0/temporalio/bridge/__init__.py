"""Python interface to SDK Core. (unstable)

Nothing in this package should be considered stable. The API may change.
"""
