from .message_pb2 import Region

__all__ = [
    "Region",
]
