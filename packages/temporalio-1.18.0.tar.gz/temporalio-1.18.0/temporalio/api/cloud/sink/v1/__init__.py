from .message_pb2 import GCSSpec, S3Spec

__all__ = [
    "GCSSpec",
    "S3Spec",
]
