"""Test package initializer.

Intentionally empty to avoid importing optional test utilities during collection.
"""

__all__: list[str] = []
