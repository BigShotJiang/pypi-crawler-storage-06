"""A package of Python modules, used to configure and test IBIS-AMI models."""

print("pyibisami is a package of sub-modules, and is not directly executable.")
print("Perhaps, you meant:")
print("    - pyibisami.ami.config")
print("    - pyibisami.tools.run_tests")
raise RuntimeError("pyibisami is not executable.")
