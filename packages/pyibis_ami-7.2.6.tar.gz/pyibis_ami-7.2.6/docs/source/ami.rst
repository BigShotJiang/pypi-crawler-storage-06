pyibisami.ami
=============

AMI related submodules in the *PyIBIS-AMI* package.

config
------

.. automodule:: pyibisami.ami.config

model
-----

.. automodule:: pyibisami.ami.model

parameter
---------

.. automodule:: pyibisami.ami.parameter

parser
------

Sorry, the code in this module breaks the *Sphinx* ``autodoc`` processor.
So, we have to exclude it from these docs.
You'll have to peruse the comments in the code, manually.
See the ``pyibisami/ami/parser.py`` file.
