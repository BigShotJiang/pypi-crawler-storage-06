"""The ncaabw data sportsball module."""

# ruff: noqa: F401
from .combined.ncaabw_combined_league_model import \
    NCAABWCombinedLeagueModel as NCAABWLeagueModel
