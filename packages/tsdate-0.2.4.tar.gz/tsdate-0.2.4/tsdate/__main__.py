from . import cli


def main():
    cli.tsdate_main()


if __name__ == "__main__":
    main()  # pragma: no cover
