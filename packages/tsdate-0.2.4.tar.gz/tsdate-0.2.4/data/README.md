The file prior_1000df.bak is provided as the default example of the precalculated, cached prior. It is only used in the circleci to expedite testing.
