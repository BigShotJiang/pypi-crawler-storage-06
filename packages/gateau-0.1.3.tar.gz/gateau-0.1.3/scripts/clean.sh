#!/bin/sh

rm -rf \
	.ruff_cache \
	.skbuild-info.json \
	CMakeCache.txt \
	CMakeFiles \
	CMakeInit.txt \
	dist \
	*.cmake \
	.cmake \
	testfile \
	docs \
	gsl \
	Makefile \
	gateau_test

