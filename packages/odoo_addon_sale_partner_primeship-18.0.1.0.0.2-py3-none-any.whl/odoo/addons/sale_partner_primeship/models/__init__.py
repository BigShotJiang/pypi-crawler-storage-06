from . import product_template, res_partner, sale_primeship, sale_order
