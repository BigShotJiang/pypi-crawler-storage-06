# main.py


from ui import GameUI

if __name__ == "__main__":
    ui = GameUI()
    ui.run()