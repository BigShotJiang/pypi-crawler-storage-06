# Paranet Agent Framework for Python

## Documentation

The API documentation is auto-generated.  If you update the API, run the following from the `pydoc` folder:
```python
python makedocs.py
```

Requires the `pydoc-markdown` package.