"""
This setup.py file is kept for backward compatibility.
All configuration has been moved to pyproject.toml.
"""

from setuptools import setup

# This setup.py is kept for backward compatibility
# All configuration is in pyproject.toml
setup()
