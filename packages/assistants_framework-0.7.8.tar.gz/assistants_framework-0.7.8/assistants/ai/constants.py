"""
Constants for the AI assistants.
"""

REASONING_MODELS = ["o1", "o3-mini", "o4-mini"]
