"""
The asynchronous control server for the DAQ6510 device.
"""
