\# aiden-v-dlp

A friendly `yt-dlp` wrapper with sensible defaults.



\## Install (recommended)

\- With pipx: `pipx install aiden-v-dlp`

\- Or pip: `pip install --user aiden-v-dlp`



\## Use

`aiden-v-dlp <video\_url>`  

Downloads MP4 to your Downloads folder. Pass any `yt-dlp` flags and they'll be forwarded.



