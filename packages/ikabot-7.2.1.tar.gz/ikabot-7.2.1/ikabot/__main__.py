from ikabot.command_line import main

main()
