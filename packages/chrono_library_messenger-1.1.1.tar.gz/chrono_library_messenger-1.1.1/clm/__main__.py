# Copyright © 2025, Alexander Suvorov
from .cli import main

if __name__ == "__main__":
    main()
