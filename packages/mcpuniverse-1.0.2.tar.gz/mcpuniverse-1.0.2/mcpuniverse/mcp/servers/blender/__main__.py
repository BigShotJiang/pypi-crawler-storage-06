import sys

from .server import main

sys.exit(main())
