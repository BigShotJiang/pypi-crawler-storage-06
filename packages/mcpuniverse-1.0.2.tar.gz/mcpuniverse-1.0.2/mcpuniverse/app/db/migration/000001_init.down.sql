DROP TABLE IF EXISTS "benchmark_job";
DROP TABLE IF EXISTS "released_task";
DROP TABLE IF EXISTS "released_benchmark";
DROP TABLE IF EXISTS "released_project";

DROP TABLE IF EXISTS "task";
DROP TABLE IF EXISTS "benchmark";
DROP TABLE IF EXISTS "project";
DROP TABLE IF EXISTS "user";

DROP TYPE "user_perm";