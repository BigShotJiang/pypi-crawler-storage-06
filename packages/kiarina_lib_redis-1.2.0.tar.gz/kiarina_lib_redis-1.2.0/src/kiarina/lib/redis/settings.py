from typing import Any

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic_settings_manager import SettingsManager


class RedisSettings(BaseSettings):
    """
    Redis Settings
    """

    model_config = SettingsConfigDict(env_prefix="KIARINA_LIB_REDIS_")

    url: str = "redis://localhost:6379"
    """
    Redis URL

    Example:
    - redis://[[username]:[password]]@localhost:6379
    - rediss://[[username]:[password]]@localhost:6379
    """

    initialize_params: dict[str, Any] = Field(default_factory=dict)
    """
    Additional parameters to initialize the Redis client.
    """

    use_retry: bool = False
    """
    Whether to enable automatic retries

    When enabled, it is configured to retry upon occurrence of
    redis.ConnectionError or redis.TimeoutError.
    """

    socket_timeout: float = 6.0
    """
    Socket timeout in seconds

    After sending a command, if this time is exceeded, a redis.TimeoutError will be raised.
    """

    socket_connect_timeout: float = 3.0
    """
    Socket connection timeout in seconds

    If this time is exceeded when establishing a new connection, a redis.ConnectionError will occur.
    """

    health_check_interval: int = 60
    """
    Health check interval in seconds

    When acquiring a connection from the pool,
    if the time since last use has elapsed, execute a PING to verify the connection status.
    """

    retry_attempts: int = 3
    """
    Number of retry attempts
    """

    retry_delay: float = 1.0
    """
    Delay between retry attempts in seconds
    """


settings_manager = SettingsManager(RedisSettings, multi=True)
