from baseapp_core.tests.fixtures import *  # noqa

from .fixtures import *  # noqa
