from baseapp_core.tests.fixtures import *  # noqa: F403, F401
