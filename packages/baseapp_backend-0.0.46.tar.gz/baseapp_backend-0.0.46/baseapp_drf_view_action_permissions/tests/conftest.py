from baseapp_core.tests.fixtures import *  # noqa
