class DeepLinkFetchError(Exception):
    pass
