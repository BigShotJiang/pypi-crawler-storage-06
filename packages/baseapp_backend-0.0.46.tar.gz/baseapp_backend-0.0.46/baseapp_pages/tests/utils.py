def make_text_into_quill(text):
    return '{"delta": [], "html": "' + text + '", "ops": []}'
