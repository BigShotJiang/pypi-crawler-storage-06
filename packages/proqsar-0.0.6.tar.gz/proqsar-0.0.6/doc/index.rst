Welcome to template documentation!
=================================
This is documentation for **proqsar** version |version| (release |release|).

.. toctree::
   :caption: Contents
   :maxdepth: 1

   Getting Started <getting_started>
   Data module <data>
   Preprocessor module <preprocess>
   Model module <model>
   Pipeline <pipeline>
   API Reference <api>
