from __future__ import annotations

from ._http_config import HttpConfig

__all__ = [
    'HttpConfig'
]
