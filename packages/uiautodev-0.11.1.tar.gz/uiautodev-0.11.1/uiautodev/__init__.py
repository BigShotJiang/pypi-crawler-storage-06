#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Created on Mon Mar 04 2024 14:28:53 by codeskyblue
"""

# version is auto managed by poetry
__version__ = "0.11.1"