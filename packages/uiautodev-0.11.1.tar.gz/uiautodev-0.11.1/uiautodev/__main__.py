#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Created on Sun Feb 18 2024 14:20:15 by codeskyblue
"""

from uiautodev.cli import main

if __name__ == "__main__":
    main()