class BasePretrained:

    def __init__(self, huggingface_repo_ID):
        self.repo_id = huggingface_repo_ID

    def load_pretrained_model(self):
        pass
