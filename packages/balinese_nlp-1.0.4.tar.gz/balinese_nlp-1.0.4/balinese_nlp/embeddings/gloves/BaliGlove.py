from balinese_nlp.embeddings.BasePretrained import BasePretrained
from gensim.models import Word2Vec
from huggingface_hub import hf_hub_download


class BaliGlove(BasePretrained):
    pass
