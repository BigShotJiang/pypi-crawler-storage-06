"""Tests for demo_example_package."""
