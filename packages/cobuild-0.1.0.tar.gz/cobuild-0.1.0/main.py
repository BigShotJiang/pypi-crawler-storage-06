def main():
    print("Hello from cobuild!")


if __name__ == "__main__":
    main()
