#!/bin/bash
poetry add sekoia-automation-sdk@latest
poetry lock