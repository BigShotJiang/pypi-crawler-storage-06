from pydantic.v1 import BaseModel, Field


class {{cookiecutter.module_name.title().replace(" ", "")}}ModuleConfiguration(BaseModel):
    pass
