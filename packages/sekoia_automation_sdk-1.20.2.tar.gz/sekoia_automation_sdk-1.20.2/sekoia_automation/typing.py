from typing import Literal

SupportedAuthentications = Literal["basic", "apiKey", "bearer", None]
