"""
Utilities and wrappers to work with http services.

To use this package you need to install additional libraries:

* aiohttp (https://github.com/aio-libs/aiohttp)
* aiofiles (https://github.com/Tinche/aiofiles)
"""
