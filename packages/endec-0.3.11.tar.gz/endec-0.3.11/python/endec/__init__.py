from ._endec import encode, decode
from . import _endec

__doc__ = _endec.__doc__
__all__ = ["encode", "decode"]
