

class Worker:

    def __init__(self,
                 instrument: str,
                 volatility: float,
                 trend: float,
                 first_value: float,
                 density_mean: float,
                 density_std: float,
                 ticks_to_emmit: int=1000
                 ):
        pass


    def emit_ticks(self):

        pass





