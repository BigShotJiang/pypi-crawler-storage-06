from quadtree_bench.main import main 

main()