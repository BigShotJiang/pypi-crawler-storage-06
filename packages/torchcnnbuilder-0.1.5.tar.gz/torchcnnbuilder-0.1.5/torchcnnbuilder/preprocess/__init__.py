from torchcnnbuilder.preprocess._dynamic_window import (
    multi_output_tensor,
    single_output_tensor,
)

__all__ = [
    "single_output_tensor",
    "multi_output_tensor",
]
