# Changelog

## Version 0.3.0
- Add command retry logic
- Revert exposure of mocker module due to dependency
- Improve documentation

## Version 0.2.0
- Add chamber mocker module

## Version 0.1.3
- Add documentation

## Version 0.1.2
- Fix License

## Version 0.1.1
- Fix CI issues

## Version 0.1.0

- Initial implementation
- Unit tests
