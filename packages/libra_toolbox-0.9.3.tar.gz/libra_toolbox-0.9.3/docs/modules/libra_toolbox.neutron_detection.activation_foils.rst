libra\_toolbox.neutron\_detection.activation\_foils package
===========================================================

Submodules
----------

libra\_toolbox.neutron\_detection.activation\_foils.calculations module
-----------------------------------------------------------------------

.. automodule:: libra_toolbox.neutron_detection.activation_foils.calculations
   :members:
   :undoc-members:
   :show-inheritance:

libra\_toolbox.neutron\_detection.activation\_foils.explicit module
-------------------------------------------------------------------

.. automodule:: libra_toolbox.neutron_detection.activation_foils.explicit
   :members:
   :undoc-members:
   :show-inheritance:

libra\_toolbox.neutron\_detection.activation\_foils.settings module
-------------------------------------------------------------------

.. automodule:: libra_toolbox.neutron_detection.activation_foils.settings
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: libra_toolbox.neutron_detection.activation_foils
   :members:
   :undoc-members:
   :show-inheritance:
