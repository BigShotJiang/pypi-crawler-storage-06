def main(pr_file, new_inputs, new_outputs, old_inputs, old_outputs):
    """Generate the PR files"""