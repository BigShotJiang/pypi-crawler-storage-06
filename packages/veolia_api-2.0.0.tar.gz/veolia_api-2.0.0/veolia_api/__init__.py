"""veolia_api package"""

from .veolia_api import VeoliaAPI

__all__ = ["VeoliaAPI"]

__version__ = "2.0.0"
