- [Vermon](http://www.grupovermon.com)
  - Carlos Sánchez Cifuentes \<<csanchez@grupovermon.com>\>
- [AvanzOsc](http://avanzosc.es)
  - Oihane Crucelaegui \<<oihanecrucelaegi@avanzosc.es>\>
  - Ana Juaristi \<<anajuaristi@avanzosc.es>\>
  - Daniel Campos \<<danielcampos@avanzosc.es>\>
  - Ainara Galdona \<<ainaragaldona@avanzosc.es>\>
- [Agile Business Group](https://www.agilebg.com)
  - Lorenzo Battistini \<<lorenzo.battistini@agilebg.com>\>
- [Niboo](https://www.niboo.be/)
  - Samuel Lefever \<<sam@niboo.be>\>
  - Pierre Faniel \<<pierre@niboo.be>\>
- [Tecnativa](https://www.tecnativa.com)
  - Pedro M. Baeza
  - David Vidal
  - Carlos Dauden
  - Sergio Teruel
- [Pesol](https://www.pesol.es)
  - Angel Moya Pardo \<<angel.moya@pesol.es>\>
  - Antonio J Rubio Lorente \<<antonio.rubio@pesol.es>\>
- Rattapong Chokmasermkul \<<rattapongc@ecosoft.co.th>\>
- [Druidoo](https://www.druidoo.io)
  - Iván Todorovich \<<ivan.todorovich@druidoo.io>\>
- [GSLab.it](https://www.gslab.it)
  - Giovanni Serra \<<giovanni@gslab.it>\>
- Tharathip Chaweewongphan \<<tharathipc@ecosoft.co.th>\>
- Isaac Gallart \<<igallart@puntsistemes.es>\>

Do not contact contributors directly about support or help with
technical issues.
