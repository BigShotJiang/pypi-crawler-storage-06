"""Top-level package for xero-python."""

__author__ = """Xero Developer API"""
__email__ = "api@xero.com"
__version__ = "9.1.0"
