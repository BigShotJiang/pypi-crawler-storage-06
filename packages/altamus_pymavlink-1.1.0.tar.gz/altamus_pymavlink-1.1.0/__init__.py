'''Altamus Python MAVLink library - see https://mavlink.io/en/'''
__version__ = '1.1.0'
