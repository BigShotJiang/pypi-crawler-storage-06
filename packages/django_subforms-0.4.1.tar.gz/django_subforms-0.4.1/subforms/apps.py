from __future__ import annotations

from django.apps import AppConfig


class DjangoSubformsConfig(AppConfig):
    name = "subforms"
    verbose_name = "subforms"
    default_auto_field = "django.db.models.BigAutoField"
