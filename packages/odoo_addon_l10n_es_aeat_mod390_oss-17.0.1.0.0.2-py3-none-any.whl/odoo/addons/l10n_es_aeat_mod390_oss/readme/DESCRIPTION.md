Este módulo añade las casillas 126 y 127 al modelo390 y genera el valor
de la casilla 126, dependiente de los impuestos OSS.
