"""!
It provides tools to use the traditional approximation of rotation (TAR)

@author Jérôme Ballot
"""

from .plot_stretch_rot import plot_stretch_rot
from .generate_aTAR import *
