from services_communication.routing import MessageRouter

message_router = MessageRouter()
