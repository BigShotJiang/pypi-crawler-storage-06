References
==========

.. [BasuMandal2007] Basu-Mandal, P.; Chatterjee, A. & Papadopoulos, J. M.
   Hands-free circular motions of a benchmark bicycle. Proceedings of the Royal
   Society A: Mathematical, Physical and Engineering Sciences, 2007, 463,
   1983-2003

.. [Meijaard2007] Meijaard, J. P.; Papadopoulos, J. M.; Ruina, A. &
   Schwab, A. L. Linearized dynamics equations for the balance and steer
   of a bicycle: A benchmark and review. Proceedings of the Royal Society
   A: Mathematical, Physical and Engineering Sciences, 2007, 463,
   1955-1982

.. [Moore2012] Moore, J. K. Human Control of a Bicycle. PhD Dissertation.
   University of California, Davis, 2012
