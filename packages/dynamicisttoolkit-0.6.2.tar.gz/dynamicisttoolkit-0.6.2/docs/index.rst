=============================================
Welcome to DynamicistToolKit's documentation!
=============================================

Contents:

.. toctree::
   :maxdepth: 2

   dtk
   references

.. include:: ../README.rst

.. include:: ../CONTRIBUTING.rst

.. include:: ../CHANGELOG.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
