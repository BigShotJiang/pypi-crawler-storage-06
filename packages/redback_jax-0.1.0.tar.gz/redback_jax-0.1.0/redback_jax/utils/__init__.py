"""
Utility functions for redback-jax.
"""