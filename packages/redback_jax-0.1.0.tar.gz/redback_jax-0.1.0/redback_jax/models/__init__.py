"""
JAX-based transient models for electromagnetic counterparts.
"""