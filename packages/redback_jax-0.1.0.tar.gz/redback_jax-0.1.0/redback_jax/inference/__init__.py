"""
JAX-based Bayesian inference tools.
"""