from pathlib import Path

RESOURCES_DIRECTORY = Path(__file__).parent / "__resources__"
