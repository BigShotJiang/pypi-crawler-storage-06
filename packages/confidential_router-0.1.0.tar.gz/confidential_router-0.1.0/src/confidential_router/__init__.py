"""
confidential_router package: modular FastAPI app with decoupled crypto and core services.
"""
__all__ = ["create_app"]
