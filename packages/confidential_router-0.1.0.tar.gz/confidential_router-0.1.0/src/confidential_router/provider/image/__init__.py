from .fal import CRFal

__all__ = [
    "CRFal"
]