# pom-parser

Python library for parsing [POM configuration files](https://pom.computer).

## Changelog

- `0.0.2` - Link to GitHub repository from PyPI page.
- `0.0.1` - Initial release.
