# Libary for minimal SQL Server Utils

- Call a stored proc with results and store in a data class list
- Load a Table from DeltaLake into SQL Server

This package has very few docs. It's used internally and maybe documented better in a later stage
