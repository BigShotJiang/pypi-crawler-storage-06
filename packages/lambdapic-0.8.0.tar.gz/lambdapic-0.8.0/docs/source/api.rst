API Reference
=============

.. toctree::
   :maxdepth: 2

   simulation
   species
   callbacks
   core