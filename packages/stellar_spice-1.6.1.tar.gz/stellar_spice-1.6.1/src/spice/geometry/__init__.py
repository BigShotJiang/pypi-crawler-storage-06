from .utils import polygon_area
from .sutherland_hodgman import clip
