class CodeElementWIthHash(object):
    def __init__(self, hash):
        self.hash = hash
