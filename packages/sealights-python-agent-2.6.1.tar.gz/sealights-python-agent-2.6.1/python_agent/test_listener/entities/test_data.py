class TestData(object):
    def __init__(self, test_name, execution_id, local_time):
        self.testName = test_name
        self.executionId = execution_id
        self.localTime = local_time
        self.testId = None
