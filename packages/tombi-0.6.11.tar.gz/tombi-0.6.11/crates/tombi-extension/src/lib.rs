mod completion;
mod definition;
mod document_link;
pub use completion::*;
pub use definition::*;
pub use document_link::*;

pub trait Extension {}
