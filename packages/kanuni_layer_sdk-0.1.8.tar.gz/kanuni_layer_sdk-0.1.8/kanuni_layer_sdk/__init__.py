from .main import reduct

__all__ = ["reduct"]

__version__ = "0.1.8"
