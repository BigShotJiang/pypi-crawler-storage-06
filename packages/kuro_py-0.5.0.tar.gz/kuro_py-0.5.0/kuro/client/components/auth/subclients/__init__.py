"""Subclients for authentication client."""

from .game import *
from .web import *
