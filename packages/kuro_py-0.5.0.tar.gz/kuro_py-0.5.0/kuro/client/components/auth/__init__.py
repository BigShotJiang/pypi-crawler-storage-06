"""Auth component responsible for authentication."""

from .client import *
