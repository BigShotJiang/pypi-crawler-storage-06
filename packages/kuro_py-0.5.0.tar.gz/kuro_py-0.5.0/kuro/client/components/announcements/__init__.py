"""Announcements Client."""

from .client import *
