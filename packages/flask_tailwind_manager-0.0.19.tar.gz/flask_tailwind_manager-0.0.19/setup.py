from setuptools import setup  # type: ignore

setup()
