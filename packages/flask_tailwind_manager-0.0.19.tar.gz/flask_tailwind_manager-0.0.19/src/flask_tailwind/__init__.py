from .tailwind import TailwindCSS

__all__ = ("TailwindCSS",)
