A pure-python, friendly interface to the generalized singular value decomposition (GSVD).
