from .core import AzureAI, AzureAIError

__version__ = "0.1.0"

__all__ = ["AzureAI", "AzureAIError", "__version__"]
