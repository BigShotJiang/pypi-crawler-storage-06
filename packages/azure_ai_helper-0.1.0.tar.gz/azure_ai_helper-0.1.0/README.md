# azure-ai-helper

A simple, human-friendly wrapper over Azure AI Vision and Language services.

- Clean API: one-line calls like `ai.vision.analyze(path_or_url)` and `ai.language.summarize(text)`.
- Human-readable outputs instead of raw JSON.
- Friendly errors with quick hints.

## Install

Choose extras for services you need:

```powershell
pip install "azure-ai-helper[vision,language]"
```

Or base package only (no SDKs):

```powershell
pip install azure-ai-helper
```

## Quick Start

```python
from azure_ai_helper import AzureAI

# IMPORTANT: Use your own Vision & Language endpoint/key
# Do NOT reuse credentials from other Azure services
ai = AzureAI(endpoint="https://<your-endpoint>", key="<your-key>")

print(ai.vision.analyze("my_image.jpg"))  # local file
print(ai.vision.analyze("https://example.com/photo.jpg"))  # URL

print(ai.language.summarize("Long text..."))
print(ai.language.sentiment("I love this!"))
```

## Credentials
- You must provide your own Azure Cognitive Services endpoint and key.
- This library never ships with embedded credentials and will not read any demo defaults. You control the endpoint/key.
- Use resource keys for the specific services included here (Vision and Text Analytics). Do not use keys from unrelated services.

## Errors
- All errors raise `AzureAIError` with a helpful hint. Common cases:
  - Missing SDK -> install the corresponding extra.
  - Invalid image URL -> provide a direct `.jpg`/`.png` or local path.
  - Summarization unsupported -> we fallback to key phrases; consider enabling the feature in your Azure resource.

## Testing

Install dev tools and run tests:

```powershell
pip install pytest
pytest -q
```

## Roadmap
- Speech service placeholders are present and will be implemented in a future release.

## License
Select a license (e.g., MIT) and update this section.