src.canns.misc.benchmark
========================

.. py:module:: src.canns.misc.benchmark


Functions
---------

.. autoapisummary::

   src.canns.misc.benchmark.benchmark


Module Contents
---------------

.. py:function:: benchmark(runs=10)

