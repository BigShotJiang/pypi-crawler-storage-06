class Collection:
    def get(self):
        pass

    def get_mode(self) -> str:
        pass
