"""Package that allows third party code to extend the server.

This allows registering extra stored procedures or filter functions.
"""
