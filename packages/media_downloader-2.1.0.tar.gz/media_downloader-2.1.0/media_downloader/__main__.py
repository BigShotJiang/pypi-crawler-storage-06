#!/usr/bin/python
# coding: utf-8
from media_downloader.media_downloader_mcp import (
    media_downloader_mcp,
)

if __name__ == "__main__":
    media_downloader_mcp()
