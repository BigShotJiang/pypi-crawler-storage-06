#!/usr/bin/env python
# coding: utf-8

# Copyright (c) b3m2a1.
# Distributed under the terms of the Modified BSD License.

version_info = (0, 1, 0, 'dev')
__version__ = ".".join(map(str, version_info))
