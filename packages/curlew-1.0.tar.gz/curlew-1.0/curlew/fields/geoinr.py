"""
TODO - implement neural field based on the GeoINR approach.
"""