"""
TODO - implement functions for pre-training (initialising) neural fields to either a planar geometry or to 
an analytical function (analytical implicit field model).
"""
