"""
TODO - refactor Fourier-Feature based neural fields into this file.
"""