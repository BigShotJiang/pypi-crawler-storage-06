"""
TODO - implement neural field based on the Siren approach.
"""
