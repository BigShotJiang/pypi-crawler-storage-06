class ResourceFileNotFound(Exception):
    pass


class StreamJsonObjectNotFound(Exception):
    pass
