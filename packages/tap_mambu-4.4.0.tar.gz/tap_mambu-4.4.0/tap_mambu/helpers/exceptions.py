class NoDeduplicationCapabilityException(Exception):
    pass

class NoDeduplicationKeyException(Exception):
    pass

class MambuGeneratorThreadNotAlive(Exception):
    pass
