class UnknownProperty(Exception):
    pass

class AnchorDoesNotExist(Exception):
    pass

class UnauthorizedError(Exception):
    pass

class ForbiddenError(Exception):
    pass

class RxDjangoBug(Exception):
    pass

class ActionNotAsync(Exception):
    pass
