from .related_properties import RelatedProperty as related_property
