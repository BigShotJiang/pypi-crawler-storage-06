from .memoryBase import MemoryDetect

__all__ = ['MemoryDetect']
