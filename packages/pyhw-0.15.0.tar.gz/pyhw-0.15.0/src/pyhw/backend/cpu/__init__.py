from .cpuBase import CPUDetect

__all__ = ['CPUDetect']
