from .titleBase import TitleDetect


__all__ = ["TitleDetect"]
