from .Registry import auto_register
auto_register()
