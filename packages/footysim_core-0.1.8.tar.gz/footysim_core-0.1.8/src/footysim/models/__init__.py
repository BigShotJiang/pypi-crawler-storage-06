# src/footysim/models/__init__.py
from . import league  # noqa: F401
from . import season  # noqa: F401
from . import stadium  # noqa: F401
from . import country  # noqa: F401
from . import club  # noqa: F401
from . import player  # noqa: F401
from . import fixture  # noqa: F401
from . import match  # noqa: F401
from . import transfer  # noqa: F401
