"""Backward compatibility package for autocleaneeg_view."""

from autocleaneeg_view import *  # noqa: F401,F403
