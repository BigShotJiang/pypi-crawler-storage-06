from ani_scrapy.sync_api.scrapers.animeflv.scraper import AnimeFlvScraper
from ani_scrapy.sync_api.scrapers.jkanime.scraper import JKAnimeScraper
from ani_scrapy.sync_api.browser import SyncBrowser
