from __future__ import annotations

from fast_django.routers import APIRouter

router = APIRouter()


