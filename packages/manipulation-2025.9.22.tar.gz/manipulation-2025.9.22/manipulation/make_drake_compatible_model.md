# `manipulation.make_drake_compatible_model`

```{eval-rst}
.. automodule:: manipulation.make_drake_compatible_model
   :members:
