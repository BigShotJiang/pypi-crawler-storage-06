# `manipulation.letter_generation`

```{eval-rst}
.. automodule:: manipulation.letter_generation
   :members:
```
