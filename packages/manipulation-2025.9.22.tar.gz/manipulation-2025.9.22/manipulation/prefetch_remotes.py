from manipulation.remotes import PrefetchAllRemotePackages

if __name__ == "__main__":
    PrefetchAllRemotePackages()
