# `manipulation.create_sdf_from_mesh`

```{eval-rst}
.. automodule:: manipulation.create_sdf_from_mesh
   :members:
