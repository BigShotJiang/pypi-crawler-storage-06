This directory contains _temporary_ files that have hydroelastic properties
specified manually.  I hope to remove them again (or port them back to Drake)
once the "hydroelastizer" lands
(https://reviewable.io/reviews/RobotLocomotion/drake/20059).