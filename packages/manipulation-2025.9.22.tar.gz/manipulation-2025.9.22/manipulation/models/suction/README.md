
This files were copied from 
https://github.com/google-research/ravens/tree/b170602cdaa4b69240327e92c6af8393f09d49ea/ravens/environments/assets/ur5/suction

and were covered by the Apache 2.0 license.

The following modifications where made:
- deleted reference to missing obj.mtl
- added normals to the obj files using trimesh
- removed erroneous commas in rgba value.
- removed .urdf from robot names.
- added hydro properties to tip.