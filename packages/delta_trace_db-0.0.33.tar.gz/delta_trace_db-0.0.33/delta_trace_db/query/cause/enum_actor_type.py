# coding: utf-8
from enum import Enum

class EnumActorType(Enum):
    human = "human"
    ai = "ai"
    system = "system"
