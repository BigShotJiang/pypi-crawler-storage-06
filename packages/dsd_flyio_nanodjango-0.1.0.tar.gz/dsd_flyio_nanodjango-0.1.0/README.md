# dsd-flyio-nanodjango

A proof-of-concept django-simple-deploy plugin that deploys nanodjango projects to Fly.io
