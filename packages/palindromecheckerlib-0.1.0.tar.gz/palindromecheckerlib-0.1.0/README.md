
# PalindromeCheckerLib

A library to verify whether the word or sentenceis a Palindrome.
مكتبة للتحقق مما إذا كانت الكلمة أو الجملة palindrome.

## التثبيت/installation

```bash
py -m pip install PalindromeCheckerLib

Usage from : CMD
الاستخدام من  : CMD

PalindromeCheckerLib "Was it a car or a cat I saw"

It will appear if Palindrome or not
سيظهر إذا كانت Palindrome أو لا

---