
from .checker import is_palindrome, check_multiple
