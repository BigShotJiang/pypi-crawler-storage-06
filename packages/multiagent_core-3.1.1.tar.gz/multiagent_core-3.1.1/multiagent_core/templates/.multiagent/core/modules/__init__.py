"""Python module namespace for template enhancement modules."""
