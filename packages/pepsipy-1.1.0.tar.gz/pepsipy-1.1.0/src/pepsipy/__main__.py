# ─────────────────────────────────────────────────────
#                     PLAYGROUND
#   This file is just an experimental sandbox and is
#   not part of the implementation.
#
#   To run this code, execute python -m pepsipy.
# ──────────────────────────────────────────────────────

from pepsipy import Calculator

Calculator.hello_pepsi()
