def test_yes() -> None:
    assert True
