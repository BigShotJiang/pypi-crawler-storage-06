---
description: Commit the current changeset to git.
---

Use @agent-conventional-committer to commit all current changes in the git repository. Be sure that the commit message covers all changes, not just the most recent work.
