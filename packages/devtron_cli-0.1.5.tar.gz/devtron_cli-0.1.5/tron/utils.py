import requests,base64
import json
import yaml
from deepdiff import DeepDiff


class DevtronUtils:
    def __init__(self, base_url, headers):
        self.base_url = base_url
        self.headers = headers

    def makebase64(self, secret):
        """
        UTF-8 encoding is required because the base64.b64encode() function expects bytes, not a Python string. Encoding a string with .encode('utf-8') converts it to bytes, which can then be base64-encoded.
        """
        if not secret or not isinstance(secret, dict):
            return None
        new_secret = dict(secret)
        data = new_secret.get('data', {})
        if not isinstance(data, dict):
            return new_secret
        encoded_data = {}
        for k, v in data.items():
            encoded_data[k] = base64.b64encode(str(v).encode('utf-8')).decode('utf-8')
        new_secret['data'] = encoded_data
        return new_secret

    def get_team_id_by_project_name(self, project_name):
        """
        Get team ID by project name from Devtron.
        
        Args:
            project_name (str): Name of the project
            
        Returns:
            dict: Result with success status and team ID or error message
        """
        try:
            # Make API call to get all teams
            response = requests.get(
                f'{self.base_url}/orchestrator/team',
                headers=self.headers
            )
            
            # Check response status
            if response.status_code == 200:
                result = response.json()
                # Find the team with the matching name
                teams = result.get('result', [])
                for team in teams:
                    if team.get('name') == project_name:
                        return {
                            'success': True,
                            'team_id': team.get('id')
                        }
                
                # If we didn't find a matching team
                return {
                    'success': False,
                    'error': f'Could not find team with name {project_name}'
                }
            else:
                # Handle error response
                try:
                    error_result = response.json()
                    error_message = error_result.get('errors', [{}])[0].get('userMessage', '')
                    if error_message:
                        return {
                            'success': False,
                            'error': f'API request failed: {error_message}'
                        }
                    else:
                        return {
                            'success': False,
                            'error': f'API request failed with status {response.status_code}: {response.text}'
                        }
                except Exception as e:
                    # If we can't parse the error response, return the raw error
                    return {
                        'success': False,
                        'error': f'API request failed with status {response.status_code}: {response.text}'
                    }
                
        except Exception as e:
            return {
                'success': False,
                'error': f'Exception occurred: {str(e)}'
            }

    @staticmethod
    def remove_empty_values(obj):
        """
        Recursively remove empty values from a dictionary or list.
        Removes keys with empty strings, None, empty dicts, empty lists, etc.
        """
        if isinstance(obj, dict):
            result = {}
            for k, v in obj.items():
                cleaned_value = DevtronUtils.remove_empty_values(v)
                # Only include non-empty values
                if cleaned_value is not None and cleaned_value != '' and cleaned_value != {} and cleaned_value != []:
                    result[k] = cleaned_value
            return result if result else None
            
        elif isinstance(obj, list):
            result = []
            for item in obj:
                cleaned_item = DevtronUtils.remove_empty_values(item)
                # Only include non-empty items
                if cleaned_item is not None and cleaned_item != '' and cleaned_item != {} and cleaned_item != []:
                    result.append(cleaned_item)
            return result if result else None
            
        else:
            # Return primitive values as-is
            return obj

    def _get_chart_name_from_id(self, app_id, chart_ref_id):
        """Get chart name from chart reference ID"""
        try:
            url = f"{self.base_url}/orchestrator/chartref/autocomplete/{app_id}"
            response = requests.get(url, headers=self.headers)
            if response.status_code == 200:
                result = response.json().get('result', {})
                chart_refs = result.get('chartRefs', [])
                for chart_ref in chart_refs:
                    if chart_ref.get('id') == chart_ref_id:
                        return chart_ref.get('name')
            return None
        except Exception as e:
            print(f"Warning: Could not fetch chart name: {str(e)}")
            return None
        
    def get_application_id_by_name(self,app_name):


        """
        Get application ID by application name from Devtron.
        
        Args:
            app_name (str): Name of the application
            
        Returns:
            dict: Result with success status and app ID or error message
        """
        try:
            # Make API call to get all applications
            response = requests.get(
                f'{self.base_url}/orchestrator/app/autocomplete',
                headers=self.headers
            )
            
            # Check response status
            if response.status_code == 200:
                result = response.json()

                # Find the application with the matching name
                apps = result.get('result', [])
                for app in apps:
                    if app.get('name') == app_name:
                        return {
                            'success': True,
                            'app_id': app.get('id')
                        }
                
                # If we didn't find a matching application
                return {
                    'success': False,
                    'error': f'Could not find application with name {app_name}'
                }
            else:
                # Handle error response
                try:
                    error_result = response.json()
                    error_message = error_result.get('errors', [{}])[0].get('userMessage', '')
                    if error_message:
                        return {
                            'success': False,
                            'error': f'API request failed: {error_message}'
                        }
                    else:
                        return {
                            'success': False,
                            'error': f'API request failed with status {response.status_code}: {response.text}'
                        }
                except:
                    # If we can't parse the error response, return the raw error
                    return {
                        'success': False,
                        'error': f'API request failed with status {response.status_code}: {response.text}'
                    }
                
        except Exception as e:
            return {
                'success': False,
                'error': f'Exception occurred: {str(e)}'
            }

    def get_cd_pipeline_id_by_environment_name(self, app_id, environment_name):
        """
        Get CD pipeline ID by environment name from Devtron.
        
        Args:
            app_id (int): The ID of the application
            environment_name (str): Name of the environment
            
        Returns:
            dict: Result with success status and CD pipeline ID or error message
        """
        try:
            # Make API call to get all CD pipelines for the application
            response = requests.get(
                f'{self.base_url}/orchestrator/app/cd-pipeline/{app_id}',
                headers=self.headers
            )
            
            # Check response status
            if response.status_code == 200:
                result = response.json()
                # Find the CD pipeline with the matching environment name
                pipelines = result.get('result', {}).get('pipelines', [])
                for pipeline in pipelines:
                    if pipeline.get('environmentName') == environment_name:
                        return {
                            'success': True,
                            'pipeline_id': pipeline.get('id')
                        }
                
                # If we didn't find a matching CD pipeline
                return {
                    'success': False,
                    'error': f'Could not find CD pipeline with environment name {environment_name}'
                }
            else:
                # Handle error response
                try:
                    error_result = response.json()
                    error_message = error_result.get('errors', [{}])[0].get('userMessage', '')
                    if error_message:
                        return {
                            'success': False,
                            'error': f'API request failed: {error_message}'
                        }
                    else:
                        return {
                            'success': False,
                            'error': f'API request failed with status {response.status_code}: {response.text}'
                        }
                except:
                    # If we can't parse the error response, return the raw error
                    return {
                        'success': False,
                        'error': f'API request failed with status {response.status_code}: {response.text}'
                    }
                
        except Exception as e:
            return {
                'success': False,
                'error': f'Exception occurred: {str(e)}'
            }

    @staticmethod
    def convert_dict_to_yaml(data: dict, indent: int = 0) -> str:
        """Convert a dictionary to a YAML string representation."""
        yaml_str = ""
        for key, value in data.items():
            indentation = "  " * indent
            if isinstance(value, dict):
                yaml_str += f"{indentation}{key}:\n"
                yaml_str += DevtronUtils.convert_dict_to_yaml(value, indent + 1)
            elif isinstance(value, list):
                yaml_str += f"{indentation}{key}:\n"
                for item in value:
                    if isinstance(item, dict):
                        yaml_str += f"{indentation}  - "
                        # Handle nested dict in list
                        item_yaml = DevtronUtils.convert_dict_to_yaml(item, indent + 2).strip()
                        yaml_str += item_yaml.replace('\n', '\n  ') + '\n'
                    else:
                        yaml_str += f"{indentation}  - {item}\n"
            else:
                yaml_str += f"{indentation}{key}: {value}\n"
        return yaml_str
        
        return yaml.dump(data, indent=indent, default_flow_style=False)
    def get_application_details(self, app_id):
        """
        Fetch application details by app ID.

        Args:
            app_id (int): The ID of the application

        Returns:
            dict: Result with success status, Git Material IDs, and full application data
        """
        try:
            print(f"Fetching details for application ID: {app_id}")
            response = requests.get(
                f"{self.base_url}/orchestrator/app/get/{app_id}",
                headers=self.headers
            )

            if response.status_code == 200:
                result = response.json()
                materials = result.get("result", {}).get("material", [])
                material_ids = [material.get("id") for material in materials]
                print(f"Git Material IDs: {material_ids}")
                return {
                    "success": True,
                    "material_ids": material_ids,
                    "data": result.get("result", {})
                }
            else:
                return {
                    "success": False,
                    "error": f"Failed to fetch application details: {response.text}"
                }
        except Exception as e:
            return {
                "success": False,
                "error": f"Exception occurred: {str(e)}"
            }

    def get_workflows(self, app_id):
        """
        Fetch all workflows for an application by app ID.

        Args:
            app_id (int): The ID of the application

        Returns:
            dict: Result with success status and workflows data or error message
        """
        try:
            print(f"Fetching workflows for application ID: {app_id}")
            response = requests.get(
                f"{self.base_url}/orchestrator/app/app-wf/{app_id}",
                headers=self.headers
            )

            if response.status_code == 200:
                result = response.json()
                workflows = result.get("result", {}).get("workflows", [])
                print(f"Found {len(workflows)} workflows")
                return {
                    "success": True,
                    "workflows": workflows
                }
            else:
                return {
                    "success": False,
                    "error": f"Failed to fetch workflows: {response.text}"
                }
        except Exception as e:
            return {
                "success": False,
                "error": f"Exception occurred: {str(e)}"
            }

    def get_ci_pipelines(self, app_id):
        """
        Fetch all CI pipelines for an application by app ID.

        Args:
            app_id (int): The ID of the application

        Returns:
            dict: Result with success status and CI pipelines data or error message
        """
        try:
            print(f"Fetching CI pipelines for application ID: {app_id}")
            response = requests.get(
                f"{self.base_url}/orchestrator/app/ci-pipeline/{app_id}",
                headers=self.headers
            )

            if response.status_code == 200:
                result = response.json()
                ci_pipelines = result.get("result", {}).get("ciPipelines", [])
                print(f"Found {len(ci_pipelines)} CI pipelines")
                return {
                    "success": True,
                    "ci_pipelines": ci_pipelines
                }
            else:
                return {
                    "success": False,
                    "error": f"Failed to fetch CI pipelines: {response.text}"
                }
        except Exception as e:
            return {
                "success": False,
                "error": f"Exception occurred: {str(e)}"
            }
    def get_container_registry_id_by_name(self, registry_name):
        """
        Get container registry ID by registry name from Devtron.
        Args:
            registry_name (str): Name of the container registry
        Returns:
            dict: Result with success status and registry ID or error message
        """
        try:
            response = requests.get(
                f'{self.base_url}/orchestrator/docker/registry',
                headers=self.headers
            )
            if response.status_code == 200:
                result = response.json()
                registries = result.get('result', [])
                for registry in registries:
                    if registry.get('id') == registry_name:
                        return {
                            'success': True,
                            'registry_id': registry.get('id')
                        }
                return {
                    'success': False,
                    'error': f'Could not find container registry with name {registry_name}'
                }
            else:
                try:
                    error_result = response.json()
                    error_message = error_result.get('errors', [{}])[0].get('userMessage', '')
                    if error_message:
                        return {
                            'success': False,
                            'error': f'API request failed: {error_message}'
                        }
                    else:
                        return {
                            'success': False,
                            'error': f'API request failed with status {response.status_code}: {response.text}'
                        }
                except:
                    return {
                        'success': False,
                        'error': f'API request failed with status {response.status_code}: {response.text}'
                    }
        except Exception as e:
            return {
                'success': False,
                'error': f'Exception occurred: {str(e)}'
            }

    def get_ci_pipeline_id_by_name(self, app_id, pipeline_name):
        """
        Get CI pipeline ID by pipeline name from Devtron.
        
        Args:
            app_id (int): The ID of the application
            pipeline_name (str): Name of the CI pipeline
            
        Returns:
            dict: Result with success status and CI pipeline ID or error message
        """
        try:
            ci_pipelines_result = self.get_ci_pipelines(app_id)
            if not ci_pipelines_result['success']:
                return ci_pipelines_result
                
            ci_pipelines = ci_pipelines_result['ci_pipelines']
            for pipeline in ci_pipelines:
                if pipeline.get('name') == pipeline_name:
                    return {
                        'success': True,
                        'ci_pipeline_id': pipeline.get('id')
                    }
            
            return {
                'success': False,
                'error': f'Could not find CI pipeline with name {pipeline_name}'
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'Exception occurred: {str(e)}'
            }

    def get_ci_pipeline_details(self, app_id, ci_pipeline_id):
        """
        Get detailed information about a specific CI pipeline.
        
        Args:
            app_id (int): The ID of the application
            ci_pipeline_id (int): The ID of the CI pipeline
            
        Returns:
            dict: Result with success status and CI pipeline details or error message
        """
        try:
            response = requests.get(
                f'{self.base_url}/orchestrator/app/ci-pipeline/{app_id}/{ci_pipeline_id}',
                headers=self.headers
            )
            
            if response.status_code == 200:
                result = response.json()
                return {
                    'success': True,
                    'pipeline_details': result.get('result', {})
                }
            else:
                return {
                    'success': False,
                    'error': f'Failed to fetch CI pipeline details: {response.text}'
                }
        except Exception as e:
            return {
                'success': False,
                'error': f'Exception occurred: {str(e)}'
            }

    @staticmethod
    def compare_dicts(dict1, dict2):
        """
        Compare two dictionaries and return the differences.

        Args:
            dict1 (dict): First dictionary
            dict2 (dict): Second dictionary

        Returns:
            dict: {
                'success': bool,
                'is_differ': bool,
                'differences': str (YAML string with differences)
            }
        """
        try:
            diff = DeepDiff(dict1 or {}, dict2 or {}, ignore_order=True).to_dict()

            if diff:
                return {
                    "success": True,
                    "is_differ": True,
                    "differences": diff
                }
            else:
                return {
                    "success": True,
                    "is_differ": False,
                    "differences": None
                }

        except Exception as e:
            return {
                "success": False,
                "is_differ": False,
                "error": f"Error: {str(e)}"
            }



    def get_cd_pipeline_details(self, app_id, cd_pipeline_id):
        """
        Get detailed information about a specific CD pipeline.
        
        Args:
            app_id (int): The ID of the application
            cd_pipeline_id (int): The ID of the CD pipeline
            
        Returns:
            dict: Result with success status and CD pipeline details or error message
        """
        try:
            response = requests.get(
                f'{self.base_url}/orchestrator/app/cd-pipeline/{app_id}/{cd_pipeline_id}',
                headers=self.headers
            )
            
            if response.status_code == 200:
                result = response.json()
                return {
                    'success': True,
                    'pipeline_details': result.get('result', {})
                }
            else:
                return {
                    'success': False,
                    'error': f'Failed to fetch CD pipeline details: {response.text}'
                }
        except Exception as e:
            return {
                'success': False,
                'error': f'Exception occurred: {str(e)}'
            }

