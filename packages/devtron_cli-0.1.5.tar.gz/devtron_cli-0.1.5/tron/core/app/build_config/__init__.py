"""Build configuration handlers for tron."""

