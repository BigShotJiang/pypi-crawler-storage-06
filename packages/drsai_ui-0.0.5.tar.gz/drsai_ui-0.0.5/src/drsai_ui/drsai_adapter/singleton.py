

from .personal_config_fetcher import PersonalKeyConfigFetcher

personal_key_config_fetcher = PersonalKeyConfigFetcher()
