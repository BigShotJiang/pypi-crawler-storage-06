VERSION = "0.0.5"
__version__ = VERSION
APP_NAME = "Dr.Sai-UI"
