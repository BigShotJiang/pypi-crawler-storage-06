"""
This program immediately exits with a return code of 0
"""

import sys

sys.exit(0)
