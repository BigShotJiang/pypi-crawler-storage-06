---
title: "egse.setup"
---

!!! info "cgse-common"
    This code is part of the `cgse-common` package.


::: egse.setup
