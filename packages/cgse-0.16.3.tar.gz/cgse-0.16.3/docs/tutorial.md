---
hide:
  - navigation
---

# Tutorial

Welcome to the CGSE Tutorial!

By the end of this page you should have a solid understanding of the core features of the CGSE.
