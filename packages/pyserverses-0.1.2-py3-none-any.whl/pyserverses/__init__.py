# pyserverses/__init__.py
from .server import PyServer, html_response, json_response

__version__ = "0.1.2"
__author__ = "kote"