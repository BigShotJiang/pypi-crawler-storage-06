"""
    django-tools
    miscellaneous tools for Django based projects
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.57.0'
__author__ = 'Jens Diemer <django-tools@jensdiemer.de>'
