import django_tools


# Just the same version as the real project:
__version__ = django_tools.__version__
