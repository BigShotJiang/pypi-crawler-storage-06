"""Components for modular model generation."""
