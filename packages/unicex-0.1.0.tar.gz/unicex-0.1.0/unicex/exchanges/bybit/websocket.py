from unicex.abc import BaseSyncWebsocket


class BybitWebsocket(BaseSyncWebsocket):
    """Вебсокет для работы с Bybit WS API."""

    pass
