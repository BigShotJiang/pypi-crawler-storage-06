Plotlines
=========

Create and display Story structure.
