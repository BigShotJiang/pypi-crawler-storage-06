# mbu_dev_shared_components/solteqtand/application/__init__.py
from .app_handler import SolteqTandApp

__all__ = ["SolteqTandApp"]
