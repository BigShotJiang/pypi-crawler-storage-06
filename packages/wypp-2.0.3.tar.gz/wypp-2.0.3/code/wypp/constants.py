import os

SOURCE_DIR = os.path.normpath(os.path.dirname(__file__))
CODE_DIR = os.path.dirname(SOURCE_DIR)

# print(f'SOURCE_DIR: {SOURCE_DIR}, CODE_DIR: {CODE_DIR}')
