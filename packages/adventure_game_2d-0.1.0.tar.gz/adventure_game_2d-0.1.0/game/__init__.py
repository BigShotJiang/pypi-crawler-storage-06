from .adventure_game import run  # noqa: D104

__all__ = ["run"]
