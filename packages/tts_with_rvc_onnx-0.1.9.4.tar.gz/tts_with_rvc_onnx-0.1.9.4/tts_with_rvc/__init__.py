from .inference_onnx import *

__all__ = ["tts-with-rvc-onnx"]
__version__ = "0.1.9" 