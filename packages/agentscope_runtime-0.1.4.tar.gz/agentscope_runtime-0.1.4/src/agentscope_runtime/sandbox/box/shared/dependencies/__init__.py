# -*- coding: utf-8 -*-
from .deps import verify_secret_token


__all__ = ["verify_secret_token"]
