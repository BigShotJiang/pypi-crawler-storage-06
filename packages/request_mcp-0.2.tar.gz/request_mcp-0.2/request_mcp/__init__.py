__version__ = "0.1.0"

from .core import hello

def version():
    return __version__

