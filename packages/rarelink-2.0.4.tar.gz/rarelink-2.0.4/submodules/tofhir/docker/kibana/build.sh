# Execute the following command from the project.root.directory (../../)

docker build -f docker/kibana/Dockerfile -t srdc/tofhir-kibana:latest .