# """
# This module contains the utility functions for the RareLink-Phenopacket's 
# PhenotypicFeature mapping, including the adapter-specific utilities.
# """

# from .utils_phenotypic_feature import (
#     _determine_data_model,
#     _get_single_type,
#     _get_data_elements
# )
# __all__ = [
#     "_determine_data_model",
#     "_get_data_elements",
#     "_get_single_type"
# ]