# src/rarelink/cdm/__init__.py
__all__ = []