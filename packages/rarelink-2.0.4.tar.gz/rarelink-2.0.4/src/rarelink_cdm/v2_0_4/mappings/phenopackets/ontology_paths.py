ONTOLOGY_PATHS = {
    "HPO": "path/to/hp.obo",
    "MONDO": "path/to/mondo.obo",
    "SO": "path/to/so.obo",
    # Add more as needed
}