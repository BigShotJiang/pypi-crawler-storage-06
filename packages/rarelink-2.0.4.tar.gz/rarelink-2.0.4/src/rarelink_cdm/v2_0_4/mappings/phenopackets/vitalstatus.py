



VITAL_STATUS_BLOCK = {
    "instrument_name": "rarelink_3_patient_status",
    "status_field": "snomedct_278844005",
    "default_status": "UNKNOWN",
    "time_of_death_field": "snomedct_398299004",
    "cause_of_death_field": "snomedct_184305005"
}


