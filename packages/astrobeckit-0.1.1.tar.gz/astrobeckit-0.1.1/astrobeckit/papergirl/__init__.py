from .papergirl import papergirl

__all__ = ["papergirl"]
__version__ = "0.1.0"