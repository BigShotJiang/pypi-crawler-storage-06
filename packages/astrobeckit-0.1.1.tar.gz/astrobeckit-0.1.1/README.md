# astrobeckit

A small package full of useful little scripts for astro.

## Installation

```bash
pip install astrobeckit


## Usage

import astrobeckit

# To run papergirl (with appropriate topic and author list)
astrobeckit.papergirl()