Dataset standards
-------------------

.. toctree::
   :maxdepth: 3
   :caption: Contents:
   :glob:

   core/*
   data_formats/*
