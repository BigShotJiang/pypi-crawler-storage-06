water_valve
-------------

For an example of how to run automatic calibration of the water valves, refer to `this repository <https://github.com/AllenNeuralDynamics/Aind.Behavior.Device.WaterTuner>`_.

Example
########

.. literalinclude:: ../../../examples/water_valve.py
      :language: python