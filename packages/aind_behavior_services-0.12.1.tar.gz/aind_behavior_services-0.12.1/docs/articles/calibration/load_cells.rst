load_cells
-------------

Example
########

.. literalinclude:: ../../../examples/load_cells.py
      :language: python
