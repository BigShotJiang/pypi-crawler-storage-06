aind_manipulator
-----------------

Example
##########

.. literalinclude:: ../../../examples/aind_manipulator.py
      :language: python
