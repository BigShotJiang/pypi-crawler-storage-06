treadmill
-------------

For running the calibration of the treadmill refer to `this repository <https://github.com/AllenNeuralDynamics/harp.device.treadmill/>`_.

Example
########

.. literalinclude:: ../../../examples/treadmill.py
      :language: python