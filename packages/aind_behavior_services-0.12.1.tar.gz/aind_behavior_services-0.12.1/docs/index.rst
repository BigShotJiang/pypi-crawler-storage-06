Welcome to AIND Behavior Services's documentation!
==================================================

.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   self
   architecture
   articles
   json_schemas
   api/api
   GitHub Source Code <https://github.com/AllenNeuralDynamics/Aind.Behavior.Services>

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
