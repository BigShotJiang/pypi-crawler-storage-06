json-schema
------------
.. toctree::
   :maxdepth: 3
   :caption: Contents:
   :glob:

   json_schemas/*