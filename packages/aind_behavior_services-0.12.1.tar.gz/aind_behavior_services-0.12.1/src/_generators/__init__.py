from _generators import json_schema, rig_harp


def main():
    rig_harp.main()
    json_schema.main()


if __name__ == "__main__":
    main()
