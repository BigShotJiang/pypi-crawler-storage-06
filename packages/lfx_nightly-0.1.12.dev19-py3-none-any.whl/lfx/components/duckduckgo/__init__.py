from .duck_duck_go_search_run import DuckDuckGoSearchComponent

__all__ = ["DuckDuckGoSearchComponent"]
