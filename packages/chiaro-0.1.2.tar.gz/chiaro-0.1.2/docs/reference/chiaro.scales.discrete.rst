chiaro.scales.discrete
======================

.. automodule:: chiaro.scales.discrete

   