chiaro.core.base
================

.. automodule:: chiaro.core.base

   
   .. rubric:: Functions

   .. autosummary::
   
      detect_runtime_environment
      file_html
      overload
      show
   
   .. rubric:: Classes

   .. autosummary::
   
      Any
      ChartBase
      ColumnDataSource
      FacetCommonArgs
      Position
      Runtime
      figure
   