chiaro.core.io
==============

.. automodule:: chiaro.core.io

   
   .. rubric:: Functions

   .. autosummary::
   
      detect_runtime_environment
      get_ipython
   
   .. rubric:: Classes

   .. autosummary::
   
      Runtime
      StrEnum
      auto
   