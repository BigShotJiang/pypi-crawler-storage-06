chiaro.express.api
==================

.. automodule:: chiaro.express.api

   
   .. rubric:: Functions

   .. autosummary::
   
      bar
      line
      scatter
   
   .. rubric:: Classes

   .. autosummary::
   
      Chart
      ChartBar
      ChartLine
      ChartPoint
      LineMode
   