chiaro.geoms.bar
================

.. automodule:: chiaro.geoms.bar

   
   .. rubric:: Classes

   .. autosummary::
   
      AxisScale
      BarColorOptions
      BarGroupOptions
      BarStackOptions
      CategoricalAxisOptions
      ChartBar
      ChartBase
      ColumnDataSource
      NumericAxisOptions
      figure
   