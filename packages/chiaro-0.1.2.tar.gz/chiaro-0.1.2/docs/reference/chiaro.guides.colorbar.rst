chiaro.guides.colorbar
======================

.. automodule:: chiaro.guides.colorbar

   