chiaro.geoms.point
==================

.. automodule:: chiaro.geoms.point

   
   .. rubric:: Functions

   .. autosummary::
   
      factor_cmap
      shuffle
   
   .. rubric:: Classes

   .. autosummary::
   
      AxisScale
      ChartBase
      ChartPoint
      ColorBar
      ColorPalette
      ColumnDataSource
      LinearColorMapper
      NumericAxisOptions
      PointColorOptions
      PointSizeOptions
      PointSymbolOptions
      Title
      figure
   