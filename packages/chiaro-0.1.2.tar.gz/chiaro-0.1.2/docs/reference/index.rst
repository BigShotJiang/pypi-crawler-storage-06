API Reference
=============

.. toctree::
   :maxdepth: 2
   :glob:

   *

.. automodule:: chiaro
   :members:
   :undoc-members:
   :show-inheritance:
