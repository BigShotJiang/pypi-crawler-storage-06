chiaro.core.types
=================

.. automodule:: chiaro.core.types

   
   .. rubric:: Functions

   .. autosummary::
   
      TypedDict
   
   .. rubric:: Classes

   .. autosummary::
   
      AxisScale
      BarColorOptions
      BarGroupOptions
      BarStackOptions
      CategoricalAxisOptions
      ColorPalette
      FacetCommonArgs
      FacetDimArgs
      FacetRowColArgs
      LineColorOptions
      LineKind
      LineMode
      LineStyleOptions
      NumericAxisOptions
      PointColorOptions
      PointSizeOptions
      PointSymbolOptions
      Position
      StrEnum
      auto
   