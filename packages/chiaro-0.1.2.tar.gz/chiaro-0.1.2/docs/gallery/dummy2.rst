This example shows how to create a bar plot using Bokeh and export as PNG.
==========================================================================

Source Code
-----------

.. literalinclude:: /../example_scripts/dummy2.py
   :language: python
   :caption: Example code

Interactive Plot
----------------

.. raw:: html

   <iframe src="../_static/gallery/html/dummy2.html" width="100%" height=500 style="border:none; max-width:100%; display:block;"></iframe>
