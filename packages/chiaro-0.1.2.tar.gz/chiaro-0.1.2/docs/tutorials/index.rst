Tutorials
============

Basic Tutorials
-------------------
.. toctree::
   :maxdepth: 1
   :glob:

   notebooks/basic/*

Advanced Tutorials
---------------------
.. toctree::
   :maxdepth: 1
   :glob:

   notebooks/advanced/*
