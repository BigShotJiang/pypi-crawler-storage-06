"""
TODO Basic认证。一定要修改此处，不要使用默认值
"""
USER_CREDENTIALS = {
    "用户名": "密码",
    "admin": "password123",
    "user": "secret",
}

print(f"Current config:", __file__)
