"""Bytecode generation for Machine Dialect™."""

from .bytecode_serializer import BytecodeWriter

__all__ = ["BytecodeWriter"]
