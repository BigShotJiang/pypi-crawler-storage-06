"""Linting rules for Machine Dialect™.

This module manages the registration and execution of linting rules.
"""

from .base import Rule

__all__ = ["Rule"]
