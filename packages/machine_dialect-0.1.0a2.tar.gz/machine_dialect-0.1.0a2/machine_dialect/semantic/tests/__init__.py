"""Tests for semantic analysis components."""
