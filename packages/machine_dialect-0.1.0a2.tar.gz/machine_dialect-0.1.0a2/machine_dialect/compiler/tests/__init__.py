"""Tests for the Machine Dialect™ compiler module."""
