import device_modules.RODOS_10N as rele


rele.turn_off(1);

