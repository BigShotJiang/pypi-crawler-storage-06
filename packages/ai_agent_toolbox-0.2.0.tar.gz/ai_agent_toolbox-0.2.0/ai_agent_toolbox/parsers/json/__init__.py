from .json_parser import JSONParser

__all__ = ["JSONParser"]
