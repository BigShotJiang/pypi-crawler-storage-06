import json
import traceback
from typing import Optional, Dict, Any, List
from alibabacloud_eci20180808.client import Client as EciClient
from alibabacloud_eci20180808.models import (
    CreateContainerGroupRequest,
    DescribeContainerGroupsRequest,
    DeleteContainerGroupRequest,
    UpdateContainerGroupRequest,
    RestartContainerGroupRequest,
)
from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_tea_util import models as util_models
from arraylib.monitor.feishu import Feishu

feishu_alert = Feishu("devtoolkit服务报警")


class ECIUtils:
    def __init__(self, region_id: str, access_key_id: str, access_key_secret: str):
        """
        description:
            初始化ECI工具类
        parameters:
            region_id(str): 地域ID
            access_key_id(str): 访问密钥ID
            access_key_secret(str): 访问密钥Secret
        """
        self.region_id = region_id
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.client = self._create_client()

    def _create_client(self) -> EciClient:
        """
        description:
            创建ECI客户端
        return:
            EciClient: ECI客户端实例
        """
        config = open_api_models.Config(
            access_key_id=self.access_key_id,
            access_key_secret=self.access_key_secret,
            region_id=self.region_id,
            endpoint=f"eci.{self.region_id}.aliyuncs.com",
        )
        return EciClient(config)
