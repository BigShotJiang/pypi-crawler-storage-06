"""Fake graphql module for testing"""

# pylint: disable=invalid-name

type_defs = "This is a test"
resolvers = ["r1", "r2", "r3"]
