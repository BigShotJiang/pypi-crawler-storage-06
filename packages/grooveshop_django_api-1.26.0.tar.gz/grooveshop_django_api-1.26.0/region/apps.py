from django.apps import AppConfig


class RegionConfig(AppConfig):
    name = "region"
