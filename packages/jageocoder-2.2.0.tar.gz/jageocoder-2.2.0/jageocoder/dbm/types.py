from typing import Any, Dict

Record = Dict[str, Any]
