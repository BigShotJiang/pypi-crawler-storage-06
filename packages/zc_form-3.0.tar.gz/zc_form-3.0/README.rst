The zc.form package is a possibly temporary appendage used to hold extra
browser widgets and alternative approaches to code found in the
zope.formlib package.  Most or all of the code is created by Zope
Corporation and is intended for eventual folding into the main Zope 3
release.
