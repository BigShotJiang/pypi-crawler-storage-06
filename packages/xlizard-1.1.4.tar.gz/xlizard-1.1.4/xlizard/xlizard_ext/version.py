# Please DO NOT change this file manually.
# Add a new version in the CHANGELOG.md in the root folder instead
#
# pylint: disable=missing-docstring,invalid-name

version = "1.1.4"
