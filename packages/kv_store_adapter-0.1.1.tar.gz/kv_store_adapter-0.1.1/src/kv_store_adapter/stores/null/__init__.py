from .store import NullStore

__all__ = ["NullStore"]
