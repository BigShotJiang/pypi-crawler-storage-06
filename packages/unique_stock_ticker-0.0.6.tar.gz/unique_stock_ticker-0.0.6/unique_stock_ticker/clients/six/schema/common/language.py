from enum import StrEnum


class Language(StrEnum):
    EN = "EN"
    DE = "DE"
    FR = "FR"
    IT = "IT"
