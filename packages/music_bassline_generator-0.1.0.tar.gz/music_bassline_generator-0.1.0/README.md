# Music Bassline-Generator
Generate musical basslines
