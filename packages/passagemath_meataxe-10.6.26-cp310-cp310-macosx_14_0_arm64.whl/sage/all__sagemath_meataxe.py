# sage_setup: distribution = sagemath-meataxe
# delvewheel: patch
