This module adds the following features:

- The ability to limit the update permissions for a model to certain
  groups
- The ability to revoke update permissions for specific users
