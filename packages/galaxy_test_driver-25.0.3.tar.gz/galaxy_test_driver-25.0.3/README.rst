
.. image:: https://badge.fury.io/py/galaxy-test-driver.svg
   :target: https://pypi.org/project/galaxy-test-driver/



Overview
--------

The Galaxy_ test driver package.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
