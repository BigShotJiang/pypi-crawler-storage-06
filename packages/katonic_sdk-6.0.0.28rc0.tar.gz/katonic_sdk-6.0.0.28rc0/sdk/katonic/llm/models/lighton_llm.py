def create_lighton_model():
    pass