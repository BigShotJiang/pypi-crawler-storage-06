"""
Core Validation Tests

Tests data validation, declarative models, and validation utilities.
Focuses on the main validation functionality and real-world validation scenarios.
"""
