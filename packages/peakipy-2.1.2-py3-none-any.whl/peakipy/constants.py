from numpy import log, pi, finfo


log2 = log(2)
π = pi
tiny = finfo(float).eps
