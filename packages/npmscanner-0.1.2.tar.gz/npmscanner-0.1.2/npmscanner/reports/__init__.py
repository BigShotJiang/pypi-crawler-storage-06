from .html_generator import HTMLReportGenerator

__all__ = ['HTMLReportGenerator']
