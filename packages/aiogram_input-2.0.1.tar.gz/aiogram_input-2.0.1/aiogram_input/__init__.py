from .core import InputManager

__all__ = ('InputManager',)