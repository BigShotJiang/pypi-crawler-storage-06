from typing import TypeAlias

from pydantic import SecretStr

OTP: TypeAlias = SecretStr
Token: TypeAlias = SecretStr
