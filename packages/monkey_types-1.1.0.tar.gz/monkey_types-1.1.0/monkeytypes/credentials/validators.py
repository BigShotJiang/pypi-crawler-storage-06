import re

ntlm_hash_regex = re.compile(r"^[a-fA-F0-9]{32}$")
