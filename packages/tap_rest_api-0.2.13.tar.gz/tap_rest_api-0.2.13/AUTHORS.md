=======
Credits
=======

Development Lead
----------------

* Daigo Tanaka <daigo@anelen.co>

Contributors
------------

* Louis Goddard (ltrgoddard)
* Christian Gagnon (ReptilianBrain)
