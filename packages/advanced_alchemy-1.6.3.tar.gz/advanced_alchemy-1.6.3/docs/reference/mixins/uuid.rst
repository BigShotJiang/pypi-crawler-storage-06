====
uuid
====

.. automodule:: advanced_alchemy.mixins.uuid
    :members:
