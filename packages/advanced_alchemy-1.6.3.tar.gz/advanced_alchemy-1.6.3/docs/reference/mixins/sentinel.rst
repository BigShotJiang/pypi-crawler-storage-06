========
sentinel
========

.. automodule:: advanced_alchemy.mixins.sentinel
    :members:
