==========
exceptions
==========

.. automodule:: advanced_alchemy.exceptions
    :members:
    :show-inheritance:
