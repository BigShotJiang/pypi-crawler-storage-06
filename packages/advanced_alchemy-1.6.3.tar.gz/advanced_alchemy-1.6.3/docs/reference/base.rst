====
base
====

.. automodule:: advanced_alchemy.base
    :members:
    :imported-members:
    :undoc-members:
    :show-inheritance:
    :no-index: advanced_alchemy.base.AdvancedDeclarativeBase.registry advanced_alchemy.base.BasicAttributes.to_dict
