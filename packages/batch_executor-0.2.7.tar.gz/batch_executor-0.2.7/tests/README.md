# Tests for Batch Executor

Install the required packages:

```bash
pip install -e ".[test]"
```

Run the tests:

```bash
pytest -sv
```

