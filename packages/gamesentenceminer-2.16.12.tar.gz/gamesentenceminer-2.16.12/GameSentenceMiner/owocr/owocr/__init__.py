from GameSentenceMiner.owocr.owocr.ocr import *
