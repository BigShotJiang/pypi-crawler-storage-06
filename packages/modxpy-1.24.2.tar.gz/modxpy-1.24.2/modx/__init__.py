# You can paste your modx.py contents here or import from modx.py
from .modx import *
