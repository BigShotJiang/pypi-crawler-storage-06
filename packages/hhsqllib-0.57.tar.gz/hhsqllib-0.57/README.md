This is for lazy loading sql database
I modified the sangreal-wind because the inconsistency between the sangreal-wind and others
