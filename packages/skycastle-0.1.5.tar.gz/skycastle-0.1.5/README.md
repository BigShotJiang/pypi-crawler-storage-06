# 🏰 Sky Castle 🏰

Welcome, adventurer, to **Sky Castle**! This is a whimsical, text-based adventure game built with Python, where your wits, heart, and a little bit of imagination are your greatest tools.

Inspired by the classic tune "Just the Two of Us," this game invites you to explore a magical castle in the clouds on a quest to find your lost father.

---

## 📖 The Story

A young boy, determined and full of hope, steps into a castle made of dreams and memories. His father, a master builder of fantastical worlds, has vanished within its shimmering walls. Is he lost? Or is he just waiting for the final piece of his grand design to be put into place?

Navigate a labyrinth of enchanting rooms, solve puzzles that echo with themes of love and patience, and uncover the secrets of the Sky Castle to reunite with your father.

---

## 🎮 How to Play

Sky Castle is a classic text adventure. You'll type commands to interact with the world. The core gameplay is simple:

*   **Explore:** Move from room to room to uncover new areas.
*   **Observe:** `look` around to get descriptions of your surroundings and `look [item]` to inspect things more closely.
*   **Interact:** `take` items for your inventory, `drop` them when you need to, and `use` them to solve puzzles.
*   **Solve Puzzles:** Use your inventory and clues from the environment to overcome challenges and open new paths.
*   **Progress:** Every puzzle solved brings you one step closer to the Sky-High Summit and a reunion with your father.

### Player Commands

Here are the commands you can use to make your way through the castle:

| Command             | Description                                                              |
| :------------------ | :----------------------------------------------------------------------- |
| `go [direction/room]` | Move `north`, `south`, `east`, `west`, `up`, `down`, or to a named room. |
| `look`              | Get a description of your current room.                                  |
| `look [item]`       | Get a detailed description of a specific item.                           |
| `take [item]`       | Add an item from the room to your inventory.                             |
| `drop [item]`       | Remove an item from your inventory and leave it in the room.             |
| `inventory` or `i`  | Check what you're carrying.                                              |
| `use [item]`        | Use an item in your inventory.                                           |
| `help`              | Display a list of available commands.                                    |
| `quit`              | Exit the game.                                                           |

---

## ✨ Key Features

*   **Classic Text-Based Interface:** A true retro adventure experience.
*   **Vibrant, Colored Text:** Using `colorama` to bring the whimsical world of the Sky Castle to life.
*   **Challenging Puzzles:** Thought-provoking puzzles that are woven into the story.
*   **Event-Driven Time:** Time doesn't pass in minutes or hours, but in moments. Completing key puzzles can shift the world from dawn to morning, revealing new secrets.
*   **Persistent World:** The castle remembers. Solved puzzles and dropped items will stay right where you left them.
*   **A Heartfelt Journey:** At its core, this is a story about connection, perseverance, and building something beautiful together.

---

## 🗺️ The World of Sky Castle

The castle is a place of wonder, built from the very lyrics of the song that inspired it. Here are just a few of the places you'll discover:

*   **Crystal Atrium:** A grand entrance hall where crystal raindrops perpetually fall.
*   **Rainbow Gallery:** A beautiful hall of stained glass, waiting for you to bring back its light.
*   **Wasted Waterworks:** A cavern where misdirected energy needs a guiding hand to make flowers grow.
*   **Garden of Patience:** A dormant garden that teaches that good things come to those who wait.
*   **Father's Study:** A cozy, cluttered room full of memories, blueprints, and secrets.
*   **Dawning Outlook:** A serene glade where the morning dew holds a special magic.
*   **Sky-High Summit:** The magnificent, unfinished peak of the castle, where your journey will find its end.

---

## 🔧 Technical Details

For those who like to peek under the hood:

*   **Language:** Python
*   **Modular Design:** The game is built with separate, organized components for rooms, items, the player, and game logic.
*   **Data Structures:** `Room`, `Item`, and `Player` objects form the backbone of the game state.
*   **Command Parser:** A robust parser to interpret your commands.
*   **Text Formatting:** `colorama` for beautiful, cross-platform colored text.

Ready to start your adventure? Just the two of us... we can make it if we try!
