# `Model Inputs`

::: agents.realtime.model_inputs
