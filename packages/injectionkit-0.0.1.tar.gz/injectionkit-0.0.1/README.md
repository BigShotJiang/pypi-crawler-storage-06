# InjectionKit

![Status](https://img.shields.io/badge/Status-Work_in_progress-yellow)

Dependency Injection framework for Python.