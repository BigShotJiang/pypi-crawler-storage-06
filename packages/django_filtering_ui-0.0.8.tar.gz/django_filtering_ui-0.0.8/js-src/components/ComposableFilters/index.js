import ComposableFilters from "./ComposableFilters.vue";

export default ComposableFilters;
