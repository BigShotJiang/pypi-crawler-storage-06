2025-03-14 Version: 1.2.2
- Update API DescribeSellerInstances: update param PageIndex.
- Update API DescribeSellerInstances: update param PageSize.


2025-03-14 Version: 1.2.1
- Generated python 2022-12-30 for marketplaceIntl.

2025-03-13 Version: 1.2.0
- Support API DescribeSellerInstances.


2025-03-04 Version: 1.1.0
- Support API NoticeInstanceUser.


2025-03-03 Version: 1.0.2
- Generated python 2022-12-30 for marketplaceIntl.

2025-02-19 Version: 1.0.1
- Generated python 2022-12-30 for marketplaceIntl.

2025-01-17 Version: 1.0.0
- Update API PushMeteringData: update response param.


