import sys,os,re

from blues_lib.type.chain.AllMatchHandler import AllMatchHandler

class Uploader(AllMatchHandler):
  # upload the images to the cloud

  def resolve(self)->None:
    pass