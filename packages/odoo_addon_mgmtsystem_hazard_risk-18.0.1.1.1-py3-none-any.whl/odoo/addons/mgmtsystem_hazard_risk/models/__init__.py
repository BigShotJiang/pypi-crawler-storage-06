# Copyright (C) 2010 Savoir-faire Linux (<http://www.savoirfairelinux.com>).
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import mgmtsystem_hazard_risk_computation
from . import mgmtsystem_hazard_residual_risk
from . import mgmtsystem_hazard_risk_type
from . import mgmtsystem_hazard
from . import res_company
from . import res_config_settings
