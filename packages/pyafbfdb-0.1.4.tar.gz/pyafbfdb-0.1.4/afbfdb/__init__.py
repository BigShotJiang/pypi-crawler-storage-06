#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = "Frédéric Richard."
__copyright__ = "2022."
__credits__ = ["Frédéric Richard"]
__license__ = "GNU GENERAL PUBLIC LICENSE, Version 3."
__version__ = "0.1.4"
__maintainer__ = "Frédéric Richard"
__email__ = "frederic.richard_at_univ-amu.fr"
__status__ = "Release"


from afbfdb.Protocol import protocol

