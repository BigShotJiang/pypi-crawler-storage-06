from .atr import calcular_atr
