# mtcli-atr  
Plugin mtcli que adiciona o comando atr do indicador ATR (Average True Range).
  
---
  
## Instalação
  
```cmd
pip install mtcli-atr
```



