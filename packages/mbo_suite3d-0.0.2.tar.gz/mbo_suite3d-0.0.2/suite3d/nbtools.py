
import numpy as n
from matplotlib import pyplot as plt
from suite3d.io.tiff_utils import show_tif
