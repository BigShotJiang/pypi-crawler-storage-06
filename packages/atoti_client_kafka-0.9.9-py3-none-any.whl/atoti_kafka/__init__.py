"""Code to interact with Kafka streams."""

from .kafka_stream import KafkaStream as KafkaStream
