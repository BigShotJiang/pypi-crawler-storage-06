"""Version information for 1pass-env."""

__version__ = "0.1.0"
