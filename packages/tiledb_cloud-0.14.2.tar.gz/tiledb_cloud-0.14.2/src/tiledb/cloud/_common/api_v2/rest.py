"""Re-exporting the ``rest`` namespace."""

from tiledb.cloud.rest_api.rest import *  # noqa: F401,F403
