"Demo."

from bakalari_api.bakalari_demo import main

main()
