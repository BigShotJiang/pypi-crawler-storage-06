from phoenix.evals.legacy.models.google_genai import GoogleGenAIModel

__all__ = [
    "GoogleGenAIModel",
]
