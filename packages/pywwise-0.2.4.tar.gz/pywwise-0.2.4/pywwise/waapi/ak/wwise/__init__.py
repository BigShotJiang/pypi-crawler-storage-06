# Copyright 2024 Matheus Vilano
# SPDX-License-Identifier: Apache-2.0

from pywwise.waapi.ak.wwise.wwise import Wwise
