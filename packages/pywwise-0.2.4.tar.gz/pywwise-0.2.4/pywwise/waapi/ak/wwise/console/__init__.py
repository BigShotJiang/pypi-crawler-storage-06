# Copyright 2024 Matheus Vilano
# SPDX-License-Identifier: Apache-2.0

from pywwise.waapi.ak.wwise.console.console import Console
from pywwise.waapi.ak.wwise.console.project import Project
