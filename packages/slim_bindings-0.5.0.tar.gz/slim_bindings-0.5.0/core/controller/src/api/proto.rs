// Copyright AGNTCY Contributors (https://github.com/agntcy)
// SPDX-License-Identifier: Apache-2.0

pub mod api {
    pub mod v1 {
        include!("gen/controller.proto.v1.rs");
    }
}
