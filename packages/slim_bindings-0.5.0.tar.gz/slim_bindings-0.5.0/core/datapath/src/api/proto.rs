// Copyright AGNTCY Contributors (https://github.com/agntcy)
// SPDX-License-Identifier: Apache-2.0

pub mod pubsub {
    pub mod v1 {
        include!("gen/pubsub.proto.v1.rs");
    }
}
