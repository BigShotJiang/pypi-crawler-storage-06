from PyExtender.bcfo import *
create("test2.c")