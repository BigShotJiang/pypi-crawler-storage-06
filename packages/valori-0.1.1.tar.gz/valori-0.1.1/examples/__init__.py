"""
Examples for the Vectara vector database.
"""
