"""Pytest configuration for utils tests.

This module provides shared fixtures and configuration for all
utils package tests.
"""

import pytest
import z3