"""Utilities used internally in library."""
