# Documentation (MVP)

- Architecture overview
- Quickstart usage
- Contribution guide

