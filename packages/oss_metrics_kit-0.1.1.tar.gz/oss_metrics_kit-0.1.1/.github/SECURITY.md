# Security Policy

If you discover a vulnerability, please email security@example.com. Do not open a public issue.

