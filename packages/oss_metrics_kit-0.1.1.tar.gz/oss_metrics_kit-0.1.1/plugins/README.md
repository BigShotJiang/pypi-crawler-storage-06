# Plugins

Place external plugin templates here. Use Python entry points to register.

