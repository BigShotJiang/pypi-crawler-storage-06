"""Normalization namespace.

Map provider-specific payloads to `ossmk.core.models` entities.
Implementers can add modules under this package per provider.
"""

__all__ = []
