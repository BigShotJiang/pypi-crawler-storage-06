class MemoryBackend:
    """In-memory marker backend (not for production)."""

    name = "memory"


backend = MemoryBackend()
