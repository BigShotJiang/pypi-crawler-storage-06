from .client import GitHubProvider

provider = GitHubProvider()
