# Copyright 2020-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0


"""openfl.experimental.workflow.federated package."""

# FIXME: Recursion!
from openfl.experimental.workflow.federated.plan import Plan
