"""
AI CLI
"""
from .ai_cli import main

__all__ = ['main']

