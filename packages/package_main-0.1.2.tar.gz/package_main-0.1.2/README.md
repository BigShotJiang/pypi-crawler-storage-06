# my-package

Heegoo package example.

## Install
```bash
pip install package_main