from setuptools import setup, find_packages

setup(
    name="hellorota",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[],
    description="Funzione HelloWorld con effetto typing",
    author="Rotafn",
    author_email="rotafn@vortexmc.it",
    url="",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)