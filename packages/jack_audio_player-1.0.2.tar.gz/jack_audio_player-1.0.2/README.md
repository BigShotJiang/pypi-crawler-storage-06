# jack_audio_player

Python Jack client which plays audio files.
