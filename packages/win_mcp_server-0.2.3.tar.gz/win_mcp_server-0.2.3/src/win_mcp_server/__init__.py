"""WinRM MCP Server - MCP server for Windows Remote Management."""

__version__ = "0.2.0"

from .server import main

__all__ = ["main"]
