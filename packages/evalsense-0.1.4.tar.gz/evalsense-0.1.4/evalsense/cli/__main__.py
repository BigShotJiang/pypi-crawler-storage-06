from evalsense.cli.main import app
from evalsense.constants import APP_NAME

app(prog_name=APP_NAME)
