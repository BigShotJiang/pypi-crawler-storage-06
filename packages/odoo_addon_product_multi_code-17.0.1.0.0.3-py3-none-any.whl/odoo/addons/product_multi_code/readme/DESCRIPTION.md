This module allows multiple internal references (default_code) per product.
