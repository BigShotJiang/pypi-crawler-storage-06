"""
    Guinier.__init__.py
"""