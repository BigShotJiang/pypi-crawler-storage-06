Allows changes on the scheduled date of the pickings to be propagated
when picking moves are chained.

Propagate the date delta between the new date and the old date to the
`move_dest_ids` of the stock move being updated.
