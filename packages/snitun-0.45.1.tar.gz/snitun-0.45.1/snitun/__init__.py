"""SniTun - SNI Proxy + TCP multiplexer."""

from .utils import PROTOCOL_VERSION

__all__ = ("PROTOCOL_VERSION",)
