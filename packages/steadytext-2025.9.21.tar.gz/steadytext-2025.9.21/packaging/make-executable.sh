#!/bin/bash
# Make all build scripts executable

chmod +x build-deb.sh
chmod +x build-rpm.sh
chmod +x pgxn-upload.sh
chmod +x test-builds.sh

echo "All build scripts are now executable"