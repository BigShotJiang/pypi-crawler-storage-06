# Nested case tools
