#!/usr/bin/env bash
set -e

cargo test "$@"
