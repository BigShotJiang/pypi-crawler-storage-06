# simple-calculator-fath-alrahman-ahmed

A simple calculator package for basic math operations.

## Installation

```bash
pip install simple-calculator-fath-alrahman-ahmed
```

## Usage

```python
from simple_calculator_fath_alrahman_ahmed import add, subtract, multiply, divide

print(add(5, 3))       # Output: 8
print(subtract(5, 3))  # Output: 2
print(multiply(5, 3))  # Output: 15
print(divide(5, 3))    # Output: 1.6666666666666667
```
```

