# Copyright (C) 2023 Intel Corporation
#
# SPDX-License-Identifier: MIT

from .tile import Tile

__all__ = ["Tile"]
