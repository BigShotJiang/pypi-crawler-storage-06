class OdbResult:
    """
    用于获取结果数据
    """