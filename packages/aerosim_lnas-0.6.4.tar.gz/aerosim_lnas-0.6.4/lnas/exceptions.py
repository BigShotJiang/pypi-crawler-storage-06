class LnasVersionError(BaseException):
    """Version error reading .lnas file"""
