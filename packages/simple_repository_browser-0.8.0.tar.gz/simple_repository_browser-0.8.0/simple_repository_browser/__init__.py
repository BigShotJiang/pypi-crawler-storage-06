"""
Documentation for the simple_repository_browser package

"""

from . import _version  # type: ignore

__version__ = _version.version  # type: ignore
