# -*- coding: utf-8 -*-
"""
turkanime_api.common paketi
"""
