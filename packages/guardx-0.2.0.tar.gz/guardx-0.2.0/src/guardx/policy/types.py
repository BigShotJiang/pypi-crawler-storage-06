"""Define types for the policy package."""
# from enum import Enum
