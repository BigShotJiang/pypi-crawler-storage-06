# pybif6

[![PyPI - Version](https://img.shields.io/pypi/v/pybif6)](https://pypi.org/project/pybif6/)

This tiny project rewrites [the BIF6 file parsing part] of [the R package `tofsims`] in Python.

[the BIF6 file parsing part]: https://github.com/lorenzgerber/tofsims/blob/master/src/c_importer.cpp
[the R package `tofsims`]: https://github.com/lorenzgerber/tofsims

## Usage

```python
import pybif6

with pybif6.parse_bif6("path/to/bif6/file") as bif6_file:
    for inteval_image in bif6_file:
        print(
            f'id: {inteval_image.id}, '
            f'mz_lower: {inteval_image.mz_lower}, '
            f'mz_middle: {inteval_image.mz_middle}, '
            f'mz_upper: {inteval_image.mz_upper}, '
            f'image: {inteval_image.image.shape}'
        )
        # The image data is stored in `inteval_image.image`, a 2D numpy array.
```
