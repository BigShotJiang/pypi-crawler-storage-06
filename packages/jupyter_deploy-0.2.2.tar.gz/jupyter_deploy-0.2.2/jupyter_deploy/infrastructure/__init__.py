"""Infrastructure module for jupyter-deploy."""
