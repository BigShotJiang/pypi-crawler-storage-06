"""Console script for daksh."""

import typer

cli = typer.Typer(no_args_is_help=True)
