from .composition import register_schema_composition

__all__ = ["register_schema_composition"]
