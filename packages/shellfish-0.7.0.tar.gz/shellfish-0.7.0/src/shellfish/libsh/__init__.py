# -*- coding: utf-8 -*-
"""shellfish internals"""

from __future__ import annotations
