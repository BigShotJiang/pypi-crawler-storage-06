# -*- coding: utf-8 -*-
"""Constants"""

from __future__ import annotations

from typing import Final, Literal

a: Final[Literal["a"]] = "a"
r: Final[Literal["r"]] = "r"
w: Final[Literal["w"]] = "w"
ab: Final[Literal["ab"]] = "ab"
rb: Final[Literal["rb"]] = "rb"
wb: Final[Literal["wb"]] = "wb"
