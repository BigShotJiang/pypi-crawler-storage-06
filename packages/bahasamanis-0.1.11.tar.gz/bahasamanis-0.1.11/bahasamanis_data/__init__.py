"""Data paket Bahasa Manis: modul standar .bm (bm_standar/)
Paket ini berisi file-file .bm agar dapat terdistribusi via PyPI.
"""
