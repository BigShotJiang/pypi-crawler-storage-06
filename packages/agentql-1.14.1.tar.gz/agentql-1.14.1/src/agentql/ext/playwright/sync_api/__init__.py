from .playwright_smart_locator import Page
from .response_proxy import Locator

__all__ = ["Locator", "Page"]
