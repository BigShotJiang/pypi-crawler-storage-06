() => {
  return [
    window.document.documentElement.clientHeight,
    window.document.documentElement.scrollHeight,
    window.scrollY,
  ];
};
