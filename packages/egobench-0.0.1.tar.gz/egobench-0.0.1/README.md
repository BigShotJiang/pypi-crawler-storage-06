# egobench

A unified framework for egocentric datasets.

## Installation

```bash
pip install egobench
```
