"""
egobench - A unified framework for egocentric datasets.
"""

__version__ = "0.0.1"
__author__ = "FPV Labs"
__email__ = "contact@fpvlabs.ai"

__all__ = []