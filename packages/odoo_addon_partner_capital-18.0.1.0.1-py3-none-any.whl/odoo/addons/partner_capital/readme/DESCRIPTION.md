This module extends the functionality of partners to support setting the
country of origin of capital, registered capital amount and turnover.

By capital country we mean country of origin of the capital of the
company.

By registered capital amount we mean the amount of money registered in
the corresponding commercial registry, A.K.A. social capital or just
capital of a company.

By turnover we can define a range for a concrete amount.
