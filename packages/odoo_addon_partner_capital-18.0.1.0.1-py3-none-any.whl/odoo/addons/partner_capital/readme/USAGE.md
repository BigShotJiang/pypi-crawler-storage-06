To use this module, you need to:

- Go to any partner's form.
- You will find the new fields in *Sales & Purchases \> Capital*.

To manage turnover ranges, you need to:

- Go to *Contacts \> Configuration \> Turnover ranges*.
