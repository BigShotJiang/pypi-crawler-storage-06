"""FastAPI Radar - Debugging dashboard for FastAPI applications."""

from .radar import Radar

__version__ = "0.1.4"
__all__ = ["Radar"]
