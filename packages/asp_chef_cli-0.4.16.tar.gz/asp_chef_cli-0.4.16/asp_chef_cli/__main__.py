#!/usr/bin/env python

from asp_chef_cli.cli import run_app

if __name__ == "__main__":
    run_app()
