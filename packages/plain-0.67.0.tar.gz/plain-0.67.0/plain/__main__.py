from .cli.core import cli

# Make the CLI available as `python -m plain`
if __name__ == "__main__":
    cli()
