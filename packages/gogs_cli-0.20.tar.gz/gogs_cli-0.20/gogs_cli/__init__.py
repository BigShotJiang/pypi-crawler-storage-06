from .gogs_cli import CLI, main
