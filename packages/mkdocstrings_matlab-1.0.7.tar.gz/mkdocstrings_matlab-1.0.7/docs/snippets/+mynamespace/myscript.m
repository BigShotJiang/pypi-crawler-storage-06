% This is an example script.

% This is a paragraph. 
disp('hello world');
