function subfunction
    % This is a subfunction.
end
