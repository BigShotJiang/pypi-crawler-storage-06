??? code "Source files"

    === ":material-file-tree: tree"

        ```tree
        +mymembers
            Contents.m
            BaseClass.m
            ThisClass.m
            this_function.m
        ```

    === ":material-file-code: `Contents.m`"

        ```matlab
        --8<-- "docs/snippets/+mymembers/Contents.m"
        ```
    
    === ":material-file-code: `ThisClass.m`"

        ```matlab
        --8<-- "docs/snippets/+mymembers/ThisClass.m"
        ```

    === ":material-file-code: `BaseClass.m`"

        ```matlab
        --8<-- "docs/snippets/+mymembers/BaseClass.m"
        ```

    === ":material-file-code: `this_function.m`"

        ```matlab
        --8<-- "docs/snippets/+mymembers/this_function.m"
        ```