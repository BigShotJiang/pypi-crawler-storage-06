classdef Class
    % Summary.
    %
    % Long description.
    %
    % Warning: Deprecated
    %     Stop using this class.
    %
    % Properties:
    %     attr: Some attribute.

    properties
        attr int = 1
    end
end
