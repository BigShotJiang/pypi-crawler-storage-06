classdef NamespaceClass
% Class in namespace.
    methods
        function obj = NamespaceClass()
        end
    end
end
