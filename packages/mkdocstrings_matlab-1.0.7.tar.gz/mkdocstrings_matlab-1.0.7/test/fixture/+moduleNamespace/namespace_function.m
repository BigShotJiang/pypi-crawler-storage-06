function namespace_function()
% Function in namespace.
end
