This is the classFolder docstring
