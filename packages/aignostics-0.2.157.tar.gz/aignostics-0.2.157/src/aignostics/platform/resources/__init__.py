"""Resources exposed by the client."""
