project = "Test"
copyright = "test"
author = "test"

extensions = ["sphinx_syntax"]
