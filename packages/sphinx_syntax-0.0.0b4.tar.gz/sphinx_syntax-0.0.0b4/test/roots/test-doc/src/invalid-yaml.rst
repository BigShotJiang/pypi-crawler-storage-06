Invalid yaml
============

.. container:: regression

   .. syntax:diagram::

      - oh noo,
      this yaml is invalid!
