Objects
=======

.. container:: regression

   .. syntax:rule:: global-rule

   .. syntax:grammar:: grammar

      .. syntax:rule:: rule

   .. syntax:grammar:: name-clash

   .. syntax:rule:: name-clash
