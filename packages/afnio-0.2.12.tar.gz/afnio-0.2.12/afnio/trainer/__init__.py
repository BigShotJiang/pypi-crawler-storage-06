# afnio/trainer/__init__.py

from .trainer import Trainer

__all__ = [
    "Trainer",
]

# Please keep this list sorted
assert __all__ == sorted(__all__)
