.. automodule:: vivarium_public_health.disease.state
