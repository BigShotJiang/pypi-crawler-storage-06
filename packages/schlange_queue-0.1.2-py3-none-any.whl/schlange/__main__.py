from schlange import cli

cli.main()
