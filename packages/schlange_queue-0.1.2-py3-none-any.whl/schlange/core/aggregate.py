import dataclasses


@dataclasses.dataclass
class Aggregate:

    id: str
    version: int
