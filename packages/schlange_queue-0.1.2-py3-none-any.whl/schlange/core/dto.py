from typing import Any, Dict

DTO = Dict[str, Any]
