from .app import App


def main() -> None:
    app = App.new()
    app.run()
