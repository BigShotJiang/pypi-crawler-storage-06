#!/bin/bash
# Wrapper script for clang-tidy
exec /usr/bin/clang-tidy "$@"