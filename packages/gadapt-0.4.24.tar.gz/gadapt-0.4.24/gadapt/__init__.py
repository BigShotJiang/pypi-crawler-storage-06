"""
GAdapt genetic algorithm
"""
