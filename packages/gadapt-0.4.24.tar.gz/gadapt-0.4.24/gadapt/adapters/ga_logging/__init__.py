"""
Logging settings
"""
