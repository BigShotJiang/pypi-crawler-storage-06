"""
Population update algorithms
"""
