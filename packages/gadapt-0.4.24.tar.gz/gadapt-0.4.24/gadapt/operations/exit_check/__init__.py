"""
Techniques for exiting genetic algorithm flow.
"""
