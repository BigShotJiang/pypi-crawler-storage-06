from square_logger.main import SquareLogger, SquareCustomLogger
