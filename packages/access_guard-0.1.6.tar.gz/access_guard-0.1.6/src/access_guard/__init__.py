from .final import Access, final, final_class

__all__ = ["Access", "final", "final_class", "__version__"]

__version__ = "0.1.6"