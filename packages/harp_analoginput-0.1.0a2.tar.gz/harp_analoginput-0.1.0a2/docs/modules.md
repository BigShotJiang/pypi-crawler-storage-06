::: harp.devices.analoginput
