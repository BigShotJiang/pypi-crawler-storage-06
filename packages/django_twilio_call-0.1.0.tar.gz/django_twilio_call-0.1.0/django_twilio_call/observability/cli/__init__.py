"""CLI monitoring tools package."""
