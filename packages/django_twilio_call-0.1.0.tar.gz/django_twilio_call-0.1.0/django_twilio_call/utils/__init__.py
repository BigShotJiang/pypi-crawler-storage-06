"""Utility functions and helpers."""
