"""
This module is callable via the command line
but importing it does nothing
"""
from .install_nginx import install_nginx


def main():
    pass


if __name__ == "__main__":
    main()
