#!/bin/bash
# Install uv for our calculator mcp
curl -LsSf https://astral.sh/uv/0.8.14/install.sh | sh
