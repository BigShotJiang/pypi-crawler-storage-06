# File Organizer

[![CI](https://github.com/recregt/file-organizer/actions/workflows/python-tests.yml/badge.svg)](https://github.com/recregt/file-organizer/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![PyPI version](https://badge.fury.io/py/organize-my-files.svg)](https://pypi.org/project/organize-my-files/)

Small Python utility to organize files in a directory into subfolders by extension.

Install

    pip install organize-my-files

Usage:

Run the CLI:

    python -m organizer.cli [target] [--dry-run] [--copy] [--overwrite]

Or import the `organize` function from `organizer.core`.

Testing:

    pip install pytest
    pytest

Configuration (--config)

You can supply a JSON or TOML config that maps folder names to file extensions. Example config files are provided in the `examples/` directory:

- `examples/groups.json`
- `examples/groups.toml`

Quick example using the CLI:

    organize-my-files . --config examples/groups.toml

The CLI accepts either JSON or TOML; the implementation will try to use Python's built-in TOML parser when available and fall back to `tomli` for older Python versions.
