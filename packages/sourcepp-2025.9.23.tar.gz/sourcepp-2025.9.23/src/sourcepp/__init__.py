from ._sourcepp_impl import __doc__, bsppp, gamepp, sourcepp, steampp, toolpp, vcryptpp, vpkpp, vtfpp

__author__: str = "craftablescience"
__version__: str = "2025.9.23"
__all__: list[str] = ['__author__', '__doc__', '__version__', 'bsppp', 'gamepp', 'sourcepp', 'steampp', 'toolpp', 'vcryptpp', 'vpkpp', 'vtfpp']
