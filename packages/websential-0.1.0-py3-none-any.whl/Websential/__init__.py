# Websential/__init__.py

# استدعاء detectprotection كـ protections
from . import detect as urldetect
from . import filter as urlfilter