render = 'JSON'
source = 'national'

#D210025 -int
#30202110025U -nat
appnum_mask = ['(DU*)\\d{4}(.*\\w)', '30\\d{4}(\\d*\\w)']
