render = 'JSON'
source = 'national'

# AL/I/1996/000003
appnum_mask = 'EG/\\d*/(\\d*)'
