render = 'JSON'
source = 'national'

# UK(E) 02-0380
appnum_mask = ['UK\(E\) (\\d*)-(\\d*)', '(\\d*)-([A-Z0-9]*)-(\\d*)']
