render = 'JSON'
source = 'national'

# KEKED20141478, KEAPD2012574
appnum_mask = ['KEKED\\d{4}(\\d*)', 'KEAPD\\d{4}(\\d*)']
