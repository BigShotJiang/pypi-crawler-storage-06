render = 'JSON'
source = 'national'

# 30-2014-0003049
appnum_mask = ['30-\\d{4}-(\\d*)',
               '10-\\d{4}-(\\d*)']
