render = 'JSON'
source = 'national'

# AID2018000076
appnum_mask = ['A(\\d*)', 'AID\\d{4}(\\d*)']
