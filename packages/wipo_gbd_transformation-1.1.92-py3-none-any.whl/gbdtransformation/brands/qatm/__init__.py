render = 'JSON'
source = 'national'

# AE/321890
appnum_mask = 'QA/T/1/(\\d*)'
