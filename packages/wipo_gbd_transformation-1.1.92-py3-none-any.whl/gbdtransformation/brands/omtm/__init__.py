render = 'JSON'
source = 'national'

# OM/T/1/055758
appnum_mask = [ 'OM/T/1/(\\d*)',
                '([A-Z]{2})/T/1/(\\d*)' ]
