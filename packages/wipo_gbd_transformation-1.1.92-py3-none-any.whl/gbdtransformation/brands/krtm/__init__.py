# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

# 4520180121818
appnum_mask = '(\\d{2})\\d{4}(\\d*)'
