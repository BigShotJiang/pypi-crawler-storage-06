# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

# M200701818
# 9801818
appnum_mask = [ 'M\\d{4}(\\d*)([A-Z]{0,2}?)',
                '\\d{2}(\\d*)([A-Z]{0,2}?)' ]
