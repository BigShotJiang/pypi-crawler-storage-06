render = 'JSON'
source = 'national'

# 40-2011-0010042
# 40-M-0830042
appnum_mask = [ '40-\\d{4}-(\\d*)',
                '40-(M)-(\\d*)' ]

# 40-0017732
regnum_mask = [ '40-(\\d*)',
                'M-(.*)' ]
