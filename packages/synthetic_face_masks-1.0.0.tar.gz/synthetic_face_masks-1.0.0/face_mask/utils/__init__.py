"""Utility modules for image processing and dataset management."""
