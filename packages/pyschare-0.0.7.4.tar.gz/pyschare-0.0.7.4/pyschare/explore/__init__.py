from .data_explore import _Explore

def _init_explore():
    global explore
    explore = _Explore()

_init_explore()
