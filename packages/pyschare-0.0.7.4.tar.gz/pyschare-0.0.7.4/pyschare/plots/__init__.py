from .interactive_plots import _Visuals

def _init_plots():
    global plots
    plots = _Visuals()


_init_plots()


