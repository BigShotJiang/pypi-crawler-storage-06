To build snap run from the project root

```bash
snapcraft pack
```

and then install it with:

```bash
sudo snap install rbf-lang_*.snap --devmode
sudo snap alias rbf-lang.rbf rbf
```
