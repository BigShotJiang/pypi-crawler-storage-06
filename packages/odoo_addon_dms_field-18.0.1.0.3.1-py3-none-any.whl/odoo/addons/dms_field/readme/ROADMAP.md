- Add drag & drop compatibility to the dms_tree mode
- Multiple selection support (e.g. cut several files and paste to
  another folder).
