1. Go to the form view of an existing partner and click on the
   "DMS" tab icon, a hierarchy of folders and files linked to
   that record will be created.
2. Create a new partner. A hierarchy of folders and files
   linked to that record will be created.
