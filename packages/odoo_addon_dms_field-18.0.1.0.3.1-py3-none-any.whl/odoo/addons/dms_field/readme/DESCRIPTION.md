This addon creates a new kind of view and allows to define a folder
related to a record.
