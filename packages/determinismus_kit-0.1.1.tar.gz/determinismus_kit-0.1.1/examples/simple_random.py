# examples/simple_random.py
import random
print("Zahlen:", [random.random() for _ in range(5)])
