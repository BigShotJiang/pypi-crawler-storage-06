import sys

from thriftpyi.cli import main

if __name__ == "__main__":
    sys.exit(main())
