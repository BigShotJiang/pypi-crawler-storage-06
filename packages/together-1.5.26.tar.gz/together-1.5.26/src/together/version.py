import importlib.metadata


VERSION = importlib.metadata.version(
    "together"
)  # gets version number from pyproject.toml
