# orca/__init__.py
from .core import study

__all__ = ['study']

__version__ = "1.0.0"
__author__ = "Δrj★n"