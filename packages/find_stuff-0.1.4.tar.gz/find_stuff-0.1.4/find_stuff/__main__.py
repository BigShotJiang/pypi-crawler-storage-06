from find_stuff.cli import cli  # noqa: F401

if __name__ == "__main__":
    cli()
