"""Logger based on the framework"""

from sincpro_framework.sincpro_logger import create_logger

logger = create_logger("siat-soap-sdk")
