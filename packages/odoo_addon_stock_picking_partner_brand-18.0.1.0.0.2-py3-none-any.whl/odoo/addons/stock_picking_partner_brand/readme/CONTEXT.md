This module was developed because it is a common use case for (sub)contractors and other types of businesses to sell products under different brands.
