print('inference template placeholder')

