
# API Reference

::: spectraxgk.io_config
    options:
      show_source: false

---

::: spectraxgk.backends
    options:
      show_source: false

---

::: spectraxgk.plots
    options:
      show_source: false

---

::: spectraxgk.diagnostics
    options:
      show_source: false

---

::: spectraxgk.util
    options:
      show_source: false
````
