from sqlalchemy.orm import DeclarativeBase


class SQLEntity(DeclarativeBase): ...
