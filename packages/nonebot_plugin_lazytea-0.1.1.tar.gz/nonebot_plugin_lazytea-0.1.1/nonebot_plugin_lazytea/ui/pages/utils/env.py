import os
IS_RUN_ALONE = not os.getenv("LAUNCHASCHILD", False)
