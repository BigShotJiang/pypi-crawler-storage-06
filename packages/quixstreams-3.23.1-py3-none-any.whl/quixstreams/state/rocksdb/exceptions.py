from quixstreams.state.exceptions import StateError

__all__ = ("RocksDBCorruptedError",)


class RocksDBCorruptedError(StateError): ...
