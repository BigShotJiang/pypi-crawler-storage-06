# eKuiper

This is the python SDK for [LF Edge eKuiper](https://github.com/lf-edge/ekuiper) to create portable plugins.