To associate orders to Helpdesk tickets:

1.  Create or modify a Helpdesk ticket.
2.  In the ticket view, you will find a **Sales Order** Smartbutton
    which will show the number of orders associated to the ticket.
3.  Clicking on the Smartbutton will open a view with all the sales
    orders related to the current ticket.
4.  To create an order associated to the ticket click on the **Create**
    button.
