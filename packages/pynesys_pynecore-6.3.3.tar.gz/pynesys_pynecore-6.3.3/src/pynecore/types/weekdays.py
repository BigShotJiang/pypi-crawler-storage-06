from enum import IntEnum


class Weekdays(IntEnum):
    Sun = 6
    Mon = 0
    Tue = 1
    Wed = 2
    Thu = 3
    Fri = 4
    Sat = 5
