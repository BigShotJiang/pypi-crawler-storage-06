from .base import StrLiteral


class Earnings(StrLiteral):
    ...
