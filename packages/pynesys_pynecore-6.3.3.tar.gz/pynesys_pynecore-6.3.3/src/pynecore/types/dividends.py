from .base import StrLiteral


class Dividends(StrLiteral):
    ...
