from .base import IntEnum


class Display(IntEnum):
    ...
