#
# Constants
#
none = 0
dividends = 1
splits = 2
