
DIVIDER = ''

PARAMS = {
    'label': 'Update Textures(s)'
}

def command(*args, **kwargs):
    import cg3dcasc
    cg3dcasc.update_textures()