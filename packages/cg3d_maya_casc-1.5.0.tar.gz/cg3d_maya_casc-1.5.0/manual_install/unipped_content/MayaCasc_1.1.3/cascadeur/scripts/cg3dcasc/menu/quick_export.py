

PARAMS = {
    'label': 'Quick Export'
}


def command(*args, **kwargs):
    import cg3dcasc
    cg3dcasc.smart_export()