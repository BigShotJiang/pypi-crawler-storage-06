"""z/OS MCP Client for Amazon Q CLI"""
__version__ = "1.0.0"
