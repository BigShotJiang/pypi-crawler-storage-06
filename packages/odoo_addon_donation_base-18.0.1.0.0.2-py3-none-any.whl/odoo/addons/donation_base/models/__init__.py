from . import product
from . import res_partner
from . import donation_tax_receipt
