To configure this module, you need to:

> - create donation products
> - set the *Tax Receipt Option* on partners
