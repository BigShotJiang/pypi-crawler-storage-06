This is the base module for donations. This module doesn't do anything
in itself ; it just adds some properties on products and partners and
adds the *donation.tax.receipt* object.

To get some real features, you should install the *donation* or the
*donation_sale* module. To understand the difference between these 2
modules, read [this post](https://github.com/OCA/donation/issues/22).
