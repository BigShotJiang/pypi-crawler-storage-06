# -*- coding: utf-8 -*-

CLIENT = "client"
SERVER = "server"