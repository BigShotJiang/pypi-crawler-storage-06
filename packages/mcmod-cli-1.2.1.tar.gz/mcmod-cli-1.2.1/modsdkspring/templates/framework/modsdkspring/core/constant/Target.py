# -*- coding: utf-8 -*-

DEFAULT = "default"