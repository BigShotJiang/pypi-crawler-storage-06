﻿# -*- coding: utf-8 -*-
"""配置管理层的公共导出。"""

from .config_manager import ConfigManager

__all__ = ['ConfigManager']
