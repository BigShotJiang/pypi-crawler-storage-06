﻿# -*- coding: utf-8 -*-
"""UI 辅助层的公共导出。"""

from .ui_manager import UIManager

__all__ = ['UIManager']
