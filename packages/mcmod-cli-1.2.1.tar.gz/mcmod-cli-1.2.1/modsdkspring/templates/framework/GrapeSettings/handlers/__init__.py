﻿# -*- coding: utf-8 -*-
"""事件处理层的公共导出。"""

from .event_handler import EventHandler

__all__ = ['EventHandler']
