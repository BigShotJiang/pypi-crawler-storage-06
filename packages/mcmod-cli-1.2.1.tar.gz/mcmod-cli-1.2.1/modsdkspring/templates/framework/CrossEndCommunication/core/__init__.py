# -*- coding: utf-8 -*-
"""
CrossEndCommunication 核心模块
"""