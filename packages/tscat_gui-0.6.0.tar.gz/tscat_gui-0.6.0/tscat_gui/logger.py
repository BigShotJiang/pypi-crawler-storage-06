import logging

log = logging.getLogger("tscat-gui")
