from PySide6 import QtCore

UUIDDataRole = QtCore.Qt.UserRole + 1  # type: ignore
EntityRole = QtCore.Qt.UserRole + 2  # type: ignore

PathAttributeName = 'path__'
