===========================
Time series catalogue - GUI
===========================


.. image:: https://img.shields.io/pypi/v/tscat_gui.svg
        :target: https://pypi.python.org/pypi/tscat_gui

.. image:: https://img.shields.io/travis/SciQLop/tscat_gui.svg
        :target: https://travis-ci.com/SciQLop/tscat_gui

.. image:: https://readthedocs.org/projects/tscat-gui/badge/?version=latest
        :target: https://tscat-gui.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Time-series catalogue - graphical user interface library


* Free software: GNU General Public License v3
* Documentation: https://tscat-gui.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
