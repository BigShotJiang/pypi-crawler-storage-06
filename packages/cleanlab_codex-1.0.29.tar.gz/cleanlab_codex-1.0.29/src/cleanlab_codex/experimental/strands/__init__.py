"""Methods to integrate with AI Agents built using the AWS Strands framework."""

from cleanlab_codex.experimental.strands.cleanlab_model import CleanlabModel

__all__ = ["CleanlabModel"]
