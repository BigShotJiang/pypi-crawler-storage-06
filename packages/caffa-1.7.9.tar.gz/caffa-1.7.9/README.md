# caffa-python
Python REST client code for the [Caffa Application Framework](http://github.com/lindkvis/caffa).

# Licensing
Caffa-Python is distributed under the LGPL license, meaning it is acceptable to use it in commercial software without releasing the source of the commercial software, while modifications to Caffa Python itself should be made available.

Technically if you distribute software using this library you should accompany your software with a written offer for the source code of Caffa Python. However, if you are using it unmodified, we suggest just asking any interested parties to download the source code from the [Caffa Python] (http://github.com/lindkvis/caffa-python) repository directly.
