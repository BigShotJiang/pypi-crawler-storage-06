# snakemake-software-deployment-plugin-conda

A Snakemake software deployment plugin for conda packages, using [py-rattler](https://conda.github.io/rattler/py-rattler) for ultra fast and robust environment deployment.