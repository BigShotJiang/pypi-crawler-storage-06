# `FastGPs`: Fast Gaussian Process Regression Models in Python

[![](https://img.shields.io/badge/Docs-6b03fc)](https://alegresor.github.io/fastgps/)
[![](https://img.shields.io/badge/GitHub-15bfa9)](https://github.com/alegresor/fastgps)
[![PyPI Downloads](https://img.shields.io/pypi/dm/fastgps.svg?label=PyPI%20downloads)](https://pypi.org/project/fastgps/)

```bash
pip install fastgps
```

