Errors
======

.. automodule:: ansys.simai.core.errors
  :members:
