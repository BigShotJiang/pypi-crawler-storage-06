Static files can be found here (like images and other assets).
