# [Claude-Opus-3](https://poe.com/Claude-Opus-3){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Input Text | 585 points/1k tokens |
| Input Image | 585 points/1k tokens |
| Bot Message | 1918 points/message |
| Chat History | Input rates are applied |
| Chat History Cache Discount | 90% discount oncached chat history |
| Initial Points Cost | 2052+ points |

**Last Checked:** 2025-08-05 23:16:22.197900


## Bot Information

**Creator:** @anthropic

**Description:** Anthropic's Claude Opus 3 can handle complex analysis, longer tasks with multiple steps, and higher-order math and coding tasks. Supports 200k tokens of context (approximately 150k English words).

**Extra:** Powered by Anthropic: claude-3-opus-20240229. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Claude-Opus-3`

**Object Type:** model

**Created:** 1709574492024

**Owned By:** poe

**Root:** Claude-Opus-3
