# [Bagoodex-Web-Search](https://poe.com/Bagoodex-Web-Search){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Initial Points Cost | 650 points |
| Per Search | 650 points |

**Last Checked:** 2025-09-20 11:39:33.052634


## Bot Information

**Creator:** @empiriolabsai

**Description:** Bagoodex delivers real-time AI-powered web search offering instant access to videos, images, weather, and more. Audio and video uploads are not supported at this time.

**Extra:** Powered by a server managed by @empiriolabsai. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `Bagoodex-Web-Search`

**Object Type:** model

**Created:** 1753947757043

**Owned By:** poe

**Root:** Bagoodex-Web-Search
