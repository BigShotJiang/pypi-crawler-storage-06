# [ChatGPT-4o-Latest](https://poe.com/ChatGPT-4o-Latest){ .md-button .md-button--primary }

## Pricing

| Type | Cost |
|------|------|
| Input Text | 150 points/1k tokens |
| Input Image | 150 points/1k tokens |
| Bot Message | 302 points/message |
| Chat History | Input rates are applied |
| Initial Points Cost | 335+ points |

**Last Checked:** 2025-08-05 23:15:47.594449


## Bot Information

**Creator:** @openai

**Description:** Dynamic model continuously updated to the current version of GPT-4o in ChatGPT. Stronger than GPT-3.5 in quantitative questions (math and physics), creative writing, and many other challenging tasks. Supports context window of 128k tokens, cannot generate images.

**Extra:** Powered by OpenAI: chatgpt-4o-latest. Learn more


## Architecture

**Input Modalities:** text

**Output Modalities:** text

**Modality:** text->text


## Technical Details

**Model ID:** `ChatGPT-4o-Latest`

**Object Type:** model

**Created:** 1723609331341

**Owned By:** poe

**Root:** ChatGPT-4o-Latest
