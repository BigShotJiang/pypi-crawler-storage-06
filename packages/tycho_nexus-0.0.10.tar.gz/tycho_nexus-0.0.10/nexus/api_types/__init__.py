"""

Nexus API raw response data types.

"""
