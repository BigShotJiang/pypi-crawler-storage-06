# Dinkar_Pattern
This is a simple Package to print a patterns

# Installation
Install it using pip:
pip install Dinkar_Pattern

from Pattern import (pyramid, right_angle, left_angle)

# right_angle
pyramid(5)
