__all__ = ["version", "version_info"]


version = "0.5.1"
version_info = (0, 5, 1, "final", 0)
