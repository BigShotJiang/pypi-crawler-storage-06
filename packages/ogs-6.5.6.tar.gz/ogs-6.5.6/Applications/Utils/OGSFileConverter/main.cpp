/**
 * \file
 * \copyright
 * Copyright (c) 2012-2025, OpenGeoSys Community (http://www.opengeosys.org)
 *            Distributed under a Modified BSD License.
 *              See accompanying file LICENSE.txt or
 *              http://www.opengeosys.org/project/license
 */

#include <tclap/CmdLine.h>

#include <QApplication>
#include <clocale>

#include "InfoLib/GitInfo.h"
#include "OGSFileConverter.h"

int main(int argc, char* argv[])
{
    TCLAP::CmdLine cmd(
        "A conversion tool for ogs5 and ogs6 files.\n\n"
        "OpenGeoSys-6 software, version " +
            GitInfoLib::GitInfo::ogs_version +
            ".\n"
            "Copyright (c) 2012-2025, OpenGeoSys Community "
            "(http://www.opengeosys.org)",
        ' ', GitInfoLib::GitInfo::ogs_version);
    TCLAP::ValueArg<std::string> gmsh_path_arg(
        "g", "gmsh-path",
        "Input (.msh). The path to the input gmsh binary file", false, "",
        "INPUT_FILE");
    cmd.add(gmsh_path_arg);
    cmd.parse(argc, argv);
    QApplication app(argc, argv);
    setlocale(LC_NUMERIC, "C");
    auto* fc = new OGSFileConverter(gmsh_path_arg.getValue());
    fc->setWindowTitle(fc->windowTitle());
    fc->show();
    int returncode = QApplication::exec();
    delete fc;

    return returncode;
}
