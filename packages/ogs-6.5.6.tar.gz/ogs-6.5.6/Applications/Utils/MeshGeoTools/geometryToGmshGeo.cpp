/**
 * \file
 * \brief  A small tool to create a gmsh geometry out of gml geometry.
 *
 * \copyright
 * Copyright (c) 2012-2025, OpenGeoSys Community (http://www.opengeosys.org)
 *            Distributed under a Modified BSD License.
 *              See accompanying file LICENSE.txt or
 *              http://www.opengeosys.org/project/license
 */

#include <tclap/CmdLine.h>

#include "Applications/FileIO/Gmsh/GMSHInterface.h"
#include "BaseLib/Logging.h"
#include "BaseLib/MPI.h"
#include "BaseLib/TCLAPArguments.h"
#include "GeoLib/GEOObjects.h"
#include "GeoLib/IO/XmlIO/Boost/BoostXmlGmlInterface.h"
#include "InfoLib/GitInfo.h"

int main(int argc, char* argv[])
{
    TCLAP::CmdLine cmd(
        "Tool to create gmsh geometry (geo-file) out of a gml geometry.\n\n"
        "OpenGeoSys-6 software, version " +
            GitInfoLib::GitInfo::ogs_version +
            ".\n"
            "Copyright (c) 2012-2025, OpenGeoSys Community "
            "(http://www.opengeosys.org)",
        ' ', GitInfoLib::GitInfo::ogs_version);
    TCLAP::ValueArg<std::string> geo_output_arg(
        "o", "output", "Output (.geo) gmsh geometry file ", true, "",
        "OUTPUT_FILE");
    cmd.add(geo_output_arg);
    TCLAP::MultiArg<std::string> geo_input_arg(
        "i", "input", "Input (.gml) geometry file", true, "INPUT_FILE");
    cmd.add(geo_input_arg);
    TCLAP::ValueArg<unsigned> max_number_of_points_in_quadtree_leaf_arg(
        "", "max_points_in_quadtree_leaf", "positive number/ (min = 0)", false,
        2, "POINTS_QUADTREE");
    cmd.add(max_number_of_points_in_quadtree_leaf_arg);
    TCLAP::ValueArg<double> mesh_density_scaling_points_arg(
        "", "mesh_density_scaling_at_points",
        "positive floating point number, (min = 0)", false, 0.2,
        "SCALING_POINTS");
    cmd.add(mesh_density_scaling_points_arg);
    TCLAP::ValueArg<double> mesh_density_scaling_stations_arg(
        "", "mesh_density_scaling_at_stations",
        "positive floating point number, (min = 0)", false, 0.05,
        "SCALING_STATIONS");
    cmd.add(mesh_density_scaling_stations_arg);
    TCLAP::ValueArg<double> average_point_density_arg(
        "a", "average_point_density",
        "average point density / average edge length as a positive floating "
        "point number, (min = 0)",
        false, 1, "AVERAGE_POINT_DENSITY");
    cmd.add(average_point_density_arg);
    TCLAP::SwitchArg homogeneous_flag(
        "", "homogeneous", "Use Gmsh homogeneous meshing method.", false);
    cmd.add(homogeneous_flag);
    TCLAP::ValueArg<std::string> merged_geometries_output(
        "", "write_merged_geometries",
        "Output (.gml). File name for the output of the internal created "
        "geometry (useful for debugging the data)",
        false, "", "OUTPUT_FILE");
    cmd.add(merged_geometries_output);
    auto log_level_arg = BaseLib::makeLogLevelArg();
    cmd.add(log_level_arg);

    cmd.parse(argc, argv);

    BaseLib::MPI::Setup mpi_setup(argc, argv);
    BaseLib::initOGSLogger(log_level_arg.getValue());

    GeoLib::GEOObjects geo_objects;
    for (auto const& geometry_name : geo_input_arg.getValue())
    {
        GeoLib::IO::BoostXmlGmlInterface xml(geo_objects);
        try
        {
            if (!xml.readFile(geometry_name))
            {
                return EXIT_FAILURE;
            }
        }
        catch (std::runtime_error const& err)
        {
            ERR("Failed to read file '{:s}'.", geometry_name);
            ERR("{:s}", err.what());
            return EXIT_FAILURE;
        }
        INFO("Successfully read file '{:s}'.", geometry_name);
    }

    auto const geo_names = geo_objects.getGeometryNames();

    bool const rotate = false;
    bool const keep_preprocessed_geometry = false;

    try
    {
        if (homogeneous_flag.getValue())
        {  // homogeneous meshing
            double const average_mesh_density =
                average_point_density_arg.getValue();
            FileIO::GMSH::GMSHInterface gmsh_io(
                geo_objects, true,
                FileIO::GMSH::MeshDensityAlgorithm::FixedMeshDensity,
                average_mesh_density, 0.0, 0, geo_names, rotate,
                keep_preprocessed_geometry);
            BaseLib::IO::writeStringToFile(gmsh_io.writeToString(),
                                           geo_output_arg.getValue());
        }
        else
        {  // adaptive meshing
            unsigned const max_number_of_points_in_quadtree_leaf =
                max_number_of_points_in_quadtree_leaf_arg.getValue();
            double const mesh_density_scaling_points =
                mesh_density_scaling_points_arg.getValue();
            double const mesh_density_scaling_stations =
                mesh_density_scaling_stations_arg.getValue();
            FileIO::GMSH::GMSHInterface gmsh_io(
                geo_objects, true,
                FileIO::GMSH::MeshDensityAlgorithm::AdaptiveMeshDensity,
                mesh_density_scaling_points, mesh_density_scaling_stations,
                max_number_of_points_in_quadtree_leaf, geo_names, rotate,
                keep_preprocessed_geometry);
            BaseLib::IO::writeStringToFile(gmsh_io.writeToString(),
                                           geo_output_arg.getValue());
        }
    }
    catch (std::runtime_error& error)
    {
        ERR("{}", error.what());
        if (merged_geometries_output.isSet())
        {
            GeoLib::IO::BoostXmlGmlInterface xml(geo_objects);
            xml.export_name = geo_objects.getGeometryNames().back();
            BaseLib::IO::writeStringToFile(xml.writeToString(),
                                           merged_geometries_output.getValue());
        }
        else
        {
            INFO(
                "Hint: Using the command line flag "
                "'--write_merged_geometries buggy_geometry.gml' allows "
                "for better analysis of the problem.");
        }
        ERR("An error has occurred - programme will be terminated.");
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
