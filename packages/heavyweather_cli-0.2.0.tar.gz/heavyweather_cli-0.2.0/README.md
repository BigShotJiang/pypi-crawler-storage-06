# ws-cli

## TODO
[] - Autocompletion