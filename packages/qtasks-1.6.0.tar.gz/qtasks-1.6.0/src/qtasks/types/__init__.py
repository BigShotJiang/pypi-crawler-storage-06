"""QTasks type annotations."""

from .annotations import P, R
