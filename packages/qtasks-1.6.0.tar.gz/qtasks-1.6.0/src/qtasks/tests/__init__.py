"""Init tests."""

from .sync_testcase import SyncTestCase
from .async_testcase import AsyncTestCase
