"""Init asyncio."""

from .qtasks import QueueTasks
