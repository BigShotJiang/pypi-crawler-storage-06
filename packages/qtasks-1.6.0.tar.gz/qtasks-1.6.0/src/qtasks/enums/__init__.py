"""Init Enums."""

from .task_status import TaskStatusEnum
