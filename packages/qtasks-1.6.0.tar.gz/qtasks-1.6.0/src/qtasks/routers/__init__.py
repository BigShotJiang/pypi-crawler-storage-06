"""Init Routers."""

from .router import Router
