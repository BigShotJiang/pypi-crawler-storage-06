"""Init Test plugins."""

from .sync_test import SyncTestPlugin
from .async_test import AsyncTestPlugin
