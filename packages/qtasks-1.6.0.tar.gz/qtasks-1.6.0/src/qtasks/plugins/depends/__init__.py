"""Init Depends plugin."""

from .sync_depends import SyncDependsPlugin
from .async_depends import AsyncDependsPlugin

from .class_depends import Depends
