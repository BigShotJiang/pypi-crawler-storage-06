"""Init Exceptions."""

from .task import TaskCancelError
from .plugins import TaskPluginTriggerError
