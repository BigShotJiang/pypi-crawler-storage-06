"""Init executors."""

from .sync_task_executor import SyncTaskExecutor
from .async_task_executor import AsyncTaskExecutor
