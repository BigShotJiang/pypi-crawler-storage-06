"""Init Django contrib."""

from .autodiscover import autodiscover_tasks
