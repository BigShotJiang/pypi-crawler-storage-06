"""Init Base QTasks."""

from .qtasks import BaseQueueTasks
