"""Init middlewares."""

from .task import TaskMiddleware
