"""Init module for timers."""

from .sync_timer import SyncTimer, CronTrigger
from .async_timer import AsyncTimer
