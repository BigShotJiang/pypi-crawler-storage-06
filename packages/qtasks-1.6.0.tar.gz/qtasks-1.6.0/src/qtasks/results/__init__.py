"""Init Results."""

from .sync_result import SyncResult
from .async_result import AsyncResult
