"""Init Registries."""

from .task_registry import TaskRegistry
from .sync_task_decorator import SyncTask
from .async_task_decorator import AsyncTask
