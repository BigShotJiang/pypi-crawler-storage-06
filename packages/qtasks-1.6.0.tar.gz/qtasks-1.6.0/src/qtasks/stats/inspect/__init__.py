"""Init Inspect Stats."""

from .base import UtilsInspectStats
from .inspect import InspectStats
