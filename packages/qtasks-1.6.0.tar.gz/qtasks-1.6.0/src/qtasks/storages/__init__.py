"""Init storages."""

from .async_redis import AsyncRedisStorage
from .sync_redis import SyncRedisStorage
