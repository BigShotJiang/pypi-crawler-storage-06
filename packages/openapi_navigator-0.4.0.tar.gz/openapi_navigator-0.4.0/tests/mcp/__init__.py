# MCP integration tests
