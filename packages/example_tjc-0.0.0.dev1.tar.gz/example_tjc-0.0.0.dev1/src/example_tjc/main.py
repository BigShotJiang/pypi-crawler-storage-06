def increment(num: int) -> int:
    return num + 1
