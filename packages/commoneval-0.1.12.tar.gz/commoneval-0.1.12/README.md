# CommonEval

Repo for staging LLM evaluation benchmarks.

You are encouraged to use the data here for evaluating LLMs against
standards for Christian faith and human flourishing. Please do **not**
use these files for fine-tuning, since that compromises their ability
to measure LLM performance fairly.


