class CocoApplication:
    def run(self) -> None:
        return None
