"""coco_core

A middleware rich backend framework for building APIs.
"""

__version__ = "0.0.1"

from .app import CocoApplication

__all__ = ["__version__", "CocoApplication"]
