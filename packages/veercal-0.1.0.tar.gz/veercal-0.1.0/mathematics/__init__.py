# This file makes the mathematics directory a Python package
from mathematics.basic_math import *
from mathematics.advance_math import *
