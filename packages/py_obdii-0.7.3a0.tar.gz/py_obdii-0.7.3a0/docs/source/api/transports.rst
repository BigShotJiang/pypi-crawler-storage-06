.. title:: Transports API

Transports
==========

.. automodule:: obdii.transports
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__, __call__
    :inherited-members:

.. automodule:: obdii.transports.transport_base
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__, __call__
    :inherited-members: