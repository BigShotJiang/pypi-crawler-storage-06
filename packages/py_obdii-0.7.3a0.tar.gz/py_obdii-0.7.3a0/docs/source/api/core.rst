.. title:: Core API

Core
====

.. automodule:: obdii
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__, __call__
    :inherited-members: