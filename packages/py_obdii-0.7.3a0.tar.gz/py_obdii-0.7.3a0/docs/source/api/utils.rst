.. title:: Utils API

Utils
=====

.. automodule:: obdii.utils.scan
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__, __call__
    :inherited-members: