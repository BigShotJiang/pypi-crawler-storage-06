.. title:: Commands API

Modes/Commands
==============

.. automodule:: obdii.modes
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__, __call__
    :inherited-members:

.. automodule:: obdii.modes.group_commands
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__, __call__
    :inherited-members: