.. title:: Protocols API

Protocols
=========

.. automodule:: obdii.protocols
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__, __call__
    :inherited-members:

.. automodule:: obdii.protocols.protocol_base
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__, __call__
    :inherited-members: