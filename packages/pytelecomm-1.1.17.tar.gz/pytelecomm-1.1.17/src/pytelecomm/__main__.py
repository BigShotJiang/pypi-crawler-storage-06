from . import run_notebook

run_notebook()
