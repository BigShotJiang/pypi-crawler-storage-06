=====
Usage
=====

To use snappl in a project::

    import snappl
