# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import (
    auth_saml_attribute_mapping,
    auth_saml_provider,
    auth_saml_request,
    ir_config_parameter,
    res_config_settings,
    res_users,
    res_users_saml,
)
