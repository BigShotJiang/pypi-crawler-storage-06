Users can login with the configured SAML IdP with buttons added in the
login screen.
