"""Environment variables used in the sandbox."""

# ==== [ Environment variable names ] ====
FEATURE_FLAGS_BASE64 = "FEATURE_FLAGS_BASE64"
REPO_CONFIG_BASE64 = "REPO_CONFIG_BASE64"
GITHUB_TOKEN = "GITHUB_TOKEN"
