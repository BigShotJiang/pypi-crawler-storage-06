"""Code for fetching attributions from 3rd party products."""
