PyType = "PyUnionType[Parent] | PyNamedType[Parent] | PyGenericType[Parent] | NoneType"
__all__ = ["PyType"]
