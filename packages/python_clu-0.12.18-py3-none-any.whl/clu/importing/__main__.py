# -*- coding: utf-8 -*-
from __future__ import print_function
from clu.importing import test
import sys # pragma: no cover

if __name__ == '__main__':
    sys.exit(test())