__version__ = "2.0.2"
# You must change the version in parser = pydantic_argparse.ArgumentParser in cli_pydantic.py!!!
