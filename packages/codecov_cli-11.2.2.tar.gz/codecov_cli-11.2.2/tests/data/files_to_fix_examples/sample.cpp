
{ // wubba lubba dub dub
    
}
// LCOV_EXCL_BEGIN
Hello
// LCOV_EXCL_START
// LCOV_EXCL_END
{
    
}
not empty
// LCOV_EXCL_STOP
