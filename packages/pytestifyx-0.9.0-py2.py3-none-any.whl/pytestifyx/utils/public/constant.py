# 数据库相关的常量
Query_Success = '查询到结果成功'
Query_None = '查询到结果为空'
Query_Fail = '查询失败'
