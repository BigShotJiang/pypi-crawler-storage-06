__all__ = ["version", "version_info"]


version = "0.6.1"
version_info = (0, 6, 1, "final", 0)
