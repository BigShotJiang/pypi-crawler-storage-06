from .decorators import autolog as autolog
