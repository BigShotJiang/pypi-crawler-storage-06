# -*- coding: utf-8 -*-
"""
Internal utilities and platform-specific code for vindauga.

This package contains internal implementation details that are not part
of the public API and may change between versions.
"""
__author__ = 'akm'
