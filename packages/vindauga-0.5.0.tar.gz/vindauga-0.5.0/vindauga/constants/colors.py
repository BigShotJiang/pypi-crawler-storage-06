# -*- coding: utf-8 -*-
cmColorForegroundChanged = 71
cmColorBackgroundChanged = 72
cmColorSet = 73
cmNewColorItem = 74
cmNewColorIndex = 75
cmSaveColorIndex = 76
cmSetColorIndex = 77
