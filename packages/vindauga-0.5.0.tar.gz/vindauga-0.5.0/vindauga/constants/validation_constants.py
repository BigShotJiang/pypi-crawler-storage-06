# -*- coding: utf-8 -*-

vsOK = 0
vsSyntax = 1

voFill = 0x0001
voTransfer = 0x0002
voReserved = 0x00FC

vtDataSize = 0
vtSetData = 1
vtGetData = 2
