#!/usr/bin/python
# coding: utf-8
from repository_manager.repository_manager_mcp import repository_manager_mcp

if __name__ == "__main__":
    repository_manager_mcp()
