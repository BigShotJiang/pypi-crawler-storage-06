from typing import TypedDict


class Usage(TypedDict):
    inputTokens: int
    outputTokens: int
    totalTokens: int
