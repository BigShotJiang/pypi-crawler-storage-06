class Unspecified():
    def __repr__(self):
        return 'OPTIONAL'


UNSPECIFIED = Unspecified()
