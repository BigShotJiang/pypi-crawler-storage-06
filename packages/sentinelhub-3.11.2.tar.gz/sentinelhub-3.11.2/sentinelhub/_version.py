"""Version of the sentinelhub package."""

__version__ = "3.11.2"
