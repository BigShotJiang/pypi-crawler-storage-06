"""Ghost MCP Server - Comprehensive Ghost CMS integration for MCP."""

__version__ = "0.1.0"
__author__ = "Ghost MCP Team"
__description__ = "Ghost CMS MCP server providing comprehensive Ghost API access"