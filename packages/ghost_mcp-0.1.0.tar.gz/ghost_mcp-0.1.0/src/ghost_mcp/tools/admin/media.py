"""Admin API tools for media management."""

from fastmcp import FastMCP


def register_admin_media_tools(mcp: FastMCP) -> None:
    """Register media management Admin API tools."""
    # Media upload and management tools would go here
    pass