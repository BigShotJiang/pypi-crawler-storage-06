"""Admin API tools for settings management."""

from fastmcp import FastMCP


def register_admin_settings_tools(mcp: FastMCP) -> None:
    """Register settings management Admin API tools."""
    # Settings management tools would go here
    pass