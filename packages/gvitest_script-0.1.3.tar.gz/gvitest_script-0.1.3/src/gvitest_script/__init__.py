"""
Script Server - Jinja2 模板引擎脚本生成器

基于 Jinja2 模板引擎的脚本生成系统，用于重构现有的脚本生成功能。
支持预期结果列表、实时状态追踪、独立日志文件等核心新需求。
"""

__version__ = "0.1.0"
__author__ = "G-Vitest Team" 