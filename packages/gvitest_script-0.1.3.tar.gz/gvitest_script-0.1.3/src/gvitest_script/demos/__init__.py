"""
演示脚本包

包含各种演示脚本：
- demo.py: 核心功能演示
- websocket_demo.py: WebSocket实时推送演示
"""
