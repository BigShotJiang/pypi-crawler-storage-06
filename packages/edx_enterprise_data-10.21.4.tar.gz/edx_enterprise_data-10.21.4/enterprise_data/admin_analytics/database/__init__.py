"""
This module contains the database queries for the admin analytics.
"""
from .utils import run_query
