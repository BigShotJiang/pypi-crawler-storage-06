"""
Test Vertica client.
"""

import unittest

from enterprise_reporting import clients


class TestVerticaClient(unittest.TestCase):
	pass
