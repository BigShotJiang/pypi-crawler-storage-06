"""Statistical utilities for evaluation reporting (confidence intervals, etc.)."""

from .confidence_intervals import compute_fixed_set_mu_ci  # re-export
