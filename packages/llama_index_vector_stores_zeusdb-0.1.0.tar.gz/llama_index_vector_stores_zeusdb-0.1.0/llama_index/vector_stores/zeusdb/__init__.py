"""ZeusDB vector store integration for LlamaIndex."""
from llama_index.vector_stores.zeusdb.base import ZeusDBVectorStore

__all__ = ["ZeusDBVectorStore"]
