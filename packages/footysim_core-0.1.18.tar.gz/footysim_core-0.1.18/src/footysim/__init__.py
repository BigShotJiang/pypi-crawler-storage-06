# src/footysim/__init__.py
__all__: list[str] = []  # ne rien importer ici
