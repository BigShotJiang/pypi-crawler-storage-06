# Package metadata for wheel
__title__ = "testcato"
__version__ = "1.1.8"
