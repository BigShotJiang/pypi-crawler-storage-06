"""Entry point for running dotclaude as a module."""

from dotclaude.cli import app

if __name__ == "__main__":
    app()
