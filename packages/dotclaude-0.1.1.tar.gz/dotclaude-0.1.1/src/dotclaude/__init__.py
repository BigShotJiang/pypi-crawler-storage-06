"""Modern CLI tool for managing Claude Code configuration."""

__version__ = "0.1.1"
__author__ = "FradSer"
__email__ = "frad@frad.io"
