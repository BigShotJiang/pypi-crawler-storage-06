from .core import CaptchaCore
from .ui import CaptchaWidget
from .utils import detect_language
from .universal import run_captcha
