MESSAGES = {
    "en": {"success": "CAPTCHA completed ✅", "fail": "Incorrect CAPTCHA ❌"},
    "es": {"success": "CAPTCHA completado ✅", "fail": "CAPTCHA incorrecto ❌"}
}
