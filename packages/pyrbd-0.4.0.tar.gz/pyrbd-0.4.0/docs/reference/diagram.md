::: pyrbd.diagram
    options:
        heading_level: 1