#!/usr/bin/env python3
"""
Setup script for persona-generator package.
This is a fallback for older pip versions that don't support pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
