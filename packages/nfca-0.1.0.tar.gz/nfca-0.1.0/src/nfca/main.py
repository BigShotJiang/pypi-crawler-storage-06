from rich import print
import sys
import torch

def main():
    print("Hello from codespacetest!")
    print(sys.version)
    print(torch.__version__)

if __name__ == "__main__":
    main()
