"""
kclasses

Extensions of built-in Python classes
"""

__version__ = "0.1.0"
__author__ = "KeVeon White"
