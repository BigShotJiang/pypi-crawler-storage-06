from setuptools import setup


setup()


"""
import setuptools

with open("README", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="kclasses",
    version="0.0.1",
    author="KeVeon White",
    author_email="keveonwhite@gmail.com",
    description="Extensions of built-in Python classes",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/AMS0x2A/KClasses",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    package_dir= {"", "src"},
    packages=setuptools.find_packages(where="src")
)
"""