Select implementation details of `pylibtemplate`
================================================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:
