Title: About Me
Navigation: No


Write in `about.mkdn` using **Markdown** syntax a page about yourself or
about your site.  ``Navigation`` is set to "no" in this page, so it
won't appear in the navgation bar, for there's a link in the author's
name.
