# Math MCP Server

A simple example demonstrating how to create a custom Python MCP server that provides mathematical operations.

## Features
- Basic arithmetic operations
- Advanced mathematical functions
- Example of proper tool documentation
- Clean implementation of MCP server tools

## Requirements
- Python >=3.11
- UiPath MCP SDK

