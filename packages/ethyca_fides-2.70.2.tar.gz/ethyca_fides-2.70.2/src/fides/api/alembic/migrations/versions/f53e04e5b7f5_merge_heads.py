"""Merge heads

Revision ID: f53e04e5b7f5
Revises: 155fd8e51d9d, d8f8bd52754f
Create Date: 2022-07-16 02:48:43.622664

"""

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "f53e04e5b7f5"
down_revision = ("155fd8e51d9d", "d8f8bd52754f")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
