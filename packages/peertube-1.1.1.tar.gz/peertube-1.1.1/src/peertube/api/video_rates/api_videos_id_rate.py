from typing import Any
from uuid import UUID

import httpx
from pydantic import ConfigDict, validate_call

from peertube import errors
from peertube.api.shared_utils import build_response
from peertube.client import AuthenticatedClient, Client
from peertube.models.put_api_v1_videos_id_rate_body import PutApiV1VideosIdRateBody
from peertube.types import UNSET, Response, Unset


def _get_kwargs(
    id: UUID | int | str,
    *,
    body: PutApiV1VideosIdRateBody,
    x_peertube_video_password: Unset | str = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_peertube_video_password, Unset):
        headers["x-peertube-video-password"] = x_peertube_video_password
    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": f"/api/v1/videos/{id}/rate",
    }
    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | None:
    if response.status_code == 204:
        return None

    if response.status_code == 404:
        return None
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any]:
    return build_response(client=client, response=response)


@validate_call(config=ConfigDict(arbitrary_types_allowed=True))
def sync_detailed(
    id: UUID | int | str,
    *,
    client: AuthenticatedClient,
    body: PutApiV1VideosIdRateBody,
    x_peertube_video_password: Unset | str = UNSET,
) -> Response[Any]:
    """Like/dislike a video


    Args:
        id (Union[UUID, int, str]): Unique identifier for the entity.
        x_peertube_video_password (Union[Unset, str]): Video-related parameter.
        body (PutApiV1VideosIdRateBody): Request body data.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        id=id, body=body, x_peertube_video_password=x_peertube_video_password
    )

    response = client.get_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


@validate_call(config=ConfigDict(arbitrary_types_allowed=True))
def sync(
    id: UUID | int | str,
    *,
    client: AuthenticatedClient,
    body: PutApiV1VideosIdRateBody,
    x_peertube_video_password: Unset | str = UNSET,
) -> Any | None:
    """Like/dislike a video


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
        x_peertube_video_password=x_peertube_video_password,
    ).parsed


@validate_call(config=ConfigDict(arbitrary_types_allowed=True))
async def asyncio_detailed(
    id: UUID | int | str,
    *,
    client: AuthenticatedClient,
    body: PutApiV1VideosIdRateBody,
    x_peertube_video_password: Unset | str = UNSET,
) -> Response[Any]:
    """Like/dislike a video


    Args:
        id (Union[UUID, int, str]): Unique identifier for the entity.
        x_peertube_video_password (Union[Unset, str]): Video-related parameter.
        body (PutApiV1VideosIdRateBody): Request body data.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        id=id, body=body, x_peertube_video_password=x_peertube_video_password
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
