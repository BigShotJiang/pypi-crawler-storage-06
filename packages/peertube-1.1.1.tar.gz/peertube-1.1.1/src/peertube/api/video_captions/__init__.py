"""Contains endpoint functions for accessing the API"""

from .get_video_captions_content import get_video_captions_content

__all__ = ["get_video_captions_content"]
