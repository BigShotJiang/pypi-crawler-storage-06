# Base API utilities
