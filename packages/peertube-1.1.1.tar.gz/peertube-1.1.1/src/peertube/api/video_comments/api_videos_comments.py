from typing import Any

import httpx

from peertube.api.shared_utils import build_response, parse_response
from peertube.client import AuthenticatedClient, Client
from peertube.types import UNSET, Response, Unset


def _get_kwargs(
    *,
    search: Unset | str = UNSET,
    search_account: Unset | str = UNSET,
    search_video: Unset | str = UNSET,
    video_id: Unset | int = UNSET,
    video_channel_id: Unset | int = UNSET,
    auto_tag_one_of: Unset | list[str] | str = UNSET,
    is_local: Unset | bool = UNSET,
    on_local_video: Unset | bool = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["search"] = search

    params["searchAccount"] = search_account

    params["searchVideo"] = search_video

    params["videoId"] = video_id

    params["videoChannelId"] = video_channel_id
    json_auto_tag_one_of: Unset | list[str] | str
    if isinstance(auto_tag_one_of, Unset):
        json_auto_tag_one_of = UNSET
    elif isinstance(auto_tag_one_of, list):
        json_auto_tag_one_of = auto_tag_one_of

    else:
        json_auto_tag_one_of = auto_tag_one_of
    params["autoTagOneOf"] = json_auto_tag_one_of

    params["isLocal"] = is_local

    params["onLocalVideo"] = on_local_video
    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/videos/comments",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | None:
    return parse_response(client=client, response=response)


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any]:
    return build_response(client=client, response=response)


def sync_detailed(
    *,
    client: AuthenticatedClient,
    search: Unset | str = UNSET,
    search_account: Unset | str = UNSET,
    search_video: Unset | str = UNSET,
    video_id: Unset | int = UNSET,
    video_channel_id: Unset | int = UNSET,
    auto_tag_one_of: Unset | list[str] | str = UNSET,
    is_local: Unset | bool = UNSET,
    on_local_video: Unset | bool = UNSET,
) -> Response[Any]:
    """List instance comments


    Args:
        search (Union[Unset, str]): Search query filter.
        search_account (Union[Unset, str]): Search filter for account.
        search_video (Union[Unset, str]): Search filter for video.
        video_id (Union[Unset, int]): Unique identifier for the video.
        video_channel_id (Union[Unset, int]): Video-related parameter.
        auto_tag_one_of (Union[Unset, list[str], str]): Parameter for auto tag one of.
        is_local (Union[Unset, bool]): Parameter for is local.
        on_local_video (Union[Unset, bool]): Video-related parameter.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        search=search,
        search_account=search_account,
        search_video=search_video,
        video_id=video_id,
        video_channel_id=video_channel_id,
        auto_tag_one_of=auto_tag_one_of,
        is_local=is_local,
        on_local_video=on_local_video,
    )

    response = client.get_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    search: Unset | str = UNSET,
    search_account: Unset | str = UNSET,
    search_video: Unset | str = UNSET,
    video_id: Unset | int = UNSET,
    video_channel_id: Unset | int = UNSET,
    auto_tag_one_of: Unset | list[str] | str = UNSET,
    is_local: Unset | bool = UNSET,
    on_local_video: Unset | bool = UNSET,
) -> Any | None:
    """List instance comments


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any
    """

    return sync_detailed(
        client=client,
        search=search,
        search_account=search_account,
        search_video=search_video,
        video_id=video_id,
        video_channel_id=video_channel_id,
        auto_tag_one_of=auto_tag_one_of,
        is_local=is_local,
        on_local_video=on_local_video,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    search: Unset | str = UNSET,
    search_account: Unset | str = UNSET,
    search_video: Unset | str = UNSET,
    video_id: Unset | int = UNSET,
    video_channel_id: Unset | int = UNSET,
    auto_tag_one_of: Unset | list[str] | str = UNSET,
    is_local: Unset | bool = UNSET,
    on_local_video: Unset | bool = UNSET,
) -> Response[Any]:
    """List instance comments


    Args:
        search (Union[Unset, str]): Search query filter.
        search_account (Union[Unset, str]): Search filter for account.
        search_video (Union[Unset, str]): Search filter for video.
        video_id (Union[Unset, int]): Unique identifier for the video.
        video_channel_id (Union[Unset, int]): Video-related parameter.
        auto_tag_one_of (Union[Unset, list[str], str]): Parameter for auto tag one of.
        is_local (Union[Unset, bool]): Parameter for is local.
        on_local_video (Union[Unset, bool]): Video-related parameter.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        search=search,
        search_account=search_account,
        search_video=search_video,
        video_id=video_id,
        video_channel_id=video_channel_id,
        auto_tag_one_of=auto_tag_one_of,
        is_local=is_local,
        on_local_video=on_local_video,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
