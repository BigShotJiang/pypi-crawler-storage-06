# Tests for encoding edge cases
