API_VERSION = 'v2'
API_BASE_URL = f'https://onfleet.com/api/{API_VERSION}'

RATE_LIMIT = 20
