/* Public domain. */

#ifndef CLOSEONEXEC_H
#define CLOSEONEXEC_H

extern int closeonexec(int);

#endif
