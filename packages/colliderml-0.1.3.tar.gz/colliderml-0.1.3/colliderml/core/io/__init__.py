"""IO operations for ColliderML."""

from .downloader import DataDownloader

__all__ = ["DataDownloader"] 