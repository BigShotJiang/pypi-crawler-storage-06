"""Version information for superflag."""

__version__ = "3.0.1"
