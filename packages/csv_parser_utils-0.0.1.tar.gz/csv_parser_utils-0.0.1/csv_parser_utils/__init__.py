# csv_parser_utils/__init__.py

__version__ = "0.0.1"