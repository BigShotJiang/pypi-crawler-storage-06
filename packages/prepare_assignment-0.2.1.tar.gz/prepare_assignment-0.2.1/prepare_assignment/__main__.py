from prepare_assignment.cli.main import app

if __name__ == '__main__':
    app(prog_name="prepare")
