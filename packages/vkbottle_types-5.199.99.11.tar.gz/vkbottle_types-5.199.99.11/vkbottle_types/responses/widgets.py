from vkbottle_types.codegen.responses.widgets import *  # noqa: F403,F401
