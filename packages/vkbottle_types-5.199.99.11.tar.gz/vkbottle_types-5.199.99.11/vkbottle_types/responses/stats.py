from vkbottle_types.codegen.responses.stats import *  # noqa: F403,F401
