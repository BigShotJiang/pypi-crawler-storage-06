from vkbottle_types.codegen.responses.board import *  # noqa: F403,F401
