from vkbottle_types.codegen.responses.newsfeed import *  # noqa: F403,F401
