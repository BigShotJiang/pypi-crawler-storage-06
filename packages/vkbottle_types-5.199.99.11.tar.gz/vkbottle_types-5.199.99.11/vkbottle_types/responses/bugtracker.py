from vkbottle_types.codegen.responses.bugtracker import *  # noqa: F403,F401
