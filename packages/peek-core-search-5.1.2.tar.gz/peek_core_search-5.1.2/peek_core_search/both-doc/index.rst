==========
User Guide
==========

This plugin provides a search facility for peek with the following support :

- Search by multiple keywords
- Indexing multiple object types, jobs, equipment, etc.
- Support for switching to other plugins and showing the object.
- Multiple location results for each object.

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    searching.rst