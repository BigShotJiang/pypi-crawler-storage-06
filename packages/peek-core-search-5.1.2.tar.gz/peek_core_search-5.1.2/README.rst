=============
Search Plugin
=============

This plugin provides search support for Peek.

Searches can be run with one or more keywords,
results return a list of objects which can then be opened with other plugins.

