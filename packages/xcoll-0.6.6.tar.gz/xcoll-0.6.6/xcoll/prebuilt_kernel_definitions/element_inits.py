# copyright ############################### #
# This file is part of the Xcoll package.   #
# Copyright (c) CERN, 2025.                 #
# ######################################### #

XCOLL_ELEMENTS_INIT_DEFAULTS = {}
