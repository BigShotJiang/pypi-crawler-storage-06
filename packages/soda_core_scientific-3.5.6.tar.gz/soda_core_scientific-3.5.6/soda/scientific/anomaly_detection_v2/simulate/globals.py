HYPERPARAMETER_PROFILE_DOC = "docs.soda.io/soda-cl/anomaly-detection.html"  # TODO: update
