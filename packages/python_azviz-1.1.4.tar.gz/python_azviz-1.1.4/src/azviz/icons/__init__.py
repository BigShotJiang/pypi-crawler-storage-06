"""Icon management module."""

from .icon_manager import IconManager

__all__ = ["IconManager"]
