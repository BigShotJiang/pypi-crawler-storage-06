- If the brand module gets implemented more broadly this module could need extension to work properly, because not all
  odoo modules use the same mail templates
- Color the buttons & other elements in the email according to brand style.

