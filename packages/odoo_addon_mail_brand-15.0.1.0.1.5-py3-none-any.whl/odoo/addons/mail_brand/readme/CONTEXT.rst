**In summary:**

The module prioritizes automatic branding based on the originating record.
If no brand is associated with the record, or if you need to override it, you can manually select a brand in the "Compose Email" wizard.
Ensure your brands are correctly configured with linked partners and logos for the branding to appear in your outgoing emails.
