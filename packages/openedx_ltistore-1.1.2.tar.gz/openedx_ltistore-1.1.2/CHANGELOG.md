Change Log
==========

Unreleased
----------

*

1.1.2 - 2025-09-19
------------------

### Fixed

* Fixed issue with LTI 1.3 public JWK not being included in serialized config.

1.1.0 – 2025-05-21
------------------

### Added

* Initial release to PyPI.
* CI pipelines.
* Django 5.2 support.
