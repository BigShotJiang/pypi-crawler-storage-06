from .service import Service as HiveService
