"""Entry point for running life3d-rgb as a module."""

from .cli import main

if __name__ == "__main__":
    main()