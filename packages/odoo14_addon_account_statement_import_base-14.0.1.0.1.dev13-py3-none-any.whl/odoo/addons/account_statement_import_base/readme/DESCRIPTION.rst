This is a technical module designed to share code between 2 other modules:

* **account_statement_import** that allows to import bank statements from files,
* **account_statement_import_online** that allows to import bank statements from webservices/APIs.
