import { Component } from "@angular/core";

@Component({
    selector: "plugin-branch",
    templateUrl: "branch.component.mweb.html",
})
export class BranchComponent {
    constructor() {}
}
