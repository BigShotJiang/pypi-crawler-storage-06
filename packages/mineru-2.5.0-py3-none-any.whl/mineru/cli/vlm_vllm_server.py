from mineru.model.vlm_vllm_model.server import main

if __name__ == "__main__":
    main()