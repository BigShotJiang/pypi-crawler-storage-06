__author__ = "Janosh Riebesell <janosh.riebesell@gmail.com>"

from os.path import abspath, dirname

module_dir = dirname(abspath(__file__))
