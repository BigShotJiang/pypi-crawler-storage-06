These scripts are all explained more in the FireWorks tutorials. Please refer to the tutorial documentation referred to in the comments for each file for further explanations.

You might need to initially configure your database, i.e. "lpad init" followed by "lpad reset".
