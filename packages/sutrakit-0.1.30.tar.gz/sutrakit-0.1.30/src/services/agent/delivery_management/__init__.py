"""
Sequential delivery management module.
"""

from .sequential_delivery_manager import delivery_manager

__all__ = ["delivery_manager"]
