from acb.config import AdapterBase, Settings


class AnalyticsBaseSettings(Settings): ...


class AnalyticsBase(AdapterBase): ...
