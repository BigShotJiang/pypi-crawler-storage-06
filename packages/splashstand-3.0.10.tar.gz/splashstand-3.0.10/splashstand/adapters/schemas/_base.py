from acb.config import AdapterBase, Settings


class SchemasBaseSettings(Settings): ...


class SchemasBase(AdapterBase): ...
