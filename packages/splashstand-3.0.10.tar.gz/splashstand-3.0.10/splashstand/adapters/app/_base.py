import typing as t

from acb.config import AdapterBase
from acb.config import AppSettings as AppConfigSettings
from starlette.routing import Router


class AppBaseSettings(AppConfigSettings):
    project: str = "splashstand"  # type: ignore
    name: str = "splashstand"
    title: str = "SplashStand"  # type: ignore
    style: str = "webawesome"
    theme: str = "light"


class AppProtocol(t.Protocol):
    def __init__(self) -> None: ...
    async def lifespan(self) -> t.AsyncIterator[None]: ...


class AppBase(AdapterBase):
    router: Router | None
