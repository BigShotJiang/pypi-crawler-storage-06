from aiware.graphql.client import AiwareGraphQL as _AiwareGraphQL


class BaseAiwareGraphQL(_AiwareGraphQL):
    pass
