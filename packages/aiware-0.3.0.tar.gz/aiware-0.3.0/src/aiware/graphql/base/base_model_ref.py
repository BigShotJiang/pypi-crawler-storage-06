from aiware.graphql.base.base_model import * # pyright: ignore[reportWildcardImportFromLibrary]
