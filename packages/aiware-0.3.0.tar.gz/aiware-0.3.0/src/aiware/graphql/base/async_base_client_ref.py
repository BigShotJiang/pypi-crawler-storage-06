# This file gets copied in by ariadne-codegen
from aiware.graphql.base.async_base_client import AsyncBaseClient as _AsyncBaseClient

class AsyncBaseClient(_AsyncBaseClient):
    pass
