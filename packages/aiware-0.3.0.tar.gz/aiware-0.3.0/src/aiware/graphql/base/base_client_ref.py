# This file gets copied in by ariadne-codegen
from aiware.graphql.base.base_client import BaseClient as _BaseClient

class BaseClient(_BaseClient):
    pass
