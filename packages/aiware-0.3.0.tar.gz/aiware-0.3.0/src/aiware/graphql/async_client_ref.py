from aiware.graphql.async_client import AsyncAiwareGraphQL as _AsyncAiwareGraphQL


class AsyncBaseAiwareGraphQL(_AsyncAiwareGraphQL):
    pass
