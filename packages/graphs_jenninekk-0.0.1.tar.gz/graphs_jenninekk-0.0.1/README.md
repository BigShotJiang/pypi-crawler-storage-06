# graphs_Jenninekk

This is the code for Dijkstra's algorith to find the shortest path from all sources 