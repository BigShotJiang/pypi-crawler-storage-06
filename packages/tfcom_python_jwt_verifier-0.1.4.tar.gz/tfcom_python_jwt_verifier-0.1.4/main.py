def main():
    print("Hello from tfcom-python-jwt-verifier!")


if __name__ == "__main__":
    main()
