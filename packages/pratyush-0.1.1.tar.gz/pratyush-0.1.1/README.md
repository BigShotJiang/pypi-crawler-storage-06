# Pratyush CLI 🚀

A simple Python CLI to showcase Pratyush's portfolio and projects.

## Installation

```bash
pip install pratyush
