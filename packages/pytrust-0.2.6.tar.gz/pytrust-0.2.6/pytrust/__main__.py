"""Execute pytrust as a module."""

from pytrust.cli import main

if __name__ == "__main__":
    main()
