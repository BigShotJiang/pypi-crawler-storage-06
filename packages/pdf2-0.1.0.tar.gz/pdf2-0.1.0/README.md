``` sh
uv tool install maturin
uv venv
```

``` sh
uvx maturin develop
```

``` sh
cargo run --bin stub_gen
```
