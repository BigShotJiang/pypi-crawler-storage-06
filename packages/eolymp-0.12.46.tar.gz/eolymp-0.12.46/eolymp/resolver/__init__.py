from .resolver_http import *
from .resolver_pb2 import *
