# Importa la clase principal para que sea fácil de acceder.
from .model import StackingRegressor