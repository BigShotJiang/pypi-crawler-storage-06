from phoenix.evals.legacy.models.vertexai import VertexAIModel

__all__ = [
    "VertexAIModel",
]
