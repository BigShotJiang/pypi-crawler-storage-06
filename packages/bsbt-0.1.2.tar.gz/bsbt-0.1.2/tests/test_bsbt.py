from bsbt import run

result = run("antibody_A")
print("Output for antibody_A:", result)  
