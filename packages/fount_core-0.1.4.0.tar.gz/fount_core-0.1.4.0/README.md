# Fount SDK

The Fount client provides a high-level interface for machine learning operations including dataset management, model training, fine-tuning, and inference on the Fount platform.
