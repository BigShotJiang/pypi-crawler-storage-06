from tacotoolbox.tortilla.extensions.majortom import MajorTOM
from tacotoolbox.tortilla.extensions.territorial import Territorial, TERRITORIAL_PRODUCTS
