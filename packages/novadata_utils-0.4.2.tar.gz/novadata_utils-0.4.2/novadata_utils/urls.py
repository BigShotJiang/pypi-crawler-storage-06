from django.urls import include, path

urlpatterns = [

]
