# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""
This module provides command-line interface functionalities for PyRIT.
The CLI module is currently experimental.
"""
