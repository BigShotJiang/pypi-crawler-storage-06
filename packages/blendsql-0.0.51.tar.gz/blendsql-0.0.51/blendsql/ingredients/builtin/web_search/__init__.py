from .main import BingWebSearch
