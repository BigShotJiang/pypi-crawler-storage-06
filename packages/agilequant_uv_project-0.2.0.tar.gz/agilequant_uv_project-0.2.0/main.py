def main():
    print("Hello from uv-project!")
    print("Hello from agilequant-my-project! v2")


if __name__ == "__main__":
    main()
