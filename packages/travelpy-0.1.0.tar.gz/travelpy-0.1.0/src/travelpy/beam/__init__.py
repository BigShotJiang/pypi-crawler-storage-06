"""Beam handling and analysis."""

from .beam import Beam

__all__ = ["Beam"]
