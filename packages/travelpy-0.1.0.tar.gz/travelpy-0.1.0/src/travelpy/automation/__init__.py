"""Automation tools for parameter sweeps, optimization, and batch studies."""
