# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class WorkflowSimpleInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'enable_stream_response': 'bool',
        'id': 'str',
        'workflow_urn': 'str',
        'name': 'str',
        'description': 'str',
        'created_time': 'str',
        'updated_time': 'str',
        'created_by': 'str'
    }

    attribute_map = {
        'enable_stream_response': 'enable_stream_response',
        'id': 'id',
        'workflow_urn': 'workflow_urn',
        'name': 'name',
        'description': 'description',
        'created_time': 'created_time',
        'updated_time': 'updated_time',
        'created_by': 'created_by'
    }

    def __init__(self, enable_stream_response=None, id=None, workflow_urn=None, name=None, description=None, created_time=None, updated_time=None, created_by=None):
        r"""WorkflowSimpleInfo

        The model defined in huaweicloud sdk

        :param enable_stream_response: 函数流是否返回流式数据
        :type enable_stream_response: bool
        :param id: 唯一标识ID，流程定义ID
        :type id: str
        :param workflow_urn: 函数工作流URN, 格式为： urn:fss:&lt;region_id&gt;:&lt;project_id&gt;:workflow:\\&lt;package\\&gt;:&lt;workflow_name&gt;:\\&lt;version\\&gt; 注意： package当前只支持default version当前只支持latest
        :type workflow_urn: str
        :param name: 流程定义名称
        :type name: str
        :param description: 流程定义描述
        :type description: str
        :param created_time: 流程创建时间，格式：yyyy-MM-ddTHH:mm:ssZ，UTC时间
        :type created_time: str
        :param updated_time: 流程修改时间，格式：yyyy-MM-ddTHH:mm:ssZ，UTC时间
        :type updated_time: str
        :param created_by: 流程创建者
        :type created_by: str
        """
        
        

        self._enable_stream_response = None
        self._id = None
        self._workflow_urn = None
        self._name = None
        self._description = None
        self._created_time = None
        self._updated_time = None
        self._created_by = None
        self.discriminator = None

        self.enable_stream_response = enable_stream_response
        self.id = id
        self.workflow_urn = workflow_urn
        self.name = name
        self.description = description
        self.created_time = created_time
        self.updated_time = updated_time
        self.created_by = created_by

    @property
    def enable_stream_response(self):
        r"""Gets the enable_stream_response of this WorkflowSimpleInfo.

        函数流是否返回流式数据

        :return: The enable_stream_response of this WorkflowSimpleInfo.
        :rtype: bool
        """
        return self._enable_stream_response

    @enable_stream_response.setter
    def enable_stream_response(self, enable_stream_response):
        r"""Sets the enable_stream_response of this WorkflowSimpleInfo.

        函数流是否返回流式数据

        :param enable_stream_response: The enable_stream_response of this WorkflowSimpleInfo.
        :type enable_stream_response: bool
        """
        self._enable_stream_response = enable_stream_response

    @property
    def id(self):
        r"""Gets the id of this WorkflowSimpleInfo.

        唯一标识ID，流程定义ID

        :return: The id of this WorkflowSimpleInfo.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this WorkflowSimpleInfo.

        唯一标识ID，流程定义ID

        :param id: The id of this WorkflowSimpleInfo.
        :type id: str
        """
        self._id = id

    @property
    def workflow_urn(self):
        r"""Gets the workflow_urn of this WorkflowSimpleInfo.

        函数工作流URN, 格式为： urn:fss:<region_id>:<project_id>:workflow:\\<package\\>:<workflow_name>:\\<version\\> 注意： package当前只支持default version当前只支持latest

        :return: The workflow_urn of this WorkflowSimpleInfo.
        :rtype: str
        """
        return self._workflow_urn

    @workflow_urn.setter
    def workflow_urn(self, workflow_urn):
        r"""Sets the workflow_urn of this WorkflowSimpleInfo.

        函数工作流URN, 格式为： urn:fss:<region_id>:<project_id>:workflow:\\<package\\>:<workflow_name>:\\<version\\> 注意： package当前只支持default version当前只支持latest

        :param workflow_urn: The workflow_urn of this WorkflowSimpleInfo.
        :type workflow_urn: str
        """
        self._workflow_urn = workflow_urn

    @property
    def name(self):
        r"""Gets the name of this WorkflowSimpleInfo.

        流程定义名称

        :return: The name of this WorkflowSimpleInfo.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this WorkflowSimpleInfo.

        流程定义名称

        :param name: The name of this WorkflowSimpleInfo.
        :type name: str
        """
        self._name = name

    @property
    def description(self):
        r"""Gets the description of this WorkflowSimpleInfo.

        流程定义描述

        :return: The description of this WorkflowSimpleInfo.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this WorkflowSimpleInfo.

        流程定义描述

        :param description: The description of this WorkflowSimpleInfo.
        :type description: str
        """
        self._description = description

    @property
    def created_time(self):
        r"""Gets the created_time of this WorkflowSimpleInfo.

        流程创建时间，格式：yyyy-MM-ddTHH:mm:ssZ，UTC时间

        :return: The created_time of this WorkflowSimpleInfo.
        :rtype: str
        """
        return self._created_time

    @created_time.setter
    def created_time(self, created_time):
        r"""Sets the created_time of this WorkflowSimpleInfo.

        流程创建时间，格式：yyyy-MM-ddTHH:mm:ssZ，UTC时间

        :param created_time: The created_time of this WorkflowSimpleInfo.
        :type created_time: str
        """
        self._created_time = created_time

    @property
    def updated_time(self):
        r"""Gets the updated_time of this WorkflowSimpleInfo.

        流程修改时间，格式：yyyy-MM-ddTHH:mm:ssZ，UTC时间

        :return: The updated_time of this WorkflowSimpleInfo.
        :rtype: str
        """
        return self._updated_time

    @updated_time.setter
    def updated_time(self, updated_time):
        r"""Sets the updated_time of this WorkflowSimpleInfo.

        流程修改时间，格式：yyyy-MM-ddTHH:mm:ssZ，UTC时间

        :param updated_time: The updated_time of this WorkflowSimpleInfo.
        :type updated_time: str
        """
        self._updated_time = updated_time

    @property
    def created_by(self):
        r"""Gets the created_by of this WorkflowSimpleInfo.

        流程创建者

        :return: The created_by of this WorkflowSimpleInfo.
        :rtype: str
        """
        return self._created_by

    @created_by.setter
    def created_by(self, created_by):
        r"""Sets the created_by of this WorkflowSimpleInfo.

        流程创建者

        :param created_by: The created_by of this WorkflowSimpleInfo.
        :type created_by: str
        """
        self._created_by = created_by

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, WorkflowSimpleInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
