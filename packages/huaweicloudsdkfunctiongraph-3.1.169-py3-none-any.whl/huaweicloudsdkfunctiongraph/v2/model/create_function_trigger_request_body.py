# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateFunctionTriggerRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'trigger_type_code': 'str',
        'trigger_status': 'str',
        'event_type_code': 'str',
        'event_data': 'TriggerEventDataRequestBody'
    }

    attribute_map = {
        'trigger_type_code': 'trigger_type_code',
        'trigger_status': 'trigger_status',
        'event_type_code': 'event_type_code',
        'event_data': 'event_data'
    }

    def __init__(self, trigger_type_code=None, trigger_status=None, event_type_code=None, event_data=None):
        r"""CreateFunctionTriggerRequestBody

        The model defined in huaweicloud sdk

        :param trigger_type_code: 触发器类型。  - TIMER: 定时触发器。 - APIG: APIGW触发器。 - CTS: 云审计触发器，需要先开通云审计服务。 - DDS: 文档数据库触发器，需要开启函数vpc。 - DMS: 分布式消息服务触发器，需要配置dms委托。 - DIS: 数据接入服务触发器，需要配置dis委托。 - LTS: 云审计日志服务触发器，需要配置lts委托。 - OBS: 对象存储服务触发器。 - KAFKA: 专享版本kafka触发器。
        :type trigger_type_code: str
        :param trigger_status: 触发器状态，取值为ACTIVE,DISABLED。
        :type trigger_status: str
        :param event_type_code: 消息代码。
        :type event_type_code: str
        :param event_data: 
        :type event_data: :class:`huaweicloudsdkfunctiongraph.v2.TriggerEventDataRequestBody`
        """
        
        

        self._trigger_type_code = None
        self._trigger_status = None
        self._event_type_code = None
        self._event_data = None
        self.discriminator = None

        self.trigger_type_code = trigger_type_code
        if trigger_status is not None:
            self.trigger_status = trigger_status
        if event_type_code is not None:
            self.event_type_code = event_type_code
        self.event_data = event_data

    @property
    def trigger_type_code(self):
        r"""Gets the trigger_type_code of this CreateFunctionTriggerRequestBody.

        触发器类型。  - TIMER: 定时触发器。 - APIG: APIGW触发器。 - CTS: 云审计触发器，需要先开通云审计服务。 - DDS: 文档数据库触发器，需要开启函数vpc。 - DMS: 分布式消息服务触发器，需要配置dms委托。 - DIS: 数据接入服务触发器，需要配置dis委托。 - LTS: 云审计日志服务触发器，需要配置lts委托。 - OBS: 对象存储服务触发器。 - KAFKA: 专享版本kafka触发器。

        :return: The trigger_type_code of this CreateFunctionTriggerRequestBody.
        :rtype: str
        """
        return self._trigger_type_code

    @trigger_type_code.setter
    def trigger_type_code(self, trigger_type_code):
        r"""Sets the trigger_type_code of this CreateFunctionTriggerRequestBody.

        触发器类型。  - TIMER: 定时触发器。 - APIG: APIGW触发器。 - CTS: 云审计触发器，需要先开通云审计服务。 - DDS: 文档数据库触发器，需要开启函数vpc。 - DMS: 分布式消息服务触发器，需要配置dms委托。 - DIS: 数据接入服务触发器，需要配置dis委托。 - LTS: 云审计日志服务触发器，需要配置lts委托。 - OBS: 对象存储服务触发器。 - KAFKA: 专享版本kafka触发器。

        :param trigger_type_code: The trigger_type_code of this CreateFunctionTriggerRequestBody.
        :type trigger_type_code: str
        """
        self._trigger_type_code = trigger_type_code

    @property
    def trigger_status(self):
        r"""Gets the trigger_status of this CreateFunctionTriggerRequestBody.

        触发器状态，取值为ACTIVE,DISABLED。

        :return: The trigger_status of this CreateFunctionTriggerRequestBody.
        :rtype: str
        """
        return self._trigger_status

    @trigger_status.setter
    def trigger_status(self, trigger_status):
        r"""Sets the trigger_status of this CreateFunctionTriggerRequestBody.

        触发器状态，取值为ACTIVE,DISABLED。

        :param trigger_status: The trigger_status of this CreateFunctionTriggerRequestBody.
        :type trigger_status: str
        """
        self._trigger_status = trigger_status

    @property
    def event_type_code(self):
        r"""Gets the event_type_code of this CreateFunctionTriggerRequestBody.

        消息代码。

        :return: The event_type_code of this CreateFunctionTriggerRequestBody.
        :rtype: str
        """
        return self._event_type_code

    @event_type_code.setter
    def event_type_code(self, event_type_code):
        r"""Sets the event_type_code of this CreateFunctionTriggerRequestBody.

        消息代码。

        :param event_type_code: The event_type_code of this CreateFunctionTriggerRequestBody.
        :type event_type_code: str
        """
        self._event_type_code = event_type_code

    @property
    def event_data(self):
        r"""Gets the event_data of this CreateFunctionTriggerRequestBody.

        :return: The event_data of this CreateFunctionTriggerRequestBody.
        :rtype: :class:`huaweicloudsdkfunctiongraph.v2.TriggerEventDataRequestBody`
        """
        return self._event_data

    @event_data.setter
    def event_data(self, event_data):
        r"""Sets the event_data of this CreateFunctionTriggerRequestBody.

        :param event_data: The event_data of this CreateFunctionTriggerRequestBody.
        :type event_data: :class:`huaweicloudsdkfunctiongraph.v2.TriggerEventDataRequestBody`
        """
        self._event_data = event_data

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateFunctionTriggerRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
