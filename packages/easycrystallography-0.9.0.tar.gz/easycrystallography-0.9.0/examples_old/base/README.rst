.. _base_examples:

Subclassing Examples
------------------------

This section gathers examples which correspond to subclassing the :class:`easyCore.Objects.Base.BaseObj`  class.
