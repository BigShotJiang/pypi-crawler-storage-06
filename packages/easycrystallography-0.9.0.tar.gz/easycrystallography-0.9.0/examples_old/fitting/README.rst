.. _fitting_examples:

Fitting Examples
------------------------

This section gathers examples which correspond to fitting data.
