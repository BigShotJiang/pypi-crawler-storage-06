# Copyright (c) QuantCo 2025-2025
# SPDX-License-Identifier: BSD-3-Clause

SCHEMA_METADATA_KEY = "dataframely_schema"
COLLECTION_METADATA_KEY = "dataframely_collection"
RULE_METADATA_KEY = "dataframely_rule_columns"
