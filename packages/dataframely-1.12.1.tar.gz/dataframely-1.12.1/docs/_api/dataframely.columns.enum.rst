dataframely.columns.enum module
===============================

.. automodule:: dataframely.columns.enum
   :members:
   :show-inheritance:
   :undoc-members:
