dataframely.functional module
=============================

.. automodule:: dataframely.functional
   :members:
   :show-inheritance:
   :undoc-members:
