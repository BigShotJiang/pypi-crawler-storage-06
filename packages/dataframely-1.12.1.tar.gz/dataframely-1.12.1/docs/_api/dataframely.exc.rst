dataframely.exc module
======================

.. automodule:: dataframely.exc
   :members:
   :show-inheritance:
   :undoc-members:
