dataframely.columns.integer module
==================================

.. automodule:: dataframely.columns.integer
   :members:
   :show-inheritance:
   :undoc-members:
