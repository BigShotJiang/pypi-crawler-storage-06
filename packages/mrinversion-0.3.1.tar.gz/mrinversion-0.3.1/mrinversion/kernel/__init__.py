"""Initialization of the kernel module."""
from mrinversion.kernel.relaxation import T1  # NOQA
from mrinversion.kernel.relaxation import T2  # NOQA
