class ClipKITException(Exception):
    pass


class InvalidInputFileFormat(ClipKITException):
    pass
