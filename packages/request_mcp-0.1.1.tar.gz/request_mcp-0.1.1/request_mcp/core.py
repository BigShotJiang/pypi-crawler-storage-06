def hello(name: str) -> str:
    return f"Hello, {name} from request-mcp!"

