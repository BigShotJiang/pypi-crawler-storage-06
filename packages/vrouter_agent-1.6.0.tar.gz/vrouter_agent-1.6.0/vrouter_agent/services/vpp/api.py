from loguru import logger as log
from vpp_vrouter.common import models
import ipaddress

from vrouter_agent.utils.ipaddr import get_wan_ip_addresses
