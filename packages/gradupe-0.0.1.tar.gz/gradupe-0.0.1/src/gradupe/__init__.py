"""Sobel Gradient Based Image Deduper"""

__version__ = "0.0.1"
