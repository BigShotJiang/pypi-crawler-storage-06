"""Internal implementation of `~certbot_dns_abion.dns_abion` plugin."""
