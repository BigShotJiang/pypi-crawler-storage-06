from niaclass.niaclass import NiaClass

__all__ = ["NiaClass"]

__version__ = "0.2.4"
