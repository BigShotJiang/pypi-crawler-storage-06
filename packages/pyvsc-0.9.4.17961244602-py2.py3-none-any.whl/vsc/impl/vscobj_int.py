'''
Created on Mar 21, 2020

@author: ballance
'''

class VscObjInt(object):
    
    def __init__(self):
        self.ctor_level = 0
        self.srcinfo = False
        