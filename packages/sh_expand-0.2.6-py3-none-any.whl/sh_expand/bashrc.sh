readonly PS1='EXPECT$ '
unset PROMPTCOMMAND

