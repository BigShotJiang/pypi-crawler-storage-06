from f4enix.input.ww_gvr.models import CoordinateType, ParticleType
from f4enix.input.ww_gvr.weight_window import WW
