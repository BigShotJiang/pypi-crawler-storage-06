from .generator import FakeXYZ
