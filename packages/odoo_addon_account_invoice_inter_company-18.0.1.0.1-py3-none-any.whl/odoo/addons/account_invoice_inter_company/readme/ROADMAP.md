> - This module cannot be fully used in combination with
>   remove_odoo_entreprise module. If you need both, uninstall
>   remove_odoo_entreprise, complete settings with
>   account_invoice_inter_company and then re-install
>   remove_odoo_entreprise.
> - Product mapping: would be nice to have a matrix with the products on
>   the left side and on the top row the companies.
