This module is usefull if there are multiple companies in the same Odoo
database and those companies sell goods or services among themselves. It
allow to create an invoice in company A from an invoice in company B.

Imagine you have company A and company B in the same Odoo database.
First scenario: company B create an invoice with company A as customer.
The module will automate the generation of the supplier invoice in
company A. Second scenario: company A create an invoice with company B
as supplier. The module will automate the generation of the customer
invoice in company B.
