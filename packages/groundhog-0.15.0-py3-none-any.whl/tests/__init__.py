"""
tests
~~~~~

Test suite for the geotechnics package.
"""
