"""
geotechnics
~~~~~~

The geotechnics package - a Python package template project that is intended
to be used as a cookie-cutter for developing new Python packages.
"""
