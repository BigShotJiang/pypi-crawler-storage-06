"""
Slash Commands MCP Server Package
"""

# Main function is exported from unified_router
from .unified_router import main

__all__ = ["main"]