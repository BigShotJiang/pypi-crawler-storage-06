"""This module contains the models for the services."""
