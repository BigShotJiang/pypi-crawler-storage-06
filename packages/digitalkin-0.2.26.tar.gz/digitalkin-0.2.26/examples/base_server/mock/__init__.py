"""Basic greeting service.

This module contains the definition of the basic greeting service
implemented using Protocol Buffers and gRPC.
"""
