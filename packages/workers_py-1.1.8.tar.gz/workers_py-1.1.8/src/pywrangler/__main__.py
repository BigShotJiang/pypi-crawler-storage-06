from pywrangler.cli import app

app()
