"""
Directory for saving user-defined components and functions.
"""
