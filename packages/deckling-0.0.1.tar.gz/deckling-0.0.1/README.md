## deckling
install it via pip/pip3
```
pip install deckling
```