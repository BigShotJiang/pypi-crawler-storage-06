## v0.5.0 (2025-09-17)

### Feat

- define a public-facing API

## v0.4.0 (2025-09-17)

### BREAKING CHANGE

- s3_cache, json_utils, and uri_utils have been removed

### Feat

- Remove s3_cache, json_utils, and uri_utils

## v0.3.1 (2025-09-11)

### Fix

- Attempt to fix file parsing on windows (#21)

## v0.3.0 (2025-09-10)

### Feat

- add convenience function to load all files from neuroglancer

## v0.2.0 (2025-09-09)

### Feat

- **domain**: add pipeline domain/transform utils; S3 caching; docs

## v0.1.4 (2025-08-07)

## v0.1.3 (2025-07-29)

### Fix

- Typing (#10)

## v0.1.2 (2025-07-01)

## v0.1.1 (2025-06-30)

## v0.1.0 (2025-06-30)

### Feat

- add annotations

## v0.0.11 (2025-06-30)

## v0.0.10 (2025-06-26)

## v0.0.9 (2025-06-26)

## v0.0.8 (2025-06-26)

## v0.0.7 (2025-06-26)

## v0.0.6 (2025-06-26)

## v0.0.5 (2025-06-13)

## v0.0.4 (2025-04-24)

### Fix

- some problems with variable names

## v0.0.3 (2025-04-23)

## v0.0.2 (2025-04-23)

## v0.0.1 (2025-04-23)

## v0.0.0 (2025-04-23)
