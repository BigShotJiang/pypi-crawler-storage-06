from MyDatabase.ZLDb import BaseEntity, db

__all__ = [BaseEntity, db]
