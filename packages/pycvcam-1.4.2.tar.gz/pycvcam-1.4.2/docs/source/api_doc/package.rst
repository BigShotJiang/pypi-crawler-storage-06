pycvcam.core.Package
=============================

.. autoclass:: pycvcam.core.Package
    :members:
    :undoc-members:
    :private-members:
    :show-inheritance: