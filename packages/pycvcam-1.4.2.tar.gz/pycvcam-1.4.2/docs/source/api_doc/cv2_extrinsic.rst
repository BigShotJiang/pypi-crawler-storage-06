pycvcam.Cv2Extrinsic
=============================

.. autoclass:: pycvcam.Cv2Extrinsic
    :members:
    :undoc-members:
    :private-members:
    :show-inheritance: