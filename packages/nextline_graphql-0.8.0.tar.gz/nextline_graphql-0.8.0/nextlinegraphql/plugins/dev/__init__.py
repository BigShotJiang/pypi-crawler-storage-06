__all__ = ['Plugin']

from .plugin import Plugin
