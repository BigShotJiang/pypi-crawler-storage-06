"""Prompt management for DataBeak.

This package provides prompt templates and generation utilities for AI-driven data analysis
workflows in DataBeak.
"""
