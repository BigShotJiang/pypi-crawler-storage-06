"""Utility functions and classes for DataBeak.

This package provides common utilities, validators, and helper functions used throughout the
DataBeak codebase.
"""
