"""The main module of the eo-grow package."""

__version__ = "1.7.15"
