"""A submodule with definitions of core objects."""
