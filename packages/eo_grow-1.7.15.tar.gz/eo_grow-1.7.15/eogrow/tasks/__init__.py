"""A submodule with custom EOTasks implementations."""
