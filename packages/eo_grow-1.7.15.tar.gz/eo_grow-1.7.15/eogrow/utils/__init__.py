"""A submodule implementing various utilities."""
