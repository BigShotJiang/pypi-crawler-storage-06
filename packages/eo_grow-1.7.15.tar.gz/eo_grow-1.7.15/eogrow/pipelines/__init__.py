"""A submodule with Pipeline definitions."""
