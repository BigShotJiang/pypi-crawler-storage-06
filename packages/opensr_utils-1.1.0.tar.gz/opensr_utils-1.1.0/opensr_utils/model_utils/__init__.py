# -*- coding: utf-8 -*-
"""Model utilities for OpenSR-Utils."""

from .prepare_model import preprocess_model

__all__ = [
    "preprocess_model",
]