# 3rd Party Libs We Want But Not Depend On

## sh

- Great tool but since 2017 years on a halt
- Single file.
- Requires a patch for structlogging anyway

Better not depend but just copy.
