# Don't remove. Import for not repetitive implementation
from sqlexecutorx import DBError


class NotFoundError(DBError):
    pass

