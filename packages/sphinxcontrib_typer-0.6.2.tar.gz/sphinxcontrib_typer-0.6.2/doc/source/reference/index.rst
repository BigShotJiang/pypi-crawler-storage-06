.. include:: ../refs.rst

.. _reference:

=========
Reference
=========

.. automodule:: sphinxcontrib.typer

|

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   directive
   configuration
   roles
