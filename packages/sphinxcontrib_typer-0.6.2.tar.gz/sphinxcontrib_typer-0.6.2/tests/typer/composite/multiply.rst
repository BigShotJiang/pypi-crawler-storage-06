.. typer:: composite.cli.app:subgroup:multiply
    :width: 65
    :convert-png: latex
    :make-sections:
    :preferred: text
