import typer


def echo(name: str):
    typer.echo(name)
