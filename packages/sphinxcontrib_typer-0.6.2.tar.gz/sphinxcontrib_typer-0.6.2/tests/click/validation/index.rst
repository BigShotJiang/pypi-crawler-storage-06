.. typer:: validation.cli
    :preferred: html
    :width: 65
    :convert-png: latex

.. typer:: validation.cli
    :preferred: svg
    :width: 65

.. typer:: validation.cli
    :preferred: text
    :width: 65
