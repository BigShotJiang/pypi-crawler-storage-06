.. typer:: inout.cli
    :builders: html=html
    :markup-mode: markdown
    :width: 65
