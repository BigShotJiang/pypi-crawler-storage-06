.. typer:: aliases:cli
    :show-nested:
    :preferred: text
    :width: 65
