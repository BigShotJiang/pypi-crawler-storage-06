.. typer:: naval.cli
    :show-nested:
    :make-sections:
    :width: 80

.. typer:: naval.cli:ship:new
    :make-sections:
