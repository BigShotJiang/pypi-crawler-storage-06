ProcessOut Python
==============

This package provides bindings to the ProcessOut API.

Dependencies
------------

* Python 2.4 or higher
* Requests

Installation
------------

The package's installation is done using pypi:

``` sh
pip install processout
```

If you don't want to use pip to install this package, you may simply do a git clone
of this repository.
