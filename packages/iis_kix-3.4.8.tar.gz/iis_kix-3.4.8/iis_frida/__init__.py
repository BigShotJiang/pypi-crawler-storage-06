"""
.. include:: ../README.md
"""



__docformat__ = "restructuredtext"
