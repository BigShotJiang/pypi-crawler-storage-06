
# Messkit

Hopefully some kind of generic data manipulation thingy, we'll see...
