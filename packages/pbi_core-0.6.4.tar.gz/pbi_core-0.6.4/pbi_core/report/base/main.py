class BaseReport:
    pass
