from .main import BaseReport

__all__ = ["BaseReport"]
