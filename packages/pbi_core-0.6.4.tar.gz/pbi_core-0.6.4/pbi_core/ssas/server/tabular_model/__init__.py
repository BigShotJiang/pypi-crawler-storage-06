from .tabular_model import BaseTabularModel, LocalTabularModel

__all__ = [
    "BaseTabularModel",
    "LocalTabularModel",
]
