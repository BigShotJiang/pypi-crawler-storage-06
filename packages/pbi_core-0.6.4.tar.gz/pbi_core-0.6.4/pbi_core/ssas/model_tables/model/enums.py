from enum import IntEnum


class DefaultDataView(IntEnum):
    FULL = 0
    SAMPLE = 1
    DEFAULT = 3
