# Auto-generated to make this a Python package
from .model import Model

__all__ = ["Model"]
