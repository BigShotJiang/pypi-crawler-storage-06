# Auto-generated to make this a Python package
from .perspective import Perspective as Perspective

__all__ = ["Perspective"]
