# Auto-generated to make this a Python package
from .table_permission import MetadataPermission, TablePermission

__all__ = [
    "MetadataPermission",
    "TablePermission",
]
