```mermaid
---
title: OrCondition
---
graph 
CompositeConditionHelper[CompositeConditionHelper]
OrCondition[<a href='/layout/erd/OrCondition'>OrCondition</a>]
OrCondition --->|Or| CompositeConditionHelper
```