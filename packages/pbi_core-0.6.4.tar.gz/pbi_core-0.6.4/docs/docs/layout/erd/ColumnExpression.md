```mermaid
---
title: ColumnExpression
---
graph 
ColumnExpression[<a href='/layout/erd/ColumnExpression'>ColumnExpression</a>]
ColumnSource[<a href='/layout/erd/ColumnSource'>ColumnSource</a>]
style ColumnSource stroke:#ff0000,stroke-width:1px
ColumnExpression ---> ColumnSource
```