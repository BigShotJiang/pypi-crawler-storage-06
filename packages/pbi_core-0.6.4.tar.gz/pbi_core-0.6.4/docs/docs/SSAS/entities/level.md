# Level


::: pbi_core.ssas.model_tables.level.Level