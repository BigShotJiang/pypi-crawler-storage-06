# KPI


::: pbi_core.ssas.model_tables.kpi.KPI