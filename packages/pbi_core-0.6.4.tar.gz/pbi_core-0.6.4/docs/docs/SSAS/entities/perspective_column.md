# Perspective Column


::: pbi_core.ssas.model_tables.perspective_column.PerspectiveColumn