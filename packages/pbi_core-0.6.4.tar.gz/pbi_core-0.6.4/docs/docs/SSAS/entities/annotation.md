# Annotation
::: pbi_core.ssas.model_tables.annotation.Annotation