# Perspective


:::pbi_core.ssas.model_tables.perspective.Perspective