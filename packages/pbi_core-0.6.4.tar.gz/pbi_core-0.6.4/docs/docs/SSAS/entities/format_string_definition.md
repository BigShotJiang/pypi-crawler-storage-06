# Format String Definition


::: pbi_core.ssas.model_tables.format_string_definition.FormatStringDefinition