# Relationship


::: pbi_core.ssas.model_tables.relationship.Relationship