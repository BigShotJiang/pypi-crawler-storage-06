# Alternate Of
::: pbi_core.ssas.model_tables.alternate_of.AlternateOf
