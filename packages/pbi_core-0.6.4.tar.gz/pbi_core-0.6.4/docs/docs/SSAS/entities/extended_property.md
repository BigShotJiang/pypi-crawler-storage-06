# Extended Property


::: pbi_core.ssas.model_tables.extended_property.ExtendedProperty