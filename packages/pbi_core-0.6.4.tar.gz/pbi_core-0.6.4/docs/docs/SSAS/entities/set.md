# Set


::: pbi_core.ssas.model_tables.set.Set