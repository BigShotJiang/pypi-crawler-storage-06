# get_rank

Returns the current rank in a distributed training.
