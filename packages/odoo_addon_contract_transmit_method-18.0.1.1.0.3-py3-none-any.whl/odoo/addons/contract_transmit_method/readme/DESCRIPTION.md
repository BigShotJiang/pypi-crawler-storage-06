Set transmit method (email, post, portal, ...) in contracts and
propagate it to invoices.
