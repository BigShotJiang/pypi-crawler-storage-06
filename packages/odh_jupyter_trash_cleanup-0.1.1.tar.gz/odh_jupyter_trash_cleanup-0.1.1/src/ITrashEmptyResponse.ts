export interface ITrashEmptyResponse {
  message: string;
  deleted: number;
}
