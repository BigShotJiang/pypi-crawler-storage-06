/**
 * Example of [Jest](https://jestjs.io/docs/getting-started) unit tests
 */

describe('odh-jupyter-trash-cleanup', () => {
  it.todo('activates the plugin without errors');
  it.todo('registers the "empty-trash" command in the CommandRegistry');
});
