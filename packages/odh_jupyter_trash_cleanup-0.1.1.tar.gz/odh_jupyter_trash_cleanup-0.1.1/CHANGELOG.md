# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## [0.1.0] - 2025-08-28

### Added

- Initial release of `odh-jupyter-trash-cleanup` JupyterLab extension providing:
  - UI command and toolbar button to empty the user's Trash directory.
  - Authenticated server handler to remove files under the configured Trash path.
  - Basic unit tests and packaging.

<!-- <END NEW CHANGELOG ENTRY> -->
