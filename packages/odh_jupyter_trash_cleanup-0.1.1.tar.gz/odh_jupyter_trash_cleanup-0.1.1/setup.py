__import__("setuptools").setup()
raise SystemExit(
    "This project uses pyproject.toml (PEP 517). Use `python -m build` or `pip install .`."
)