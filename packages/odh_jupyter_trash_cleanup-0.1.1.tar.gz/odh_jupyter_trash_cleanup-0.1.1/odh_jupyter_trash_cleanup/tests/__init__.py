"""Python unit tests for odh_jupyter_trash_cleanup."""
