
Gzip-like compression for tskit tree sequences.

Tszip is a command line utility and Python library for converting the
``.trees`` files used by `tskit <https://tskit.readthedocs.org/en/stable/>`_
into a highly compressed format. Please see the
`documentation <https://tszip.readthedocs.org/en/stable>`_
for more details and
`installation instructions <https://tszip.readthedocs.org/en/stable/installation.html>`_.
