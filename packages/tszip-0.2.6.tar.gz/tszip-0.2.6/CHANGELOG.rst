--------------------
[0.2.6] - 2025-09-18
--------------------

- In previous versions, if a metadata column had byte values outside the ASCII range,
  the file written would raise a `ValueError` when decompressed. This is now fixed,
  and files written with this bug are now read correctly.
  (benjeffery, #115)
- Drop Python 3.9 support, require Python >= 3.10 (#112, benjeffery)
- Support zarr v3 (#114, benjeffery)

--------------------
[0.2.5] - 2024-08-15
--------------------

Maintenance release

--------------------
[0.2.4] - 2024-07-10
--------------------

- tszip now supports Python 3.12, 3.8 support has been removed.

--------------------
[0.2.3] - 2023-10-30
--------------------

- Add `tszip.load` which loads both compressed and uncompressed trees sequences
  (benjeffery, #75)

- tszip now supports Python 3.10 and 3.11, 3.7 support has been removed.
  (benjeffery, #76)

--------------------
[0.2.2] - 2022-02-22
--------------------

- Support compressing to stdout (aabiddanda, #53, #64)

--------------------
[0.2.1] - 2022-01-26
--------------------

- Fix for `time_units` in tskit 0.4.0 (benjeffery, #54, #55)

- Add support for reference sequence (benjeffery, #59)

--------------------
[0.2.0] - 2021-11-08
--------------------

- Support decompressing to stdout. (aabiddanda, #44).

- Add support for new columns in tskit. (benjeffery, #39, #42).

--------------------
[0.1.0] - 2019-05-10
--------------------

Initial version
