(sec_development)=
# Development

If you would like to add some features to `tszip`, please read the following. If you think there is anything missing, please open an [issue](http://github.com/tskit-dev/tszip/issues) or [pull request](http://github.com/tskit-dev/tszip/pulls) on GitHub!

## Workflow

An overview of the workflow is at the [tskit docs](https://tskit.dev/tskit/docs/stable/development.html#workflow). Note the sections on running tests [here](https://tskit.dev/tskit/docs/stable/development.html#tests).
