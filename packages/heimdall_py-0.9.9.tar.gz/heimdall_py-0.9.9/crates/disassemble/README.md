# heimdall-disassembler

Disassembles EVM bytecode to EVM assembly
