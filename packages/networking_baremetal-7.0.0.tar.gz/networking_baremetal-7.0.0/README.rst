networking-baremetal plugin
---------------------------

This project's goal is to provide deep integration between the Networking
service and the Bare Metal service and advanced networking features like
notifications of port status changes and routed networks support in clouds
with Bare Metal service.

* Free software: Apache license
* Documentation: http://docs.openstack.org/networking-baremetal/latest
* Source: http://opendev.org/openstack/networking-baremetal
* Bugs: https://bugs.launchpad.net/networking-baremetal
* Release notes: https://docs.openstack.org/releasenotes/networking-baremetal/
