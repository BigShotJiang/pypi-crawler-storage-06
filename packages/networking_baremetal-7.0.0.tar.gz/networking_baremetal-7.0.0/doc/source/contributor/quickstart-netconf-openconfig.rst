Virtual lab with virtual switch and netconf-openconfig Device Driver
####################################################################

Ansible playbooks that can be used to set up a lab for developing
networking-baremetal network device integration is hosted on `GitHub
<https://github.com/hjensas/net-bm-lab>`_.
