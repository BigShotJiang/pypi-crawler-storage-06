"""Legacy entry point - redirect to new CLI."""

from git_mpc.cli import main

if __name__ == "__main__":
    main()
