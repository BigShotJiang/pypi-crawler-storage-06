"""Command handlers for git-mcp CLI."""
