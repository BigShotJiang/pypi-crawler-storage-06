"""Gemini CLI slash commands for Git MCP Server."""
