Generate a JSON schema for extracting the following information: {{prompt}}
