"""UI utility functions."""


def generate_line(char, length=40):
    """Generate a line of characters for display formatting."""
    return char * length + "\n"
