class WopnBank:
    def __init__(self, name, index):
        self.name = name
        self.index = index
        self.instruments = []
