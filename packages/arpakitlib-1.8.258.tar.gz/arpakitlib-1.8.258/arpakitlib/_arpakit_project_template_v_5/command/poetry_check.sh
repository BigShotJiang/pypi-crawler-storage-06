cd ..
poetry check
