Command Line Interface
======================


.. toctree::
    :maxdepth: 2

    ibridges_cli
    api/cli
