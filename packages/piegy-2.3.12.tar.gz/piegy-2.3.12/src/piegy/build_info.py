"""
Contains build info, whether it's local built, or a pre-compiled wheel.
Auto-generated at compile time.
"""

build_info = {
    "version": "2.3.12",
    "build date": "2025-09-23 18:13:25",
    "python used": "3.11.10",
    "platform": "darwin"
}
