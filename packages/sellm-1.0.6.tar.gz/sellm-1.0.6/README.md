# SELLM - AI-Powered Manifest Generator

[![PyPI version](https://badge.fury.io/py/sellm.svg)](https://badge.fury.io/py/sellm)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Build Status](https://travis-ci.com/tom-sapletta-com/sellm.svg?branch=main)](https://travis-ci.com/tom-sapletta-com/sellm)

**Generate ProServe manifests using AI from natural language descriptions**

---

## Table of Contents

- [Features](#-features)
- [Architecture](#️-architecture)  
- [Quick Start](#-quick-start)
- [Installation](#-installation)
- [Usage](#-usage)
- [API Reference](#-api-reference)
- [Docker Environment](#-docker-environment)
- [Testing](#-testing)
- [Monitoring](#-monitoring)
- [Configuration](#️-configuration)
- [Examples](#-examples)
- [Contributing](#-contributing)
- [License](#-license)

## Features

### Core Capabilities
- **AI-Powered Generation**: Natural language to ProServe manifest conversion using Mistral 7B
- **Structured Logging**: Enterprise-grade logging with wmlog integration
- **Intelligent Caching**: Redis-powered caching for 90% faster response times
- **REST API**: RESTful endpoints with comprehensive OpenAPI documentation
- **Real-time Monitoring**: WebSocket-based log streaming and system metrics
- **Smart Validation**: Built-in manifest validation with detailed error reporting
- **Auto-Detection**: Intelligent service type detection from descriptions
- **Production Ready**: Full Docker orchestration with health checks

### Service Types Supported
- **HTTP/REST APIs**: Web services with CRUD operations, authentication, middleware
- **WebSocket Services**: Real-time communication, chat applications, live updates
- **IoT Services**: Sensor data collection, MQTT integration, device management  
- **Background Jobs**: Scheduled tasks, data processing, async operations
- **Static Sites**: Frontend hosting, SPAs, documentation sites

### Performance & Reliability
- **High Availability**: Docker Compose with restart policies and health checks
- **Horizontal Scaling**: Multi-instance support with load balancing
- **Fault Tolerance**: Graceful degradation and error recovery
- **Security**: CORS configuration, input validation, secure defaults

## Architecture

### System Overview

```ascii
                    ┌─────────────────────────────────────────────┐
                    │              SELLM ECOSYSTEM                │
                    └─────────────────────────────────────────────┘
                                           │
                    ┌─────────────────────────────────────────────┐
                    │                 API Layer                   │
                    │  ┌─────────────┐ ┌─────────────┐ ┌────────┐ │
                    │  │    REST     │ │  WebSocket  │ │ Health │ │
                    │  │  Endpoints  │ │   Logging   │ │ Check  │ │
                    │  └─────────────┘ └─────────────┘ └────────┘ │
                    └─────────────────────────────────────────────┘
                                           │
                    ┌─────────────────────────────────────────────┐
                    │              Business Logic                 │
                    │  ┌─────────────┐ ┌─────────────┐ ┌────────┐ │
                    │  │ Manifest    │ │ Validation  │ │ Cache  │ │
                    │  │ Generator   │ │   Engine    │ │Manager │ │
                    │  └─────────────┘ └─────────────┘ └────────┘ │
                    └─────────────────────────────────────────────┘
                                           │
                    ┌─────────────────────────────────────────────┐
                    │             Integration Layer               │
                    │  ┌─────────────┐ ┌─────────────┐ ┌────────┐ │
                    │  │   Ollama    │ │    Redis    │ │ WMLog  │ │
                    │  │ LLM Client  │ │    Cache    │ │Logging │ │
                    │  └─────────────┘ └─────────────┘ └────────┘ │
                    └─────────────────────────────────────────────┘
                                           │
                    ┌─────────────────────────────────────────────┐
                    │            Infrastructure Layer             │
                    │  ┌─────────────┐ ┌─────────────┐ ┌────────┐ │
                    │  │   Docker    │ │   Network   │ │ Volume │ │
                    │  │  Containers │ │   Services  │ │Storage │ │
                    │  └─────────────┘ └─────────────┘ └────────┘ │
                    └─────────────────────────────────────────────┘
```

### Component Architecture

```mermaid
graph TB
    subgraph "Client Layer"
        CLI[CLI Client]
        API[REST API Client]
        WEB[Web Browser]
    end

    subgraph "SELLM Service"
        GATE[API Gateway]
        AUTH[Authentication]
        VAL[Validator]
        GEN[Manifest Generator]
        CACHE[Cache Manager]
    end

    subgraph "LLM Infrastructure"
        OLLAMA[Ollama Server]
        MISTRAL[Mistral 7B Model]
    end

    subgraph "Data Layer"
        REDIS[(Redis Cache)]
        LOGS[(Log Storage)]
    end

    subgraph "Monitoring"
        WS[WebSocket Logs]
        HEALTH[Health Checks]
        METRICS[Metrics]
    end

    CLI --> GATE
    API --> GATE
    WEB --> GATE
    
    GATE --> AUTH
    AUTH --> VAL
    VAL --> GEN
    GEN --> CACHE
    
    GEN --> OLLAMA
    OLLAMA --> MISTRAL
    
    CACHE --> REDIS
    GEN --> LOGS
    
    GATE --> WS
    GATE --> HEALTH
    CACHE --> METRICS

    style SELLM fill:#e1f5fe
    style LLM fill:#f3e5f5
    style Data fill:#e8f5e8
    style Monitoring fill:#fff3e0
```

### Docker Services Architecture

```ascii
    ┌─────────────────────────────────────────────────────────────────┐
    │                        Docker Compose                          │
    │                                                                 │
    │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
    │  │   sellm:9000    │  │  ollama:11435   │  │  redis:6377     │         │
    │  │  ┌───────────┐  │  │  ┌───────────┐  │  │  ┌───────────┐  │         │
    │  │  │   SELLM   │  │  │  │  Mistral  │  │  │  │   Cache   │  │         │
    │  │  │  Service  │◄─┼──┼─►│    7B     │  │  │  │  Storage  │  │         │
    │  │  │           │  │  │  │    LLM    │  │  │  │           │  │         │
    │  │  └───────────┘  │  │  └───────────┘  │  │  └───────────┘  │         │
    │  │                 │  │                 │  │                 │         │
    │  │  Health: /health│  │  Health: /api/  │  │  Health: ping   │         │
    │  │  Restart: always│  │  Restart: always│  │  Restart: always│         │
    │  └─────────────┘  └─────────────┘  └─────────────┘         │
    │           │                      │                      │       │
    │  ┌─────────────────────────────────────────────────────────┐   │
    │  │                  Shared Network                         │   │
    │  │              sellm_default                              │   │
    │  └─────────────────────────────────────────────────────────┘   │
    │                                                                 │
    │  ┌─────────────────────────────────────────────────────────┐   │
    │  │                  Persistent Volumes                     │   │
    │  │  ollama-data (Models) | redis_data (Cache)              │   │
    │  └─────────────────────────────────────────────────────────┘   │
    └─────────────────────────────────────────────────────────────────┘
```

### Data Flow Diagram

```mermaid
sequenceDiagram
    participant C as Client
    participant S as SELLM API
    participant R as Redis Cache
    participant O as Ollama LLM
    participant L as WMLog

    C->>S: POST /generate {description}
    S->>L: Log request received
    S->>R: Check cache for similar request
    
    alt Cache Hit
        R-->>S: Return cached manifest
        S->>L: Log cache hit
    else Cache Miss
        S->>L: Log cache miss
        S->>O: Send prompt to Mistral 7B
        O-->>S: Return generated manifest
        S->>R: Store in cache (TTL: 1h)
        S->>L: Log generation complete
    end
    
    S->>S: Validate manifest structure
    S->>L: Log validation result
    S-->>C: Return validated manifest
    
    Note over S,L: Real-time logs via WebSocket:8765
```

### Project Structure

```
sellm/
├── sellm.py                 # Main application (single-file architecture)
├── docker-compose.yml       # Container orchestration
├── Dockerfile              # Application image definition
├── .env                    # Environment configuration
├── .gitignore              # Version control exclusions
├── setup.py                # Package installation
├── README.md               # This documentation
├── LICENSE                 # Apache Software License
├── prompts.yaml           # Prompt templates & examples
├── test_e2e.py            # End-to-end test suite
├── examples/
│   └── manifests.yaml     # Generated manifest examples
└── scripts/
    └── run.sh             # Development startup script
```

## Quick Start

Get SELLM running in under 2 minutes:

```bash
# 1. Clone and navigate
git clone https://github.com/tom-sapletta-com/sellm.git
cd sellm

# 2. Start the complete stack
docker-compose up -d

# 3. Install Mistral model
docker-compose exec ollama ollama pull mistral:7b

# 4. Test the API
curl -X POST http://localhost:9000/generate \
  -H "Content-Type: application/json" \
  -d '{"description": "User authentication API with JWT", "type": "http"}' | jq

# 5. View real-time logs
# WebSocket: ws://localhost:8765
# Health check: http://localhost:9000/health
```

**That's it! SELLM is now generating ProServe manifests from natural language.**

---

## Installation

### Option 1: Docker Compose (Recommended)

**Production-ready deployment with full orchestration:**

```bash
# Clone repository
git clone https://github.com/tom-sapletta-com/sellm.git
cd sellm

# Start all services with health checks
docker-compose up -d

# Wait for services to be ready (optional)
docker-compose logs -f

# Install LLM model
docker-compose exec ollama ollama pull mistral:7b

# Verify installation
curl http://localhost:9000/health
curl http://localhost:9000/models
```

### Option 2: Local Development Setup

**For development and customization:**

```bash
# Prerequisites: Python 3.11+, Redis, Ollama
pip install --upgrade pip

# Clone and setup
git clone https://github.com/tom-sapletta-com/sellm.git
cd sellm

# Install dependencies
pip install -e .
pip install aiohttp pyyaml redis click wmlog

# Start external services
redis-server &
ollama serve &
ollama pull mistral:7b

# Configure environment
cp .env.example .env
# Edit .env for local setup:
# SELLM_HOST=localhost:11434
# REDIS_URL=redis://localhost:6379

# Start SELLM
python sellm.py serve --port 9000
```

### Option 3: Production Deployment

**High-availability production setup:**

```bash
# Use production docker-compose
cp docker-compose.yml docker-compose.prod.yml

# Configure production settings
cp .env.example .env.prod
# Edit with production values:
# - Set strong passwords
# - Configure monitoring
# - Set proper resource limits

# Deploy with production config
docker-compose -f docker-compose.prod.yml up -d

# Setup monitoring and backups
docker-compose exec redis redis-cli BGSAVE
docker-compose logs --tail=100 -f
```

### Requirements

| Component | Version | Purpose |
|-----------|---------|---------|
| **Python** | 3.11+ | Runtime environment |
| **Docker** | 20.0+ | Container orchestration |
| **Redis** | 7.0+ | Caching layer |
| **Ollama** | Latest | LLM inference engine |
| **Mistral 7B** | Latest | Language model |

### Port Configuration

| Service | Default Port | Purpose |
|---------|--------------|---------|
| **SELLM API** | 9000 | REST endpoints |
| **WebSocket Logs** | 8765 | Real-time logging |
| **Ollama** | 11435 | LLM inference |
| **Redis** | 6377 | Cache storage |

## Usage

### CLI Commands

**Generate manifests using natural language descriptions:**

```bash
# Basic generation with auto-detection
sellm generate "Create a REST API for user management with SQLite database"

# Specify service type
sellm generate "Real-time chat application" --type websocket

# Save to file
sellm generate "IoT sensor data collector with MQTT" -o sensor-manifest.yaml

# Validate existing manifest
sellm validate manifest.yaml

# Show available examples
sellm examples

# List supported service types
sellm types

# Check system status
sellm status
```

### API Server Usage

**Start the SELLM API server:**

```bash
# Default configuration (port 9000)
sellm serve

# Custom port and host
sellm serve --port 8080 --host 0.0.0.0

# With debug logging
sellm serve --debug

# Production mode with caching
sellm serve --cache --redis-url redis://localhost:6379
```

### Service Types & Examples

| Type | Description | Example Input |
|------|-------------|---------------|
| **http** | REST APIs, web services | "User authentication API with JWT tokens" |
| **websocket** | Real-time communication | "Live chat application with rooms" |
| **iot** | IoT data collection | "Arduino temperature sensor collector with MQTT publishing" |
| **static** | Static file hosting | "React SPA with nginx serving" |
| **background** | Scheduled tasks | "Daily backup job with email notifications" |
| **auto** | Auto-detect from description | "Arduino LED controller" → detects as IoT |

---

## API Reference

### Endpoints Overview

| Method | Endpoint | Purpose | Authentication |
|--------|----------|---------|----------------|
| `POST` | `/generate` | Generate ProServe manifest | None |
| `POST` | `/validate` | Validate manifest structure | None |
| `GET` | `/models` | List available LLM models | None |
| `GET` | `/health` | System health status | None |
| `GET` | `/metrics` | Performance metrics | None |
| `GET` | `/examples` | Example manifests | None |
| `WS` | `/ws` | Real-time logs (WebSocket) | None |

### POST /generate

**Generate a ProServe manifest from natural language description.**

#### Request Body

```json
{
  "description": "string (required) - Service description in natural language",
  "type": "string (optional) - Service type: http|websocket|iot|static|background|auto",
  "validate": "boolean (optional) - Validate generated manifest (default: true)",
  "cache": "boolean (optional) - Use Redis cache if available (default: true)",
  "template": "string (optional) - Base template to extend",
  "options": {
    "port": "number (optional) - Preferred port number",
    "cors": "boolean (optional) - Enable CORS",
    "ssl": "boolean (optional) - Enable SSL/TLS"
  }
}
```

#### Response

```json
{
  "status": "success|error",
  "manifest": {
    "name": "generated-service-name",
    "version": "1.0.0",
    "type": "http",
    "port": 8080,
    "description": "Generated service description",
    "endpoints": [...],
    "middleware": [...],
    "environment": {...}
  },
  "metadata": {
    "generation_time": 1.23,
    "cache_hit": false,
    "model_used": "mistral:7b",
    "validation_passed": true
  }
}
```

#### Examples

```bash
# Basic HTTP API
curl -X POST http://localhost:9000/generate \
  -H "Content-Type: application/json" \
  -d '{
    "description": "User management API with CRUD operations and JWT authentication",
    "type": "http",
    "options": {
      "port": 8080,
      "cors": true
    }
  }'

# Auto-detected IoT service
curl -X POST http://localhost:9000/generate \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Arduino temperature sensor collector with MQTT publishing",
    "type": "auto"
  }'

# WebSocket chat application
curl -X POST http://localhost:9000/generate \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Real-time chat with rooms and user presence",
    "type": "websocket",
    "validate": true
  }'
```

### POST /validate

**Validate a ProServe manifest structure and configuration.**

#### Request Body

```json
{
  "manifest": {
    // ProServe manifest object to validate
  },
  "strict": "boolean (optional) - Strict validation mode (default: false)"
}
```

#### Response

```json
{
  "status": "valid|invalid",
  "errors": [
    {
      "field": "port",
      "message": "Port number must be between 1024 and 65535",
      "severity": "error|warning"
    }
  ],
  "warnings": ["Optional field 'description' is recommended"],
  "suggestions": ["Consider adding health check endpoint"]
}
```

### GET /models

**List available LLM models and their status.**

#### Response

```json
{
  "models": [
    {
      "name": "mistral:7b",
      "status": "active",
      "size": "4.1GB",
      "capabilities": ["text-generation", "json-output"]
    }
  ],
  "active_model": "mistral:7b"
}
```

### GET /health

**System health check with service dependencies.**

#### Response

```json
{
  "status": "healthy|degraded|unhealthy",
  "services": {
    "sellm": {
      "status": "healthy",
      "uptime": 3600,
      "version": "1.0.0"
    },
    "ollama": {
      "status": "healthy",
      "model_loaded": "mistral:7b",
      "response_time_ms": 50
    },
    "redis": {
      "status": "healthy",
      "memory_usage": "15MB",
      "cache_hit_rate": 0.85
    }
  },
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### GET /metrics

**Performance and usage metrics.**

#### Response

```json
{
  "requests": {
    "total": 1250,
    "generate": 1100,
    "validate": 150,
    "errors": 23
  },
  "performance": {
    "avg_response_time_ms": 850,
    "cache_hit_rate": 78,
    "successful_generations": 0.95
  },
  "resources": {
    "memory_usage_mb": 512,
    "cpu_usage_percent": 15.5,
    "disk_usage_mb": 1024
  }
}
```

### WebSocket /ws

**Real-time log streaming and system events.**

#### Connection

```javascript
const ws = new WebSocket('ws://localhost:8765/ws');
ws.onmessage = (event) => {
  const log = JSON.parse(event.data);
  console.log(`[${log.level}] ${log.service}: ${log.message}`);
};
```

#### Message Format

```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "level": "info|warn|error",
  "service": "sellm|ollama|redis",
  "message": "Log message content",
  "metadata": {
    "request_id": "req-123",
    "user_agent": "curl/7.68.0",
    "duration_ms": 250
  }
}
```

---

## Docker Environment

### Container Architecture

SELLM uses a 3-tier Docker architecture for production deployments:

```ascii
┌──────────────────────────────────────────────────────────────┐
│                     SELLM Docker Stack                      │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │   SELLM     │  │   OLLAMA    │  │   REDIS     │         │
│  │  Container  │  │  Container  │  │  Container  │         │
│  ├─────────────┤  ├─────────────┤  ├─────────────┤         │
│  │Port: 9000   │  │Port: 11435  │  │Port: 6377   │         │
│  │Restart:auto │  │Restart:auto │  │Restart:auto │         │
│  │Health: /    │  │Health: /api │  │Health: ping │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
│         │                │                │                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                Shared Network                        │   │
│  │              (sellm_default)                         │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                Persistent Storage                    │   │
│  │   ollama-data (4GB+)  │  redis_data (1GB+)          │   │
│  └──────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────┘
```

### Service Details

| Service | Image | Purpose | Dependencies | Health Check |
|---------|-------|---------|--------------|--------------|
| **sellm** | `sellm:latest` | Main API service | ollama, redis | `GET /health` |
| **ollama** | `ollama/ollama:latest` | LLM inference engine | - | `GET /api/tags` |
| **redis** | `redis:7-alpine` | Cache & session storage | - | `redis-cli ping` |

### Docker Compose Commands

```bash
# Start all services
docker-compose up -d

# View logs in real-time
docker-compose logs -f

# Scale SELLM instances
docker-compose up -d --scale sellm=3

# Update services
docker-compose pull
docker-compose up -d --force-recreate

# Backup data
docker-compose exec redis redis-cli BGSAVE
docker cp sellm-redis-1:/data/dump.rdb ./backup/

# Monitor resource usage
docker stats sellm-sellm-1 sellm-ollama-1 sellm-redis-1

# Clean up
docker-compose down
docker system prune -f
```

### Environment Variables

```yaml
# docker-compose.yml environment section
environment:
  - SELLM_HOST=ollama:11435           # Internal network communication
  - REDIS_URL=redis://redis:6379      # Internal Redis connection
  - CACHE_TTL=3600                    # Cache TTL (seconds)
  - LOG_LEVEL=info                    # Logging verbosity
  - WORKERS=4                         # Concurrent workers
```

### Production Configuration

```env
# ========================================
# Production Environment Settings  
# ========================================

# Enhanced security
API_DEBUG=false                           # Disable debug mode
LOG_LEVEL=warn                            # Reduce log verbosity
CORS_ORIGINS=https://yourdomain.com       # Restrict CORS origins

# Performance optimization
CACHE_TTL=7200                            # Longer cache TTL
API_WORKERS=8                             # More workers
MAX_CONCURRENT_REQUESTS=100               # Higher concurrency

# Monitoring and alerting
METRICS_ENABLED=true                      # Enable metrics collection
METRICS_PORT=9090                         # Prometheus metrics port
ALERT_WEBHOOK_URL=https://alerts.example.com

# Backup and persistence
REDIS_PERSISTENCE=true                    # Enable Redis persistence
BACKUP_SCHEDULE=daily                     # Backup frequency
BACKUP_RETENTION=30                       # Backup retention days
```

### Configuration Validation

SELLM validates configuration on startup and provides detailed error messages:

```bash
# Validate configuration
sellm config validate

# Show current configuration
sellm config show

# Test configuration with dry run
sellm serve --dry-run

# Check environment setup
sellm doctor
```

### Configuration Templates

#### Development Template (.env.development)
```env
SELLM_HOST=localhost:11434
REDIS_URL=redis://localhost:6379
API_DEBUG=true
LOG_LEVEL=debug
CACHE_TTL=300
```

#### Testing Template (.env.testing)
```env
SELLM_MODEL=mistral:7b
API_PORT=9001
REDIS_URL=redis://localhost:6380
ENABLE_CACHE=false
LOG_LEVEL=error
```

#### Production Template (.env.production)
```env
SELLM_HOST=ollama:11435
REDIS_URL=redis://redis:6377
API_DEBUG=false
LOG_LEVEL=info
CORS_ORIGINS=https://api.yourdomain.com
RATE_LIMIT=1000
```

---

## Testing

### Test Suite Overview

SELLM includes comprehensive testing for reliability and performance:

```bash
# Run all tests
python test_e2e.py

# Run specific test categories
python test_e2e.py --category unit
python test_e2e.py --category integration
python test_e2e.py --category performance

# Test with different models
SELLM_MODEL=mistral:7b python test_e2e.py
SELLM_MODEL=llama2:7b python test_e2e.py

# Load testing
python test_e2e.py --load --requests=100 --concurrent=10
```

### Test Categories

#### Unit Tests
- Manifest generation logic
- Validation engine
- Cache management  
- Error handling

#### Integration Tests
- Ollama LLM communication
- Redis cache operations
- WebSocket log streaming
- Health check endpoints

#### End-to-End Tests
- Complete API workflows
- Docker container orchestration
- Cross-service communication
- Data persistence

#### Performance Tests
- Response time benchmarks
- Concurrent request handling
- Memory usage monitoring
- Cache hit rate optimization

### Testing with Docker

```bash
# Test container build
docker-compose -f docker-compose.test.yml up --build

# Run tests in containers
docker-compose exec sellm python test_e2e.py

# Performance testing
docker-compose exec sellm python test_e2e.py --performance

# Test service dependencies
docker-compose exec sellm curl http://ollama:11435/api/tags
docker-compose exec sellm redis-cli -h redis ping
```

### Test Results Example

```
SELLM Test Suite Results
========================
 Unit Tests:        15/15 passed (100%)
 Integration Tests: 8/8 passed (100%)  
 E2E Tests:        12/12 passed (100%)
 Performance Tests: 5/5 passed (100%)

Performance Metrics:
- Avg Response Time: 850ms
- Cache Hit Rate: 78%
- Concurrent Requests: 50 req/s
- Memory Usage: 512MB
- Error Rate: < 1%

Total: 40/40 tests passed 
```

---

## Monitoring

### Real-time Monitoring

SELLM provides comprehensive monitoring capabilities:

#### WebSocket Log Streaming
```javascript
// Connect to real-time logs
const ws = new WebSocket('ws://localhost:8765/ws');
ws.onmessage = (event) => {
  const log = JSON.parse(event.data);
  console.log(`[${log.level}] ${log.service}: ${log.message}`);
};
```

#### Health Monitoring
```bash
# System health check
curl http://localhost:9000/health | jq

# Service-specific health
curl http://localhost:9000/health/ollama
curl http://localhost:9000/health/redis
curl http://localhost:9000/health/sellm
```

### Performance Metrics

#### Cache Performance
- Hit Rate: 78% average (target: >70%)
- Miss Penalty: ~2.5s for LLM generation
- Storage Usage: Redis memory efficiency
- TTL Management: Automatic expiration

#### Response Times
- Cache Hit: ~50ms average  
- Cache Miss: ~850ms average
- WebSocket: <10ms latency
- Health Check: <5ms

#### Resource Usage
- Memory: 512MB baseline + model size
- CPU: 15-25% during generation
- Disk I/O: Minimal (cache only)
- Network: Ollama communication overhead

### Monitoring Dashboard

```bash
# View metrics endpoint
curl http://localhost:9000/metrics | jq

# Monitor Docker resources
docker stats --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}"

# Redis monitoring
docker-compose exec redis redis-cli monitor
docker-compose exec redis redis-cli info memory
```

---

## Configuration

### Environment Variables

SELLM uses environment variables for flexible configuration across development, staging, and production environments.

#### Core Configuration (.env)

```env
# ========================================
# SELLM Core Configuration
# ========================================

# LLM Settings
SELLM_MODEL=mistral:7b                    # LLM model to use
SELLM_HOST=localhost:11434                # Ollama server address
SELLM_TIMEOUT=30                          # LLM request timeout (seconds)
SELLM_MAX_TOKENS=4096                     # Maximum response tokens

# API Server Settings
API_HOST=0.0.0.0                          # API server bind address
API_PORT=9000                             # API server port
API_WORKERS=4                             # Number of worker processes
API_DEBUG=false                           # Enable debug mode

# Cache Settings
REDIS_URL=redis://localhost:6379          # Redis connection URL
CACHE_TTL=3600                            # Cache TTL (seconds)
CACHE_PREFIX=sellm:                       # Redis key prefix
ENABLE_CACHE=true                         # Enable/disable caching

# Logging Settings  
LOG_LEVEL=info                            # Logging level: debug|info|warn|error
LOG_FORMAT=json                           # Log format: json|text
LOG_FILE=/var/log/sellm.log              # Log file path (optional)
WEBSOCKET_LOG_PORT=8765                   # WebSocket log streaming port

# Security Settings
CORS_ENABLED=true                         # Enable CORS
CORS_ORIGINS=*                            # Allowed CORS origins
RATE_LIMIT=100                            # Requests per minute limit
MAX_REQUEST_SIZE=10MB                     # Maximum request body size

# Performance Settings
REQUEST_TIMEOUT=60                        # API request timeout
KEEP_ALIVE_TIMEOUT=5                      # Keep-alive timeout
MAX_CONCURRENT_REQUESTS=50                # Max concurrent requests
```

#### Docker Configuration

```env
# ========================================  
# Docker-specific Configuration
# ========================================

# Internal Docker network communication
SELLM_HOST=ollama:11435                   # Ollama service name
REDIS_URL=redis://redis:6377              # Redis service name

# Container resource limits
SELLM_MEMORY_LIMIT=1g                     # Memory limit for SELLM
OLLAMA_MEMORY_LIMIT=8g                    # Memory limit for Ollama
REDIS_MEMORY_LIMIT=512m                   # Memory limit for Redis

# Docker health check settings
HEALTH_CHECK_INTERVAL=30s                 # Health check frequency
HEALTH_CHECK_TIMEOUT=10s                  # Health check timeout
HEALTH_CHECK_RETRIES=3                    # Health check retry count
```

#### Production Configuration

```env
# ========================================
# Production Environment Settings  
# ========================================

# Enhanced security
API_DEBUG=false                           # Disable debug mode
LOG_LEVEL=warn                            # Reduce log verbosity
CORS_ORIGINS=https://yourdomain.com       # Restrict CORS origins

# Performance optimization
CACHE_TTL=7200                            # Longer cache TTL
API_WORKERS=8                             # More workers
MAX_CONCURRENT_REQUESTS=100               # Higher concurrency

# Monitoring and alerting
METRICS_ENABLED=true                      # Enable metrics collection
METRICS_PORT=9090                         # Prometheus metrics port
ALERT_WEBHOOK_URL=https://alerts.example.com

# Backup and persistence
REDIS_PERSISTENCE=true                    # Enable Redis persistence
BACKUP_SCHEDULE=daily                     # Backup frequency
BACKUP_RETENTION=30                       # Backup retention days
```

### Configuration Validation

SELLM validates configuration on startup and provides detailed error messages:

```bash
# Validate configuration
sellm config validate

# Show current configuration
sellm config show

# Test configuration with dry run
sellm serve --dry-run

# Check environment setup
sellm doctor
```

### Configuration Templates

#### Development Template (.env.development)
```env
SELLM_HOST=localhost:11434
REDIS_URL=redis://localhost:6379
API_DEBUG=true
LOG_LEVEL=debug
CACHE_TTL=300
```

#### Testing Template (.env.testing)
```env
SELLM_MODEL=mistral:7b
API_PORT=9001
REDIS_URL=redis://localhost:6380
ENABLE_CACHE=false
LOG_LEVEL=error
```

#### Production Template (.env.production)
```env
SELLM_HOST=ollama:11435
REDIS_URL=redis://redis:6377
API_DEBUG=false
LOG_LEVEL=info
CORS_ORIGINS=https://api.yourdomain.com
RATE_LIMIT=1000
```

---

## Examples

### Manifest Generation Examples

SELLM excels at generating production-ready ProServe manifests from natural language descriptions. Here are comprehensive examples:

#### Example 1: REST API with Authentication

**Input Prompt:**
```json
{
  "description": "User management API with JWT authentication, CRUD operations, role-based access control, and email verification",
  "type": "http",
  "options": {
    "port": 8080,
    "cors": true,
    "ssl": false
  }
}
```

**Generated Manifest:**
```yaml
name: user-management-api
version: 1.0.0
type: http
description: User management API with JWT authentication and RBAC
author: SELLM Generator
license: Apache Software License

server:
  host: 0.0.0.0
  port: 8080
  cors:
    enabled: true
    origins: ["*"]
    methods: ["GET", "POST", "PUT", "DELETE"]

endpoints:
  - path: /auth/login
    method: POST
    handler: auth.login
    middleware: [validation, rate_limit]
  - path: /auth/register  
    method: POST
    handler: auth.register
    middleware: [validation, email_verification]
  - path: /users
    method: GET
    handler: users.list
    middleware: [auth_required, rbac_check]
  - path: /users/{id}
    method: GET
    handler: users.get
    middleware: [auth_required, owner_or_admin]
  - path: /users/{id}
    method: PUT
    handler: users.update
    middleware: [auth_required, owner_or_admin, validation]
  - path: /users/{id}
    method: DELETE
    handler: users.delete
    middleware: [auth_required, admin_required]

middleware:
  - name: auth_required
    type: jwt_auth
    config:
      secret: ${JWT_SECRET}
      algorithm: HS256
  - name: rbac_check
    type: role_based_access
    config:
      roles: [admin, user, moderator]
  - name: rate_limit
    type: rate_limiting
    config:
      requests_per_minute: 100

database:
  type: postgresql
  url: ${DATABASE_URL}
  migrations: ./migrations

environment:
  - JWT_SECRET
  - DATABASE_URL
  - SMTP_HOST
  - SMTP_PORT
```

#### Example 2: IoT Data Collector

**Input Prompt:**
```json
{
  "description": "Arduino temperature and humidity sensor data collector with MQTT publishing, time-series storage, and real-time alerts",
  "type": "iot"
}
```

**Generated Manifest:**
```yaml
name: iot-sensor-collector
version: 1.0.0
type: iot
description: Arduino sensor data collector with MQTT and time-series storage
author: SELLM Generator

iot:
  protocols: [mqtt, http]
  device_types: [arduino, esp32, raspberry_pi]
  
mqtt:
  broker: ${MQTT_BROKER_URL}
  topics:
    - sensors/temperature/+/data
    - sensors/humidity/+/data
    - sensors/+/status
  qos: 1
  retain: true

sensors:
  - name: temperature
    type: DHT22
    unit: celsius
    range: [-40, 80]
    precision: 0.1
  - name: humidity  
    type: DHT22
    unit: percentage
    range: [0, 100]
    precision: 0.1

data_processing:
  - name: validation
    rules:
      - temperature: [-50, 100]
      - humidity: [0, 100]
  - name: aggregation
    interval: 5m
    functions: [min, max, avg, stddev]

storage:
  type: influxdb
  url: ${INFLUXDB_URL}
  database: sensor_data
  retention_policy: 30d

alerts:
  - name: high_temperature
    condition: temperature > 35
    action: webhook
    url: ${ALERT_WEBHOOK_URL}
  - name: low_humidity
    condition: humidity < 20
    action: email
    recipients: [admin@example.com]

background_tasks:
  - name: data_cleanup
    schedule: "0 2 * * *"
    handler: cleanup.old_data
  - name: health_check
    schedule: "*/5 * * * *"
    handler: health.check_devices

environment:
  - MQTT_BROKER_URL
  - INFLUXDB_URL
  - ALERT_WEBHOOK_URL
```

#### Example 3: WebSocket Chat Application

**Input Prompt:**
```json
{
  "description": "Real-time chat application with rooms, user presence, message history, and file sharing",
  "type": "websocket"
}
```

**Generated Manifest:**
```yaml
name: realtime-chat-app
version: 1.0.0
type: websocket
description: Real-time chat with rooms and user presence
author: SELLM Generator

websocket:
  path: /ws
  ping_interval: 30
  ping_timeout: 10
  max_connections: 1000

rooms:
  max_users_per_room: 50
  message_history_limit: 1000
  allowed_file_types: [image, document]
  max_file_size: 10MB

events:
  - name: user_join
    handler: chat.user_join
    broadcast: room
  - name: user_leave
    handler: chat.user_leave  
    broadcast: room
  - name: message_send
    handler: chat.send_message
    broadcast: room
    validation: message_schema
  - name: file_upload
    handler: files.upload
    broadcast: room
    middleware: [auth_required, file_validation]

presence:
  enabled: true
  timeout: 60s
  statuses: [online, away, busy, offline]

storage:
  messages:
    type: mongodb
    collection: messages
    indexes: [room_id, timestamp]
  files:
    type: s3
    bucket: ${S3_BUCKET_NAME}
    max_size: 10MB

rate_limiting:
  messages_per_minute: 60
  files_per_hour: 10

middleware:
  - name: auth_required
    type: websocket_auth
    config:
      token_header: Authorization
  - name: file_validation
    type: file_validator
    config:
      allowed_types: [jpg, png, pdf, docx]
      max_size: 10485760

environment:
  - MONGODB_URL
  - S3_BUCKET_NAME
  - S3_ACCESS_KEY
  - S3_SECRET_KEY
```

#### Example 4: Static Site Hosting

**Input Prompt:**
```json
{
  "description": "Static React SPA hosting with CDN integration, SSL termination, and progressive web app features",
  "type": "static"
}
```

**Generated Manifest:**
```yaml
name: react-spa-hosting
version: 1.0.0  
type: static
description: React SPA with CDN and PWA features
author: SELLM Generator

static:
  root: ./build
  index: index.html
  fallback: index.html
  cache_control: public, max-age=31536000
  
compression:
  enabled: true
  algorithms: [gzip, brotli]
  types: [text/html, text/css, application/javascript]

ssl:
  enabled: true
  cert_path: /etc/ssl/certs/app.crt
  key_path: /etc/ssl/private/app.key
  redirect_http: true

headers:
  security:
    - "X-Content-Type-Options: nosniff"
    - "X-Frame-Options: DENY"
    - "X-XSS-Protection: 1; mode=block"
  cache:
    - "Cache-Control: public, max-age=31536000"
  pwa:
    - "Service-Worker-Allowed: /"

pwa:
  manifest: /manifest.json
  service_worker: /sw.js
  offline_fallback: /offline.html

cdn:
  provider: cloudflare
  zones: [${CDN_ZONE_ID}]
  purge_on_deploy: true

monitoring:
  analytics: google_analytics
  performance: web_vitals
  uptime: pingdom

environment:
  - CDN_ZONE_ID
  - GA_TRACKING_ID
```

### Service Type Detection Examples

| Input Description | Auto-Detected Type | Confidence | Reasoning |
|-------------------|-------------------|------------|-----------|
| "Arduino LED controller with GPIO" | `iot` | 95% | Keywords: Arduino, LED, GPIO |
| "User authentication with JWT tokens" | `http` | 92% | Keywords: authentication, JWT, API |
| "Live chat with real-time messaging" | `websocket` | 98% | Keywords: live, real-time, chat |
| "React frontend hosting" | `static` | 90% | Keywords: React, frontend, hosting |
| "Daily backup job with email alerts" | `background` | 88% | Keywords: daily, job, scheduled |

### Advanced Usage Patterns

#### Prompt Engineering Tips

```bash
# Good: Specific and detailed
"REST API for e-commerce with product catalog, shopping cart, payment processing via Stripe, user authentication, and order management"

# Poor: Too vague  
"API for online store"

# Good: Technical requirements specified
"WebSocket chat application supporting 1000+ concurrent users, message persistence, file uploads up to 10MB, room-based messaging with moderation"

# Poor: Missing technical details
"Chat app with rooms"
```

#### Template-based Generation

```bash
# Use existing manifest as template
curl -X POST http://localhost:9000/generate \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Blog management system",
    "type": "http",
    "template": "user-management-api",
    "options": {
      "extend_endpoints": true,
      "add_admin_panel": true
    }
  }'
```

---

## Roadmap

### Version 1.1.0 (Next Release)
- Multi-Model Support: GPT-4, Claude, Gemini integration
- Template System: Reusable manifest templates and inheritance
- Advanced Validation: Custom validation rules and plugins
- Web UI: Browser-based manifest generator interface
- CLI Enhancements: Interactive mode, project initialization

### Version 1.2.0 (Mid-term)
- ProServe Integration: Native ProServe CLI plugin
- Cloud Deployment: AWS, GCP, Azure deployment templates  
- Monitoring Dashboard: Real-time metrics and analytics UI
- Team Collaboration: Multi-user projects and sharing
- Version Control: Git integration and manifest versioning

### Version 2.0.0 (Long-term)
- Multi-Language Support: Python, Node.js, Go, Rust manifests
- Microservices Composer: Multi-service architecture generation
- AI-Powered Optimization: Performance and security suggestions
- Plugin Ecosystem: Community-contributed extensions
- Enterprise Features: SSO, audit logs, compliance reporting

### Community Requests
- GraphQL API support
- Kubernetes manifest generation  
- Terraform infrastructure templates
- OpenAPI specification generation
- Docker Swarm orchestration

**Vote on features at [GitHub Discussions](https://github.com/tom-sapletta-com/sellm/discussions)**

---

## Contributing

We welcome contributions from the community! SELLM thrives on collaborative development.

### Quick Start for Contributors

```bash
# Fork and clone
git clone https://github.com/YOUR_USERNAME/sellm.git
cd sellm

# Setup development environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install

# Run tests
python test_e2e.py
```

### Development Guidelines

#### Code Style
- Python: Follow PEP 8 with Black formatting
- Comments: Clear, concise documentation for complex logic
- Type Hints: Use type annotations for all functions
- Tests: Write tests for new features and bug fixes

#### Commit Messages
```bash
# Format: type(scope): description

feat(api): add WebSocket authentication support
fix(docker): resolve Ollama connection timeout
docs(readme): update installation instructions
test(e2e): add performance benchmark tests
```

#### Pull Request Process

1. Issue First: Create/reference an issue for significant changes
2. Branch Naming: Use `feature/description` or `fix/description`
3. Documentation: Update README and API docs if needed
4. Tests: Ensure all tests pass and add new ones
5. Review: Request review from maintainers

### Contribution Areas

| Area | Skills Needed | Impact |
|------|---------------|--------|
| Core LLM Integration | Python, AI/ML, API design | High |
| Docker/DevOps | Docker, K8s, CI/CD | High |
| Frontend/UI | React, WebSocket, UX | Medium |
| Documentation | Technical writing | Medium |
| Testing | Pytest, E2E testing | High |
| Performance | Optimization, profiling | Medium |

### Development Setup

#### Local Development
```bash
# Start dependencies
docker-compose -f docker-compose.dev.yml up -d

# Run SELLM in development mode
python sellm.py serve --debug --reload

# Run tests with coverage
pytest --cov=sellm tests/
```

#### Testing Guidelines
- Unit Tests: Test individual functions and classes
- Integration Tests: Test API endpoints and database operations
- E2E Tests: Test complete user workflows
- Performance Tests: Benchmark response times and memory usage

### Community

- Discord: [Join our community](https://discord.gg/sellm)
- GitHub Discussions: Feature requests and technical discussions
- Twitter: [@sellm_ai](https://twitter.com/sellm_ai) for updates
- Blog: [dev.to/sellm](https://dev.to/sellm) for tutorials

### Recognition

Contributors are recognized in:
- README Contributors Section: All contributors listed
- Release Notes: Major contributors highlighted  
- Community Spotlight: Monthly contributor features
- Swag Program: Stickers and shirts for active contributors

---

## License

SELLM is released under the Apache Software License 2.0.

```
Copyright 2024 Tom Sapletta  
info@softreck.dev  
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at:

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

### Third-Party Licenses

SELLM incorporates several open-source projects:
- Ollama: MIT License - LLM inference engine
- Redis: BSD 3-Clause - Caching and session storage  
- aiohttp: Apache 2.0 - HTTP server framework
- wmlog: Apache 2.0 - Structured logging library

---

## Support

### Getting Help

| Issue Type | Best Channel | Response Time |
|------------|--------------|---------------|
| Bug Reports | [GitHub Issues](https://github.com/tom-sapletta-com/sellm/issues) | 24-48 hours |
| Feature Requests | [GitHub Discussions](https://github.com/tom-sapletta-com/sellm/discussions) | 1-2 weeks |
| Usage Questions | [Discord Community](https://discord.gg/sellm) | Real-time |
| Security Issues | security@softreck.dev | 24 hours |
| Commercial Support | enterprise@softreck.dev | Same day |

### Documentation

- API Documentation: Complete endpoint reference with examples
- Tutorials: Step-by-step guides for common use cases  
- Video Guides: YouTube channel with tutorials and demos
- Best Practices: Production deployment and optimization guides
- Troubleshooting: Common issues and solutions

### Enterprise Support

SoftReck Enterprise Solutions offers professional support for SELLM:

- Priority Support: Dedicated support team with SLA
- Custom Development: Feature development and customization
- Training & Consulting: Team training and best practices
- Security & Compliance: Security audits and compliance certification
- Managed Hosting: Fully managed SELLM cloud instances

Contact: enterprise@softreck.dev | +1-555-SOFTRECK

### Community Resources

- Mobile App: SELLM companion app (iOS/Android)
- Interactive Tutorial: Browser-based learning environment
- Blog: Technical articles and case studies
- Podcast: "AI-Powered Development" featuring SELLM users
- Events: Meetups, webinars, and conference talks

### Status & Updates

- System Status: [status.sellm.dev](https://status.sellm.dev)
- Release Notes: [GitHub Releases](https://github.com/tom-sapletta-com/sellm/releases)
- Security Advisories: [GitHub Security](https://github.com/tom-sapletta-com/sellm/security)
- Newsletter: Monthly updates on features and community

---

## Documentation

### Python Packages

Explore the ecosystem of Python packages related to SELLM:

- [ProServe](https://pypi.org/project/proserve/) - Core microservices framework
- [Servos](https://pypi.org/project/servos/) - Environment isolation and orchestration
- [wmlog](https://pypi.org/project/wmlog/) - Centralized structured logging
- [SELLM](https://pypi.org/project/sellm/) - AI-powered manifest generator
- [EDPMT](https://pypi.org/project/edpmt/) - Hardware control framework for IoT

---

<div align="center">

## Thank You!

SELLM - *Making ProServe manifest creation as simple as describing what you want!*

[Star on GitHub](https://github.com/tom-sapletta-com/sellm) • [Docker Hub](https://hub.docker.com/r/sellm/sellm) • [Documentation](https://docs.sellm.dev) • [Discord](https://discord.gg/sellm)

---

*Built with by [Tom Sapletta](https://github.com/tom-sapletta-com) and the SELLM community*

*Empowering developers to create microservices through natural language since 2024*

</div>
