
## CATO-CLI - query.site.secondaryAwsVSocket:
[Click here](https://api.catonetworks.com/documentation/#query-query.site.secondaryAwsVSocket) for documentation on this operation.

### Usage for query.site.secondaryAwsVSocket:

`catocli query site secondaryAwsVSocket -h`

`catocli query site secondaryAwsVSocket <json>`

`catocli query site secondaryAwsVSocket "$(cat < query.site.secondaryAwsVSocket.json)"`

`catocli query site secondaryAwsVSocket '{"socketId":"id"}'`

`catocli query site secondaryAwsVSocket -p '{
    "socketId": "id"
}'`


#### Operation Arguments for query.site.secondaryAwsVSocket ####

`accountId` [ID] - (required) N/A    
`socketId` [ID] - (required) N/A    
