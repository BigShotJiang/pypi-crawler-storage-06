
## CATO-CLI - mutation.container:
[Click here](https://api.catonetworks.com/documentation/#mutation-container) for documentation on this operation.

### Usage for mutation.container:

`catocli mutation container -h`
