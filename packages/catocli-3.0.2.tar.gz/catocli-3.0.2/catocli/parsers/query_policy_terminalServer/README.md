
## CATO-CLI - query.policy.terminalServer:
[Click here](https://api.catonetworks.com/documentation/#query-terminalServer) for documentation on this operation.

### Usage for query.policy.terminalServer:

`catocli query policy terminalServer -h`
