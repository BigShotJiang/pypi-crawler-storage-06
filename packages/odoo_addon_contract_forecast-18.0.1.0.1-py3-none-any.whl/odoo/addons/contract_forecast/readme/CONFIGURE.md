Go **General Settings** under the **Contract Forecast** section:

- **Enable Contract Forecast**: Enable or disable forecasting for the company.
- **Number of Contract Forecast Periods**: Define how many future periods are 
  generated.
- **Forecast Period Type**: Choose between **Monthly** or **Yearly** periods.
