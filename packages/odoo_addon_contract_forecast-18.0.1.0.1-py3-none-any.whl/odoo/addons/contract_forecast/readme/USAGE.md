1. Open a **Contract**.
2. Click on the **Forecast** button to access the generated forecast periods.
3. Forecasts can be analyzed through:
   - **Pivot view** (grouped by Invoice Date)
   - **Tree view** (detailed forecast lines)

Forecast periods are regenerated automatically when relevant fields are 
modified (e.g., quantity, price, dates).
