# import re
# from syncmodels.model import Enum

# from .models import (
#     BudgetTypeEnum,
#     TravelPartyCompositionEnum,
# )

DEFAULT_LANGUAGE = "es"

MODEL_TABLE = "model"

TAG_KEY = "tags"

UID_TYPE = str

TAG_KEY = "tags"

MONOTONIC_KEY = "wave__"

# ----------------------------------------------------------
# Namespaces
# ----------------------------------------------------------

TEST_NS = "test"
APP_NS = "swarm"
APP_DB = "swarm"
PARTICLE_THING = "particle"

CONFIG_NS = "config"
RAW_NS = "raw"
PREFERENCES_NS = "preferences"


# ----------------------------------------------------------
# MAPPING
# ----------------------------------------------------------
MAPPING = {}
