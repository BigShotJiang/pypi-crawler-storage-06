# timescape-placeholder

This is not the timescape package you are looking for.

If you ended up here, you likely installed the wrong package. Please double-check your installation instructions.

Remember that installing packages from PyPI without verification can be risky. This project exists to prevent cybersquatting, and every import from it will raise this error.