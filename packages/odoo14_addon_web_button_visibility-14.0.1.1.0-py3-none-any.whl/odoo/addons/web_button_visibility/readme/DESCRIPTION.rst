This module allows to hide specific buttons for specific user groups if specific conditions are verified.
