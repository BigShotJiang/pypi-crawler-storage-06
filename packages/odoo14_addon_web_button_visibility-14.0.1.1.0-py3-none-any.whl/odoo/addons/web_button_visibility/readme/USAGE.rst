Go to Settings > Technical > Models, open a model

In tab "Hide button rule", add a button name and a group, and optionally a condition

For users of that group and as long as the condition is met, button is not visible.
