This module can be useful in combination with customized workflows
(eg: module base_substate) to avoid user from performing certain actions if a specific
condition is verified.
