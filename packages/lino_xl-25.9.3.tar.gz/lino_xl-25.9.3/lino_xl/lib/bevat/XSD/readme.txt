Files downloaded from 
https://finances.belgium.be/fr/E-services/Intervat/documentation-technique
