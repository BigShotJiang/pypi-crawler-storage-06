# -*- coding: UTF-8 -*-
# Copyright 2012 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""
The :term:`dummy module` for `contacts`, 
used by :func:`lino.core.utils.resolve_app`.
"""
from builtins import object


class Partner(object):
    pass


class Partners(object):
    pass


class PartnerDocument(object):
    pass
