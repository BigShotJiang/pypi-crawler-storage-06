"""
Mixture of CLI and TUI
"""

from .main import main
