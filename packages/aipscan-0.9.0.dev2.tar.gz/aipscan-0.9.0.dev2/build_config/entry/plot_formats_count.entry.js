import "bootstrap/dist/css/bootstrap.css";

import $ from "jquery";
window.$ = window.jQuery = $;

import "/AIPscan/static/css/custom.css";
