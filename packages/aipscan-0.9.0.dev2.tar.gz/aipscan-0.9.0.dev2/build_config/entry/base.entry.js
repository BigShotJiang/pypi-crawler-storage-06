import "./shared/base_shared.js";
