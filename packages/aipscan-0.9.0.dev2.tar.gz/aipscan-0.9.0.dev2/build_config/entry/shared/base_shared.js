import "bootstrap/dist/css/bootstrap.css";
import "@fortawesome/fontawesome-free/css/all.css";
import "jquery-ui-dist/jquery-ui.min.css";

import $ from "jquery";
import "jquery-ui-dist/jquery-ui.min.js";

window.$ = window.jQuery = $;

import "bootstrap";

import "/AIPscan/static/css/custom.css";
