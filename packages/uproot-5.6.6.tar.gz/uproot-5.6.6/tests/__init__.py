# BSD 3-Clause License; see https://github.com/scikit-hep/uproot5/blob/main/LICENSE
