---
name: Documentation
about: Something needs to be explained…
title: ''
labels: docs
assignees: ''

---

On the [tutorials site](https://uproot.readthedocs.io/)?

In the Python docstrings? (They're presented on the same website.)

What, specifically, needs more explanation?
