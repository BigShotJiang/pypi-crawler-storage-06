Developer and user documentation.
Design and themes gratefully copied from [Requests](https://github.com/psf/requests).
