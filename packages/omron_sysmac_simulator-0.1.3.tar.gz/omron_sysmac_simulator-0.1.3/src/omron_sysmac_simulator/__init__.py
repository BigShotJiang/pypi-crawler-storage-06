__author__ = 'Joseph Ryan'
__license__ = "GPLv3"
__maintainer__ = "Joseph Ryan"
__email__ = "jr@aphyt.com"
