# maksim_132

Библиотека для управления сервомотором через Arduino с поддержкой Telegram бота.

## Установка

```bash
pip install maksim_132_servo