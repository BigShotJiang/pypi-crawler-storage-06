from llama_index.embeddings.opea.base import OPEAEmbedding

__all__ = ["OPEAEmbedding"]
