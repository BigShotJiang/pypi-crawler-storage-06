__all__ = [
    "Page",
]

from .abstract_pages import Page
