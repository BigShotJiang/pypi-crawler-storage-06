# TODO: support formatting with markdown and component json
# https://klikli-dev.github.io/modonomicon/docs/basics/page-types
