"""
Server entry points for GitLab Pipeline Analyzer MCP Server

Copyright (c) 2025 Siarhei Skuratovich
Licensed under the MIT License - see LICENSE file for details
"""
