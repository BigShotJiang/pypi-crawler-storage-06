"""
Test package for GitLab Pipeline Analyzer MCP server

Copyright (c) 2025 Siarhei Skuratovich
Licensed under the MIT License - see LICENSE file for details
"""
