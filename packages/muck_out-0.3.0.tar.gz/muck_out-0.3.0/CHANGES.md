# changes to muck_out

## 0.3.0

- Split into stubs and types
- Allow some classes in links [muck_out#11](https://codeberg.org/bovine/muck_out/issues/11)

## 0.2.0

- Add stub objects [muck_out#6](https://codeberg.org/bovine/muck_out/issues/6)
- Remove griffe-fieldz as dependency [muck_out#5](https://codeberg.org/bovine/muck_out/issues/5)

## 0.1.1

- Fix publish credentials

## 0.1.0

- Add release pipeline [muck_out](https://codeberg.org/bovine/muck_out/issues/2)
