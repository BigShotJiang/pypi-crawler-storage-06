"""Handles authentication related things."""
