"""Http response and url utils for datacosmos."""
