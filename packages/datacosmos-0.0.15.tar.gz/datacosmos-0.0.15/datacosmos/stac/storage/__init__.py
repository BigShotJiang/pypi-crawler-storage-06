"""Facade module for all storage-related operations."""

from datacosmos.stac.storage.storage_client import StorageClient

__all__ = ["StorageClient"]
