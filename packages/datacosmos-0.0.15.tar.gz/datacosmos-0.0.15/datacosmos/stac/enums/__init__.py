"""Enums for STAC."""
