__version__ = "0.4.0"
"""The version of the package."""
