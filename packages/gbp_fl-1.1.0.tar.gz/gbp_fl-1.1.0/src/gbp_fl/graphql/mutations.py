"""The Mutation GraphQL type for gbp-fl"""

from ariadne import ObjectType

Mutation = ObjectType("Mutation")
