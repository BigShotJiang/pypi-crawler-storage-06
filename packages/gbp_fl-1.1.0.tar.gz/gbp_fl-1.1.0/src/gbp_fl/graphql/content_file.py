"""The GraphQL flContentFile resolver for gbp-fl"""

from ariadne import ObjectType

flContentFile = ObjectType("flContentFile")
