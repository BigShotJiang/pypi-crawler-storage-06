'''
Version Checker module entry point
'''
__version__ = '0.3.0'
