from .openinference import setup

__all__ = ["setup"]
