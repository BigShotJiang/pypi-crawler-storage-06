# IDSignal

IDSignal is a python module with tools which can be used to add signaling between different components.

## The Current State of IDSignal

IDSignal is currently in beta version.
