# warlock-waker

paradigm: log sdk

简单测试
1

- 添加wake