from .resolver import *  # noqa
# NOTE: order imported here will be order tabs appear in loader dialog
from .file import *  # noqa
from .file_drop import *  # noqa
from .url import *  # noqa
from .object import *  # noqa