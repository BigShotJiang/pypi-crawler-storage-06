import logging

logger = logging.getLogger("aiopytesseract")
logger.addHandler(logging.NullHandler())
