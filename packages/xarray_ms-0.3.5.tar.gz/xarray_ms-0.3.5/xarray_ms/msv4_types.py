from typing import List

CORRELATED_DATASET_TYPES: List[str] = ["visibility", "spectrum", "wvr"]
