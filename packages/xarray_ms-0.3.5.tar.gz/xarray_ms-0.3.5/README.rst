xarray-ms
=========

|CI Status| |Doc Status| |Version Status|

xarray-ms presents an xarray Measurement Set v4 view over a CASA Measurement Set v2.
See the documentation_ for further information.

.. _documentation: https://xarray-ms.readthedocs.io
.. |CI Status| image:: https://github.com/ratt-ru/xarray-ms/actions/workflows/ci.yml/badge.svg
   :target: https://github.com/ratt-ru/xarray-ms/actions/workflows/ci.yml
   :alt: Continuous Integration Status
.. |Doc Status| image:: https://readthedocs.org/projects/xarray-ms/badge/?version=latest
   :target: https://xarray-ms.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status
.. |Version Status| image:: https://img.shields.io/pypi/v/xarray-ms.svg
   :target: https://pypi.python.org/pypi/xarray-ms
   :alt: Version Status
