.. xarray-ms documentation master file, created by
   sphinx-quickstart on Tue Sep 10 10:36:27 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

xarray-ms documentation
=======================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   install
   tutorial
   api
   changelog
