/* Alias shell for shellscript */
export { default } from './shellscript.mjs'
