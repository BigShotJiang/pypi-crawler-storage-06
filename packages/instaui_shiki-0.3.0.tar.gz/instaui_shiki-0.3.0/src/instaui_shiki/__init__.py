__all__ = ["shiki"]

from ._shiki_code import Code as shiki
