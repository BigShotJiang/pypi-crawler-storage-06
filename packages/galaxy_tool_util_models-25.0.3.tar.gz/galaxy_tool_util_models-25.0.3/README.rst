
.. image:: https://badge.fury.io/py/galaxy-tool-util-models.svg
   :target: https://pypi.org/project/galaxy-tool-util-models/


Overview
--------

Pydantic models to support Galaxy_ tool utilities.

* Code: https://github.com/galaxyproject/galaxy/tree/dev/packages/tool_util_models

.. _Galaxy: http://galaxyproject.org/
