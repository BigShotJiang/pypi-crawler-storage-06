History
-------

.. to_doc

-------------------
25.0.3 (2025-09-23)
-------------------


=========
Bug fixes
=========

* Fix collection element sorting in extended_metadata by `@mvdbeek <https://github.com/mvdbeek>`_ in `#20928 <https://github.com/galaxyproject/galaxy/pull/20928>`_

-------------------
25.0.2 (2025-08-13)
-------------------


=========
Bug fixes
=========

* Fix parameter models for optional color params. by `@jmchilton <https://github.com/jmchilton>`_ in `#20705 <https://github.com/galaxyproject/galaxy/pull/20705>`_

-------------------
25.0.1 (2025-06-20)
-------------------

No recorded changes since last release

-------------------
25.0.0 (2025-06-18)
-------------------

First release
