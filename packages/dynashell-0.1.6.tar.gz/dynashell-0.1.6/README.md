# dynashell
A flexible shell to run python snippets in a configurable context
## description
Dynashell is a small compact module that can be used to run python code in a configurable context.
It includes a simple command prompt that lets the user execute python scripts within a running python context.




