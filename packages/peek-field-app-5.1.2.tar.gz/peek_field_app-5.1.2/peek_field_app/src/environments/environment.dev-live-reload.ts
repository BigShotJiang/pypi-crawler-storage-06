export const environment = {
  production: false,
  serviceWorkerEnabled: false,
};
