from posteriors.vi import dense
from posteriors.vi import diag
