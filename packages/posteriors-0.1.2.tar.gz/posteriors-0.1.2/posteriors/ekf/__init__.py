from posteriors.ekf import diag_fisher
from posteriors.ekf import dense_fisher
