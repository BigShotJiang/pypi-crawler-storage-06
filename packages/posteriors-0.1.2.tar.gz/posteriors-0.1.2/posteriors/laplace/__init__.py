from posteriors.laplace import dense_fisher
from posteriors.laplace import diag_fisher
from posteriors.laplace import dense_ggn
from posteriors.laplace import diag_ggn
from posteriors.laplace import dense_hessian
