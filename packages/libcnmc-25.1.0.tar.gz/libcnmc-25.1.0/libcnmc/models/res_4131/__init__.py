from f1_4131 import F1Res4131
from f2_4131 import F2Res4131
from f3_4131 import F3Res4131
from f4_4131 import F4Res4131
from f5_4131 import F5Res4131
from f6_4131 import F6Res4131
from f7_4131 import F7Res4131
from f8_4131 import F8Res4131
