def main():
    print("Hello from materials-science!")


if __name__ == "__main__":
    main()
