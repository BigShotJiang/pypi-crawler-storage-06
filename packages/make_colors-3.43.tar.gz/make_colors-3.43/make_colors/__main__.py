from . test import run_all_tests

def main():
    run_all_tests()

if __name__ == "__main__":
    main()