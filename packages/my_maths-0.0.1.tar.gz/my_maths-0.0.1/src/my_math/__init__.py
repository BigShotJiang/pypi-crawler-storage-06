VERSION = "1.0.0"

def greet(name):
    return f"Hello, {name}! (version {VERSION})"