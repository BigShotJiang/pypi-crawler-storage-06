# Tools to build microservice

Backend of the Saad & Trad microservices architecture based on Graphql, Starlette and a custom SQL query builder