"""Utility functions for the Zarafe application."""
