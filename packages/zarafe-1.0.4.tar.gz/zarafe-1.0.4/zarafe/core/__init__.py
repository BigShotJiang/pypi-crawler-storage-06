"""Core business logic for the Zarafe application."""
