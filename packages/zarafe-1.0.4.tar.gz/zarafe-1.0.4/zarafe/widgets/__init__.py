"""UI widgets for the Zarafe application."""
