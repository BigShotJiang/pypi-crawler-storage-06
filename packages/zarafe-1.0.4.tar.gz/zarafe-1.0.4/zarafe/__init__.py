"""Zarafe - Video annotation tool for eye tracking studies."""
