# This file is needs to be multi-lingual in both Python and POSIX
# shell which "exec()" or "source" it respectively.

# This file should define a variable __version__ which we use as the
# debugger version number.

# fmt: off
__version__="1.5.0"  # noqa
