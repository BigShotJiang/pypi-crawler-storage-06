You can configure the rules to compute the cycle count, acting as follow:

#. Go to *Inventory > Configuration > Cycle Count Rules*.
#. Create as much cycle count rules as you want.
#. Assign the rules to the Warehouse or zones where you want to apply the rules
   in.
#. Go to *Inventory > Configuration > Warehouse Management > Warehouses* and
   set a *Cycle Count Planning Horizon* for each warehouse.
