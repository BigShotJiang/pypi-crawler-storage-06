"""
Version information for the HUD SDK.
"""

from __future__ import annotations

__version__ = "0.4.37"
