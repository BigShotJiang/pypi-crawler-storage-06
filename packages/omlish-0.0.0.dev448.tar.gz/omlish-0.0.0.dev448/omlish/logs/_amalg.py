# @omlish-lite
# @omlish-amalg ../../omdev/scripts/lib/logs.py
from .base import AnyLogger  # noqa
from .standard import configure_standard_logging  # noqa
from .std.loggers import StdLogger  # noqa


##
