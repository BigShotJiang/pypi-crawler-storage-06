To use this module, you need to:

1.  Go to Sales \> Orders \> Sales Orders Lines
2.  You can filter, group and switch view type
3.  Create new line related with existing order
4.  If order field is empty, a new order will be created
