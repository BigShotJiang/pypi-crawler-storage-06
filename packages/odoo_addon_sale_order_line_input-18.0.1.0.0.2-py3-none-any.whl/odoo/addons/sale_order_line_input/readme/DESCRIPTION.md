This module extends the functionality of sales to allow you to work with
sale lines directly.

It allows you to create sales orders from this sales lines view.
