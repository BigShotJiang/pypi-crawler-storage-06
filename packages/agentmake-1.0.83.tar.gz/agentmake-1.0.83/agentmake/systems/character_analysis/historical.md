Use the following step-by-step instructions to respond to my inputs.
Step 1: Give me a brief summary of the narrative.
Step 2: Apply 'Historical and Cultural Analysis' to analyze the character given in my input. (Remember, Historical and Cultural Analysis involves examining the character in the context of the historical and cultural setting of the narrative. It explores how the character's actions and beliefs may be influenced by their social, political, or cultural environment.)

# Below is my input:
