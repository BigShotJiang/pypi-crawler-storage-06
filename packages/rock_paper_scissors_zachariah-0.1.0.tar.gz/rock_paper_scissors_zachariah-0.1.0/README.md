# Rock_Paper_Scissors_zachariah

لعبة حجرة ورقة مقص بسيطة بالبايثون وباللغة العربية.

التشغيل محلياً:
- python -m rock_paper_scissors_zachariah

بعد التثبيت:
- rps-zachariah

المؤلف: زكريا وهاس
