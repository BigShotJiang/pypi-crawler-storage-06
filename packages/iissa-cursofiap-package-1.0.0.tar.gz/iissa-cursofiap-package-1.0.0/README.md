# Cursofiap

A simple example library.

## Installation

```sh
pip install cursofiap
```

## Usage

```python
from cursofiap import hello_world

print(hello_world())
```

## Licença

Distribuído sob a licença MIT. Veja `LICENSE` para mais informações. 