# This file is placed in the Public Domain.


import setuptools


if __name__ == "__main__":
    setuptools.setup(scripts=["bin/nixbot"])
