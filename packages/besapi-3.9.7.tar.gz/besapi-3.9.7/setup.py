#!/usr/bin/env python
"""File to configure python build and packaging for pip."""

from setuptools import setup

if __name__ == "__main__":
    setup()
