"""
Entry point for the pyscn command-line interface.
"""

from .main import main

if __name__ == "__main__":
    main()