"""File management for MCP artifact organization.

This module provides functionality to organize analysis artifacts within the
project's documentation folder structure as specified in Story 4.4.
"""