#!/usr/bin/env python3
"""Roundtable AI MCP Server - Main entry point for module execution."""

from .server import main

if __name__ == "__main__":
    main()