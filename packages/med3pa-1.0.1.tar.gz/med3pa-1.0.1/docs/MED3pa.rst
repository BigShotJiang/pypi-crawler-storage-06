
.. toctree::
   :maxdepth: 4
   
   MED3pa.datasets
   MED3pa.models
   MED3pa.med3pa

