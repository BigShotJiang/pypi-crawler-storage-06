.. toctree::
   :maxdepth: 4
   :caption: Tutorials

   datasets_tutorials
   models_tutorials
   med3pa_tutorials