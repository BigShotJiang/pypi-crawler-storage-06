# Busy

## Escape from overwhelm and stay focused all day

Documentation at https://busy.steamwiz.io
