# Pyarmor 8.4.7 (basic), 004363, 2025-09-18T16:25:15.166261
from .pyarmor_runtime import __pyarmor__
