# cryptocoreedu/modes/__init__.py
from .ECBMode import ECBMode

__all__ = ['ECBMode']