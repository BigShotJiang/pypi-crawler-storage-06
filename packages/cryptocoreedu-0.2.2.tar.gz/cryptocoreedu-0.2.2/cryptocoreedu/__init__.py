# cryptocoreedu/__init__.py
from .main import main
# from .file_io import read_file, write_file

__version__ = "0.2.2" # ОБНОВЛЕНИЕ ВЕРСИИ ПРИ КАЖДОМ ВЫПУСКЕ