"""
User convenience utilities
"""

