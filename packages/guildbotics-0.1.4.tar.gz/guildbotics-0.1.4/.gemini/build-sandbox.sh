#!/bin/bash

docker build -t guildbotics-test:latest -f sandbox.Dockerfile --no-cache .
