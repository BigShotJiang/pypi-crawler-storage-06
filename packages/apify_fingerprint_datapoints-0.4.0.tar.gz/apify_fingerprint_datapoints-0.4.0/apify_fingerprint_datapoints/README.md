Fingerprint datapoints files collected by Apify and originally stored at https://github.com/apify/fingerprint-suite.
This package contains datafiles and helper functions for getting the path to the datafiles.

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](https://github.com/apify/fingerprint-suite/blob/master/fingerprint_datapoints/LICENSE) file for details.
