# Changelog

All notable changes to this project will be documented in this file.

## 0.4.0 - (2025-09-25)

- Updated data. Same as npm package `fingerprint-generator` version `2.1.73`

## 0.3.0 - (2025-09-25)

- Updated data. Same as npm package `fingerprint-generator` version `2.1.72`

## 0.2.0 - (2025-09-25)

- Updated data. Same as npm package `fingerprint-generator` version `2.1.71`

## 0.1.0 - (2025-08-28)

- Updated data. Same as npm package `fingerprint-generator` version `2.1.70`

## 0.0.3 - (2025-06-27)

- Updated data. Same as npm package `fingerprint-generator` version `2.1.68`
- Added `py.typed`

## 0.0.2 - (2025-03-10)

- Update project metadata.
- Add Python 3.8 as supported.

## 0.0.1 - (2025-03-05)

- Initial version.
