:html_theme.sidebar_secondary.remove:

{{ objname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}
