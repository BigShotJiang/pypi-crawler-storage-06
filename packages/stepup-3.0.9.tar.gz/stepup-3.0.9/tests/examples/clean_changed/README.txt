The `cleanup` script will only remove outputs that have not changed since their last known state in the `graph.db` file.
