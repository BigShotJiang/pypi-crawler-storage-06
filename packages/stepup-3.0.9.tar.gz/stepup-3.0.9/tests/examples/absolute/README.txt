This is a simple example with an absolute path.
