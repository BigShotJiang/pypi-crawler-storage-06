#!/usr/bin/env python3
from stepup.core.call import driver


def run(size: int):
    return list(range(size))


if __name__ == "__main__":
    driver()
