#!/usr/bin/env python3
from stepup.core.call import driver


def run(order):
    return 2 * order


if __name__ == "__main__":
    driver()
