The call function allows one to manually set the input and output files.
