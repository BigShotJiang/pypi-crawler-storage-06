#!/usr/bin/env python3
from stepup.core.api import amend

amend(out=["nonexisting/foo.out"])
