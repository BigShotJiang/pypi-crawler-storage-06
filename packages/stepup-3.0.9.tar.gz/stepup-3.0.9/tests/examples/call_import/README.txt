This example shows that imported local modules are automatically when using `stepup.core.call.driver()`.
