def func():
    return "second helper"
