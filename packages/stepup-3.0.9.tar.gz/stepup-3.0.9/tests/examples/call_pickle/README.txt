This is an example of the call protocol, using pickle serialization to pass the arguments.
