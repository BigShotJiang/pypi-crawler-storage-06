One can manually specify the format (json or pickle) when calling the `call` function.
