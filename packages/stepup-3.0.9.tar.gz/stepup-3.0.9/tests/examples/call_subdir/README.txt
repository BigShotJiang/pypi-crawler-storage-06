This example runs a script through the call protocol from a different directory,
which can be useful when reusing a script in several places.
