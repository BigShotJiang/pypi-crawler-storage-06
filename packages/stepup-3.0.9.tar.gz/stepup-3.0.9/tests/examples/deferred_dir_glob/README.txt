This example tests and demonstrates recursive globbing to get a list of files
with a specific extension in a directory tree.
