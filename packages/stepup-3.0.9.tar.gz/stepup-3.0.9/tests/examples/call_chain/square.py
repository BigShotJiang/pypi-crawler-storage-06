#!/usr/bin/env python3
from stepup.core.call import driver


def run(x):
    return x**2


if __name__ == "__main__":
    driver()
