This example shows that `plan.py` can declare a file as static and then use it as input,
without creating a cyclic dependency.
