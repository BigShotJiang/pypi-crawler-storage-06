This example tests that one can define a step whose workdir and parent directories of inputs and outputs become static due to a deferred glob.
