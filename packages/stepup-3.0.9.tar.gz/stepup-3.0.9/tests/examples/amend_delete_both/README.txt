This example defines a step with a normal and an amended input and tests what happens
when both are deleted.
