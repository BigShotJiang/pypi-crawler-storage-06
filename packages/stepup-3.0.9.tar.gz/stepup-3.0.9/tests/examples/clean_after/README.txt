This example shows a few things:
- run `cleanup` after `stepup` has stopped
- run `cleanup` from another directory
- failure to remove a directory because it contains unknown files
