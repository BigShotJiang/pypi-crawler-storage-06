The `cleanup` script will not remove files that have status AWAITED.
If they exist, these must have another origin than the StepUp build.
