This example tests that one can amend a step where parent directories of inputs and outputs become static due to a deferred glob.
