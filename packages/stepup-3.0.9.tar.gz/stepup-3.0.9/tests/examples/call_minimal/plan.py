#!/usr/bin/env python3
from stepup.core.api import call, static

static("example.py")
call("example.py")
