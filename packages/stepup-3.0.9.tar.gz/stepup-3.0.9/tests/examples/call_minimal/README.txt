A simple example of StepUp's call protocol.
