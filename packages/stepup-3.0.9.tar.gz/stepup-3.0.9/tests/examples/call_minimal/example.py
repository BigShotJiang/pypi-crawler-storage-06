#!/usr/bin/env python3
from stepup.core.call import driver


def run():
    return 42


if __name__ == "__main__":
    driver()
