When the JSON format is requested in the `call` function,
while the inputs cannot be serialized with JSON,
an error is raised.
