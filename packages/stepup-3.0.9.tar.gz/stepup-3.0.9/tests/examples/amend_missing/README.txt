When an amended input should exist according to StepUp (e.g. because it is declared static),
but it is missing, the amend function will raise an exception.
