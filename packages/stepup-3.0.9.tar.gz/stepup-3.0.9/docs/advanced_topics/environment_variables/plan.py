#!/usr/bin/env python3
from stepup.core.api import runsh

runsh("echo ${MYVAR}", env="MYVAR")
