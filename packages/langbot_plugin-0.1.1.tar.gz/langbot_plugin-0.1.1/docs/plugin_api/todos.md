# Plugin API TODOs

- 获取 Bot 详细信息
    - 包括 Bot Account ID
- 添加命令返回值的图片、语音、文件支持