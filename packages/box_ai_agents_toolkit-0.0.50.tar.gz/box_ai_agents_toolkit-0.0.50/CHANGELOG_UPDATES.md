## 0.0.50 - 2025-09-18

* Merge pull request #4 from box-community/rb/groups (d6ee5da)
* ruff (4474ad7)
* ruff (5b59488)
* implementing the group tools (abdf89e)
* Update version to 0.0.49 and changelog (8e6d4de)