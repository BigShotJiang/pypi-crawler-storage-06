# flake8: noqa

# import apis into api package
from linebot.v3.liff.api.liff import Liff


# Async version
from linebot.v3.liff.api.async_liff import AsyncLiff

