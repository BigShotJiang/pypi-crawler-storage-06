from .lib import autoinstall


autoinstall()

__all__ = []
