keeps all the prompts


-> at this moment we need 3 high level prompts
-> feature orchestator
-> feature decomposer
-> singel cte executor
