this folder keeps all the llms, connections, and other important llm specific tools to be used for the scope of this project



- > starting with chatgpt integrations
-> creating a custom wrapper for barebone tool calling
-> integrate other llms opensource or closed
-> need to integrate semantic search model with this as well
