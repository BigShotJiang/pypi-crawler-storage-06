def test_import():
    import tabsearch  # noqa: F401
