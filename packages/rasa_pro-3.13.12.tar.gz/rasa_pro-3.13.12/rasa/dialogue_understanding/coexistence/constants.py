CALM_ENTRY = "calm_entry"
NLU_ENTRY = "nlu_entry"
STICKY = "sticky"
NON_STICKY = "non_sticky"
