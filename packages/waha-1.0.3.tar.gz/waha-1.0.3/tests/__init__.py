"""
Tests for WAHA

This package contains unit and integration tests for WAHA.
"""
