# -*- coding: utf-8 -*-
"""
Created on 2025/02/03 18:36:49
@author: Whenxuan Wang
@email: wwhenxuan@gmail.com
"""
from .emd2d import EMD2D
