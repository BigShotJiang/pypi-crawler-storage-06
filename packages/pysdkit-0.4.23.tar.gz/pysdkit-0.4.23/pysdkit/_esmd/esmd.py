# -*- coding: utf-8 -*-
"""
Created on 2025/02/05 21:04:29
@author: Whenxuan Wang
@email: wwhenxuan@gmail.com
"""
import numpy as np


class ESMD(object):
    def __init__(self):
        pass
