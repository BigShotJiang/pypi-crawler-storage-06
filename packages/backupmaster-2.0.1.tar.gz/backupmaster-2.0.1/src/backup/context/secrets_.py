from dataclasses import dataclass


@dataclass
class Secrets:
    rclone: str
