class BaseScript(object):
    def run(self):
        raise NotImplementedError
