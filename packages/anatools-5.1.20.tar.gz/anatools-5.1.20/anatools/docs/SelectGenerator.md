Selects a random generator from a group of generators based on weight
* "Generators" - one or more generators to choose from