Change the weight of a generator
* "Generator" - The generator to set the weight for
* "Weight" - The weight to give the generator