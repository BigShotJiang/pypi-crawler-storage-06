Set the number of times this generator will be instanced
* "Generator" - The generator to set the instance count for
* "Count" - The number of times to instance this generator