from b24api.async_api import AsyncBitrix24
from b24api.sync_api import SyncBitrix24

__all__ = ["AsyncBitrix24", "SyncBitrix24"]
