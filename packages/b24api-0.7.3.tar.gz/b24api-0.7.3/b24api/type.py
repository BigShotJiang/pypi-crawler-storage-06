from datetime import datetime

# Types allowed in response and request
type ApiTypes = bool | str | int | float | dict | list | datetime | None
