# Copyright (c) 2024, NVIDIA CORPORATION. All rights reserved.

from .fully_sharded_data_parallel import FullyShardedDataParallel
