# Copyright (c) 2024, NVIDIA CORPORATION. All rights reserved.
from .gpt_model import GPTModel
