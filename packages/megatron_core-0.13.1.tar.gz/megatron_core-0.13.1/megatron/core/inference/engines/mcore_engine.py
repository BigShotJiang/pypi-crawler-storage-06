# Copyright (c) 2025, NVIDIA CORPORATION. All rights reserved.

from .static_engine import (  # noqa: F401 # pylint: disable=unused-import
    StaticInferenceEngine as MCoreEngine,
)
