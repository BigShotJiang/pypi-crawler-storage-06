<div align="Center">

###  luminare

[![Test Status](https://github.com/andycasey/luminare/actions/workflows/ci.yml/badge.svg)](https://github.com/andycasey/luminare/actions/workflows/ci.yml)
[![Coverage Status](https://coveralls.io/repos/github/andycasey/luminare/badge.svg?branch=main&service=github)](https://coveralls.io/github/andycasey/luminare?branch=main)

</div>

```
uv add luminare
```


