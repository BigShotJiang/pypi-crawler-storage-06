import os

tmp_node_cache = os.path.abspath(os.path.join(__file__, '../tmp_node_cache'))
