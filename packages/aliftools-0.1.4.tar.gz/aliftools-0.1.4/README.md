[![Python package](https://github.com/aliftype/tools/actions/workflows/python-package.yml/badge.svg)](https://github.com/aliftype/tools/actions/workflows/python-package.yml)
[![PyPI](https://img.shields.io/pypi/v/alifTools.svg)](https://pypi.org/project/alifTools)

Alif Tools
==========

Helper tools for building Alif Type Foundry fonts.
