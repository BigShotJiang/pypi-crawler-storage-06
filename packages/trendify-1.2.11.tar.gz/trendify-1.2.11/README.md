

[![PyPI version](https://img.shields.io/pypi/v/trendify.svg)](https://pypi.org/project/trendify/)
[![Python versions](https://img.shields.io/pypi/pyversions/trendify.svg)](https://pypi.org/project/trendify/)
[![License](https://img.shields.io/github/license/TalbotKnighton/trendify.svg)](https://github.com/TalbotKnighton/trendify/blob/main/LICENSE)
[![Documentation](https://img.shields.io/badge/docs-latest-blue.svg)](https://talbotknighton.github.io/trendify/)
[![GitHub](https://img.shields.io/github/stars/TalbotKnighton/trendify?style=social)](https://github.com/TalbotKnighton/trendify)
