"""
The api collection for plugins

In plugin environment, import components inside these modules only:

1. ``mcdreforged.api.xxx``
2. ``mcdreforged`` (alias of ``mcdreforged.api.all``)
"""
