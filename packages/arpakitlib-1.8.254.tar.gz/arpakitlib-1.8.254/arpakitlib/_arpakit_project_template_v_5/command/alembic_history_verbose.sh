cd ..
alembic history --verbose
