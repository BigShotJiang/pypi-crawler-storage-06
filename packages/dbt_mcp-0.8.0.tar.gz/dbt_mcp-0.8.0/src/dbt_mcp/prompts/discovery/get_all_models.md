Get the name and description of all dbt models in the environment.
