from mohe_mcp_server import main

main()