"""Shared test fixtures for mcp-fastmcp package."""
