"""
Widgets from Development workflow category

"""
# ID = "orangecontrib.AAIT"

NAME = "Image Analysis Intelligent Tools"

# Category icon show in the menu
ICON = "icons/img4it.svg"

BACKGROUND = "light-yellow"

DESCRIPTION = ("Exploit computer vision technology with Orange Data Mining !")



# PRIORITY = 6