class photonic_problem:
    def __init__(self):
        self.n = None

    def setup_structure(self):
        pass

    def __call__(self):
        pass
