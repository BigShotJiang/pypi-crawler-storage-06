LLaMEA API
======

.. toctree::
   :titlesonly:
   :caption: LLaMEA Modules

   llamea
   solution
   llm
   loggers
   utils

