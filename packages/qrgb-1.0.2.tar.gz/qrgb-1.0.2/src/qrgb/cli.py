"""CLI interface for QRGB."""

# Move your main CLI code here, importing from core.py
from .qrgb import app

if __name__ == "__main__":
    app()
