PREFIX = "[DH-TEST]"


def log(*args, **kwargs):
    print(PREFIX, *args, **kwargs)
