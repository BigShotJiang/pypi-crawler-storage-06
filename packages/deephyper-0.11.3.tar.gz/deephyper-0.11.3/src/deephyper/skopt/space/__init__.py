"""Utilities to define a search space.
"""

from .space import Dimension, Space, Integer, Real, Categorical, check_dimension
