.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   deephyper.analysis 
   deephyper.cli
   deephyper.ensemble
   deephyper.evaluator
   deephyper.hpo
   deephyper.predictor
   deephyper.skopt
   deephyper.stopper
