from django.apps import AppConfig


class MetenoxConfig(AppConfig):
    name = "metenox"
    label = "metenox"
    verbose_name = "metenox"
