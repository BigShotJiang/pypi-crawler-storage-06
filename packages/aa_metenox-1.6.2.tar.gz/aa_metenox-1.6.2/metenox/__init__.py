"""Metenox app config"""

# pylint: disable = invalid-name
default_app_config = "metenox.apps.MetenoxConfig"

repo_url = "https://gitlab.com/r0kym/aa-metenox/"

__version__ = "1.6.2"
