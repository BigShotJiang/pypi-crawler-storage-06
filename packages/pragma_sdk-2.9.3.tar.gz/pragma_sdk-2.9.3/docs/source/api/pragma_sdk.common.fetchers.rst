fetchers
==============================

FetcherClient
---------------------------------------------

.. automodule:: pragma_sdk.common.fetchers.fetcher_client
   :members:
   :undoc-members:
   :show-inheritance:

HopHandler
------------------------------------------

.. automodule:: pragma_sdk.common.fetchers.handlers.hop_handler
   :members:
   :undoc-members:
   :show-inheritance:

IndexAggregation
------------------------------------------

.. automodule:: pragma_sdk.common.fetchers.handlers.index_aggregator_handler
   :members:
   :undoc-members:
   :show-inheritance:

FetcherInterfaceT
---------------------------------------

.. automodule:: pragma_sdk.common.fetchers.interface
   :members:
   :undoc-members:
   :show-inheritance:
