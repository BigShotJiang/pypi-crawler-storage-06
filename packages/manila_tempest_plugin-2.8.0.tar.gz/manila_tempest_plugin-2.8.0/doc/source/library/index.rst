========
Usage
========

To use openstack in a project::

    import manila-tempest-plugin
