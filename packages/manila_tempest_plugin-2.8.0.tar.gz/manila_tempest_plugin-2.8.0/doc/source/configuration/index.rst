=============
Configuration
=============

Configuration of openstack.
