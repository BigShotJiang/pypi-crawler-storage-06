from django.apps import AppConfig


class TmplsConfig(AppConfig):
    name = "tests.tmpls"
    label = name.replace(".", "_")


7
