# flake8: noqa
from enum import Enum


class Color(Enum):

    RED   = 'R'
    GREEN = 'G'
    BLUE  = 'B'
