from enum import IntFlag


class IntFlagEnum(IntFlag):
    VAL1 = 2**12
    VAL2 = 2**13
    VAL3 = 2**14
