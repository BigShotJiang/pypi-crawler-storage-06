.. include:: ../refs.rst

.. _urls:

====
URLS
====

.. automodule:: django_enum.urls
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
