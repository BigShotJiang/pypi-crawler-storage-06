.. include:: ../refs.rst

.. _drf_ref:

===
DRF
===

.. automodule:: django_enum.drf
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
