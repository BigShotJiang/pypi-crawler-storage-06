.. include:: ../refs.rst

.. _forms_ref:

===========
Form Fields
===========

.. autoclass:: django_enum.forms.ChoiceFieldMixin
   :members:
   :show-inheritance:

.. autoclass:: django_enum.forms.EnumChoiceField
   :members:
   :show-inheritance:

.. autoclass:: django_enum.forms.EnumFlagField
   :members:
   :show-inheritance:

.. autoclass:: django_enum.forms.EnumMultipleChoiceField
   :members:
   :show-inheritance:
