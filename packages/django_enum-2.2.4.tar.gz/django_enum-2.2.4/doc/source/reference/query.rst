.. include:: ../refs.rst

.. _query:

=====
Query
=====

.. automodule:: django_enum.query
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
