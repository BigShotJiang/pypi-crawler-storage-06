.. include:: ../refs.rst

.. _choices_ref:

=======
Choices
=======

.. automodule:: django_enum.choices
   :members:
   :show-inheritance:
