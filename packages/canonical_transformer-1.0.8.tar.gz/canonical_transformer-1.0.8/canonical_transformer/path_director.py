import os
DIR_DATA = 'data'
FILE_FOLDER = {
    'morphism': os.path.join(DIR_DATA, 'data-morphism'),
}