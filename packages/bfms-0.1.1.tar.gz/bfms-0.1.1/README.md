# `bfms`

This library provides core model architectures for brain
foundation models (i.e. FMs for psychophysiological data).
Inspired by the [`torch_brain`](https://github.com/neuro-galaxy/torch_brain)
library.