from marker.schema.blocks.base import Block
from marker.schema.groups.figure import FigureGroup
from marker.schema.groups.table import TableGroup
from marker.schema.groups.list import ListGroup
from marker.schema.groups.picture import PictureGroup
from marker.schema.groups.page import PageGroup
