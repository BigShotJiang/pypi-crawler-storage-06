from marker.schema.blocks import Block


class Group(Block):
    pass