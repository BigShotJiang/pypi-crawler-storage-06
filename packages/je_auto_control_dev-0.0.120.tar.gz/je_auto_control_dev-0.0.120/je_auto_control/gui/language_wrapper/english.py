english_word_dict = {
    # Main
    "application_name": "AutoControlGUI",
    # Widget
    "interval_time": "Interval Time (s):",
    "cursor_x": "Cursor X Position:",
    "cursor_y": "Cursor Y Position:",
    "mouse_button": "Mouse Button:",
    "keyboard_button": "Keyboard Button:",
    "click_type": "Click Type:",
    "input_method": "Input Method:",
    "mouse_radio": "Mouse",
    "keyboard_radio": "Keyboard",
    "repeat_until_stopped_radio": "Repeat until stopped",
    "repeat_radio": "Repeat",
    "times": "Times",
    "start": "Start",
    "stop": "Stop",
}
