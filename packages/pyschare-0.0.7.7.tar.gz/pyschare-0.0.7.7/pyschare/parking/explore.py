from pyschare.explore import _Explore

def explore():
    new_instance_explore = _Explore()
    return new_instance_explore

explore()