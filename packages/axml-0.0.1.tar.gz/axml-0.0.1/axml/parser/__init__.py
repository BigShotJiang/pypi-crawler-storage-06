from axml.parser.stringblock import StringBlock
