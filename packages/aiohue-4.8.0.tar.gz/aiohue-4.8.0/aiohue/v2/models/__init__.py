"""Schemas for Hue objects."""
