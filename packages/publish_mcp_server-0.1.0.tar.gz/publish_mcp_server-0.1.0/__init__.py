"""Publish MCP Server - A tool to help publish MCP servers to the registry."""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .publish_mcp_server import mcp, main

__all__ = ["mcp", "main"]