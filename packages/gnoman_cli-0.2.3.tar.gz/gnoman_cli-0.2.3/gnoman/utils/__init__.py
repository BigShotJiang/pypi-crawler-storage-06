"""Utility helpers for GNOMAN."""
