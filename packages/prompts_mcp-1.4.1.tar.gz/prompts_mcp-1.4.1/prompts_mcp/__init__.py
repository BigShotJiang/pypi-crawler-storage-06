"""
MCP Server for serving prompts from a local directory.
"""

__version__ = "1.4.1"
