"""Core"""

from xodex.core.localization import Localization, localize

__all__ = ("Localization", "localize")
