from supervisor_pydantic import __version__


def test_all():
    assert __version__
    assert True
