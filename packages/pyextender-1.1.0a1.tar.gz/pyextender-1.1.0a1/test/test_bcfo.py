from PyExtender.bcfo import *
create("test/test_PErandom.py")
output("from PyExtender.PErandom import *","test/test_PErandom.py")