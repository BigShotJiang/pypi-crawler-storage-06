from PyExtender.pyassist import scaffolder
from PyExtender.PErandom import randchar
scaffolder.list(["list1", "list2", "list3"],["1", "2", "3"],file="test/test_pyassist.py")


var1="n"
var2="K"
var3="H"