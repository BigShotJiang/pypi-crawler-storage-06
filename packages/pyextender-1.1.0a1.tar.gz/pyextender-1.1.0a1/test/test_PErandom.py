from PyExtender.PErandom import *
print(randstr())