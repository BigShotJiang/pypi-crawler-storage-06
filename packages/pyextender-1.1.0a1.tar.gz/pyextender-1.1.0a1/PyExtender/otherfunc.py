def welcome(text:str = "Hello!"):
    print(text)
def version():
    print('0.1.0-alpha')

def all_functions():
    print('otherfunc=[welcome, version,all_functions]\n')
    print('bcfo=[output, create]\n')
    print('PErandom=[get_seed, xorshift, randint, randdev, randchar, randstr, random]\n')
    print('pyassist=[create_list(it is a class;functions,list,varible,classes,set)]\n')

