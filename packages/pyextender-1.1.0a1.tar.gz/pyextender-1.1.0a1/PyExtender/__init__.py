from .bcfo import output, create
from .otherfunc import welcome, version, all_functions
from .pyassist import scaffolder
from .PErandom import get_seed, xorshift, randdev, randint