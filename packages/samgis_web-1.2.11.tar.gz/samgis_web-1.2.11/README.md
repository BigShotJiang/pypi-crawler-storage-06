# Samgis Web

Web modules for [SamGIS](https://trinca.tornidor.com/projects/samgis-segment-anything-applied-to-GIS) project.

See also [samgis-core](https://pypi.org/project/samgis_core/).
