"""various helpers functions"""
import samgis_core.utilities.frontend_builder as frontend_builder
