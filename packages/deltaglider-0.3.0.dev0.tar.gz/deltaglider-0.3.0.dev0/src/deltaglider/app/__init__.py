"""Application layer for DeltaGlider."""
