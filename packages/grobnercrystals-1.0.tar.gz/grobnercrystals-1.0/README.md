# Summary

This repository contains SageMath code for working with *Gröbner crystal structures*, introduced in (insert paper link here).

## Dependencies

- SageMath ([documentation here](https://doc.sagemath.org/html/en/index.html))
- Macaulay2 ([documentation here](https://www.macaulay2.com))
  - the "gfanInterface" package ([documentation here](https://macaulay2.com/doc/Macaulay2/share/doc/Macaulay2/gfanInterface/html/index.html))
- numpy

## Installation

## Documentation
