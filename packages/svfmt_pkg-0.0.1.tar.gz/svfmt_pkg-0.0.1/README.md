[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"

[project]
name = "svfmt_pkg"       # Unique name on PyPI
version = "0.1.0"
description = "A cool Python function"
authors = [
  { name="Valerio Venceslai", email="valerio.venceslai@synthara.ai" }
]
readme = "README.md"
requires-python = ">=3.8"
license = {text = "MIT"}
dependencies = []
