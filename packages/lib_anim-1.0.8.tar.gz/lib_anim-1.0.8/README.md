# lib-anim

A python toolbox for creating animations.

## Installation

```
pip install --upgrade pip
pip install lib-anim
```

## Dependencies

Depends on `numpy`, `matplotlib`, `pyqt6`, `pyqt6-3d` and `imageio[ffmpeg]`
