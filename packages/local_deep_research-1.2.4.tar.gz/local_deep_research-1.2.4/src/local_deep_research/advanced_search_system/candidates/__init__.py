# Candidates System Package

from .base_candidate import Candidate

__all__ = ["Candidate"]
