ROCS_DEFAULT_STORAGE_ENDPOINT = "https://storage.svc.uvt-01.eocube.ro"
