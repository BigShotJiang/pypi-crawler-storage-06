ROCS_DISCOVERY_URL = (
    "https://aai.eocube.ro/realms/rocs/.well-known/openid-configuration"
)
