# SearchBinaryIds

Optionally perform the search on matching functions from binaries in this list

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from revengai.models.search_binary_ids import SearchBinaryIds

# TODO update the JSON string below
json = "{}"
# create an instance of SearchBinaryIds from a JSON string
search_binary_ids_instance = SearchBinaryIds.from_json(json)
# print the JSON string representation of the object
print(SearchBinaryIds.to_json())

# convert the object into a dict
search_binary_ids_dict = search_binary_ids_instance.to_dict()
# create an instance of SearchBinaryIds from a dict
search_binary_ids_from_dict = SearchBinaryIds.from_dict(search_binary_ids_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


