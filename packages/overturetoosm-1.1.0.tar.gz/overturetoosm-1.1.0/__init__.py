"""Convert Overture's `places`, `buildings`, and `addresses` features to OSM tags."""
