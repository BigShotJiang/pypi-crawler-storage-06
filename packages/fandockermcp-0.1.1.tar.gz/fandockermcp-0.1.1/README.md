# FastMCP Docker工具

这是一个使用FastMCP框架构建的Docker镜像管理工具，可以方便地拉取和管理Docker镜像。

## 功能特性

- 拉取Docker镜像（支持指定标签，默认latest）
- 列出本地所有Docker镜像
- 基于FastMCP的异步命令行接口
- 友好的错误处理和提示信息
- 返回结构化的结果数据