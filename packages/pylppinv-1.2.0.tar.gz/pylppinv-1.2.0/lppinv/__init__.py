__version__ = "1.2.0"

from .lppinv import lppinv

__all__ = [
    "lppinv",
    "__version__"
]
