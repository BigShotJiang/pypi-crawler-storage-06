# Importación corta, limpia y profesional
from .model import StackingClassifier