rm -f output/*.jsonl && meltano run tap-spreadsheets target-jsonl $@
