"""spreadsheets entry point."""

from __future__ import annotations

from tap_spreadsheets.tap import TapSpreadsheets

TapSpreadsheets.cli()
