export { PeekCanvasBounds } from "@peek/peek_plugin_diagram/_private/PeekCanvasBounds";
