# Synthetrick Change Log

## Version 0.1.0

- Implemented featire to remove weekends
- CLEAN Code refactors
