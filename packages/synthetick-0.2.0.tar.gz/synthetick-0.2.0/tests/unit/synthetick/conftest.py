# import asyncio
# import pytest
# from tests.test_utils import socket_server
# from multiprocessing import Process
#
#
# @pytest.fixture(scope="session")
# def start_socket_server():
#     asyncio.run(socket_server.main())
