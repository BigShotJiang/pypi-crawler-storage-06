import pygamejr

bee = pygamejr.ImageSprite(pygamejr.resources.image.bee)

pygamejr.wait_quit()