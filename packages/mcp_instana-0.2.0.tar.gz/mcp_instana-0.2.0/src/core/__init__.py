# Core module for MCP Instana
