# Settings Module for Instana MCP
