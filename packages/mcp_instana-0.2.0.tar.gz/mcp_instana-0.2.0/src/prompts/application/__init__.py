"""Application-specific prompts package."""
