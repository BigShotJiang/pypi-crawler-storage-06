# bot extend default openai executor and extend it with additional functionality
from .ai_settings import AiSettings
