"""
Utilities for Fukui_Net model training and data preparation.
"""

