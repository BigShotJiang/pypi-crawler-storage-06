__all__ = [
    "VERSION_INFO",
    "__version__",
]

from holypack.__version__ import (
    VERSION_INFO,
    __version__,
)
