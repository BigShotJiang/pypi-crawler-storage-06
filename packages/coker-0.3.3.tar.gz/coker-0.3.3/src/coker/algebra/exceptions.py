class InvalidArgument(Exception):
    pass


class InvalidShape(InvalidArgument):
    pass
