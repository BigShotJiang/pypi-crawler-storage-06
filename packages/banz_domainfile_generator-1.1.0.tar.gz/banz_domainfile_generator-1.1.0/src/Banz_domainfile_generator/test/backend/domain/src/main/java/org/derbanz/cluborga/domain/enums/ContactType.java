// generated
package org.derbanz.cluborga.domain.enums;

public enum ContactType {
  ADDRESS,
  PHONE,
  EMAIL,
}