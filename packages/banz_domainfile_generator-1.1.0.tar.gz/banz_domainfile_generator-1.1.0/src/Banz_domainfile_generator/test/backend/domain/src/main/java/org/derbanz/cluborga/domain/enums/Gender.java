// generated
package org.derbanz.cluborga.domain.enums;

public enum Gender {
  MALE,
  FEMALE,
  DIVERSE,
}