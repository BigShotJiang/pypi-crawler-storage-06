// generated
package org.derbanz.cluborga.domain.enums;

public enum Status {
  APPLICATION,
  ACCEPTED,
  DECLINED,
}