// generated
package org.derbanz.cluborga.domain.enums;

public enum MembershipStatus {
  APPLICATION,
  ACTIVE_MEMBER,
  INACTIVE_MEMBER,
  FORMER_MEMBER,
  DECLINED,
}