package org.derbanz.cluborga.domain.model.organization.validation;

public interface PaymentMethodValidatorRule {
}