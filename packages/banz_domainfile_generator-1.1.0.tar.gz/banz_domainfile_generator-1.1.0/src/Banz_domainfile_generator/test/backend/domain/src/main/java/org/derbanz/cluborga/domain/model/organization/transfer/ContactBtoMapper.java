package org.derbanz.cluborga.domain.model.organization.transfer;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ContactBtoMapper extends ContactCoreBtoMapper {

}