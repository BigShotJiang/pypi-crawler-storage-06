package org.derbanz.cluborga.logic.organization.impl;

import jakarta.enterprise.context.ApplicationScoped;
import org.derbanz.cluborga.domain.model.organization.validation.PersonValidatorRule;

@ApplicationScoped
public class PersonValidatorRuleImpl implements PersonValidatorRule {
}