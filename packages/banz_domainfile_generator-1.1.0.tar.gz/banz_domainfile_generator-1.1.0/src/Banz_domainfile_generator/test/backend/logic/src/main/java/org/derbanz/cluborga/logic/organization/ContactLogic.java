package org.derbanz.cluborga.logic.organization;

public interface ContactLogic extends BaseContactLogic {
}