package org.derbanz.cluborga.logic.organization;

public interface PersonLogic extends BasePersonLogic {
}