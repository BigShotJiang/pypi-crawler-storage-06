package org.derbanz.cluborga.logic.organization.impl;

import jakarta.enterprise.context.ApplicationScoped;
import org.derbanz.cluborga.domain.model.organization.validation.ContactValidatorRule;

@ApplicationScoped
public class ContactValidatorRuleImpl implements ContactValidatorRule {
}