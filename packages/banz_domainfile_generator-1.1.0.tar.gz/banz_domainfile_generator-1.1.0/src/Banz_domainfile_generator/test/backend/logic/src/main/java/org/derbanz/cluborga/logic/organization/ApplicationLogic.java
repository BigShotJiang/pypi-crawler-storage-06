package org.derbanz.cluborga.logic.organization;

public interface ApplicationLogic extends BaseApplicationLogic {
}