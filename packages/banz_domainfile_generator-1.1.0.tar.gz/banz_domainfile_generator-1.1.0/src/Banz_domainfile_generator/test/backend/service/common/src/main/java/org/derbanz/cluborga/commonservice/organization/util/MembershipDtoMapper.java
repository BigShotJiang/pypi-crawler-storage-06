package org.derbanz.cluborga.commonservice.organization.util;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MembershipDtoMapper extends MembershipCoreDtoMapper {

}