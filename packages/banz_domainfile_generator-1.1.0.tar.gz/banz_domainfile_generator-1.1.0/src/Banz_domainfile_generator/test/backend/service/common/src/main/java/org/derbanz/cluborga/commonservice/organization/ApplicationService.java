package org.derbanz.cluborga.commonservice.organization;

public interface ApplicationService extends BaseApplicationService {
}