package org.derbanz.cluborga.commonservice.organization;

public interface PaymentMethodService extends BasePaymentMethodService {
}