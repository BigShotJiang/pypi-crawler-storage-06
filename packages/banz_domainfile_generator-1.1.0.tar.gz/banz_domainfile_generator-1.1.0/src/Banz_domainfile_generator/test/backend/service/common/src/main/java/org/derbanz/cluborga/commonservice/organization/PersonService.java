package org.derbanz.cluborga.commonservice.organization;

public interface PersonService extends BasePersonService {
}