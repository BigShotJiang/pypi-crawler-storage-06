package org.derbanz.cluborga.commonservice.organization;

public interface MembershipService extends BaseMembershipService {
}