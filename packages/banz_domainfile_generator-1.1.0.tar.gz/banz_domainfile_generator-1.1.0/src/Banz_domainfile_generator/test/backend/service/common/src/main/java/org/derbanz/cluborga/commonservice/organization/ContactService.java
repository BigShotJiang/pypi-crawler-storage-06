package org.derbanz.cluborga.commonservice.organization;

public interface ContactService extends BaseContactService {
}