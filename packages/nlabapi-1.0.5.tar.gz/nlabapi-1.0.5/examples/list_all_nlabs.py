from nlabapi import LabBench

print("List of all detected nScopes:")
LabBench.list_all_nlabs()
