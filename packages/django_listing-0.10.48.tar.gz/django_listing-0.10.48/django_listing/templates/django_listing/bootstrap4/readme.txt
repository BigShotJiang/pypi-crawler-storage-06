default theme is already a bootstrap4 theme :
goto to templates/django_listing/default directory to see them
This comes from that in theme_config.py, theme_fallback_name = 'default'