# agent-framework-lab-tau2

Evaluating customer service agents on Tau2 bench
