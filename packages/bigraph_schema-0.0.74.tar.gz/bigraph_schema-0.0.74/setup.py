from setuptools import setup, find_packages


# VERSION = '0.0.71'


with open("README.md", "r") as readme:
    description = readme.read()


setup(
    name="bigraph-schema",
    # version=VERSION,
    author="Eran Agmon, Ryan Spangler",
)
