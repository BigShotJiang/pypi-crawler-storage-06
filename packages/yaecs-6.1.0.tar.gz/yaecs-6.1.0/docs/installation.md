# Installation

The package can be installed from pipy: `pip install yaecs`.

It supports Python 3.6+ and all operating systems (Linux, Mac, Windows).

Requirements (**will not** be installed automatically by pip to keep this
lightweight):

- `python>=3.7`
- `pygraphviz==1.7`
- `scipy`
- `numpy`
- `sudo apt install graphviz`
