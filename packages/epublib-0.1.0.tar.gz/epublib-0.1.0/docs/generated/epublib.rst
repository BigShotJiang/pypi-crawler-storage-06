﻿epublib
=======

.. automodule:: epublib

   
   .. rubric:: Classes

   .. autosummary::
   
      EPUB
   