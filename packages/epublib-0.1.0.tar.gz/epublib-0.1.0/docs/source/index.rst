.. include:: ../../README.md
   :parser: myst_parser.sphinx_

----

Contents
------------------------------

.. toctree::
   :maxdepth: 1

   self
   epublib
