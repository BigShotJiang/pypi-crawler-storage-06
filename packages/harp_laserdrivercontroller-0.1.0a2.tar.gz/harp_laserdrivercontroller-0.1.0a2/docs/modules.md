::: harp.devices.laserdrivercontroller
