The source repository for this project can be found at:
  
   https://opendev.org/openstack/freezer-tempest-plugin

Pull requests submitted through GitHub are not monitored.

To start contributing to OpenStack, follow the steps in the contribution guide
to set up and use Gerrit:

   https://docs.openstack.org/contributors/code-and-documentation/quick-start.html

Bugs should be filed on Storyboard:

   https://storyboard.openstack.org/#!/project/openstack/freezer-tempest-plugin

For more specific information about contributing to this repository, see the
freezer-tempest-plugin contributor guide:

   https://opendev.org/openstack/freezer-tempest-plugin/src/branch/master/doc/source/contributor/contributing.rst
