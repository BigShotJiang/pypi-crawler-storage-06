======================
freezer-tempest-plugin
======================

Tempest plugin for the freezer project.

Tempest plugin for functional testing of freezer backup and restore features.
More information can be found in the freezer developer documentation.

* Documentation: https://docs.openstack.org/tempest/latest/plugin-registry.html
* Source: https://opendev.org/openstack/freezer-tempest-plugin
* Issue tracking: https://launchpad.net/freezer
