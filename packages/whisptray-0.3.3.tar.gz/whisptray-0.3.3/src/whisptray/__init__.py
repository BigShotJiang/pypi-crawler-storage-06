"""whisptray package"""

from .__main__ import main  # noqa: F401
