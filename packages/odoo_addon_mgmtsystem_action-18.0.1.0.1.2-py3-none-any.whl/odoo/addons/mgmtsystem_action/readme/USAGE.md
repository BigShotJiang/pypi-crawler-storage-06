Go to "Management System -\> Management System -\> Actions" and create
your actions.
