#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# vim: set tabstop=2 shiftwidth=2 textwidth=80 expandtab :
#
#
"""
仅用于收集无明确归属但确实可复用的工具函数
建议优先拆分至更专业 utils 模块

@author: cyhfvg
@date: 2025/04/20
"""
