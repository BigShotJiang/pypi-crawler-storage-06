"""
Tests for FCM Receiver library
"""
