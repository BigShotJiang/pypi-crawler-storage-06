from ._reference_model import RegressionModel

__all__ = [
    "RegressionModel",
]
