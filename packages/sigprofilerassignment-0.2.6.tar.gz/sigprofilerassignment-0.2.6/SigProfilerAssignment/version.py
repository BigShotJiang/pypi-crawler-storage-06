
# THIS FILE IS GENERATED FROM SigProfilerAssignment SETUP.PY
short_version = '0.2.6'
version = '0.2.6'
Update = 'v0.2.6:  Support for assigning signatures for rn7 and mm39 genomes.'

    