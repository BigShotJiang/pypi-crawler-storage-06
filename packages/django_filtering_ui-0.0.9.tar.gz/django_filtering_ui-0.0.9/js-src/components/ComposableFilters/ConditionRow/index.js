import ConditionRow from "./ConditionRow.vue";

export default ConditionRow;
