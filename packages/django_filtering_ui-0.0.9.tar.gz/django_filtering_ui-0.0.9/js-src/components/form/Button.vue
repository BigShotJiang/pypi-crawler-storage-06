<template>
  <button type="button" class="btn">
    <slot>button</slot>
  </button>
</template>

<style></style>
