<script setup>
import "@/app.css";
import ComposableFilters from "@/components/ComposableFilters";
</script>

<template>
  <ComposableFilters />
</template>
