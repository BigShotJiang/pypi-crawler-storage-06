from setuptools import setup, find_packages

setup(
    name="Dungeo_ai",             # must be unique on PyPI
    version="0.1.0",
    description="this is a dungeon ai run locally that use your llm",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Laszlobeer",
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "requests",
        "sounddevice",
        "numpy",
        "soundfile"
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "adventure-game=my_adventure_game.main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
