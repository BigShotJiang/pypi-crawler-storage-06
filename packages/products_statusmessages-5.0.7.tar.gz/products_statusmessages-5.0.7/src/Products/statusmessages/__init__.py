STATUSMESSAGEKEY = "statusmessages"
