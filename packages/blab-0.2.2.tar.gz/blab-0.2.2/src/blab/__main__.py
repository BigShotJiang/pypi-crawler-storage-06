# __main__.py

import blab
from importlib.metadata import version

def main():
    print('Hello blab', version('blab') )

    
    
if __name__ == "__main__":
    main()    
    
    
    
    