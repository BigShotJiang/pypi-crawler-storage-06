def rega():
    print("My name is Ediko gay")