# jack_midi_split

Provides a jack client which can be instructed to split noteon/noteoff events
between multiple output ports.
