from pdf_suite.command_line.command_line import CommandLine

def main():
    CommandLine().main()

if __name__ == "__main__":
    main()