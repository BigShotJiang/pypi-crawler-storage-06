<!-- simple file for rendering on pypi.org -->

# ParaMorse

README & documentation:  
https://github.com/petertoshev/paramorse#readme

Examples:  
https://github.com/petertoshev/paramorse/tree/main/examples

Cite this repository:  
https://github.com/petertoshev/paramorse/blob/main/CITATION.cff