#!/usr/bin/env python3
"""sticker-convert"""

from sticker_convert.version import __version__  # noqa
