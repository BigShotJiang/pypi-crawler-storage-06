::: albert.collections.btmodel.BTModelSessionCollection
::: albert.collections.btmodel.BTModelCollection
