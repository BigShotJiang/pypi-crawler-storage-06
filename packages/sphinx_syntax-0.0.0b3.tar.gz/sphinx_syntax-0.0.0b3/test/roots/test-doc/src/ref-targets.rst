Ref targets
===========

.. syntax:grammar:: ref-target-in-other-file
   :imports: ref-target-included

   .. syntax:rule:: some-rule


.. syntax:grammar:: ref-target-included

   .. syntax:rule:: some-other-rule
