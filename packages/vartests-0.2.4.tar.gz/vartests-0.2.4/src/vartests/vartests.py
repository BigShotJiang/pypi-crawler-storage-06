# -*- coding: utf-8 -*-

from scipy import stats
import numpy as np
from scipy import optimize
from scipy.stats import chi2
import math
import arch
import time
import pandas as pd
from tqdm import tqdm
from typing import List, Union, Dict

import warnings

warnings.filterwarnings("ignore")


def zero_mean_test(
    data: pd.DataFrame, true_mu: float = 0, conf_level: float = 0.95
) -> Dict:
    """ Perfom a t-Test if mean of distribution:
         - null hypothesis (H0) = zero
         - alternative hypothesis (H1) != zero
         
        Parameters:
            data (dataframe):   pnl (distribution of profit and loss) or return
            true_mu (float):    expected mean of distribuition
            conf_level (float): test confidence level
        Returns:
            answer (dict):      statistics and decision of the test
    """
    if not isinstance(data, pd.DataFrame):
        raise ValueError("Input must be dataframe.")

    significance = 1 - conf_level

    mean = np.mean(data)
    std = np.std(data, ddof=1).values[0]

    t = (mean - true_mu) / (std / np.sqrt(len(data)))
    """p<0.05, 2-tail"""
    t_padrao = stats.t.ppf(1 - round(significance / 2, 4), len(data) - 1)
    pvalue = stats.ttest_1samp(data, popmean=true_mu, alternative="two-sided")[-1]
    H0 = "Mean of distribution = 0"
    if pvalue > significance:  # ou t < np.abs(t_padrao):
        decision = "Fail to rejected H0"
    else:
        decision = "Reject H0"

    answer = {
        "null hypothesis": H0,
        "decision": decision,
        "t-test statistc": t,
        "t-tabuladed": t_padrao,
        "p-value": pvalue,
    }

    return answer


def duration_test(
    violations: Union[List[int], np.ndarray, pd.Series, pd.DataFrame],
    conf_level: float = 0.95,
) -> Dict:

    """Perform the Christoffersen and Pelletier Test (2004) called Duration Test.
        The main objective is to know if the VaR model responds quickly to market movements
         in order to do not form volatility clusters.
        Duration is time betwenn violations of VaR.
        This test verifies if violations has no memory i.e. should be independent.

        Parameters:
            violations (series): series of violations of VaR
            conf_level (float):  test confidence level
        Returns:
            answer (dict):       statistics and decision of the test
    """
    typeok = False
    if isinstance(violations, pd.core.series.Series) or isinstance(
        violations, pd.core.frame.DataFrame
    ):
        violations = violations.values.flatten()
        typeok = True
    elif isinstance(violations, np.ndarray):
        violations = violations.flatten()
        typeok = True
    elif isinstance(violations, list):
        typeok = True
    if not typeok:
        raise ValueError("Input must be list, array, series or dataframe.")

    N = int(sum(violations))
    first_hit = violations[0]
    last_hit = violations[-1]

    duration = [i + 1 for i, x in enumerate(violations) if x == 1]

    D = np.diff(duration)

    TN = len(violations)
    C = np.zeros(len(D))

    if not duration or (D.shape[0] == 0 and len(duration) == 0):
        duration = [0]
        D = [0]
        N = 1

    if first_hit == 0:
        C = np.append(1, C)
        D = np.append(duration[0], D)  # days until first violation

    if last_hit == 0:
        C = np.append(C, 1)
        D = np.append(D, TN - duration[-1])

    else:
        N = len(D)

    def likDurationW(x, D, C, N):
        b = x
        a = ((N - C[0] - C[N - 1]) / (sum(D ** b))) ** (1 / b)
        lik = (
            C[0] * np.log(pweibull(D[0], a, b, survival=True))
            + (1 - C[0]) * dweibull(D[0], a, b, log=True)
            + sum(dweibull(D[1 : (N - 1)], a, b, log=True))
            + C[N - 1] * np.log(pweibull(D[N - 1], a, b, survival=True))
            + (1 - C[N - 1]) * dweibull(D[N - 1], a, b, log=True)
        )

        if np.isnan(lik) or np.isinf(lik):
            lik = 1e10
        else:
            lik = -lik
        return lik

    # When b=1 we get the exponential
    def dweibull(D, a, b, log=False):
        # density of Weibull
        pdf = b * np.log(a) + np.log(b) + (b - 1) * np.log(D) - (a * D) ** b
        if not log:
            pdf = np.exp(pdf)
        return pdf

    def pweibull(D, a, b, survival=False):
        # distribution of Weibull
        cdf = 1 - np.exp(-((a * D) ** b))
        if survival:
            cdf = 1 - cdf
        return cdf

    optimizedBetas = optimize.minimize(
        likDurationW, x0=[2], args=(D, C, N), method="L-BFGS-B", bounds=[(0.001, 10)]
    )

    print(optimizedBetas.message)

    b = optimizedBetas.x
    uLL = -likDurationW(b, D, C, N)
    rLL = -likDurationW(np.array([1]), D, C, N)
    LR = 2 * (uLL - rLL)
    LRp = 1 - chi2.cdf(LR, 1)

    H0 = "Duration Between Exceedances have no memory (Weibull b=1 = Exponential)"
    # i.e. whether we fail to reject the alternative in the LR test that b=1 (hence correct model)
    if LRp < (1 - conf_level):
        decision = "Reject H0"
    else:
        decision = "Fail to Reject H0"

    answer = {
        "weibull exponential": b,
        "unrestricted log-likelihood": uLL,
        "restricted log-likelihood": rLL,
        "log-likelihood": LR,
        "log-likelihood ratio test statistic": LRp,
        "null hypothesis": H0,
        "decision": decision,
    }

    return answer


def failure_rate(violations: Union[List[int], pd.Series, pd.DataFrame]) -> Dict:
    if isinstance(violations, pd.core.series.Series) or isinstance(
        violations, pd.core.frame.DataFrame
    ):
        N = violations.sum()
    elif isinstance(violations, List) or isinstance(violations, np.ndarray):
        N = sum(violations)
    else:
        raise ValueError("Input must be list, array, series or dataframe.")
    TN = len(violations)

    answer = {"failure rate": N / TN}
    print(f"Failure rate of {round((N/TN)*100,2)}%")
    return answer


def kupiec_test(
    violations: Union[List[int], np.ndarray, pd.Series, pd.DataFrame],
    var_conf_level: float = 0.99,
    conf_level: float = 0.95,
) -> Dict:

    """Perform Kupiec Test (1995).
       The main goal is to verify if the number of violations, i.e. proportion of failures, is consistent with the
       violations predicted by the model.
       
        Parameters:
            violations (series):    series of violations of VaR
            var_conf_level (float): VaR confidence level
            conf_level (float):     test confidence level
        Returns:
            answer (dict):          statistics and decision of the test
    """
    if isinstance(violations, pd.core.series.Series):
        n1 = violations[violations == 1].count()
    elif isinstance(violations, pd.core.frame.DataFrame):
        n1 = violations[violations == 1].count().values[0]
    elif isinstance(violations, list):
        lista_array = np.array(violations)
        n1 = len(lista_array[lista_array == 1])
    elif isinstance(violations, np.ndarray):
        n1 = len(violations[violations == 1])
    else:
        raise ValueError("Input must be list, array, series or dataframe.")

    critical_value = 1 - var_conf_level
    n = len(violations)
    n0 = n - n1
    pi_obs = n1 / n
    critical_chi_square = chi2.ppf(conf_level, 1)  # one degree of freedom

    if pi_obs == 0 or pi_obs == 1: # critical values
        return {
                "log-likelihood": np.inf,
                "chi square critical value": critical_chi_square,
                "null hypothesis": f"Probability of failure is {round(1-var_conf_level,3)}",
                "result": "Reject H0",
                    }

    LR = -2 * (
        n1 * np.log(critical_value)
        + n0 * np.log(1 - critical_value)
        - n1 * np.log(pi_obs)
        - n0 * np.log(1 - pi_obs)
    )

    if LR > critical_chi_square:
        result = "Reject H0"
    else:
        result = "Fail to reject H0"

    return {
        "log-likelihood": LR,
        "chi square critical value": critical_chi_square,
        "null hypothesis": f"Probability of failure is {round(1-var_conf_level,3)}",
        "result": result,
            }


def berkowtiz_tail_test(
    pnl: pd.DataFrame,
    volatility_window: int = 252,
    var_conf_level: float = 0.99,
    conf_level: float = 0.95,
    random_seed: int = 443,
) -> Dict:
    """Perform Berkowitz Test (2001).
        The goal is to verify if conditional distributions of returns "GARCH(1,1)" 
        used in the VaR Model is adherent to the data.
        In this specific test, we do not observe the whole data, only the tail.
        
        Parameters:
            data (dataframe):        pnl (distribution of profit and loss) or return
            volatility_window (int): window to cabibrate volatility GARCH model
            var_conf_level (float):  VaR confidence level
            conf_level (float):      test confidence level
            random_seed (int):       integer value to set seed to random values of the optimizer
        Returns:
            answer (dict):           statistics and decision of the test
    """
    if not isinstance(pnl, pd.DataFrame):
        raise ValueError("Input must be dataframe.")

    print("Normalizing returns...")
    conditional_vol, conditional_mean = pd.DataFrame(), pd.DataFrame()
    for t in tqdm(range(pnl.shape[0] - volatility_window)):
        am = arch.arch_model(
            pnl[(t) : (volatility_window + t)],
            vol="GARCH",
            dist="normal",
            rescale=False,
        ).fit(disp="off")
        cond_vol = am.forecast(horizon=1, reindex=False).variance.apply(np.sqrt)
        cond_mean = am.forecast(horizon=1, reindex=False).mean
        conditional_vol = pd.concat([conditional_vol, cond_vol])
        conditional_mean = pd.concat([conditional_mean, cond_mean])

    # Standardized returns with inconditional mean and forecasted conditional volatility
    ret_padr = (pnl[volatility_window:].values.flatten() - pnl[volatility_window:].mean().values[0]) / conditional_vol.values.flatten()

    zeta = stats.norm.ppf(stats.norm.cdf(ret_padr))
    zeta[zeta == np.inf] = 0
    zeta[zeta == -np.inf] = 0

    alpha = 1 - var_conf_level
    significance = 1 - conf_level

    def objective(x):
        # x[0] => media
        # x[1] => vol incondicional
        p1 = zeta[np.where(zeta < stats.norm.ppf((alpha)))]
        p2 = zeta[np.where(zeta >= stats.norm.ppf(alpha))] * 0 + stats.norm.ppf(alpha)
        return -(
            sum(np.log(stats.norm.pdf((p1 - x[0]) / x[1]) / x[1]))
            + sum(np.log(1 - stats.norm.cdf((p2 - x[0]) / x[1])))
        )

    print("Optimizing...")
    start = time.time()
    
    # Configurar semente para reproducibilidade
    np.random.seed(random_seed)
    
    # Inicializações múltiplas para simular restarts
    n_simulations = 200
    n_restarts = 20
    best_result = None
    best_obj_value = np.inf
    initial_guesses = [np.random.uniform(low=[-10, 0.01], high=[10, 3], size=2) for _ in range(n_simulations)]
    
    for guess in initial_guesses[:n_restarts]:
        result = optimize.minimize(
            objective,
            x0=guess,
            method='L-BFGS-B',
            bounds=[(-10, 10), (0.01, 3)],
            options={'maxiter': 100, 'disp': False}
        )
        if result.success and result.fun < best_obj_value:
            best_obj_value = result.fun
            best_result = result

    print(f"Elapsed time: {time.time() - start} s")

    # Resultados
    uLL = -best_result.fun
    rLL = -objective([0, 1])
    LR = 2 * (uLL - rLL)
    chid = 1 - stats.chi2.cdf(LR, 2)
    if chid < significance:
        decision = "Reject H0"
    else:
        decision = "Fail to Reject H0"
    H0 = "Distribuition is Normal(0,1)"

    answer = {
        "solution": best_result,  # Objeto OptimizeResult do scipy
        "ull": uLL,
        "rll": rLL,
        "LR": LR,
        "chi square test": chid,
        "null hypothesis": H0,
        "decision": decision,
    }

    return answer