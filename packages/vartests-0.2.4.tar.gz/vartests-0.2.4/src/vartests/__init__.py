from .vartests import *
from . import version

__version__ = version.__version__
__author__ = "Rafael Rodrigues, rafa-rod @ GitHub"