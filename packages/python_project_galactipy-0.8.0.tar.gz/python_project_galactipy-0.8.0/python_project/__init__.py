# type: ignore[attr-defined]
"""Awesome `python-project` is a Python cli/package created with https://gitlab.com/galactipy/galactipy."""

# Placeholder for poetry-dynamic-versioning, do not change:
# https://github.com/mtkennerly/poetry-dynamic-versioning#installation
__version__ = "0.8.0"

# TODO Update with imported objects
# __all__ = []
