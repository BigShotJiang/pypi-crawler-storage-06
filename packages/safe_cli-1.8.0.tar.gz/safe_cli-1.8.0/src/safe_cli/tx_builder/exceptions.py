class SoliditySyntaxError(Exception):
    pass


class TxBuilderEncodingError(Exception):
    pass
