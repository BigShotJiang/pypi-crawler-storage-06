from .fits import scan_fits_table

__all__ = ["scan_fits_table"]
