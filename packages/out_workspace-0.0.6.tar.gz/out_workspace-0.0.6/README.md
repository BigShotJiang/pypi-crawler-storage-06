[![pytest](https://github.com/ppak10/out-workspace/actions/workflows/pytest.yml/badge.svg)](https://github.com/ppak10/out-workspace/actions/workflows/pytest.yml)
[![codecov](https://codecov.io/gh/ppak10/out-workspace/graph/badge.svg?token=U54BBR0EAA)](https://codecov.io/gh/ppak10/out-workspace)

# out-workspace
Workspace management package for `out` folder shared between different packages.
