"""Compatibility shim: common has been split into client and server packages."""
