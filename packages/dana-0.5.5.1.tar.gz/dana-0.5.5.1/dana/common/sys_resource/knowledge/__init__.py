"""Knowledge system resources."""

from .knowledge_base_resource import KnowledgeBaseResource

__all__ = ["KnowledgeBaseResource"]
