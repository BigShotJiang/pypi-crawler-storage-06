# lonelyguy

[![PyPI - Version](https://img.shields.io/pypi/v/lonelyguy.svg)](https://pypi.org/project/lonelyguy)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/lonelyguy.svg)](https://pypi.org/project/lonelyguy)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install lonelyguy
```

## License

`lonelyguy` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
