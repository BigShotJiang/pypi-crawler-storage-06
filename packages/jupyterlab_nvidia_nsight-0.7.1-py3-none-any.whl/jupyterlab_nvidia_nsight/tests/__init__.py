"""Python unit tests for jupyterlab_nvidia_nsight."""
