# Changelog

## 0.10.0 (2025-09-19)

Full Changelog: [v0.9.0...v0.10.0](https://github.com/ppl-ai/perplexity-py/compare/v0.9.0...v0.10.0)

### Features

* **api:** manual updates ([7f38b2f](https://github.com/ppl-ai/perplexity-py/commit/7f38b2f1eb750a6d5e435a5bfd376b62fa5a9594))

## 0.9.0 (2025-09-17)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/ppl-ai/perplexity-py/compare/v0.8.0...v0.9.0)

### Features

* **api:** manual updates ([8fbe318](https://github.com/ppl-ai/perplexity-py/commit/8fbe318c5ed7df04335c2cd14de708cae5780623))


### Chores

* **internal:** update pydantic dependency ([cac84f2](https://github.com/ppl-ai/perplexity-py/commit/cac84f25cd550ee57f8971d74231f63ba8d36905))

## 0.8.0 (2025-09-15)

Full Changelog: [v0.7.2...v0.8.0](https://github.com/ppl-ai/perplexity-py/compare/v0.7.2...v0.8.0)

### Features

* **api:** update via SDK Studio ([5a26918](https://github.com/ppl-ai/perplexity-py/commit/5a269186a185f62a94fbfc57e627f8820194dc23))

## 0.7.2 (2025-09-10)

Full Changelog: [v0.7.1...v0.7.2](https://github.com/ppl-ai/perplexity-py/compare/v0.7.1...v0.7.2)

## 0.7.1 (2025-09-10)

Full Changelog: [v0.7.0...v0.7.1](https://github.com/ppl-ai/perplexity-py/compare/v0.7.0...v0.7.1)

### Chores

* remove custom code ([3270d55](https://github.com/ppl-ai/perplexity-py/commit/3270d55b91143e4b9dbc118f39791d36444e0409))

## 0.7.0 (2025-09-10)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/ppl-ai/perplexity-py/compare/v0.6.0...v0.7.0)

### Features

* **api:** add /chat/completions and /async/chat/completions ([945f7c2](https://github.com/ppl-ai/perplexity-py/commit/945f7c27c80ca90f6c703590578a414351e0adb2))

## 0.6.0 (2025-09-08)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/ppl-ai/perplexity-py/compare/v0.5.0...v0.6.0)

### Features

* **api:** add /content endpoint ([a83e23b](https://github.com/ppl-ai/perplexity-py/commit/a83e23bbcacc8b80748ccf512f3a287ed6011a37))
* **api:** include /content endpoint ([d30ca3e](https://github.com/ppl-ai/perplexity-py/commit/d30ca3e3697f8fd5e17f00762ab2a89ea4d5814f))

## 0.5.0 (2025-09-08)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/ppl-ai/perplexity-py/compare/v0.4.0...v0.5.0)

### Features

* **api:** change bearer_token to api_key ([875bba1](https://github.com/ppl-ai/perplexity-py/commit/875bba126072093d572f00818746b0637a1a56a6))

## 0.4.0 (2025-09-07)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/ppl-ai/perplexity-py/compare/v0.3.0...v0.4.0)

### Features

* **api:** update from perform -&gt; create ([35d2c42](https://github.com/ppl-ai/perplexity-py/commit/35d2c42567e59d53b37be7d4699f80755c09ca30))


### Chores

* update SDK settings ([a5a9d00](https://github.com/ppl-ai/perplexity-py/commit/a5a9d0009d07b48cf9b5f4521705acdb6878c904))

## 0.3.0 (2025-09-07)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/ppl-ai/perplexity-py/compare/v0.2.1...v0.3.0)

### Features

* **api:** update project name ([b9ab21e](https://github.com/ppl-ai/perplexity-py/commit/b9ab21e669afb28c61908dc222cc5a94ec1d6b8e))

## 0.2.1 (2025-09-07)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/ppl-ai/perplexity-py/compare/v0.2.0...v0.2.1)

### Chores

* remove custom code ([e275207](https://github.com/ppl-ai/perplexity-py/commit/e27520747d07452162ae76fddcc7064d3d7f4631))
* update SDK settings ([b4668b0](https://github.com/ppl-ai/perplexity-py/commit/b4668b0ab36992c7e097f4e134a8eb36a2de7395))

## 0.2.0 (2025-09-07)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/ppl-ai/perplexity-py/compare/v0.1.0...v0.2.0)

### Features

* **api:** initial updates ([dd0709d](https://github.com/ppl-ai/perplexity-py/commit/dd0709dcc9775ae935a6dad72bc826d2a61dd740))
* **api:** simplify name ([6794370](https://github.com/ppl-ai/perplexity-py/commit/679437027a8d0f3d930902d3410e366cd392beb8))

## 0.1.0 (2025-09-07)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/ppl-ai/perplexity-py/compare/v0.0.2...v0.1.0)

### Features

* **api:** initial updates ([dd0709d](https://github.com/ppl-ai/perplexity-py/commit/dd0709dcc9775ae935a6dad72bc826d2a61dd740))

## 0.0.2 (2025-09-07)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/ppl-ai/perplexity-py/compare/v0.0.1...v0.0.2)

### Chores

* sync repo ([b968b23](https://github.com/ppl-ai/perplexity-py/commit/b968b23fc9d25d7cd9e84d2796e33a3f56c60656))
* update SDK settings ([e3c15b6](https://github.com/ppl-ai/perplexity-py/commit/e3c15b6ab6392d0f7605c7ba7666cec2eb405f23))
* update SDK settings ([235c22f](https://github.com/ppl-ai/perplexity-py/commit/235c22f4bdd73b3dd5657bd1caadef4bac172fbe))
