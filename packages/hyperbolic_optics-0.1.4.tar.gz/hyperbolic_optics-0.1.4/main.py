def main():
    print("Hello from hyperbolic-optics!")


if __name__ == "__main__":
    main()
