"""Telemetry module for Agent Copilot."""
