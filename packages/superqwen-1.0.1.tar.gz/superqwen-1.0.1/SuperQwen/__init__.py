__version__ = "1.0.1"
__author__ = "NomenAK, Mithun Gowda B"
__email__ = "anton.knoery@gmail.com, mithungowda.b7411@gmail.com"
__github__ = "NomenAK, mithun50"
