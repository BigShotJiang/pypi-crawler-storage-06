"""Tests for Contexter package."""
