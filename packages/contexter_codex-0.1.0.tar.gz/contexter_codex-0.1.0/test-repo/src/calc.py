class Calculator:
    pass
