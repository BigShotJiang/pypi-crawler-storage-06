"""
Utility modules for Contexter.

Contains helper functions for file operations, git integration,
and cross-platform clipboard support.
"""
