"""
Contexter — Prompt-first, Codex-only context pack generator

A tool that lets GPT-5 Codex build and maintain compact, navigable
Markdown context packs for repositories without touching source code.
"""

__version__ = "0.1.0"
__author__ = "Gudjon Mar Gudjonsson"
__license__ = "MIT"
