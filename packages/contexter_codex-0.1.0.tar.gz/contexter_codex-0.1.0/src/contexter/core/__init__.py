"""
Core modules for Contexter.

Contains the main orchestration logic and deterministic processing
that prepares inputs for Codex to perform intelligent analysis.
"""
