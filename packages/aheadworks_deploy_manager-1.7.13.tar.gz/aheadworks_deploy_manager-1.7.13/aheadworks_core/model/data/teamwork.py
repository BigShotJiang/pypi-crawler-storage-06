
class TeamworkConfig:
    def __init__(self, user, token):
        self.user = user
        self.token = token
