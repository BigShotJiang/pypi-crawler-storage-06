"""Entry point for cell_cycle_classification."""

from cell_cycle_classification.cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
