from cell_cycle_classification.base import NAME


def test_base():
    assert NAME == "cell_cycle_classification"
