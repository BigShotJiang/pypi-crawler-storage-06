def test_imports():
    import cell_cycle_classification.utils.model_trainer
