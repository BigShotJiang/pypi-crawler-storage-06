from relationalai.early_access.builder import select

select(1 + 1).inspect()