"""Zymmr Client - Python library for Zymmr Project Management API."""

__version__ = "0.1.0"
__author__ = "Kiran Harbak"
__email__ = "kiran.harbak@amruts.com"


def main() -> None:
    """CLI entry point."""
    print("Hello from zymmr-client!")

# Future exports will go here
# from .client import ZymmrClient
# __all__ = ["ZymmrClient"]
