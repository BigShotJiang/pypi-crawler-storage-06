"""
Tests for PyroChain.
"""
