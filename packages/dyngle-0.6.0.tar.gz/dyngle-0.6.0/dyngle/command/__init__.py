from wizlib.command import WizCommand


class DyngleCommand(WizCommand):

    default = 'run'
