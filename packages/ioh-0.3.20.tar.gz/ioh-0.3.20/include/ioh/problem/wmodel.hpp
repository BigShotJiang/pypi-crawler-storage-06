#pragma once

#include "wmodel/wmodel_problem.hpp"
#include "wmodel/wmodel_leading_ones.hpp"
#include "wmodel/wmodel_one_max.hpp"

