#pragma once

#include "submodular/graph_problem.hpp"
#include "submodular/max_cut.hpp"
#include "submodular/max_coverage.hpp"
#include "submodular/max_influence.hpp"
#include "submodular/pack_while_travel.hpp"