#pragma once
#ifndef FMT_HEADER_ONLY
#define FMT_HEADER_ONLY
#endif 
#include <fmt/compile.h>
#include <fmt/format.h>
#include <fmt/ranges.h> 