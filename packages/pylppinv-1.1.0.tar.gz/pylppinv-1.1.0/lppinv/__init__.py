__version__ = "1.1.0"

from .lppinv import lppinv

__all__ = [
    "lppinv",
    "__version__"
]
