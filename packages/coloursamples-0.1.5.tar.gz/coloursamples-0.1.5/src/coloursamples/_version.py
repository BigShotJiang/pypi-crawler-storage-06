"""Version information for coloursamples package."""

__version__ = "0.1.5"
__version_tuple__ = (0, 1, 5)

# For backwards compatibility
version = __version__
version_tuple = __version_tuple__
