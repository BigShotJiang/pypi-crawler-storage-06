"""Test package for coloursamples."""
