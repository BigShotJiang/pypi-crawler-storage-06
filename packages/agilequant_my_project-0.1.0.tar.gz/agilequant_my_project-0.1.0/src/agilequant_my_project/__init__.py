def main() -> None:
    print("Hello from my-project!")
