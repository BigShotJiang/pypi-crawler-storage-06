"""Stadata X - Terminal UI untuk data BPS Indonesia"""

__version__ = "0.1.7"
