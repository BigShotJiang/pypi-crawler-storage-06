# stadata_x/widgets/footer.py

from textual.widgets import Footer

class StadataFooter(Footer):
    """Footer kustom untuk aplikasi Stadata-X."""
    pass 
