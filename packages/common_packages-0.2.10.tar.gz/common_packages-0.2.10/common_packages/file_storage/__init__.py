from .local import LocalStorage
from .tencent_cos import TencentCos
