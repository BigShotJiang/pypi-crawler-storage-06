===========
User Plugin
===========

This plugin currently has an internal list of users,
an admin interface,
and a mobile login interface

It needs a pretty big redesign to support authenticating against AD and configurable
plugin authentications - Currently that's hard coded in the plugins.