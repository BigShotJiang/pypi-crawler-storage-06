import typing


BootstrapObjectT = typing.TypeVar("BootstrapObjectT", bound=typing.Any)
ApplicationT = typing.TypeVar("ApplicationT", bound=typing.Any)
