# Changelog

## 0.2.1 (2025-09-19)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/landing-ai/ade-python/compare/v0.2.0...v0.2.1)

### Chores

* **types:** change optional parameter type from NotGiven to Omit ([29a0a2d](https://github.com/landing-ai/ade-python/commit/29a0a2de368b135025a8379e26634f4dc5d6a1e8))

## 0.2.0 (2025-09-18)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/landing-ai/ade-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** support environments ([e9b604e](https://github.com/landing-ai/ade-python/commit/e9b604e76d03a9e630c8567d3f014032ca186376))

## 0.1.0 (2025-09-18)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/landing-ai/ade-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([eb76a32](https://github.com/landing-ai/ade-python/commit/eb76a3275704d50396d00fd8ac79c2537ce251fc))


### Chores

* configure new SDK language ([9761e2b](https://github.com/landing-ai/ade-python/commit/9761e2bed207087deba958e693fd381eb5599a67))
* update SDK settings ([b46e740](https://github.com/landing-ai/ade-python/commit/b46e74012a27713aaa82f99bd11e527c92e912f4))
* update SDK settings ([982e228](https://github.com/landing-ai/ade-python/commit/982e2280ef59753578cfc5c4272fca2f90c2083a))
