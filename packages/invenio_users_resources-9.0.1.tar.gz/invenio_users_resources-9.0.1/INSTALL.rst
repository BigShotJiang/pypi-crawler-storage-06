Installation
============

Invenio-Users-Resources is on PyPI so all you need is:

.. code-block:: console

   $ pip install invenio-users-resources
