..
    Copyright (C) 2022 CERN.

    Invenio-Users-Resources is free software; you can redistribute it
    and/or modify it under the terms of the MIT License; see LICENSE file for
    more details.

=========================
 Invenio-Users-Resources
=========================

.. image:: https://github.com/inveniosoftware/invenio-users-resources/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-users-resources/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/inveniosoftware/invenio-users-resources.svg
        :target: https://github.com/inveniosoftware/invenio-users-resources/releases

.. image:: https://img.shields.io/pypi/dm/invenio-users-resources.svg
        :target: https://pypi.python.org/pypi/invenio-users-resources

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-users-resources.svg
        :target: https://github.com/inveniosoftware/invenio-users-resources/blob/master/LICENSE

Invenio module providing management APIs for users and roles/groups.

TODO: Please provide feature overview of module

Further documentation is available on
https://invenio-users-resources.readthedocs.io/
