from .machine_dialect_vm import *

__doc__ = machine_dialect_vm.__doc__
if hasattr(machine_dialect_vm, "__all__"):
    __all__ = machine_dialect_vm.__all__