"""
Erreurs propres à Taxhub
"""


class TaxhubError(Exception):
    pass
