# -*- coding: utf-8 -*-

"""Unit tests for ChemoPy."""
