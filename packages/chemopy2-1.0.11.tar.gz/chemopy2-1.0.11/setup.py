# -*- coding: utf-8 -*-

"""Setup module."""

# import os
# import shutil

import setuptools

if __name__ == "__main__":
    setuptools.setup()
