from django.apps import AppConfig


class LacreiModelsLacreiidConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "lacrei_models.lacreiid"
