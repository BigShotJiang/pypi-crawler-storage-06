import click
import rich


def main():
    print("Hi! from", __file__)
    print("Got", rich)
    print("Got", click)
