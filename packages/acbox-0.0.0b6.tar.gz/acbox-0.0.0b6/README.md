## ACBox my little toolbox


### Development

```
python3.13 -m venv .venv
source .venv/bin/activate
```

```
python -m pip install --upgrade pip
python -m pip install --group dev
pre-commit install
```

Ready.
