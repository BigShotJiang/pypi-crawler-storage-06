# This is a simple text in Markdown

You can only render this file into json 
if you have [pandoc](https://pandoc.org/) installed.

## Title level 2
Pandoc is a fairly heavy package, so **we are not installing it**.

## Second title level 2
To make things easier, the file `test_pandoc.json` is a result of the conversion to json (`pandoc test_pandoc.md -o test_pandoc.json`)

It is that that file which is tested wiht the `test_pandoc.py` file.