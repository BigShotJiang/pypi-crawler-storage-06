if __name__ == "__main__":
  from togura.cli import app
  app()
