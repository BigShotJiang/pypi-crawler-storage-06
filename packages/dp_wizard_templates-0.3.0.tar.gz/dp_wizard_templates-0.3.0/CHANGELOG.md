# CHANGELOG

## 0.3.0

- Show all errors, and support comment blocks [#12](https://github.com/opendp/dp-wizard-templates/pull/12)

## 0.2.0

- Link to ghpages [#7](https://github.com/opendp/dp-wizard-templates/pull/7)
- Add black, and a generated index.html [#6](https://github.com/opendp/dp-wizard-templates/pull/6)

## 0.1.0

Initial release