"""Tests that communicate with file plugin via the v3 API."""
