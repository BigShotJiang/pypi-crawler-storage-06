``pulp_rpm`` Plugin
===================

.. figure:: https://github.com/pulp/pulp_rpm/actions/workflows/nightly.yml/badge.svg?branch=main
   :alt: Rpm Nightly CI/CD

This is the ``pulp_rpm`` Plugin for `Pulp Project
3.0+ <https://pypi.python.org/pypi/pulpcore/>`__. This plugin provides support for RPM family
content types, similar to the ``pulp_rpm`` plugin for Pulp 2.

For more information, please see the `documentation
<https://docs.pulpproject.org/pulp_rpm/>`_ or the `Pulp project page
<https://pulpproject.org>`_.
