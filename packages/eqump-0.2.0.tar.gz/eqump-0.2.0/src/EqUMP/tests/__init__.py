"""Test suite for EqUMP package."""
