# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BandWidthRules:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'name': 'str',
        'admin_state_up': 'bool',
        'egress_size': 'int',
        'egress_guarented_size': 'int',
        'publicip_info': 'list[PublicipInfoResp]'
    }

    attribute_map = {
        'id': 'id',
        'name': 'name',
        'admin_state_up': 'admin_state_up',
        'egress_size': 'egress_size',
        'egress_guarented_size': 'egress_guarented_size',
        'publicip_info': 'publicip_info'
    }

    def __init__(self, id=None, name=None, admin_state_up=None, egress_size=None, egress_guarented_size=None, publicip_info=None):
        r"""BandWidthRules

        The model defined in huaweicloud sdk

        :param id: 带宽规则ID
        :type id: str
        :param name: 带宽规则名称
        :type name: str
        :param admin_state_up: 配置状态，为False时配置不生效。
        :type admin_state_up: bool
        :param egress_size: 出网带宽最大值，单位M bps。取值范围[0,n]，其中n为所属带宽的带宽大小（size字段）。0表示设置为最大带宽。
        :type egress_size: int
        :param egress_guarented_size: 出网保障带宽大小，单位M bps。取值范围[0,x]，其中x为所属带宽剩余的保障额。
        :type egress_guarented_size: int
        :param publicip_info: 功能说明：带宽对应的弹性公网IP信息  约束：WHOLE类型的带宽支持多个弹性公网IP，PER类型的带宽只能对应一个弹性公网IP
        :type publicip_info: list[:class:`huaweicloudsdkeip.v2.PublicipInfoResp`]
        """
        
        

        self._id = None
        self._name = None
        self._admin_state_up = None
        self._egress_size = None
        self._egress_guarented_size = None
        self._publicip_info = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if name is not None:
            self.name = name
        if admin_state_up is not None:
            self.admin_state_up = admin_state_up
        if egress_size is not None:
            self.egress_size = egress_size
        if egress_guarented_size is not None:
            self.egress_guarented_size = egress_guarented_size
        if publicip_info is not None:
            self.publicip_info = publicip_info

    @property
    def id(self):
        r"""Gets the id of this BandWidthRules.

        带宽规则ID

        :return: The id of this BandWidthRules.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this BandWidthRules.

        带宽规则ID

        :param id: The id of this BandWidthRules.
        :type id: str
        """
        self._id = id

    @property
    def name(self):
        r"""Gets the name of this BandWidthRules.

        带宽规则名称

        :return: The name of this BandWidthRules.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this BandWidthRules.

        带宽规则名称

        :param name: The name of this BandWidthRules.
        :type name: str
        """
        self._name = name

    @property
    def admin_state_up(self):
        r"""Gets the admin_state_up of this BandWidthRules.

        配置状态，为False时配置不生效。

        :return: The admin_state_up of this BandWidthRules.
        :rtype: bool
        """
        return self._admin_state_up

    @admin_state_up.setter
    def admin_state_up(self, admin_state_up):
        r"""Sets the admin_state_up of this BandWidthRules.

        配置状态，为False时配置不生效。

        :param admin_state_up: The admin_state_up of this BandWidthRules.
        :type admin_state_up: bool
        """
        self._admin_state_up = admin_state_up

    @property
    def egress_size(self):
        r"""Gets the egress_size of this BandWidthRules.

        出网带宽最大值，单位M bps。取值范围[0,n]，其中n为所属带宽的带宽大小（size字段）。0表示设置为最大带宽。

        :return: The egress_size of this BandWidthRules.
        :rtype: int
        """
        return self._egress_size

    @egress_size.setter
    def egress_size(self, egress_size):
        r"""Sets the egress_size of this BandWidthRules.

        出网带宽最大值，单位M bps。取值范围[0,n]，其中n为所属带宽的带宽大小（size字段）。0表示设置为最大带宽。

        :param egress_size: The egress_size of this BandWidthRules.
        :type egress_size: int
        """
        self._egress_size = egress_size

    @property
    def egress_guarented_size(self):
        r"""Gets the egress_guarented_size of this BandWidthRules.

        出网保障带宽大小，单位M bps。取值范围[0,x]，其中x为所属带宽剩余的保障额。

        :return: The egress_guarented_size of this BandWidthRules.
        :rtype: int
        """
        return self._egress_guarented_size

    @egress_guarented_size.setter
    def egress_guarented_size(self, egress_guarented_size):
        r"""Sets the egress_guarented_size of this BandWidthRules.

        出网保障带宽大小，单位M bps。取值范围[0,x]，其中x为所属带宽剩余的保障额。

        :param egress_guarented_size: The egress_guarented_size of this BandWidthRules.
        :type egress_guarented_size: int
        """
        self._egress_guarented_size = egress_guarented_size

    @property
    def publicip_info(self):
        r"""Gets the publicip_info of this BandWidthRules.

        功能说明：带宽对应的弹性公网IP信息  约束：WHOLE类型的带宽支持多个弹性公网IP，PER类型的带宽只能对应一个弹性公网IP

        :return: The publicip_info of this BandWidthRules.
        :rtype: list[:class:`huaweicloudsdkeip.v2.PublicipInfoResp`]
        """
        return self._publicip_info

    @publicip_info.setter
    def publicip_info(self, publicip_info):
        r"""Sets the publicip_info of this BandWidthRules.

        功能说明：带宽对应的弹性公网IP信息  约束：WHOLE类型的带宽支持多个弹性公网IP，PER类型的带宽只能对应一个弹性公网IP

        :param publicip_info: The publicip_info of this BandWidthRules.
        :type publicip_info: list[:class:`huaweicloudsdkeip.v2.PublicipInfoResp`]
        """
        self._publicip_info = publicip_info

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BandWidthRules):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
