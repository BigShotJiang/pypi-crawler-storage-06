
# Register models
from terratorch.models.backbones.terramind.model import terramind_register
from terratorch.models.backbones.terramind.tokenizer import tokenizer_register
from terratorch.models.backbones.terramind.tokenizer import tokenizer_backbones_register
