# Aerospike common module

Library for commonly used or shared code.
Used by Aerospike Server and Aerospike C Client.

## Build

### Linux and MacOS

	$ make clean
	$ make

### MacOS XCode

- Double click xcode/aerospike-common.xcworkspace
- Click Product -> Build

### Windows Visual Studio 2022+

- Double click vs/aerospike-common.sln
- Click Build -> Build Solution
