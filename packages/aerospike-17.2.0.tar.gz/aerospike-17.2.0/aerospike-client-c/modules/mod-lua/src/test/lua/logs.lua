
function INFO(r,m)
    info(m)
    return 1
end

function WARN(r,m)
    warn(m)
    return 1
end

function DEBUG(r,m)
    debug(m)
    return 1
end

function TRACE(r,m)
    trace(m)
    return 1
end