
function a(b)
    b[c] = d
end
