
a.b = c