# Template Docs

- test: {{ custom_macros }}
- var: {{ vars('project_id') }}
