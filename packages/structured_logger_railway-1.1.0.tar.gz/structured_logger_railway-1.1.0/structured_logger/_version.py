"""Version information for structured-logger package."""

__version__ = "1.1.0"