NAME = "binance-sdk-derivatives-trading-coin-futures"
