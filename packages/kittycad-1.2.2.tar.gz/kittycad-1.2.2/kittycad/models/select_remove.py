from .base import KittyCadBaseModel


class SelectRemove(KittyCadBaseModel):
    """The response from the `SelectRemove` endpoint."""
