from .base import KittyCadBaseModel


class Solid3dShellFace(KittyCadBaseModel):
    """The response from the `Solid3dShellFace` endpoint."""
