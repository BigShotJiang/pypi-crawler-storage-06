from .base import KittyCadBaseModel


class EntityMakeHelixFromEdge(KittyCadBaseModel):
    """The response from the `EntityMakeHelixFromEdge` endpoint."""
