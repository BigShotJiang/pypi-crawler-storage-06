Módulo para la presentación del modelo 420 (IGIC - Autodeclaración) de
la Agencia Tributaria Canaria.

Instrucciones del modelo:
<https://www3.gobiernodecanarias.org/tributos/atc/estatico/asistencia_contribuyente/modelos/ref_y_propios/igic/mod420/pdf/instrucciones/420.pdf>
