# Cursor Integration

Coming soon - detailed Cursor setup guide.

Tip: If Cursor supports custom MCP servers, use the same JSON from Quick Start.

→ [Back to Integrations Overview](index.md)
