# Claude Desktop Integration

*Coming soon - comprehensive Claude Desktop setup guide*

For now, please refer to our [Quick Start Guide](../getting-started/quickstart.md) which includes Claude Desktop configuration instructions.

## Quick Configuration

Use the configuration JSON from the Quick Start guide.

→ [Back to Integrations Overview](index.md)
