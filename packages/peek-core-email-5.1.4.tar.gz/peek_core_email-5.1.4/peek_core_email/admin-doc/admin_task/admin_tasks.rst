===========
Admin Tasks
===========

This section describes how to perform administration tasks for the Core Email
Plugin.

Edit the Email Settings
-----------------------

The email and sms settings can edited via the admin UI.

Open the Peek Admin UI and navigate to the Email Menu.

----

#. Click the **Settings** tab.
#. Edit the settings.
#. Click **Save**.

.. image:: edit_email_settings.png
    :align: center




