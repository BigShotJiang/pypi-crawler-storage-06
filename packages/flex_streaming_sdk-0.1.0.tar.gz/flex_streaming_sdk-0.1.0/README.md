Flexitricity Streaming Tools 🛶

🛠️ Note, this library is still under development, and not yet published!

Development tools for streaming, install via pip install flexitricity-stream-tools and import with from flex import stream.

Tools in here are designed to support streaming onto Azure event hubs, grids etc, as well as to create standards for consistent message formats for easier sending/recieving.
