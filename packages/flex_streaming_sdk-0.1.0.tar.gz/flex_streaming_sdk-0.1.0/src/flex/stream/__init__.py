"""
Flex stream sdk is a tool for handling streaming to eventhub with minimal bottlenecks
"""

from flex.stream.batch_handler import send_to_eventhub, BatchHandler  # noqa
from flex.stream._version import __version__  # noqa
