def test_protocol():
    pass
