from .thinking_actions import think


__all__ = ["think"]
