from .rlbot_flatbuffers import *

__doc__ = rlbot_flatbuffers.__doc__
if hasattr(rlbot_flatbuffers, "__all__"):
    __all__ = rlbot_flatbuffers.__all__