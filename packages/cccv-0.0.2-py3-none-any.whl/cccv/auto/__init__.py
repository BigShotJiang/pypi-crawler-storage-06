from cccv.auto.config import AutoConfig  # noqa
from cccv.auto.model import AutoModel  # noqa
