from typing import List

# ...existing settings...

ALLOWED_HOSTS: List[str] = []

# ...existing settings...
