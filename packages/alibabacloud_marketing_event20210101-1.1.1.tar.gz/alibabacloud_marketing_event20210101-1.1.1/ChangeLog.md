2024-10-09 Version: 1.1.0
- Support API AddSumRecordFlowPop.
- Support API BindExhibitorRfidPop.
- Support API BindGuestRfidPop.
- Support API CheckNFCBindPop.
- Support API QueryOrderSessionListPop.
- Support API QuerySessionByActivityIdPop.
- Support API QuerySessionListPop.
- Support API QuerySignInRecordPop.
- Support API TicketOrCredentialsSignInPop.
- Support API UpdateCredentialsStatusPop.
- Support API UpdateTicketRecordByticketCodePop.


2024-09-09 Version: 1.0.1
- Update API FindGuestCredentialsRecord: add param EndDateTime.
- Update API FindGuestCredentialsRecord: add param StartDateTime.
- Update API FindGuestTicketRecord: add param EndDateTime.
- Update API FindGuestTicketRecord: add param StartDateTime.


2024-09-04 Version: 1.0.0
- Generated python 2021-01-01 for marketing_event.

