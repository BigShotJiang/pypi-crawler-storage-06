# data/flu

`cluster_cons.json`

- See `djpiri/content/Sequence/h3n2/1968-2023/2023-03-30-classifying-h3n2-seqs-clusters.ipynb`
- More info: https://djpiri.vetmed.wisc.edu/2023-03-30-classifying-h3n2-seqs-clusters.html