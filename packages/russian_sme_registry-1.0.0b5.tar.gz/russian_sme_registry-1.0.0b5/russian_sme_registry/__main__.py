from russian_sme_registry.main import app

if __name__ == "__main__":
    app(prog_name="russian-sme-registry")
