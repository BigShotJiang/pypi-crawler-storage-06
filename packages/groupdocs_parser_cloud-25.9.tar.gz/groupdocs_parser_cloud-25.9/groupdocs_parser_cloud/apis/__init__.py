from __future__ import absolute_import

# flake8: noqa

# import apis
from groupdocs_parser_cloud.apis.file_api import FileApi
from groupdocs_parser_cloud.apis.folder_api import FolderApi
from groupdocs_parser_cloud.apis.info_api import InfoApi
from groupdocs_parser_cloud.apis.parse_api import ParseApi
from groupdocs_parser_cloud.apis.storage_api import StorageApi
from groupdocs_parser_cloud.apis.template_api import TemplateApi
