model_data = {
    ("edc_list_data.consignee", "name"): [
        {
            "name": "The META Trial",
            "contact": "Sokoine Kivuyo",
            "address": "NIMR Tanzania",
        }
    ]
}
