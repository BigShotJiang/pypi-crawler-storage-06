list_data = {
    "edc_list_data.antibiotic": [
        ("one", "One"),
        ("two", "Two"),
        ("three", "Three"),
    ],
}

list_data.append("oops")
