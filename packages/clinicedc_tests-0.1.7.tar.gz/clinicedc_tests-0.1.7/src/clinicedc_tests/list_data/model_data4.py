model_data = {
    "edc_list_data.customer": [
        {
            "name": "The META Trial",
            "contact": "Sokoine Kivuyo",
            "address": "NIMR Tanzania",
        }
    ]
}
