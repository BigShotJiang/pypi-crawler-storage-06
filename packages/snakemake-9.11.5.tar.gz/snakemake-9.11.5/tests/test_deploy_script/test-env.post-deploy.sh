#!/bin/bash

touch $CONDA_PREFIX/test.txt