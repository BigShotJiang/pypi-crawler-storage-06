from vkbottle_types.codegen.methods.apps import *  # noqa: F403,F401
