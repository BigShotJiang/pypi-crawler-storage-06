from vkbottle_types.codegen.methods.notes import *  # noqa: F403,F401
