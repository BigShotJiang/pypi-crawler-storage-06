from ..base_component import BaseComponent

class MonitoringComponent(BaseComponent):
    name = "monitoring"

    def register(self, server, config=None):
        # Skeleton: add monitoring hooks to server
        pass
