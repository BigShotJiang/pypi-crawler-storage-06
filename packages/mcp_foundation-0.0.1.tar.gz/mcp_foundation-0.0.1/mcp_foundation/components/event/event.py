from ..base_component import BaseComponent

class EventComponent(BaseComponent):
    name = "event"

    def register(self, server, config=None):
        # Skeleton: add event hooks to server
        pass
