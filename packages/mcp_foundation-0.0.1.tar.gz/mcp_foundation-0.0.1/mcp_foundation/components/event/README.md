# Event Component

This is a plugin component. Implementation will be added when we have detailed requirements.

## Basic Idea

The event component is intended for asynchronous communication between the MCP service and the MCP management platform.
