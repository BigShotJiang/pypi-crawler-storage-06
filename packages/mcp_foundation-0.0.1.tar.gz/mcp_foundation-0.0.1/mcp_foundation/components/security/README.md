# Security Component

This is a plugin component. Implementation will be added when we have detailed requirements.

## Basic Idea

The security component is intended to provide security controls for MCP services, such as rate limiting.
