"""Tests for Malti Python SDK"""
