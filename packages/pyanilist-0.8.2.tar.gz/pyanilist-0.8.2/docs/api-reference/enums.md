::: pyanilist.CharacterRole
    options:
        members: true
::: pyanilist.CharacterSort
    options:
        members: true
::: pyanilist.ExternalLinkType
    options:
        members: true
::: pyanilist.MediaFormat
    options:
        members: true
::: pyanilist.MediaRankType
    options:
        members: true
::: pyanilist.MediaRelation
    options:
        members: true
::: pyanilist.MediaSeason
    options:
        members: true
::: pyanilist.MediaSort
    options:
        members: true
::: pyanilist.MediaSource
    options:
        members: true
::: pyanilist.MediaStatus
    options:
        members: true
::: pyanilist.MediaType
    options:
        members: true
::: pyanilist.RecommendationSort
    options:
        members: true
::: pyanilist.StaffSort
    options:
        members: true
::: pyanilist.StudioSort
    options:
        members: true
