::: pyanilist.AnilistError
::: pyanilist.MediaNotFoundError
::: pyanilist.NoMediaArgumentsError
::: pyanilist.RateLimitError
