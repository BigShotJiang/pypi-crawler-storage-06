<!-- Private Base Class -->
::: pyanilist._types.Base
<!-- Public Types -->
::: pyanilist.AiringSchedule
::: pyanilist.Character
::: pyanilist.CharacterImage
::: pyanilist.CharacterName
::: pyanilist.FuzzyDate
::: pyanilist.Media
::: pyanilist.MediaCoverImage
::: pyanilist.MediaExternalLink
::: pyanilist.MediaRank
::: pyanilist.MediaStreamingEpisode
::: pyanilist.MediaTag
::: pyanilist.MediaTitle
::: pyanilist.MediaTrailer
::: pyanilist.RecommendedMedia
::: pyanilist.RelatedMedia
::: pyanilist.Staff
::: pyanilist.StaffImage
::: pyanilist.StaffName
::: pyanilist.Studio
::: pyanilist.YearsActive
    options:
        members: true
