# Active Tasks
_Status: not started • Version: v0.1 • Date: <YYYY-MM-DD>_

> Produced per `.spec-dev/Tasks.md`. Capture the task board, then pause for review.

## Plan Snapshot
- **Key Modules/Areas:** <list from active-plan>
- **Feature Flags / Milestones:** <if applicable>

## Backlog
<!-- Append new task cards here using the strict format. Include `**Status:** pending` below the header. -->

## In Progress
<!-- Update status with `spec-dev tasks-status T-### --set in-progress`. -->

## Done
<!-- Update status with `spec-dev tasks-status T-### --set done`. -->

Gate: FAIL (set to READY FOR IMPLEMENTATION when the board is complete)
