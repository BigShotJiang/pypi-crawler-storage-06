# python environment

```bash
# For windows, if no permission to run scripts
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

## Install talib for windows
https://github.com/cgohlke/talib-build/releases

## Activate python virtual env
```bash
poetry shell
poetry update
```

# Test

```bash
pytest # Under repo root
```
# Build

```bash
# install tbump
https://github.com/your-tools/tbump

# bump version
tbump 0.1.110
```

# Encrypt confidential string for vault

In windows, use Git Bash

```bash
echo "hello world" | openssl pkeyutl -encrypt -pubin -inkey ~/.ssh/id_rsa_pub.pem|base64 -w0
```

# Use Ansible to setup server for rust compilation

1. Go to the ansible directory `cd /mnt/d/sk/omega-quote-center/ansible`
2. Run ansible scripts one by one 
   ```bash
   ansible-playbook --user root -vv 10_create_user.yml
   ansible-playbook --user root -vv 20_install_packages.yml
   ...
   ansible-playbook --user root -vv 40_restore_key.yml --ask-vault-pass
   ...
   ```
3. Cargo mirror, Create `~/.cargo/config`
   ```
   [source.crates-io]
   registry = "https://github.com/rust-lang/crates.io-index"
   # specify the mirror source
   replace-with = 'tuna'

   [source.tuna]
   registry = "https://mirrors.tuna.tsinghua.edu.cn/git/crates.io-index.git"
   ```