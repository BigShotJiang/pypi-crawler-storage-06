#!/usr/bin/env python3
import pika
import argparse
import logging
from datetime import date, timedelta, datetime
import time
import random

# from market_calendar import Calendar
from oqclib.config import Config


logger = logging.getLogger(__name__)


def equal_dicts(d1, d2, ignore_keys):
    ignored = set(ignore_keys)
    for k1, v1 in d1.items():
        if k1 not in ignored and (k1 not in d2 or d2[k1] != v1):
            return False
    for k2, v2 in d2.items():
        if k2 not in ignored and k2 not in d1:
            return False
    return True

class QuoteSubscriber:
    def __init__(self, config_file, args):  # Add args parameter
        config = Config(config_file)
        today = date.today()
        # self.market_calendar = Calendar(config, today - timedelta(days=1), today)
        self.args = args  # Store args

        self.config = config.data
        
        self.quoteExchange = self.config['amqpStructure']['exchanges']['request']['name']
        self.credentials = pika.PlainCredentials(self.config['amqpServer']['user'], self.config['amqpServer']['password'])
        self.connectionParams = pika.ConnectionParameters(
            self.config['amqpServer']['host'], self.config['amqpServer']['port'], self.config['amqpServer']['vhost'], self.credentials)
        
    @staticmethod
    def get_contract_time_of_next_n_month(year, month, n):
        month += n
        while month > 12:
            month -= 12
            year += 1
        return str(year % 100)+"%02d" % month
    
    def is_trading_day(self, d: datetime.date):
        is_trading_day = self.market_calendar.is_trading_day(d)
        return is_trading_day

    def get_instruments_to_subscribe(self):
        products = ["IC", "IH", "IF", "IM"]
        insts = set()
        d = date.today()
        monthes = []
        year, month = d.year, d.month
        monthes.append(d.strftime("%y%m"))
        monthes.append(self.get_contract_time_of_next_n_month(year, month, 1))
        for m in [3, 6, 9]:
            t = m - month % 3
            monthes.append(self.get_contract_time_of_next_n_month(year, month, t))
        for c in products:
            for ct in monthes:
                insts.add(c+ct)

        monthes.clear()
        for m in [2, 4, 6]:
            t = m - month % 2
            monthes.append(self.get_contract_time_of_next_n_month(year, month, t))
        for ct in monthes:
            insts.add("ec"+ct)

        return list(insts)

    def run(self):
        # if not self.is_trading_day(date.today()):
        #     logger.info("Today is not trading day." )
        #     return
        insts = self.get_instruments_to_subscribe()
        logger.info(f"Get insts {insts} to subscribe")
        self.connection = pika.BlockingConnection(self.connectionParams)
        self.channel = self.connection.channel()
        
        self.channel.basic_publish("request", "sub.future.domestic", ','.join(insts).encode("utf-8"))
        logger.info("Done subscribing futures %s" % ', '.join(insts))

        if not self.args.no_sleep:
            sleep_duration = random.randint(0, 180)
            logger.info("Sleeping {} seconds".format(sleep_duration))
            time.sleep(sleep_duration)
        spot_symbols = 'sh000300,sh000905,sh000016,sh000852'
        self.channel.basic_publish("request", "sub.stock.domestic", spot_symbols.encode("utf-8"))
        logger.info("Done subscribing spot symbols %s" % spot_symbols)


def setup_logger():
    logging_format = ('%(levelname) -10s %(asctime)s - %(funcName) '
        '-8s %(lineno) -5d: %(message)s')

    sh = logging.StreamHandler()
    sh.setLevel(logging.INFO)
    sh.setFormatter(logging.Formatter(logging_format))
    logger.addHandler(sh)
    logger.setLevel(logging.INFO)


if __name__ == '__main__':
    setup_logger()
    current_time = int(time.time() * 1000)
    random.seed(current_time)

    parser = argparse.ArgumentParser(description='Quote Center Subscriber.')
    parser.add_argument('-c', '--config', type=str, metavar="ConfigFile.toml", default="/etc/oqc/config2.toml",
        help='Specify the configuration file.')
    parser.add_argument('--no-sleep', action='store_true', help='Skip random sleep between subscriptions')

    args = parser.parse_args()

    logger.info("Run with conf {}".format(args.config))
    ah = QuoteSubscriber(args.config, args)  # Pass args to constructor
    ah.run()
