#!/usr/bin/env python3
import asyncio
import argparse
import logging
import time
import random
from datetime import datetime, date, timedelta

import aiohttp
import pandas as pd
from sqlalchemy import create_engine, text

from oqclib.config import Config
from oqclib.constants import HTTP_USER_AGENT, HTTP_ACCEPT_LANGUAGE

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)


def valid_date(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        msg = "Not a valid date: '{0}'".format(s)
        raise argparse.ArgumentTypeError(msg)


class MoneyFlowPersister:
    # Class constants
    API_ORIGIN = 'https://vip.stock.finance.sina.com.cn/moneyflow'
    API_REFERER = API_ORIGIN + '/'
    API_ACCEPT = 'application/json, text/plain, */*'
    API_URL = 'https://stock.sina.com.cn/stock/api/jsonp.php/var%20_sh0000012025=/TouziService.getHistoryMinuteFlow?symbol=sh000001&random='
    
    def __init__(self, config):
        self.config = config
        self.db_config_name = "MarketData"
        connection_string = self.config.get_mysql_string(self.db_config_name)
        self.engine = create_engine(connection_string)
        
    def ensure_table_exists(self):
        """Ensure the moneyflow_sina table exists in the database"""
        with self.engine.connect() as conn:
            create_table_sql = text("""
                CREATE TABLE IF NOT EXISTS moneyflow_sina (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    date DATE NOT NULL,
                    time TIME NOT NULL,
                    flow DECIMAL(18,2) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_time (date, time)
                )
            """)
            conn.execute(create_table_sql)
            conn.commit()
    
    async def fetch_money_flow_data(self):
        """Fetch money flow data from Sina Finance API"""
        headers = {
            'Accept': self.API_ACCEPT,
            'Accept-Language': HTTP_ACCEPT_LANGUAGE,
            'Origin': self.API_ORIGIN,
            'Referer': self.API_REFERER,
            'User-Agent': HTTP_USER_AGENT
        }
        
        try:
            # Add random number to URL to prevent caching
            url = f"{self.API_URL}{int(time.time() * 1000)}"
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, ssl=False) as response:
                    if response.status != 200:
                        logger.error(f"API request failed with status: {response.status}")
                        return []
                    
                    text = await response.text()
                    # Remove JS comments and get the data part
                    text = text.split('*/')[1].strip()  # Remove everything before and including */
                    data_str = text.split('=')[1].strip('()";\n')
                    
                    # Parse the data
                    lines = data_str.split('R')
                    parts = lines[-1].split('|')
                    date_str = parts[0]
                    time_flow_pairs = []
                    
                    for part in parts[1:]:
                        values = part.split(',')
                        if len(values) >= 2:
                            time_str = values[0]
                            flow = float(values[1])  # Use the second value as flow
                            time_flow_pairs.append((time_str, flow))
                    
                    # Convert date_str to date object and process time-flow pairs
                    data_date = datetime.strptime(date_str, '%Y-%m-%d').date()
                    result = [
                        {
                            'date': data_date,
                            'time': datetime.strptime(t.replace(':', ''), '%H%M').time(),
                            'flow': f
                        }
                        for t, f in time_flow_pairs
                    ]
                    
                    return result
        except Exception as e:
            logger.error(f"Error fetching money flow data: {e}")
            return []
    
    async def save_to_database(self, data):
        """Save money flow data to the database"""
        if not data:
            logger.info("No data to save")
            return
        
        self.ensure_table_exists()
        
        insert_sql = text("""
            INSERT IGNORE INTO moneyflow_sina (date, time, flow)
            VALUES (:date, :time, :flow)
        """)
        
        inserted_count = 0
        with self.engine.connect() as conn:
            for record in data:
                result = conn.execute(insert_sql, {
                    'date': record['date'],
                    'time': record['time'],
                    'flow': record['flow']
                })
                inserted_count += result.rowcount
            
            conn.commit()
            logger.info(f"Successfully inserted/updated {inserted_count} records")
    
    async def fetch_and_save(self):
        """Fetch money flow data and save it to the database"""
        logger.info("Starting to fetch money flow data")
        data = await self.fetch_money_flow_data()
        if data:
            logger.info(f"Fetched {len(data)} money flow records")
            await self.save_to_database(data)
        else:
            logger.warning("No money flow data fetched")
    
    async def run_periodically(self, interval=60):
        """Run the fetch and save process periodically"""
        while True:
            try:
                await self.fetch_and_save()
                # Sleep for the specified interval with some randomness
                sleep_time = random.uniform(interval * 0.9, interval * 1.1)
                logger.info(f"Next fetch in {sleep_time:.1f} seconds")
                await asyncio.sleep(sleep_time)
            except Exception as e:
                logger.error(f"Error in periodic task: {e}")
                # Wait a bit before retrying
                await asyncio.sleep(30)


def persist_money_flow(args):
    config = Config(args.config)
    persister = MoneyFlowPersister(config)
    
    asyncio.run(persister.fetch_and_save())

def main():
    parser = argparse.ArgumentParser(description="Fetch and persist money flow data from Sina Finance")
    parser.add_argument('-c', '--config', type=str, default="/etc/oqc/config2.toml",
                        help='Specify the configuration file')
    
    args = parser.parse_args()
    persist_money_flow(args)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Exiting gracefully")
        sys.exit(0)