import sys
import os
import time
from datetime import datetime, timedelta

import asyncio
import argparse
import logging
import tweepy

from oqclib.config import Config
from oqclib.robot.lark import LarkMsg

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)

class TwitterUserSignal:
    def __init__(self, args, config):
        self.args = args
        self.robot = LarkMsg(config['lark']['robot'])
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self.last_tweet_id = None
        self.client = None
        self.setup_twitter_client(config)

    def setup_twitter_client(self, config):
        try:
            if 'twitter' not in config or 'bearer_token' not in config['twitter']:
                logger.error("Twitter bearer token not found in config")
                sys.exit(1)
            # Authenticate with Twitter API
            auth = tweepy.OAuth1UserHandler(
                config['twitter']['api_key'], config['twitter']['api_key_secret'], config['twitter']['access_token'], config['twitter']['access_token_secret']
            )
            self.api = tweepy.API(auth)

            bearer_token = config['twitter']['bearer_token']
            if not bearer_token:
                logger.error("Twitter bearer token is empty")
                sys.exit(1)

            self.client = tweepy.Client(
                bearer_token=bearer_token,
                wait_on_rate_limit=True
            )
            
            # Test the client with a simple API call
            # self.api.get_user(id=self.args.user_id)
            logger.info("Twitter client initialized")
            
        except tweepy.errors.Unauthorized:
            logger.error("Twitter API authentication failed: Invalid bearer token")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Failed to initialize Twitter client: {e}")
            sys.exit(1)

    def fetch_user_timeline(self, username, count=10):
        try:
            # Fetch tweets from the user's timeline
            tweets = self.api.user_timeline(screen_name=username, count=count, tweet_mode="extended")

            # Print the tweets
            for tweet in tweets:
                print(f"Tweet ID: {tweet.id}")
                print(f"Created At: {tweet.created_at}")
                print(f"Text: {tweet.full_text}")
                print("-" * 60)
            return tweets

        except tweepy.errors.TweepyException as e:
            logger.error(f"An error occurred: {e}")
            return None

    async def periodic_task(self):
        while True:
            try:
                # tweets = self.fetch_user_timeline(self.args.user_id)
                tweets = self.client.get_users_tweets(
                    id=self.args.user_id,
                    tweet_fields=['created_at', 'public_metrics'],
                    max_results=5,
                    since_id=self.last_tweet_id
                )

                if tweets.data:
                    self.last_tweet_id = tweets.data[0].id
                    for tweet in reversed(tweets.data):
                        created_at = tweet.created_at.strftime('%Y-%m-%d %H:%M:%S')
                        metrics = tweet.public_metrics
                        msg = f"[{created_at}] {tweet.text}\nLikes: {metrics['like_count']} | RTs: {metrics['retweet_count']} | Replies: {metrics['reply_count']}"
                        self.robot.send_msg(self.args.robot_key, msg)
                        logger.info(f"Sent tweet notification: {tweet.id}")

            except Exception as e:
                logger.error(f"Error fetching tweets: {e}")

            await asyncio.sleep(self.args.interval)

    def test_decorator(self, message: str) -> str:
        return ('[TEST] ' if self.args.test else '') + message

    def start(self):
        asyncio.set_event_loop(self._ioloop)
        periodic = self._ioloop.create_task(self.periodic_task())

        try:
            self._ioloop.run_forever()
        finally:
            periodic.cancel()
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()

    def stop(self):
        if self._ioloop:
            self._ioloop.stop()


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Twitter User Monitor')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                          help='Specify the configuration toml file.')
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                          default='twitter')
        parser.add_argument('-u', '--user_id', type=str, required=True,
                          help='Twitter user ID to monitor')
        parser.add_argument('-i', '--interval', type=int, default=300,
                          help='Polling interval in seconds (default: 300)')
        parser.add_argument('-t', '--test', action='store_true', help='Test mode')

        args = parser.parse_args()
        config = Config(args.config)

        service = TwitterUserSignal(args, config.data)
        service.start()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        service.stop()
        sys.exit(0)