import sys
import random
from datetime import date, timedelta

import asyncio
import argparse
import logging

from oqclib.config import Config
from oqclib.robot.lark import LarkMsg
from oqclib.constants import HTTP_USER_AGENT, HTTP_ACCEPT_LANGUAGE

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)


class MoneyFlowSignal:
    # Class constants
    API_URL = 'http://43.143.226.164:16264/aaa1122334455'
    API_ORIGIN = 'http://123.56.42.10:16137'
    API_REFERER = API_ORIGIN + '/'
    API_ACCEPT = 'application/json, text/plain, */*'

    def __init__(self, args, config):
        self.args = args
        self.robot = LarkMsg(config['lark']['robot'])
        self.first_positive_flow_notified = False
        self._ioloop:asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self.last_recovery_alert_time = None  # Add this line
        self.recovery_alert_cooldown = timedelta(minutes=15)  # Add this line - 5 minutes cooldown

    async def mock_data(self, current_time):
        logger.info(f"Generating mock data for {current_time}")
        # Mock data for testing
        base_flow = -1000000  # Start with negative flow
        if current_time.strftime('%H:%M') > '10:30':
            base_flow = 500000  # Turn positive after 10:30
        
        # Generate test data points for the last 30 minutes
        x_data = []
        y_data = []
        for i in range(30):
            test_time = current_time - timedelta(minutes=29-i)
            # Remove market hours check for testing
            x_data.append(test_time.strftime('%H%M'))
            # Add some random variation to the flow
            flow = base_flow + random.uniform(-500000, 500000)
            if i == 29:  # Last point (current)
                flow = base_flow + 2000000  # Simulate a significant recovery
            y_data.append(str(flow))
        
        logger.info(f"Generated {len(x_data)} data points")
        return {'p8': {'x': x_data, 'y': y_data}}

    async def periodic_task(self):
        import aiohttp
        from datetime import datetime, date, timedelta
        
        headers = {
            'Accept': self.API_ACCEPT,
            'Accept-Language': HTTP_ACCEPT_LANGUAGE,
            'Origin': self.API_ORIGIN,
            'Referer': self.API_REFERER,
            'User-Agent': HTTP_USER_AGENT
        }
        
        while True:
            next_sleep = random.uniform(5, 20)  # Move this here to ensure it's always defined
            try:
                if self.args.test:
                    # Use mock data in test mode
                    current_time = datetime.now()
                    data = await self.mock_data(current_time)
                else:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(self.API_URL, headers=headers, ssl=False) as response:
                            if response.status == 200:
                                data = await response.json()

                if 'p8' in data:
                    p8_data = data['p8']
                    today = date.today()

                    # Process time-flow pairs
                    time_flow_pairs = [
                        (datetime.combine(today, datetime.strptime(t, '%H%M').time()), float(y))
                        for t, y in zip(p8_data['x'], p8_data['y'])
                    ]

                    if time_flow_pairs:
                        current_time = time_flow_pairs[-1][0]
                        current_flow = time_flow_pairs[-1][1]
                        now = datetime.now()
                        now_str = now.strftime('%H:%M')

                        # Skip if current time is before 10:00 and latest data is after 14:30 (previous day's data)
                        if now_str < '10:00' and current_time.strftime('%H:%M') > '14:30':
                            logger.info("Skipping previous day's data")
                            await asyncio.sleep(next_sleep)
                            continue

                        if '11:30' < now_str < '13:00':
                            await asyncio.sleep(next_sleep)
                            continue

                        # Find lowest flow and its time in the recent window
                        cutoff_time = current_time - timedelta(minutes=self.args.recent_minutes)
                        recent_pairs = [(t, f) for t, f in time_flow_pairs if t > cutoff_time]

                        if recent_pairs:
                            min_time, min_flow = min(recent_pairs, key=lambda x: x[1])
                            next_sleep = random.uniform(5, 20)
                            logger.info(f"Current flow at {current_time.strftime('%H:%M:%S')}: {current_flow/1000000:,.2f}m, "
                                      f"Lowest flow {min_time.strftime('%H:%M:%S')}: {min_flow/1000000:,.2f}m, "
                                      f"Next update in {next_sleep:.1f}s")

                        # Check first positive flow of the day
                        if not self.first_positive_flow_notified and current_flow > 0:
                            msg = f"{current_flow / 1000000:,.2f}m Positive flow of the day! "
                            self.robot.send_msg(self.args.robot_key, msg)
                            logger.info(f"Sent robot message: {msg}")
                            self.first_positive_flow_notified = True

                        # Check for significant recovery from recent low
                        if recent_pairs:
                            recent_min = min(flow for _, flow in recent_pairs)
                            if current_flow - recent_min > self.args.flow_threshold * 1e6:  # Convert to millions
                                if (self.last_recovery_alert_time is None or
                                        now - self.last_recovery_alert_time > self.recovery_alert_cooldown):
                                    msg = f"InFlow {current_flow / 1000000:,.2f}m Up {(current_flow - recent_min) / 1000000:,.2f}m from recent low {recent_min / 1000000:,.2f}m"
                                    self.robot.send_msg(self.args.robot_key, msg)
                                    logger.info(f"Sent robot message: {msg}")
                                    self.last_recovery_alert_time = now
                                else:
                                    logger.info("Skipping recovery alert due to cooldown")
                                
            except Exception as e:
                logger.error(f"Error making API request: {e}")
            
            await asyncio.sleep(next_sleep)

    def test_decorator(self, message: str) -> str:
        return ("[TEST] " if self.args.test else "") + message

    def start(self):
        asyncio.set_event_loop(self._ioloop)
        periodic = self._ioloop.create_task(self.periodic_task())

        try:
            self._ioloop.run_forever()
        finally:
            periodic.cancel()
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()

    def stop(self):
        if self._ioloop:
            self._ioloop.stop()
            
if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Quote Center Forwarder.')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                            help='Specify the configuration toml file.')
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                            default='ashare')

        parser.add_argument('-t', '--test', action='store_true', help='Test mode')
        parser.add_argument('--recent_minutes', type=int, default=10,
                          help='Number of minutes to look back for money flow analysis')
        parser.add_argument('-f', '--flow_threshold', type=float, default=100,
                          help='Money flow threshold in millions for recovery alert. Default 100')

        args = parser.parse_args()
        config = Config(args.config)

        service = MoneyFlowSignal(args, config.data)
        service.start()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        service.stop()  # Add this line to properly stop the service
        sys.exit(0)
