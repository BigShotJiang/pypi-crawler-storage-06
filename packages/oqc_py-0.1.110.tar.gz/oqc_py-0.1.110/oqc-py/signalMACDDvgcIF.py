import math
import sys
import time
from datetime import date

import pika
from pika.adapters.asyncio_connection import AsyncioConnection
import asyncio
import argparse
import json
import logging
import socket
import functools
from oqclib.config import Config
from oqclib.robot.lark import LarkMsg
from oqclib.utils.future_symbol_util import get_future_symbol_root, get_contract_time_of_next_n_month
from oqclib.utils.datetime_util import are_in_same_bar, get_bar_time_ms

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)


def get_symbol_from_routing_key(routing_key:str) -> str:
    return routing_key.split('.')[-1]


def get_future_symbols(spot: str) -> set:
    d = date.today()
    symbols = set()
    months = []
    months.append(d.strftime("%y%m"))
    months.append(get_contract_time_of_next_n_month(d.year, d.month, 1))
    future_root = get_future_symbol_root(spot)
    if future_root:
        for month in months:
            symbols.add(future_root + month)
    return symbols


def uptime_acceptable(update_time: str) -> bool:
    # update_time is in this format 13:30:23
    if "09:30:00" <= update_time <= "11:30:00":
        return True
    if "13:00:00" <= update_time <= "15:00:00":
        return True
    return False


class MACDDivergenceSignal:
    def __init__(self, args, config):
        self.args = args
        self.symbols = set(args.spot_symbols)
        self.requestExchange = config['amqpStructure']['exchanges']['request']['name']
        self.quoteExchange = config['amqpStructure']['exchanges']['quote']['name']
        self.listenQueueName = "MACDDvgcStock-%s" % socket.gethostname()
        self.credentials = pika.PlainCredentials(
            config['amqpServer']['user'], config['amqpServer']['password'])
        self.connectionParams = pika.ConnectionParameters(
            config['amqpServer']['host'], config['amqpServer']['port'], config['amqpServer']['vhost'], self.credentials)

        self.received_msgs = 0
        self.all_candle_sticks = {}
        self.last_quote = {}
        self.robot = LarkMsg(config['lark']['robot'])

        # Copied from https://github.com/pika/pika/blob/10cbe33a1ab36f6da984fc2f5eb1ebdd83eced27/examples/asyncio_consumer_example.py
        self.should_reconnect = False
        self.was_consuming = False

        self._connection = None
        self._channel = None
        self._closing = False
        self._consumer_tag = None
        self._consuming = False
        self._qos_set = False
        # In production, experiment with higher prefetch values
        # for higher consumer throughput
        self._prefetch_count = 1
        self._ioloop:asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self._message_throttle_count = 300

    def on_ampq_quote(self, ch, method, properties, body):
        symbol = get_symbol_from_routing_key(method.routing_key)
        if self.received_msgs % self._message_throttle_count == 0:
            quote = json.loads(body)
            logger.info("Rcvd {} AMQP msgs, last {} {}".format(self.received_msgs, symbol, quote))
        self.received_msgs += 1

        if symbol not in self.symbols:
            return

        # logger.info(f"Got ticker {body}")

        quote = json.loads(body)

        if not uptime_acceptable(quote['uptime']):
            return

        self.last_quote[symbol] = quote

        if symbol in self.args.spot_symbols:
            if symbol not in self.all_candle_sticks:
                periods_dict = {}
                for period in self.args.periods:
                    periods_dict[period] = []
                self.all_candle_sticks[symbol] = periods_dict

            periods_dict = self.all_candle_sticks[symbol]
            price = quote['last']
            for period, candles in periods_dict.items():
                bar_time_ms = get_bar_time_ms(period * 60000, quote['timeMs'])
                if not candles:
                    candles.append([bar_time_ms, price, price, price, price, 0])
                else:
                    last_candle = candles[-1]
                    if are_in_same_bar(period * 60, last_candle[0], quote['timeMs']):
                        last_candle[4] = price
                    else:
                        local_time = time.localtime(last_candle[0] / 1000)
                        readable_time = time.strftime("%H:%M:%S", local_time)
                        # logger.info(f"Closing stick {symbol}@{period}m {readable_time} Px {last_candle[4]}")
                        candles.append([bar_time_ms, price, price, price, price, 0])
                        if len(candles) > 3:
                            df = self.detect(symbol, period, candles)
                            logger.info(f"Closing stick {symbol}@{period}m {readable_time} Px {df.iloc[-1]['close']:.2f} "
                                      f"MACD dif/dea {df.iloc[-1]['dif']:.2f}/{df.iloc[-1]['dea']:.2f}")
                        else:
                            logger.info(f"Closing stick {symbol}@{period}m {readable_time} Px {last_candle[4]}")

    def detect(self, symbol: str, period: int, candle_sticks, fast_period=12, slow_period=26, signal_period=9):
        from oqclib.indicators.macd_dvgc import detect_macd_divergence, is_death_cross, is_golden_cross, populate_macd_fields
        from oqclib.indicators.model import DivergenceType
        import pandas as pd

        # Convert to DataFrame
        df = pd.DataFrame(candle_sticks, columns=['timeMs', 'open', 'high', 'low', 'close', 'volume'])
        df['open'] = df['open'].astype(float)
        df['high'] = df['high'].astype(float)
        df['low'] = df['low'].astype(float)
        df['close'] = df['close'].astype(float)
        df['timeMs'] = pd.to_datetime(df['timeMs'].astype('Int64'), unit='ms')
        df.drop(columns=['volume'], inplace=True)
        df.set_index('timeMs', inplace=True)

        populate_macd_fields(df, fast_period, slow_period, signal_period)

        # df.to_csv(f"macd_{symbol}_{period}__{df.index[-1].strftime('%Y-%m-%d_%H-%M-%S')}.csv")
        dvgc = detect_macd_divergence(df, nth=1)
        last_px = df.iloc[-1]['close']
        if dvgc:
            logger.info(f"MACD Divergence Signal for {symbol} {period}m len {len(df)} dvgc {dvgc} LastPx {last_px}")

        ref_future_symbol = None
        fut_symbols = get_future_symbols(symbol)
        for fut_symbol in fut_symbols:
            if fut_symbol in self.last_quote:
                if not ref_future_symbol or ref_future_symbol > fut_symbol:
                    ref_future_symbol = fut_symbol
        ref_future_quote = self.last_quote[ref_future_symbol] if ref_future_symbol else {}
        ref_bid = ref_future_quote['bidPrice1'] if ref_future_quote else math.nan
        ref_ask = ref_future_quote['askPrice1'] if ref_future_quote else math.nan

        if dvgc == DivergenceType.BEARISH:
            self.robot.send_msg(self.args.robot_key, self.test_decorator(f"{symbol} {period}m 顶背离 LastPx {last_px} Fut {ref_future_symbol} bid/ask {ref_bid} {ref_ask}"))
        elif dvgc == DivergenceType.BULLISH:
            self.robot.send_msg(self.args.robot_key, self.test_decorator(f"{symbol} {period}m 底背离 LastPx {last_px} Fut {ref_future_symbol} bid/ask {ref_bid} {ref_ask}"))
        elif True:
            cross = is_death_cross(df, nth=1)
            if cross:
                logger.info(f"{symbol} {period}m Death Cross {df.tail(5)[['close', 'dif', 'dea']]}")
                if self.args.cross_alert:
                    self.robot.send_msg(self.args.robot_key, self.test_decorator(f"{symbol} {period}m Death Cross. LastPx {last_px} Fut {ref_future_symbol} bid/ask {ref_bid} {ref_ask}"))
            cross = is_golden_cross(df, nth=1)
            if cross:
                logger.info(f"{symbol} {period}m Golden Cross {df.tail(5)[['close', 'dif', 'dea']]}")
                if self.args.cross_alert:
                    self.robot.send_msg(self.args.robot_key, self.test_decorator(f"{symbol} {period}m Golden Cross. LastPx {last_px} Fut {ref_future_symbol} bid/ask {ref_bid} {ref_ask}"))

        if self.args.draw:
            import mplfinance as mpf
            apds = [mpf.make_addplot(df['dif'], panel=1, color='fuchsia', title="MACD", linewidths=1),
                    mpf.make_addplot(df['dea'], panel=1, color='b', linewidths=1)]

            mpf.plot(df, type='candle', style='charles', title='Candlestick Chart with MACD', ylabel='Price',
                     addplot=apds,
                     savefig={
                         'fname': f"{symbol}_{period}_macd.png",
                         'dpi': 300,  # Resolution of the figure
                         'bbox_inches': 'tight'  # Optional parameter to fit the layout tightly
                     })
        return df

    def test_decorator(self, message: str) -> str:
        return ("[TEST] " if self.args.test else "") + message

    def connect(self):
        logger.info('Connecting to %s', self.connectionParams)
        return AsyncioConnection(
            parameters=self.connectionParams,
            on_open_callback=self.on_connection_open,
            on_open_error_callback=self.on_connection_open_error,
            on_close_callback=self.on_connection_closed,
            custom_ioloop=self._ioloop)

    def open_channel(self):
        logger.info('Creating a new channel')
        self._connection.channel(on_open_callback=self.on_channel_open)

    def on_channel_open(self, channel):
        logger.info('Channel opened')
        self._channel:pika.channel.Channel = channel
        self.add_on_channel_close_callback()
        self.setup_queue(self.listenQueueName)

    def add_on_channel_close_callback(self):
        logger.info('Adding channel close callback')
        self._channel.add_on_close_callback(self.on_channel_closed)

    def on_channel_closed(self, channel, reason):
        logger.warning('Channel %i was closed: %s', channel, reason)
        self.close_connection()

    def setup_queue(self, queue_name):
        logger.info('Declaring queue %s', queue_name)
        cb = functools.partial(self.on_queue_declare_ok, userdata=queue_name)
        self._channel.queue_declare(queue=queue_name, callback=cb, durable=True, auto_delete=True)

    def on_queue_declare_ok(self, _unused_frame, userdata):
        queue_name = userdata
        logger.info('Binding %s to %s ', self.quoteExchange, queue_name)
        cb = functools.partial(self.on_bind_ok, userdata=queue_name)

        for spot in self.args.spot_symbols:
            self._channel.queue_bind(
                exchange=self.quoteExchange, queue=queue_name, routing_key="quote.stock.domestic." + spot, callback=cb)
            fut_symbols = get_future_symbols(spot)
            for fut_symbol in fut_symbols:
                self._channel.queue_bind(
                    exchange=self.quoteExchange, queue=queue_name, routing_key="quote.future.domestic." + fut_symbol, callback=cb)
            self.symbols.update(fut_symbols)
            logger.info(f"Subscribing to {spot} and {fut_symbols}")

    def on_bind_ok(self, _unused_frame, userdata):
        logger.info('Queue bound: %s', userdata)
        if not self._qos_set:
            self.set_qos()
            self._qos_set = True

    def set_qos(self):
        self._channel.basic_qos(
            prefetch_count=self._prefetch_count, callback=self.on_basic_qos_ok)

    def on_basic_qos_ok(self, _unused_frame):
        logger.info('QOS set to: %d', self._prefetch_count)
        self.start_consuming()

    def start_consuming(self):
        logger.info('Issuing consumer related RPC commands')
        self.add_on_cancel_callback()
        self._channel.basic_consume(queue=self.listenQueueName, on_message_callback=self.on_ampq_quote, auto_ack=True)

        # self._consumer_tag = self._channel.basic_consume(
        #     self.QUEUE, self.on_message)
        self.was_consuming = True
        self._consuming = True

    def add_on_cancel_callback(self):
        logger.info('Adding consumer cancellation callback')
        self._channel.add_on_cancel_callback(self.on_consumer_cancelled)

    def on_consumer_cancelled(self, method_frame):
        logger.info('Consumer was cancelled remotely, shutting down: %r',
                    method_frame)
        if self._channel:
            self._channel.close()

    def close_connection(self):
        self._consuming = False
        if self._connection.is_closing or self._connection.is_closed:
            logger.info('Connection is closing or already closed')
        else:
            logger.info('Closing connection')
            self._connection.close()

    def on_connection_open(self, _unused_connection):
        logger.info('Connection opened')
        self.open_channel()

    def on_connection_open_error(self, _unused_connection, err):
        logger.error('Connection open failed: %s', err)
        self.reconnect()

    def on_connection_closed(self, _unused_connection, reason):
        self._channel = None
        if self._closing:
            self._connection.ioloop.stop()
        else:
            logger.warning('Connection closed, reconnect necessary: %s', reason)
            self.reconnect()

    def on_message(self, _unused_channel, basic_deliver, properties, body):
        logger.info('Received message # %s from %s: %s',
                    basic_deliver.delivery_tag, properties.app_id, body)
        self.acknowledge_message(basic_deliver.delivery_tag)

    def acknowledge_message(self, delivery_tag):
        logger.info('Acknowledging message %s', delivery_tag)
        self._channel.basic_ack(delivery_tag)

    def stop_consuming(self):
        if self._channel:
            logger.info('Sending a Basic.Cancel RPC command to RabbitMQ')
            cb = functools.partial(
                self.on_cancelok, userdata=self._consumer_tag)
            self._channel.basic_cancel(self._consumer_tag, cb)

    def on_cancelok(self, _unused_frame, userdata):
        self._consuming = False
        logger.info(
            'RabbitMQ acknowledged the cancellation of the consumer: %s',
            userdata)
        self.close_channel()

    def close_channel(self):
        logger.info('Closing the channel')
        self._channel.close()

    def run_amqp_subscriber(self):
        self._connection = self.connect()

    def stop(self):
        if not self._closing:
            self._closing = True
            logger.info('Stop consuming AMQP')
            if self._consuming:
                self.stop_consuming()
                self._ioloop.run_forever()
            else:
                self._ioloop.stop()
            logger.info('Stopped consuming AMQP')

    def reconnect(self):
        self.should_reconnect = True
        self.stop()

    def start(self):
        self.run_amqp_subscriber()
        asyncio.set_event_loop(self._ioloop)

        try:
            self._ioloop.run_forever()
        finally:
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Quote Center Forwarder.')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                            help='Specify the configuration toml file.')
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                            default='ashare')

        parser.add_argument('-s', '--spot_symbols', nargs='+', help='symbols to watch', default=["sh000300", "sh000905"])
        parser.add_argument('-p', '--periods', nargs='+', help='periods in minutes to watch', type=int,
                            default=[1])
        parser.add_argument('-t', '--test', action='store_true', help='Test mode')
        parser.add_argument('-x', '--cross_alert', action='store_true', help='Send alert for crosses')
        parser.add_argument('--draw', action='store_true', help='Output the candlestick chart')


        args = parser.parse_args()
        config = Config(args.config)

        service = MACDDivergenceSignal(args, config.data)

        service.start()
        # asyncio.run(service.start())
        #asyncio.get_event_loop().run_forever()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        sys.exit(0)
