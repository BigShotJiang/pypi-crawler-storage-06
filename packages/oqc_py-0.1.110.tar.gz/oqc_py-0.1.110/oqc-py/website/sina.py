import aiohttp
import asyncio
import datetime
from typing import Dict, Any
from oqclib.constants import HTTP_USER_AGENT

SYMBOL_FOR_TRADING_DAY = 'nf_AU0_i'

async def is_today_trading_day() -> bool:
    """
    Check if today is a trading day in Sina futures market
    """
    today = datetime.date.today()
    quotes = await get_futures_quotes([SYMBOL_FOR_TRADING_DAY]) 
    if quotes[SYMBOL_FOR_TRADING_DAY] is None:
        return True
    trading_day = datetime.datetime.strptime(quotes[SYMBOL_FOR_TRADING_DAY][1], '%Y-%m-%d').date()
    return trading_day == today

async def get_futures_quotes(symbols: list[str]) -> Dict[str, Any]:
    """
    Fetch futures quotes from Sina API asynchronously
    """
    url = "https://hq.sinajs.cn/list=" + ",".join(symbols)
    headers = {
        'Referer': 'https://finance.sina.com.cn',
        'User-Agent': HTTP_USER_AGENT
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers) as response:
            text = await response.text()
            
    result = {}
    for line in text.split('\n'):
        if not line:
            continue
        # Format: var hq_str_nf_AU0="AU0,price,..."
        symbol = line.split('=')[0].replace('var hq_str_', '').strip()
        data = line.split('=')[1].strip('";').split(',')
        if len(data) > 1:
            result[symbol] = data

    return result

async def get_quote():
    symbols = [SYMBOL_FOR_TRADING_DAY]
    result = await get_futures_quotes(symbols)
    print(result)

async def is_trading_day():
    print(await is_today_trading_day())

if __name__ == "__main__":
    asyncio.run(is_trading_day())