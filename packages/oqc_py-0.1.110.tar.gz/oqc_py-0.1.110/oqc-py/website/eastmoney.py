import aiohttp
import json
import re
import time

from pandas import Timestamp

from oqclib.constants import HTTP_USER_AGENT
import pandas as pd

HOST_URL = "push2his.eastmoney.com"

async def get_trading_date(limit=120) -> list[Timestamp]:
    df = await get_stock_klines("1.000300", limit=limit)
    return list(df.date)


async def get_stock_klines(secid: str, limit=120) -> pd.DataFrame:
    """
    Get stock klines data from EastMoney
    Args:
        secid: stock ID in format 'market_code.stock_code' (e.g., '1.000300' for HS300)
        limit: number of data points to retrieve
    """
    url = f"https://{HOST_URL}/api/qt/stock/kline/get"
    params = {
        "cb": "jQuery35106302273538953851_1741865531349",
        "secid": secid,
        "ut": "fa5fd1943c7b386f172d6893dbfba10b",
        "fields1": "f1,f2,f3,f4,f5,f6",
        "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
        "klt": "101",
        "fqt": "1",
        "end": "20500101",
        "lmt": limit,
        "_": str(int(time.time() * 1000)),
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, params=params, headers={'User-Agent': HTTP_USER_AGENT}) as response:
            text = await response.text()
    
    json_str = re.search(r'\{.*\}', text).group()
    data = json.loads(json_str)
    klines = data['data']['klines']
    stock_name = data['data']['name']
    
    df = pd.DataFrame([k.split(',') for k in klines], columns=[
        'date_txt', 'open', 'close', 'high', 'low', 'volume', 
        'amount', 'amplitude_pct', 'change_pct', 'change', 'turnover_pct'
    ])
    df['name'] = stock_name
    
    df['date'] = pd.to_datetime(df['date_txt'])
    numeric_columns = ['open', 'close', 'high', 'low', 'volume', 'amount', 
                      'amplitude_pct', 'change_pct', 'change', 'turnover_pct']
    df[numeric_columns] = df[numeric_columns].apply(pd.to_numeric)
    
    return df


if __name__ == "__main__":
    import asyncio
    data = asyncio.run(get_stock_klines("0.300573"))
    print(data)

