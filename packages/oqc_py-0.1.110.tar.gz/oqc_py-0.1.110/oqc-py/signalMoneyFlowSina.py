import sys
import time
import random
from datetime import date, timedelta

import asyncio
import argparse
import logging
import redis.asyncio as aioredis

from oqclib.config import Config
from oqclib.robot.lark import LarkMsg
from oqclib.constants import HTTP_USER_AGENT, HTTP_ACCEPT_LANGUAGE
from website.eastmoney import get_stock_klines

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)


class MoneyFlowSignal:
    # Class constants
    API_ORIGIN = 'https://vip.stock.finance.sina.com.cn/moneyflow'
    API_REFERER = API_ORIGIN + '/'
    API_ACCEPT = 'application/json, text/plain, */*'
    API_URL = 'https://stock.sina.com.cn/stock/api/jsonp.php/var%20_sh0000012025=/TouziService.getHistoryMinuteFlow?symbol=sh000001&random='

    def __init__(self, args, config):
        self.args = args
        self.robot = LarkMsg(config['lark']['robot'])
        self.first_positive_flow_notified = False
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self.last_inflow_alert_time = None
        self.last_outflow_alert_time = None
        self.leverage = 2.5
        self.alert_cooldown = timedelta(minutes=15)
        if 'redis' in config and 'signal' in config['redis']:
            redis_config = config['redis']['signal']
            self.redis_url = f"redis://:{redis_config['pwd']}@{redis_config['host']}:{redis_config['port']}/{redis_config['db']}"

    async def initialize_redis(self):
        if hasattr(self, 'redis_url'):
            self.redis = await aioredis.from_url(self.redis_url, decode_responses=True)

    async def load_config_from_redis(self):
        import json
        key = "p:ashare:config"
        try:
            json_str = await self.redis.get(key)
            if json_str:
                config = json.loads(json_str)
                return config  # Return the entire JSON object
        except Exception as e:
            logger.error(f"Error loading config from Redis: {e}")
        return {}

    async def load_market_data(self):
        klines = await get_stock_klines("1.000300", limit=100)
        df = klines

        self.index_close = df['close'].iloc[-1]

    async def periodic_task(self):
        import aiohttp
        from datetime import datetime, date, timedelta

        config = await self.load_config_from_redis()
        equity = config['equity']
        lots = (int)(equity * self.leverage / self.index_close / 300)

        logger.info(f"Equity {equity} IndexClose {self.index_close} Lots {lots}")

        headers = {
            'Accept': self.API_ACCEPT,
            'Accept-Language': HTTP_ACCEPT_LANGUAGE,
            'Origin': self.API_ORIGIN,
            'Referer': self.API_REFERER,
            'User-Agent': HTTP_USER_AGENT
        }

        while True:
            next_sleep = random.uniform(18, 29)
            try:
                # Add random number to URL to prevent caching
                url = f"{self.API_URL}{int(time.time() * 1000)}"
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, headers=headers, ssl=False) as response:
                        if response.status != 200:
                            await asyncio.sleep(next_sleep)
                            continue
                        text = await response.text()
                        # Remove JS comments and get the data part
                        text = text.split('*/')[1].strip()  # Remove everything before and including */
                        data_str = text.split('=')[1].strip('()";\n')
                        # Parse the data
                        lines = data_str.split('R')
                        parts = lines[-1].split('|')
                        date_str = parts[0]
                        time_flow_pairs = []

                        for part in parts[1:]:
                            values = part.split(',')
                            if len(values) >= 2:
                                time_str = values[0]
                                flow = float(values[1])  # Use the second value as flow
                                time_flow_pairs.append((time_str, flow))

                        # Convert date_str to date object and process time-flow pairs
                        data_date = datetime.strptime(date_str, '%Y-%m-%d').date()
                        time_flow_pairs = [
                            (datetime.combine(data_date, datetime.strptime(t.replace(':', ''), '%H%M').time()), f)
                            for t, f in time_flow_pairs
                        ]

                        if time_flow_pairs:
                            current_time = time_flow_pairs[-1][0]
                            current_flow = time_flow_pairs[-1][1]
                        now = datetime.now()
                        now_str = now.strftime('%H:%M')

                        # Skip if current time is before 10:00 and latest data is after 14:30 (previous day's data)
                        if now_str < '10:00' and current_time.strftime('%H:%M') > '14:30':
                            logger.info("Skipping previous day's data")
                            await asyncio.sleep(next_sleep)
                            continue

                        if '11:30' < now_str < '13:00':
                            await asyncio.sleep(next_sleep)
                            continue

                        cutoff_time = current_time - timedelta(minutes=self.args.in_flow_window_size)
                        recent_pairs = [(t, f) for t, f in time_flow_pairs if t > cutoff_time]

                        if recent_pairs:
                            min_time, min_flow = min(recent_pairs, key=lambda x: x[1])
                            logger.info(
                                f"Current flow at {current_time.strftime('%H:%M:%S')}: {current_flow / 1000000:,.2f}m, "
                                f"Lowest flow {min_time.strftime('%H:%M:%S')}: {min_flow / 1000000:,.2f}m, "
                                f"Next update in {next_sleep:.1f}s")

                            recent_min = min(flow for _, flow in recent_pairs)
                            if current_flow - recent_min > self.args.in_flow_threshold * 1e6:  # Convert to millions
                                if (self.last_inflow_alert_time is None or
                                        now - self.last_inflow_alert_time > self.alert_cooldown):
                                    msg = f"InFlow: **{current_flow / 1000000:,.2f}m**\n" \
                                        f"Up: **{(current_flow - recent_min) / 1000000:,.2f}m** from recent low\n" \
                                        f"Recent Low: **{recent_min / 1000000:,.2f}m**\n" \
                                        f"https://vip.stock.finance.sina.com.cn/moneyflow/\n" \
                                        f"Lots: {lots}\n" \
                                        f"{now_str}"
                                    card_body = {
                                        "header": {
                                            "template": "green",
                                            "title": {
                                                "tag": "plain_text",
                                                "content": self.test_decorator("💰 InFlow Alert")
                                            }
                                        },
                                        "elements": [
                                            {
                                                "tag": "markdown",
                                                "content": msg
                                            }
                                        ]
                                    }
                                    # msg = f"InFlow {current_flow / 1000000:,.2f}m Up {(current_flow - recent_min) / 1000000:,.2f}m from recent low {recent_min / 1000000:,.2f}m\nhttps://vip.stock.finance.sina.com.cn/moneyflow/\nLots {lots}\n{now_str}"
                                    self.robot.send_card(self.args.robot_key, card_body)
                                    logger.info(f"Sent robot message: {msg}")
                                    self.last_inflow_alert_time = now
                                else:
                                    logger.info("Skipping recovery alert due to cooldown")

                        cutoff_time = current_time - timedelta(minutes=self.args.out_flow_window_size)
                        recent_pairs = [(t, f) for t, f in time_flow_pairs if t > cutoff_time]

                        if recent_pairs:
                            # min_time, min_flow = min(recent_pairs, key=lambda x: x[1])

                            recent_max = max(flow for _, flow in recent_pairs)
                            if current_flow - recent_max < -self.args.out_flow_threshold * 1e6:  # Convert to millions
                                if (self.last_outflow_alert_time is None or
                                        now - self.last_outflow_alert_time > self.alert_cooldown):
                                    msg = f"OutFlow {current_flow / 1000000:,.2f}m Down {(recent_max - current_flow) / 1000000:,.2f}m from recent high {recent_max / 1000000:,.2f}m\nhttps://vip.stock.finance.sina.com.cn/moneyflow/\n{now_str}"
                                    self.robot.send_msg(self.args.robot_key, msg)
                                    logger.info(f"Sent robot message: {msg}")
                                    self.last_outflow_alert_time = now
                                else:
                                    logger.info("Skipping drop alert due to cooldown")

                        next_sleep = random.uniform(5, 20)

            except Exception as e:
                logger.error(f"Error making API request: {e}")

            await asyncio.sleep(next_sleep)

    def test_decorator(self, message: str) -> str:
        return ("[TEST] " if self.args.test else "") + message

    def start(self):
        asyncio.set_event_loop(self._ioloop)
        self._ioloop.run_until_complete(self.initialize_redis())
        self._ioloop.run_until_complete(self.load_market_data())

        periodic = self._ioloop.create_task(self.periodic_task())

        try:
            self._ioloop.run_forever()
        finally:
            periodic.cancel()
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()

    def stop(self):
        if self._ioloop:
            self._ioloop.stop()


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Watch money flow on sina.')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                            help='Specify the configuration toml file.')
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                            default='sina')

        parser.add_argument('-t', '--test', action='store_true', help='Test mode')
        parser.add_argument('--in_flow_window_size', type=int, default=10,
                            help='Number of minutes to look back for in flow analysis')
        parser.add_argument('-i', '--in_flow_threshold', type=float, default=100,
                            help='Money flow threshold in millions for in flow alert. Default 100')
        parser.add_argument('--out_flow_window_size', type=int, default=5,
                            help='Number of minutes to look back for out flow analysis')
        parser.add_argument('-o', '--out_flow_threshold', type=float, default=100,
                            help='Money flow threshold in millions for out flow alert. Default 100')

        args = parser.parse_args()
        config = Config(args.config)

        service = MoneyFlowSignal(args, config.data)
        service.start()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        service.stop()  # Add this line to properly stop the service
        sys.exit(0)
