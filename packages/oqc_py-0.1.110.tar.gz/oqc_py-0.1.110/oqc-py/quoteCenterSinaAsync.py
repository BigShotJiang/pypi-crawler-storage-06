#!/usr/bin/env python3
import asyncio
import json
import logging
import argparse
import socket
import re
import signal
from datetime import datetime
from abc import ABC, abstractmethod
from websockets import connect as websocket_connect
from aio_pika import connect_robust, IncomingMessage, Message

logger = logging.getLogger(__name__)
gTickLogger = logging.getLogger("tick")


class WebQuote(ABC):
    @abstractmethod
    def get_quote_url(self, symbols):
        pass

    @abstractmethod
    def api_symbol_to_qc_symbol(self, response):
        pass

    @abstractmethod
    def qc_symbol_to_api_symbol(self, response):
        pass


class SinaQuoteWSProtocol:
    api_symbol_reg_ex = re.compile(r"(sh|sz)[0-9]{6}")
    _message_throttle_count = 100
    log_quote_throttle = 0

    async def send_ping(self, websocket):
        await websocket.ping()
        await asyncio.sleep(30)
        await self.send_ping(websocket)

    async def on_message(self, msg):
        str_msg = msg if isinstance(msg, str) else msg.decode('UTF-8')
        data = self.parse_response(str_msg)
        if self.log_quote_throttle % self._message_throttle_count == 0:
            logger.info("msg: %s", data)
        self.log_quote_throttle += 1

        for quote in data:
            await self.factory.publish_quote(quote['symbol'], json.dumps(quote))

    def parse_response(self, response) -> list:
        quotes = []
        lines = response.splitlines()
        for line in lines:
            t = line.split('=')
            if len(t) < 2:
                continue
            info = {}
            match = self.api_symbol_reg_ex.search(t[0])
            if match:
                info['symbol'] = match.group(0)
            pieces = t[1].split(',')
            if len(pieces) < 33:
                logger.error("Could not parse quote from sina. Check API return %d %s", len(pieces), line)
                continue
            info['desc'] = pieces[0]
            info["open"] = float(pieces[1])
            info["preClose"] = float(pieces[2])
            info['last'] = float(pieces[3])
            info["high"] = float(pieces[4])
            info["low"] = float(pieces[5])
            info["bidPrice1"] = float(pieces[6])
            info["askPrice1"] = float(pieces[7])
            info["vol"] = (50 + float(pieces[8])) / 100  # Round to
            info["turnover"] = float(pieces[9])
            info["bidVolume1"] = float(pieces[10])
            info["askVolume1"] = float(pieces[20])
            info["date"] = pieces[30]
            info["uptime"] = pieces[31]
            info["src"] = "sina"
            info["timeMs"] = convert_to_epoch_ms(pieces[30], pieces[31])
            quotes.append(info)
        return quotes


def convert_to_epoch_ms(date_str, time_str):
    datetime_str = f"{date_str} {time_str}"
    dt = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M:%S")
    epoch_ms = int(dt.timestamp() * 1000)
    return epoch_ms


class SinaWSClientFactory(WebQuote):
    headers = {
        'Origin': 'http://finance.sina.com.cn'
    }
    url_template = "wss://hq.sinajs.cn/wskt?list=%s"
    symbols = set()
    should_reconnect = True

    async def publish_quote(self, symbol, quote):
        # Create exchange for publishing quotes
        if not hasattr(self, '_channel'):
            connection = await connect_robust(**self.amqp_params)
            self._channel = await connection.channel()
            self._exchange = await self._channel.declare_exchange(
                self.config['amqpStructure']['exchanges']['quote']['name'],
                type='topic',
                durable=self.config['amqpStructure']['exchanges']['quote']['durable']
            )

        # Publish the quote
        routing_key = f"quote.stock.domestic.{symbol}"
        await self._exchange.publish(
            Message(body=quote.encode()),
            routing_key=routing_key
        )

    def __init__(self, symbols, **kwargs):
        self.symbols = set(symbols)
        self.url = self.get_quote_url(self.symbols)
        self.config = kwargs.get('config', {})  # Get config from kwargs
        self.amqp_params = kwargs.get('amqp_params', {})  # Get AMQP params from kwargs
        logger.info("Init client factory %s", self.url)

    async def connect(self):
        self.should_reconnect = True
        while self.should_reconnect:
            try:
                async with websocket_connect(self.url, extra_headers=self.headers, ping_interval=30) as websocket:
                    logger.info(f"WebSocket connected to {self.url}")
                    self.websocket = websocket
                    while self.should_reconnect:
                        try:
                            msg = await websocket.recv()
                            await self.on_message(msg)
                        except Exception as e:
                            logger.error(f"Error receiving message: {e}")
                            break
            except Exception as e:
                logger.error(f"Connection error: {e}")
                if self.should_reconnect:
                    await asyncio.sleep(5)  # Wait before reconnecting

    # Remove the problematic send_ping method as we're using websockets' built-in ping
    # async def send_ping(self):
    #     await self.websocket.ping()
    #     await asyncio.sleep(30)
    #     await self.send_ping()

    async def on_message(self, msg):
        protocol = SinaQuoteWSProtocol()
        protocol.factory = self  # Add this line to pass the factory reference
        await protocol.on_message(msg)

    def qc_symbol_to_api_symbol(self, code):
        return code

    def api_symbol_to_qc_symbol(self, code):
        return code

    def get_quote_url(self, symbols):
        mycodes = [self.qc_symbol_to_api_symbol(c) for c in symbols]
        query_params = ','.join(mycodes)
        url = self.url_template % query_params
        return url


class WebQuoteFactory:
    @classmethod
    def create(cls, route, symbols, **kwargs):
        route = route.lower().strip()
        if route == 'sub.stock.domestic':
            factory = SinaWSClientFactory(
                symbols=symbols,
                config=kwargs.get('config', {}),
                amqp_params=kwargs.get('connection_params', {})
            )
            return factory
        return None


class AMQPService:
    def __init__(self, config):
        self.config = config
        self.connection_params = {
            'host': config['amqpServer']['address'],
            'port': config['amqpServer']['port'],
            'virtualhost': config['amqpServer']['vhost'],
            'login': config['amqpServer']['user'],
            'password': config['amqpServer']['password'],
        }
        self.subscriptions = {}

    async def run(self):
        logger.info("Starting AMQP service.")
        connection = await connect_robust(**self.connection_params)
        channel = await connection.channel()
        
        # Declare queue
        queue = await channel.declare_queue("WebAsync.Sina-%s" % socket.gethostname(), auto_delete=True)
        
        # Declare and bind to exchange
        exchange = await channel.declare_exchange(
            self.config['amqpStructure']['exchanges']['request']['name'],
            type='topic',
            durable=self.config['amqpStructure']['exchanges']['request']['durable'] 
        )
        await queue.bind(exchange, routing_key="sub.stock.#")
        
        async for message in queue:
            await self.process_message(message)

    async def process_message(self, message: IncomingMessage):
        body = message.body.decode("utf-8")
        try:
            routing_key = message.routing_key
            symbols = body.split(',')
            # logger.info("process_message Subscribing {}".format(symbols))
            await self.subscribe(routing_key, symbols)
        except ValueError as e:
            logger.warning(e)

    async def subscribe(self, routing_key, symbols):
        logger.info("Subscribing insts: %s %s", routing_key, symbols)
        valid_symbols = set([i for i in symbols if self.valid_qc_symbol(i)])

        if routing_key not in self.subscriptions:
            factory = await self.create_connection_factory_and_connect(routing_key, symbols)
            self.subscriptions[routing_key] = factory
        else:
            subscription = self.subscriptions[routing_key]
            if subscription.symbols.issuperset(valid_symbols):
                return
            subscription.should_reconnect = False
            new_factory = await self.create_connection_factory_and_connect(routing_key, symbols)
            self.subscriptions[routing_key] = new_factory

    def valid_qc_symbol(self, symbol):
        match = re.match(r"(sh|sz)[0-9]{6}", symbol)
        return match is not None

    async def create_connection_factory_and_connect(self, routing_key, symbols):
        factory = WebQuoteFactory.create(
            routing_key, 
            symbols, 
            config=self.config,
            connection_params=self.connection_params
        )
        await factory.connect()
        return factory


def setup_logger():
    global_format = '%(levelname)-10s %(asctime)s - %(funcName)-8s %(lineno)-5d: %(message)s'
    succinct_format = '%(message)s'

    sh = logging.StreamHandler()
    sh.setLevel(logging.INFO)
    sh.setFormatter(logging.Formatter(global_format))
    logger.addHandler(sh)
    logger.setLevel(logging.INFO)

    fh = logging.FileHandler(filename="stockTick.log")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(succinct_format))
    gTickLogger.addHandler(fh)
    gTickLogger.setLevel(logging.DEBUG)


async def main():
    parser = argparse.ArgumentParser(description='Quote Center Sina Client.')
    parser.add_argument('-c', '--config', type=str, metavar="ConfigFile.json", default="etc/config.json",
                        help='Specify the configuration file.')
    args = parser.parse_args()
    with open(args.config, 'r') as content:
        config = json.load(content)

    setup_logger()

    # Setup signal handlers
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, lambda: asyncio.create_task(shutdown(loop)))

    service = AMQPService(config)
    try:
        await service.run()
    except asyncio.CancelledError:
        logger.info("Service shutdown initiated")

async def shutdown(loop):
    logger.info("Shutting down...")
    for task in [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]:
        task.cancel()


if __name__ == '__main__':
    asyncio.run(main())
