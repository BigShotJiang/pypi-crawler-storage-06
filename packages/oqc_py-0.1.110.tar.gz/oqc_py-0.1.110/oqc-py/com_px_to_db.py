#! /usr/bin/python3
import urllib.request
from datetime import datetime
import datetime
from collections import defaultdict
import MySQLdb
from oqclib.config import Config
from oqclib.constants import HTTP_USER_AGENT


class CommoditySpotPrice:
    def __init__(self, args):
        self.spread_list = None
        self.urls = ['http://www.100ppi.com/sf2/day-', 'http://www.100ppi.com/sf/day-']
        self.history_day = 6
        self.headers = {'User-Agent': HTTP_USER_AGENT}
        self.quoteDict = {}

        # Load config and setup database connection
        self.config = Config(args.config)
        mysql_config = self.config.data["mysql"]["MarketData"]
        self.conn = MySQLdb.connect(
            host=mysql_config["host"],
            user=mysql_config["user"],
            passwd=mysql_config["password"],
            db=mysql_config["db"],
            port=int(mysql_config["port"])
        )
        self.cur = self.conn.cursor()

        self.today = datetime.datetime.now()
        self.weekday = self.today.weekday()
        self.insertion_report = defaultdict(int)

        self.ch_name_to_exch_symbol = {
            u"铜": "cu",
            u"螺纹钢": "rb",
            u"锌": "zn",
            u"铝": "al",
            u"黄金": "au",
            u"线材": "wr",
            u"燃料油": "fu",
            u"天然橡胶": "ru",
            u"铅": "pb",
            u"白银": "ag",
            u"石油沥青": "bu",
            u"热轧卷板": "hc",
            u"镍": "ni",
            u"锡": "sn",
            u"PTA": "TA",
            u"白糖": "SR",
            u"棉花": "CF",
            u"普麦": "WH",
            u"菜籽油OI": "OI",
            u"早籼稻RI": "RI",
            u"玻璃": "FG",
            u"菜籽粕": "RM",
            u"油菜籽": "RS",
            u"动力煤": "TC",
            u"粳稻": "JR",
            u"晚籼稻": "LR",
            u"硅铁": "SF",
            u"锰硅": "SM",
            u"甲醇MA": "MA",
            u"动力煤ZC": "ZC",
            u"棕榈油": "p",
            u"聚氯乙烯": "v",
            u"聚乙烯": "l",
            u"豆一": "a",
            u"豆粕": "m",
            u"豆油": "y",
            u"玉米": "c",
            u"焦炭": "j",
            u"焦煤": "jm",
            u"铁矿石": "i",
            u"鸡蛋": "jd",
            u"胶合板": "bb",
            u"纤维板": "fb",
            u"聚丙烯": "pp",
            u"玉米淀粉": "cs"
        }

    def query_data(self, url):
        req = urllib.request.Request(url, headers=self.headers)
        content = urllib.request.urlopen(req).read().decode('utf-8')
        return content

    @staticmethod
    def is_number(s):
        try:
            complex(s)  # for int, long, float and complex
        except ValueError:
            return False
        return True

    def get_historical_price(self, url, date):
        print("getHistoricalPrice " + date)
        data = self.query_data(url + date + ".html")
        if not data:
            return
        data = data.split('<td>')
        for i, item in enumerate(data):
            if item.find('href') and item.find('www.100ppi.com/sf'):
                info = item.split('>')
                if len(info) > 1:
                    if i < len(data) - 1:
                        next_data = data[i + 1]
                        info2 = next_data.split('&')
                        price = info2[0]
                        if self.is_number(price):
                            code = info[1].split('<')[0]
                            if code in self.ch_name_to_exch_symbol:
                                symbol = self.ch_name_to_exch_symbol[code]
                                self.quoteDict[symbol] = price

    def create_table(self, table):
        sql = ('''CREATE TABLE IF NOT EXISTS `replace_me` (
                `id` bigint(20) NOT NULL AUTO_INCREMENT,
                `instrumentId` varchar(30) DEFAULT NULL,
                `day` date DEFAULT NULL,
                `open` double DEFAULT NULL,
                `close` double DEFAULT NULL,
                `high` double DEFAULT NULL,
                `low` double DEFAULT NULL,
                `preClose` double DEFAULT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `Day` (`day`)
            ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;''')
        sql = sql.replace("replace_me", table)
        self.cur.execute(sql)

    def insert_data(self, code, day, price):
        table = "DK_COM_" + code
        sql = "insert ignore into `" + table + "` values"
        sql += "(NULL, '" + code + "','" + day + "'," + price + ", " + price + "," + price + ", " + price + ", " + price + ");"
        print(sql)
        rows = self.cur.execute(sql)
        self.insertion_report[table] += rows

    def advance_date(self, n=0, date_format="%Y-%m-%d"):
        if n != 0:
            another_time = self.today + datetime.timedelta(days=n)
        else:
            another_time = self.today
        return another_time.strftime(date_format)

    def set_spread_list(self, spread_list):
        self.spread_list = spread_list

    def get_pair_name(self, spread_params):
        (inst1, mtpl1, inst2, mtpl2) = spread_params
        pair = inst1
        if mtpl1 != 1:
            pair += '*%d' % mtpl1
        pair += '~%s' % inst2
        if mtpl2 != 1:
            pair += '*%d' % mtpl2
        return pair

    def make_spread_price(self):
        date = self.advance_date(0)
        for v in self.spread_list:
            pair = self.get_pair_name(v)
            (inst1, mtpl1, inst2, mtpl2) = v
            symbol = "COM_" + pair
            table_name = "DK_" + symbol
            self.create_table(table_name)
            spread_sql = ('INSERT ignore INTO `%s` (instrumentId, DAY,OPEN,CLOSE,high,low,preclose) SELECT "%s", '
                         'a.day AS day, a.open*%d - b.open*%d AS open, a.close*%d - b.close*%d AS close, '
                         'a.high*%d-b.high*%d AS high, a.low*%d-b.low*%d AS low, 0 AS preClose FROM `%s` AS a, '
                         '`%s` AS b WHERE a.day = b.day and a.day="%s"') % (
                table_name, symbol, mtpl1, mtpl2, mtpl1, mtpl2, mtpl1, mtpl2, mtpl1, mtpl2, "DK_COM_" + inst1,
                "DK_COM_" + inst2, date)
            print(spread_sql)
            try:
                rows = self.cur.execute(spread_sql)
                self.insertion_report[table_name] += rows
            except Error as e:
                print("Inserting error: " + e)

    def load_data(self):
        date = self.advance_date(0)
        for url in self.urls:
            self.get_historical_price(url, date)

        for k, v in self.quoteDict.items():
            self.insert_data(k, date, v)

    def commit(self):
        self.conn.commit()

    def print_report(self):
        for k in sorted(self.insertion_report.keys()):
            print(" Table: %s Inserted records: %d" % (k, self.insertion_report[k]))


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description="China market calendar.")
    parser.add_argument('-c', '--config', type=str, default="/etc/oqc/config2.toml",
                        help='Specify the configuration file')

    args = parser.parse_args()

    csp = CommoditySpotPrice(args)
    csp.set_spread_list(
        [
            ["y", 1, "p", 1],
            ["RM", 1, "m", 1],
        ]
    )
    csp.load_data()
    csp.make_spread_price()
    csp.commit()
    csp.print_report()
