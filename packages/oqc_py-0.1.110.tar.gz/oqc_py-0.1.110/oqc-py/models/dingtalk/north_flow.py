def get_card(title, north_money, lower, mean, upper):
    return {
         "title": title,
         "text": "# {}\n> #### North Flow\n**{}**\n> #### Upper Band\n**{}**\n> #### Mean\n**{}**\n> #### Lower Band\n**{}**"
            .format(title, north_money, upper, mean, lower)
    }
