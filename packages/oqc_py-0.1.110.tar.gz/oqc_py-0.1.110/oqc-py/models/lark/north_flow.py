def get_card(title, north_money, lower, mean, upper):
    return {
        "header": {
            "template": "blue",
            "title": {
            "tag": "plain_text",
            "content": title
            }
        },
        "elements": [
            {
            "tag": "column_set",
            "flex_mode": "bisect",
            "background_style": "grey",
            "horizontal_spacing": "default",
            "columns": [
                {
                "tag": "column",
                "width": "weighted",
                "weight": 1,
                "elements": [
                    {
                    "tag": "markdown",
                    "text_align": "center",
                    "content": "North Flow\n**{}**".format(north_money)
                    }
                ]
                },
                {
                "tag": "column",
                "width": "weighted",
                "weight": 1,
                "elements": [
                    {
                    "tag": "markdown",
                    "text_align": "center",
                    "content": "Lower Band\n**{}**".format(lower)
                    }
                ]
                },
                {
                "tag": "column",
                "width": "weighted",
                "weight": 1,
                "elements": [
                    {
                    "tag": "markdown",
                    "text_align": "center",
                    "content": "Mean\n**{}**".format(mean)
                    }
                ]
                },
                {
                "tag": "column",
                "width": "weighted",
                "weight": 1,
                "elements": [
                    {
                    "tag": "markdown",
                    "text_align": "center",
                    "content": "Upper Band\n**{}**".format(upper)
                    }
                ]
                }
            ]
            }
        ]
    }