from importlib import reload
import re
import numpy as np
import random
from datetime import timedelta, datetime
import asyncio, aiohttp
import argparse
import logging
import ccxt
import socket
import json
import os
import redis.asyncio as aioredis
import pandas as pd

from common import test_decorator
from oqclib.config import Config
from oqclib.robot.lark import LarkMsg, StatusColor
from oqclib.utils.crypto_symbol_util import get_coin_and_quote_ccy_from_ccxt_symbol, get_exchange_url_for_perpetual
from oqclib.utils.datetime_util import is_midnight

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)

class OIMCSignal:
    def __init__(self, args, config):
        self.args = args
        dirname = os.path.dirname(args.config)
        self.coin_cmcid_mapping_file = os.path.join(dirname, "coin_cmcid_mapping.csv")
        self.https_proxy = args.https_proxy
        self.robot = LarkMsg(config['lark']['robot'])

        self.exchange = "binance"
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()

        # Initialize Redis connection
        if 'redis' in config and 'signal' in config['redis']:
            redis_config = config['redis']['signal']
            self.redis_url = f"redis://:{redis_config['pwd']}@{redis_config['host']}:{redis_config['port']}/{redis_config['db']}"
            self.redis = None

        # Initialize Binance client with proxy
        self.exchange_cli = ccxt.binanceusdm()
        if self.https_proxy:
            self.exchange_cli.proxies = {'https': self.https_proxy}

        self.cmc_key = ''
        self.last_oi_values = {}
        self.last_query_time = datetime.now() - timedelta(days=1000)

    async def load_config_from_redis(self):
        key = "p:oimc:config"
        try:
            json_str = await self.redis.get(key)
            if json_str:
                config = json.loads(json_str)
                return config  # Return the entire JSON object
        except Exception as e:
            logger.error(f"Error loading config from Redis: {e}")
        return {}

    async def should_send_alert(self, type: str, symbol: str, interval_s: int) -> bool:
        redis_key = f"p:oimc:alert:{type}:{symbol}"
        exists = await self.redis.exists(redis_key)
        if exists:
            return False
        await self.redis.setex(redis_key, interval_s, "1") 
        return True

    def get_all_swap_tickers(self):
        swap_list = []
        self.exchange_cli.load_markets(reload=True)
        swap_ticker_data = self.exchange_cli.fetch_tickers()
        for symbol in swap_ticker_data.keys():
            if symbol.endswith('/USDT:USDT'):
                t = swap_ticker_data[symbol]['timestamp']
                swap_USD_volume_24h = swap_ticker_data[symbol]['quoteVolume']
                swap_price = swap_ticker_data[symbol]['last']
                if datetime.now() - datetime.fromtimestamp(t/1000) < timedelta(minutes=10):
                    swap_list.append([symbol, swap_USD_volume_24h, swap_price])
        df = pd.DataFrame(swap_list, columns=['symbol', 'swap_USD_volume_24h', 'swap_price'])
        return df

    # STEP4: query latest CMC data for realtime market cap and merge data
    async def loadCoinSupplyFrCMC(self, start=1, limit=5000):
        url = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest'
        parameters = {
            'start':'{}'.format(start),
            'limit':'{}'.format(limit),
            'convert':'USD'
        }
        headers = {
            'Accepts': 'application/json',
            'X-CMC_PRO_API_KEY': self.cmc_key,
        }
        
        async with aiohttp.ClientSession() as session:
            try:
                proxy = self.https_proxy if self.https_proxy else None
                async with session.get(url, params=parameters, headers=headers, proxy=proxy) as response:
                    data = await response.json()
                    return data
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                logger.error(f"Failed to loadCoinSupplyFrCMC {start} {limit}", e)
                return None
    
    async def refresh_cmc_if_needed(self):
        if datetime.now() - self.last_query_time < timedelta(days=1):
            return

        data1 = await self.loadCoinSupplyFrCMC()
        data2 = await self.loadCoinSupplyFrCMC(start=5001)
        data1['data'].extend(data2['data'])

        self.df_cmc = pd.DataFrame(data1['data'])
        self.last_query_time = datetime.now()
        logging.info('Query CMC coin supply data, last_query_time: {}'.format(self.last_query_time))

    async def periodic_task(self):
        while True:
            next_sleep = random.uniform(1890, 2020)  
            logger.info(f"Starting new iteration, will sleep for {next_sleep / 60:.1f} minutes after completion")
            oimc_config = await self.load_config_from_redis()
            self.cmc_key = oimc_config.get("CMCKey", "")

            try:
                # STEP1: Get all SWAP USDT pairs in Binance
                df_swap_vol = self.get_all_swap_tickers()
                logger.info(f"Found {len(df_swap_vol)} swap pairs")

                # STEP2: Fetch swap open interest data for each pair
                start_time = datetime.now() - timedelta(minutes=60)
                since = int(start_time.timestamp() * 1000)
                oi_data = []
                total_pairs = len(df_swap_vol)
                for idx, (i, row) in enumerate(df_swap_vol.iterrows(), 1):
                    try:
                        symbol = row['symbol']
                        if idx % 30 == 0:
                            logger.info(f"Processing {symbol} ({idx}/{total_pairs})")
                        ret = self.exchange_cli.fetchOpenInterestHistory(symbol, '5m', since=since)
                        swap_OI_value = ret[-1]['openInterestValue']
                        oi_data.append([symbol, swap_OI_value])
                        if self.args.test and idx > 20:
                            break
                    except Exception as e:
                        logging.error(f"Error fetching OI for {symbol}: {e}")
                        continue
                df_oi = pd.DataFrame(oi_data, columns=['symbol', 'swap_OI_value'])

                df_oi = pd.merge(df_oi, df_swap_vol, on='symbol')
                df_oi['base_asset'] = df_oi['symbol'].apply(lambda x: x.split('/')[0])

                multiplyer = []
                coin_name = []
                for i,r in df_oi.iterrows():
                    if r['base_asset'].startswith('1M'):
                        multiplyer.append(1000000)
                        coin_name.append(r['base_asset'].replace('1M',''))
                        # logging.info('{} {}'.format(1000000, r['base_asset']))
                        continue
                    try:
                        m = int(re.findall(r'\d+', r['base_asset'])[0])
                        if m%10==0:
                            multiplyer.append(m)
                            # logging.info('{} {}'.format(m, r['base_asset']))
                            coin_name.append(r['base_asset'].replace(str(m),""))
                        else:
                            multiplyer.append(1)
                            # logging.info('{} {}'.format(m, r['base_asset']))
                            coin_name.append(r['base_asset'])
                    except:
                        multiplyer.append(1)
                        coin_name.append(r['base_asset'])

                df_oi['coin_name'] = coin_name
                df_oi['multiplier'] = multiplyer 


                # STEP3: load bn_swap_name_CMC_id_match.csv
                df_map = pd.read_csv(self.coin_cmcid_mapping_file)
                coin_id_map_keys = set(df_map['coin_name'].to_list())

                for coin in df_oi['coin_name'].to_list():
                    if coin not in coin_id_map_keys:
                        logging.error(f'{coin} not in match {self.coin_cmcid_mapping_file}, pls update csv')
                        if await self.should_send_alert('map_miss', coin, 3600 * 24):
                            self.robot.send_msg(self.args.robot_key, f'[CMCID Missing] ID of {coin} not {self.coin_cmcid_mapping_file}, pls update csv')

                df_oi_id = pd.merge(df_oi, df_map, left_on='coin_name', right_on='coin_name', how='left')

                await self.refresh_cmc_if_needed()
                # df_cmc = pd.concat([df_cmc1, df_cmc2])

                df_oi_id_CMC = pd.merge(df_oi_id, self.df_cmc.loc[:, ['circulating_supply','total_supply','max_supply','self_reported_circulating_supply','id']], left_on='id', right_on='id', how='left')

                # STEP5: calculate the signal
                df_oi_id_CMC_good = df_oi_id_CMC.loc[~pd.isna(df_oi_id_CMC['circulating_supply'])].copy()
                df_oi_id_CMC_good['market_cap'] = df_oi_id_CMC_good.apply(lambda x: round(x['swap_price']/x['multiplier']*x['circulating_supply'],1) if x['circulating_supply']>1 else round(x['swap_price']/x['multiplier']*x['self_reported_circulating_supply'],1), axis=1)
                df_oi_id_CMC_good['fdv'] = df_oi_id_CMC_good.apply(lambda x: round(x['swap_price']/x['multiplier']*x['total_supply'],1) if pd.isna(x['max_supply']) else round(x['swap_price']/x['multiplier']*x['max_supply'],1), axis=1)

                df_oi_id_CMC_good['bn_swap_OI_MC_ratio'] = df_oi_id_CMC_good.apply(lambda x: x['swap_OI_value']/ x['market_cap'] if x['market_cap']>1 else np.nan, axis=1)
                df_oi_id_CMC_good['bn_swap_VOL_MC_ratio'] = df_oi_id_CMC_good.apply(lambda x: x['swap_USD_volume_24h']/ x['market_cap'] if x['market_cap']>1 else np.nan, axis=1)
                df_oi_id_CMC_good.sort_values('bn_swap_OI_MC_ratio', ascending=False, inplace=True)

                await self.send_alert_for_oimc_df(df_oi_id_CMC_good, oimc_config)

            except Exception as e:
                logger.error(f"Error in periodic task: {e}", exc_info=True)

            await asyncio.sleep(next_sleep)

    async def send_alert_for_oimc_df(self, df, oimc_config: dict):
        oimc_ratio_threshold = oimc_config.get("BnOIMCRatioThreshold", 1)
        df = df[df['bn_swap_OI_MC_ratio'] > oimc_ratio_threshold]
        top_n = 10
        logger.info(df.head(top_n))
        # Construct and send Lark card for top results
        if not df.empty:
            top_results = df.head(top_n)
            elements = []

            title = f"OI/MC Top {top_n} Coins"
            
            # Add header text
            # elements.append({
            #     "tag": "div",
            #     "text": {
            #         "tag": "lark_md",
            #         "content": title
            #     }
            # })

            # Format table header
            table_content = "| Symbol | OI/MC Ratio | Vol/MC Ratio | Spot Vol/MC Ratio |\n"
            table_content += "|--------|------------|--------------|------------------|\n"

            # Add each row
            row_added = 0
            for _, row in top_results.iterrows():
                if not await self.should_send_alert('alert', row['symbol'], 3600 * 8) or is_midnight():
                    continue
                coin, quote_ccy = get_coin_and_quote_ccy_from_ccxt_symbol(self.exchange, row['symbol'])
                url = get_exchange_url_for_perpetual(self.exchange, coin, quote_ccy) if coin else ""
                table_content += f"| {row['symbol']} | {row['bn_swap_OI_MC_ratio']:.4f} | {row['bn_swap_VOL_MC_ratio']:.4f} | {row['CMC_spot_VOL_MC_ratio']:.4f} | {url}\n"
                row_added += 1

            elements.append({
                "tag": "markdown",
                "content": table_content
            })

            # Add timestamp
            elements.append({
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": f" Threshold: {oimc_ratio_threshold}\nGenerated at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} from {socket.gethostname()}"
                }
            })

            card_body = {
                "header": {
                    "template": StatusColor.BLUE.value,
                    "title": {
                        "tag": "plain_text",
                        "content": title
                    }
                },
                "elements": elements
            }
            if row_added > 0:
                self.robot.send_card(self.args.robot_key, card_body=card_body)


    async def start(self):
        logger.info("Starting service...")
        self.redis = await aioredis.from_url(self.redis_url)
        try:
            await self.periodic_task()
        finally:
            await self.redis.aclose()

    def run(self):
        asyncio.set_event_loop(self._ioloop)
        try:
            self._ioloop.run_until_complete(self.start())
        except KeyboardInterrupt:
            pass
        finally:
            self._ioloop.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Binance Open Interest and MC')
    parser.add_argument('-t', '--test', action='store_true', help='Test mode')
    parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                      help='Specify the configuration toml file.')
    parser.add_argument('--https_proxy', type=str, help='HTTPS proxy URL')
    parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                      default='open-interest-alert')

    args = parser.parse_args()
    config = Config(args.config)

    service = OIMCSignal(args, config.data)
    service.run()
