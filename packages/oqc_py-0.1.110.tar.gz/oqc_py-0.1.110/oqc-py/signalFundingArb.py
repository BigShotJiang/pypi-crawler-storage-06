import sys
import os
import random
from datetime import timedelta

import asyncio
import argparse
import logging
import socket

from oqclib.config import Config
from oqclib.robot.lark import LarkMsg, StatusColor
from oqclib.constants import HTTP_USER_AGENT, HTTP_ACCEPT_LANGUAGE
from oqclib.utils import datetime_util
from oqclib.utils.crypto_symbol_util import get_exchange_url_for_perpetual
from oqclib.utils.math_util import least_common_multiple

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)
VERSION = "0.1.110"

def estimate_funding_1d(funding_rate: float, max_funding_times: int) -> float:
    # max_funding_times = 4 if interval_hours <= 6 else 3 if interval_hours == 8 else 2 if interval_hours == 12 else 1
    estimate_fr = funding_rate
    total_funding = 0.0
    while max_funding_times > 0:
        total_funding += estimate_fr
        estimate_fr = funding_rate / 2
        max_funding_times = max_funding_times - 1
    return total_funding


class FundingArbSignal:
    # Class constants
    API_ORIGIN = 'https://chillybot.xyz/'
    API_REFERER = API_ORIGIN + '/'
    API_ACCEPT = 'application/json, text/plain, */*'
    API_URL = 'https://api.chillybot.xyz/api/data'
    OUTPUT_COUNT = 10
    EXCLUDE_EXCHANGES = {"Gate"}

    def __init__(self, args, config):
        self.args = args
        self.profit_threshold = args.profit_threshold
        self.robot = LarkMsg(config['lark']['robot'])
        self.first_positive_flow_notified = False
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self.last_recovery_alert_time = None  # Add this line
        self.recovery_alert_cooldown = timedelta(minutes=15)

    async def periodic_task(self):
        import aiohttp
        from datetime import datetime, date, timedelta

        headers = {
            'Accept': self.API_ACCEPT,
            'Accept-Language': HTTP_ACCEPT_LANGUAGE,
            'Origin': self.API_ORIGIN,
            'Referer': self.API_REFERER,
            'User-Agent': HTTP_USER_AGENT,
            "Cache-Control": "max-age=0"
        }

        while True:
            # next_sleep = random.uniform(1418, 1729)
            now = datetime.now()
            if now.minute < 45:
                target = now.replace(minute=45, second=0, microsecond=0)
            elif now.minute < 55:
                target = now.replace(minute=55, second=0, microsecond=0)
            else:
                target = (now + timedelta(hours=1)).replace(minute=45, second=0, microsecond=0)

            next_sleep = (target - now).total_seconds()
            try:
                # Add random number to URL to prevent caching
                url = self.API_URL
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, headers=headers, ssl=False) as response:
                        if response.status != 200:
                            await asyncio.sleep(next_sleep)
                            continue
                        json = await response.json()

                        # Group data by Symbol
                        symbol_data = {}
                        for item in json['data']:
                            if item['Exchange'] in self.EXCLUDE_EXCHANGES:
                                continue
                            if item['Volume'] > 0 and item['Volume'] * item['Price'] < 5000000:
                                continue
                            symbol = item['Symbol']

                            if symbol not in symbol_data:
                                symbol_data[symbol] = []
                            symbol_data[symbol].append(item)

                        # Calculate funding rate differences for symbols with multiple exchanges
                        funding_diffs = []
                        for symbol, exchanges in symbol_data.items():
                            if len(exchanges) >= 2:
                                for i in range(len(exchanges)):
                                    for j in range(i + 1, len(exchanges)):
                                        funding1 = exchanges[i]
                                        funding2 = exchanges[j]
                                        lcm = least_common_multiple(funding1['FundingInterval'], funding2['FundingInterval'])
                                        funding1_1d = estimate_funding_1d(funding1['FundingRate'], lcm / funding1['FundingInterval'])
                                        funding2_1d = estimate_funding_1d(funding2['FundingRate'], lcm / funding2['FundingInterval'])
                                        diff = abs(funding1_1d - funding2_1d)
                                        # Put higher APR exchange as the first leg
                                        if funding1_1d >= funding2_1d:
                                            price_diff = (funding1['Price'] - funding2['Price']) / (
                                                        funding1['Price'] + funding2['Price']) * 2
                                            if price_diff >= 0:
                                                funding_diffs.append({
                                                    'symbol': symbol,
                                                    'exchange1': funding1['Exchange'],
                                                    'rate1': funding1_1d,
                                                    'interval1': funding1['FundingInterval'],
                                                    'price1': funding1['Price'],
                                                    'exchange2': funding2['Exchange'],
                                                    'rate2': funding2_1d,
                                                    'interval2': funding2['FundingInterval'],
                                                    'price2': funding2['Price'],
                                                    'diff': diff,
                                                    'price_diff': price_diff
                                                })
                                        else:
                                            price_diff = (funding2['Price'] - funding1['Price']) / (
                                                        funding2['Price'] + funding1['Price']) * 2
                                            if price_diff >= 0:
                                                funding_diffs.append({
                                                    'symbol': symbol,
                                                    'exchange1': funding2['Exchange'],
                                                    'rate1': funding2_1d,
                                                    'interval1': funding2['FundingInterval'],
                                                    'price1': funding2['Price'],
                                                    'exchange2': funding1['Exchange'],
                                                    'rate2': funding1_1d,
                                                    'interval2': funding1['FundingInterval'],
                                                    'price2': funding1['Price'],
                                                    'diff': diff,
                                                    'price_diff': price_diff
                                                })

                        # Sort by funding rate difference
                        funding_diffs.sort(key=lambda x: x['diff'], reverse=True)

                        # Log the results
                        logger.info(f"Top {self.OUTPUT_COUNT}")
                        for arb in funding_diffs[:self.OUTPUT_COUNT]:
                            logger.info(
                                f"{arb['symbol']}: {arb['diff'] * 100:.2f}% ({arb['exchange1']}: {arb['rate1'] * 100:.3f}% vs {arb['exchange2']}: {arb['rate2'] * 100:.3f}%)")

                        content_lines = [
                            "| Coin | 1dFund | PxDiffBps | Ex1 | Px 1 | Rate 1 BPS | Ex2 | Px 2 | Rate 2 BPS |",
                            "|------|--------|-----------|-----|------|------------|-----|------|------------|"
                        ]
                        for arb in funding_diffs[:self.OUTPUT_COUNT]:
                            line = (f"| **{str(arb['symbol']).ljust(7)}** | {arb['diff']*100:.0f} | {arb['price_diff'] * 10000:.0f} | {arb['exchange1']} | {arb['price1']:.4f} |"
                                    f" {arb['rate1'] * 100:.0f}@{arb['interval1']} | {arb['exchange2']} | {arb['price2']:.4f} | {arb['rate2'] * 100:.0f}@{arb['interval2']} |")
                            content_lines.append(line)

                        top_1 = funding_diffs[0]
                        top1_profit = top_1['diff'] + top_1['price_diff'] * 100 * 0.8

                        significant = top1_profit > self.profit_threshold
                        url1 = get_exchange_url_for_perpetual(top_1['exchange1'], top_1['symbol'], "USDT")
                        url2 = get_exchange_url_for_perpetual(top_1['exchange2'], top_1['symbol'], "USDT")
                        card_body = {
                            "header": {
                                "template": StatusColor.GREEN.value if significant else StatusColor.LIME.value,
                                "title": {
                                    "tag": "plain_text",
                                    "content": self.test_decorator(f"Funding Arbitrage Opportunities Ver {VERSION}")
                                }
                            },
                            "elements": [
                                {
                                    "tag": "markdown",
                                    "content": "\n".join(content_lines)
                                },
                                {
                                    "tag": "div",
                                    "text": {
                                        "tag": "lark_md",
                                        "content": f"**Top Opportunity {top_1['symbol']}**: {top1_profit*100:.0f} "
                                                   f"(1d Funding {top_1['diff']*100:.0f} + PxDiffBPS {top_1['price_diff']*10000:.0f}*0.8)\nURL1: {url1}\nURL2 {url2}\n"
                                                   f"Sent from {socket.gethostname()} Next Query in {next_sleep / 60:.1f} min"
                                    }
                                }
                            ]
                        }

                        if significant and not datetime_util.is_midnight():
                            self.robot.send_card('funding-alert', card_body=card_body)
                        else:
                            self.robot.send_card('funding-report', card_body=card_body)

            except Exception as e:
                logger.error(f"Error making API request: {e}")

            await asyncio.sleep(next_sleep)

    def test_decorator(self, message: str) -> str:
        return message if os.getenv('JTP_FQ_ENV', '').endswith('_PRD') else f"[TEST] {message}"

    def start(self):
        asyncio.set_event_loop(self._ioloop)
        periodic = self._ioloop.create_task(self.periodic_task())

        try:
            self._ioloop.run_forever()
        finally:
            periodic.cancel()
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()

    def stop(self):
        if self._ioloop:
            self._ioloop.stop()


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Quote Center Forwarder.')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                            help='Specify the configuration toml file.')
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                            default='funding')

        parser.add_argument('-t', '--test', action='store_true', help='Test mode')

        parser.add_argument('-p', '--profit_threshold', type=float, default=3.0,
                          help='Profit threshold percentage for alerts. Default 3.0')

        args = parser.parse_args()
        config = Config(args.config)

        service = FundingArbSignal(args, config.data)
        service.start()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        service.stop()  # Add this line to properly stop the service
        sys.exit(0)
