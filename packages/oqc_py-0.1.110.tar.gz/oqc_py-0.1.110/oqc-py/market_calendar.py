#! /usr/bin/python3
from oqclib.config import Config
from sqlalchemy import create_engine, text
from datetime import timedelta, date, datetime
import pandas as pd
import sys

from oqclib.market.china import ChinaMarketCalendar


def valid_date(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        msg = "Not a valid date: '{0}'.".format(s)
        raise argparse.ArgumentTypeError(msg)


def is_trading_day(args):
    config = Config(args.config)

    day = args.date
    c = ChinaMarketCalendar(config, day - timedelta(days=1), day)
    td = c.is_trading_day(day)
    if not args.silent:
        print("%s is %strading day" % (day, '' if td else 'NOT '))
    if td:
        sys.exit(0)
    else:
        sys.exit(1)


def get_pre_trading_day(args):
    config = Config(args.config)

    day = args.date
    c = ChinaMarketCalendar(config, day - timedelta(days=30), day)
    print(c.get_pre_trading_day(day))


class CalendarUpdater:
    def __init__(self, config):
        self.config = config
        self.db_config_name = "MarketData"
        connection_string = self.config.get_mysql_string(self.db_config_name)
        self.engine = create_engine(connection_string)

    async def load_web_and_save(self, limit):
        from website.eastmoney import get_trading_date
        trading_days = await get_trading_date(limit)
        
        # Create records for all dates in the range
        all_dates = pd.date_range(start=trading_days[0], end=trading_days[-1])
        
        # Prepare SQL statement
        insert_sql = text("""
            INSERT IGNORE INTO Calendar (exchange, date, isOpen, preTradeDate)
            VALUES (:exchange, :date, :isOpen, :preTradeDate)
        """)
        
        prev_trading_day = None
        inserted_count = 0
        with self.engine.connect() as conn:
            for date in all_dates:
                date_str = date.strftime('%Y-%m-%d')
                is_trading = date in trading_days
                
                # Print the SQL with parameters
                final_sql = insert_sql.bindparams(
                    exchange='SSE',
                    date=date_str,
                    isOpen=1 if is_trading else 0,
                    preTradeDate=prev_trading_day if is_trading else None
                ).compile(compile_kwargs={"literal_binds": True})
                
                # Execute the SQL
                result = conn.execute(insert_sql, {
                    'exchange': 'SSE',
                    'date': date_str,
                    'isOpen': 1 if is_trading else 0,
                    'preTradeDate': prev_trading_day if is_trading else None
                })
                inserted_count += result.rowcount
                
                if is_trading:
                    prev_trading_day = date_str
            
            conn.commit()
            print(f"Successfully inserted {inserted_count} new records")


    async def update_today_and_save(self):
        from website.sina import is_today_trading_day
        is_trading_day_today = await is_today_trading_day()
        today = date.today()
        
        # Get the last trading day for preTradeDate
        sql = text("SELECT date FROM Calendar WHERE isOpen = 1 AND date < :today ORDER BY date DESC LIMIT 1")
        with self.engine.connect() as conn:
            result = conn.execute(sql, {'today': today})
            last_trading_day = result.scalar()
            
            # Insert or update today's record
            upsert_sql = text("""
                INSERT INTO Calendar (exchange, date, isOpen, preTradeDate)
                VALUES (:exchange, :date, :isOpen, :preTradeDate)
                ON DUPLICATE KEY UPDATE
                isOpen = VALUES(isOpen),
                preTradeDate = VALUES(preTradeDate)
            """)

            # Print SQL with actual values
            final_sql = upsert_sql.bindparams(
                exchange='SSE',
                date=today,
                isOpen=1 if is_trading_day_today else 0,
                preTradeDate=last_trading_day if is_trading_day_today else None
            ).compile(compile_kwargs={"literal_binds": True})
            print(str(final_sql))
            
            result = conn.execute(upsert_sql, {
                'exchange': 'SSE',
                'date': today,
                'isOpen': 1 if is_trading_day_today else 0,
                'preTradeDate': last_trading_day if is_trading_day_today else None
            })
            
            conn.commit()
            print(f"Successfully {'updated' if result.rowcount == 2 else f'inserted {result.rowcount}'} records for {today}")


def update_market_calendar(args):
    config = Config(args.config)
    calendar_updater = CalendarUpdater(config)
    import asyncio
    asyncio.run(calendar_updater.load_web_and_save(args.limit))


def update_today_market_calendar(args):
    config = Config(args.config)
    calendar_updater = CalendarUpdater(config)
    import asyncio
    asyncio.run(calendar_updater.update_today_and_save())


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="China market calendar.")
    parser.add_argument('-c', '--config', type=str, default="/etc/oqc/config2.toml",
                        help='Specify the configuration file')

    subparsers = parser.add_subparsers(dest='command')

    parser_trading_day = subparsers.add_parser("isopen")
    parser_trading_day.set_defaults(func=is_trading_day)
    parser_trading_day.add_argument('-d', '--date', type=valid_date, default=date.today())
    parser_trading_day.add_argument('-s', '--silent',
                                    help='Not printing. Only use exit code to indicate whether the specified date '
                                         'is a trading day', action='store_true')

    parser_get_pre_trading_day = subparsers.add_parser("pretradingday")
    parser_get_pre_trading_day.set_defaults(func=get_pre_trading_day)
    parser_get_pre_trading_day.add_argument('-d', '--date', type=valid_date, default=date.today())

    parser_get_pre_trading_day = subparsers.add_parser("update_db")
    parser_get_pre_trading_day.set_defaults(func=update_market_calendar)
    parser_get_pre_trading_day.add_argument('-l', '--limit', type=int, default=15,
                                          help='Number of trading days to fetch')

    parser_get_pre_trading_day = subparsers.add_parser("update_db_today")
    parser_get_pre_trading_day.set_defaults(func=update_today_market_calendar)

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit()
    args.func(args)
