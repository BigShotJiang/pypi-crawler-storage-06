import tushare as ts
import pandas as pd
import logging
from datetime import *
import time
from sqlalchemy import create_engine, select
from sqlalchemy.sql import text
from oqclib.config import Config
from oqclib import tushare_util
from oqclib.robot.dingtalk import DingTalkRobot
from models.dingtalk.north_flow import get_card

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', force=True)


class MoneyHsgt:
    def __init__(self, config_file: str, db_config_name):
        self.config = Config(config_file)
        self.table_name = "moneyflow_hsgt"
        ts.set_token(self.config.data['tushare']['key'])
        self.pro = ts.pro_api()

        conn_str = self.config.get_mysql_string(db_config_name)
        self.sql_engine = create_engine(conn_str)
        self.robot = DingTalkRobot(self.config.data['dingtalk']['robot'])

    def fetch_northward_fund(self, start_date: pd.Timestamp, end_date: pd.Timestamp) -> pd.DataFrame:
        logger.info("get_northward_fund {} {}".format(start_date, end_date))
        all_data = pd.DataFrame()
        days_per_call = 300

        # Loop over the date range in increments of n days
        for batch_start_date in pd.date_range(start_date, end_date, freq=f"{days_per_call}D"):
            # Define the end date for the current batch
            batch_end_date = min(pd.Timestamp(date.today()),
                                 batch_start_date + pd.Timedelta(days_per_call - 1, unit="D"))

            logger.info('batch_start_date %s batch_end_date %s', batch_start_date, batch_end_date)
            # Call the Python API with the current batch dates
            batch_data = self.pro.moneyflow_hsgt(
                start_date=tushare_util.to_tushare_date_str(batch_start_date),
                end_date=tushare_util.to_tushare_date_str(batch_end_date))
            batch_data['trade_date'] = pd.to_datetime(batch_data['trade_date'])
            batch_data = batch_data.set_index('trade_date')
            # Concatenate the batch data with the current data
            all_data = pd.concat([all_data, batch_data])
            time.sleep(0.5)

        all_data = all_data.dropna(axis=0).sort_index()

        return all_data

    def insert_row(self, table, conn, keys, data_iter):
        fields = "`" + "`,`".join(keys) + "`"
        table_name = table.name

        with conn.connection.cursor() as cur:
            values = []
            for row in data_iter:
                value = '("%s", %d, %d, %d, %d, %d, %d)' % (*row,)
                logger.info(value)

                values.append(value)
            sql = 'replace into `%s` (%s) values %s;' % (table_name, fields, ','.join(values))
            logger.info(sql)
            cur.execute(sql)

    def save_df(self, df):
        df.to_sql(self.table_name, self.sql_engine, if_exists="append", method=self.insert_row)

    def load_northward_fund(self, end_date: datetime.date, window_length: int):
        stmt = text(
            "(select trade_date, north_money from moneyflow_hsgt where trade_date <= '{}' order by trade_date desc limit {}) order by trade_date" \
            .format(end_date, window_length))
        logger.info(stmt)
        with self.sql_engine.connect() as conn:
            result = conn.execute(stmt)

            # Fetch all rows
            rows = result.fetchall()

            # Get the column names from the query result
            column_names = result.keys()

            # Create a pandas DataFrame
            df = pd.DataFrame(rows, columns=column_names)

            return df.set_index('trade_date')

    def save_to_db(self, args):
        # Set the start and end dates for the data you want to retrieve
        start_date = pd.Timestamp(args.start_date)
        end_date = pd.Timestamp(args.end_date)
        df = self.fetch_northward_fund(start_date, end_date)
        self.save_df(df)

    def check_northward_fund_signal(self, args):
        # Set the start and end dates for the data you want to retrieve
        window_length = args.window_length
        u = args.multi_std_up
        d = args.multi_std_down
        end_date = args.end_date
        northward_flow = self.load_northward_fund(end_date, window_length * 2)
        northward_flow = calc_bollinger_bands(northward_flow, window_length, u, d)
        last_entry = northward_flow.iloc[-1]

        card = None
        if (last_entry['north_money'] > last_entry['upper_band']):
            card = get_card("NM Up break on " + str(last_entry.name), last_entry['north_money'],
                            last_entry['lower_band'], last_entry['rolling_mean'], last_entry['upper_band'])
            logger.info(
                "UP Break. Date {} Flow {}, lower {}, upper {}".format(last_entry.name, last_entry['north_money'],
                                                                       last_entry['lower_band'],
                                                                       last_entry['upper_band']))
        elif (last_entry['north_money'] < last_entry['lower_band']):
            card = get_card("NM Down break on " + str(last_entry.name), last_entry['north_money'],
                            last_entry['lower_band'], last_entry['rolling_mean'], last_entry['upper_band'])
            logger.info(
                "Down Break. Date {} Flow {}, lower {}, upper {}".format(last_entry.name, last_entry['north_money'],
                                                                         last_entry['lower_band'],
                                                                         last_entry['upper_band']))
        else:
            card = get_card("NM No break on " + str(last_entry.name), last_entry['north_money'],
                            last_entry['lower_band'], last_entry['rolling_mean'], last_entry['upper_band'])
            logger.info(
                "No Break. Date {} Flow {}, lower {}, upper {}".format(last_entry.name, last_entry['north_money'],
                                                                       last_entry['lower_band'],
                                                                       last_entry['upper_band']))

        if card is not None:
            self.robot.send_card(args.robot_key, card)


def valid_date(s) -> datetime.date:
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        msg = "Not a valid date: '{0}'.".format(s)
        raise argparse.ArgumentTypeError(msg)


def calc_bollinger_bands(df: pd.DataFrame, window_size, num_std_up, num_std_down):
    # Calculate the rolling mean and standard deviation
    df['rolling_mean'] = df['north_money'].rolling(window=window_size).mean()
    df['rolling_std'] = df['north_money'].rolling(window=window_size).std()

    # Calculate the upper and lower Bollinger Bands
    df['upper_band'] = df['rolling_mean'] + (df['rolling_std'] * num_std_up)
    df['lower_band'] = df['rolling_mean'] - (df['rolling_std'] * num_std_down)
    return df


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description="HSG money flow")
    parser.add_argument('-c', '--config', type=str, default="/etc/oqc/config2.toml")
    parser.add_argument('-d', '--db_config', type=str, default="MarketData")
    parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                        default='okx')

    subparsers = parser.add_subparsers(dest='command')

    parser_command_save = subparsers.add_parser("save")
    parser_command_save.set_defaults(func=MoneyHsgt.save_to_db)
    parser_command_save.add_argument('-s', '--start_date', type=valid_date, default=date.today() - timedelta(days=20))
    parser_command_save.add_argument('-e', '--end_date', type=valid_date, default=date.today())

    parser_command_save = subparsers.add_parser("check")
    parser_command_save.set_defaults(func=MoneyHsgt.check_northward_fund_signal)
    parser_command_save.add_argument('-w', '--window_length', type=int, default=60)
    parser_command_save.add_argument('-u', '--multi_std_up', type=int, default=1.5)
    parser_command_save.add_argument('-d', '--multi_std_down', type=int, default=1.5)
    parser_command_save.add_argument('-e', '--end_date', type=valid_date, default=date.today())

    # args = parser.parse_args('isopen -s'.split())
    args = parser.parse_args()

    money_hsgt = MoneyHsgt(args.config, args.db_config)
    if "func" not in args:
        parser.print_help()
        import sys

        sys.exit()

    args.func(money_hsgt, args)
    # getattr(money_hsgt, )(args)
