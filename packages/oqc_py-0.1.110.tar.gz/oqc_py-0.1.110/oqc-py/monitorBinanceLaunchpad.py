import sys
import random
import socket
from datetime import datetime, timedelta
import redis.asyncio as aioredis

import asyncio
import argparse
import logging
import aiohttp

from oqclib.config import Config
from oqclib.robot.lark import LarkMsg
from oqclib.constants import HTTP_USER_AGENT

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)


class BinanceLaunchpadSignal:
    API_URL = 'https://launchpad.binance.com/bapi/lending/v1/friendly/launchpool/project/listV3'

    def __init__(self, args, config):
        self.redis = None
        self.redis_expiry = 86400 * 100  # Update this line too

        # Initialize Redis connection only if redis config exists
        if 'redis' in config and 'signal' in config['redis']:
            redis_config = config['redis']['signal']
            self.redis_url = f"redis://:{redis_config['pwd']}@{redis_config['host']}:{redis_config['port']}/{redis_config['db']}"

        self.args = args
        self.robot = LarkMsg(config['lark']['robot'])
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()

    def calculate_next_sleep(self):
        next_sleep = random.uniform(3432, 4239)
        now = datetime.now()
        next_run_time = now + timedelta(seconds=next_sleep)
        if next_run_time.hour < 8 or next_run_time.hour >= 23:
            # If next run time is outside active hours, adjust to next 8:00 AM
            next_run_time = (now + timedelta(days=1)).replace(hour=8, minute=0, second=0, microsecond=0)
            if now.hour < 8: 
                next_run_time = next_run_time - timedelta(days=1)  # Use today's 8 AM instead
        return (next_run_time - now).total_seconds()

    async def should_send_alert(self, coin) -> bool:
        if not self.redis:
            return True

        key = f"p:launchpool:bn:{coin}"
        try:
            exists = await self.redis.exists(key)
            if not exists:
                await self.redis.setex(key, self.redis_expiry, "1")
                return True
            return False
        except Exception as e:
            logger.error(f"Error checking redis key {key}: {e}")
            return True

    async def periodic_task(self):
        headers = {
            'Accept': 'application/json',
            'User-Agent': HTTP_USER_AGENT
        }

        params = {
            'pageIndex': 1,
            'pageSize': 4
        }

        proxy = self.args.https_proxy if hasattr(self.args, 'https_proxy') else None

        while True:
            next_sleep = self.calculate_next_sleep()
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(self.API_URL, headers=headers, params=params, proxy=proxy, ssl=False) as response:
                        if response.status != 200:
                            logger.error(f"API request failed with status {response.status}")
                            await asyncio.sleep(next_sleep)
                            continue

                        data = await response.json()
                        if data.get('code') != '000000':
                            logger.error(f"API returned error code: {data.get('code')}")
                            await asyncio.sleep(next_sleep)
                            continue

                        tracking_list = data.get('data', {}).get('tracking', [])
                        if tracking_list:
                            for project in tracking_list:
                                rebate_coin = project.get('rebateCoin', '')
                                if not await self.should_send_alert(rebate_coin):
                                    continue
                                duration = project.get('duration', '')
                                start_time = datetime.fromtimestamp(int(project.get('investStartTime', '0'))/1000).strftime('%Y-%m-%d %H:%M:%S')
                                end_time = datetime.fromtimestamp(int(project.get('mineEndTime', '0'))/1000).strftime('%Y-%m-%d %H:%M:%S')
                                status = project.get('status', '')
                                
                                card_body = {
                                    "header": {
                                        "template": "yellow",
                                        "title": {
                                            "tag": "plain_text",
                                            "content": f"New Binance Launchpad Project: {rebate_coin}"
                                        }
                                    },
                                    "elements": [
                                        {
                                            "tag": "markdown",
                                            "content": f"Duration: {duration} days\nStart Time: {start_time}\nEnd Time: {end_time}\nStatus: {status}"
                                        },
                                        {
                                            "tag": "div",
                                            "text": {
                                                "tag": "lark_md",
                                                "content": f"URL: https://launchpad.binance.com/en/\nSent from {socket.gethostname()} Next Query in {next_sleep / 60:.1f} min"
                                            }
                                        }
                                    ]
                                }
                                self.robot.send_card(self.args.robot_key, card_body=card_body)

                            logger.info(f"Sent alert for {len(tracking_list)} projects")

            except Exception as e:
                logger.error(f"Error making API request: {e}")

            logger.info(f"Next check will be after {next_sleep/3600:.1f} hours")

            await asyncio.sleep(next_sleep)

    async def initialize_redis(self):
        if hasattr(self, 'redis_url'):
            self.redis = await aioredis.from_url(self.redis_url, decode_responses=True)

    def start(self):
        asyncio.set_event_loop(self._ioloop)
        self._ioloop.run_until_complete(self.initialize_redis())
        periodic = self._ioloop.create_task(self.periodic_task())

        try:
            self._ioloop.run_forever()
        finally:
            periodic.cancel()
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()

    def stop(self):
        if self._ioloop:
            self._ioloop.stop()


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Monitor Binance Launchpad projects.')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                          help='Specify the configuration toml file.')
        parser.add_argument('--https_proxy', type=str, help='HTTPS proxy URL')  # Add proxy argument
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                          default='news-bn')
        parser.add_argument('-t', '--test', action='store_true', help='Test mode')

        args = parser.parse_args()
        config = Config(args.config)

        service = BinanceLaunchpadSignal(args, config.data)
        service.start()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        service.stop()
        sys.exit(0)