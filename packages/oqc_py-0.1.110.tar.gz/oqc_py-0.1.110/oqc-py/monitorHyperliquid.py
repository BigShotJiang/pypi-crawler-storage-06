import sys
import os
import random
from datetime import timedelta, datetime

import asyncio
import argparse
import logging
import socket
import json
import aiohttp
import redis

from common import test_decorator
from oqclib.config import Config
from oqclib.robot.lark import LarkMsg, StatusColor
from oqclib.constants import HTTP_USER_AGENT, HTTP_ACCEPT_LANGUAGE
from oqclib.utils import datetime_util

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)

class HyperliquidLiquidationSignal:
    # Class constants
    API_URL = 'https://api-ui.hyperliquid.xyz/info'
    API_ORIGIN = 'https://hypurrscan.io'
    API_REFERER = API_ORIGIN + '/'
    REDIS_KEY = 'p:hl:liquidation:LastAlert'

    def __init__(self, args, config):
        self.args = args
        self.https_proxy = args.https_proxy or os.getenv('HTTPS_PROXY')
        self.robot = LarkMsg(config['lark']['robot'])
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        redis_config = config['redis']['signal']
        self.redis_url = f"redis://:{redis_config['pwd']}@{redis_config['host']}:{redis_config['port']}/{redis_config['db']}"
        self.redis_client = redis.from_url(self.redis_url)

    async def periodic_task(self):
        logger.info("Starting periodic task...")
        headers = {
            'Accept': '*/*',
            'Accept-Language': HTTP_ACCEPT_LANGUAGE,
            'Connection': 'keep-alive',
            'Content-Type': 'application/json',
            'Origin': self.API_ORIGIN,
            'Referer': self.API_REFERER,
            'User-Agent': HTTP_USER_AGENT,
            'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"'
        }

        data = {
            "type": "userFills",
            "user": "0x2e3d94f0562703b25c83308a05046ddaf9a8dd14"
        }

        last_health_check = None
        last_record_time = None
        last_query_time = None

        while True:
            next_sleep = random.uniform(61, 89)

            try:
                async with aiohttp.ClientSession() as session:
                    logger.info(f"Making API request to {self.API_URL}")
                    async with session.post(self.API_URL, headers=headers, json=data, ssl=False, proxy=self.https_proxy) as response:
                        if response.status != 200:
                            logger.error(f"API request failed with status {response.status}")
                            await asyncio.sleep(next_sleep)
                            continue
                        fills = await response.json()
                        if fills and len(fills) > 0:
                            last_record_time = datetime.fromtimestamp(fills[0]['time'] / 1000)
                            last_query_time = datetime.now()

                        for fill in reversed(fills):
                            if 'liquidation' in fill:
                                last_alert_time = self.redis_client.get(self.REDIS_KEY)
                                if last_alert_time and int(last_alert_time) >= fill['time']:
                                    continue

                                size_usd = float(fill['px']) * float(fill['sz'])
                                if size_usd < 100000:
                                    continue

                                self.redis_client.set(self.REDIS_KEY, fill['time'])
                                liquidation = fill['liquidation']
                                card_body = {
                                    "header": {
                                        "template": StatusColor.RED.value,
                                        "title": {
                                            "tag": "plain_text",
                                            "content": test_decorator(f"HyperLiquid Liquidation {fill['coin']}")
                                        }
                                    },
                                    "elements": [
                                        {
                                            "tag": "markdown",
                                            "content": f"**Liquidation Details**\n" +
                                                      f"- Coin: {fill['coin']}\n" +
                                                      f"- Price: {fill['px']}\n" +
                                                      f"- Size: {fill['sz']}\n" +
                                                      f"- SizeUSD: {size_usd:.2f}\n" +
                                                      f"- Direction: {fill['dir']}\n" +
                                                      f"- Liquidated User: {liquidation['liquidatedUser']}\n" +
                                                      f"- Mark Price: {liquidation['markPx']}\n" +
                                                      f"- Method: {liquidation['method']}\n" +
                                                      f"- Time: {datetime.fromtimestamp(fill['time'] / 1000)}"
                                        },
                                        {
                                            "tag": "div",
                                            "text": {
                                                "tag": "lark_md",
                                                "content": f"https://hypurrscan.io/address/0x2e3d94f0562703b25c83308a05046ddaf9a8dd14\n"
                                                           f"🧎🏼‍➡️LiquidatedUser: https://hypurrscan.io/address/{liquidation['liquidatedUser']}\n"
                                                           f"📠 TradeGuide: https://acneiil1bef4.feishu.cn/wiki/H6jQw8bodiWQG5k15W0cqnTmnpb\n"
                                                           f"Sent from {socket.gethostname()} Next Query in {next_sleep / 60:.1f} min"
                                            }
                                        }
                                    ]
                                }

                                self.robot.send_card(self.args.robot_key, card_body=card_body)

            except Exception as e:
                logger.error(f"Error making API request: {e}", exc_info=True)  # Added exc_info for full traceback

            current_time = datetime.now()
            # # Send health check at 10:06 AM daily using cached last record time 
            # if (last_health_check is None or last_health_check.date() < current_time.date()) and \
            #         current_time.hour >= 10 and current_time.minute >= 6 and last_record_time:
            #     try:
            #         time_diff = current_time - last_query_time
            #         status = "WARNING: Data is stale" if time_diff > timedelta(minutes=30) else "Normal"

            #         if time_diff > timedelta(minutes=30):
            #             card_body = {
            #                 "header": {
            #                     "template": StatusColor.RED.value,
            #                     "title": {
            #                         "tag": "plain_text",
            #                         "content": test_decorator("⚠️ HyperLiquid Monitor Alert")
            #                     }
            #                 },
            #                 "elements": [
            #                     {
            #                         "tag": "markdown",
            #                         "content": f"**Status: {status}**\n" +
            #                                    f"- Running on: {socket.gethostname()}\n" +
            #                                    f"- Last record: {last_record_time}\n" +
            #                                    f"- Last query age: {time_diff.total_seconds() / 60:.1f} minutes"
            #                     }
            #                 ]
            #             }
            #             self.robot.send_card(self.args.robot_key, card_body=card_body)
            #         else:
            #             message = f"HyperLiquid Monitor is running on {socket.gethostname()}\nLast record time: {last_record_time}"
            #             self.robot.send_msg(self.args.robot_key, message)

            #         last_health_check = current_time
            #     except Exception as e:
            #         logger.error(f"Error in health check: {e}", exc_info=True)

            await asyncio.sleep(next_sleep)

    def start(self):
        logger.info("Starting service...")
        asyncio.set_event_loop(self._ioloop)
        periodic = self._ioloop.create_task(self.periodic_task())
        logger.info("Created periodic task")

        try:
            logger.info("Starting event loop")
            self._ioloop.run_forever()
        finally:
            logger.info("Shutting down...")
            periodic.cancel()
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()
            logger.info("Shutdown complete")

    def stop(self):
        if self._ioloop:
            self._ioloop.stop()


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Hyperliquid Liquidation Monitor')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                          help='Specify the configuration toml file.')
        parser.add_argument('--https_proxy', type=str, help='HTTPS proxy URL')
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                          default='hyperliquid')

        args = parser.parse_args()
        config = Config(args.config)

        service = HyperliquidLiquidationSignal(args, config.data)
        service.start()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        service.stop()
        sys.exit(0)