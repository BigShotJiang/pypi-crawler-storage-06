import sys
import socket
import asyncio
import logging
import time
from datetime import datetime
from ccxt.async_support.base.exchange import Exchange
import ccxt.async_support as ccxt
import json
import redis.asyncio as aioredis

from oqclib.config import Config
from oqclib.robot.lark import LarkMsg, StatusColor
import oqclib.utils.datetime_util as datetime_util
import pandas as pd

from oqclib.utils.crypto_symbol_util import get_coin_and_quote_ccy_from_ccxt_symbol, get_exchange_url_for_perpetual

logger = logging.getLogger(__name__)
LOG_FORMAT = ('%(levelname) -10s %(asctime)s '
              '-8s %(lineno) -5d: %(message)s')
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)

def format_time_period(minutes:int) -> str:
    if minutes < 60:
        return f"{minutes}m"  # Minutes
    elif minutes == 60:
        return "1H"  # 1 Hour
    elif minutes < 1440:
        hours = minutes // 60
        return f"{hours}H"  # Hours
    elif minutes == 1440:
        return "1D"  # 1 Day
    elif minutes < 10080:
        days = minutes // 1440
        return f"{days}D"  # Days
    elif minutes < 43200:
        weeks = minutes // 10080
        return f"{weeks}W"  # Weeks
    else:
        months = minutes // 43200
        return f"{months}M"  # Months


class MACDDivergenceSignal:
    def __init__(self, args):
        self.args = args

        self.config = Config(args.config).data
        self.redis = None
        if 'redis' in self.config and 'signal' in self.config['redis']:
            redis_config = self.config['redis']['signal']
            self.redis_url = f"redis://:{redis_config['pwd']}@{redis_config['host']}:{redis_config['port']}/{redis_config['db']}"

        self.MAX_NUM_CANDLES = 400
        self.all_candle_sticks = {}
        self.tasks = {}
        self.exchange = 'okx'
        self.exchange_cli = ccxt.okx({})
        self.robot = LarkMsg(self.config['lark']['robot'])

    async def load_config_from_redis(self, period):
        key = f"p:macd:{period}:config"
        try:
            json_str = await self.redis.get(key)
            if json_str:
                config = json.loads(json_str)
                return config  # Return the entire JSON object
        except Exception as e:
            logger.error(f"Error loading config from Redis {key}: {e}")
        return {"symbols": []}

    async def load_symbols_from_redis(self, period):
        key = f"p:macd:{period}:symbols:*"
        try:
            symbols = []
            cursor = 0
            while True:
                keys = await self.redis.scan(cursor, match=key, count=100)
                if keys[1]:
                    symbols.extend([k.split(':')[-1] for k in keys[1]])
                if keys[0] == 0:
                    break
                cursor = keys[0]
            return symbols
        except Exception as e:
            logger.error(f"Error loading config from Redis {key}: {e}")
        return []

    async def fetch_candlesticks(self, symbol: str, period: int, look_back_minutes: int):
        bar_period = format_time_period(period)

        result = []
        now_ms = int(time.time() * 1000)
        from_ms = now_ms - look_back_minutes * 60 * 1000

        while True:
            limit = 100
            to_ms = from_ms + limit * period * 60 * 1000

            try:
                logger.info(
                    f"Requesting {symbol} {bar_period} from {datetime.fromtimestamp(from_ms / 1000)} to {datetime.fromtimestamp(to_ms / 1000)}")
                candles = await self.exchange_cli.publicGetMarketMarkPriceCandles({
                    'instId': symbol,
                    'bar': bar_period,
                    'limit': 100,
                    'before': from_ms,
                    'after': to_ms
                })

                if candles['code'] != '0':
                    logger.error(f"Error fetching candlesticks: {candles['msg']}")
                    break
                candles['data'].reverse()
                result.extend(candles['data'])
            except Exception as e:
                logger.error(f"Error fetching candlesticks: {e}")
                break

            if to_ms >= now_ms:
                break
            from_ms = to_ms
            # await asyncio.sleep(RATE_LIMIT_SLEEP_20_PER_2 / 1000)  # Convert milliseconds to seconds

        # result.reverse()
        return result

    def detect(self, symbol: str, period: int, candle_sticks, fast_period=12, slow_period=26, signal_period=9):
        from oqclib.indicators.macd_dvgc import detect_macd_divergence, is_death_cross, is_golden_cross, populate_macd_fields
        from oqclib.indicators.model import DivergenceType

        # Convert to DataFrame
        df = pd.DataFrame(candle_sticks, columns=['timeMs', 'open', 'high', 'low', 'close', 'volume'])
        df['open'] = df['open'].astype(float)
        df['high'] = df['high'].astype(float)
        df['low'] = df['low'].astype(float)
        df['close'] = df['close'].astype(float)
        df['timeMs'] = pd.to_datetime(df['timeMs'].astype('Int64'), unit='ms')
        df.drop(columns=['volume'], inplace=True)
        df.set_index('timeMs', inplace=True)

        populate_macd_fields(df, fast_period, slow_period, signal_period)

        # df.to_csv(f"macd_{symbol}_{period}__{df.index[-1].strftime('%Y-%m-%d_%H-%M-%S')}.csv")
        dvgc = detect_macd_divergence(df)
        last_px = df.iloc[-1]['close']
        logger.info(f"MACD Divergence Signal for {symbol} {period}m len {len(df)} dvgc {dvgc} LastPx {last_px}")

        coin, qccy = get_coin_and_quote_ccy_from_ccxt_symbol(self.exchange, symbol)
        url = get_exchange_url_for_perpetual(self.exchange, coin, qccy) if coin else ""
        if dvgc == DivergenceType.BEARISH:
            self.robot.send_msg(self.args.robot_key, self.test_decorator(f"{symbol} {period}m 顶背离 LastPx {last_px}\n{url}"))
        elif dvgc == DivergenceType.BULLISH:
            self.robot.send_msg(self.args.robot_key, self.test_decorator(f"{symbol} {period}m 底背离 LastPx {last_px}\n{url}"))
        elif period > 30 or (self.args.short_period_alert and not datetime_util.is_midnight()):
            cross = is_death_cross(df)
            if cross:
                logger.info(f"{symbol} {period}m Death Cross {df.tail(5)[['close', 'dif', 'dea']]}")
                self.robot.send_msg(self.args.robot_key, self.test_decorator(f"{symbol} {period}m Death Cross. LastPx {last_px}\n{url}"))
            cross = is_golden_cross(df)
            if cross:
                logger.info(f"{symbol} {period}m Golden Cross {df.tail(5)[['close', 'dif', 'dea']]}")
                self.robot.send_msg(self.args.robot_key, self.test_decorator(f"{symbol} {period}m Golden Cross. LastPx {last_px}\n{url}"))

        if self.args.draw:
            import mplfinance as mpf
            apds = [mpf.make_addplot(df['dif'], panel=1, color='fuchsia', title="MACD", linewidths=1),
                    mpf.make_addplot(df['dea'], panel=1, color='b', linewidths=1)]

            mpf.plot(df, type='candle', style='charles', title='Candlestick Chart with MACD', ylabel='Price',
                     addplot=apds,
                     savefig={
                         'fname': f"{symbol}_{period}_macd.png",
                         'dpi': 300,  # Resolution of the figure
                         'bbox_inches': 'tight'  # Optional parameter to fit the layout tightly
                     })

    def test_decorator(self, message: str) -> str:
        return ("[TEST] " if self.args.test else "") + message

    async def initialize_redis(self):
        if hasattr(self, 'redis_url'):
            self.redis = await aioredis.from_url(self.redis_url, decode_responses=True)
            
    async def start(self):
        await self.initialize_redis()
        if not self.args.test:
            status_report_task = asyncio.create_task(run_interactively(0,
                                                                       3600 * 24,
                                                                       3600 * 10 + 392,
                                                                       self.status_report,
                                                                       self.args.robot_key,
                                                                       self.test_decorator(
                                                                           f"Divergence for {self.args.symbols} {self.args.periods} running on {socket.gethostname()}")))
            self.tasks["status_report"] = status_report_task
        while True:
            for period in self.args.periods:
                if period not in self.tasks:
                    self.tasks[period] = {}
                if period not in self.all_candle_sticks:
                    self.all_candle_sticks[period] = {}

                symbols = self.args.symbols if self.args.symbols else await self.load_symbols_from_redis(period)
                # Create a list of symbols to remove to avoid modifying dict during iteration
                symbols_to_remove = []
                for symbol, task in self.tasks[period].items():
                    if symbol not in symbols:
                        logger.info(f"Stopping task for {symbol} {period}")
                        task.cancel()
                        symbols_to_remove.append(symbol)
                
                # Remove the tasks after iteration
                for symbol in symbols_to_remove:
                    self.tasks[period].pop(symbol)

                for symbol in symbols:
                    if symbol in self.all_candle_sticks[period]:
                        continue

                    try:
                        look_back_minutes = period * self.MAX_NUM_CANDLES
                        candlesticks = await self.fetch_candlesticks(symbol, period, look_back_minutes)
                        logger.info(f"Fetched candlesticks for {symbol} {period} {len(candlesticks)}")
                        # if has_gui():
                        #     self.plot(candlesticks)
                        self.all_candle_sticks[period][symbol] = candlesticks
                        period_in_s = period * 60
                        initial_delay_s = datetime_util.seconds_to_next_interval(datetime.now(), period_in_s)
                        if initial_delay_s < 3:
                            initial_delay_s = initial_delay_s + period_in_s
                        else:
                            candlesticks.pop(-1)
                        if self.args.test:
                            initial_delay_s = 1
                        # initial_delay_s = 3
                        logger.info(f"Adding task for {symbol} {period}")
                        self.tasks[period][symbol] = asyncio.create_task(run_interactively(initial_delay_s, period_in_s, 0, self.fetch_ticker, symbol, period))
                    except Exception as e:
                        logger.error(f"Error fetching candlesticks: {symbol} {e}")

            await asyncio.sleep(60)

        # self.gather = asyncio.gather(*self.tasks)
        # await self.gather

    async def status_report(self, robot_key: str, msg: str) -> bool:
        try:
            self.robot.send_msg(robot_key, msg)
        except:
            pass

        return True

    async def fetch_ticker(self, symbol: str, period: int) -> bool:
        candle_sticks = self.all_candle_sticks[period][symbol]
        for i in range(3):
            try:
                ticker = await self.exchange_cli.fetch_ticker(symbol)
                # 2024-04-18 17:41:00,779 - __main__ - INFO - Got ticker BTC-USDT at {'symbol': 'BTC/USDT', 'timestamp': 1713433260013, 'datetime': '2024-04-18T09:41:00.013Z', 'high': 63440.7, 'low': 59632.6, 'bid': 61460.6, 'bidVolume': 0.93629273, 'ask': 61460.7, 'askVolume': 0.74162674, 'vwap': 61328.72579282822, 'open': 63434.6, 'close': 61460.6, 'last': 61460.6, 'previousClose': None, 'change': -1974.0, 'percentage': -3.1118663946805056, 'average': 62447.6, 'baseVolume': 20777.61654493, 'quoteVolume': 1274264747.7125428, 'info': {'instType': 'SPOT', 'instId': 'BTC-USDT', 'last': '61460.6', 'lastSz': '0.006293', 'askPx': '61460.7', 'askSz': '0.74162674', 'bidPx': '61460.6', 'bidSz': '0.93629273', 'open24h': '63434.6', 'high24h': '63440.7', 'low24h': '59632.6', 'volCcy24h': '1274264747.712542803', 'vol24h': '20777.61654493', 'ts': '1713433260013', 'sodUtc0': '61274.5', 'sodUtc8': '60295.9'}}
                #logger.info(f"Got ticker {symbol} {ticker}")
                info = ticker['info']
                # mid_px = str((float(info['askPx']) + float(info['bidPx'])) / 2)
                mid_px = str((float(ticker['ask']) + ticker['bid']) / 2)
                logger.info(
                    f"* Got ticker {symbol} period {period}m at {datetime.fromtimestamp(ticker['timestamp'] / 1000)} {info} mid_px {mid_px} i {i}")
                candle_sticks.append([info['ts'], mid_px, mid_px, mid_px, mid_px, 0])
                while len(candle_sticks) > self.MAX_NUM_CANDLES:
                    candle_sticks.pop(0)

                # logger.info(f"Candlestick chart for {symbol} {period}m {candle_sticks[-2:]}")
                self.detect(symbol, period, candle_sticks)
                return True
            except Exception as e:
                logger.error(f"Error fetching ticker for the {i} time {period}", exc_info=True)
        logger.error(f"Failed to get ticker for {symbol} after 3 attempts")
        await asyncio.sleep(600)
        self.gather.cancel()
        return False


async def run_interactively(initial_delay_s: float, period_s: float, time_offset_s: float, async_func: callable, *args):
    logger.info(
        f"Running {async_func.__name__} every {period_s} seconds with initial delay of {initial_delay_s} seconds and args {args}")
    """ Wait for the specified delay and then call the given function with provided arguments. """
    await asyncio.sleep(initial_delay_s)

    try:
        while True:
            should_continue = await async_func(*args)
            if not should_continue:
                break
            wait_s = datetime_util.seconds_to_next_interval(datetime.now(), period_s)
            await asyncio.sleep(wait_s + time_offset_s)
    except asyncio.CancelledError:
        logger.info(f"Task {async_func.__name__} cancelled")
    except Exception as e:
        logger.error(f"Error running {async_func.__name__}", exc_info=True)


async def close(exchange: Exchange):
    await exchange.close()
    await asyncio.sleep(0.1)


if __name__ == '__main__':
    try:
        import argparse

        parser = argparse.ArgumentParser(description="Divergence")
        parser.add_argument('-c', '--config', type=str, default="/etc/oqc/config2.toml")
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                            default='macd')

        parser.add_argument('--symbols', nargs='+', help='symbols to watch')
        parser.add_argument('-p', '--periods', nargs='+', help='Periods in minutes to watch', type=int, default=[15, 60, 240, 1440])
        parser.add_argument('-f', '--fast', type=int, default=12)
        parser.add_argument('-s', '--slow', type=int, default=26)
        parser.add_argument('-t', '--test', action='store_true', help='Test mode')
        parser.add_argument('--short_period_alert', action='store_true', help='Send alerts for MACD cross for periods <= 30min')

        parser.add_argument('--draw', action='store_true', help='Output the candlestick chart')

        prog_args = parser.parse_args()

        logger.info(f"Watching symbols: {prog_args.symbols} with periods: {prog_args.periods}")
        macd = MACDDivergenceSignal(prog_args)
        asyncio.run(macd.start())

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        sys.exit(0)

