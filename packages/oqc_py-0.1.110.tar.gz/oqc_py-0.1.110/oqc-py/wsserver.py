import sys
import pika
from pika.adapters.asyncio_connection import AsyncioConnection
import asyncio
import argparse
import json
import logging
import socket
import websockets
import functools
from websockets.frames import OP_TEXT
from websockets.connection import State
from collections import defaultdict
from oqclib.config import Config

LOG_FORMAT = ('%(levelname) -10s %(asctime)s '
              ': %(message)s')
logger = logging.getLogger(__name__)

def get_symbol_from_routing_key(routing_key:str) -> str:
    return routing_key.split('.')[-1]
    
class WSAMQPForwarder:
    def __init__(self, config):
        self.requestExchange = config['amqpStructure']['exchanges']['request']['name']
        self.quoteExchange = config['amqpStructure']['exchanges']['quote']['name']
        self.listenQueue = "wsserver-%s" % socket.gethostname()
        self.credentials = pika.PlainCredentials(
            config['amqpServer']['user'], config['amqpServer']['password'])
        self.connectionParams = pika.ConnectionParameters(
            config['amqpServer']['host'], config['amqpServer']['port'], config['amqpServer']['vhost'], self.credentials)
        self.host = config['wsServer']['host']
        self.port = config['wsServer']['port']
        self.clients:set[websockets.WebSocketServerProtocol] = set({})
        self.subscribers = defaultdict(set)
        self.log_quote_throttle = 0

        # Copied from https://github.com/pika/pika/blob/10cbe33a1ab36f6da984fc2f5eb1ebdd83eced27/examples/asyncio_consumer_example.py
        self.should_reconnect = False
        self.was_consuming = False

        self._connection = None
        self._channel = None
        self._closing = False
        self._consumer_tag = None
        self._consuming = False
        # In production, experiment with higher prefetch values
        # for higher consumer throughput
        self._prefetch_count = 1
        self._ioloop:asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self._message_throttle_count = 30

    def broadcast(self, symbol, message):
        for websocket in self.subscribers[symbol]:
            if websocket.state is not State.OPEN:
                continue

            if websocket._fragmented_message_waiter is not None:
                raise RuntimeError("busy sending a fragmented message")

            self._ioloop.call_soon(functools.partial(websocket.write_frame_sync, True, OP_TEXT, message))
            # await websocket.send(True, opcode, data)
       #asyncio.ensure_future(websockets.broadcast(self.clients, decodedBody))


    def on_message_callback(self, ch, method, properties, body):
        symbol = get_symbol_from_routing_key(method.routing_key)
        if self.log_quote_throttle % self._message_throttle_count == 0:
            #decodedBody = body.decode("utf-8")
            json_msg = json.loads(body)
            logger.info("Rcvd {} AMQP msgs, last {} {}".format(self._message_throttle_count, symbol, json_msg['last']))
        self.log_quote_throttle += 1
        self.broadcast(symbol, body)

    def connect(self):
        logger.info('Connecting to %s', self.connectionParams)
        return AsyncioConnection(
            parameters=self.connectionParams,
            on_open_callback=self.on_connection_open,
            on_open_error_callback=self.on_connection_open_error,
            on_close_callback=self.on_connection_closed,
            custom_ioloop=self._ioloop)

    def open_channel(self):
        logger.info('Creating a new channel')
        self._connection.channel(on_open_callback=self.on_channel_open)

    def on_channel_open(self, channel):
        logger.info('Channel opened')
        self._channel:pika.channel.Channel = channel
        self.add_on_channel_close_callback()
        self.setup_queue(self.listenQueue)

    def add_on_channel_close_callback(self):
        logger.info('Adding channel close callback')
        self._channel.add_on_close_callback(self.on_channel_closed)

    def on_channel_closed(self, channel, reason):
        logger.warning('Channel %i was closed: %s', channel, reason)
        self.close_connection()

    def setup_queue(self, queue_name):
        logger.info('Declaring queue %s', queue_name)
        cb = functools.partial(self.on_queue_declareok, userdata=queue_name)
        self._channel.queue_declare(queue=queue_name, callback=cb, durable=True, auto_delete=True)

    def on_queue_declareok(self, _unused_frame, userdata):
        queue_name = userdata
        logger.info('Binding %s to %s ', self.quoteExchange, queue_name)
        cb = functools.partial(self.on_bindok, userdata=queue_name)
        #self._channel.basic_publish(self.requestExchange, 'sub.future.domestic', 'ag2306,au2306,ss2304')
        self._channel.queue_bind(
            exchange=self.quoteExchange, queue=queue_name, routing_key="quote.stock.domestic.*", callback = cb)
        self._channel.queue_bind(
            exchange=self.quoteExchange, queue=queue_name, routing_key="quote.future.domestic.*")    

    def on_bindok(self, _unused_frame, userdata):
        logger.info('Queue bound: %s', userdata)
        self.set_qos()

    def set_qos(self):
        self._channel.basic_qos(
            prefetch_count=self._prefetch_count, callback=self.on_basic_qos_ok)

    def on_basic_qos_ok(self, _unused_frame):
        logger.info('QOS set to: %d', self._prefetch_count)
        self.start_consuming()

    def start_consuming(self):
        logger.info('Issuing consumer related RPC commands')
        self.add_on_cancel_callback()
        self._channel.basic_consume(queue=self.listenQueue, on_message_callback=self.on_message_callback, auto_ack=True)

        # self._consumer_tag = self._channel.basic_consume(
        #     self.QUEUE, self.on_message)
        self.was_consuming = True
        self._consuming = True

    def add_on_cancel_callback(self):
        logger.info('Adding consumer cancellation callback')
        self._channel.add_on_cancel_callback(self.on_consumer_cancelled)

    def on_consumer_cancelled(self, method_frame):
        logger.info('Consumer was cancelled remotely, shutting down: %r',
                    method_frame)
        if self._channel:
            self._channel.close()
            
    def close_connection(self):
        self._consuming = False
        if self._connection.is_closing or self._connection.is_closed:
            logger.info('Connection is closing or already closed')
        else:
            logger.info('Closing connection')
            self._connection.close()

    def on_connection_open(self, _unused_connection):
        logger.info('Connection opened')
        self.open_channel()

    def on_connection_open_error(self, _unused_connection, err):
        logger.error('Connection open failed: %s', err)
        self.reconnect()

    def on_connection_closed(self, _unused_connection, reason):
        self._channel = None
        if self._closing:
            self._connection.ioloop.stop()
        else:
            logger.warning('Connection closed, reconnect necessary: %s', reason)
            self.reconnect()

    def on_message(self, _unused_channel, basic_deliver, properties, body):
        logger.info('Received message # %s from %s: %s',
                    basic_deliver.delivery_tag, properties.app_id, body)
        self.acknowledge_message(basic_deliver.delivery_tag)

    def acknowledge_message(self, delivery_tag):
        logger.info('Acknowledging message %s', delivery_tag)
        self._channel.basic_ack(delivery_tag)

    def stop_consuming(self):
        if self._channel:
            logger.info('Sending a Basic.Cancel RPC command to RabbitMQ')
            cb = functools.partial(
                self.on_cancelok, userdata=self._consumer_tag)
            self._channel.basic_cancel(self._consumer_tag, cb)

    def on_cancelok(self, _unused_frame, userdata):
        self._consuming = False
        logger.info(
            'RabbitMQ acknowledged the cancellation of the consumer: %s',
            userdata)
        self.close_channel()

    def close_channel(self):
        logger.info('Closing the channel')
        self._channel.close()

    def run_amqp_subscriber(self):
        self._connection = self.connect()

    def stop(self):
        if not self._closing:
            self._closing = True
            logger.info('Stop consuming AMQP')
            if self._consuming:
                self.stop_consuming()
                self._ioloop.run_forever()
            else:
                self._ioloop.stop()
            logger.info('Stopped consuming AMQP')

    def reconnect(self):
        self.should_reconnect = True
        self.stop()

    async def wsserver_listen(self):
        logger.info("Start listen to WS %s %d", self.host, self.port)
        await websockets.serve(self.websocket_consumer, self.host, self.port)
        # async with websockets.serve(self.websocket_consumer, self.host, self.port):
        #     await asyncio.Future() 

    def start(self):
        logger.info("Start listen to {} {}".format(self.host, self.port))
        self.run_amqp_subscriber()
        asyncio.set_event_loop(self._ioloop)

        # await self.wsserver_listen()
        asyncio.gather(
            self.wsserver_listen()
        )
        try:
            self._ioloop.run_forever()
        finally:
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()
            
    async def subscribe_market(self, websocket, message_type, decoded: dict):
        symbols = decoded['data']
        subscription = ",".join([p for p in symbols if not p.startswith("es_")])
        logger.info("Subscribe market %s %s", message_type, subscription)

        self._channel.basic_publish(self.requestExchange, message_type, subscription)

        for symbol in symbols:
            self.subscribers[symbol] |= {websocket}

    async def process_decoded_message(self, websocket, decoded: dict):
        message_type = decoded['type']
        split = message_type.split(".")
        if split[0] == 'sub' and len(split) == 3:
            await self.subscribe_market(websocket, message_type, decoded)

        else:
            logger.error("Unknown message type: %s", decoded['type'])

    async def websocket_consumer(self, websocket, path):
        # Define a callback function for incoming messages

        # Consume messages from the queue and call the callback function
        logger.info("A client connected")
        try:
            self.clients.add(websocket)
            async for message in websocket:
                logger.info("Get Msg {}".format(message))
                decoded = json.loads(message)
                await self.process_decoded_message(websocket, decoded)
        finally:
            logger.info("Remove WS client connection %s", websocket)
            self.clients.remove(websocket)
            for symbol in self.subscribers:
                self.subscribers[symbol] -= {websocket}

if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Quote Center Forwarder.')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                            help='Specify the configuration toml file.')

        args = parser.parse_args()
        config = Config(args.config)

        logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)
        service = WSAMQPForwarder(config.data)

        service.start()
        # asyncio.run(service.start())
        #asyncio.get_event_loop().run_forever()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        sys.exit(0)
