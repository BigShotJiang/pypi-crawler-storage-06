import sys
import random
from datetime import timedelta, datetime
import asyncio
import argparse
import logging
import ccxt
import socket
import pandas as pd
import redis.asyncio as aioredis
from pandas import Timestamp

from common import test_decorator
from oqclib.config import Config
from oqclib.models.trade import TradingSide
from oqclib.robot.lark import LarkMsg
from oqclib.utils.crypto_symbol_util import get_exchange_url_from_jtp_symbol, jtp_symbol_to_ccxt_symbol, get_exchange_from_jtp_symbol
from tzlocal import get_localzone
import numpy as np
import os

from oqclib.utils.datetime_util import YYYYMMDD_HHMMSS
from oqclib.utils.exchanges import Exchanges, Exchange

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'

logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)

class FailedToReverse:
    @classmethod
    def get_start_datetime(cls, args):
        timestamp = int(datetime.now().timestamp()) - args.look_back_days * 24 * 3600
        timestamp = timestamp - (timestamp % (4 * 3600))  # Round down to nearest 4 hours
        return datetime.fromtimestamp(timestamp)

    @classmethod
    async def load_symbols_from_redis(cls, redis_client) -> dict:
        symbols = {}
        key = "p:reverse:symbols"
        logger.info(f"Loading from redis {key}")
        try:
            json_str = await redis_client.get(key)
            if json_str:
                import json
                data = json.loads(json_str)
                # Process uptrends (SELL signals)
                for symbol in data.get('uptrends', []):
                    symbols[symbol] = {TradingSide.SELL}
                # Process downtrends (BUY signals)
                for symbol in data.get('downtrends', []):
                    if symbol in symbols:
                        symbols[symbol].add(TradingSide.BUY)
                    else:
                        symbols[symbol] = {TradingSide.BUY}
        except Exception as e:
            logger.error(f"Error loading symbols from Redis: {e}")
            
        if not symbols:
            logger.warning("No symbols found in Redis, using default")
            symbols = {'GRIFFAIN-USDT-SWAP.OK': {TradingSide.BUY, TradingSide.SELL}}
        
        return symbols

    @classmethod
    def load_symbols_from_files(cls, args=None):
        symbols = {}

        try:
            symbol_file = cls.get_symbol_file_path(args, 'symbols_failed_reverse_uptrend.txt')
            if os.path.isfile(symbol_file):
                with open(symbol_file, 'r') as f:
                    for line in f:
                        symbol = line.strip()
                        if symbol and not symbol.startswith('#'):
                            symbols[symbol] = {TradingSide.SELL}

            symbol_file = cls.get_symbol_file_path(args, 'symbols_failed_reverse_downtrend.txt')
            if os.path.isfile(symbol_file):
                with open(symbol_file, 'r') as f:
                    for line in f:
                        symbol = line.strip()
                        if symbol and not symbol.startswith('#'):
                            if symbol in symbols:
                                symbols[symbol].add(TradingSide.BUY)
                            else:
                                symbols[symbol] = {TradingSide.BUY}
        except (FileNotFoundError, TypeError):
            logger.warning(f"Using default symbol")
            symbols = {'GRIFFAIN-USDT-SWAP.OK': {TradingSide.BUY, TradingSide.SELL}}
        return symbols

    @classmethod
    def get_symbol_file_path(cls, args, symbol_file_name):
        if args and hasattr(args, 'config'):
            if not isinstance(args.config, (str, bytes, os.PathLike)):
                # For test cases with Mock objects
                symbol_file = os.path.join(os.path.dirname(__file__), symbol_file_name)
            else:
                config_dir = os.path.dirname(os.path.abspath(args.config))
                symbol_file = os.path.join(config_dir, symbol_file_name)
        else:
            symbol_file = os.path.join(os.path.dirname(__file__), symbol_file_name)
        return symbol_file

    # Update the class attribute initialization
    checklist = {}  # Initialize empty first
    
    def __init__(self, args, config):
        self.redis = None

        # Initialize Redis connection only if redis config exists
        if 'redis' in config and 'signal' in config['redis']:
            redis_config = config['redis']['signal']
            self.redis_url = f"redis://:{redis_config['pwd']}@{redis_config['host']}:{redis_config['port']}/{redis_config['db']}"

        if hasattr(args, 'symbols') and args.symbols:
            # Convert list of symbols to dictionary with sets of trading sides
            self.checklist = {}
            for symbol in args.symbols:
                self.checklist[symbol] = {TradingSide.BUY, TradingSide.SELL}
            self.use_arg_symbols = True
        else:
            self.use_arg_symbols = False

        self.args = args
        self.config = config
        self.robot = LarkMsg(config['lark']['robot'])
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self.last_recovery_alert_time = None
        self.recovery_alert_cooldown = timedelta(minutes=15)
        self.break_even_exp_ratio = args.break_even_exp_ratio
        self.trend_exp_threshold = args.trend_exp_threshold

        self.reversal_exp_up = args.reversal_exp_up
        self.reversal_exp_up_target = args.reversal_exp_up_target

        self.reversal_exp_down = args.reversal_exp_down
        self.reversal_exp_down_target = args.reversal_exp_down_target

        self.redis_expiry = 86400 * args.look_back_days * 2
        self.init_exch_clients(args)

    def init_exch_clients(self, args):
        # Use command line proxy if provided, otherwise use environment variable
        https_proxy = args.https_proxy or os.getenv('HTTPS_PROXY')
        # Initialize exchange clients with proxy
        self.okx = ccxt.okx()
        self.okx.options['fetchOHLCV']['timezone'] = 'HK'
        if https_proxy:
            self.okx.proxies = {'https': https_proxy}
        self.bitget = ccxt.bitget({
            'options': {
                'defaultType': 'swap',
            },
        })
        self.bitget.options['fetchOHLCV']['timezone'] = 'HK'
        if https_proxy:
            self.bitget.proxies = {'https': https_proxy}
        self.bybit = ccxt.bybit()
        if https_proxy:
            self.bybit.proxies = {'https': https_proxy}

    async def periodic_task(self):
        while True:
            next_sleep = random.uniform(1418, 1729)

            start_datetime = self.get_start_datetime(args)

            if not self.use_arg_symbols:
                self.checklist = await self.load_symbols_from_redis(self.redis)
            # self.reload_markets()
            logger.info(f"------ Start to find_all, start_datetime {start_datetime} next_sleep {next_sleep}s")

            for symbol, directions in self.checklist.items():
                try:
                    await self.find_all(start_datetime, symbol, directions)
                except Exception as e:
                    logger.error(f"Error making API request: {e}")
                    try:
                        exch = get_exchange_from_jtp_symbol(symbol)
                        exch_cli = self.get_exch_cli(exch)
                        exch_cli.load_markets(reload=True)
                        logger.info(f"Reloaded market for {exch.name}")
                    except:
                        pass


            await asyncio.sleep(next_sleep)

    async def find_all(self, start_date, symbol, directions):
        exch = get_exchange_from_jtp_symbol(symbol)
        exch_cli = self.get_exch_cli(exch)

        ccxt_symbol = jtp_symbol_to_ccxt_symbol(symbol)
        candles = exch_cli.fetch_ohlcv(ccxt_symbol, timeframe='1h',
                                  since=int(start_date.timestamp() * 1000), limit=365 * 2)
        df = pd.DataFrame(candles, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timeMs'] = pd.to_datetime(df['timestamp'], unit='ms', utc=True).dt.tz_convert(str(get_localzone()))
        df['volumeUSD'] = df['volume'] * (df['open'] + df['close']) / 2
        df['volumeUSD_24h'] = df['volumeUSD'].rolling(window=24, min_periods=1).sum()
        if (len(df) > 96):
            latest_volume_24h = df['volumeUSD_24h'].iloc[-2]
            if latest_volume_24h < 5_000_000 and await self.should_send_low_vol_alert(symbol): 
                url = get_exchange_url_from_jtp_symbol(symbol)
                self.robot.send_msg(self.args.robot_key, f"⚠️ Low 24h Volume for {symbol}, consider removing\n"
                                            f"Current 24h VolUSD: ${latest_volume_24h / 1000000:,.2f}mil\n"
                                            f"{url}")

        logger.info(
            f"/* Fetched {symbol} candles from {datetime.fromtimestamp(candles[0][0] / 1000).astimezone().strftime('%Y-%m-%d %H:%M:%S')} to "
            f"{datetime.fromtimestamp(candles[-1][0] / 1000).astimezone().strftime('%Y-%m-%d %H:%M:%S')} "
            f"Lowest {df['low'].min()} -> Highest {df['high'].max()}")

        if TradingSide.SELL in directions:
            uptrends = await self.find_up_trends(df, symbol)
            # Process uptrends
            for idx, trend in enumerate(uptrends, 0):
                logger.info(f"Up trend #{idx} found in {symbol} Start: {trend['start_time']} at {trend['start_price']}"
                            f" Peak: {trend['peak_time']} at {trend['peak_price']} End: {trend['end_time']} at "
                            f"{trend['end_price']} Total gain: {trend['gain'] * 100:.1f}%")

            succeeded, failed_up_trends, in_progress = await self.find_succeeded_and_failed_to_reverse_down(df, uptrends, only_last=False)
            await self.send_trends_notification(symbol, succeeded, "up", True)
            await self.send_trends_notification(symbol, failed_up_trends, "up", False)
            await self.notify_in_progress_trends(symbol, in_progress, "up")

        if TradingSide.BUY in directions:
            downtrends = await self.find_down_trends(df, symbol)
            # Process downtrends
            for idx, trend in enumerate(downtrends, 0):
                logger.info(f"Down trend #{idx} found in {symbol} Start: {trend['start_time']} at {trend['start_price']}"
                            f" Bottom: {trend['bottom_time']} at {trend['bottom_price']} End: {trend['end_time']} at "
                            f"{trend['end_price']} Total drop: {trend['drop'] * 100:.1f}%")

            succeeded, failed_down_trends, in_progress = await self.find_succeeded_and_failed_to_reverse_up(df, downtrends, only_last=False)
            await self.send_trends_notification(symbol, succeeded, "down", True)
            await self.send_trends_notification(symbol, failed_down_trends, "down", False)
            await self.notify_in_progress_trends(symbol, in_progress, "down")

    def get_exch_cli(self, exch: Exchange):
        if exch == Exchanges.OKX:
            return self.okx
        elif exch == Exchanges.BITGET:
            return self.bitget
        elif exch == Exchanges.BYBIT:
            return self.bybit
        else:
            raise ValueError(f"Exchange {exch} not supported")
        return exch_cli

    async def find_up_trends(self, df, symbol) -> list:
        up_trends = []
        i = 0
        move_ratio = np.exp(self.trend_exp_threshold)
        reversal_ratio = np.exp(-self.reversal_exp_down)

        while i < len(df) - 1:
            trend_start_low = df.iloc[i]['low']
            current_low_idx = i

            # Look forward for a 20% increase
            for j in range(i + 1, len(df)):
                if trend_start_low > df.iloc[j]['low'] and (j != i + 1 or df.iloc[j]['close'] > df.iloc[j]['open']):
                    trend_start_low = df.iloc[j]['low']
                    current_high = df.iloc[j]['close']
                    current_low_idx = j
                else:
                    current_high = df.iloc[j]['high']

                if current_high / trend_start_low >= move_ratio:
                    # Found an up trend, now look for its end
                    trend_high = current_high
                    trend_high_idx = j

                    # logger.info(f"Init TrendHigh to {trend_high} at {df.iloc[j]['timeMs']} currLow {trend_start_low} at {df.iloc[current_low_idx]['timeMs']} ")

                    # Look for either a reversal or a new high
                    for k in range(j + 1, len(df)):
                        if ((k != trend_high_idx + 1 or df.iloc[k]['high'] < trend_high)
                                and df.iloc[k]['low'] < trend_high * reversal_ratio):
                            # Found reversal, trend ends
                            up_trends.append({
                                'start_time': df.iloc[current_low_idx]['timeMs'],
                                'start_price': trend_start_low,
                                'peak_time': df.iloc[trend_high_idx]['timeMs'],
                                'peak_price': trend_high,
                                'end_time': df.iloc[k]['timeMs'],
                                'end_price': df.iloc[k]['low'],
                                'gain': (trend_high - trend_start_low) / trend_start_low
                            })
                            i = k - 1  # Continue searching from the reversal point
                            break
                        elif df.iloc[k]['high'] > trend_high:
                            trend_high = df.iloc[k]['high']
                            trend_high_idx = k
                    else:
                        # Reached end of data without reversal
                        up_trends.append({
                            'start_time': df.iloc[current_low_idx]['timeMs'],
                            'start_price': trend_start_low,
                            'peak_time': df.iloc[trend_high_idx]['timeMs'],
                            'peak_price': trend_high,
                            'end_time': df.iloc[-1]['timeMs'],
                            'end_price': df.iloc[-1]['close'],
                            'gain': (trend_high - trend_start_low) / trend_start_low
                        })
                        i = len(df)  # Exit the outer loop
                    break
            i += 1

        return up_trends

    async def find_succeeded_and_failed_to_reverse_down(self, df, uptrends, only_last: bool = False) -> (list, list, list):
        failed_trends = []
        succeeded_trends = []
        in_progress_trends = []

        trends_to_check = [uptrends[-1]] if only_last and uptrends else uptrends
        break_even_ratio = np.exp(-self.reversal_exp_down) * np.exp(-self.break_even_exp_ratio)
        tp_ratio = np.exp(-self.reversal_exp_down) * np.exp(-self.reversal_exp_down_target)

        for idx, trend in enumerate(trends_to_check, 0):
            end_idx = df[df['timeMs'] == trend['end_time']].index[0]
            peak_price = trend['peak_price']
            reversal_target = peak_price * break_even_ratio
            tp_price = peak_price * tp_ratio

            logger.info(f"Up trend {idx}, peak price {peak_price}, reversal target {reversal_target}")

            found_new_high = False
            all_above_target = True

            for i in range(end_idx, len(df)):
                bar = df.iloc[i]

                if bar['high'] > peak_price:
                    found_new_high = True
                    break
                if bar['low'] < reversal_target and (i != end_idx or bar["close"] < bar["open"]):
                    all_above_target = False
                    succeeded_trends.append({**trend, "reversal_target": reversal_target, 'tp_price': tp_price})
                    logger.info(
                        f"   Trend {idx} {bar['timeMs']} low price {bar['low']} < reversal target {reversal_target}")
                    break

            if not all_above_target:
                continue

            if found_new_high:
                failed_trends.append({
                    **trend,
                    'reversal_target': reversal_target,
                    'tp_price': tp_price
                })
            else:
                in_progress_trends.append(trend)

        return succeeded_trends, failed_trends, in_progress_trends

    async def find_down_trends(self, df, symbol) -> list:
        down_trends = []
        i = 0
        move_ratio = np.exp(-self.trend_exp_threshold)
        reversal_ratio = np.exp(self.reversal_exp_up)

        while i < len(df) - 1:
            trend_start_high = df.iloc[i]['high']
            current_high_idx = i

            # Look forward for a significant decrease
            for j in range(i + 1, len(df)):
                if trend_start_high < df.iloc[j]['high'] and (j != i + 1 or df.iloc[j]['close'] < df.iloc[j]['open']):
                    trend_start_high = df.iloc[j]['high']
                    current_low = df.iloc[j]['close']
                    current_high_idx = j
                else:
                    current_low = df.iloc[j]['low']

                if current_low / trend_start_high <= move_ratio:
                    trend_low = current_low
                    trend_low_idx = j

                    # logger.info(f"Init TrendLow to {trend_low} at {df.iloc[j]['timeMs']} currHigh {trend_start_high} at {df.iloc[current_high_idx]['timeMs']} ")

                    # Look for either a reversal up or a new low
                    for k in range(j + 1, len(df)):
                        if ((k != trend_low_idx + 1 or df.iloc[k]['low'] > trend_low)
                                and df.iloc[k]['high'] > trend_low * reversal_ratio):
                            down_trends.append({
                                'start_time': df.iloc[current_high_idx]['timeMs'],
                                'start_price': trend_start_high,
                                'bottom_time': df.iloc[trend_low_idx]['timeMs'],
                                'bottom_price': trend_low,
                                'end_time': df.iloc[k]['timeMs'],
                                'end_price': df.iloc[k]['high'],
                                'drop': (trend_start_high - trend_low) / trend_start_high
                            })
                            i = k - 1
                            break
                        elif df.iloc[k]['low'] < trend_low:
                            # logger.info(f"Update2 low to {df.iloc[k]['timeMs']} last trend_low {trend_low}")

                            trend_low = df.iloc[k]['low']
                            trend_low_idx = k
                    else:
                        down_trends.append({
                            'start_time': df.iloc[current_high_idx]['timeMs'],
                            'start_price': trend_start_high,
                            'bottom_time': df.iloc[trend_low_idx]['timeMs'],
                            'bottom_price': trend_low,
                            'end_time': df.iloc[-1]['timeMs'],
                            'end_price': df.iloc[-1]['close'],
                            'drop': (trend_start_high - trend_low) / trend_start_high
                        })
                        i = len(df)
                    break
            i += 1
        return down_trends

    async def find_succeeded_and_failed_to_reverse_up(self, df, downtrends, only_last: bool = False) -> (list, list, list):
        failed_trends = []
        succeeded_trends = []
        in_progress_trends = []

        trends_to_check = [downtrends[-1]] if only_last and downtrends else downtrends
        break_even_ratio = np.exp(self.reversal_exp_up) * np.exp(self.break_even_exp_ratio)
        tp_ratio = np.exp(self.reversal_exp_up) * np.exp(self.reversal_exp_up_target)

        for idx, trend in enumerate(trends_to_check, 0):
            end_idx = df[df['timeMs'] == trend['end_time']].index[0]
            bottom_price = trend['bottom_price']
            reversal_target = bottom_price * break_even_ratio
            tp_price = bottom_price * tp_ratio

            logger.info(f"Down trend {idx}, bottom price {bottom_price}, reversal target {reversal_target}")

            found_new_low = False
            all_below_target = True

            for i in range(end_idx, len(df)):
                bar = df.iloc[i]

                if bar['low'] < bottom_price:
                    found_new_low = True
                    break
                if bar['high'] > reversal_target and (i != end_idx or bar["close"] > bar["open"]):
                    all_below_target = False
                    succeeded_trends.append({**trend, "reversal_target": reversal_target, 'tp_price': tp_price})
                    logger.info(
                        f"Down trend {idx} {bar['timeMs']} high price {bar['high']} > reversal target {reversal_target}")
                    break

            if not all_below_target:
                continue

            if found_new_low:
                failed_trends.append({
                    **trend,
                    'reversal_target': reversal_target,
                    'tp_price': tp_price
                })
            else:
                in_progress_trends.append(trend)

        return succeeded_trends, failed_trends, in_progress_trends
    
    async def notify_in_progress_trends(self, symbol: str, trends: list, trend_type: str):
        for trend in trends:
            time_key = 'peak_time' if trend_type == 'up' else 'bottom_time'
            price_key = 'peak_price' if trend_type == 'up' else 'bottom_price'

            logger.info(f"{symbol} {trend_type} trend in progress, {time_key.split('_')[0].title()}: {trend[time_key]} at {trend[price_key]}")

            url = get_exchange_url_from_jtp_symbol(symbol)

            if await self.should_send_in_progress_alert(symbol, trend_type, trend['start_time']):
                card_body = {
                    "header": {
                        "template": "green" if trend_type == 'up' else 'red',
                        "title": {
                            "tag": "plain_text",
                            "content": test_decorator(f"{symbol} {trend_type.title()} Trend Formed 💪")
                        }
                    },
                    "elements": [
                        {
                            "tag": "markdown",
                            "content": f"{trend_type.title()} Trend started at {trend['start_time']} of {trend['start_price']}\n"
                                       f"{price_key.split('_')[0].title()} Price so far {trend[price_key]} at {trend[time_key]}"
                        },
                        {
                            "tag": "div",
                            "text": {
                                "tag": "lark_md",
                                "content": f"URL: {url}\nSent from {socket.gethostname()}"
                            }
                        }
                    ]
                }
                self.robot.send_card(self.args.robot_key, card_body=card_body)

    async def send_trends_notification(self, symbol, trends, trend_type, true_success_false_failure: bool):
        sof = "SUCCEEDED 💖" if true_success_false_failure else "Failed 🤮"
        # if len(trends) == 0:
        #     logger.info(f"No {sof} to reverse {trend_type} trend found in {symbol}")
        #     return

        for trend in trends:
            time_key = 'peak_time' if trend_type == 'up' else 'bottom_time'
            price_key = 'peak_price' if trend_type == 'up' else 'bottom_price'

            logger.info(f"{trend_type} trend {sof} to reverse {symbol}:")
            logger.info(f"  Start: {trend['start_time']} at {trend['start_price']}")
            logger.info(f"  {time_key.split('_')[0].title()}: {trend[time_key]} at {trend[price_key]}")
            logger.info(f"  End: {trend['end_time']} at {trend['end_price']}")
            logger.info(f"  Reversal target: {trend['reversal_target']}")

            url = get_exchange_url_from_jtp_symbol(symbol)

            if await self.should_send_alert(symbol, trend[time_key]):
                card_body = {
                    "header": {
                        "template": "green" if trend_type == 'up' else 'red',
                        "title": {
                            "tag": "plain_text",
                            "content": test_decorator(f"{symbol} {trend_type.title()} Trend {sof} To Reverse")
                        }
                    },
                    "elements": [
                        {
                            "tag": "markdown",
                            "content": f"{price_key.split('_')[0].title()} Price {trend[price_key]} at {trend[time_key]} \n Target1: {trend['reversal_target']}\n Target2: {trend['tp_price']}"
                        },
                        {
                            "tag": "div",
                            "text": {
                                "tag": "lark_md",
                                "content": f"URL: {url}\nSent from {socket.gethostname()}"
                            }
                        }
                    ]
                }
                self.robot.send_card(self.args.robot_key, card_body=card_body)

    async def initialize_redis(self):
        if hasattr(self, 'redis_url'):
            self.redis = await aioredis.from_url(self.redis_url, decode_responses=True)

    async def should_send_low_vol_alert(self, symbol) -> bool:
        if not self.redis:
            return True

        key = f"p:reverse:LowVol:{symbol}"
        try:
            exists = await self.redis.exists(key)
            if not exists:
                await self.redis.setex(key, 2 * 86400, "1")
                return True
            return False
        except Exception as e:
            logger.error(f"Error checking redis key {key}: {e}")
            return True

    async def should_send_in_progress_alert(self, symbol, trend_type: str, start_time: Timestamp) -> bool:
        if not self.redis:
            return True

        str_time = start_time.strftime(YYYYMMDD_HHMMSS)
        key = f"p:reverse:{symbol}:ongoing_{trend_type}:{str_time}"
        try:
            exists = await self.redis.exists(key)
            if not exists:
                await self.redis.setex(key, self.redis_expiry, "1")
                return True
            return False
        except Exception as e:
            logger.error(f"Error checking redis key {key}: {e}")
            return True

    async def should_send_alert(self, symbol, peak_or_bottom_time: Timestamp) -> bool:
        if not self.redis:
            return True

        str_time = peak_or_bottom_time.strftime(YYYYMMDD_HHMMSS)
        key = f"p:reverse:{symbol}:{str_time}"
        try:
            exists = await self.redis.exists(key)
            if not exists:
                await self.redis.setex(key, self.redis_expiry, "1")
                return True
            return False
        except Exception as e:
            logger.error(f"Error checking redis key {key}: {e}")
            return True

    def start(self):
        asyncio.set_event_loop(self._ioloop)
        # Initialize Redis connection
        self._ioloop.run_until_complete(self.initialize_redis())

        # if not self.checklist:
        #     # Fall back to loading from file
        #     self.checklist = self._ioloop.run_until_complete(self.load_symbols_from_redis(self.redis))

        periodic = self._ioloop.create_task(self.periodic_task())

        try:
            self._ioloop.run_forever()
        finally:
            periodic.cancel()
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()

    def stop(self):
        if self._ioloop:
            self._ioloop.stop()


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Find failed to reverse trends ')
        # Add new argument before other arguments
        parser.add_argument('--look_back_days', type=int, default=5,
                          help='Number of days to look back for analysis. Default: 5')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                            help='Specify the configuration toml file.')
        parser.add_argument('--https_proxy', type=str, help='HTTPS proxy URL')
        parser.add_argument('--redis_url', type=str, help='Redis URL')
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                            default='reverse')
        parser.add_argument('-t', '--test', action='store_true', help='Test mode')
        parser.add_argument('--trend_exp_threshold', type=float, default=0.182,
                            help='Uptrend threshold ratio. Default: 0.182 (20%%)')
        parser.add_argument('--reversal_exp_up', type=float, default=0.0953,
                            help='Reverse up ratio threshold from down trend. Default: 0.0953 (10%% price up)')
        parser.add_argument('--reversal_exp_up_target', type=float, default=0.0953,
                            help='Reversal up TP Price change ratio. Default: 0.0953 (10%% price up)')
        parser.add_argument('--reversal_exp_down', type=float, default=0.105,
                            help='Reverse down ratio threshold from up trend. Default: 0.105 (10%% price down)')
        parser.add_argument('--reversal_exp_down_target', type=float, default=0.105,
                            help='Reversal down TP Price change ratio. Default: 0.105 (10%% price down)')
        parser.add_argument('-b', '--break_even_exp_ratio', type=float, default=0.045,
                            help='Break even exponential ratio. Default: 0.045')
        parser.add_argument('--symbols', nargs='+', type=lambda s: s.split(','),
                            help='List of symbols to monitor (e.g., BTC-USDT-SWAP.OK ETH-USDT-SWAP.OK)')
        args = parser.parse_args()

        config = Config(args.config)

        service = FailedToReverse(args, config.data)
        service.start()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        service.stop()  # Add this line to properly stop the service
        sys.exit(0)
