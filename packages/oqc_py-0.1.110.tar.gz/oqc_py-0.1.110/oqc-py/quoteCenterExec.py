#!/usr/bin/env python3
import pika
import sys
import argparse
import json
import logging
import subprocess
import socket
import time

LOG_FORMAT = ('%(levelname) -10s %(asctime)s - %(funcName) '
              '-8s %(lineno) -5d: %(message)s')
LOGGER = logging.getLogger(__name__)

safeExectable = set({'makeSpreadCandleSticks'})


class AmqpHandler:
    def __init__(self, config):
        self.requestExchange = config['amqpStructure']['exchanges']['request']['name']
        self.responseExchange = config['amqpStructure']['exchanges']['response']['name']
        self.listenQueue = "Executor-%s" % socket.gethostname()
        self.credentials = pika.PlainCredentials(
            config['amqpServer']['user'], config['amqpServer']['password'])
        self.connectionParams = pika.ConnectionParameters(
            config['amqpServer']['address'], config['amqpServer']['port'], config['amqpServer']['vhost'], self.credentials)

    def callback(self, ch, method, porperites, body):
        body = body.decode("utf-8")
        LOGGER.info("[x] %r:%r" % (method.routing_key, body))
        try:
            execInfo = json.loads(body)
            routingKey = method.routing_key
            if execInfo["exec"] not in safeExectable:
                LOGGER.warning(
                    "Unsafe executable request. %s. Discard it." % execInfo["exec"])
                ch.basic_ack(method.delivery_tag)
                return
            try:
                start = time.time()
                command = "bin/%s.sh" % execInfo["exec"]
                args = execInfo["args"]
                LOGGER.info("Executing: %s %s" % (command, args))
                exitCode = subprocess.call([command, args])
                elapsed = (time.time() - start)
                LOGGER.info("Execution result: %d" % exitCode)
                execInfo["exitCode"] = exitCode
                execInfo["execTime"] = elapsed
            except OSError as e:
                LOGGER.warning(e)
                execInfo["exitCode"] = 1
            execInfo["originExec"] = execInfo.pop("exec")

            ch.basic_publish(self.responseExchange,
                             routingKey, json.dumps(execInfo))
        except ValueError as e:
            LOGGER.warning(e)
        finally:
            ch.basic_ack(method.delivery_tag)

    def run(self):
        self.connection = pika.BlockingConnection(self.connectionParams)
        self.channel = self.connection.channel()
        result = self.channel.queue_declare(self.listenQueue, durable=True)
        self.listenQueue = result.method.queue
        self.channel.queue_bind(
            exchange=self.requestExchange, queue=self.listenQueue, routing_key="exec")
        self.channel.basic_consume(
            self.listenQueue, on_message_callback=self.callback, auto_ack=False)
        LOGGER.setLevel(logging.INFO)
        LOGGER.info("Start working.")
        self.channel.start_consuming()


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Quote Center Executor.')
        parser.add_argument('-c', '--config', type=str, metavar="ConfigFile.json", default="etc/config.json",
                            help='Specify the configuration file.')

        args = parser.parse_args()
        with open(args.config, 'r') as content:
            config = json.load(content)

        logging.basicConfig(level=logging.WARNING, format=LOG_FORMAT)
        ah = AmqpHandler(config)
        ah.run()
    except KeyboardInterrupt:
        LOGGER.info("Exiting. ")
        sys.exit(0)
