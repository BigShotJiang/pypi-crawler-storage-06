import argparse
import logging

import requests
import time
import socket

from datetime import datetime, timedelta
from oqclib.config import Config
from oqclib.robot.lark import LarkMsg

# Define global array of keywords
KEYWORDS = ["delist"]  # Example keywords
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', force=True)

def convert_to_hk_time(timestamp_ms):
    # Convert milliseconds since epoch to seconds
    timestamp_s = timestamp_ms / 1000
    # Create a datetime object from the timestamp
    utc_time = datetime.utcfromtimestamp(timestamp_s)
    # Add 8 hours to convert to Hong Kong time
    hk_time = utc_time + timedelta(hours=8)
    # Format the time as a string
    return hk_time.strftime('%Y-%m-%d %H:%M:%S')

class NewsCrawler:
    def __init__(self, url, args):
        self.args = args
        self.config = Config(args.config)
        self.url = url
        self.robot = LarkMsg(self.config.data['lark']['robot'])
        self.first_time = False
        self.headers = {
            "Accept-Language": "en-US,en;q=0.9"  # Example Accept-Language header
        }
        self.seen_sorts = set()
        self.hostname = socket.gethostname()


    def fetch_and_process_data(self):
        current_time_since_epoch_ms = int(time.time() * 1000)
        url = f"{self.url}?t={current_time_since_epoch_ms}"

        try:
            response = requests.get(url, headers=self.headers, timeout=5)
            logger.info(f"Checking {url} get {response.status_code}")
            if response.status_code == 200:
                # logger.info(response.text)
                json_data = response.json()
                self.process_json_data(json_data)
            else:
                logger.info(f"Failed to fetch data: {response.status_code}")
            self.first_time = False

        except requests.Timeout:
            logger.error("Request timed out. Please try again later.")
            self.robot.send_msg(self.args.robot_key, f"NewsScrawler Request timeout {self.hostname}, Update hosts file!")
            time.sleep(1200)
        except requests.RequestException as e:
            logger.error(f"An error occurred: {e}")
            self.robot.send_msg(self.args.robot_key, f"NewsScrawler Erorr happened on {self.hostname}. Check it!")
            time.sleep(1200)

    def process_json_data(self, json_data):
        messages = []
        if json_data["code"] == 0:
            notices = json_data["data"]["notices"]
            for notice in notices:
                key = notice["link"]
                if key not in self.seen_sorts:
                    if any(keyword.lower() in notice["title"].lower() for keyword in KEYWORDS):
                        hk_time = convert_to_hk_time(notice["startTime"])
                        title = notice["title"]
                        message = f" * {title} | Time {hk_time}"
                        logger.info(f"Found news {message} {key}")
                        messages.append(message)
                        self.seen_sorts.add(key)
        else:
            logger.info(f"Invalid JSON data: {json_data}")

        if not self.first_time and len(messages) > 0:
            alert = '\n'.join(messages) + "\n by: " + self.hostname

            self.robot.send_msg(self.args.robot_key, alert)


def main():
    parser = argparse.ArgumentParser(description="Monitor news from OKX and send alert")
    parser.add_argument("--interval", type=int, help="The interval in seconds between each fetch", default=77)
    parser.add_argument('-c', '--config', type=str, default="/etc/oqc/config2.toml")
    parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                        default='news-ok')

    args = parser.parse_args()
    news_crawler = NewsCrawler("https://www.okx.com/v2/support/home/web", args)

    while True:
        news_crawler.fetch_and_process_data()
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
