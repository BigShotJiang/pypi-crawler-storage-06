import sys
import os
import random
from datetime import timedelta, datetime

import asyncio
import argparse
import logging
import socket
import aiohttp
import redis
import html2text

from common import test_decorator
from oqclib.config import Config
from oqclib.robot.lark import LarkMsg, StatusColor
from oqclib.constants import HTTP_USER_AGENT, HTTP_ACCEPT_LANGUAGE

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)

class GateCapSignal:
    # Class constants
    API_URL = 'https://www.gate.io/api-price/api/inner/v3/price/getArticleMulti'
    API_ORIGIN = 'https://www.gate.io'
    API_REFERER = API_ORIGIN + '/zh/price'
    REDIS_KEY_PREFIX = 'p:gate:recap:'
    REDIS_TTL = 7 * 24 * 3600  # 7 days in seconds

    def get_redis_key(self, data_tab, show_time):
        timestamp = int(datetime.strptime(show_time, '%Y-%m-%d %H:%M:%S').timestamp())
        return f"{self.REDIS_KEY_PREFIX}{data_tab}:{timestamp}"

    def __init__(self, args, config):
        self.args = args
        self.https_proxy = args.https_proxy or os.getenv('HTTPS_PROXY')
        self.robot = LarkMsg(config['lark']['robot'])
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        redis_config = config['redis']['signal']
        self.redis_url = f"redis://:{redis_config['pwd']}@{redis_config['host']}:{redis_config['port']}/{redis_config['db']}"
        self.redis_client = redis.from_url(self.redis_url)
        self.html_converter = html2text.HTML2Text()
        self.html_converter.ignore_links = False

    async def periodic_task(self):
        logger.info("Starting periodic task...")
        headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': HTTP_ACCEPT_LANGUAGE,
            'Connection': 'keep-alive',
            'Content-Type': 'application/json',
            'Origin': self.API_ORIGIN,
            'Referer': self.API_REFERER,
            'User-Agent': HTTP_USER_AGENT,
            'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"'
        }

        params = {
            'data_tabs': '1083001,1083002',
            'lang': 'zh'
        }

        while True:
            next_sleep = random.uniform(861, 1089)

            try:
                async with aiohttp.ClientSession() as session:
                    logger.info(f"Making API request to {self.API_URL} next sleep in {next_sleep / 60:.1f} min")
                    async with session.get(self.API_URL, headers=headers, params=params, ssl=False, proxy=self.https_proxy) as response:
                        if response.status != 200:
                            logger.error(f"API request failed with status {response.status}")
                            await asyncio.sleep(next_sleep)
                            continue
                        
                        data = await response.json()
                        if data.get('code') != 0:
                            logger.error(f"API returned error code: {data.get('code')}")
                            await asyncio.sleep(next_sleep)
                            continue

                        articles = data.get('data', [])
                        for article in articles:
                            show_time = article.get('show_time')
                            data_tab = article.get('data_tab')
                            redis_key = self.get_redis_key(data_tab, show_time)
                            
                            if not self.redis_client.get(redis_key):
                                content_html = article.get('content', '')
                                content_md = self.html_converter.handle(content_html)
                                
                                card_body = {
                                    "header": {
                                        "template": StatusColor.YELLOW.value,
                                        "title": {
                                            "tag": "plain_text",
                                            "content": test_decorator(f"Gate.io Market Recap {show_time}")
                                        }
                                    },
                                    "elements": [
                                        {
                                            "tag": "markdown",
                                            "content": content_md
                                        },
                                        {
                                            "tag": "div",
                                            "text": {
                                                "tag": "lark_md",
                                                "content": f"https://www.gate.io/zh/price\nSent from {socket.gethostname()} Next Query in {next_sleep / 60:.1f} min"
                                            }
                                        }
                                    ]
                                }

                                self.robot.send_card(self.args.robot_key, card_body=card_body)
                                self.redis_client.setex(redis_key, self.REDIS_TTL, '1')
                                logger.info(f"Sent alert for article at {show_time}")

            except Exception as e:
                logger.error(f"Error making API request: {e}", exc_info=True)

            await asyncio.sleep(next_sleep)

    def start(self):
        logger.info("Starting service...")
        asyncio.set_event_loop(self._ioloop)
        periodic = self._ioloop.create_task(self.periodic_task())
        logger.info("Created periodic task")

        try:
            logger.info("Starting event loop")
            self._ioloop.run_forever()
        finally:
            logger.info("Shutting down...")
            periodic.cancel()
            loop = self._ioloop
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
            loop.close()
            logger.info("Shutdown complete")

    def stop(self):
        if self._ioloop:
            self._ioloop.stop()


if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Gate.io Market Cap Monitor')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                          help='Specify the configuration toml file.')
        parser.add_argument('--https_proxy', type=str, help='HTTPS proxy URL')
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                          default='news-gate')

        args = parser.parse_args()
        config = Config(args.config)

        service = GateCapSignal(args, config.data)
        service.start()

    except KeyboardInterrupt:
        logger.info("Exiting. ")
        service.stop()
        sys.exit(0)