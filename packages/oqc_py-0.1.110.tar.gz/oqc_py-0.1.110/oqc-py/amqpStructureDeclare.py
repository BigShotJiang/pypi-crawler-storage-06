#!/usr/bin/env python3
import pika
import sys
import argparse
import json
import logging

from twisted.internet import protocol
from twisted.internet.defer import inlineCallbacks
from twisted.internet import reactor
from pika.adapters import twisted_connection

LOG_FORMAT = ('%(levelname) -10s %(asctime)s - %(funcName) '
              '-8s %(lineno) -5d: %(message)s')
LOGGER = logging.getLogger(__name__)


class PikaProtocol(twisted_connection.TwistedProtocolConnection):
    connected = False
    name = 'AMQP:Protocol'

    def __init__(self, factory, parameters):
        super().__init__(parameters)
        self.factory = factory

    def closed(self, reason):
        LOGGER.info("Connection lost %s" % reason)

    @inlineCallbacks
    def connectionReady(self):
        self._channel = yield self.channel()
        self.connected = True
        for exchange in self.factory.exchanges:
            LOGGER.info("Declaing exchange %s" % exchange["name"])
            t = exchange.get("type", "topic")
            d = exchange.get("durable", False)
            ad = exchange.get("autoDelete", False)
            yield self.declareExchange(exchange["name"], t, d, ad)
        self.close()

    @inlineCallbacks
    def declareExchange(self, exchange, type="topic", durable=True, autoDelete=False):
        if self.connected:
            yield self._channel.exchange_declare(
                exchange=exchange,
                exchange_type=type,
                durable=durable,
                auto_delete=autoDelete)


class PikaFactory(protocol.ReconnectingClientFactory):
    name = 'AMQP:Factory'

    def __init__(self, service, parameters, exchanges):
        self.service = service
        self.connParameters = parameters
        self.amqpClient = None
        self.exchanges = exchanges

    def buildProtocol(self, addr):
        self.resetDelay()
        LOGGER.info('Connected')
        self.amqpClient = PikaProtocol(self, self.connParameters)
        return self.amqpClient

    def clientConnectionLost(self, connector, reason):
        LOGGER.info('Connection lost. Reason: %s' % reason)
        self.service.stop()

    def clientConnectionFailed(self, connector, reason):
        LOGGER.info('Connection failed. Reason: %s' % reason)
        protocol.ReconnectingClientFactory.clientConnectionFailed(
            self, connector, reason)


class AMQPService:
    def __init__(self, config):
        self.config = config
        self.exchanges = []
        self.credentials = pika.PlainCredentials(
            config['amqpServer']['user'], config['amqpServer']['password'])
        self.connectionParams = pika.ConnectionParameters(
            config['amqpServer']['address'], config['amqpServer']['port'], config['amqpServer']['vhost'], self.credentials)
        for _, exchange in self.config['amqpStructure']['exchanges'].items():
            self.exchanges.append(exchange)

    def run(self):
        clientfactory = PikaFactory(
            self, self.connectionParams, self.exchanges)
        reactor.connectTCP(self.connectionParams.host,
                           self.connectionParams.port, clientfactory)
        LOGGER.setLevel(logging.INFO)

        reactor.run()

    def stop(self):
        reactor.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Quote Center RabbitMQ exchange initializer.')
    parser.add_argument('-c', '--config', type=str, metavar="ConfigFile.json", default="etc/config.json",
                        help='Specify the configuration file.')

    args = parser.parse_args()
    with open(args.config, 'r') as content:
        config = json.load(content)

    logging.basicConfig(level=logging.WARNING, format=LOG_FORMAT)

    service = AMQPService(config)
    service.run()
