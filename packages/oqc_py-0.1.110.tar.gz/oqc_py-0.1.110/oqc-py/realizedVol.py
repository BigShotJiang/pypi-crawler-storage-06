import numpy as np
import pandas as pd


if __name__ == "__main__":
    # Example historical price data
    prices = pd.Series([11551, 11480, 11476, 11382, 11256, 11269, 11224, 11195, 11128, 11174, 11222, 11190,
                        11249, 11246, 11316, 12001, 12186, 12792, 13500, 13900, 13799, 14833, 14990, 15436,
                        15576
                        ])

    # Calculate daily returns
    returns = np.log(prices / prices.shift(1))

    # Drop the first NaN value
    returns = returns.dropna()

    # Calculate the variance of daily returns
    variance = np.var(returns, ddof=1)  # ddof=1 for sample variance

    # Calculate the standard deviation (realized volatility)
    realized_volatility = np.sqrt(variance)

    # Annualize the volatility (assuming 252 trading days in a year)
    annualized_volatility = realized_volatility * np.sqrt(252)

    print(f"Realized Volatility: {realized_volatility}")
    print(f"Annualized Realized Volatility: {annualized_volatility}")
