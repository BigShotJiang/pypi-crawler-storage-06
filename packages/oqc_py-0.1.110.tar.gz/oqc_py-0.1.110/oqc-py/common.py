import os


def test_decorator(message: str) -> str:
    fq_env = os.getenv('JTP_FQ_ENV', '')
    if fq_env.endswith("_PRD") or fq_env.endswith("_PRE"):
        return message
    return f"[TEST] {message}"