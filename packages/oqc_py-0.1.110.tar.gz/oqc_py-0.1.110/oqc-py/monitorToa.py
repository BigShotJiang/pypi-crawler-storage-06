import sys
import random
import asyncio
import argparse
import logging
import threading

import websocket
import json

from common import test_decorator
from oqclib.config import Config
from oqclib.robot.lark import LarkMsg

logger = logging.getLogger(__name__)
LOG_FORMAT = ('%(levelname) -10s %(asctime)s - %(funcName) '
              '-8s %(lineno) -5d: %(message)s')
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)


def get_title(json_data: dict) -> str:
    if is_from_twitter(json_data) and 'body' in json_data:
        return json_data['body'][:60] + " " + json_data['title']
        
    if 'title' in json_data:
        return json_data['title']
    elif 'body' in json_data:
        return json_data['body']
    elif 'En' in json_data:
        return json_data['En']
    elif 'Zh' in json_data:
        return json_data['Zh']
    else:
        return json.dumps(json_data)

def should_filter_out(json_data: dict, string_filters: list) -> bool:
    if string_filters and 'title' in json_data:
        if not any(filter in str(json_data['title']) for filter in string_filters):
            logger.info(f"Ignoring message: {json_data['title']}")
            return True

    return False

def is_from_twitter(json_data: dict) -> bool:
    return 'title' in json_data and '(@' in json_data['title'] and json_data['title'].endswith(')')

class TreeOfAlphaMonitor:
    def __init__(self, args, config):
        self.args = args
        self.config = config
        self.robot = LarkMsg(config['lark']['robot'])
        # self.user_robots = {}
        # Initialize user-specific robots if configured
        # if 'user_robots' in config['lark']:
        #     for user, token in config['lark']['user_robots'].items():
        #         self.user_robots[user] = LarkMsg(token)
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self.last_alert_time = None
        self.ws = None
        self.api_key = config['toa']['api_key']
        self._shutdown = False
        self.ignore_list = {"icon", "title", "time", "_id", "show_feed", "show_notif", "body", "delay"}
        self.filters_list_delist = {"elist", "Will Launch"}
        self.title_filters = self.filters_list_delist.copy()
        if hasattr(self.args, 'users') and self.args.users:
            users = self.args.users
            self.title_filters.update(set([f"(@{user})" for user in users]))
            logger.info(f"Title filters {self.title_filters}")


    def get_robot_for_message(self, title: str) -> str:
        # if not self.user_robots:
        #     return self.default_robot
            
        # Extract username from title like "Message @(username)"
        if '(@' in title and title.endswith(')'):
            username = "x_" + title[title.index('(@')+2:-1]
            if username in self.config['lark']['robot']:
                return username
        
        if any(filter in title for filter in self.filters_list_delist) and "hitelist" not in title:
            robot_name = "tree-of-alpha-list-delist"
            if robot_name in self.config['lark']['robot']:
                return robot_name

        return self.args.robot_key

    def on_message(self, ws, message):
        try:
            data = json.loads(message)
            
            if 'time' in data and 'user' in data and len(data) == 2:
                logger.info(f"Received login message: {data}")
                return

            if should_filter_out(data, self.title_filters):
                return

            if 'body' in data:
                body = data['body'].strip()
                # check if body is only an URL
                if body.startswith("http") and " " not in body:
                    logger.info(f"Ignoring message with URL: {body}")
                    return

            # Extract all string fields
            string_fields = []
            if 'body' in data:
                string_fields.append(data['body'])
            for key, value in data.items():
                if key in self.ignore_list:
                    continue
                # Skip lists and objects, include all primitive types
                if not isinstance(value, (list, dict)):
                    string_fields.append(f"{key.capitalize()}: {value}")

            # Join all string fields with newlines
            message_content = "\n".join(string_fields)
            logger.info(f"Received Message: {message_content}")
            
            title = get_title(data)
            
            # Get appropriate robot based on the message
            robot_key = self.get_robot_for_message(title)
            
            card_body = {
                "header": {
                    "template": "blue",
                    "title": {
                        "tag": "plain_text",
                        "content": test_decorator(title)
                    }
                },
                "elements": [
                    {
                        "tag": "markdown",
                        "content": message_content
                    }
                ]
            }
            # logger.info(f"Sending message to Lark: {robot_key} {title}")
            self.robot.send_card(robot_key, card_body=card_body)
        except Exception as e:
            logger.error(f"Error processing message: {e}", exc_info=True)

    def on_error(self, ws, error):
        logger.error(f"WebSocket error: {error}")

    def on_close(self, ws, close_status_code, close_msg):
        logger.info(f"WebSocket connection closed: {close_status_code} - {close_msg}")

    def on_open(self, ws):
        logger.info("WebSocket connection established")
        ws.send(f"login {self.api_key}")

    async def start_websocket(self):
        while True:
            try:
                if self._shutdown:
                    break
                    
                self.ws = websocket.WebSocketApp(
                    "wss://news.treeofalpha.com/ws",
                    on_open=self.on_open,
                    on_message=self.on_message,
                    on_error=self.on_error,
                    on_close=self.on_close,
                    on_ping=self.on_ping,
                    on_pong=self.on_pong
                )
                
                # Run WebSocket with ping_interval and ping_timeout
                ws_thread = threading.Thread(
                    target=lambda: self.ws.run_forever(
                        ping_interval=30,  # Send ping every 30 seconds
                        ping_timeout=10    # Wait 10 seconds for pong response
                    )
                )
                ws_thread.daemon = True
                ws_thread.start()
                
                while ws_thread.is_alive() and not self._shutdown:
                    await asyncio.sleep(1)
                
                if self._shutdown:
                    self.ws.close()
                    break
                
                next_sleep = random.uniform(5, 15)
                logger.info(f"Reconnecting in {next_sleep:.2f} seconds...")
                await asyncio.sleep(next_sleep)
            except Exception as e:
                logger.error(f"Error in WebSocket connection: {e}")
                if not self._shutdown:
                    await asyncio.sleep(5)

    def start(self):
        try:
            asyncio.set_event_loop(self._ioloop)
            self._ioloop.run_until_complete(self.start_websocket())
        except KeyboardInterrupt:
            logger.info("Received shutdown signal...")
        finally:
            self.stop()
            self._ioloop.close()

    def stop(self):
        self._shutdown = True  # Set shutdown flag
        if self.ws:
            self.ws.close()
        if self._ioloop and self._ioloop.is_running():
            self._ioloop.stop()

    def on_ping(self, ws, message):
        # logger.debug("Received ping")
        ws.send(message, websocket.ABNF.OPCODE_PONG)  # Use correct opcode for pong

    def on_pong(self, ws, message):
        pass
        # logger.debug("Received pong")

if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='Monitor Tree of Alpha WebSocket feed')
        parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                          help='Specify the configuration toml file.')
        parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                          default='tree-of-alpha')
        parser.add_argument('-u', '--users', type=lambda s: s.split(','),
                          help='Comma-separated list of X user IDs to monitor (e.g., cz_binance,elonmusk)')
        args = parser.parse_args()

        config = Config(args.config)
        service = TreeOfAlphaMonitor(args, config.data)
        service.start()

    except KeyboardInterrupt:
        logger.info("Shutting down...")
        sys.exit(0)
