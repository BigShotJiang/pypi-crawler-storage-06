#! /usr/bin/python3
from oqclib.config import Config
from datetime import datetime
import argparse
import asyncio
import logging

from website.eastmoney import get_stock_klines
from oqclib.indicators.macd_dvgc import (
    populate_macd_fields, is_death_cross, is_golden_cross,
    is_bearish_divergence, is_bullish_divergence
)
import pandas as pd
from oqclib.robot.lark import LarkMsg

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'

logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)

def parse_args():
    parser = argparse.ArgumentParser(description='Monitor MACD signals for stocks')
    parser.add_argument('-c', '--config', type=str, default='/etc/oqc/config2.toml', help='Config file path')
    parser.add_argument('-r', '--robot-key', type=str, default='ashare', help='Lark robot key')
    parser.add_argument('-s', '--symbols', type=str, default='1.000300',
                       help='Comma-separated list of symbols (e.g., "1.000300,0.399001")')
    return parser.parse_args()

class AShareMACDSignal:
    def __init__(self, config, robot_key, symbols):
        self.config = config
        self.robot = LarkMsg(config['lark']['robot'])
        self.robot_key = robot_key
        
        # Parse symbols and percent thresholds: symbol:percent format
        self.symbols = []
        self.ema_thresholds = {}  # symbol -> percentage threshold
        
        for item in [s.strip() for s in symbols.split(',')]:
            if ':' in item:
                symbol, percent = item.rsplit(':', 1)
                try:
                    percent_val = float(percent)
                    self.symbols.append(symbol)
                    self.ema_thresholds[symbol] = percent_val
                except ValueError:
                    # Invalid percentage, treat as regular symbol
                    self.symbols.append(item)
            else:
                self.symbols.append(item)

    async def check_symbol(self, symbol: str):
        try:
            klines = await get_stock_klines(symbol, limit=180)
            df = klines
            populate_macd_fields(df, ma_type='ema')
            
            # Calculate 20-day EMA
            ema_20 = df['close'].ewm(span=20, adjust=False).mean()
            current_ema = ema_20.iloc[-1]
            
            stock_name = df['name'].iloc[0]
            current_close = df['close'].iloc[-1]
            macd = df['dif'].iloc[-1] - df['dea'].iloc[-1]
            pre_macd = df['dif'].iloc[-2] - df['dea'].iloc[-2]
            pre2_macd = df['dif'].iloc[-3] - df['dea'].iloc[-3]
            
            # Check EMA price alert
            if symbol in self.ema_thresholds:
                percent = self.ema_thresholds[symbol]
                price_diff_percent = (current_close - current_ema) / current_ema * 100
                
                if price_diff_percent >= percent:
                    alert_message = f"{stock_name} Price Alert: Close {current_close:.2f} is {price_diff_percent:.2f}% above 20-day EMA {current_ema:.2f}"
                    logger.info(alert_message)
                    self.robot.send_msg(self.robot_key, alert_message)
                else:
                    logger.info(f"{stock_name} Close {current_close:.2f} is {price_diff_percent:.2f}% above 20-day EMA {current_ema:.2f}, which < {percent:.2f}")
            
            if is_bearish_divergence(df, nth=0):
                card = {
                    "config": {
                        "wide_screen_mode": True
                    },
                    "elements": [{
                        "tag": "markdown",
                        "content": f"**{stock_name} Bearish Divergence Alert**\n"
                                 f"Time: {df['date'].iloc[-1]}\n"
                                 f"Close: {df['close'].iloc[-1]:.2f}\n"
                                 f"MACD: {macd:.4f}\n"
                                 f"PreMACD: {pre_macd:.4f}"
                    }],
                    "header": {
                        "template": "red",
                        "title": {
                            "content": f"🔻 {stock_name} Bearish Divergence",
                            "tag": "plain_text"
                        }
                    }
                }
                logger.info(f"{stock_name} Bearish Divergence detected")
                self.robot.send_card(self.robot_key, card)

            elif is_death_cross(df, nth=0):
                message = f"{stock_name} MACD Death Cross at {df['date'].iloc[-1]}\nClose {df['close'].iloc[-1]:.2f}\nMACD {macd:.4f}\nPreMACD {pre_macd:.4f}"
                logger.info(message)
                self.robot.send_msg(self.robot_key, message)
            
            elif is_bullish_divergence(df, nth=0):
                card = {
                    "config": {
                        "wide_screen_mode": True
                    },
                    "elements": [{
                        "tag": "markdown",
                        "content": f"**{stock_name} Bullish Divergence Alert**\n"
                                 f"Time: {df['date'].iloc[-1]}\n"
                                 f"Close: {df['close'].iloc[-1]:.2f}\n"
                                 f"MACD: {macd:.4f}\n"
                                 f"PreMACD: {pre_macd:.4f}"
                    }],
                    "header": {
                        "template": "green",
                        "title": {
                            "content": f"🔺 {stock_name} Bullish Divergence",
                            "tag": "plain_text"
                        }
                    }
                }
                logger.info(f"{stock_name} Bullish Divergence detected")
                self.robot.send_card(self.robot_key, card)

            elif is_golden_cross(df, nth=0):
                message = f"{stock_name} MACD Golden Cross at {df['date'].iloc[-1]}\nClose {df['close'].iloc[-1]:.2f}\nMACD {macd:.4f}\nPreMACD {pre_macd:.4f}"
                logger.info(message)
                self.robot.send_msg(self.robot_key, message)
            elif (pre_macd > pre2_macd and macd < pre_macd and macd > 0):  # Bearish Reversal
                message = f"{stock_name} MACD Bearish Reversal at {df['date'].iloc[-1]}\nClose {df['close'].iloc[-1]:.2f}\nMACD {macd:.4f}\nPreMACD {pre_macd:.4f}\nPre2MACD {pre2_macd:.4f}"
                logger.info(f"{stock_name} MACD Bearish Reversal detected")
                self.robot.send_msg(self.robot_key, message)

            elif (pre_macd < pre2_macd and macd > pre_macd and macd < 0):  # Bullish Reversal
                message = f"{stock_name} MACD Bullish Reversal at {df['date'].iloc[-1]}\nClose {df['close'].iloc[-1]:.2f}\nMACD {macd:.4f}\nPreMACD {pre_macd:.4f}\nPre2MACD {pre2_macd:.4f}"
                logger.info(f"{stock_name} MACD Bullish Reversal detected")
                self.robot.send_msg(self.robot_key, message)
            else:
                logger.info(f"No signals {stock_name} LastDate {df['date_txt'].iloc[-1]} Close {df['close'].iloc[-1]:.2f} DIF {df['dif'].iloc[-1]:.4f} DEA {df['dea'].iloc[-1]:.4f} MACD {macd:.4f} PreDIF {df['dif'].iloc[-2]:.4f} PreDEA {df['dea'].iloc[-2]:.4f} PreMACD {pre_macd:.4f}")

        except Exception as e:
            logger.error(f"Error monitoring {symbol}: {e}", exc_info=True)
            raise

    async def monitor(self):
        tasks = [self.check_symbol(symbol) for symbol in self.symbols]
        await asyncio.gather(*tasks)

async def main():
    args = parse_args()
    config = Config(args.config)
    
    if not args.robot_key:
        logger.error("Robot key is required")
        return
    
    monitor = AShareMACDSignal(config.data, args.robot_key, args.symbols)
    await monitor.monitor()

if __name__ == '__main__':
    asyncio.run(main())