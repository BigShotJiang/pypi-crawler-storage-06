import sys
import random
from datetime import timedelta, datetime
import asyncio
import argparse
import logging
import ccxt
import socket
import json
import redis.asyncio as aioredis

from oqclib.config import Config
from oqclib.robot.lark import LarkMsg, StatusColor
from oqclib.utils.crypto_symbol_util import get_coin_and_quote_ccy_from_ccxt_symbol, get_exchange_url_for_perpetual

logger = logging.getLogger(__name__)
LOG_FORMAT = '%(levelname) -10s %(asctime)s : %(message)s'
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)


class OIChangeSignal:
    def __init__(self, args, config):
        self.args = args
        self.https_proxy = args.https_proxy# or os.getenv('HTTPS_PROXY')
        self.robot = LarkMsg(config['lark']['robot'])
        self.exchange = "binance"
        self._ioloop: asyncio.AbstractEventLoop = asyncio.new_event_loop()

        # Initialize Redis connection
        if 'redis' in config and 'signal' in config['redis']:
            redis_config = config['redis']['signal']
            self.redis_url = f"redis://:{redis_config['pwd']}@{redis_config['host']}:{redis_config['port']}/{redis_config['db']}"
            self.redis = None

        # Initialize Binance client with proxy
        self.exchange_cli = ccxt.binanceusdm()
        if self.https_proxy:
            self.exchange_cli.proxies = {'https': self.https_proxy}

        self.last_oi_values = {}

    async def load_config_from_redis(self):
        key = "p:oi:config"
        try:
            json_str = await self.redis.get(key)
            if json_str:
                config = json.loads(json_str)
                return config  # Return the entire JSON object
        except Exception as e:
            logger.error(f"Error loading config from Redis: {e}")
        return {"OIChangeThresholdUSD": 5000000}  # Return default config

    async def should_send_alert(self, symbol: str) -> bool:
        redis_key = f"p:oi:alert:{symbol}"
        exists = await self.redis.exists(redis_key)
        if exists:
            return False
        await self.redis.setex(redis_key, 10800, "1")  # Store for 24 hours
        return True

    async def periodic_task(self):
        while True:
            next_sleep = random.uniform(10, 20)  
            logger.info(f"Starting new iteration, will sleep for {next_sleep / 60:.1f} minutes after completion")

            try:
                markets = self.exchange_cli.load_markets(reload=True)
                perpetual_symbols = [symbol for symbol in markets.keys() 
                                   if markets[symbol].get('linear') and 
                                   markets[symbol].get('quote') == 'USDT' and
                                   markets[symbol].get('active')]
                logger.info(f"Found {len(perpetual_symbols)} active USDT perpetual markets")

                config = await self.load_config_from_redis()
                threshold = config.get('OIChangeThresholdUSD', 500000)
                ratio_percent_threshold = config.get('OIChangePercent', 10)
                price_change_1h_threshold = config.get('PriceChange1hPercent', 10)
                price_change_24h_threshold = config.get('PriceChange24hPercent', 20)

                black_list = set(config.get('BlackList', []))
                logger.info(f"Using OI change threshold: ${threshold:,.0f}, ratio threshold: {ratio_percent_threshold}%")

                processed_symbols = 0

                for symbol in perpetual_symbols:
                    if symbol in black_list:
                        continue

                    await self.check_symbol(symbol, threshold, ratio_percent_threshold, price_change_1h_threshold, price_change_24h_threshold)

                    processed_symbols += 1
                    if self.args.test and processed_symbols > 10:
                        break
            except Exception as e:
                logger.error(f"Error in periodic task: {e}", exc_info=True)

            await asyncio.sleep(next_sleep)

    async def start(self):
        logger.info("Starting service...")
        self.redis = await aioredis.from_url(self.redis_url)
        try:
            await self.periodic_task()
        finally:
            await self.redis.aclose()

    def run(self):
        asyncio.set_event_loop(self._ioloop)
        try:
            self._ioloop.run_until_complete(self.start())
        except KeyboardInterrupt:
            pass
        finally:
            self._ioloop.close()

    async def check_symbol(self, symbol, threshold, ratio_percent_threshold, price_change_1h_threshold, price_change_24h_threshold):
        open_interest_field = "openInterestAmount"
        try:
            # Fetch price data (25 hours of 1-hour intervals)
            price_data = self.exchange_cli.fetch_ohlcv(symbol, '5m', limit=288)
            if not price_data or len(price_data) < 288:
                logger.info(f"Insufficient price data for {symbol}")
                return

            data_1h_ago = price_data[-12]
            data_24h_ago = price_data[0]    # Close price 24 hours ago

            # Get current price and historical prices
            current_price = price_data[-1][4]  # Close price of latest hour
            price_1h_ago = data_1h_ago[4]   # Close price 1 hour ago
            price_24h_ago = data_24h_ago[4]    # Close price 24 hours ago

            # price_data[-2][4]

            # Calculate price changes
            price_change_1h = (current_price - price_1h_ago) / price_1h_ago
            price_change_24h = (current_price - price_24h_ago) / price_24h_ago

            # Fetch enough data points to cover 3 hours (36 * 5min)
            oi_data = self.exchange_cli.fetchOpenInterestHistory(symbol, '5m', limit=26)
            if not oi_data or len(oi_data) < 26:
                logger.info(f"Insufficient OI data for {symbol}")
                return

            # Get current time rounded down to nearest 5 minutes
            now = datetime.now()
            # current_stick_end_dt = now.replace(minute=(now.minute // 5) * 5, second=0, microsecond=0)
            current_stick_end = int(now.replace(minute=(now.minute // 5) * 5, second=0, microsecond=0).timestamp() * 1000)

            # Find the latest completed stick (15:10:00 in your example)
            last_finished_stick = next((d for d in oi_data if d['timestamp'] == current_stick_end - 300000), None)
            stick_1h_ago = next((d for d in oi_data if d['timestamp'] == current_stick_end - 3900000), None)  # 1 hour earlier

            if not all([last_finished_stick, stick_1h_ago]):
                logger.info(f"Missing required sticks for {symbol}")
                return

            # Calculate changes
            change1 = last_finished_stick[open_interest_field] - stick_1h_ago[open_interest_field]

            # Get current price for USD conversion
            current_price = self.exchange_cli.fetch_ticker(symbol)['last']
            change1_usd = change1 * current_price

            logger.info(f"{symbol} - OIChg ${change1_usd:,.0f} Px {current_price}, Price -1h {price_1h_ago} {datetime.fromtimestamp(data_1h_ago[0]/1000)},"
                        f" Price -24h {price_24h_ago} {datetime.fromtimestamp(data_24h_ago[0]/1000)}")

            if (change1_usd >= threshold and 
                change1 / stick_1h_ago[open_interest_field] > ratio_percent_threshold / 100 and
                abs(price_change_1h) < price_change_1h_threshold / 100 and
                abs(price_change_24h) < price_change_24h_threshold / 100):

                # Get higest price for the last 1h in price_data
                highest_price_1h = max([d[2] for d in price_data[-12:]])
                if current_price < highest_price_1h * 0.95:
                    logger.info(f"But {symbol} current px {current_price} < 95% of 1h highest {highest_price_1h}")
                    return

                if not await self.should_send_alert(symbol):
                    logger.info(f"Skipping duplicate alert for {symbol}")
                    return
                
                coin, quote_ccy = get_coin_and_quote_ccy_from_ccxt_symbol(self.exchange, symbol)
                url = get_exchange_url_for_perpetual(self.exchange, coin, quote_ccy)

                change_type = "Up" if change1_usd > 0 else "Down"
                title = f"{symbol} OI 1h {change_type} ${change1_usd / 1000:,.0f}k Chg% {change1 / stick_1h_ago[open_interest_field] * 100:.1f}%"

                message = f"CurrOI {datetime.fromtimestamp(last_finished_stick['timestamp'] / 1000)} {last_finished_stick[open_interest_field]:,.2f}\n" \
                          f"PrevOI {datetime.fromtimestamp(stick_1h_ago['timestamp'] / 1000)} {stick_1h_ago[open_interest_field]:,.2f}\n" \
                          f"Price {current_price:,.5f}\n \\* Chg1h {price_change_1h*100:.1f}% Px-1h {price_1h_ago:,.5f} 1hHigh {highest_price_1h:.5f}\n \\* Chg24h {price_change_24h*100:.1f}% Px-24h {price_24h_ago:,.5f}\n{url}"

                card_body = {
                    "header": {
                        "template": StatusColor.YELLOW.value,
                        "title": {
                            "tag": "plain_text",
                            "content": title
                        }
                    },
                    "elements": [
                        {
                            "tag": "markdown",
                            "content": message
                        },
                        {
                            "tag": "div",
                            "text": {
                                "tag": "lark_md",
                                "content": f"Sent from {socket.gethostname()}"
                            }
                        }
                    ]
                }
                self.robot.send_card(self.args.robot_key, card_body=card_body)

        except Exception as e:
            logger.error(f"Error processing {symbol}: {e}")
            return


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Binance Perpetual Open Interest Monitor')
    parser.add_argument('-t', '--test', action='store_true', help='Test mode')
    parser.add_argument('-c', '--config', type=str, metavar="config2.toml", default="/etc/oqc/config2.toml",
                      help='Specify the configuration toml file.')
    parser.add_argument('--https_proxy', type=str, help='HTTPS proxy URL')
    parser.add_argument('-r', '--robot_key', help='The key name of Lark robot, defined in config', type=str,
                      default='open-interest-alert')

    args = parser.parse_args()
    config = Config(args.config)

    service = OIChangeSignal(args, config.data)
    service.run()
