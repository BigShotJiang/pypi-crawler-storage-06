from flask import Blueprint

user = Blueprint("user", __name__)
