import "bootstrap/dist/css/bootstrap.css";
import "/AIPscan/static/css/custom.css";

import $ from "jquery";
window.$ = $;
window.jQuery = $;

import "bootstrap";

import Chart from "chart.js/auto";
window.Chart = Chart;
