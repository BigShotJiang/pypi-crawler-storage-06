import "./shared/base_shared.js";

import "/AIPscan/static/js/report.js";
