from .endpoint import SavedLocationsEndpoint
from .schemas import SavedLocation


__all__ = ["SavedLocationsEndpoint", "SavedLocation"]
