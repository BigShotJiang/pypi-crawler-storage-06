from .endpoint import AccountsEndpoint

assert AccountsEndpoint
