
# Erton Security — Unified Kit (v1.0.0)


# Made By DeathAmir

```bash
pip install -e .

pip install '.[gui]'

pip install '.[lua]'
```


```bash
erton-serve --host 127.0.0.1 --port 8765 --policy config/policy.json --guard
```


- EXE (PyInstaller): `tools/build_exe.bat`
- DLL/PYD (Nuitka module): `tools/build_dll.bat`

