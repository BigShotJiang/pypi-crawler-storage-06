from __future__ import annotations
from .. import BRAND, AUTHOR
def brand_text()->str:
    return f"{BRAND} — Powered by {AUTHOR}"
