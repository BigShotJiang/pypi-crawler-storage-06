# sage_setup: distribution = sagemath-cddlib
# delvewheel: patch

from sage.all__sagemath_polyhedra import *
