# Aplicacion de Ventas

Este paquete proporciona funcionalidades para gestionar
ventas, incluyendo cálculos de precios, impuestos y descuentos.

## Instalacion

Puedes instalar el paquete usando:

'''bash
pip install.
"