
# hypersonic/__init__.py
from .hy import main as hy  

__all__ = ["hy"]
__version__ = "0.1.0" # dated 17 Oct 2025



