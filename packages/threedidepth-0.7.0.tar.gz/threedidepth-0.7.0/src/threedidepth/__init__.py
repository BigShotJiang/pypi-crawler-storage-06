# -*- coding: utf-8 -*-

from osgeo.gdal import UseExceptions

from threedidepth.calculate import calculate_waterdepth  # noqa
from threedidepth.calculate import calculate_water_quality  # noqa


UseExceptions()
