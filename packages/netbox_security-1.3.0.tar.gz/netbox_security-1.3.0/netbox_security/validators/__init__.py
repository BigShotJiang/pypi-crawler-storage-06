from .fqdn import validate_fqdn

__all__ = ("validate_fqdn",)
