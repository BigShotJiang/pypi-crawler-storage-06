This module was written to allow you to write email templates in `QWeb view` instead
of QWeb. The advantage here is that with QWeb View, you can make use of
inheritance and the ``call`` statement, which allows you to reuse designs and
snippets in multiple templates, making your development process simpler.
Furthermore, QWeb views are easier to edit with the integrated ACE editor.
