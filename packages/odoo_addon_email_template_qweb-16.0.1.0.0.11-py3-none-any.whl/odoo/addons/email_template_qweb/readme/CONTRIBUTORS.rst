* Holger Brunn <hbrunn@therp.nl>
* Dave Lasley <dave@laslabs.com>
* Carlos Lopez Mite <celm1990@gmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

    * Ernesto Tejeda

* Thomas Fossoul (thomas@niboo.com)
* Phuc Tran Thanh <phuc@trobz.com>
* Foram Shah <foram.shah@initos.com>
* `Trobz <https://trobz.com>`_:
    * Dzung Tran <dungtd@trobz.com>
