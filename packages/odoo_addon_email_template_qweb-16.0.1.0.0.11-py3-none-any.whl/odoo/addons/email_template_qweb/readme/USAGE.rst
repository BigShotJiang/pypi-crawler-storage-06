To use this module, you need to:

#. Select `QWeb View` in the field `Body templating engine`
#. Select a `QWeb View` to be used to render the body field
#. Apart from `QWeb View` standard variables, you also have access to ``object`` and ``email_template``, which are browse records of the current object and the email template in use, respectively.
