# VirtualInput

Cross-platform virtual mouse and keyboard library with ghost coordinates and Bézier curves.

## Installation
```bash
pip install git+https://github.com/off-rkv/Virtual-Input.git