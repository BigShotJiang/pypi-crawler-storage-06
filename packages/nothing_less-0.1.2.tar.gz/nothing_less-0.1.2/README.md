# Nothing-less (nless)

Nless is a TUI paging application that has enhanced support for tabular data - such as inferring file delimiters, delimiter swapping on the fly, filtering, sorting, searching, and real-time event parsing
