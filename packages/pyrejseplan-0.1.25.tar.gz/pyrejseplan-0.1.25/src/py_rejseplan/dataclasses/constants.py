NSMAP = {
    '': 'http://hacon.de/hafas/proxy/hafas-proxy'
}