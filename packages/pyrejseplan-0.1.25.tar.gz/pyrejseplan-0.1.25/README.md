# pyRejseplan
Python implementation for Rejseplanens new API

## Credentials

Make a file called rejseplan.key in your root folder and prepend the key with "KEY: "
The main.py function will parse the file and look for the key. This is required for testing purposes.

## Further work

The package is a work in progress and should be treated as such. There are a lot of potential for improvements in the structure of the package.
Further work includes building functionality to do location searches based on the address or geolocation.
Further improvements could be to have a journey planner feature either as preconfigured or like the one found at journeyplanner.dk.
