from excitationsolve.excitation_solve_pennylane import excitationsolve_pennylane
import time
from pyscf import gto, ao2mo, scf, fci
import pennylane as qml
from pennylane import numpy as np
import scipy
import matplotlib.pyplot as plt

if __name__ == "__main__":
    molname = "H2"
    bondlength = 0.742

    basis = "STO-3G"
    data = qml.data.load("qchem", molname=molname, bondlength=bondlength, basis=basis)
    data = data[0]
    molecule = data.molecule
    H = data.hamiltonian
    electrons = molecule.n_electrons
    charge = molecule.charge
    qubits = molecule.n_orbitals * 2
    fci_energy = data.fci_energy

    wires = range(qubits)

    # Define the HF state
    hf_state = qml.qchem.hf_state(electrons, qubits)

    # Generate single and double excitations
    singles, doubles = qml.qchem.excitations(electrons, qubits)

    # Map excitations to the wires the UCCSD circuit will act on
    s_wires, d_wires = qml.qchem.excitations_to_wires(singles, doubles)

    # Define the initial values of the circuit parameters
    num_params = len(singles) + len(doubles)
    # Define the device
    dev_hf = qml.device("lightning.qubit", wires=qubits)
    dev_excsolve = qml.device("lightning.qubit", wires=qubits)

    @qml.qnode(dev_hf)
    def circuit_hf():
        qml.BasisState(hf_state, wires=range(qubits))
        return qml.expval(H)

    hf_energy = circuit_hf()

    # Define the qnode
    @qml.qnode(dev_excsolve, interface=None)
    def circuit_excsolve(params):
        global singles
        # Fix UCCSD parameter order: first doubles, then singles
        params = np.concatenate([params[len(singles) :], params[: len(singles)]])
        qml.UCCSD(params, wires, s_wires, d_wires, hf_state)
        return qml.expval(H)

    # Define the initial values of the circuit parameters
    params_excsolve = np.zeros(num_params)

    num_samples = 5
    num_vqe_steps = 10

    energies_excsolve = []
    energy_evaluations = (np.arange(num_vqe_steps * num_params) + 1) * 4 - 4

    # Optimize the circuit parameters and compute the energy
    print("Starting ExcitationSolve VQE optimization (starting timer)")
    start_time = time.time()

    current_energy_excsolve = hf_energy
    for n in range(num_vqe_steps):
        params_excsolve, current_energy_excsolve = excitationsolve_pennylane(circuit_excsolve, params_excsolve, num_samples=num_samples)
        energies_excsolve.extend(current_energy_excsolve)

        print(
            f"step = {n}, E_excsolve = {energies_excsolve[-1]:.8f} Ha, Diff. to FCI: {np.abs(energies_excsolve[-1]-fci_energy)}",
            end="\r",
        )

    energies_excsolve = np.array(energies_excsolve)

    end_time = time.time()
    time_s = end_time - start_time
    time_min = time_s / 60
    time_h = time_min / 60
    print(f"Took {time_s:.2f} s/{time_min:.2f} min/{time_h:.2f} h!")
    print(f"E_excsolve = {energies_excsolve[-1]:.8f} Ha, Diff. to FCI: {np.abs(energies_excsolve[-1]-fci_energy)}")

    dev_cobyla = qml.device("lightning.qubit", wires=qubits)

    @qml.qnode(dev_cobyla, interface=None)
    def circuit_cobyla(params):
        qml.UCCSD(params, wires, s_wires, d_wires, hf_state)
        return qml.expval(H)

    params_cobyla = np.zeros(num_params)
    energies_cobyla = []
    count_cobyla = 0

    def cost(weights):
        global count_cobyla
        count_cobyla = count_cobyla + 1
        energy_cobyla = circuit_cobyla(weights)
        energies_cobyla.append(energy_cobyla)
        print(
            f"Iteration {len(energies_cobyla)}, Diff. to FCI: {np.abs(energy_cobyla-fci_energy)}",
            end="\r",
        )
        return energy_cobyla

    print("Starting COBYLA optimization")
    maxiter_cobyla = 1_000_000
    cobyla_res = scipy.optimize.minimize(
        cost,
        x0=params_cobyla,
        method="COBYLA",
        options={"maxiter": maxiter_cobyla},
        tol=1e-13,
    )

    params_cobyla = cobyla_res.x
    cobyla_evaluations = np.arange(len(energies_cobyla))
    print(cobyla_res)

    # Options
    params = {
        "text.usetex": True,
        "font.size": 12,
        "font.family": "lmodern",
        "text.latex.preamble": r"\usepackage{amsmath}",
    }

    plt.rcParams.update(params)

    colors = plt.cm.tab20.colors

    fig, ax = plt.subplots(figsize=(6.7 / 2, 4))
    ax.set_title(f"{molname} $\\vert$ {bondlength} $\\vert$ {basis}")
    ax.set_xlabel(r"\#Energy evaluations [-]")
    ax.set_ylabel("Energy difference to FCI [Ha]")

    label = r"$E_\mathrm{Exc.Solve}$"
    ax.plot(
        energy_evaluations,
        np.abs(fci_energy - energies_excsolve),
        linestyle="-",
        marker=".",
        color=colors[6],
        label=label,
    )

    ax.plot(
        cobyla_evaluations,
        np.abs(fci_energy - energies_cobyla),
        linestyle="-",
        marker=".",
        markersize=4,
        color=colors[8],
        label=r"$E_\mathrm{COBYLA}$",
    )

    ax.set_yscale("log")
    ax.set_yscale("log")

    start_x, end_x = ax.get_xlim()
    start_y, end_y = ax.get_ylim()

    chem_acc = 1e-3  # "chemical accuracy"
    chem_acc_color = plt.cm.tab10.colors[-1]
    chem_acc_alpha = 0.3
    ax.axhspan(
        ymin=0.0,
        ymax=chem_acc,
        color=chem_acc_color,
        alpha=chem_acc_alpha,
        label=r"$\leq$~chem.~acc.",
    )

    ax.set_yscale("log")
    ax.legend(loc="upper right")
    ax.grid(axis="y")

    ax.yaxis.set_minor_locator(plt.NullLocator())

    num_vqe_steps = 100
    lines_1d = np.arange(0, end_x, (num_samples - 1) * num_params)[1 : num_vqe_steps + 1]

    # shaded area in the background every second vqe_step
    shaded_color = plt.cm.tab10.colors[-3]
    shaded_color = "black"
    for x_pos in np.arange(0, end_x, (num_samples - 1) * num_params)[: num_vqe_steps + 1 : 2]:
        plt.axvspan(x_pos, x_pos + (num_samples - 1) * num_params, color=shaded_color, alpha=0.1)
