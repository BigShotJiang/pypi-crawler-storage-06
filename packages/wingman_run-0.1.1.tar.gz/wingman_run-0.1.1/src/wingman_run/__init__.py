"""
Wingman Run - Real-time typo fixer
"""

__version__ = "0.1.1"