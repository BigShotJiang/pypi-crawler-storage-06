.. automodule:: verry.interval
