.. automodule:: verry.optimize
