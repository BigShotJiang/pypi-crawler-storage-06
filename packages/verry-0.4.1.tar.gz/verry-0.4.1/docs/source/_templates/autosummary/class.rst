{{ fullname | escape | underline }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
    :show-inheritance:
    :members:
    :inherited-members:
    :special-members: __call__
    :member-order: groupwise
