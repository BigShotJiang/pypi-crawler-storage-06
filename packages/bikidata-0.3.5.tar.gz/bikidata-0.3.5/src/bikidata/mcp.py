from mcp.server.fastmcp import FastMCP


# List tablenames
# select schema_name from information_schema.schemata where catalog_name = 'bikidata';
