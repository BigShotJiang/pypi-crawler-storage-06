#!/usr/bin/env python3


""" Простой тестовый файл """

import os
import sys

def hello_world():
    print("Hello, World!")

if __name__ == "__main__":
    hello_world()