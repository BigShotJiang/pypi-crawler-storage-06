"""Utility to transfer data from MySQL to SQLite 3."""

__version__ = "2.4.5"

from .transporter import MySQLtoSQLite
