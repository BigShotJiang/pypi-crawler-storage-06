from django.apps import AppConfig


class PostgresLockConfig(AppConfig):
    name = "postgres_lock"
