from .schema import Schema


class String(Schema):
    pass
