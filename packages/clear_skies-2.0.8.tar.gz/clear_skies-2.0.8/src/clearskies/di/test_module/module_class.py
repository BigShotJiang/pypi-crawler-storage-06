import datetime


class ModuleClass:
    pass
