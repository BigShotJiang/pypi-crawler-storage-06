class AnotherModuleClass:
    pass
