## [2.0.8] - 2025-09-22

### Changed
- Move typing import to IF TYPE_CHECKING by @cmancone in [#19](https://github.com/clearskies-py/clearskies/pull/19)
- Move typing import to IF TYPE_CHECKING:

### Fixed
- Importing reorder

