"""Automation helpers for Greeum workflows."""

__all__ = ["workflow", "digest"]
