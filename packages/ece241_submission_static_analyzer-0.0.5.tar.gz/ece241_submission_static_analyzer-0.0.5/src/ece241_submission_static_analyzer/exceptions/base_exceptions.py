
class ECE241StaticAnalyzerException(Exception):
    """Base class for exceptions in the ECE241 static analyzer."""
    pass
