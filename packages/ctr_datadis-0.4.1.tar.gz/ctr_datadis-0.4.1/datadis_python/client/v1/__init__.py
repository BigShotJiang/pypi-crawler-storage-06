"""Cliente Datadis API v1 - Respuestas raw, máxima compatibilidad."""

from .simple_client import SimpleDatadisClientV1 as DatadisClientV1

__all__ = ["DatadisClientV1"]
