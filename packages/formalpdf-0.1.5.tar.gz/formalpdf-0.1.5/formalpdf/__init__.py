from .widget import Document, Page, Widget, Rect, open
