This module links sale_commission with hr module. For now, it only adds
another type of agent whose commissions are not invoiced in the
corresponding wizard.

It also computes the Boolean field "employee" in ResPartner to be
updated according to the ResPartner-HrEmployee relation that was
created.
