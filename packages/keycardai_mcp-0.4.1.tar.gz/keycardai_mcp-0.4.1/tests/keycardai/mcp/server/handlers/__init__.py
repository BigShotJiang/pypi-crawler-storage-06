"""Tests for keycardai.mcp.server.handlers package."""
