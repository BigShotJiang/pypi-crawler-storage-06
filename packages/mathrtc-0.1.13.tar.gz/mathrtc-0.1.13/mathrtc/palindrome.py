def palindrome(a):
    try:
        a = str(a)
        b = a[::-1]
        
        if a == b:
            print("It's palindrome")
        else:
            print("It's not palindrome")
    
    except Exception as e:
        print("Error:", e)