from leanup.utils.config import ConfigManager

def test_init_default_config_dir():
    """Test ConfigManager initialization with default config directory"""
    ConfigManager()