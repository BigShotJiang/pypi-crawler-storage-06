from typing_extensions import Literal, TypeAlias

__all__ = ["TranscriptionInclude"]

TranscriptionInclude: TypeAlias = Literal["logprobs"]
