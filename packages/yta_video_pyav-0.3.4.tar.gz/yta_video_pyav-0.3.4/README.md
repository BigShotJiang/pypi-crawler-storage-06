# Youtube Autonomous Video PyAv Module

The way to handle videos with PyAv.