from pathlib import Path

temp_dir = Path("temp/")
items_dir = temp_dir / "items"
