from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent.parent
TEMP_PATH = Path("temp")
SEQ_PATH = TEMP_PATH / "sequences"
