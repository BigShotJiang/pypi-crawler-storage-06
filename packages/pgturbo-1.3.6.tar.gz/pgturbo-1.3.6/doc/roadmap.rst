Roadmap
=======

Pygame Turbo is an open source project, and as with any such project, the
development roadmap is subject to change.

This document just lays out some goals for future releases, but there is **no
guarantee** that these targets will be hit.


Translations
------------

Pygame Turbo is aimed at young users, whose English skills might not be good
enough to read the documentation if it isn't in their own language.

Adding translations of the documentation would help to bring Pygame Turbo to new
users. This is something that needs contributors to help with. My own language
skills aren't good enough!

Please see :ref:`the translating guide <translating>` if you think you can
help.


Gamepad Support
---------------

.. caution::

    This roadmap item comes from Pygame Zero, meaning the link to the relevant
    issue also leads to the GitHub for Pygame Zero, not Pygame Turbo.

    Gamepad support is actively being worked on by the maintainer of Pygame
    Turbo however, meaning that it will likely be added to Turbo in the near
    future.

Github Issue: `#70 <https://github.com/lordmauve/pgturbo/issues/70>`_

SNES-style gamepads are now extremely cheap. For example, they are sold for
a few pounds from the `Pi Hut`_, in packs of 2 at Amazon_, and even in some
Raspberry Pi bundles.

Gamepad support should not be limited to these specific models; rather, we
should treat this as a lowest-common-denominator across modern gamepads, as
nearly all more modern gamepads have at least as many buttons and axes.

This feature needs to be added in a way that will not **require** a gamepad to
play any Pygame Turbo game, in order to follow the principle of
:ref:`accessibility`.

.. _`Pi Hut`: https://thepihut.com/products/raspberry-pi-compatible-usb-gamepad-controller-snes-style
.. _Amazon: https://www.amazon.co.uk/s/ref=nb_sb_noss_2?url=search-alias%3Delectronics&field-keywords=usb+snes


Surface juggling
----------------

.. caution::

    This roadmap item comes from Pygame Zero, meaning the link to the relevant
    issue also leads to the GitHub for Pygame Zero, not Pygame Turbo.

Github Issue: `#71 <https://github.com/lordmauve/pgturbo/issues/71>`_

Pygame experts make lots of use of off-screen surfaces to create interesting
effects.

Pygame Turbo chose to consider only the screen surface, which we wrap with
a richer ``Screen`` API for drawing, etc.

The problem is that there is no easy path to using additional surfaces -
Pygame Turbo immediately becomes dead weight as you start to look past that
curtain.

We should look to smooth out this path to make Pygame Turbo Actors and Screen
work better with custom surfaces.
