def draw():
    screen.fill('green')
