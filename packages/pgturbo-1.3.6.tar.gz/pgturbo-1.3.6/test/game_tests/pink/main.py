def draw():
    screen.fill('pink')
