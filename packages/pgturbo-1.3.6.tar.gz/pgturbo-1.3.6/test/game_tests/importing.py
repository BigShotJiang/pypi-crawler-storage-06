import helper

assert helper.RECT


def draw():
    helper.circle()
