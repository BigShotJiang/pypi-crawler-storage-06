def draw():
    screen.fill('blue')
