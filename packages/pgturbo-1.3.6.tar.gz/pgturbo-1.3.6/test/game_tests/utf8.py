WIDTH = HEIGHT = 300


def draw():
    '''😂'''
    screen.fill('blue')
    screen.draw.text('foo', color='white', center=(150, 150))
