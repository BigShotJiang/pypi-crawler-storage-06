def draw():
    screen.fill('red')
