
RECT = ZRect(30, 30, 40, 40)


def circle():
    screen.draw.circle((50, 50), radius=20, color='cyan')
