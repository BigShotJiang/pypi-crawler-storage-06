def on_mouse_down(pos, button):
    print("You clicked the", button.name.lower(), "mouse button at", pos)
