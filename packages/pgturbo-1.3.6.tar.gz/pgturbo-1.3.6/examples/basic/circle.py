def draw():
    screen.clear()
    screen.draw.circle((400, 300), 30, 'white')
