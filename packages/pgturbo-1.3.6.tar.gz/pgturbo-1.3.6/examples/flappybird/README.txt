Flappy Bird

    by Max00355
    via https://github.com/Max00355/FlappyBird
    ported to pgzero by Daniel Pope
