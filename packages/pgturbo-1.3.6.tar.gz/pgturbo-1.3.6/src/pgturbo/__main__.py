from pgturbo.runner import main

main()
