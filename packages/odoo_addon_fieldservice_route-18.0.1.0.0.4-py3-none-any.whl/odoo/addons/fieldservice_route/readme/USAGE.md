To use this module, you need to:

- Go to Field Service
- Create or select an order
- Assign it to a worker and schedule it
- Go to Field Service \> Dashboard \> Day Routes. A new record has been
  created.
