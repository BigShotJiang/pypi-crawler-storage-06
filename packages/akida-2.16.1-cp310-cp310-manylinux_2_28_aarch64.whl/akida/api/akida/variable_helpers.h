#pragma once

#include "akida/dense.h"

namespace akida {

int evaluate_bitwidth(const Dense& dense);

}  // namespace akida
