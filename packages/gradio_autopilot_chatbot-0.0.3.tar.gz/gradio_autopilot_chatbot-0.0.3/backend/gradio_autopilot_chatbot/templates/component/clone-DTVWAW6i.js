import { b as r } from "./_baseUniq-_Utf515a.js";
var e = 4;
function a(o) {
  return r(o, e);
}
export {
  a as c
};
