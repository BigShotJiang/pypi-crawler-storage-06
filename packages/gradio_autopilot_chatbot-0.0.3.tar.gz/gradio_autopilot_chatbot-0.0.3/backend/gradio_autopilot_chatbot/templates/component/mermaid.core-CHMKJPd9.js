var Gm = Object.defineProperty;
var Xm = (e, t, r) => t in e ? Gm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var gt = (e, t, r) => Xm(e, typeof t != "symbol" ? t + "" : t, r);
import { g as Vm, c as Zm } from "./Index-I0QmpPNJ.js";
var zl = {
  name: "mermaid",
  version: "11.11.0",
  description: "Markdown-ish syntax for generating flowcharts, mindmaps, sequence diagrams, class diagrams, gantt charts, git graphs and more.",
  type: "module",
  module: "./dist/mermaid.core.mjs",
  types: "./dist/mermaid.d.ts",
  exports: {
    ".": {
      types: "./dist/mermaid.d.ts",
      import: "./dist/mermaid.core.mjs",
      default: "./dist/mermaid.core.mjs"
    },
    "./*": "./*"
  },
  keywords: [
    "diagram",
    "markdown",
    "flowchart",
    "sequence diagram",
    "gantt",
    "class diagram",
    "git graph",
    "mindmap",
    "packet diagram",
    "c4 diagram",
    "er diagram",
    "pie chart",
    "pie diagram",
    "quadrant chart",
    "requirement diagram",
    "graph"
  ],
  scripts: {
    clean: "rimraf dist",
    dev: "pnpm -w dev",
    "docs:code": "typedoc src/defaultConfig.ts src/config.ts src/mermaid.ts && prettier --write ./src/docs/config/setup",
    "docs:build": "rimraf ../../docs && pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts",
    "docs:verify": "pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts --verify",
    "docs:pre:vitepress": "pnpm --filter ./src/docs prefetch && rimraf src/vitepress && pnpm docs:code && tsx scripts/docs.cli.mts --vitepress && pnpm --filter ./src/vitepress install --no-frozen-lockfile --ignore-scripts",
    "docs:build:vitepress": "pnpm docs:pre:vitepress && (cd src/vitepress && pnpm run build) && cpy --flat src/docs/landing/ ./src/vitepress/.vitepress/dist/landing",
    "docs:dev": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:dev:docker": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev:docker" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:serve": "pnpm docs:build:vitepress && vitepress serve src/vitepress",
    "docs:spellcheck": 'cspell "src/docs/**/*.md"',
    "docs:release-version": "tsx scripts/update-release-version.mts",
    "docs:verify-version": "tsx scripts/update-release-version.mts --verify",
    "types:build-config": "tsx scripts/create-types-from-json-schema.mts",
    "types:verify-config": "tsx scripts/create-types-from-json-schema.mts --verify",
    checkCircle: "npx madge --circular ./src",
    prepublishOnly: "pnpm docs:verify-version"
  },
  repository: {
    type: "git",
    url: "https://github.com/mermaid-js/mermaid"
  },
  author: "Knut Sveidqvist",
  license: "MIT",
  standard: {
    ignore: [
      "**/parser/*.js",
      "dist/**/*.js",
      "cypress/**/*.js"
    ],
    globals: [
      "page"
    ]
  },
  dependencies: {
    "@braintree/sanitize-url": "^7.0.4",
    "@iconify/utils": "^3.0.1",
    "@mermaid-js/parser": "workspace:^",
    "@types/d3": "^7.4.3",
    cytoscape: "^3.29.3",
    "cytoscape-cose-bilkent": "^4.1.0",
    "cytoscape-fcose": "^2.2.0",
    d3: "^7.9.0",
    "d3-sankey": "^0.12.3",
    "dagre-d3-es": "7.0.11",
    dayjs: "^1.11.13",
    dompurify: "^3.2.5",
    katex: "^0.16.22",
    khroma: "^2.1.0",
    "lodash-es": "^4.17.21",
    marked: "^15.0.7",
    roughjs: "^4.6.6",
    stylis: "^4.3.6",
    "ts-dedent": "^2.2.0",
    uuid: "^11.1.0"
  },
  devDependencies: {
    "@adobe/jsonschema2md": "^8.0.2",
    "@iconify/types": "^2.0.0",
    "@types/cytoscape": "^3.21.9",
    "@types/cytoscape-fcose": "^2.2.4",
    "@types/d3-sankey": "^0.12.4",
    "@types/d3-scale": "^4.0.9",
    "@types/d3-scale-chromatic": "^3.1.0",
    "@types/d3-selection": "^3.0.11",
    "@types/d3-shape": "^3.1.7",
    "@types/jsdom": "^21.1.7",
    "@types/katex": "^0.16.7",
    "@types/lodash-es": "^4.17.12",
    "@types/micromatch": "^4.0.9",
    "@types/stylis": "^4.2.7",
    "@types/uuid": "^10.0.0",
    ajv: "^8.17.1",
    canvas: "^3.1.0",
    chokidar: "3.6.0",
    concurrently: "^9.1.2",
    "csstree-validator": "^4.0.1",
    globby: "^14.0.2",
    jison: "^0.4.18",
    "js-base64": "^3.7.7",
    jsdom: "^26.1.0",
    "json-schema-to-typescript": "^15.0.4",
    micromatch: "^4.0.8",
    "path-browserify": "^1.0.1",
    prettier: "^3.5.2",
    remark: "^15.0.1",
    "remark-frontmatter": "^5.0.0",
    "remark-gfm": "^4.0.1",
    rimraf: "^6.0.1",
    "start-server-and-test": "^2.0.10",
    "type-fest": "^4.35.0",
    typedoc: "^0.28.9",
    "typedoc-plugin-markdown": "^4.8.0",
    typescript: "~5.7.3",
    "unist-util-flatmap": "^1.0.0",
    "unist-util-visit": "^5.0.0",
    vitepress: "^1.0.2",
    "vitepress-plugin-search": "1.0.4-alpha.22"
  },
  files: [
    "dist/",
    "README.md"
  ],
  publishConfig: {
    access: "public"
  }
}, xh = { exports: {} };
(function(e, t) {
  (function(r, i) {
    e.exports = i();
  })(Zm, function() {
    var r = 1e3, i = 6e4, n = 36e5, a = "millisecond", o = "second", s = "minute", l = "hour", c = "day", h = "week", u = "month", f = "quarter", p = "year", g = "date", m = "Invalid Date", x = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, b = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(L) {
      var A = ["th", "st", "nd", "rd"], B = L % 100;
      return "[" + L + (A[(B - 20) % 10] || A[B] || A[0]) + "]";
    } }, _ = function(L, A, B) {
      var $ = String(L);
      return !$ || $.length >= A ? L : "" + Array(A + 1 - $.length).join(B) + L;
    }, k = { s: _, z: function(L) {
      var A = -L.utcOffset(), B = Math.abs(A), $ = Math.floor(B / 60), M = B % 60;
      return (A <= 0 ? "+" : "-") + _($, 2, "0") + ":" + _(M, 2, "0");
    }, m: function L(A, B) {
      if (A.date() < B.date()) return -L(B, A);
      var $ = 12 * (B.year() - A.year()) + (B.month() - A.month()), M = A.clone().add($, u), q = B - M < 0, Z = A.clone().add($ + (q ? -1 : 1), u);
      return +(-($ + (B - M) / (q ? M - Z : Z - M)) || 0);
    }, a: function(L) {
      return L < 0 ? Math.ceil(L) || 0 : Math.floor(L);
    }, p: function(L) {
      return { M: u, y: p, w: h, d: c, D: g, h: l, m: s, s: o, ms: a, Q: f }[L] || String(L || "").toLowerCase().replace(/s$/, "");
    }, u: function(L) {
      return L === void 0;
    } }, v = "en", C = {};
    C[v] = b;
    var S = "$isDayjsObject", O = function(L) {
      return L instanceof N || !(!L || !L[S]);
    }, P = function L(A, B, $) {
      var M;
      if (!A) return v;
      if (typeof A == "string") {
        var q = A.toLowerCase();
        C[q] && (M = q), B && (C[q] = B, M = q);
        var Z = A.split("-");
        if (!M && Z.length > 1) return L(Z[0]);
      } else {
        var X = A.name;
        C[X] = A, M = X;
      }
      return !$ && M && (v = M), M || !$ && v;
    }, R = function(L, A) {
      if (O(L)) return L.clone();
      var B = typeof A == "object" ? A : {};
      return B.date = L, B.args = arguments, new N(B);
    }, E = k;
    E.l = P, E.i = O, E.w = function(L, A) {
      return R(L, { locale: A.$L, utc: A.$u, x: A.$x, $offset: A.$offset });
    };
    var N = function() {
      function L(B) {
        this.$L = P(B.locale, null, !0), this.parse(B), this.$x = this.$x || B.x || {}, this[S] = !0;
      }
      var A = L.prototype;
      return A.parse = function(B) {
        this.$d = function($) {
          var M = $.date, q = $.utc;
          if (M === null) return /* @__PURE__ */ new Date(NaN);
          if (E.u(M)) return /* @__PURE__ */ new Date();
          if (M instanceof Date) return new Date(M);
          if (typeof M == "string" && !/Z$/i.test(M)) {
            var Z = M.match(x);
            if (Z) {
              var X = Z[2] - 1 || 0, dt = (Z[7] || "0").substring(0, 3);
              return q ? new Date(Date.UTC(Z[1], X, Z[3] || 1, Z[4] || 0, Z[5] || 0, Z[6] || 0, dt)) : new Date(Z[1], X, Z[3] || 1, Z[4] || 0, Z[5] || 0, Z[6] || 0, dt);
            }
          }
          return new Date(M);
        }(B), this.init();
      }, A.init = function() {
        var B = this.$d;
        this.$y = B.getFullYear(), this.$M = B.getMonth(), this.$D = B.getDate(), this.$W = B.getDay(), this.$H = B.getHours(), this.$m = B.getMinutes(), this.$s = B.getSeconds(), this.$ms = B.getMilliseconds();
      }, A.$utils = function() {
        return E;
      }, A.isValid = function() {
        return this.$d.toString() !== m;
      }, A.isSame = function(B, $) {
        var M = R(B);
        return this.startOf($) <= M && M <= this.endOf($);
      }, A.isAfter = function(B, $) {
        return R(B) < this.startOf($);
      }, A.isBefore = function(B, $) {
        return this.endOf($) < R(B);
      }, A.$g = function(B, $, M) {
        return E.u(B) ? this[$] : this.set(M, B);
      }, A.unix = function() {
        return Math.floor(this.valueOf() / 1e3);
      }, A.valueOf = function() {
        return this.$d.getTime();
      }, A.startOf = function(B, $) {
        var M = this, q = !!E.u($) || $, Z = E.p(B), X = function(mt, yt) {
          var kt = E.w(M.$u ? Date.UTC(M.$y, yt, mt) : new Date(M.$y, yt, mt), M);
          return q ? kt : kt.endOf(c);
        }, dt = function(mt, yt) {
          return E.w(M.toDate()[mt].apply(M.toDate("s"), (q ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(yt)), M);
        }, at = this.$W, wt = this.$M, st = this.$D, nt = "set" + (this.$u ? "UTC" : "");
        switch (Z) {
          case p:
            return q ? X(1, 0) : X(31, 11);
          case u:
            return q ? X(1, wt) : X(0, wt + 1);
          case h:
            var ct = this.$locale().weekStart || 0, _t = (at < ct ? at + 7 : at) - ct;
            return X(q ? st - _t : st + (6 - _t), wt);
          case c:
          case g:
            return dt(nt + "Hours", 0);
          case l:
            return dt(nt + "Minutes", 1);
          case s:
            return dt(nt + "Seconds", 2);
          case o:
            return dt(nt + "Milliseconds", 3);
          default:
            return this.clone();
        }
      }, A.endOf = function(B) {
        return this.startOf(B, !1);
      }, A.$set = function(B, $) {
        var M, q = E.p(B), Z = "set" + (this.$u ? "UTC" : ""), X = (M = {}, M[c] = Z + "Date", M[g] = Z + "Date", M[u] = Z + "Month", M[p] = Z + "FullYear", M[l] = Z + "Hours", M[s] = Z + "Minutes", M[o] = Z + "Seconds", M[a] = Z + "Milliseconds", M)[q], dt = q === c ? this.$D + ($ - this.$W) : $;
        if (q === u || q === p) {
          var at = this.clone().set(g, 1);
          at.$d[X](dt), at.init(), this.$d = at.set(g, Math.min(this.$D, at.daysInMonth())).$d;
        } else X && this.$d[X](dt);
        return this.init(), this;
      }, A.set = function(B, $) {
        return this.clone().$set(B, $);
      }, A.get = function(B) {
        return this[E.p(B)]();
      }, A.add = function(B, $) {
        var M, q = this;
        B = Number(B);
        var Z = E.p($), X = function(wt) {
          var st = R(q);
          return E.w(st.date(st.date() + Math.round(wt * B)), q);
        };
        if (Z === u) return this.set(u, this.$M + B);
        if (Z === p) return this.set(p, this.$y + B);
        if (Z === c) return X(1);
        if (Z === h) return X(7);
        var dt = (M = {}, M[s] = i, M[l] = n, M[o] = r, M)[Z] || 1, at = this.$d.getTime() + B * dt;
        return E.w(at, this);
      }, A.subtract = function(B, $) {
        return this.add(-1 * B, $);
      }, A.format = function(B) {
        var $ = this, M = this.$locale();
        if (!this.isValid()) return M.invalidDate || m;
        var q = B || "YYYY-MM-DDTHH:mm:ssZ", Z = E.z(this), X = this.$H, dt = this.$m, at = this.$M, wt = M.weekdays, st = M.months, nt = M.meridiem, ct = function(yt, kt, qt, ge) {
          return yt && (yt[kt] || yt($, q)) || qt[kt].slice(0, ge);
        }, _t = function(yt) {
          return E.s(X % 12 || 12, yt, "0");
        }, mt = nt || function(yt, kt, qt) {
          var ge = yt < 12 ? "AM" : "PM";
          return qt ? ge.toLowerCase() : ge;
        };
        return q.replace(y, function(yt, kt) {
          return kt || function(qt) {
            switch (qt) {
              case "YY":
                return String($.$y).slice(-2);
              case "YYYY":
                return E.s($.$y, 4, "0");
              case "M":
                return at + 1;
              case "MM":
                return E.s(at + 1, 2, "0");
              case "MMM":
                return ct(M.monthsShort, at, st, 3);
              case "MMMM":
                return ct(st, at);
              case "D":
                return $.$D;
              case "DD":
                return E.s($.$D, 2, "0");
              case "d":
                return String($.$W);
              case "dd":
                return ct(M.weekdaysMin, $.$W, wt, 2);
              case "ddd":
                return ct(M.weekdaysShort, $.$W, wt, 3);
              case "dddd":
                return wt[$.$W];
              case "H":
                return String(X);
              case "HH":
                return E.s(X, 2, "0");
              case "h":
                return _t(1);
              case "hh":
                return _t(2);
              case "a":
                return mt(X, dt, !0);
              case "A":
                return mt(X, dt, !1);
              case "m":
                return String(dt);
              case "mm":
                return E.s(dt, 2, "0");
              case "s":
                return String($.$s);
              case "ss":
                return E.s($.$s, 2, "0");
              case "SSS":
                return E.s($.$ms, 3, "0");
              case "Z":
                return Z;
            }
            return null;
          }(yt) || Z.replace(":", "");
        });
      }, A.utcOffset = function() {
        return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
      }, A.diff = function(B, $, M) {
        var q, Z = this, X = E.p($), dt = R(B), at = (dt.utcOffset() - this.utcOffset()) * i, wt = this - dt, st = function() {
          return E.m(Z, dt);
        };
        switch (X) {
          case p:
            q = st() / 12;
            break;
          case u:
            q = st();
            break;
          case f:
            q = st() / 3;
            break;
          case h:
            q = (wt - at) / 6048e5;
            break;
          case c:
            q = (wt - at) / 864e5;
            break;
          case l:
            q = wt / n;
            break;
          case s:
            q = wt / i;
            break;
          case o:
            q = wt / r;
            break;
          default:
            q = wt;
        }
        return M ? q : E.a(q);
      }, A.daysInMonth = function() {
        return this.endOf(u).$D;
      }, A.$locale = function() {
        return C[this.$L];
      }, A.locale = function(B, $) {
        if (!B) return this.$L;
        var M = this.clone(), q = P(B, $, !0);
        return q && (M.$L = q), M;
      }, A.clone = function() {
        return E.w(this.$d, this);
      }, A.toDate = function() {
        return new Date(this.valueOf());
      }, A.toJSON = function() {
        return this.isValid() ? this.toISOString() : null;
      }, A.toISOString = function() {
        return this.$d.toISOString();
      }, A.toString = function() {
        return this.$d.toUTCString();
      }, L;
    }(), D = N.prototype;
    return R.prototype = D, [["$ms", a], ["$s", o], ["$m", s], ["$H", l], ["$W", c], ["$M", u], ["$y", p], ["$D", g]].forEach(function(L) {
      D[L[1]] = function(A) {
        return this.$g(A, L[0], L[1]);
      };
    }), R.extend = function(L, A) {
      return L.$i || (L(A, N, R), L.$i = !0), R;
    }, R.locale = P, R.isDayjs = O, R.unix = function(L) {
      return R(1e3 * L);
    }, R.en = C[v], R.Ls = C, R.p = {}, R;
  });
})(xh);
var Km = xh.exports;
const Qm = /* @__PURE__ */ Vm(Km);
var bh = Object.defineProperty, d = (e, t) => bh(e, "name", { value: t, configurable: !0 }), Jm = (e, t) => {
  for (var r in t)
    bh(e, r, { get: t[r], enumerable: !0 });
}, Ae = {
  trace: 0,
  debug: 1,
  info: 2,
  warn: 3,
  error: 4,
  fatal: 5
}, F = {
  trace: /* @__PURE__ */ d((...e) => {
  }, "trace"),
  debug: /* @__PURE__ */ d((...e) => {
  }, "debug"),
  info: /* @__PURE__ */ d((...e) => {
  }, "info"),
  warn: /* @__PURE__ */ d((...e) => {
  }, "warn"),
  error: /* @__PURE__ */ d((...e) => {
  }, "error"),
  fatal: /* @__PURE__ */ d((...e) => {
  }, "fatal")
}, bo = /* @__PURE__ */ d(function(e = "fatal") {
  let t = Ae.fatal;
  typeof e == "string" ? e.toLowerCase() in Ae && (t = Ae[e]) : typeof e == "number" && (t = e), F.trace = () => {
  }, F.debug = () => {
  }, F.info = () => {
  }, F.warn = () => {
  }, F.error = () => {
  }, F.fatal = () => {
  }, t <= Ae.fatal && (F.fatal = console.error ? console.error.bind(console, ie("FATAL"), "color: orange") : console.log.bind(console, "\x1B[35m", ie("FATAL"))), t <= Ae.error && (F.error = console.error ? console.error.bind(console, ie("ERROR"), "color: orange") : console.log.bind(console, "\x1B[31m", ie("ERROR"))), t <= Ae.warn && (F.warn = console.warn ? console.warn.bind(console, ie("WARN"), "color: orange") : console.log.bind(console, "\x1B[33m", ie("WARN"))), t <= Ae.info && (F.info = console.info ? console.info.bind(console, ie("INFO"), "color: lightblue") : console.log.bind(console, "\x1B[34m", ie("INFO"))), t <= Ae.debug && (F.debug = console.debug ? console.debug.bind(console, ie("DEBUG"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", ie("DEBUG"))), t <= Ae.trace && (F.trace = console.debug ? console.debug.bind(console, ie("TRACE"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", ie("TRACE")));
}, "setLogLevel"), ie = /* @__PURE__ */ d((e) => `%c${Qm().format("ss.SSS")} : ${e} : `, "format");
const _n = {
  /* CLAMP */
  min: {
    r: 0,
    g: 0,
    b: 0,
    s: 0,
    l: 0,
    a: 0
  },
  max: {
    r: 255,
    g: 255,
    b: 255,
    h: 360,
    s: 100,
    l: 100,
    a: 1
  },
  clamp: {
    r: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    g: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    b: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    h: (e) => e % 360,
    s: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    l: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    a: (e) => e >= 1 ? 1 : e < 0 ? 0 : e
  },
  /* CONVERSION */
  //SOURCE: https://planetcalc.com/7779
  toLinear: (e) => {
    const t = e / 255;
    return e > 0.03928 ? Math.pow((t + 0.055) / 1.055, 2.4) : t / 12.92;
  },
  //SOURCE: https://gist.github.com/mjackson/5311256
  hue2rgb: (e, t, r) => (r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + (t - e) * 6 * r : r < 1 / 2 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e),
  hsl2rgb: ({ h: e, s: t, l: r }, i) => {
    if (!t)
      return r * 2.55;
    e /= 360, t /= 100, r /= 100;
    const n = r < 0.5 ? r * (1 + t) : r + t - r * t, a = 2 * r - n;
    switch (i) {
      case "r":
        return _n.hue2rgb(a, n, e + 1 / 3) * 255;
      case "g":
        return _n.hue2rgb(a, n, e) * 255;
      case "b":
        return _n.hue2rgb(a, n, e - 1 / 3) * 255;
    }
  },
  rgb2hsl: ({ r: e, g: t, b: r }, i) => {
    e /= 255, t /= 255, r /= 255;
    const n = Math.max(e, t, r), a = Math.min(e, t, r), o = (n + a) / 2;
    if (i === "l")
      return o * 100;
    if (n === a)
      return 0;
    const s = n - a, l = o > 0.5 ? s / (2 - n - a) : s / (n + a);
    if (i === "s")
      return l * 100;
    switch (n) {
      case e:
        return ((t - r) / s + (t < r ? 6 : 0)) * 60;
      case t:
        return ((r - e) / s + 2) * 60;
      case r:
        return ((e - t) / s + 4) * 60;
      default:
        return -1;
    }
  }
}, t0 = {
  /* API */
  clamp: (e, t, r) => t > r ? Math.min(t, Math.max(r, e)) : Math.min(r, Math.max(t, e)),
  round: (e) => Math.round(e * 1e10) / 1e10
}, e0 = {
  /* API */
  dec2hex: (e) => {
    const t = Math.round(e).toString(16);
    return t.length > 1 ? t : `0${t}`;
  }
}, it = {
  channel: _n,
  lang: t0,
  unit: e0
}, We = {};
for (let e = 0; e <= 255; e++)
  We[e] = it.unit.dec2hex(e);
const Rt = {
  ALL: 0,
  RGB: 1,
  HSL: 2
};
class r0 {
  constructor() {
    this.type = Rt.ALL;
  }
  /* API */
  get() {
    return this.type;
  }
  set(t) {
    if (this.type && this.type !== t)
      throw new Error("Cannot change both RGB and HSL channels at the same time");
    this.type = t;
  }
  reset() {
    this.type = Rt.ALL;
  }
  is(t) {
    return this.type === t;
  }
}
class i0 {
  /* CONSTRUCTOR */
  constructor(t, r) {
    this.color = r, this.changed = !1, this.data = t, this.type = new r0();
  }
  /* API */
  set(t, r) {
    return this.color = r, this.changed = !1, this.data = t, this.type.type = Rt.ALL, this;
  }
  /* HELPERS */
  _ensureHSL() {
    const t = this.data, { h: r, s: i, l: n } = t;
    r === void 0 && (t.h = it.channel.rgb2hsl(t, "h")), i === void 0 && (t.s = it.channel.rgb2hsl(t, "s")), n === void 0 && (t.l = it.channel.rgb2hsl(t, "l"));
  }
  _ensureRGB() {
    const t = this.data, { r, g: i, b: n } = t;
    r === void 0 && (t.r = it.channel.hsl2rgb(t, "r")), i === void 0 && (t.g = it.channel.hsl2rgb(t, "g")), n === void 0 && (t.b = it.channel.hsl2rgb(t, "b"));
  }
  /* GETTERS */
  get r() {
    const t = this.data, r = t.r;
    return !this.type.is(Rt.HSL) && r !== void 0 ? r : (this._ensureHSL(), it.channel.hsl2rgb(t, "r"));
  }
  get g() {
    const t = this.data, r = t.g;
    return !this.type.is(Rt.HSL) && r !== void 0 ? r : (this._ensureHSL(), it.channel.hsl2rgb(t, "g"));
  }
  get b() {
    const t = this.data, r = t.b;
    return !this.type.is(Rt.HSL) && r !== void 0 ? r : (this._ensureHSL(), it.channel.hsl2rgb(t, "b"));
  }
  get h() {
    const t = this.data, r = t.h;
    return !this.type.is(Rt.RGB) && r !== void 0 ? r : (this._ensureRGB(), it.channel.rgb2hsl(t, "h"));
  }
  get s() {
    const t = this.data, r = t.s;
    return !this.type.is(Rt.RGB) && r !== void 0 ? r : (this._ensureRGB(), it.channel.rgb2hsl(t, "s"));
  }
  get l() {
    const t = this.data, r = t.l;
    return !this.type.is(Rt.RGB) && r !== void 0 ? r : (this._ensureRGB(), it.channel.rgb2hsl(t, "l"));
  }
  get a() {
    return this.data.a;
  }
  /* SETTERS */
  set r(t) {
    this.type.set(Rt.RGB), this.changed = !0, this.data.r = t;
  }
  set g(t) {
    this.type.set(Rt.RGB), this.changed = !0, this.data.g = t;
  }
  set b(t) {
    this.type.set(Rt.RGB), this.changed = !0, this.data.b = t;
  }
  set h(t) {
    this.type.set(Rt.HSL), this.changed = !0, this.data.h = t;
  }
  set s(t) {
    this.type.set(Rt.HSL), this.changed = !0, this.data.s = t;
  }
  set l(t) {
    this.type.set(Rt.HSL), this.changed = !0, this.data.l = t;
  }
  set a(t) {
    this.changed = !0, this.data.a = t;
  }
}
const xa = new i0({ r: 0, g: 0, b: 0, a: 0 }, "transparent"), Fr = {
  /* VARIABLES */
  re: /^#((?:[a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i,
  /* API */
  parse: (e) => {
    if (e.charCodeAt(0) !== 35)
      return;
    const t = e.match(Fr.re);
    if (!t)
      return;
    const r = t[1], i = parseInt(r, 16), n = r.length, a = n % 4 === 0, o = n > 4, s = o ? 1 : 17, l = o ? 8 : 4, c = a ? 0 : -1, h = o ? 255 : 15;
    return xa.set({
      r: (i >> l * (c + 3) & h) * s,
      g: (i >> l * (c + 2) & h) * s,
      b: (i >> l * (c + 1) & h) * s,
      a: a ? (i & h) * s / 255 : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `#${We[Math.round(t)]}${We[Math.round(r)]}${We[Math.round(i)]}${We[Math.round(n * 255)]}` : `#${We[Math.round(t)]}${We[Math.round(r)]}${We[Math.round(i)]}`;
  }
}, ir = {
  /* VARIABLES */
  re: /^hsla?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(?:deg|grad|rad|turn)?)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(%)?))?\s*?\)$/i,
  hueRe: /^(.+?)(deg|grad|rad|turn)$/i,
  /* HELPERS */
  _hue2deg: (e) => {
    const t = e.match(ir.hueRe);
    if (t) {
      const [, r, i] = t;
      switch (i) {
        case "grad":
          return it.channel.clamp.h(parseFloat(r) * 0.9);
        case "rad":
          return it.channel.clamp.h(parseFloat(r) * 180 / Math.PI);
        case "turn":
          return it.channel.clamp.h(parseFloat(r) * 360);
      }
    }
    return it.channel.clamp.h(parseFloat(e));
  },
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 104 && t !== 72)
      return;
    const r = e.match(ir.re);
    if (!r)
      return;
    const [, i, n, a, o, s] = r;
    return xa.set({
      h: ir._hue2deg(i),
      s: it.channel.clamp.s(parseFloat(n)),
      l: it.channel.clamp.l(parseFloat(a)),
      a: o ? it.channel.clamp.a(s ? parseFloat(o) / 100 : parseFloat(o)) : 1
    }, e);
  },
  stringify: (e) => {
    const { h: t, s: r, l: i, a: n } = e;
    return n < 1 ? `hsla(${it.lang.round(t)}, ${it.lang.round(r)}%, ${it.lang.round(i)}%, ${n})` : `hsl(${it.lang.round(t)}, ${it.lang.round(r)}%, ${it.lang.round(i)}%)`;
  }
}, Li = {
  /* VARIABLES */
  colors: {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyanaqua: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    transparent: "#00000000",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
  },
  /* API */
  parse: (e) => {
    e = e.toLowerCase();
    const t = Li.colors[e];
    if (t)
      return Fr.parse(t);
  },
  stringify: (e) => {
    const t = Fr.stringify(e);
    for (const r in Li.colors)
      if (Li.colors[r] === t)
        return r;
  }
}, Ci = {
  /* VARIABLES */
  re: /^rgba?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?)))?\s*?\)$/i,
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 114 && t !== 82)
      return;
    const r = e.match(Ci.re);
    if (!r)
      return;
    const [, i, n, a, o, s, l, c, h] = r;
    return xa.set({
      r: it.channel.clamp.r(n ? parseFloat(i) * 2.55 : parseFloat(i)),
      g: it.channel.clamp.g(o ? parseFloat(a) * 2.55 : parseFloat(a)),
      b: it.channel.clamp.b(l ? parseFloat(s) * 2.55 : parseFloat(s)),
      a: c ? it.channel.clamp.a(h ? parseFloat(c) / 100 : parseFloat(c)) : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `rgba(${it.lang.round(t)}, ${it.lang.round(r)}, ${it.lang.round(i)}, ${it.lang.round(n)})` : `rgb(${it.lang.round(t)}, ${it.lang.round(r)}, ${it.lang.round(i)})`;
  }
}, we = {
  /* VARIABLES */
  format: {
    keyword: Li,
    hex: Fr,
    rgb: Ci,
    rgba: Ci,
    hsl: ir,
    hsla: ir
  },
  /* API */
  parse: (e) => {
    if (typeof e != "string")
      return e;
    const t = Fr.parse(e) || Ci.parse(e) || ir.parse(e) || Li.parse(e);
    if (t)
      return t;
    throw new Error(`Unsupported color format: "${e}"`);
  },
  stringify: (e) => !e.changed && e.color ? e.color : e.type.is(Rt.HSL) || e.data.r === void 0 ? ir.stringify(e) : e.a < 1 || !Number.isInteger(e.r) || !Number.isInteger(e.g) || !Number.isInteger(e.b) ? Ci.stringify(e) : Fr.stringify(e)
}, Ch = (e, t) => {
  const r = we.parse(e);
  for (const i in t)
    r[i] = it.channel.clamp[i](t[i]);
  return we.stringify(r);
}, Ai = (e, t, r = 0, i = 1) => {
  if (typeof e != "number")
    return Ch(e, { a: t });
  const n = xa.set({
    r: it.channel.clamp.r(e),
    g: it.channel.clamp.g(t),
    b: it.channel.clamp.b(r),
    a: it.channel.clamp.a(i)
  });
  return we.stringify(n);
}, n0 = (e) => {
  const { r: t, g: r, b: i } = we.parse(e), n = 0.2126 * it.channel.toLinear(t) + 0.7152 * it.channel.toLinear(r) + 0.0722 * it.channel.toLinear(i);
  return it.lang.round(n);
}, a0 = (e) => n0(e) >= 0.5, Gi = (e) => !a0(e), _h = (e, t, r) => {
  const i = we.parse(e), n = i[t], a = it.channel.clamp[t](n + r);
  return n !== a && (i[t] = a), we.stringify(i);
}, H = (e, t) => _h(e, "l", t), J = (e, t) => _h(e, "l", -t), T = (e, t) => {
  const r = we.parse(e), i = {};
  for (const n in t)
    t[n] && (i[n] = r[n] + t[n]);
  return Ch(e, i);
}, s0 = (e, t, r = 50) => {
  const { r: i, g: n, b: a, a: o } = we.parse(e), { r: s, g: l, b: c, a: h } = we.parse(t), u = r / 100, f = u * 2 - 1, p = o - h, m = ((f * p === -1 ? f : (f + p) / (1 + f * p)) + 1) / 2, x = 1 - m, y = i * m + s * x, b = n * m + l * x, _ = a * m + c * x, k = o * u + h * (1 - u);
  return Ai(y, b, _, k);
}, z = (e, t = 100) => {
  const r = we.parse(e);
  return r.r = 255 - r.r, r.g = 255 - r.g, r.b = 255 - r.b, s0(r, e, t);
};
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: wh,
  setPrototypeOf: Wl,
  isFrozen: o0,
  getPrototypeOf: l0,
  getOwnPropertyDescriptor: c0
} = Object;
let {
  freeze: Gt,
  seal: ae,
  create: vh
} = Object, {
  apply: _s,
  construct: ws
} = typeof Reflect < "u" && Reflect;
Gt || (Gt = function(t) {
  return t;
});
ae || (ae = function(t) {
  return t;
});
_s || (_s = function(t, r, i) {
  return t.apply(r, i);
});
ws || (ws = function(t, r) {
  return new t(...r);
});
const hn = Xt(Array.prototype.forEach), h0 = Xt(Array.prototype.lastIndexOf), ql = Xt(Array.prototype.pop), li = Xt(Array.prototype.push), u0 = Xt(Array.prototype.splice), wn = Xt(String.prototype.toLowerCase), ts = Xt(String.prototype.toString), Hl = Xt(String.prototype.match), ci = Xt(String.prototype.replace), f0 = Xt(String.prototype.indexOf), p0 = Xt(String.prototype.trim), ce = Xt(Object.prototype.hasOwnProperty), Ht = Xt(RegExp.prototype.test), hi = d0(TypeError);
function Xt(e) {
  return function(t) {
    t instanceof RegExp && (t.lastIndex = 0);
    for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++)
      i[n - 1] = arguments[n];
    return _s(e, t, i);
  };
}
function d0(e) {
  return function() {
    for (var t = arguments.length, r = new Array(t), i = 0; i < t; i++)
      r[i] = arguments[i];
    return ws(e, r);
  };
}
function ot(e, t) {
  let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : wn;
  Wl && Wl(e, null);
  let i = t.length;
  for (; i--; ) {
    let n = t[i];
    if (typeof n == "string") {
      const a = r(n);
      a !== n && (o0(t) || (t[i] = a), n = a);
    }
    e[n] = !0;
  }
  return e;
}
function g0(e) {
  for (let t = 0; t < e.length; t++)
    ce(e, t) || (e[t] = null);
  return e;
}
function Ee(e) {
  const t = vh(null);
  for (const [r, i] of wh(e))
    ce(e, r) && (Array.isArray(i) ? t[r] = g0(i) : i && typeof i == "object" && i.constructor === Object ? t[r] = Ee(i) : t[r] = i);
  return t;
}
function ui(e, t) {
  for (; e !== null; ) {
    const i = c0(e, t);
    if (i) {
      if (i.get)
        return Xt(i.get);
      if (typeof i.value == "function")
        return Xt(i.value);
    }
    e = l0(e);
  }
  function r() {
    return null;
  }
  return r;
}
const jl = Gt(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), es = Gt(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), rs = Gt(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), m0 = Gt(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), is = Gt(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), y0 = Gt(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Yl = Gt(["#text"]), Ul = Gt(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), ns = Gt(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Gl = Gt(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), un = Gt(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), x0 = ae(/\{\{[\w\W]*|[\w\W]*\}\}/gm), b0 = ae(/<%[\w\W]*|[\w\W]*%>/gm), C0 = ae(/\$\{[\w\W]*/gm), _0 = ae(/^data-[\-\w.\u00B7-\uFFFF]+$/), w0 = ae(/^aria-[\-\w]+$/), kh = ae(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), v0 = ae(/^(?:\w+script|data):/i), k0 = ae(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Sh = ae(/^html$/i), S0 = ae(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Xl = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: w0,
  ATTR_WHITESPACE: k0,
  CUSTOM_ELEMENT: S0,
  DATA_ATTR: _0,
  DOCTYPE_NAME: Sh,
  ERB_EXPR: b0,
  IS_ALLOWED_URI: kh,
  IS_SCRIPT_OR_DATA: v0,
  MUSTACHE_EXPR: x0,
  TMPLIT_EXPR: C0
});
const fi = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, T0 = function() {
  return typeof window > "u" ? null : window;
}, B0 = function(t, r) {
  if (typeof t != "object" || typeof t.createPolicy != "function")
    return null;
  let i = null;
  const n = "data-tt-policy-suffix";
  r && r.hasAttribute(n) && (i = r.getAttribute(n));
  const a = "dompurify" + (i ? "#" + i : "");
  try {
    return t.createPolicy(a, {
      createHTML(o) {
        return o;
      },
      createScriptURL(o) {
        return o;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + a + " could not be created."), null;
  }
}, Vl = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Th() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : T0();
  const t = (Q) => Th(Q);
  if (t.version = "3.2.6", t.removed = [], !e || !e.document || e.document.nodeType !== fi.document || !e.Element)
    return t.isSupported = !1, t;
  let {
    document: r
  } = e;
  const i = r, n = i.currentScript, {
    DocumentFragment: a,
    HTMLTemplateElement: o,
    Node: s,
    Element: l,
    NodeFilter: c,
    NamedNodeMap: h = e.NamedNodeMap || e.MozNamedAttrMap,
    HTMLFormElement: u,
    DOMParser: f,
    trustedTypes: p
  } = e, g = l.prototype, m = ui(g, "cloneNode"), x = ui(g, "remove"), y = ui(g, "nextSibling"), b = ui(g, "childNodes"), _ = ui(g, "parentNode");
  if (typeof o == "function") {
    const Q = r.createElement("template");
    Q.content && Q.content.ownerDocument && (r = Q.content.ownerDocument);
  }
  let k, v = "";
  const {
    implementation: C,
    createNodeIterator: S,
    createDocumentFragment: O,
    getElementsByTagName: P
  } = r, {
    importNode: R
  } = i;
  let E = Vl();
  t.isSupported = typeof wh == "function" && typeof _ == "function" && C && C.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: N,
    ERB_EXPR: D,
    TMPLIT_EXPR: L,
    DATA_ATTR: A,
    ARIA_ATTR: B,
    IS_SCRIPT_OR_DATA: $,
    ATTR_WHITESPACE: M,
    CUSTOM_ELEMENT: q
  } = Xl;
  let {
    IS_ALLOWED_URI: Z
  } = Xl, X = null;
  const dt = ot({}, [...jl, ...es, ...rs, ...is, ...Yl]);
  let at = null;
  const wt = ot({}, [...Ul, ...ns, ...Gl, ...un]);
  let st = Object.seal(vh(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), nt = null, ct = null, _t = !0, mt = !0, yt = !1, kt = !0, qt = !1, ge = !0, le = !1, Ya = !1, Ua = !1, wr = !1, nn = !1, an = !1, wl = !0, vl = !1;
  const Nm = "user-content-";
  let Ga = !0, ai = !1, vr = {}, kr = null;
  const kl = ot({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Sl = null;
  const Tl = ot({}, ["audio", "video", "img", "source", "image", "track"]);
  let Xa = null;
  const Bl = ot({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), sn = "http://www.w3.org/1998/Math/MathML", on = "http://www.w3.org/2000/svg", Te = "http://www.w3.org/1999/xhtml";
  let Sr = Te, Va = !1, Za = null;
  const zm = ot({}, [sn, on, Te], ts);
  let ln = ot({}, ["mi", "mo", "mn", "ms", "mtext"]), cn = ot({}, ["annotation-xml"]);
  const Wm = ot({}, ["title", "style", "font", "a", "script"]);
  let si = null;
  const qm = ["application/xhtml+xml", "text/html"], Hm = "text/html";
  let Mt = null, Tr = null;
  const jm = r.createElement("form"), Ll = function(w) {
    return w instanceof RegExp || w instanceof Function;
  }, Ka = function() {
    let w = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Tr && Tr === w)) {
      if ((!w || typeof w != "object") && (w = {}), w = Ee(w), si = // eslint-disable-next-line unicorn/prefer-includes
      qm.indexOf(w.PARSER_MEDIA_TYPE) === -1 ? Hm : w.PARSER_MEDIA_TYPE, Mt = si === "application/xhtml+xml" ? ts : wn, X = ce(w, "ALLOWED_TAGS") ? ot({}, w.ALLOWED_TAGS, Mt) : dt, at = ce(w, "ALLOWED_ATTR") ? ot({}, w.ALLOWED_ATTR, Mt) : wt, Za = ce(w, "ALLOWED_NAMESPACES") ? ot({}, w.ALLOWED_NAMESPACES, ts) : zm, Xa = ce(w, "ADD_URI_SAFE_ATTR") ? ot(Ee(Bl), w.ADD_URI_SAFE_ATTR, Mt) : Bl, Sl = ce(w, "ADD_DATA_URI_TAGS") ? ot(Ee(Tl), w.ADD_DATA_URI_TAGS, Mt) : Tl, kr = ce(w, "FORBID_CONTENTS") ? ot({}, w.FORBID_CONTENTS, Mt) : kl, nt = ce(w, "FORBID_TAGS") ? ot({}, w.FORBID_TAGS, Mt) : Ee({}), ct = ce(w, "FORBID_ATTR") ? ot({}, w.FORBID_ATTR, Mt) : Ee({}), vr = ce(w, "USE_PROFILES") ? w.USE_PROFILES : !1, _t = w.ALLOW_ARIA_ATTR !== !1, mt = w.ALLOW_DATA_ATTR !== !1, yt = w.ALLOW_UNKNOWN_PROTOCOLS || !1, kt = w.ALLOW_SELF_CLOSE_IN_ATTR !== !1, qt = w.SAFE_FOR_TEMPLATES || !1, ge = w.SAFE_FOR_XML !== !1, le = w.WHOLE_DOCUMENT || !1, wr = w.RETURN_DOM || !1, nn = w.RETURN_DOM_FRAGMENT || !1, an = w.RETURN_TRUSTED_TYPE || !1, Ua = w.FORCE_BODY || !1, wl = w.SANITIZE_DOM !== !1, vl = w.SANITIZE_NAMED_PROPS || !1, Ga = w.KEEP_CONTENT !== !1, ai = w.IN_PLACE || !1, Z = w.ALLOWED_URI_REGEXP || kh, Sr = w.NAMESPACE || Te, ln = w.MATHML_TEXT_INTEGRATION_POINTS || ln, cn = w.HTML_INTEGRATION_POINTS || cn, st = w.CUSTOM_ELEMENT_HANDLING || {}, w.CUSTOM_ELEMENT_HANDLING && Ll(w.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (st.tagNameCheck = w.CUSTOM_ELEMENT_HANDLING.tagNameCheck), w.CUSTOM_ELEMENT_HANDLING && Ll(w.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (st.attributeNameCheck = w.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), w.CUSTOM_ELEMENT_HANDLING && typeof w.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (st.allowCustomizedBuiltInElements = w.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), qt && (mt = !1), nn && (wr = !0), vr && (X = ot({}, Yl), at = [], vr.html === !0 && (ot(X, jl), ot(at, Ul)), vr.svg === !0 && (ot(X, es), ot(at, ns), ot(at, un)), vr.svgFilters === !0 && (ot(X, rs), ot(at, ns), ot(at, un)), vr.mathMl === !0 && (ot(X, is), ot(at, Gl), ot(at, un))), w.ADD_TAGS && (X === dt && (X = Ee(X)), ot(X, w.ADD_TAGS, Mt)), w.ADD_ATTR && (at === wt && (at = Ee(at)), ot(at, w.ADD_ATTR, Mt)), w.ADD_URI_SAFE_ATTR && ot(Xa, w.ADD_URI_SAFE_ATTR, Mt), w.FORBID_CONTENTS && (kr === kl && (kr = Ee(kr)), ot(kr, w.FORBID_CONTENTS, Mt)), Ga && (X["#text"] = !0), le && ot(X, ["html", "head", "body"]), X.table && (ot(X, ["tbody"]), delete nt.tbody), w.TRUSTED_TYPES_POLICY) {
        if (typeof w.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw hi('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof w.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw hi('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        k = w.TRUSTED_TYPES_POLICY, v = k.createHTML("");
      } else
        k === void 0 && (k = B0(p, n)), k !== null && typeof v == "string" && (v = k.createHTML(""));
      Gt && Gt(w), Tr = w;
    }
  }, Al = ot({}, [...es, ...rs, ...m0]), Ml = ot({}, [...is, ...y0]), Ym = function(w) {
    let I = _(w);
    (!I || !I.tagName) && (I = {
      namespaceURI: Sr,
      tagName: "template"
    });
    const V = wn(w.tagName), bt = wn(I.tagName);
    return Za[w.namespaceURI] ? w.namespaceURI === on ? I.namespaceURI === Te ? V === "svg" : I.namespaceURI === sn ? V === "svg" && (bt === "annotation-xml" || ln[bt]) : !!Al[V] : w.namespaceURI === sn ? I.namespaceURI === Te ? V === "math" : I.namespaceURI === on ? V === "math" && cn[bt] : !!Ml[V] : w.namespaceURI === Te ? I.namespaceURI === on && !cn[bt] || I.namespaceURI === sn && !ln[bt] ? !1 : !Ml[V] && (Wm[V] || !Al[V]) : !!(si === "application/xhtml+xml" && Za[w.namespaceURI]) : !1;
  }, me = function(w) {
    li(t.removed, {
      element: w
    });
    try {
      _(w).removeChild(w);
    } catch {
      x(w);
    }
  }, Br = function(w, I) {
    try {
      li(t.removed, {
        attribute: I.getAttributeNode(w),
        from: I
      });
    } catch {
      li(t.removed, {
        attribute: null,
        from: I
      });
    }
    if (I.removeAttribute(w), w === "is")
      if (wr || nn)
        try {
          me(I);
        } catch {
        }
      else
        try {
          I.setAttribute(w, "");
        } catch {
        }
  }, El = function(w) {
    let I = null, V = null;
    if (Ua)
      w = "<remove></remove>" + w;
    else {
      const Tt = Hl(w, /^[\r\n\t ]+/);
      V = Tt && Tt[0];
    }
    si === "application/xhtml+xml" && Sr === Te && (w = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + w + "</body></html>");
    const bt = k ? k.createHTML(w) : w;
    if (Sr === Te)
      try {
        I = new f().parseFromString(bt, si);
      } catch {
      }
    if (!I || !I.documentElement) {
      I = C.createDocument(Sr, "template", null);
      try {
        I.documentElement.innerHTML = Va ? v : bt;
      } catch {
      }
    }
    const Dt = I.body || I.documentElement;
    return w && V && Dt.insertBefore(r.createTextNode(V), Dt.childNodes[0] || null), Sr === Te ? P.call(I, le ? "html" : "body")[0] : le ? I.documentElement : Dt;
  }, $l = function(w) {
    return S.call(
      w.ownerDocument || w,
      w,
      // eslint-disable-next-line no-bitwise
      c.SHOW_ELEMENT | c.SHOW_COMMENT | c.SHOW_TEXT | c.SHOW_PROCESSING_INSTRUCTION | c.SHOW_CDATA_SECTION,
      null
    );
  }, Qa = function(w) {
    return w instanceof u && (typeof w.nodeName != "string" || typeof w.textContent != "string" || typeof w.removeChild != "function" || !(w.attributes instanceof h) || typeof w.removeAttribute != "function" || typeof w.setAttribute != "function" || typeof w.namespaceURI != "string" || typeof w.insertBefore != "function" || typeof w.hasChildNodes != "function");
  }, Fl = function(w) {
    return typeof s == "function" && w instanceof s;
  };
  function Be(Q, w, I) {
    hn(Q, (V) => {
      V.call(t, w, I, Tr);
    });
  }
  const Dl = function(w) {
    let I = null;
    if (Be(E.beforeSanitizeElements, w, null), Qa(w))
      return me(w), !0;
    const V = Mt(w.nodeName);
    if (Be(E.uponSanitizeElement, w, {
      tagName: V,
      allowedTags: X
    }), ge && w.hasChildNodes() && !Fl(w.firstElementChild) && Ht(/<[/\w!]/g, w.innerHTML) && Ht(/<[/\w!]/g, w.textContent) || w.nodeType === fi.progressingInstruction || ge && w.nodeType === fi.comment && Ht(/<[/\w]/g, w.data))
      return me(w), !0;
    if (!X[V] || nt[V]) {
      if (!nt[V] && Rl(V) && (st.tagNameCheck instanceof RegExp && Ht(st.tagNameCheck, V) || st.tagNameCheck instanceof Function && st.tagNameCheck(V)))
        return !1;
      if (Ga && !kr[V]) {
        const bt = _(w) || w.parentNode, Dt = b(w) || w.childNodes;
        if (Dt && bt) {
          const Tt = Dt.length;
          for (let Vt = Tt - 1; Vt >= 0; --Vt) {
            const Le = m(Dt[Vt], !0);
            Le.__removalCount = (w.__removalCount || 0) + 1, bt.insertBefore(Le, y(w));
          }
        }
      }
      return me(w), !0;
    }
    return w instanceof l && !Ym(w) || (V === "noscript" || V === "noembed" || V === "noframes") && Ht(/<\/no(script|embed|frames)/i, w.innerHTML) ? (me(w), !0) : (qt && w.nodeType === fi.text && (I = w.textContent, hn([N, D, L], (bt) => {
      I = ci(I, bt, " ");
    }), w.textContent !== I && (li(t.removed, {
      element: w.cloneNode()
    }), w.textContent = I)), Be(E.afterSanitizeElements, w, null), !1);
  }, Ol = function(w, I, V) {
    if (wl && (I === "id" || I === "name") && (V in r || V in jm))
      return !1;
    if (!(mt && !ct[I] && Ht(A, I))) {
      if (!(_t && Ht(B, I))) {
        if (!at[I] || ct[I]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Rl(w) && (st.tagNameCheck instanceof RegExp && Ht(st.tagNameCheck, w) || st.tagNameCheck instanceof Function && st.tagNameCheck(w)) && (st.attributeNameCheck instanceof RegExp && Ht(st.attributeNameCheck, I) || st.attributeNameCheck instanceof Function && st.attributeNameCheck(I)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            I === "is" && st.allowCustomizedBuiltInElements && (st.tagNameCheck instanceof RegExp && Ht(st.tagNameCheck, V) || st.tagNameCheck instanceof Function && st.tagNameCheck(V)))
          ) return !1;
        } else if (!Xa[I]) {
          if (!Ht(Z, ci(V, M, ""))) {
            if (!((I === "src" || I === "xlink:href" || I === "href") && w !== "script" && f0(V, "data:") === 0 && Sl[w])) {
              if (!(yt && !Ht($, ci(V, M, "")))) {
                if (V)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Rl = function(w) {
    return w !== "annotation-xml" && Hl(w, q);
  }, Il = function(w) {
    Be(E.beforeSanitizeAttributes, w, null);
    const {
      attributes: I
    } = w;
    if (!I || Qa(w))
      return;
    const V = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: at,
      forceKeepAttr: void 0
    };
    let bt = I.length;
    for (; bt--; ) {
      const Dt = I[bt], {
        name: Tt,
        namespaceURI: Vt,
        value: Le
      } = Dt, oi = Mt(Tt), Ja = Le;
      let Ot = Tt === "value" ? Ja : p0(Ja);
      if (V.attrName = oi, V.attrValue = Ot, V.keepAttr = !0, V.forceKeepAttr = void 0, Be(E.uponSanitizeAttribute, w, V), Ot = V.attrValue, vl && (oi === "id" || oi === "name") && (Br(Tt, w), Ot = Nm + Ot), ge && Ht(/((--!?|])>)|<\/(style|title)/i, Ot)) {
        Br(Tt, w);
        continue;
      }
      if (V.forceKeepAttr)
        continue;
      if (!V.keepAttr) {
        Br(Tt, w);
        continue;
      }
      if (!kt && Ht(/\/>/i, Ot)) {
        Br(Tt, w);
        continue;
      }
      qt && hn([N, D, L], (Nl) => {
        Ot = ci(Ot, Nl, " ");
      });
      const Pl = Mt(w.nodeName);
      if (!Ol(Pl, oi, Ot)) {
        Br(Tt, w);
        continue;
      }
      if (k && typeof p == "object" && typeof p.getAttributeType == "function" && !Vt)
        switch (p.getAttributeType(Pl, oi)) {
          case "TrustedHTML": {
            Ot = k.createHTML(Ot);
            break;
          }
          case "TrustedScriptURL": {
            Ot = k.createScriptURL(Ot);
            break;
          }
        }
      if (Ot !== Ja)
        try {
          Vt ? w.setAttributeNS(Vt, Tt, Ot) : w.setAttribute(Tt, Ot), Qa(w) ? me(w) : ql(t.removed);
        } catch {
          Br(Tt, w);
        }
    }
    Be(E.afterSanitizeAttributes, w, null);
  }, Um = function Q(w) {
    let I = null;
    const V = $l(w);
    for (Be(E.beforeSanitizeShadowDOM, w, null); I = V.nextNode(); )
      Be(E.uponSanitizeShadowNode, I, null), Dl(I), Il(I), I.content instanceof a && Q(I.content);
    Be(E.afterSanitizeShadowDOM, w, null);
  };
  return t.sanitize = function(Q) {
    let w = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, I = null, V = null, bt = null, Dt = null;
    if (Va = !Q, Va && (Q = "<!-->"), typeof Q != "string" && !Fl(Q))
      if (typeof Q.toString == "function") {
        if (Q = Q.toString(), typeof Q != "string")
          throw hi("dirty is not a string, aborting");
      } else
        throw hi("toString is not a function");
    if (!t.isSupported)
      return Q;
    if (Ya || Ka(w), t.removed = [], typeof Q == "string" && (ai = !1), ai) {
      if (Q.nodeName) {
        const Le = Mt(Q.nodeName);
        if (!X[Le] || nt[Le])
          throw hi("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (Q instanceof s)
      I = El("<!---->"), V = I.ownerDocument.importNode(Q, !0), V.nodeType === fi.element && V.nodeName === "BODY" || V.nodeName === "HTML" ? I = V : I.appendChild(V);
    else {
      if (!wr && !qt && !le && // eslint-disable-next-line unicorn/prefer-includes
      Q.indexOf("<") === -1)
        return k && an ? k.createHTML(Q) : Q;
      if (I = El(Q), !I)
        return wr ? null : an ? v : "";
    }
    I && Ua && me(I.firstChild);
    const Tt = $l(ai ? Q : I);
    for (; bt = Tt.nextNode(); )
      Dl(bt), Il(bt), bt.content instanceof a && Um(bt.content);
    if (ai)
      return Q;
    if (wr) {
      if (nn)
        for (Dt = O.call(I.ownerDocument); I.firstChild; )
          Dt.appendChild(I.firstChild);
      else
        Dt = I;
      return (at.shadowroot || at.shadowrootmode) && (Dt = R.call(i, Dt, !0)), Dt;
    }
    let Vt = le ? I.outerHTML : I.innerHTML;
    return le && X["!doctype"] && I.ownerDocument && I.ownerDocument.doctype && I.ownerDocument.doctype.name && Ht(Sh, I.ownerDocument.doctype.name) && (Vt = "<!DOCTYPE " + I.ownerDocument.doctype.name + `>
` + Vt), qt && hn([N, D, L], (Le) => {
      Vt = ci(Vt, Le, " ");
    }), k && an ? k.createHTML(Vt) : Vt;
  }, t.setConfig = function() {
    let Q = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Ka(Q), Ya = !0;
  }, t.clearConfig = function() {
    Tr = null, Ya = !1;
  }, t.isValidAttribute = function(Q, w, I) {
    Tr || Ka({});
    const V = Mt(Q), bt = Mt(w);
    return Ol(V, bt, I);
  }, t.addHook = function(Q, w) {
    typeof w == "function" && li(E[Q], w);
  }, t.removeHook = function(Q, w) {
    if (w !== void 0) {
      const I = h0(E[Q], w);
      return I === -1 ? void 0 : u0(E[Q], I, 1)[0];
    }
    return ql(E[Q]);
  }, t.removeHooks = function(Q) {
    E[Q] = [];
  }, t.removeAllHooks = function() {
    E = Vl();
  }, t;
}
var jr = Th(), Bh = /^-{3}\s*[\n\r](.*?)[\n\r]-{3}\s*[\n\r]+/s, Mi = /%{2}{\s*(?:(\w+)\s*:|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, L0 = /\s*%%.*\n/gm, Rr, Lh = (Rr = class extends Error {
  constructor(t) {
    super(t), this.name = "UnknownDiagramError";
  }
}, d(Rr, "UnknownDiagramError"), Rr), hr = {}, Co = /* @__PURE__ */ d(function(e, t) {
  e = e.replace(Bh, "").replace(Mi, "").replace(L0, `
`);
  for (const [r, { detector: i }] of Object.entries(hr))
    if (i(e, t))
      return r;
  throw new Lh(
    `No diagram type detected matching given configuration for text: ${e}`
  );
}, "detectType"), vs = /* @__PURE__ */ d((...e) => {
  for (const { id: t, detector: r, loader: i } of e)
    Ah(t, r, i);
}, "registerLazyLoadedDiagrams"), Ah = /* @__PURE__ */ d((e, t, r) => {
  hr[e] && F.warn(`Detector with key ${e} already exists. Overwriting.`), hr[e] = { detector: t, loader: r }, F.debug(`Detector with key ${e} added${r ? " with loader" : ""}`);
}, "addDetector"), A0 = /* @__PURE__ */ d((e) => hr[e].loader, "getDiagramLoader"), ks = /* @__PURE__ */ d((e, t, { depth: r = 2, clobber: i = !1 } = {}) => {
  const n = { depth: r, clobber: i };
  return Array.isArray(t) && !Array.isArray(e) ? (t.forEach((a) => ks(e, a, n)), e) : Array.isArray(t) && Array.isArray(e) ? (t.forEach((a) => {
    e.includes(a) || e.push(a);
  }), e) : e === void 0 || r <= 0 ? e != null && typeof e == "object" && typeof t == "object" ? Object.assign(e, t) : t : (t !== void 0 && typeof e == "object" && typeof t == "object" && Object.keys(t).forEach((a) => {
    typeof t[a] == "object" && (e[a] === void 0 || typeof e[a] == "object") ? (e[a] === void 0 && (e[a] = Array.isArray(t[a]) ? [] : {}), e[a] = ks(e[a], t[a], { depth: r - 1, clobber: i })) : (i || typeof e[a] != "object" && typeof t[a] != "object") && (e[a] = t[a]);
  }), e);
}, "assignWithDepth"), Bt = ks, ba = "#ffffff", Ca = "#f2f2f2", jt = /* @__PURE__ */ d((e, t) => t ? T(e, { s: -40, l: 10 }) : T(e, { s: -40, l: -10 }), "mkBorder"), Ir, M0 = (Ir = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#fff4dd", this.noteBkgColor = "#fff5ad", this.noteTextColor = "#333", this.THEME_COLOR_LIMIT = 12, this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px";
  }
  updateColors() {
    var r, i, n, a, o, s, l, c, h, u, f, p, g, m, x, y, b, _, k, v, C;
    if (this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333"), this.secondaryColor = this.secondaryColor || T(this.primaryColor, { h: -120 }), this.tertiaryColor = this.tertiaryColor || T(this.primaryColor, { h: 180, l: 5 }), this.primaryBorderColor = this.primaryBorderColor || jt(this.primaryColor, this.darkMode), this.secondaryBorderColor = this.secondaryBorderColor || jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = this.tertiaryBorderColor || jt(this.tertiaryColor, this.darkMode), this.noteBorderColor = this.noteBorderColor || jt(this.noteBkgColor, this.darkMode), this.noteBkgColor = this.noteBkgColor || "#fff5ad", this.noteTextColor = this.noteTextColor || "#333", this.secondaryTextColor = this.secondaryTextColor || z(this.secondaryColor), this.tertiaryTextColor = this.tertiaryTextColor || z(this.tertiaryColor), this.lineColor = this.lineColor || z(this.background), this.arrowheadColor = this.arrowheadColor || z(this.background), this.textColor = this.textColor || this.primaryTextColor, this.border2 = this.border2 || this.tertiaryBorderColor, this.nodeBkg = this.nodeBkg || this.primaryColor, this.mainBkg = this.mainBkg || this.primaryColor, this.nodeBorder = this.nodeBorder || this.primaryBorderColor, this.clusterBkg = this.clusterBkg || this.tertiaryColor, this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor, this.defaultLinkColor = this.defaultLinkColor || this.lineColor, this.titleColor = this.titleColor || this.tertiaryTextColor, this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? J(this.secondaryColor, 30) : this.secondaryColor), this.nodeTextColor = this.nodeTextColor || this.primaryTextColor, this.actorBorder = this.actorBorder || this.primaryBorderColor, this.actorBkg = this.actorBkg || this.mainBkg, this.actorTextColor = this.actorTextColor || this.primaryTextColor, this.actorLineColor = this.actorLineColor || this.actorBorder, this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg, this.signalColor = this.signalColor || this.textColor, this.signalTextColor = this.signalTextColor || this.textColor, this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder, this.labelTextColor = this.labelTextColor || this.actorTextColor, this.loopTextColor = this.loopTextColor || this.actorTextColor, this.activationBorderColor = this.activationBorderColor || J(this.secondaryColor, 10), this.activationBkgColor = this.activationBkgColor || this.secondaryColor, this.sequenceNumberColor = this.sequenceNumberColor || z(this.lineColor), this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor, this.altSectionBkgColor = this.altSectionBkgColor || "white", this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor, this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor, this.excludeBkgColor = this.excludeBkgColor || "#eeeeee", this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor, this.taskBkgColor = this.taskBkgColor || this.primaryColor, this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor, this.activeTaskBkgColor = this.activeTaskBkgColor || H(this.primaryColor, 23), this.gridColor = this.gridColor || "lightgrey", this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey", this.doneTaskBorderColor = this.doneTaskBorderColor || "grey", this.critBorderColor = this.critBorderColor || "#ff8888", this.critBkgColor = this.critBkgColor || "red", this.todayLineColor = this.todayLineColor || "red", this.vertLineColor = this.vertLineColor || "navy", this.taskTextColor = this.taskTextColor || this.textColor, this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor, this.taskTextLightColor = this.taskTextLightColor || this.textColor, this.taskTextColor = this.taskTextColor || this.primaryTextColor, this.taskTextDarkColor = this.taskTextDarkColor || this.textColor, this.taskTextClickableColor = this.taskTextClickableColor || "#003163", this.personBorder = this.personBorder || this.primaryBorderColor, this.personBkg = this.personBkg || this.mainBkg, this.darkMode ? (this.rowOdd = this.rowOdd || J(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || J(this.mainBkg, 10)) : (this.rowOdd = this.rowOdd || H(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || H(this.mainBkg, 5)), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || this.tertiaryColor, this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.specialStateColor = this.lineColor, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210, l: 150 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 }), this.darkMode)
      for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
        this["cScale" + S] = J(this["cScale" + S], 75);
    else
      for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
        this["cScale" + S] = J(this["cScale" + S], 25);
    for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
      this["cScaleInv" + S] = this["cScaleInv" + S] || z(this["cScale" + S]);
    for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
      this.darkMode ? this["cScalePeer" + S] = this["cScalePeer" + S] || H(this["cScale" + S], 10) : this["cScalePeer" + S] = this["cScalePeer" + S] || J(this["cScale" + S], 10);
    this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
    for (let S = 0; S < this.THEME_COLOR_LIMIT; S++)
      this["cScaleLabel" + S] = this["cScaleLabel" + S] || this.scaleLabelColor;
    const t = this.darkMode ? -4 : -1;
    for (let S = 0; S < 5; S++)
      this["surface" + S] = this["surface" + S] || T(this.mainBkg, { h: 180, s: -15, l: t * (5 + S * 3) }), this["surfacePeer" + S] = this["surfacePeer" + S] || T(this.mainBkg, { h: 180, s: -15, l: t * (8 + S * 3) });
    this.classText = this.classText || this.textColor, this.fillType0 = this.fillType0 || this.primaryColor, this.fillType1 = this.fillType1 || this.secondaryColor, this.fillType2 = this.fillType2 || T(this.primaryColor, { h: 64 }), this.fillType3 = this.fillType3 || T(this.secondaryColor, { h: 64 }), this.fillType4 = this.fillType4 || T(this.primaryColor, { h: -64 }), this.fillType5 = this.fillType5 || T(this.secondaryColor, { h: -64 }), this.fillType6 = this.fillType6 || T(this.primaryColor, { h: 128 }), this.fillType7 = this.fillType7 || T(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || T(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || T(this.secondaryColor, { l: -10 }), this.pie6 = this.pie6 || T(this.tertiaryColor, { l: -10 }), this.pie7 = this.pie7 || T(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || T(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || T(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || T(this.primaryColor, { h: 60, l: -20 }), this.pie11 = this.pie11 || T(this.primaryColor, { h: -60, l: -20 }), this.pie12 = this.pie12 || T(this.primaryColor, { h: 120, l: -10 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.radar = {
      axisColor: ((r = this.radar) == null ? void 0 : r.axisColor) || this.lineColor,
      axisStrokeWidth: ((i = this.radar) == null ? void 0 : i.axisStrokeWidth) || 2,
      axisLabelFontSize: ((n = this.radar) == null ? void 0 : n.axisLabelFontSize) || 12,
      curveOpacity: ((a = this.radar) == null ? void 0 : a.curveOpacity) || 0.5,
      curveStrokeWidth: ((o = this.radar) == null ? void 0 : o.curveStrokeWidth) || 2,
      graticuleColor: ((s = this.radar) == null ? void 0 : s.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((l = this.radar) == null ? void 0 : l.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((c = this.radar) == null ? void 0 : c.graticuleOpacity) || 0.3,
      legendBoxSize: ((h = this.radar) == null ? void 0 : h.legendBoxSize) || 12,
      legendFontSize: ((u = this.radar) == null ? void 0 : u.legendFontSize) || 12
    }, this.archEdgeColor = this.archEdgeColor || "#777", this.archEdgeArrowColor = this.archEdgeArrowColor || "#777", this.archEdgeWidth = this.archEdgeWidth || "3", this.archGroupBorderColor = this.archGroupBorderColor || "#000", this.archGroupBorderWidth = this.archGroupBorderWidth || "2px", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((f = this.xyChart) == null ? void 0 : f.backgroundColor) || this.background,
      titleColor: ((p = this.xyChart) == null ? void 0 : p.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((g = this.xyChart) == null ? void 0 : g.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((m = this.xyChart) == null ? void 0 : m.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((x = this.xyChart) == null ? void 0 : x.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((y = this.xyChart) == null ? void 0 : y.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((b = this.xyChart) == null ? void 0 : b.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((k = this.xyChart) == null ? void 0 : k.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((v = this.xyChart) == null ? void 0 : v.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((C = this.xyChart) == null ? void 0 : C.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? J(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || T(this.primaryColor, { h: -30 }), this.git4 = this.git4 || T(this.primaryColor, { h: -60 }), this.git5 = this.git5 || T(this.primaryColor, { h: -90 }), this.git6 = this.git6 || T(this.primaryColor, { h: 60 }), this.git7 = this.git7 || T(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = H(this.git0, 25), this.git1 = H(this.git1, 25), this.git2 = H(this.git2, 25), this.git3 = H(this.git3, 25), this.git4 = H(this.git4, 25), this.git5 = H(this.git5, 25), this.git6 = H(this.git6, 25), this.git7 = H(this.git7, 25)) : (this.git0 = J(this.git0, 25), this.git1 = J(this.git1, 25), this.git2 = J(this.git2, 25), this.git3 = J(this.git3, 25), this.git4 = J(this.git4, 25), this.git5 = J(this.git5, 25), this.git6 = J(this.git6, 25), this.git7 = J(this.git7, 25)), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor, this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor, this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor, this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || ba, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Ca;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Ir, "Theme"), Ir), E0 = /* @__PURE__ */ d((e) => {
  const t = new M0();
  return t.calculate(e), t;
}, "getThemeVariables"), Pr, $0 = (Pr = class {
  constructor() {
    this.background = "#333", this.primaryColor = "#1f2020", this.secondaryColor = H(this.primaryColor, 16), this.tertiaryColor = T(this.primaryColor, { h: -160 }), this.primaryBorderColor = z(this.background), this.secondaryBorderColor = jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = jt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.tertiaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.mainBkg = "#1f2020", this.secondBkg = "calculated", this.mainContrastColor = "lightgrey", this.darkTextColor = H(z("#323D47"), 10), this.lineColor = "calculated", this.border1 = "#ccc", this.border2 = Ai(255, 255, 255, 0.25), this.arrowheadColor = "calculated", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "#181818", this.textColor = "#ccc", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#F9FFFE", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "calculated", this.activationBkgColor = "calculated", this.sequenceNumberColor = "black", this.sectionBkgColor = J("#EAE8D9", 30), this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "#EAE8D9", this.excludeBkgColor = J(this.sectionBkgColor, 10), this.taskBorderColor = Ai(255, 255, 255, 70), this.taskBkgColor = "calculated", this.taskTextColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = Ai(255, 255, 255, 50), this.activeTaskBkgColor = "#81B1DB", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "grey", this.critBorderColor = "#E83737", this.critBkgColor = "#E83737", this.taskTextDarkColor = "calculated", this.todayLineColor = "#DB5757", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || H(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || J(this.mainBkg, 10), this.labelColor = "calculated", this.errorBkgColor = "#a44141", this.errorTextColor = "#ddd";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, x, y, b, _, k, v;
    this.secondBkg = H(this.mainBkg, 16), this.lineColor = this.mainContrastColor, this.arrowheadColor = this.mainContrastColor, this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.edgeLabelBackground = H(this.labelBackground, 25), this.actorBorder = this.border1, this.actorBkg = this.mainBkg, this.actorTextColor = this.mainContrastColor, this.actorLineColor = this.actorBorder, this.signalColor = this.mainContrastColor, this.signalTextColor = this.mainContrastColor, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.mainContrastColor, this.loopTextColor = this.mainContrastColor, this.noteBorderColor = this.secondaryBorderColor, this.noteBkgColor = this.secondBkg, this.noteTextColor = this.secondaryTextColor, this.activationBorderColor = this.border1, this.activationBkgColor = this.secondBkg, this.altSectionBkgColor = this.background, this.taskBkgColor = H(this.mainBkg, 23), this.taskTextColor = this.darkTextColor, this.taskTextLightColor = this.mainContrastColor, this.taskTextOutsideColor = this.taskTextLightColor, this.gridColor = this.mainContrastColor, this.doneTaskBkgColor = this.mainContrastColor, this.taskTextDarkColor = this.darkTextColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#555", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#f4f4f4", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 }), this.cScale1 = this.cScale1 || "#0b0000", this.cScale2 = this.cScale2 || "#4d1037", this.cScale3 = this.cScale3 || "#3f5258", this.cScale4 = this.cScale4 || "#4f2f1b", this.cScale5 = this.cScale5 || "#6e0a0a", this.cScale6 = this.cScale6 || "#3b0048", this.cScale7 = this.cScale7 || "#995a01", this.cScale8 = this.cScale8 || "#154706", this.cScale9 = this.cScale9 || "#161722", this.cScale10 = this.cScale10 || "#00296f", this.cScale11 = this.cScale11 || "#01629c", this.cScale12 = this.cScale12 || "#010029", this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || z(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScalePeer" + C] = this["cScalePeer" + C] || H(this["cScale" + C], 10);
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(-10 + C * 4) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(-7 + C * 4) });
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((l = this.xyChart) == null ? void 0 : l.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((c = this.xyChart) == null ? void 0 : c.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#3498db,#2ecc71,#e74c3c,#f1c40f,#bdc3c7,#ffffff,#34495e,#9b59b6,#1abc9c,#e67e22"
    }, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.background
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((p = this.radar) == null ? void 0 : p.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((x = this.radar) == null ? void 0 : x.curveStrokeWidth) || 2,
      graticuleColor: ((y = this.radar) == null ? void 0 : y.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((_ = this.radar) == null ? void 0 : _.graticuleOpacity) || 0.3,
      legendBoxSize: ((k = this.radar) == null ? void 0 : k.legendBoxSize) || 12,
      legendFontSize: ((v = this.radar) == null ? void 0 : v.legendFontSize) || 12
    }, this.classText = this.primaryTextColor, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? J(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = H(this.secondaryColor, 20), this.git1 = H(this.pie2 || this.secondaryColor, 20), this.git2 = H(this.pie3 || this.tertiaryColor, 20), this.git3 = H(this.pie4 || T(this.primaryColor, { h: -30 }), 20), this.git4 = H(this.pie5 || T(this.primaryColor, { h: -60 }), 20), this.git5 = H(this.pie6 || T(this.primaryColor, { h: -90 }), 10), this.git6 = H(this.pie7 || T(this.primaryColor, { h: 60 }), 10), this.git7 = H(this.pie8 || T(this.primaryColor, { h: 120 }), 20), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || z(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || z(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || H(this.background, 12), this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || H(this.background, 2), this.nodeBorder = this.nodeBorder || "#999";
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Pr, "Theme"), Pr), F0 = /* @__PURE__ */ d((e) => {
  const t = new $0();
  return t.calculate(e), t;
}, "getThemeVariables"), Nr, D0 = (Nr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#ECECFF", this.secondaryColor = T(this.primaryColor, { h: 120 }), this.secondaryColor = "#ffffde", this.tertiaryColor = T(this.primaryColor, { h: -160 }), this.primaryBorderColor = jt(this.primaryColor, this.darkMode), this.secondaryBorderColor = jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = jt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.tertiaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.background = "white", this.mainBkg = "#ECECFF", this.secondBkg = "#ffffde", this.lineColor = "#333333", this.border1 = "#9370DB", this.border2 = "#aaaa33", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "rgba(232,232,232, 0.8)", this.textColor = "#333", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = this.taskTextDarkColor, this.taskTextClickableColor = "calculated", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBorderColor = "calculated", this.critBkgColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.sectionBkgColor = Ai(102, 102, 255, 0.49), this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#fff400", this.taskBorderColor = "#534fbc", this.taskBkgColor = "#8a90dd", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "#534fbc", this.activeTaskBkgColor = "#bfc7ff", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "navy", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = "calculated", this.rowEven = "calculated", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222", this.updateColors();
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, x, y, b, _, k, v;
    this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || J(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || J(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = J(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || J(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || T(this["cScale" + C], { h: 180 });
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { h: 30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { h: 30, l: -(7 + C * 5) });
    if (this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor, this.labelTextColor !== "calculated") {
      this.cScaleLabel0 = this.cScaleLabel0 || z(this.labelTextColor), this.cScaleLabel3 = this.cScaleLabel3 || z(this.labelTextColor);
      for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
        this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.labelTextColor;
    }
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.textColor, this.edgeLabelBackground = this.labelBackground, this.actorBorder = H(this.border1, 23), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.signalColor = this.textColor, this.signalTextColor = this.textColor, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || H(this.primaryColor, 75) || "#ffffff", this.rowEven = this.rowEven || H(this.primaryColor, 1), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || T(this.tertiaryColor, { l: -40 }), this.pie4 = this.pie4 || T(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || T(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || T(this.tertiaryColor, { l: -20 }), this.pie7 = this.pie7 || T(this.primaryColor, { h: 60, l: -20 }), this.pie8 = this.pie8 || T(this.primaryColor, { h: -60, l: -40 }), this.pie9 = this.pie9 || T(this.primaryColor, { h: 120, l: -40 }), this.pie10 = this.pie10 || T(this.primaryColor, { h: 60, l: -40 }), this.pie11 = this.pie11 || T(this.primaryColor, { h: -90, l: -40 }), this.pie12 = this.pie12 || T(this.primaryColor, { h: 120, l: -30 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((l = this.radar) == null ? void 0 : l.graticuleOpacity) || 0.3,
      legendBoxSize: ((c = this.radar) == null ? void 0 : c.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((p = this.xyChart) == null ? void 0 : p.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((x = this.xyChart) == null ? void 0 : x.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((y = this.xyChart) == null ? void 0 : y.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((k = this.xyChart) == null ? void 0 : k.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((v = this.xyChart) == null ? void 0 : v.plotColorPalette) || "#ECECFF,#8493A6,#FFC3A0,#DCDDE1,#B8E994,#D1A36F,#C3CDE6,#FFB6C1,#496078,#F8F3E3"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.labelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || T(this.primaryColor, { h: -30 }), this.git4 = this.git4 || T(this.primaryColor, { h: -60 }), this.git5 = this.git5 || T(this.primaryColor, { h: -90 }), this.git6 = this.git6 || T(this.primaryColor, { h: 60 }), this.git7 = this.git7 || T(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = H(this.git0, 25), this.git1 = H(this.git1, 25), this.git2 = H(this.git2, 25), this.git3 = H(this.git3, 25), this.git4 = H(this.git4, 25), this.git5 = H(this.git5, 25), this.git6 = H(this.git6, 25), this.git7 = H(this.git7, 25)) : (this.git0 = J(this.git0, 25), this.git1 = J(this.git1, 25), this.git2 = J(this.git2, 25), this.git3 = J(this.git3, 25), this.git4 = J(this.git4, 25), this.git5 = J(this.git5, 25), this.git6 = J(this.git6, 25), this.git7 = J(this.git7, 25)), this.gitInv0 = this.gitInv0 || J(z(this.git0), 25), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || z(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || z(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || ba, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Ca;
  }
  calculate(t) {
    if (Object.keys(this).forEach((i) => {
      this[i] === "calculated" && (this[i] = void 0);
    }), typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Nr, "Theme"), Nr), O0 = /* @__PURE__ */ d((e) => {
  const t = new D0();
  return t.calculate(e), t;
}, "getThemeVariables"), zr, R0 = (zr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#cde498", this.secondaryColor = "#cdffb2", this.background = "white", this.mainBkg = "#cde498", this.secondBkg = "#cdffb2", this.lineColor = "green", this.border1 = "#13540c", this.border2 = "#6eaa49", this.arrowheadColor = "green", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.tertiaryColor = H("#cde498", 10), this.primaryBorderColor = jt(this.primaryColor, this.darkMode), this.secondaryBorderColor = jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = jt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.primaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#333", this.edgeLabelBackground = "#e8e8e8", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "#333", this.signalTextColor = "#333", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "#326932", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "#6eaa49", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#6eaa49", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "#487e3a", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, x, y, b, _, k, v;
    this.actorBorder = J(this.mainBkg, 20), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || T(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || T(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || T(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || T(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || T(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || T(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || T(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || T(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || T(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || J(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || J(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = J(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || J(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || T(this["cScale" + C], { h: 180 });
    this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { h: 30, s: -30, l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.taskBorderColor = this.border1, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || H(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || H(this.mainBkg, 20), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || T(this.primaryColor, { l: -30 }), this.pie5 = this.pie5 || T(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || T(this.tertiaryColor, { h: 40, l: -40 }), this.pie7 = this.pie7 || T(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || T(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || T(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || T(this.primaryColor, { h: 60, l: -50 }), this.pie11 = this.pie11 || T(this.primaryColor, { h: -60, l: -50 }), this.pie12 = this.pie12 || T(this.primaryColor, { h: 120, l: -50 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.mainBkg
    }, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((l = this.radar) == null ? void 0 : l.graticuleOpacity) || 0.3,
      legendBoxSize: ((c = this.radar) == null ? void 0 : c.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((p = this.xyChart) == null ? void 0 : p.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((x = this.xyChart) == null ? void 0 : x.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((y = this.xyChart) == null ? void 0 : y.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((k = this.xyChart) == null ? void 0 : k.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((v = this.xyChart) == null ? void 0 : v.plotColorPalette) || "#CDE498,#FF6B6B,#A0D2DB,#D7BDE2,#F0F0F0,#FFC3A0,#7FD8BE,#FF9A8B,#FAF3E0,#FFF176"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || T(this.primaryColor, { h: -30 }), this.git4 = this.git4 || T(this.primaryColor, { h: -60 }), this.git5 = this.git5 || T(this.primaryColor, { h: -90 }), this.git6 = this.git6 || T(this.primaryColor, { h: 60 }), this.git7 = this.git7 || T(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = H(this.git0, 25), this.git1 = H(this.git1, 25), this.git2 = H(this.git2, 25), this.git3 = H(this.git3, 25), this.git4 = H(this.git4, 25), this.git5 = H(this.git5, 25), this.git6 = H(this.git6, 25), this.git7 = H(this.git7, 25)) : (this.git0 = J(this.git0, 25), this.git1 = J(this.git1, 25), this.git2 = J(this.git2, 25), this.git3 = J(this.git3, 25), this.git4 = J(this.git4, 25), this.git5 = J(this.git5, 25), this.git6 = J(this.git6, 25), this.git7 = J(this.git7, 25)), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || z(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || z(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || ba, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Ca;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(zr, "Theme"), zr), I0 = /* @__PURE__ */ d((e) => {
  const t = new R0();
  return t.calculate(e), t;
}, "getThemeVariables"), Wr, P0 = (Wr = class {
  constructor() {
    this.primaryColor = "#eee", this.contrast = "#707070", this.secondaryColor = H(this.contrast, 55), this.background = "#ffffff", this.tertiaryColor = T(this.primaryColor, { h: -160 }), this.primaryBorderColor = jt(this.primaryColor, this.darkMode), this.secondaryBorderColor = jt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = jt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.tertiaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.mainBkg = "#eee", this.secondBkg = "calculated", this.lineColor = "#666", this.border1 = "#999", this.border2 = "calculated", this.note = "#ffa", this.text = "#333", this.critical = "#d42", this.done = "#bbb", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "white", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = this.actorBorder, this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "calculated", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBkgColor = "calculated", this.critBorderColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || H(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || "#f4f4f4", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, p, g, m, x, y, b, _, k, v;
    this.secondBkg = H(this.contrast, 55), this.border2 = this.contrast, this.actorBorder = H(this.border1, 23), this.actorBkg = this.mainBkg, this.actorTextColor = this.text, this.actorLineColor = this.actorBorder, this.signalColor = this.text, this.signalTextColor = this.text, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.text, this.loopTextColor = this.text, this.noteBorderColor = "#999", this.noteBkgColor = "#666", this.noteTextColor = "#fff", this.cScale0 = this.cScale0 || "#555", this.cScale1 = this.cScale1 || "#F4F4F4", this.cScale2 = this.cScale2 || "#555", this.cScale3 = this.cScale3 || "#BBB", this.cScale4 = this.cScale4 || "#777", this.cScale5 = this.cScale5 || "#999", this.cScale6 = this.cScale6 || "#DDD", this.cScale7 = this.cScale7 || "#FFF", this.cScale8 = this.cScale8 || "#DDD", this.cScale9 = this.cScale9 || "#BBB", this.cScale10 = this.cScale10 || "#999", this.cScale11 = this.cScale11 || "#777";
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || z(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this.darkMode ? this["cScalePeer" + C] = this["cScalePeer" + C] || H(this["cScale" + C], 10) : this["cScalePeer" + C] = this["cScalePeer" + C] || J(this["cScale" + C], 10);
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.cScaleLabel0 = this.cScaleLabel0 || this.cScale1, this.cScaleLabel2 = this.cScaleLabel2 || this.cScale1;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || T(this.mainBkg, { l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || T(this.mainBkg, { l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.text, this.sectionBkgColor = H(this.contrast, 30), this.sectionBkgColor2 = H(this.contrast, 30), this.taskBorderColor = J(this.contrast, 10), this.taskBkgColor = this.contrast, this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = this.text, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.gridColor = H(this.border1, 30), this.doneTaskBkgColor = this.done, this.doneTaskBorderColor = this.lineColor, this.critBkgColor = this.critical, this.critBorderColor = J(this.critBkgColor, 10), this.todayLineColor = this.critBkgColor, this.vertLineColor = this.critBkgColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || "#000", this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f4f4f4", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.stateBorder = this.stateBorder || "#000", this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#222", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = T(this.primaryColor, { h: 64 }), this.fillType3 = T(this.secondaryColor, { h: 64 }), this.fillType4 = T(this.primaryColor, { h: -64 }), this.fillType5 = T(this.secondaryColor, { h: -64 }), this.fillType6 = T(this.primaryColor, { h: 128 }), this.fillType7 = T(this.secondaryColor, { h: 128 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pie12 = this.pie0, this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || T(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || T(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || T(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || T(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || T(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || T(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : J(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((l = this.xyChart) == null ? void 0 : l.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((c = this.xyChart) == null ? void 0 : c.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#EEE,#6BB8E4,#8ACB88,#C7ACD6,#E8DCC2,#FFB2A8,#FFF380,#7E8D91,#FFD8B1,#FAF3E0"
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((p = this.radar) == null ? void 0 : p.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((x = this.radar) == null ? void 0 : x.curveStrokeWidth) || 2,
      graticuleColor: ((y = this.radar) == null ? void 0 : y.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((_ = this.radar) == null ? void 0 : _.graticuleOpacity) || 0.3,
      legendBoxSize: ((k = this.radar) == null ? void 0 : k.legendBoxSize) || 12,
      legendFontSize: ((v = this.radar) == null ? void 0 : v.legendFontSize) || 12
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = J(this.pie1, 25) || this.primaryColor, this.git1 = this.pie2 || this.secondaryColor, this.git2 = this.pie3 || this.tertiaryColor, this.git3 = this.pie4 || T(this.primaryColor, { h: -30 }), this.git4 = this.pie5 || T(this.primaryColor, { h: -60 }), this.git5 = this.pie6 || T(this.primaryColor, { h: -90 }), this.git6 = this.pie7 || T(this.primaryColor, { h: 60 }), this.git7 = this.pie8 || T(this.primaryColor, { h: 120 }), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.branchLabelColor = this.branchLabelColor || this.labelTextColor, this.gitBranchLabel0 = this.branchLabelColor, this.gitBranchLabel1 = "white", this.gitBranchLabel2 = this.branchLabelColor, this.gitBranchLabel3 = "white", this.gitBranchLabel4 = this.branchLabelColor, this.gitBranchLabel5 = this.branchLabelColor, this.gitBranchLabel6 = this.branchLabelColor, this.gitBranchLabel7 = this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || ba, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Ca;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, d(Wr, "Theme"), Wr), N0 = /* @__PURE__ */ d((e) => {
  const t = new P0();
  return t.calculate(e), t;
}, "getThemeVariables"), Re = {
  base: {
    getThemeVariables: E0
  },
  dark: {
    getThemeVariables: F0
  },
  default: {
    getThemeVariables: O0
  },
  forest: {
    getThemeVariables: I0
  },
  neutral: {
    getThemeVariables: N0
  }
}, ye = {
  flowchart: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    subGraphTitleMargin: {
      top: 0,
      bottom: 0
    },
    diagramPadding: 8,
    htmlLabels: !0,
    nodeSpacing: 50,
    rankSpacing: 50,
    curve: "basis",
    padding: 15,
    defaultRenderer: "dagre-wrapper",
    wrappingWidth: 200,
    inheritDir: !1
  },
  sequence: {
    useMaxWidth: !0,
    hideUnusedParticipants: !1,
    activationWidth: 10,
    diagramMarginX: 50,
    diagramMarginY: 10,
    actorMargin: 50,
    width: 150,
    height: 65,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    mirrorActors: !0,
    forceMenus: !1,
    bottomMarginAdj: 1,
    rightAngles: !1,
    showSequenceNumbers: !1,
    actorFontSize: 14,
    actorFontFamily: '"Open Sans", sans-serif',
    actorFontWeight: 400,
    noteFontSize: 14,
    noteFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    noteFontWeight: 400,
    noteAlign: "center",
    messageFontSize: 16,
    messageFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    messageFontWeight: 400,
    wrap: !1,
    wrapPadding: 10,
    labelBoxWidth: 50,
    labelBoxHeight: 20
  },
  gantt: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    barHeight: 20,
    barGap: 4,
    topPadding: 50,
    rightPadding: 75,
    leftPadding: 75,
    gridLineStartPadding: 35,
    fontSize: 11,
    sectionFontSize: 11,
    numberSectionStyles: 4,
    axisFormat: "%Y-%m-%d",
    topAxis: !1,
    displayMode: "",
    weekday: "sunday"
  },
  journey: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    maxLabelWidth: 360,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    titleColor: "",
    titleFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    titleFontSize: "4ex"
  },
  class: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    arrowMarkerAbsolute: !1,
    dividerMargin: 10,
    padding: 5,
    textHeight: 10,
    defaultRenderer: "dagre-wrapper",
    htmlLabels: !1,
    hideEmptyMembersBox: !1
  },
  state: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    dividerMargin: 10,
    sizeUnit: 5,
    padding: 8,
    textHeight: 10,
    titleShift: -15,
    noteMargin: 10,
    forkWidth: 70,
    forkHeight: 7,
    miniPadding: 2,
    fontSizeFactor: 5.02,
    fontSize: 24,
    labelHeight: 16,
    edgeLengthFactor: "20",
    compositTitleSize: 35,
    radius: 5,
    defaultRenderer: "dagre-wrapper"
  },
  er: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 20,
    layoutDirection: "TB",
    minEntityWidth: 100,
    minEntityHeight: 75,
    entityPadding: 15,
    nodeSpacing: 140,
    rankSpacing: 80,
    stroke: "gray",
    fill: "honeydew",
    fontSize: 12
  },
  pie: {
    useMaxWidth: !0,
    textPosition: 0.75
  },
  quadrantChart: {
    useMaxWidth: !0,
    chartWidth: 500,
    chartHeight: 500,
    titleFontSize: 20,
    titlePadding: 10,
    quadrantPadding: 5,
    xAxisLabelPadding: 5,
    yAxisLabelPadding: 5,
    xAxisLabelFontSize: 16,
    yAxisLabelFontSize: 16,
    quadrantLabelFontSize: 16,
    quadrantTextTopPadding: 5,
    pointTextPadding: 5,
    pointLabelFontSize: 12,
    pointRadius: 5,
    xAxisPosition: "top",
    yAxisPosition: "left",
    quadrantInternalBorderStrokeWidth: 1,
    quadrantExternalBorderStrokeWidth: 2
  },
  xyChart: {
    useMaxWidth: !0,
    width: 700,
    height: 500,
    titleFontSize: 20,
    titlePadding: 10,
    showDataLabel: !1,
    showTitle: !0,
    xAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    yAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    chartOrientation: "vertical",
    plotReservedSpacePercent: 50
  },
  requirement: {
    useMaxWidth: !0,
    rect_fill: "#f9f9f9",
    text_color: "#333",
    rect_border_size: "0.5px",
    rect_border_color: "#bbb",
    rect_min_width: 200,
    rect_min_height: 200,
    fontSize: 14,
    rect_padding: 10,
    line_height: 20
  },
  mindmap: {
    useMaxWidth: !0,
    padding: 10,
    maxNodeWidth: 200,
    layoutAlgorithm: "cose-bilkent"
  },
  kanban: {
    useMaxWidth: !0,
    padding: 8,
    sectionWidth: 200,
    ticketBaseUrl: ""
  },
  timeline: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    disableMulticolor: !1
  },
  gitGraph: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 8,
    nodeLabel: {
      width: 75,
      height: 100,
      x: -25,
      y: 0
    },
    mainBranchName: "main",
    mainBranchOrder: 0,
    showCommitLabel: !0,
    showBranches: !0,
    rotateCommitLabel: !0,
    parallelCommits: !1,
    arrowMarkerAbsolute: !1
  },
  c4: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    c4ShapeMargin: 50,
    c4ShapePadding: 20,
    width: 216,
    height: 60,
    boxMargin: 10,
    c4ShapeInRow: 4,
    nextLinePaddingX: 0,
    c4BoundaryInRow: 2,
    personFontSize: 14,
    personFontFamily: '"Open Sans", sans-serif',
    personFontWeight: "normal",
    external_personFontSize: 14,
    external_personFontFamily: '"Open Sans", sans-serif',
    external_personFontWeight: "normal",
    systemFontSize: 14,
    systemFontFamily: '"Open Sans", sans-serif',
    systemFontWeight: "normal",
    external_systemFontSize: 14,
    external_systemFontFamily: '"Open Sans", sans-serif',
    external_systemFontWeight: "normal",
    system_dbFontSize: 14,
    system_dbFontFamily: '"Open Sans", sans-serif',
    system_dbFontWeight: "normal",
    external_system_dbFontSize: 14,
    external_system_dbFontFamily: '"Open Sans", sans-serif',
    external_system_dbFontWeight: "normal",
    system_queueFontSize: 14,
    system_queueFontFamily: '"Open Sans", sans-serif',
    system_queueFontWeight: "normal",
    external_system_queueFontSize: 14,
    external_system_queueFontFamily: '"Open Sans", sans-serif',
    external_system_queueFontWeight: "normal",
    boundaryFontSize: 14,
    boundaryFontFamily: '"Open Sans", sans-serif',
    boundaryFontWeight: "normal",
    messageFontSize: 12,
    messageFontFamily: '"Open Sans", sans-serif',
    messageFontWeight: "normal",
    containerFontSize: 14,
    containerFontFamily: '"Open Sans", sans-serif',
    containerFontWeight: "normal",
    external_containerFontSize: 14,
    external_containerFontFamily: '"Open Sans", sans-serif',
    external_containerFontWeight: "normal",
    container_dbFontSize: 14,
    container_dbFontFamily: '"Open Sans", sans-serif',
    container_dbFontWeight: "normal",
    external_container_dbFontSize: 14,
    external_container_dbFontFamily: '"Open Sans", sans-serif',
    external_container_dbFontWeight: "normal",
    container_queueFontSize: 14,
    container_queueFontFamily: '"Open Sans", sans-serif',
    container_queueFontWeight: "normal",
    external_container_queueFontSize: 14,
    external_container_queueFontFamily: '"Open Sans", sans-serif',
    external_container_queueFontWeight: "normal",
    componentFontSize: 14,
    componentFontFamily: '"Open Sans", sans-serif',
    componentFontWeight: "normal",
    external_componentFontSize: 14,
    external_componentFontFamily: '"Open Sans", sans-serif',
    external_componentFontWeight: "normal",
    component_dbFontSize: 14,
    component_dbFontFamily: '"Open Sans", sans-serif',
    component_dbFontWeight: "normal",
    external_component_dbFontSize: 14,
    external_component_dbFontFamily: '"Open Sans", sans-serif',
    external_component_dbFontWeight: "normal",
    component_queueFontSize: 14,
    component_queueFontFamily: '"Open Sans", sans-serif',
    component_queueFontWeight: "normal",
    external_component_queueFontSize: 14,
    external_component_queueFontFamily: '"Open Sans", sans-serif',
    external_component_queueFontWeight: "normal",
    wrap: !0,
    wrapPadding: 10,
    person_bg_color: "#08427B",
    person_border_color: "#073B6F",
    external_person_bg_color: "#686868",
    external_person_border_color: "#8A8A8A",
    system_bg_color: "#1168BD",
    system_border_color: "#3C7FC0",
    system_db_bg_color: "#1168BD",
    system_db_border_color: "#3C7FC0",
    system_queue_bg_color: "#1168BD",
    system_queue_border_color: "#3C7FC0",
    external_system_bg_color: "#999999",
    external_system_border_color: "#8A8A8A",
    external_system_db_bg_color: "#999999",
    external_system_db_border_color: "#8A8A8A",
    external_system_queue_bg_color: "#999999",
    external_system_queue_border_color: "#8A8A8A",
    container_bg_color: "#438DD5",
    container_border_color: "#3C7FC0",
    container_db_bg_color: "#438DD5",
    container_db_border_color: "#3C7FC0",
    container_queue_bg_color: "#438DD5",
    container_queue_border_color: "#3C7FC0",
    external_container_bg_color: "#B3B3B3",
    external_container_border_color: "#A6A6A6",
    external_container_db_bg_color: "#B3B3B3",
    external_container_db_border_color: "#A6A6A6",
    external_container_queue_bg_color: "#B3B3B3",
    external_container_queue_border_color: "#A6A6A6",
    component_bg_color: "#85BBF0",
    component_border_color: "#78A8D8",
    component_db_bg_color: "#85BBF0",
    component_db_border_color: "#78A8D8",
    component_queue_bg_color: "#85BBF0",
    component_queue_border_color: "#78A8D8",
    external_component_bg_color: "#CCCCCC",
    external_component_border_color: "#BFBFBF",
    external_component_db_bg_color: "#CCCCCC",
    external_component_db_border_color: "#BFBFBF",
    external_component_queue_bg_color: "#CCCCCC",
    external_component_queue_border_color: "#BFBFBF"
  },
  sankey: {
    useMaxWidth: !0,
    width: 600,
    height: 400,
    linkColor: "gradient",
    nodeAlignment: "justify",
    showValues: !0,
    prefix: "",
    suffix: ""
  },
  block: {
    useMaxWidth: !0,
    padding: 8
  },
  packet: {
    useMaxWidth: !0,
    rowHeight: 32,
    bitWidth: 32,
    bitsPerRow: 32,
    showBits: !0,
    paddingX: 5,
    paddingY: 5
  },
  architecture: {
    useMaxWidth: !0,
    padding: 40,
    iconSize: 80,
    fontSize: 16
  },
  radar: {
    useMaxWidth: !0,
    width: 600,
    height: 600,
    marginTop: 50,
    marginRight: 50,
    marginBottom: 50,
    marginLeft: 50,
    axisScaleFactor: 1,
    axisLabelFactor: 1.05,
    curveTension: 0.17
  },
  theme: "default",
  look: "classic",
  handDrawnSeed: 0,
  layout: "dagre",
  maxTextSize: 5e4,
  maxEdges: 500,
  darkMode: !1,
  fontFamily: '"trebuchet ms", verdana, arial, sans-serif;',
  logLevel: 5,
  securityLevel: "strict",
  startOnLoad: !0,
  arrowMarkerAbsolute: !1,
  secure: [
    "secure",
    "securityLevel",
    "startOnLoad",
    "maxTextSize",
    "suppressErrorRendering",
    "maxEdges"
  ],
  legacyMathML: !1,
  forceLegacyMathML: !1,
  deterministicIds: !1,
  fontSize: 16,
  markdownAutoWrap: !0,
  suppressErrorRendering: !1
}, Mh = {
  ...ye,
  // Set, even though they're `undefined` so that `configKeys` finds these keys
  // TODO: Should we replace these with `null` so that they can go in the JSON Schema?
  deterministicIDSeed: void 0,
  elk: {
    // mergeEdges is needed here to be considered
    mergeEdges: !1,
    nodePlacementStrategy: "BRANDES_KOEPF",
    forceNodeModelOrder: !1,
    considerModelOrder: "NODES_AND_EDGES"
  },
  themeCSS: void 0,
  // add non-JSON default config values
  themeVariables: Re.default.getThemeVariables(),
  sequence: {
    ...ye.sequence,
    messageFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont"),
    noteFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.noteFontFamily,
        fontSize: this.noteFontSize,
        fontWeight: this.noteFontWeight
      };
    }, "noteFont"),
    actorFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.actorFontFamily,
        fontSize: this.actorFontSize,
        fontWeight: this.actorFontWeight
      };
    }, "actorFont")
  },
  class: {
    hideEmptyMembersBox: !1
  },
  gantt: {
    ...ye.gantt,
    tickInterval: void 0,
    useWidth: void 0
    // can probably be removed since `configKeys` already includes this
  },
  c4: {
    ...ye.c4,
    useWidth: void 0,
    personFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.personFontFamily,
        fontSize: this.personFontSize,
        fontWeight: this.personFontWeight
      };
    }, "personFont"),
    flowchart: {
      ...ye.flowchart,
      inheritDir: !1
      // default to legacy behavior
    },
    external_personFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_personFontFamily,
        fontSize: this.external_personFontSize,
        fontWeight: this.external_personFontWeight
      };
    }, "external_personFont"),
    systemFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.systemFontFamily,
        fontSize: this.systemFontSize,
        fontWeight: this.systemFontWeight
      };
    }, "systemFont"),
    external_systemFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_systemFontFamily,
        fontSize: this.external_systemFontSize,
        fontWeight: this.external_systemFontWeight
      };
    }, "external_systemFont"),
    system_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.system_dbFontFamily,
        fontSize: this.system_dbFontSize,
        fontWeight: this.system_dbFontWeight
      };
    }, "system_dbFont"),
    external_system_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_system_dbFontFamily,
        fontSize: this.external_system_dbFontSize,
        fontWeight: this.external_system_dbFontWeight
      };
    }, "external_system_dbFont"),
    system_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.system_queueFontFamily,
        fontSize: this.system_queueFontSize,
        fontWeight: this.system_queueFontWeight
      };
    }, "system_queueFont"),
    external_system_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_system_queueFontFamily,
        fontSize: this.external_system_queueFontSize,
        fontWeight: this.external_system_queueFontWeight
      };
    }, "external_system_queueFont"),
    containerFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.containerFontFamily,
        fontSize: this.containerFontSize,
        fontWeight: this.containerFontWeight
      };
    }, "containerFont"),
    external_containerFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_containerFontFamily,
        fontSize: this.external_containerFontSize,
        fontWeight: this.external_containerFontWeight
      };
    }, "external_containerFont"),
    container_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.container_dbFontFamily,
        fontSize: this.container_dbFontSize,
        fontWeight: this.container_dbFontWeight
      };
    }, "container_dbFont"),
    external_container_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_container_dbFontFamily,
        fontSize: this.external_container_dbFontSize,
        fontWeight: this.external_container_dbFontWeight
      };
    }, "external_container_dbFont"),
    container_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.container_queueFontFamily,
        fontSize: this.container_queueFontSize,
        fontWeight: this.container_queueFontWeight
      };
    }, "container_queueFont"),
    external_container_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_container_queueFontFamily,
        fontSize: this.external_container_queueFontSize,
        fontWeight: this.external_container_queueFontWeight
      };
    }, "external_container_queueFont"),
    componentFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.componentFontFamily,
        fontSize: this.componentFontSize,
        fontWeight: this.componentFontWeight
      };
    }, "componentFont"),
    external_componentFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_componentFontFamily,
        fontSize: this.external_componentFontSize,
        fontWeight: this.external_componentFontWeight
      };
    }, "external_componentFont"),
    component_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.component_dbFontFamily,
        fontSize: this.component_dbFontSize,
        fontWeight: this.component_dbFontWeight
      };
    }, "component_dbFont"),
    external_component_dbFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_component_dbFontFamily,
        fontSize: this.external_component_dbFontSize,
        fontWeight: this.external_component_dbFontWeight
      };
    }, "external_component_dbFont"),
    component_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.component_queueFontFamily,
        fontSize: this.component_queueFontSize,
        fontWeight: this.component_queueFontWeight
      };
    }, "component_queueFont"),
    external_component_queueFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.external_component_queueFontFamily,
        fontSize: this.external_component_queueFontSize,
        fontWeight: this.external_component_queueFontWeight
      };
    }, "external_component_queueFont"),
    boundaryFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.boundaryFontFamily,
        fontSize: this.boundaryFontSize,
        fontWeight: this.boundaryFontWeight
      };
    }, "boundaryFont"),
    messageFont: /* @__PURE__ */ d(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont")
  },
  pie: {
    ...ye.pie,
    useWidth: 984
  },
  xyChart: {
    ...ye.xyChart,
    useWidth: void 0
  },
  requirement: {
    ...ye.requirement,
    useWidth: void 0
  },
  packet: {
    ...ye.packet
  },
  radar: {
    ...ye.radar
  },
  treemap: {
    useMaxWidth: !0,
    padding: 10,
    diagramPadding: 8,
    showValues: !0,
    nodeWidth: 100,
    nodeHeight: 40,
    borderWidth: 1,
    valueFontSize: 12,
    labelFontSize: 14,
    valueFormat: ","
  }
}, Eh = /* @__PURE__ */ d((e, t = "") => Object.keys(e).reduce((r, i) => Array.isArray(e[i]) ? r : typeof e[i] == "object" && e[i] !== null ? [...r, t + i, ...Eh(e[i], "")] : [...r, t + i], []), "keyify"), z0 = new Set(Eh(Mh, "")), $h = Mh, Rn = /* @__PURE__ */ d((e) => {
  if (F.debug("sanitizeDirective called with", e), !(typeof e != "object" || e == null)) {
    if (Array.isArray(e)) {
      e.forEach((t) => Rn(t));
      return;
    }
    for (const t of Object.keys(e)) {
      if (F.debug("Checking key", t), t.startsWith("__") || t.includes("proto") || t.includes("constr") || !z0.has(t) || e[t] == null) {
        F.debug("sanitize deleting key: ", t), delete e[t];
        continue;
      }
      if (typeof e[t] == "object") {
        F.debug("sanitizing object", t), Rn(e[t]);
        continue;
      }
      const r = ["themeCSS", "fontFamily", "altFontFamily"];
      for (const i of r)
        t.includes(i) && (F.debug("sanitizing css option", t), e[t] = W0(e[t]));
    }
    if (e.themeVariables)
      for (const t of Object.keys(e.themeVariables)) {
        const r = e.themeVariables[t];
        r != null && r.match && !r.match(/^[\d "#%(),.;A-Za-z]+$/) && (e.themeVariables[t] = "");
      }
    F.debug("After sanitization", e);
  }
}, "sanitizeDirective"), W0 = /* @__PURE__ */ d((e) => {
  let t = 0, r = 0;
  for (const i of e) {
    if (t < r)
      return "{ /* ERROR: Unbalanced CSS */ }";
    i === "{" ? t++ : i === "}" && r++;
  }
  return t !== r ? "{ /* ERROR: Unbalanced CSS */ }" : e;
}, "sanitizeCss"), Yr = Object.freeze($h), Kt = Bt({}, Yr), In, ur = [], Ei = Bt({}, Yr), _a = /* @__PURE__ */ d((e, t) => {
  let r = Bt({}, e), i = {};
  for (const n of t)
    Oh(n), i = Bt(i, n);
  if (r = Bt(r, i), i.theme && i.theme in Re) {
    const n = Bt({}, In), a = Bt(
      n.themeVariables || {},
      i.themeVariables
    );
    r.theme && r.theme in Re && (r.themeVariables = Re[r.theme].getThemeVariables(a));
  }
  return Ei = r, Rh(Ei), Ei;
}, "updateCurrentConfig"), q0 = /* @__PURE__ */ d((e) => (Kt = Bt({}, Yr), Kt = Bt(Kt, e), e.theme && Re[e.theme] && (Kt.themeVariables = Re[e.theme].getThemeVariables(e.themeVariables)), _a(Kt, ur), Kt), "setSiteConfig"), H0 = /* @__PURE__ */ d((e) => {
  In = Bt({}, e);
}, "saveConfigFromInitialize"), j0 = /* @__PURE__ */ d((e) => (Kt = Bt(Kt, e), _a(Kt, ur), Kt), "updateSiteConfig"), Fh = /* @__PURE__ */ d(() => Bt({}, Kt), "getSiteConfig"), Dh = /* @__PURE__ */ d((e) => (Rh(e), Bt(Ei, e), Pt()), "setConfig"), Pt = /* @__PURE__ */ d(() => Bt({}, Ei), "getConfig"), Oh = /* @__PURE__ */ d((e) => {
  e && (["secure", ...Kt.secure ?? []].forEach((t) => {
    Object.hasOwn(e, t) && (F.debug(`Denied attempt to modify a secure key ${t}`, e[t]), delete e[t]);
  }), Object.keys(e).forEach((t) => {
    t.startsWith("__") && delete e[t];
  }), Object.keys(e).forEach((t) => {
    typeof e[t] == "string" && (e[t].includes("<") || e[t].includes(">") || e[t].includes("url(data:")) && delete e[t], typeof e[t] == "object" && Oh(e[t]);
  }));
}, "sanitize"), Y0 = /* @__PURE__ */ d((e) => {
  var t;
  Rn(e), e.fontFamily && !((t = e.themeVariables) != null && t.fontFamily) && (e.themeVariables = {
    ...e.themeVariables,
    fontFamily: e.fontFamily
  }), ur.push(e), _a(Kt, ur);
}, "addDirective"), Pn = /* @__PURE__ */ d((e = Kt) => {
  ur = [], _a(e, ur);
}, "reset"), U0 = {
  LAZY_LOAD_DEPRECATED: "The configuration options lazyLoadedDiagrams and loadExternalDiagramsAtStartup are deprecated. Please use registerExternalDiagrams instead."
}, Zl = {}, G0 = /* @__PURE__ */ d((e) => {
  Zl[e] || (F.warn(U0[e]), Zl[e] = !0);
}, "issueWarning"), Rh = /* @__PURE__ */ d((e) => {
  e && (e.lazyLoadedDiagrams || e.loadExternalDiagramsAtStartup) && G0("LAZY_LOAD_DEPRECATED");
}, "checkConfig"), HL = /* @__PURE__ */ d(() => {
  let e = {};
  In && (e = Bt(e, In));
  for (const t of ur)
    e = Bt(e, t);
  return e;
}, "getUserDefinedConfig"), Xi = /<br\s*\/?>/gi, X0 = /* @__PURE__ */ d((e) => e ? Nh(e).replace(/\\n/g, "#br#").split("#br#") : [""], "getRows"), V0 = /* @__PURE__ */ (() => {
  let e = !1;
  return () => {
    e || (Ih(), e = !0);
  };
})();
function Ih() {
  const e = "data-temp-href-target";
  jr.addHook("beforeSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute("target") && t.setAttribute(e, t.getAttribute("target") ?? "");
  }), jr.addHook("afterSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute(e) && (t.setAttribute("target", t.getAttribute(e) ?? ""), t.removeAttribute(e), t.getAttribute("target") === "_blank" && t.setAttribute("rel", "noopener"));
  });
}
d(Ih, "setupDompurifyHooks");
var Ph = /* @__PURE__ */ d((e) => (V0(), jr.sanitize(e)), "removeScript"), Kl = /* @__PURE__ */ d((e, t) => {
  var r;
  if (((r = t.flowchart) == null ? void 0 : r.htmlLabels) !== !1) {
    const i = t.securityLevel;
    i === "antiscript" || i === "strict" ? e = Ph(e) : i !== "loose" && (e = Nh(e), e = e.replace(/</g, "&lt;").replace(/>/g, "&gt;"), e = e.replace(/=/g, "&equals;"), e = J0(e));
  }
  return e;
}, "sanitizeMore"), se = /* @__PURE__ */ d((e, t) => e && (t.dompurifyConfig ? e = jr.sanitize(Kl(e, t), t.dompurifyConfig).toString() : e = jr.sanitize(Kl(e, t), {
  FORBID_TAGS: ["style"]
}).toString(), e), "sanitizeText"), Z0 = /* @__PURE__ */ d((e, t) => typeof e == "string" ? se(e, t) : e.flat().map((r) => se(r, t)), "sanitizeTextOrArray"), K0 = /* @__PURE__ */ d((e) => Xi.test(e), "hasBreaks"), Q0 = /* @__PURE__ */ d((e) => e.split(Xi), "splitBreaks"), J0 = /* @__PURE__ */ d((e) => e.replace(/#br#/g, "<br/>"), "placeholderToBreak"), Nh = /* @__PURE__ */ d((e) => e.replace(Xi, "#br#"), "breakToPlaceholder"), zh = /* @__PURE__ */ d((e) => {
  let t = "";
  return e && (t = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, t = CSS.escape(t)), t;
}, "getUrl"), At = /* @__PURE__ */ d((e) => !(e === !1 || ["false", "null", "0"].includes(String(e).trim().toLowerCase())), "evaluate"), ty = /* @__PURE__ */ d(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.max(...t);
}, "getMax"), ey = /* @__PURE__ */ d(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.min(...t);
}, "getMin"), Ql = /* @__PURE__ */ d(function(e) {
  const t = e.split(/(,)/), r = [];
  for (let i = 0; i < t.length; i++) {
    let n = t[i];
    if (n === "," && i > 0 && i + 1 < t.length) {
      const a = t[i - 1], o = t[i + 1];
      ry(a, o) && (n = a + "," + o, i++, r.pop());
    }
    r.push(iy(n));
  }
  return r.join("");
}, "parseGenericTypes"), Ss = /* @__PURE__ */ d((e, t) => Math.max(0, e.split(t).length - 1), "countOccurrence"), ry = /* @__PURE__ */ d((e, t) => {
  const r = Ss(e, "~"), i = Ss(t, "~");
  return r === 1 && i === 1;
}, "shouldCombineSets"), iy = /* @__PURE__ */ d((e) => {
  const t = Ss(e, "~");
  let r = !1;
  if (t <= 1)
    return e;
  t % 2 !== 0 && e.startsWith("~") && (e = e.substring(1), r = !0);
  const i = [...e];
  let n = i.indexOf("~"), a = i.lastIndexOf("~");
  for (; n !== -1 && a !== -1 && n !== a; )
    i[n] = "<", i[a] = ">", n = i.indexOf("~"), a = i.lastIndexOf("~");
  return r && i.unshift("~"), i.join("");
}, "processSet"), Jl = /* @__PURE__ */ d(() => window.MathMLElement !== void 0, "isMathMLSupported"), Ts = /\$\$(.*)\$\$/g, Ur = /* @__PURE__ */ d((e) => {
  var t;
  return (((t = e.match(Ts)) == null ? void 0 : t.length) ?? 0) > 0;
}, "hasKatex"), jL = /* @__PURE__ */ d(async (e, t) => {
  const r = document.createElement("div");
  r.innerHTML = await _o(e, t), r.id = "katex-temp", r.style.visibility = "hidden", r.style.position = "absolute", r.style.top = "0";
  const i = document.querySelector("body");
  i == null || i.insertAdjacentElement("beforeend", r);
  const n = { width: r.clientWidth, height: r.clientHeight };
  return r.remove(), n;
}, "calculateMathMLDimensions"), ny = /* @__PURE__ */ d(async (e, t) => {
  if (!Ur(e))
    return e;
  if (!(Jl() || t.legacyMathML || t.forceLegacyMathML))
    return e.replace(Ts, "MathML is unsupported in this environment.");
  {
    const { default: r } = await import("./katex-DfcU2jCX.js"), i = t.forceLegacyMathML || !Jl() && t.legacyMathML ? "htmlAndMathml" : "mathml";
    return e.split(Xi).map(
      (n) => Ur(n) ? `<div style="display: flex; align-items: center; justify-content: center; white-space: nowrap;">${n}</div>` : `<div>${n}</div>`
    ).join("").replace(
      Ts,
      (n, a) => r.renderToString(a, {
        throwOnError: !0,
        displayMode: !0,
        output: i
      }).replace(/\n/g, " ").replace(/<annotation.*<\/annotation>/g, "")
    );
  }
}, "renderKatexUnsanitized"), _o = /* @__PURE__ */ d(async (e, t) => se(await ny(e, t), t), "renderKatexSanitized"), Jr = {
  getRows: X0,
  sanitizeText: se,
  sanitizeTextOrArray: Z0,
  hasBreaks: K0,
  splitBreaks: Q0,
  lineBreakRegex: Xi,
  removeScript: Ph,
  getUrl: zh,
  evaluate: At,
  getMax: ty,
  getMin: ey
}, ay = /* @__PURE__ */ d(function(e, t) {
  for (let r of t)
    e.attr(r[0], r[1]);
}, "d3Attrs"), sy = /* @__PURE__ */ d(function(e, t, r) {
  let i = /* @__PURE__ */ new Map();
  return r ? (i.set("width", "100%"), i.set("style", `max-width: ${t}px;`)) : (i.set("height", e), i.set("width", t)), i;
}, "calculateSvgSizeAttrs"), Wh = /* @__PURE__ */ d(function(e, t, r, i) {
  const n = sy(t, r, i);
  ay(e, n);
}, "configureSvgSize"), oy = /* @__PURE__ */ d(function(e, t, r, i) {
  const n = t.node().getBBox(), a = n.width, o = n.height;
  F.info(`SVG bounds: ${a}x${o}`, n);
  let s = 0, l = 0;
  F.info(`Graph bounds: ${s}x${l}`, e), s = a + r * 2, l = o + r * 2, F.info(`Calculated bounds: ${s}x${l}`), Wh(t, l, s, i);
  const c = `${n.x - r} ${n.y - r} ${n.width + 2 * r} ${n.height + 2 * r}`;
  t.attr("viewBox", c);
}, "setupGraphViewbox"), vn = {}, ly = /* @__PURE__ */ d((e, t, r) => {
  let i = "";
  return e in vn && vn[e] ? i = vn[e](r) : F.warn(`No theme found for ${e}`), ` & {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
    fill: ${r.textColor}
  }
  @keyframes edge-animation-frame {
    from {
      stroke-dashoffset: 0;
    }
  }
  @keyframes dash {
    to {
      stroke-dashoffset: 0;
    }
  }
  & .edge-animation-slow {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 50s linear infinite;
    stroke-linecap: round;
  }
  & .edge-animation-fast {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 20s linear infinite;
    stroke-linecap: round;
  }
  /* Classes common for multiple diagrams */

  & .error-icon {
    fill: ${r.errorBkgColor};
  }
  & .error-text {
    fill: ${r.errorTextColor};
    stroke: ${r.errorTextColor};
  }

  & .edge-thickness-normal {
    stroke-width: 1px;
  }
  & .edge-thickness-thick {
    stroke-width: 3.5px
  }
  & .edge-pattern-solid {
    stroke-dasharray: 0;
  }
  & .edge-thickness-invisible {
    stroke-width: 0;
    fill: none;
  }
  & .edge-pattern-dashed{
    stroke-dasharray: 3;
  }
  .edge-pattern-dotted {
    stroke-dasharray: 2;
  }

  & .marker {
    fill: ${r.lineColor};
    stroke: ${r.lineColor};
  }
  & .marker.cross {
    stroke: ${r.lineColor};
  }

  & svg {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
  }
   & p {
    margin: 0
   }

  ${i}

  ${t}
`;
}, "getStyles"), cy = /* @__PURE__ */ d((e, t) => {
  t !== void 0 && (vn[e] = t);
}, "addStylesForDiagram"), hy = ly, qh = {};
Jm(qh, {
  clear: () => uy,
  getAccDescription: () => gy,
  getAccTitle: () => py,
  getDiagramTitle: () => yy,
  setAccDescription: () => dy,
  setAccTitle: () => fy,
  setDiagramTitle: () => my
});
var wo = "", vo = "", ko = "", So = /* @__PURE__ */ d((e) => se(e, Pt()), "sanitizeText"), uy = /* @__PURE__ */ d(() => {
  wo = "", ko = "", vo = "";
}, "clear"), fy = /* @__PURE__ */ d((e) => {
  wo = So(e).replace(/^\s+/g, "");
}, "setAccTitle"), py = /* @__PURE__ */ d(() => wo, "getAccTitle"), dy = /* @__PURE__ */ d((e) => {
  ko = So(e).replace(/\n\s+/g, `
`);
}, "setAccDescription"), gy = /* @__PURE__ */ d(() => ko, "getAccDescription"), my = /* @__PURE__ */ d((e) => {
  vo = So(e);
}, "setDiagramTitle"), yy = /* @__PURE__ */ d(() => vo, "getDiagramTitle"), tc = F, xy = bo, ut = Pt, YL = Dh, UL = Yr, To = /* @__PURE__ */ d((e) => se(e, ut()), "sanitizeText"), by = oy, Cy = /* @__PURE__ */ d(() => qh, "getCommonDb"), Nn = {}, zn = /* @__PURE__ */ d((e, t, r) => {
  var i;
  Nn[e] && tc.warn(`Diagram with id ${e} already registered. Overwriting.`), Nn[e] = t, r && Ah(e, r), cy(e, t.styles), (i = t.injectUtils) == null || i.call(
    t,
    tc,
    xy,
    ut,
    To,
    by,
    Cy(),
    () => {
    }
  );
}, "registerDiagram"), Bs = /* @__PURE__ */ d((e) => {
  if (e in Nn)
    return Nn[e];
  throw new _y(e);
}, "getDiagram"), qr, _y = (qr = class extends Error {
  constructor(t) {
    super(`Diagram ${t} not found.`);
  }
}, d(qr, "DiagramNotFoundError"), qr), wy = { value: () => {
} };
function Hh() {
  for (var e = 0, t = arguments.length, r = {}, i; e < t; ++e) {
    if (!(i = arguments[e] + "") || i in r || /[\s.]/.test(i)) throw new Error("illegal type: " + i);
    r[i] = [];
  }
  return new kn(r);
}
function kn(e) {
  this._ = e;
}
function vy(e, t) {
  return e.trim().split(/^|\s+/).map(function(r) {
    var i = "", n = r.indexOf(".");
    if (n >= 0 && (i = r.slice(n + 1), r = r.slice(0, n)), r && !t.hasOwnProperty(r)) throw new Error("unknown type: " + r);
    return { type: r, name: i };
  });
}
kn.prototype = Hh.prototype = {
  constructor: kn,
  on: function(e, t) {
    var r = this._, i = vy(e + "", r), n, a = -1, o = i.length;
    if (arguments.length < 2) {
      for (; ++a < o; ) if ((n = (e = i[a]).type) && (n = ky(r[n], e.name))) return n;
      return;
    }
    if (t != null && typeof t != "function") throw new Error("invalid callback: " + t);
    for (; ++a < o; )
      if (n = (e = i[a]).type) r[n] = ec(r[n], e.name, t);
      else if (t == null) for (n in r) r[n] = ec(r[n], e.name, null);
    return this;
  },
  copy: function() {
    var e = {}, t = this._;
    for (var r in t) e[r] = t[r].slice();
    return new kn(e);
  },
  call: function(e, t) {
    if ((n = arguments.length - 2) > 0) for (var r = new Array(n), i = 0, n, a; i < n; ++i) r[i] = arguments[i + 2];
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (a = this._[e], i = 0, n = a.length; i < n; ++i) a[i].value.apply(t, r);
  },
  apply: function(e, t, r) {
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (var i = this._[e], n = 0, a = i.length; n < a; ++n) i[n].value.apply(t, r);
  }
};
function ky(e, t) {
  for (var r = 0, i = e.length, n; r < i; ++r)
    if ((n = e[r]).name === t)
      return n.value;
}
function ec(e, t, r) {
  for (var i = 0, n = e.length; i < n; ++i)
    if (e[i].name === t) {
      e[i] = wy, e = e.slice(0, i).concat(e.slice(i + 1));
      break;
    }
  return r != null && e.push({ name: t, value: r }), e;
}
var Ls = "http://www.w3.org/1999/xhtml";
const rc = {
  svg: "http://www.w3.org/2000/svg",
  xhtml: Ls,
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
};
function wa(e) {
  var t = e += "", r = t.indexOf(":");
  return r >= 0 && (t = e.slice(0, r)) !== "xmlns" && (e = e.slice(r + 1)), rc.hasOwnProperty(t) ? { space: rc[t], local: e } : e;
}
function Sy(e) {
  return function() {
    var t = this.ownerDocument, r = this.namespaceURI;
    return r === Ls && t.documentElement.namespaceURI === Ls ? t.createElement(e) : t.createElementNS(r, e);
  };
}
function Ty(e) {
  return function() {
    return this.ownerDocument.createElementNS(e.space, e.local);
  };
}
function jh(e) {
  var t = wa(e);
  return (t.local ? Ty : Sy)(t);
}
function By() {
}
function Bo(e) {
  return e == null ? By : function() {
    return this.querySelector(e);
  };
}
function Ly(e) {
  typeof e != "function" && (e = Bo(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = new Array(o), l, c, h = 0; h < o; ++h)
      (l = a[h]) && (c = e.call(l, l.__data__, h, a)) && ("__data__" in l && (c.__data__ = l.__data__), s[h] = c);
  return new re(i, this._parents);
}
function Ay(e) {
  return e == null ? [] : Array.isArray(e) ? e : Array.from(e);
}
function My() {
  return [];
}
function Yh(e) {
  return e == null ? My : function() {
    return this.querySelectorAll(e);
  };
}
function Ey(e) {
  return function() {
    return Ay(e.apply(this, arguments));
  };
}
function $y(e) {
  typeof e == "function" ? e = Ey(e) : e = Yh(e);
  for (var t = this._groups, r = t.length, i = [], n = [], a = 0; a < r; ++a)
    for (var o = t[a], s = o.length, l, c = 0; c < s; ++c)
      (l = o[c]) && (i.push(e.call(l, l.__data__, c, o)), n.push(l));
  return new re(i, n);
}
function Uh(e) {
  return function() {
    return this.matches(e);
  };
}
function Gh(e) {
  return function(t) {
    return t.matches(e);
  };
}
var Fy = Array.prototype.find;
function Dy(e) {
  return function() {
    return Fy.call(this.children, e);
  };
}
function Oy() {
  return this.firstElementChild;
}
function Ry(e) {
  return this.select(e == null ? Oy : Dy(typeof e == "function" ? e : Gh(e)));
}
var Iy = Array.prototype.filter;
function Py() {
  return Array.from(this.children);
}
function Ny(e) {
  return function() {
    return Iy.call(this.children, e);
  };
}
function zy(e) {
  return this.selectAll(e == null ? Py : Ny(typeof e == "function" ? e : Gh(e)));
}
function Wy(e) {
  typeof e != "function" && (e = Uh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], l, c = 0; c < o; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && s.push(l);
  return new re(i, this._parents);
}
function Xh(e) {
  return new Array(e.length);
}
function qy() {
  return new re(this._enter || this._groups.map(Xh), this._parents);
}
function Wn(e, t) {
  this.ownerDocument = e.ownerDocument, this.namespaceURI = e.namespaceURI, this._next = null, this._parent = e, this.__data__ = t;
}
Wn.prototype = {
  constructor: Wn,
  appendChild: function(e) {
    return this._parent.insertBefore(e, this._next);
  },
  insertBefore: function(e, t) {
    return this._parent.insertBefore(e, t);
  },
  querySelector: function(e) {
    return this._parent.querySelector(e);
  },
  querySelectorAll: function(e) {
    return this._parent.querySelectorAll(e);
  }
};
function Hy(e) {
  return function() {
    return e;
  };
}
function jy(e, t, r, i, n, a) {
  for (var o = 0, s, l = t.length, c = a.length; o < c; ++o)
    (s = t[o]) ? (s.__data__ = a[o], i[o] = s) : r[o] = new Wn(e, a[o]);
  for (; o < l; ++o)
    (s = t[o]) && (n[o] = s);
}
function Yy(e, t, r, i, n, a, o) {
  var s, l, c = /* @__PURE__ */ new Map(), h = t.length, u = a.length, f = new Array(h), p;
  for (s = 0; s < h; ++s)
    (l = t[s]) && (f[s] = p = o.call(l, l.__data__, s, t) + "", c.has(p) ? n[s] = l : c.set(p, l));
  for (s = 0; s < u; ++s)
    p = o.call(e, a[s], s, a) + "", (l = c.get(p)) ? (i[s] = l, l.__data__ = a[s], c.delete(p)) : r[s] = new Wn(e, a[s]);
  for (s = 0; s < h; ++s)
    (l = t[s]) && c.get(f[s]) === l && (n[s] = l);
}
function Uy(e) {
  return e.__data__;
}
function Gy(e, t) {
  if (!arguments.length) return Array.from(this, Uy);
  var r = t ? Yy : jy, i = this._parents, n = this._groups;
  typeof e != "function" && (e = Hy(e));
  for (var a = n.length, o = new Array(a), s = new Array(a), l = new Array(a), c = 0; c < a; ++c) {
    var h = i[c], u = n[c], f = u.length, p = Xy(e.call(h, h && h.__data__, c, i)), g = p.length, m = s[c] = new Array(g), x = o[c] = new Array(g), y = l[c] = new Array(f);
    r(h, u, m, x, y, p, t);
    for (var b = 0, _ = 0, k, v; b < g; ++b)
      if (k = m[b]) {
        for (b >= _ && (_ = b + 1); !(v = x[_]) && ++_ < g; ) ;
        k._next = v || null;
      }
  }
  return o = new re(o, i), o._enter = s, o._exit = l, o;
}
function Xy(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function Vy() {
  return new re(this._exit || this._groups.map(Xh), this._parents);
}
function Zy(e, t, r) {
  var i = this.enter(), n = this, a = this.exit();
  return typeof e == "function" ? (i = e(i), i && (i = i.selection())) : i = i.append(e + ""), t != null && (n = t(n), n && (n = n.selection())), r == null ? a.remove() : r(a), i && n ? i.merge(n).order() : n;
}
function Ky(e) {
  for (var t = e.selection ? e.selection() : e, r = this._groups, i = t._groups, n = r.length, a = i.length, o = Math.min(n, a), s = new Array(n), l = 0; l < o; ++l)
    for (var c = r[l], h = i[l], u = c.length, f = s[l] = new Array(u), p, g = 0; g < u; ++g)
      (p = c[g] || h[g]) && (f[g] = p);
  for (; l < n; ++l)
    s[l] = r[l];
  return new re(s, this._parents);
}
function Qy() {
  for (var e = this._groups, t = -1, r = e.length; ++t < r; )
    for (var i = e[t], n = i.length - 1, a = i[n], o; --n >= 0; )
      (o = i[n]) && (a && o.compareDocumentPosition(a) ^ 4 && a.parentNode.insertBefore(o, a), a = o);
  return this;
}
function Jy(e) {
  e || (e = tx);
  function t(u, f) {
    return u && f ? e(u.__data__, f.__data__) : !u - !f;
  }
  for (var r = this._groups, i = r.length, n = new Array(i), a = 0; a < i; ++a) {
    for (var o = r[a], s = o.length, l = n[a] = new Array(s), c, h = 0; h < s; ++h)
      (c = o[h]) && (l[h] = c);
    l.sort(t);
  }
  return new re(n, this._parents).order();
}
function tx(e, t) {
  return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function ex() {
  var e = arguments[0];
  return arguments[0] = this, e.apply(null, arguments), this;
}
function rx() {
  return Array.from(this);
}
function ix() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length; n < a; ++n) {
      var o = i[n];
      if (o) return o;
    }
  return null;
}
function nx() {
  let e = 0;
  for (const t of this) ++e;
  return e;
}
function ax() {
  return !this.node();
}
function sx(e) {
  for (var t = this._groups, r = 0, i = t.length; r < i; ++r)
    for (var n = t[r], a = 0, o = n.length, s; a < o; ++a)
      (s = n[a]) && e.call(s, s.__data__, a, n);
  return this;
}
function ox(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function lx(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function cx(e, t) {
  return function() {
    this.setAttribute(e, t);
  };
}
function hx(e, t) {
  return function() {
    this.setAttributeNS(e.space, e.local, t);
  };
}
function ux(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttribute(e) : this.setAttribute(e, r);
  };
}
function fx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttributeNS(e.space, e.local) : this.setAttributeNS(e.space, e.local, r);
  };
}
function px(e, t) {
  var r = wa(e);
  if (arguments.length < 2) {
    var i = this.node();
    return r.local ? i.getAttributeNS(r.space, r.local) : i.getAttribute(r);
  }
  return this.each((t == null ? r.local ? lx : ox : typeof t == "function" ? r.local ? fx : ux : r.local ? hx : cx)(r, t));
}
function Vh(e) {
  return e.ownerDocument && e.ownerDocument.defaultView || e.document && e || e.defaultView;
}
function dx(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function gx(e, t, r) {
  return function() {
    this.style.setProperty(e, t, r);
  };
}
function mx(e, t, r) {
  return function() {
    var i = t.apply(this, arguments);
    i == null ? this.style.removeProperty(e) : this.style.setProperty(e, i, r);
  };
}
function yx(e, t, r) {
  return arguments.length > 1 ? this.each((t == null ? dx : typeof t == "function" ? mx : gx)(e, t, r ?? "")) : Gr(this.node(), e);
}
function Gr(e, t) {
  return e.style.getPropertyValue(t) || Vh(e).getComputedStyle(e, null).getPropertyValue(t);
}
function xx(e) {
  return function() {
    delete this[e];
  };
}
function bx(e, t) {
  return function() {
    this[e] = t;
  };
}
function Cx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? delete this[e] : this[e] = r;
  };
}
function _x(e, t) {
  return arguments.length > 1 ? this.each((t == null ? xx : typeof t == "function" ? Cx : bx)(e, t)) : this.node()[e];
}
function Zh(e) {
  return e.trim().split(/^|\s+/);
}
function Lo(e) {
  return e.classList || new Kh(e);
}
function Kh(e) {
  this._node = e, this._names = Zh(e.getAttribute("class") || "");
}
Kh.prototype = {
  add: function(e) {
    var t = this._names.indexOf(e);
    t < 0 && (this._names.push(e), this._node.setAttribute("class", this._names.join(" ")));
  },
  remove: function(e) {
    var t = this._names.indexOf(e);
    t >= 0 && (this._names.splice(t, 1), this._node.setAttribute("class", this._names.join(" ")));
  },
  contains: function(e) {
    return this._names.indexOf(e) >= 0;
  }
};
function Qh(e, t) {
  for (var r = Lo(e), i = -1, n = t.length; ++i < n; ) r.add(t[i]);
}
function Jh(e, t) {
  for (var r = Lo(e), i = -1, n = t.length; ++i < n; ) r.remove(t[i]);
}
function wx(e) {
  return function() {
    Qh(this, e);
  };
}
function vx(e) {
  return function() {
    Jh(this, e);
  };
}
function kx(e, t) {
  return function() {
    (t.apply(this, arguments) ? Qh : Jh)(this, e);
  };
}
function Sx(e, t) {
  var r = Zh(e + "");
  if (arguments.length < 2) {
    for (var i = Lo(this.node()), n = -1, a = r.length; ++n < a; ) if (!i.contains(r[n])) return !1;
    return !0;
  }
  return this.each((typeof t == "function" ? kx : t ? wx : vx)(r, t));
}
function Tx() {
  this.textContent = "";
}
function Bx(e) {
  return function() {
    this.textContent = e;
  };
}
function Lx(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.textContent = t ?? "";
  };
}
function Ax(e) {
  return arguments.length ? this.each(e == null ? Tx : (typeof e == "function" ? Lx : Bx)(e)) : this.node().textContent;
}
function Mx() {
  this.innerHTML = "";
}
function Ex(e) {
  return function() {
    this.innerHTML = e;
  };
}
function $x(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.innerHTML = t ?? "";
  };
}
function Fx(e) {
  return arguments.length ? this.each(e == null ? Mx : (typeof e == "function" ? $x : Ex)(e)) : this.node().innerHTML;
}
function Dx() {
  this.nextSibling && this.parentNode.appendChild(this);
}
function Ox() {
  return this.each(Dx);
}
function Rx() {
  this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function Ix() {
  return this.each(Rx);
}
function Px(e) {
  var t = typeof e == "function" ? e : jh(e);
  return this.select(function() {
    return this.appendChild(t.apply(this, arguments));
  });
}
function Nx() {
  return null;
}
function zx(e, t) {
  var r = typeof e == "function" ? e : jh(e), i = t == null ? Nx : typeof t == "function" ? t : Bo(t);
  return this.select(function() {
    return this.insertBefore(r.apply(this, arguments), i.apply(this, arguments) || null);
  });
}
function Wx() {
  var e = this.parentNode;
  e && e.removeChild(this);
}
function qx() {
  return this.each(Wx);
}
function Hx() {
  var e = this.cloneNode(!1), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function jx() {
  var e = this.cloneNode(!0), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Yx(e) {
  return this.select(e ? jx : Hx);
}
function Ux(e) {
  return arguments.length ? this.property("__data__", e) : this.node().__data__;
}
function Gx(e) {
  return function(t) {
    e.call(this, t, this.__data__);
  };
}
function Xx(e) {
  return e.trim().split(/^|\s+/).map(function(t) {
    var r = "", i = t.indexOf(".");
    return i >= 0 && (r = t.slice(i + 1), t = t.slice(0, i)), { type: t, name: r };
  });
}
function Vx(e) {
  return function() {
    var t = this.__on;
    if (t) {
      for (var r = 0, i = -1, n = t.length, a; r < n; ++r)
        a = t[r], (!e.type || a.type === e.type) && a.name === e.name ? this.removeEventListener(a.type, a.listener, a.options) : t[++i] = a;
      ++i ? t.length = i : delete this.__on;
    }
  };
}
function Zx(e, t, r) {
  return function() {
    var i = this.__on, n, a = Gx(t);
    if (i) {
      for (var o = 0, s = i.length; o < s; ++o)
        if ((n = i[o]).type === e.type && n.name === e.name) {
          this.removeEventListener(n.type, n.listener, n.options), this.addEventListener(n.type, n.listener = a, n.options = r), n.value = t;
          return;
        }
    }
    this.addEventListener(e.type, a, r), n = { type: e.type, name: e.name, value: t, listener: a, options: r }, i ? i.push(n) : this.__on = [n];
  };
}
function Kx(e, t, r) {
  var i = Xx(e + ""), n, a = i.length, o;
  if (arguments.length < 2) {
    var s = this.node().__on;
    if (s) {
      for (var l = 0, c = s.length, h; l < c; ++l)
        for (n = 0, h = s[l]; n < a; ++n)
          if ((o = i[n]).type === h.type && o.name === h.name)
            return h.value;
    }
    return;
  }
  for (s = t ? Zx : Vx, n = 0; n < a; ++n) this.each(s(i[n], t, r));
  return this;
}
function tu(e, t, r) {
  var i = Vh(e), n = i.CustomEvent;
  typeof n == "function" ? n = new n(t, r) : (n = i.document.createEvent("Event"), r ? (n.initEvent(t, r.bubbles, r.cancelable), n.detail = r.detail) : n.initEvent(t, !1, !1)), e.dispatchEvent(n);
}
function Qx(e, t) {
  return function() {
    return tu(this, e, t);
  };
}
function Jx(e, t) {
  return function() {
    return tu(this, e, t.apply(this, arguments));
  };
}
function tb(e, t) {
  return this.each((typeof t == "function" ? Jx : Qx)(e, t));
}
function* eb() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length, o; n < a; ++n)
      (o = i[n]) && (yield o);
}
var eu = [null];
function re(e, t) {
  this._groups = e, this._parents = t;
}
function Vi() {
  return new re([[document.documentElement]], eu);
}
function rb() {
  return this;
}
re.prototype = Vi.prototype = {
  constructor: re,
  select: Ly,
  selectAll: $y,
  selectChild: Ry,
  selectChildren: zy,
  filter: Wy,
  data: Gy,
  enter: qy,
  exit: Vy,
  join: Zy,
  merge: Ky,
  selection: rb,
  order: Qy,
  sort: Jy,
  call: ex,
  nodes: rx,
  node: ix,
  size: nx,
  empty: ax,
  each: sx,
  attr: px,
  style: yx,
  property: _x,
  classed: Sx,
  text: Ax,
  html: Fx,
  raise: Ox,
  lower: Ix,
  append: Px,
  insert: zx,
  remove: qx,
  clone: Yx,
  datum: Ux,
  on: Kx,
  dispatch: tb,
  [Symbol.iterator]: eb
};
function ht(e) {
  return typeof e == "string" ? new re([[document.querySelector(e)]], [document.documentElement]) : new re([[e]], eu);
}
function Ao(e, t, r) {
  e.prototype = t.prototype = r, r.constructor = e;
}
function ru(e, t) {
  var r = Object.create(e.prototype);
  for (var i in t) r[i] = t[i];
  return r;
}
function Zi() {
}
var Di = 0.7, qn = 1 / Di, Dr = "\\s*([+-]?\\d+)\\s*", Oi = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", _e = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", ib = /^#([0-9a-f]{3,8})$/, nb = new RegExp(`^rgb\\(${Dr},${Dr},${Dr}\\)$`), ab = new RegExp(`^rgb\\(${_e},${_e},${_e}\\)$`), sb = new RegExp(`^rgba\\(${Dr},${Dr},${Dr},${Oi}\\)$`), ob = new RegExp(`^rgba\\(${_e},${_e},${_e},${Oi}\\)$`), lb = new RegExp(`^hsl\\(${Oi},${_e},${_e}\\)$`), cb = new RegExp(`^hsla\\(${Oi},${_e},${_e},${Oi}\\)$`), ic = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
};
Ao(Zi, Ri, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: nc,
  // Deprecated! Use color.formatHex.
  formatHex: nc,
  formatHex8: hb,
  formatHsl: ub,
  formatRgb: ac,
  toString: ac
});
function nc() {
  return this.rgb().formatHex();
}
function hb() {
  return this.rgb().formatHex8();
}
function ub() {
  return iu(this).formatHsl();
}
function ac() {
  return this.rgb().formatRgb();
}
function Ri(e) {
  var t, r;
  return e = (e + "").trim().toLowerCase(), (t = ib.exec(e)) ? (r = t[1].length, t = parseInt(t[1], 16), r === 6 ? sc(t) : r === 3 ? new Jt(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : r === 8 ? fn(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : r === 4 ? fn(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = nb.exec(e)) ? new Jt(t[1], t[2], t[3], 1) : (t = ab.exec(e)) ? new Jt(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = sb.exec(e)) ? fn(t[1], t[2], t[3], t[4]) : (t = ob.exec(e)) ? fn(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = lb.exec(e)) ? cc(t[1], t[2] / 100, t[3] / 100, 1) : (t = cb.exec(e)) ? cc(t[1], t[2] / 100, t[3] / 100, t[4]) : ic.hasOwnProperty(e) ? sc(ic[e]) : e === "transparent" ? new Jt(NaN, NaN, NaN, 0) : null;
}
function sc(e) {
  return new Jt(e >> 16 & 255, e >> 8 & 255, e & 255, 1);
}
function fn(e, t, r, i) {
  return i <= 0 && (e = t = r = NaN), new Jt(e, t, r, i);
}
function fb(e) {
  return e instanceof Zi || (e = Ri(e)), e ? (e = e.rgb(), new Jt(e.r, e.g, e.b, e.opacity)) : new Jt();
}
function As(e, t, r, i) {
  return arguments.length === 1 ? fb(e) : new Jt(e, t, r, i ?? 1);
}
function Jt(e, t, r, i) {
  this.r = +e, this.g = +t, this.b = +r, this.opacity = +i;
}
Ao(Jt, As, ru(Zi, {
  brighter(e) {
    return e = e == null ? qn : Math.pow(qn, e), new Jt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Di : Math.pow(Di, e), new Jt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  rgb() {
    return this;
  },
  clamp() {
    return new Jt(lr(this.r), lr(this.g), lr(this.b), Hn(this.opacity));
  },
  displayable() {
    return -0.5 <= this.r && this.r < 255.5 && -0.5 <= this.g && this.g < 255.5 && -0.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
  },
  hex: oc,
  // Deprecated! Use color.formatHex.
  formatHex: oc,
  formatHex8: pb,
  formatRgb: lc,
  toString: lc
}));
function oc() {
  return `#${nr(this.r)}${nr(this.g)}${nr(this.b)}`;
}
function pb() {
  return `#${nr(this.r)}${nr(this.g)}${nr(this.b)}${nr((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function lc() {
  const e = Hn(this.opacity);
  return `${e === 1 ? "rgb(" : "rgba("}${lr(this.r)}, ${lr(this.g)}, ${lr(this.b)}${e === 1 ? ")" : `, ${e})`}`;
}
function Hn(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function lr(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function nr(e) {
  return e = lr(e), (e < 16 ? "0" : "") + e.toString(16);
}
function cc(e, t, r, i) {
  return i <= 0 ? e = t = r = NaN : r <= 0 || r >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new he(e, t, r, i);
}
function iu(e) {
  if (e instanceof he) return new he(e.h, e.s, e.l, e.opacity);
  if (e instanceof Zi || (e = Ri(e)), !e) return new he();
  if (e instanceof he) return e;
  e = e.rgb();
  var t = e.r / 255, r = e.g / 255, i = e.b / 255, n = Math.min(t, r, i), a = Math.max(t, r, i), o = NaN, s = a - n, l = (a + n) / 2;
  return s ? (t === a ? o = (r - i) / s + (r < i) * 6 : r === a ? o = (i - t) / s + 2 : o = (t - r) / s + 4, s /= l < 0.5 ? a + n : 2 - a - n, o *= 60) : s = l > 0 && l < 1 ? 0 : o, new he(o, s, l, e.opacity);
}
function db(e, t, r, i) {
  return arguments.length === 1 ? iu(e) : new he(e, t, r, i ?? 1);
}
function he(e, t, r, i) {
  this.h = +e, this.s = +t, this.l = +r, this.opacity = +i;
}
Ao(he, db, ru(Zi, {
  brighter(e) {
    return e = e == null ? qn : Math.pow(qn, e), new he(this.h, this.s, this.l * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Di : Math.pow(Di, e), new he(this.h, this.s, this.l * e, this.opacity);
  },
  rgb() {
    var e = this.h % 360 + (this.h < 0) * 360, t = isNaN(e) || isNaN(this.s) ? 0 : this.s, r = this.l, i = r + (r < 0.5 ? r : 1 - r) * t, n = 2 * r - i;
    return new Jt(
      as(e >= 240 ? e - 240 : e + 120, n, i),
      as(e, n, i),
      as(e < 120 ? e + 240 : e - 120, n, i),
      this.opacity
    );
  },
  clamp() {
    return new he(hc(this.h), pn(this.s), pn(this.l), Hn(this.opacity));
  },
  displayable() {
    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
  },
  formatHsl() {
    const e = Hn(this.opacity);
    return `${e === 1 ? "hsl(" : "hsla("}${hc(this.h)}, ${pn(this.s) * 100}%, ${pn(this.l) * 100}%${e === 1 ? ")" : `, ${e})`}`;
  }
}));
function hc(e) {
  return e = (e || 0) % 360, e < 0 ? e + 360 : e;
}
function pn(e) {
  return Math.max(0, Math.min(1, e || 0));
}
function as(e, t, r) {
  return (e < 60 ? t + (r - t) * e / 60 : e < 180 ? r : e < 240 ? t + (r - t) * (240 - e) / 60 : t) * 255;
}
const Mo = (e) => () => e;
function nu(e, t) {
  return function(r) {
    return e + r * t;
  };
}
function gb(e, t, r) {
  return e = Math.pow(e, r), t = Math.pow(t, r) - e, r = 1 / r, function(i) {
    return Math.pow(e + i * t, r);
  };
}
function GL(e, t) {
  var r = t - e;
  return r ? nu(e, r > 180 || r < -180 ? r - 360 * Math.round(r / 360) : r) : Mo(isNaN(e) ? t : e);
}
function mb(e) {
  return (e = +e) == 1 ? au : function(t, r) {
    return r - t ? gb(t, r, e) : Mo(isNaN(t) ? r : t);
  };
}
function au(e, t) {
  var r = t - e;
  return r ? nu(e, r) : Mo(isNaN(e) ? t : e);
}
const uc = function e(t) {
  var r = mb(t);
  function i(n, a) {
    var o = r((n = As(n)).r, (a = As(a)).r), s = r(n.g, a.g), l = r(n.b, a.b), c = au(n.opacity, a.opacity);
    return function(h) {
      return n.r = o(h), n.g = s(h), n.b = l(h), n.opacity = c(h), n + "";
    };
  }
  return i.gamma = e, i;
}(1);
function qe(e, t) {
  return e = +e, t = +t, function(r) {
    return e * (1 - r) + t * r;
  };
}
var Ms = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, ss = new RegExp(Ms.source, "g");
function yb(e) {
  return function() {
    return e;
  };
}
function xb(e) {
  return function(t) {
    return e(t) + "";
  };
}
function bb(e, t) {
  var r = Ms.lastIndex = ss.lastIndex = 0, i, n, a, o = -1, s = [], l = [];
  for (e = e + "", t = t + ""; (i = Ms.exec(e)) && (n = ss.exec(t)); )
    (a = n.index) > r && (a = t.slice(r, a), s[o] ? s[o] += a : s[++o] = a), (i = i[0]) === (n = n[0]) ? s[o] ? s[o] += n : s[++o] = n : (s[++o] = null, l.push({ i: o, x: qe(i, n) })), r = ss.lastIndex;
  return r < t.length && (a = t.slice(r), s[o] ? s[o] += a : s[++o] = a), s.length < 2 ? l[0] ? xb(l[0].x) : yb(t) : (t = l.length, function(c) {
    for (var h = 0, u; h < t; ++h) s[(u = l[h]).i] = u.x(c);
    return s.join("");
  });
}
var fc = 180 / Math.PI, Es = {
  translateX: 0,
  translateY: 0,
  rotate: 0,
  skewX: 0,
  scaleX: 1,
  scaleY: 1
};
function su(e, t, r, i, n, a) {
  var o, s, l;
  return (o = Math.sqrt(e * e + t * t)) && (e /= o, t /= o), (l = e * r + t * i) && (r -= e * l, i -= t * l), (s = Math.sqrt(r * r + i * i)) && (r /= s, i /= s, l /= s), e * i < t * r && (e = -e, t = -t, l = -l, o = -o), {
    translateX: n,
    translateY: a,
    rotate: Math.atan2(t, e) * fc,
    skewX: Math.atan(l) * fc,
    scaleX: o,
    scaleY: s
  };
}
var dn;
function Cb(e) {
  const t = new (typeof DOMMatrix == "function" ? DOMMatrix : WebKitCSSMatrix)(e + "");
  return t.isIdentity ? Es : su(t.a, t.b, t.c, t.d, t.e, t.f);
}
function _b(e) {
  return e == null || (dn || (dn = document.createElementNS("http://www.w3.org/2000/svg", "g")), dn.setAttribute("transform", e), !(e = dn.transform.baseVal.consolidate())) ? Es : (e = e.matrix, su(e.a, e.b, e.c, e.d, e.e, e.f));
}
function ou(e, t, r, i) {
  function n(c) {
    return c.length ? c.pop() + " " : "";
  }
  function a(c, h, u, f, p, g) {
    if (c !== u || h !== f) {
      var m = p.push("translate(", null, t, null, r);
      g.push({ i: m - 4, x: qe(c, u) }, { i: m - 2, x: qe(h, f) });
    } else (u || f) && p.push("translate(" + u + t + f + r);
  }
  function o(c, h, u, f) {
    c !== h ? (c - h > 180 ? h += 360 : h - c > 180 && (c += 360), f.push({ i: u.push(n(u) + "rotate(", null, i) - 2, x: qe(c, h) })) : h && u.push(n(u) + "rotate(" + h + i);
  }
  function s(c, h, u, f) {
    c !== h ? f.push({ i: u.push(n(u) + "skewX(", null, i) - 2, x: qe(c, h) }) : h && u.push(n(u) + "skewX(" + h + i);
  }
  function l(c, h, u, f, p, g) {
    if (c !== u || h !== f) {
      var m = p.push(n(p) + "scale(", null, ",", null, ")");
      g.push({ i: m - 4, x: qe(c, u) }, { i: m - 2, x: qe(h, f) });
    } else (u !== 1 || f !== 1) && p.push(n(p) + "scale(" + u + "," + f + ")");
  }
  return function(c, h) {
    var u = [], f = [];
    return c = e(c), h = e(h), a(c.translateX, c.translateY, h.translateX, h.translateY, u, f), o(c.rotate, h.rotate, u, f), s(c.skewX, h.skewX, u, f), l(c.scaleX, c.scaleY, h.scaleX, h.scaleY, u, f), c = h = null, function(p) {
      for (var g = -1, m = f.length, x; ++g < m; ) u[(x = f[g]).i] = x.x(p);
      return u.join("");
    };
  };
}
var wb = ou(Cb, "px, ", "px)", "deg)"), vb = ou(_b, ", ", ")", ")"), Xr = 0, _i = 0, pi = 0, lu = 1e3, jn, wi, Yn = 0, fr = 0, va = 0, Ii = typeof performance == "object" && performance.now ? performance : Date, cu = typeof window == "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(e) {
  setTimeout(e, 17);
};
function Eo() {
  return fr || (cu(kb), fr = Ii.now() + va);
}
function kb() {
  fr = 0;
}
function Un() {
  this._call = this._time = this._next = null;
}
Un.prototype = hu.prototype = {
  constructor: Un,
  restart: function(e, t, r) {
    if (typeof e != "function") throw new TypeError("callback is not a function");
    r = (r == null ? Eo() : +r) + (t == null ? 0 : +t), !this._next && wi !== this && (wi ? wi._next = this : jn = this, wi = this), this._call = e, this._time = r, $s();
  },
  stop: function() {
    this._call && (this._call = null, this._time = 1 / 0, $s());
  }
};
function hu(e, t, r) {
  var i = new Un();
  return i.restart(e, t, r), i;
}
function Sb() {
  Eo(), ++Xr;
  for (var e = jn, t; e; )
    (t = fr - e._time) >= 0 && e._call.call(void 0, t), e = e._next;
  --Xr;
}
function pc() {
  fr = (Yn = Ii.now()) + va, Xr = _i = 0;
  try {
    Sb();
  } finally {
    Xr = 0, Bb(), fr = 0;
  }
}
function Tb() {
  var e = Ii.now(), t = e - Yn;
  t > lu && (va -= t, Yn = e);
}
function Bb() {
  for (var e, t = jn, r, i = 1 / 0; t; )
    t._call ? (i > t._time && (i = t._time), e = t, t = t._next) : (r = t._next, t._next = null, t = e ? e._next = r : jn = r);
  wi = e, $s(i);
}
function $s(e) {
  if (!Xr) {
    _i && (_i = clearTimeout(_i));
    var t = e - fr;
    t > 24 ? (e < 1 / 0 && (_i = setTimeout(pc, e - Ii.now() - va)), pi && (pi = clearInterval(pi))) : (pi || (Yn = Ii.now(), pi = setInterval(Tb, lu)), Xr = 1, cu(pc));
  }
}
function dc(e, t, r) {
  var i = new Un();
  return t = t == null ? 0 : +t, i.restart((n) => {
    i.stop(), e(n + t);
  }, t, r), i;
}
var Lb = Hh("start", "end", "cancel", "interrupt"), Ab = [], uu = 0, gc = 1, Fs = 2, Sn = 3, mc = 4, Ds = 5, Tn = 6;
function ka(e, t, r, i, n, a) {
  var o = e.__transition;
  if (!o) e.__transition = {};
  else if (r in o) return;
  Mb(e, r, {
    name: t,
    index: i,
    // For context during callback.
    group: n,
    // For context during callback.
    on: Lb,
    tween: Ab,
    time: a.time,
    delay: a.delay,
    duration: a.duration,
    ease: a.ease,
    timer: null,
    state: uu
  });
}
function $o(e, t) {
  var r = de(e, t);
  if (r.state > uu) throw new Error("too late; already scheduled");
  return r;
}
function ke(e, t) {
  var r = de(e, t);
  if (r.state > Sn) throw new Error("too late; already running");
  return r;
}
function de(e, t) {
  var r = e.__transition;
  if (!r || !(r = r[t])) throw new Error("transition not found");
  return r;
}
function Mb(e, t, r) {
  var i = e.__transition, n;
  i[t] = r, r.timer = hu(a, 0, r.time);
  function a(c) {
    r.state = gc, r.timer.restart(o, r.delay, r.time), r.delay <= c && o(c - r.delay);
  }
  function o(c) {
    var h, u, f, p;
    if (r.state !== gc) return l();
    for (h in i)
      if (p = i[h], p.name === r.name) {
        if (p.state === Sn) return dc(o);
        p.state === mc ? (p.state = Tn, p.timer.stop(), p.on.call("interrupt", e, e.__data__, p.index, p.group), delete i[h]) : +h < t && (p.state = Tn, p.timer.stop(), p.on.call("cancel", e, e.__data__, p.index, p.group), delete i[h]);
      }
    if (dc(function() {
      r.state === Sn && (r.state = mc, r.timer.restart(s, r.delay, r.time), s(c));
    }), r.state = Fs, r.on.call("start", e, e.__data__, r.index, r.group), r.state === Fs) {
      for (r.state = Sn, n = new Array(f = r.tween.length), h = 0, u = -1; h < f; ++h)
        (p = r.tween[h].value.call(e, e.__data__, r.index, r.group)) && (n[++u] = p);
      n.length = u + 1;
    }
  }
  function s(c) {
    for (var h = c < r.duration ? r.ease.call(null, c / r.duration) : (r.timer.restart(l), r.state = Ds, 1), u = -1, f = n.length; ++u < f; )
      n[u].call(e, h);
    r.state === Ds && (r.on.call("end", e, e.__data__, r.index, r.group), l());
  }
  function l() {
    r.state = Tn, r.timer.stop(), delete i[t];
    for (var c in i) return;
    delete e.__transition;
  }
}
function Eb(e, t) {
  var r = e.__transition, i, n, a = !0, o;
  if (r) {
    t = t == null ? null : t + "";
    for (o in r) {
      if ((i = r[o]).name !== t) {
        a = !1;
        continue;
      }
      n = i.state > Fs && i.state < Ds, i.state = Tn, i.timer.stop(), i.on.call(n ? "interrupt" : "cancel", e, e.__data__, i.index, i.group), delete r[o];
    }
    a && delete e.__transition;
  }
}
function $b(e) {
  return this.each(function() {
    Eb(this, e);
  });
}
function Fb(e, t) {
  var r, i;
  return function() {
    var n = ke(this, e), a = n.tween;
    if (a !== r) {
      i = r = a;
      for (var o = 0, s = i.length; o < s; ++o)
        if (i[o].name === t) {
          i = i.slice(), i.splice(o, 1);
          break;
        }
    }
    n.tween = i;
  };
}
function Db(e, t, r) {
  var i, n;
  if (typeof r != "function") throw new Error();
  return function() {
    var a = ke(this, e), o = a.tween;
    if (o !== i) {
      n = (i = o).slice();
      for (var s = { name: t, value: r }, l = 0, c = n.length; l < c; ++l)
        if (n[l].name === t) {
          n[l] = s;
          break;
        }
      l === c && n.push(s);
    }
    a.tween = n;
  };
}
function Ob(e, t) {
  var r = this._id;
  if (e += "", arguments.length < 2) {
    for (var i = de(this.node(), r).tween, n = 0, a = i.length, o; n < a; ++n)
      if ((o = i[n]).name === e)
        return o.value;
    return null;
  }
  return this.each((t == null ? Fb : Db)(r, e, t));
}
function Fo(e, t, r) {
  var i = e._id;
  return e.each(function() {
    var n = ke(this, i);
    (n.value || (n.value = {}))[t] = r.apply(this, arguments);
  }), function(n) {
    return de(n, i).value[t];
  };
}
function fu(e, t) {
  var r;
  return (typeof t == "number" ? qe : t instanceof Ri ? uc : (r = Ri(t)) ? (t = r, uc) : bb)(e, t);
}
function Rb(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function Ib(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function Pb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttribute(e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function Nb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttributeNS(e.space, e.local);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function zb(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), l;
    return s == null ? void this.removeAttribute(e) : (o = this.getAttribute(e), l = s + "", o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s)));
  };
}
function Wb(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), l;
    return s == null ? void this.removeAttributeNS(e.space, e.local) : (o = this.getAttributeNS(e.space, e.local), l = s + "", o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s)));
  };
}
function qb(e, t) {
  var r = wa(e), i = r === "transform" ? vb : fu;
  return this.attrTween(e, typeof t == "function" ? (r.local ? Wb : zb)(r, i, Fo(this, "attr." + e, t)) : t == null ? (r.local ? Ib : Rb)(r) : (r.local ? Nb : Pb)(r, i, t));
}
function Hb(e, t) {
  return function(r) {
    this.setAttribute(e, t.call(this, r));
  };
}
function jb(e, t) {
  return function(r) {
    this.setAttributeNS(e.space, e.local, t.call(this, r));
  };
}
function Yb(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && jb(e, a)), r;
  }
  return n._value = t, n;
}
function Ub(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Hb(e, a)), r;
  }
  return n._value = t, n;
}
function Gb(e, t) {
  var r = "attr." + e;
  if (arguments.length < 2) return (r = this.tween(r)) && r._value;
  if (t == null) return this.tween(r, null);
  if (typeof t != "function") throw new Error();
  var i = wa(e);
  return this.tween(r, (i.local ? Yb : Ub)(i, t));
}
function Xb(e, t) {
  return function() {
    $o(this, e).delay = +t.apply(this, arguments);
  };
}
function Vb(e, t) {
  return t = +t, function() {
    $o(this, e).delay = t;
  };
}
function Zb(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? Xb : Vb)(t, e)) : de(this.node(), t).delay;
}
function Kb(e, t) {
  return function() {
    ke(this, e).duration = +t.apply(this, arguments);
  };
}
function Qb(e, t) {
  return t = +t, function() {
    ke(this, e).duration = t;
  };
}
function Jb(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? Kb : Qb)(t, e)) : de(this.node(), t).duration;
}
function t1(e, t) {
  if (typeof t != "function") throw new Error();
  return function() {
    ke(this, e).ease = t;
  };
}
function e1(e) {
  var t = this._id;
  return arguments.length ? this.each(t1(t, e)) : de(this.node(), t).ease;
}
function r1(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    if (typeof r != "function") throw new Error();
    ke(this, e).ease = r;
  };
}
function i1(e) {
  if (typeof e != "function") throw new Error();
  return this.each(r1(this._id, e));
}
function n1(e) {
  typeof e != "function" && (e = Uh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], l, c = 0; c < o; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && s.push(l);
  return new Pe(i, this._parents, this._name, this._id);
}
function a1(e) {
  if (e._id !== this._id) throw new Error();
  for (var t = this._groups, r = e._groups, i = t.length, n = r.length, a = Math.min(i, n), o = new Array(i), s = 0; s < a; ++s)
    for (var l = t[s], c = r[s], h = l.length, u = o[s] = new Array(h), f, p = 0; p < h; ++p)
      (f = l[p] || c[p]) && (u[p] = f);
  for (; s < i; ++s)
    o[s] = t[s];
  return new Pe(o, this._parents, this._name, this._id);
}
function s1(e) {
  return (e + "").trim().split(/^|\s+/).every(function(t) {
    var r = t.indexOf(".");
    return r >= 0 && (t = t.slice(0, r)), !t || t === "start";
  });
}
function o1(e, t, r) {
  var i, n, a = s1(t) ? $o : ke;
  return function() {
    var o = a(this, e), s = o.on;
    s !== i && (n = (i = s).copy()).on(t, r), o.on = n;
  };
}
function l1(e, t) {
  var r = this._id;
  return arguments.length < 2 ? de(this.node(), r).on.on(e) : this.each(o1(r, e, t));
}
function c1(e) {
  return function() {
    var t = this.parentNode;
    for (var r in this.__transition) if (+r !== e) return;
    t && t.removeChild(this);
  };
}
function h1() {
  return this.on("end.remove", c1(this._id));
}
function u1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = Bo(e));
  for (var i = this._groups, n = i.length, a = new Array(n), o = 0; o < n; ++o)
    for (var s = i[o], l = s.length, c = a[o] = new Array(l), h, u, f = 0; f < l; ++f)
      (h = s[f]) && (u = e.call(h, h.__data__, f, s)) && ("__data__" in h && (u.__data__ = h.__data__), c[f] = u, ka(c[f], t, r, f, c, de(h, r)));
  return new Pe(a, this._parents, t, r);
}
function f1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = Yh(e));
  for (var i = this._groups, n = i.length, a = [], o = [], s = 0; s < n; ++s)
    for (var l = i[s], c = l.length, h, u = 0; u < c; ++u)
      if (h = l[u]) {
        for (var f = e.call(h, h.__data__, u, l), p, g = de(h, r), m = 0, x = f.length; m < x; ++m)
          (p = f[m]) && ka(p, t, r, m, f, g);
        a.push(f), o.push(h);
      }
  return new Pe(a, o, t, r);
}
var p1 = Vi.prototype.constructor;
function d1() {
  return new p1(this._groups, this._parents);
}
function g1(e, t) {
  var r, i, n;
  return function() {
    var a = Gr(this, e), o = (this.style.removeProperty(e), Gr(this, e));
    return a === o ? null : a === r && o === i ? n : n = t(r = a, i = o);
  };
}
function pu(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function m1(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = Gr(this, e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function y1(e, t, r) {
  var i, n, a;
  return function() {
    var o = Gr(this, e), s = r(this), l = s + "";
    return s == null && (l = s = (this.style.removeProperty(e), Gr(this, e))), o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s));
  };
}
function x1(e, t) {
  var r, i, n, a = "style." + t, o = "end." + a, s;
  return function() {
    var l = ke(this, e), c = l.on, h = l.value[a] == null ? s || (s = pu(t)) : void 0;
    (c !== r || n !== h) && (i = (r = c).copy()).on(o, n = h), l.on = i;
  };
}
function b1(e, t, r) {
  var i = (e += "") == "transform" ? wb : fu;
  return t == null ? this.styleTween(e, g1(e, i)).on("end.style." + e, pu(e)) : typeof t == "function" ? this.styleTween(e, y1(e, i, Fo(this, "style." + e, t))).each(x1(this._id, e)) : this.styleTween(e, m1(e, i, t), r).on("end.style." + e, null);
}
function C1(e, t, r) {
  return function(i) {
    this.style.setProperty(e, t.call(this, i), r);
  };
}
function _1(e, t, r) {
  var i, n;
  function a() {
    var o = t.apply(this, arguments);
    return o !== n && (i = (n = o) && C1(e, o, r)), i;
  }
  return a._value = t, a;
}
function w1(e, t, r) {
  var i = "style." + (e += "");
  if (arguments.length < 2) return (i = this.tween(i)) && i._value;
  if (t == null) return this.tween(i, null);
  if (typeof t != "function") throw new Error();
  return this.tween(i, _1(e, t, r ?? ""));
}
function v1(e) {
  return function() {
    this.textContent = e;
  };
}
function k1(e) {
  return function() {
    var t = e(this);
    this.textContent = t ?? "";
  };
}
function S1(e) {
  return this.tween("text", typeof e == "function" ? k1(Fo(this, "text", e)) : v1(e == null ? "" : e + ""));
}
function T1(e) {
  return function(t) {
    this.textContent = e.call(this, t);
  };
}
function B1(e) {
  var t, r;
  function i() {
    var n = e.apply(this, arguments);
    return n !== r && (t = (r = n) && T1(n)), t;
  }
  return i._value = e, i;
}
function L1(e) {
  var t = "text";
  if (arguments.length < 1) return (t = this.tween(t)) && t._value;
  if (e == null) return this.tween(t, null);
  if (typeof e != "function") throw new Error();
  return this.tween(t, B1(e));
}
function A1() {
  for (var e = this._name, t = this._id, r = du(), i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, l, c = 0; c < s; ++c)
      if (l = o[c]) {
        var h = de(l, t);
        ka(l, e, r, c, o, {
          time: h.time + h.delay + h.duration,
          delay: 0,
          duration: h.duration,
          ease: h.ease
        });
      }
  return new Pe(i, this._parents, e, r);
}
function M1() {
  var e, t, r = this, i = r._id, n = r.size();
  return new Promise(function(a, o) {
    var s = { value: o }, l = { value: function() {
      --n === 0 && a();
    } };
    r.each(function() {
      var c = ke(this, i), h = c.on;
      h !== e && (t = (e = h).copy(), t._.cancel.push(s), t._.interrupt.push(s), t._.end.push(l)), c.on = t;
    }), n === 0 && a();
  });
}
var E1 = 0;
function Pe(e, t, r, i) {
  this._groups = e, this._parents = t, this._name = r, this._id = i;
}
function du() {
  return ++E1;
}
var Me = Vi.prototype;
Pe.prototype = {
  constructor: Pe,
  select: u1,
  selectAll: f1,
  selectChild: Me.selectChild,
  selectChildren: Me.selectChildren,
  filter: n1,
  merge: a1,
  selection: d1,
  transition: A1,
  call: Me.call,
  nodes: Me.nodes,
  node: Me.node,
  size: Me.size,
  empty: Me.empty,
  each: Me.each,
  on: l1,
  attr: qb,
  attrTween: Gb,
  style: b1,
  styleTween: w1,
  text: S1,
  textTween: L1,
  remove: h1,
  tween: Ob,
  delay: Zb,
  duration: Jb,
  ease: e1,
  easeVarying: i1,
  end: M1,
  [Symbol.iterator]: Me[Symbol.iterator]
};
function $1(e) {
  return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2;
}
var F1 = {
  time: null,
  // Set on use.
  delay: 0,
  duration: 250,
  ease: $1
};
function D1(e, t) {
  for (var r; !(r = e.__transition) || !(r = r[t]); )
    if (!(e = e.parentNode))
      throw new Error(`transition ${t} not found`);
  return r;
}
function O1(e) {
  var t, r;
  e instanceof Pe ? (t = e._id, e = e._name) : (t = du(), (r = F1).time = Eo(), e = e == null ? null : e + "");
  for (var i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, l, c = 0; c < s; ++c)
      (l = o[c]) && ka(l, e, t, c, o, r || D1(l, t));
  return new Pe(i, this._parents, e, t);
}
Vi.prototype.interrupt = $b;
Vi.prototype.transition = O1;
const Os = Math.PI, Rs = 2 * Os, tr = 1e-6, R1 = Rs - tr;
function gu(e) {
  this._ += e[0];
  for (let t = 1, r = e.length; t < r; ++t)
    this._ += arguments[t] + e[t];
}
function I1(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw new Error(`invalid digits: ${e}`);
  if (t > 15) return gu;
  const r = 10 ** t;
  return function(i) {
    this._ += i[0];
    for (let n = 1, a = i.length; n < a; ++n)
      this._ += Math.round(arguments[n] * r) / r + i[n];
  };
}
class P1 {
  constructor(t) {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null, this._ = "", this._append = t == null ? gu : I1(t);
  }
  moveTo(t, r) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}`;
  }
  closePath() {
    this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append`Z`);
  }
  lineTo(t, r) {
    this._append`L${this._x1 = +t},${this._y1 = +r}`;
  }
  quadraticCurveTo(t, r, i, n) {
    this._append`Q${+t},${+r},${this._x1 = +i},${this._y1 = +n}`;
  }
  bezierCurveTo(t, r, i, n, a, o) {
    this._append`C${+t},${+r},${+i},${+n},${this._x1 = +a},${this._y1 = +o}`;
  }
  arcTo(t, r, i, n, a) {
    if (t = +t, r = +r, i = +i, n = +n, a = +a, a < 0) throw new Error(`negative radius: ${a}`);
    let o = this._x1, s = this._y1, l = i - t, c = n - r, h = o - t, u = s - r, f = h * h + u * u;
    if (this._x1 === null)
      this._append`M${this._x1 = t},${this._y1 = r}`;
    else if (f > tr) if (!(Math.abs(u * l - c * h) > tr) || !a)
      this._append`L${this._x1 = t},${this._y1 = r}`;
    else {
      let p = i - o, g = n - s, m = l * l + c * c, x = p * p + g * g, y = Math.sqrt(m), b = Math.sqrt(f), _ = a * Math.tan((Os - Math.acos((m + f - x) / (2 * y * b))) / 2), k = _ / b, v = _ / y;
      Math.abs(k - 1) > tr && this._append`L${t + k * h},${r + k * u}`, this._append`A${a},${a},0,0,${+(u * p > h * g)},${this._x1 = t + v * l},${this._y1 = r + v * c}`;
    }
  }
  arc(t, r, i, n, a, o) {
    if (t = +t, r = +r, i = +i, o = !!o, i < 0) throw new Error(`negative radius: ${i}`);
    let s = i * Math.cos(n), l = i * Math.sin(n), c = t + s, h = r + l, u = 1 ^ o, f = o ? n - a : a - n;
    this._x1 === null ? this._append`M${c},${h}` : (Math.abs(this._x1 - c) > tr || Math.abs(this._y1 - h) > tr) && this._append`L${c},${h}`, i && (f < 0 && (f = f % Rs + Rs), f > R1 ? this._append`A${i},${i},0,1,${u},${t - s},${r - l}A${i},${i},0,1,${u},${this._x1 = c},${this._y1 = h}` : f > tr && this._append`A${i},${i},0,${+(f >= Os)},${u},${this._x1 = t + i * Math.cos(a)},${this._y1 = r + i * Math.sin(a)}`);
  }
  rect(t, r, i, n) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}h${i = +i}v${+n}h${-i}Z`;
  }
  toString() {
    return this._;
  }
}
function Lr(e) {
  return function() {
    return e;
  };
}
const XL = Math.abs, VL = Math.atan2, ZL = Math.cos, KL = Math.max, QL = Math.min, JL = Math.sin, tA = Math.sqrt, yc = 1e-12, Do = Math.PI, xc = Do / 2, eA = 2 * Do;
function rA(e) {
  return e > 1 ? 0 : e < -1 ? Do : Math.acos(e);
}
function iA(e) {
  return e >= 1 ? xc : e <= -1 ? -xc : Math.asin(e);
}
function N1(e) {
  let t = 3;
  return e.digits = function(r) {
    if (!arguments.length) return t;
    if (r == null)
      t = null;
    else {
      const i = Math.floor(r);
      if (!(i >= 0)) throw new RangeError(`invalid digits: ${r}`);
      t = i;
    }
    return e;
  }, () => new P1(t);
}
function z1(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function mu(e) {
  this._context = e;
}
mu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default:
        this._context.lineTo(e, t);
        break;
    }
  }
};
function Gn(e) {
  return new mu(e);
}
function W1(e) {
  return e[0];
}
function q1(e) {
  return e[1];
}
function H1(e, t) {
  var r = Lr(!0), i = null, n = Gn, a = null, o = N1(s);
  e = typeof e == "function" ? e : e === void 0 ? W1 : Lr(e), t = typeof t == "function" ? t : t === void 0 ? q1 : Lr(t);
  function s(l) {
    var c, h = (l = z1(l)).length, u, f = !1, p;
    for (i == null && (a = n(p = o())), c = 0; c <= h; ++c)
      !(c < h && r(u = l[c], c, l)) === f && ((f = !f) ? a.lineStart() : a.lineEnd()), f && a.point(+e(u, c, l), +t(u, c, l));
    if (p) return a = null, p + "" || null;
  }
  return s.x = function(l) {
    return arguments.length ? (e = typeof l == "function" ? l : Lr(+l), s) : e;
  }, s.y = function(l) {
    return arguments.length ? (t = typeof l == "function" ? l : Lr(+l), s) : t;
  }, s.defined = function(l) {
    return arguments.length ? (r = typeof l == "function" ? l : Lr(!!l), s) : r;
  }, s.curve = function(l) {
    return arguments.length ? (n = l, i != null && (a = n(i)), s) : n;
  }, s.context = function(l) {
    return arguments.length ? (l == null ? i = a = null : a = n(i = l), s) : i;
  }, s;
}
class yu {
  constructor(t, r) {
    this._context = t, this._x = r;
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  }
  point(t, r) {
    switch (t = +t, r = +r, this._point) {
      case 0: {
        this._point = 1, this._line ? this._context.lineTo(t, r) : this._context.moveTo(t, r);
        break;
      }
      case 1:
        this._point = 2;
      default: {
        this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + t) / 2, this._y0, this._x0, r, t, r) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + r) / 2, t, this._y0, t, r);
        break;
      }
    }
    this._x0 = t, this._y0 = r;
  }
}
function xu(e) {
  return new yu(e, !0);
}
function bu(e) {
  return new yu(e, !1);
}
function Ye() {
}
function Xn(e, t, r) {
  e._context.bezierCurveTo(
    (2 * e._x0 + e._x1) / 3,
    (2 * e._y0 + e._y1) / 3,
    (e._x0 + 2 * e._x1) / 3,
    (e._y0 + 2 * e._y1) / 3,
    (e._x0 + 4 * e._x1 + t) / 6,
    (e._y0 + 4 * e._y1 + r) / 6
  );
}
function Sa(e) {
  this._context = e;
}
Sa.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 3:
        Xn(this, this._x1, this._y1);
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
      default:
        Xn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Bn(e) {
  return new Sa(e);
}
function Cu(e) {
  this._context = e;
}
Cu.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x2, this._y2), this._context.closePath();
        break;
      }
      case 2: {
        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x2 = e, this._y2 = t;
        break;
      case 1:
        this._point = 2, this._x3 = e, this._y3 = t;
        break;
      case 2:
        this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
        break;
      default:
        Xn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function j1(e) {
  return new Cu(e);
}
function _u(e) {
  this._context = e;
}
_u.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        var r = (this._x0 + 4 * this._x1 + e) / 6, i = (this._y0 + 4 * this._y1 + t) / 6;
        this._line ? this._context.lineTo(r, i) : this._context.moveTo(r, i);
        break;
      case 3:
        this._point = 4;
      default:
        Xn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Y1(e) {
  return new _u(e);
}
function wu(e, t) {
  this._basis = new Sa(e), this._beta = t;
}
wu.prototype = {
  lineStart: function() {
    this._x = [], this._y = [], this._basis.lineStart();
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length - 1;
    if (r > 0)
      for (var i = e[0], n = t[0], a = e[r] - i, o = t[r] - n, s = -1, l; ++s <= r; )
        l = s / r, this._basis.point(
          this._beta * e[s] + (1 - this._beta) * (i + l * a),
          this._beta * t[s] + (1 - this._beta) * (n + l * o)
        );
    this._x = this._y = null, this._basis.lineEnd();
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
const U1 = function e(t) {
  function r(i) {
    return t === 1 ? new Sa(i) : new wu(i, t);
  }
  return r.beta = function(i) {
    return e(+i);
  }, r;
}(0.85);
function Vn(e, t, r) {
  e._context.bezierCurveTo(
    e._x1 + e._k * (e._x2 - e._x0),
    e._y1 + e._k * (e._y2 - e._y0),
    e._x2 + e._k * (e._x1 - t),
    e._y2 + e._k * (e._y1 - r),
    e._x2,
    e._y2
  );
}
function Oo(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Oo.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        Vn(this, this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2, this._x1 = e, this._y1 = t;
        break;
      case 2:
        this._point = 3;
      default:
        Vn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const vu = function e(t) {
  function r(i) {
    return new Oo(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function Ro(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Ro.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        Vn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const G1 = function e(t) {
  function r(i) {
    return new Ro(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function Io(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Io.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        Vn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const X1 = function e(t) {
  function r(i) {
    return new Io(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function Po(e, t, r) {
  var i = e._x1, n = e._y1, a = e._x2, o = e._y2;
  if (e._l01_a > yc) {
    var s = 2 * e._l01_2a + 3 * e._l01_a * e._l12_a + e._l12_2a, l = 3 * e._l01_a * (e._l01_a + e._l12_a);
    i = (i * s - e._x0 * e._l12_2a + e._x2 * e._l01_2a) / l, n = (n * s - e._y0 * e._l12_2a + e._y2 * e._l01_2a) / l;
  }
  if (e._l23_a > yc) {
    var c = 2 * e._l23_2a + 3 * e._l23_a * e._l12_a + e._l12_2a, h = 3 * e._l23_a * (e._l23_a + e._l12_a);
    a = (a * c + e._x1 * e._l23_2a - t * e._l12_2a) / h, o = (o * c + e._y1 * e._l23_2a - r * e._l12_2a) / h;
  }
  e._context.bezierCurveTo(i, n, a, o, e._x2, e._y2);
}
function ku(e, t) {
  this._context = e, this._alpha = t;
}
ku.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        this.point(this._x2, this._y2);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
      default:
        Po(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Su = function e(t) {
  function r(i) {
    return t ? new ku(i, t) : new Oo(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Tu(e, t) {
  this._context = e, this._alpha = t;
}
Tu.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        Po(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const V1 = function e(t) {
  function r(i) {
    return t ? new Tu(i, t) : new Ro(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Bu(e, t) {
  this._context = e, this._alpha = t;
}
Bu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        Po(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Z1 = function e(t) {
  function r(i) {
    return t ? new Bu(i, t) : new Io(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Lu(e) {
  this._context = e;
}
Lu.prototype = {
  areaStart: Ye,
  areaEnd: Ye,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    this._point && this._context.closePath();
  },
  point: function(e, t) {
    e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t));
  }
};
function K1(e) {
  return new Lu(e);
}
function bc(e) {
  return e < 0 ? -1 : 1;
}
function Cc(e, t, r) {
  var i = e._x1 - e._x0, n = t - e._x1, a = (e._y1 - e._y0) / (i || n < 0 && -0), o = (r - e._y1) / (n || i < 0 && -0), s = (a * n + o * i) / (i + n);
  return (bc(a) + bc(o)) * Math.min(Math.abs(a), Math.abs(o), 0.5 * Math.abs(s)) || 0;
}
function _c(e, t) {
  var r = e._x1 - e._x0;
  return r ? (3 * (e._y1 - e._y0) / r - t) / 2 : t;
}
function os(e, t, r) {
  var i = e._x0, n = e._y0, a = e._x1, o = e._y1, s = (a - i) / 3;
  e._context.bezierCurveTo(i + s, n + s * t, a - s, o - s * r, a, o);
}
function Zn(e) {
  this._context = e;
}
Zn.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        os(this, this._t0, _c(this, this._t0));
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    var r = NaN;
    if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
      switch (this._point) {
        case 0:
          this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
          break;
        case 1:
          this._point = 2;
          break;
        case 2:
          this._point = 3, os(this, _c(this, r = Cc(this, e, t)), r);
          break;
        default:
          os(this, this._t0, r = Cc(this, e, t));
          break;
      }
      this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = r;
    }
  }
};
function Au(e) {
  this._context = new Mu(e);
}
(Au.prototype = Object.create(Zn.prototype)).point = function(e, t) {
  Zn.prototype.point.call(this, t, e);
};
function Mu(e) {
  this._context = e;
}
Mu.prototype = {
  moveTo: function(e, t) {
    this._context.moveTo(t, e);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(e, t) {
    this._context.lineTo(t, e);
  },
  bezierCurveTo: function(e, t, r, i, n, a) {
    this._context.bezierCurveTo(t, e, i, r, a, n);
  }
};
function Eu(e) {
  return new Zn(e);
}
function $u(e) {
  return new Au(e);
}
function Fu(e) {
  this._context = e;
}
Fu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = [], this._y = [];
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length;
    if (r)
      if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), r === 2)
        this._context.lineTo(e[1], t[1]);
      else
        for (var i = wc(e), n = wc(t), a = 0, o = 1; o < r; ++a, ++o)
          this._context.bezierCurveTo(i[0][a], n[0][a], i[1][a], n[1][a], e[o], t[o]);
    (this._line || this._line !== 0 && r === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null;
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
function wc(e) {
  var t, r = e.length - 1, i, n = new Array(r), a = new Array(r), o = new Array(r);
  for (n[0] = 0, a[0] = 2, o[0] = e[0] + 2 * e[1], t = 1; t < r - 1; ++t) n[t] = 1, a[t] = 4, o[t] = 4 * e[t] + 2 * e[t + 1];
  for (n[r - 1] = 2, a[r - 1] = 7, o[r - 1] = 8 * e[r - 1] + e[r], t = 1; t < r; ++t) i = n[t] / a[t - 1], a[t] -= i, o[t] -= i * o[t - 1];
  for (n[r - 1] = o[r - 1] / a[r - 1], t = r - 2; t >= 0; --t) n[t] = (o[t] - n[t + 1]) / a[t];
  for (a[r - 1] = (e[r] + n[r - 1]) / 2, t = 0; t < r - 1; ++t) a[t] = 2 * e[t + 1] - n[t + 1];
  return [n, a];
}
function Du(e) {
  return new Fu(e);
}
function Ta(e, t) {
  this._context = e, this._t = t;
}
Ta.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = this._y = NaN, this._point = 0;
  },
  lineEnd: function() {
    0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line);
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default: {
        if (this._t <= 0)
          this._context.lineTo(this._x, t), this._context.lineTo(e, t);
        else {
          var r = this._x * (1 - this._t) + e * this._t;
          this._context.lineTo(r, this._y), this._context.lineTo(r, t);
        }
        break;
      }
    }
    this._x = e, this._y = t;
  }
};
function Ou(e) {
  return new Ta(e, 0.5);
}
function Ru(e) {
  return new Ta(e, 0);
}
function Iu(e) {
  return new Ta(e, 1);
}
function vi(e, t, r) {
  this.k = e, this.x = t, this.y = r;
}
vi.prototype = {
  constructor: vi,
  scale: function(e) {
    return e === 1 ? this : new vi(this.k * e, this.x, this.y);
  },
  translate: function(e, t) {
    return e === 0 & t === 0 ? this : new vi(this.k, this.x + this.k * e, this.y + this.k * t);
  },
  apply: function(e) {
    return [e[0] * this.k + this.x, e[1] * this.k + this.y];
  },
  applyX: function(e) {
    return e * this.k + this.x;
  },
  applyY: function(e) {
    return e * this.k + this.y;
  },
  invert: function(e) {
    return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k];
  },
  invertX: function(e) {
    return (e - this.x) / this.k;
  },
  invertY: function(e) {
    return (e - this.y) / this.k;
  },
  rescaleX: function(e) {
    return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e));
  },
  rescaleY: function(e) {
    return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e));
  },
  toString: function() {
    return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")";
  }
};
vi.prototype;
var Q1 = /* @__PURE__ */ d((e) => {
  var n;
  const { securityLevel: t } = ut();
  let r = ht("body");
  if (t === "sandbox") {
    const o = ((n = ht(`#i${e}`).node()) == null ? void 0 : n.contentDocument) ?? document;
    r = ht(o.body);
  }
  return r.select(`#${e}`);
}, "selectSvgElement");
function No(e) {
  return typeof e > "u" || e === null;
}
d(No, "isNothing");
function Pu(e) {
  return typeof e == "object" && e !== null;
}
d(Pu, "isObject");
function Nu(e) {
  return Array.isArray(e) ? e : No(e) ? [] : [e];
}
d(Nu, "toArray");
function zu(e, t) {
  var r, i, n, a;
  if (t)
    for (a = Object.keys(t), r = 0, i = a.length; r < i; r += 1)
      n = a[r], e[n] = t[n];
  return e;
}
d(zu, "extend");
function Wu(e, t) {
  var r = "", i;
  for (i = 0; i < t; i += 1)
    r += e;
  return r;
}
d(Wu, "repeat");
function qu(e) {
  return e === 0 && Number.NEGATIVE_INFINITY === 1 / e;
}
d(qu, "isNegativeZero");
var J1 = No, t2 = Pu, e2 = Nu, r2 = Wu, i2 = qu, n2 = zu, Lt = {
  isNothing: J1,
  isObject: t2,
  toArray: e2,
  repeat: r2,
  isNegativeZero: i2,
  extend: n2
};
function zo(e, t) {
  var r = "", i = e.reason || "(unknown reason)";
  return e.mark ? (e.mark.name && (r += 'in "' + e.mark.name + '" '), r += "(" + (e.mark.line + 1) + ":" + (e.mark.column + 1) + ")", !t && e.mark.snippet && (r += `

` + e.mark.snippet), i + " " + r) : i;
}
d(zo, "formatError");
function Vr(e, t) {
  Error.call(this), this.name = "YAMLException", this.reason = e, this.mark = t, this.message = zo(this, !1), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack || "";
}
d(Vr, "YAMLException$1");
Vr.prototype = Object.create(Error.prototype);
Vr.prototype.constructor = Vr;
Vr.prototype.toString = /* @__PURE__ */ d(function(t) {
  return this.name + ": " + zo(this, t);
}, "toString");
var Qt = Vr;
function Ln(e, t, r, i, n) {
  var a = "", o = "", s = Math.floor(n / 2) - 1;
  return i - t > s && (a = " ... ", t = i - s + a.length), r - i > s && (o = " ...", r = i + s - o.length), {
    str: a + e.slice(t, r).replace(/\t/g, "→") + o,
    pos: i - t + a.length
    // relative position
  };
}
d(Ln, "getLine");
function An(e, t) {
  return Lt.repeat(" ", t - e.length) + e;
}
d(An, "padStart");
function Hu(e, t) {
  if (t = Object.create(t || null), !e.buffer) return null;
  t.maxLength || (t.maxLength = 79), typeof t.indent != "number" && (t.indent = 1), typeof t.linesBefore != "number" && (t.linesBefore = 3), typeof t.linesAfter != "number" && (t.linesAfter = 2);
  for (var r = /\r?\n|\r|\0/g, i = [0], n = [], a, o = -1; a = r.exec(e.buffer); )
    n.push(a.index), i.push(a.index + a[0].length), e.position <= a.index && o < 0 && (o = i.length - 2);
  o < 0 && (o = i.length - 1);
  var s = "", l, c, h = Math.min(e.line + t.linesAfter, n.length).toString().length, u = t.maxLength - (t.indent + h + 3);
  for (l = 1; l <= t.linesBefore && !(o - l < 0); l++)
    c = Ln(
      e.buffer,
      i[o - l],
      n[o - l],
      e.position - (i[o] - i[o - l]),
      u
    ), s = Lt.repeat(" ", t.indent) + An((e.line - l + 1).toString(), h) + " | " + c.str + `
` + s;
  for (c = Ln(e.buffer, i[o], n[o], e.position, u), s += Lt.repeat(" ", t.indent) + An((e.line + 1).toString(), h) + " | " + c.str + `
`, s += Lt.repeat("-", t.indent + h + 3 + c.pos) + `^
`, l = 1; l <= t.linesAfter && !(o + l >= n.length); l++)
    c = Ln(
      e.buffer,
      i[o + l],
      n[o + l],
      e.position - (i[o] - i[o + l]),
      u
    ), s += Lt.repeat(" ", t.indent) + An((e.line + l + 1).toString(), h) + " | " + c.str + `
`;
  return s.replace(/\n$/, "");
}
d(Hu, "makeSnippet");
var a2 = Hu, s2 = [
  "kind",
  "multi",
  "resolve",
  "construct",
  "instanceOf",
  "predicate",
  "represent",
  "representName",
  "defaultStyle",
  "styleAliases"
], o2 = [
  "scalar",
  "sequence",
  "mapping"
];
function ju(e) {
  var t = {};
  return e !== null && Object.keys(e).forEach(function(r) {
    e[r].forEach(function(i) {
      t[String(i)] = r;
    });
  }), t;
}
d(ju, "compileStyleAliases");
function Yu(e, t) {
  if (t = t || {}, Object.keys(t).forEach(function(r) {
    if (s2.indexOf(r) === -1)
      throw new Qt('Unknown option "' + r + '" is met in definition of "' + e + '" YAML type.');
  }), this.options = t, this.tag = e, this.kind = t.kind || null, this.resolve = t.resolve || function() {
    return !0;
  }, this.construct = t.construct || function(r) {
    return r;
  }, this.instanceOf = t.instanceOf || null, this.predicate = t.predicate || null, this.represent = t.represent || null, this.representName = t.representName || null, this.defaultStyle = t.defaultStyle || null, this.multi = t.multi || !1, this.styleAliases = ju(t.styleAliases || null), o2.indexOf(this.kind) === -1)
    throw new Qt('Unknown kind "' + this.kind + '" is specified for "' + e + '" YAML type.');
}
d(Yu, "Type$1");
var Nt = Yu;
function Is(e, t) {
  var r = [];
  return e[t].forEach(function(i) {
    var n = r.length;
    r.forEach(function(a, o) {
      a.tag === i.tag && a.kind === i.kind && a.multi === i.multi && (n = o);
    }), r[n] = i;
  }), r;
}
d(Is, "compileList");
function Uu() {
  var e = {
    scalar: {},
    sequence: {},
    mapping: {},
    fallback: {},
    multi: {
      scalar: [],
      sequence: [],
      mapping: [],
      fallback: []
    }
  }, t, r;
  function i(n) {
    n.multi ? (e.multi[n.kind].push(n), e.multi.fallback.push(n)) : e[n.kind][n.tag] = e.fallback[n.tag] = n;
  }
  for (d(i, "collectType"), t = 0, r = arguments.length; t < r; t += 1)
    arguments[t].forEach(i);
  return e;
}
d(Uu, "compileMap");
function Kn(e) {
  return this.extend(e);
}
d(Kn, "Schema$1");
Kn.prototype.extend = /* @__PURE__ */ d(function(t) {
  var r = [], i = [];
  if (t instanceof Nt)
    i.push(t);
  else if (Array.isArray(t))
    i = i.concat(t);
  else if (t && (Array.isArray(t.implicit) || Array.isArray(t.explicit)))
    t.implicit && (r = r.concat(t.implicit)), t.explicit && (i = i.concat(t.explicit));
  else
    throw new Qt("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");
  r.forEach(function(a) {
    if (!(a instanceof Nt))
      throw new Qt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
    if (a.loadKind && a.loadKind !== "scalar")
      throw new Qt("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");
    if (a.multi)
      throw new Qt("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.");
  }), i.forEach(function(a) {
    if (!(a instanceof Nt))
      throw new Qt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
  });
  var n = Object.create(Kn.prototype);
  return n.implicit = (this.implicit || []).concat(r), n.explicit = (this.explicit || []).concat(i), n.compiledImplicit = Is(n, "implicit"), n.compiledExplicit = Is(n, "explicit"), n.compiledTypeMap = Uu(n.compiledImplicit, n.compiledExplicit), n;
}, "extend");
var l2 = Kn, c2 = new Nt("tag:yaml.org,2002:str", {
  kind: "scalar",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : "";
  }, "construct")
}), h2 = new Nt("tag:yaml.org,2002:seq", {
  kind: "sequence",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : [];
  }, "construct")
}), u2 = new Nt("tag:yaml.org,2002:map", {
  kind: "mapping",
  construct: /* @__PURE__ */ d(function(e) {
    return e !== null ? e : {};
  }, "construct")
}), f2 = new l2({
  explicit: [
    c2,
    h2,
    u2
  ]
});
function Gu(e) {
  if (e === null) return !0;
  var t = e.length;
  return t === 1 && e === "~" || t === 4 && (e === "null" || e === "Null" || e === "NULL");
}
d(Gu, "resolveYamlNull");
function Xu() {
  return null;
}
d(Xu, "constructYamlNull");
function Vu(e) {
  return e === null;
}
d(Vu, "isNull");
var p2 = new Nt("tag:yaml.org,2002:null", {
  kind: "scalar",
  resolve: Gu,
  construct: Xu,
  predicate: Vu,
  represent: {
    canonical: /* @__PURE__ */ d(function() {
      return "~";
    }, "canonical"),
    lowercase: /* @__PURE__ */ d(function() {
      return "null";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ d(function() {
      return "NULL";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ d(function() {
      return "Null";
    }, "camelcase"),
    empty: /* @__PURE__ */ d(function() {
      return "";
    }, "empty")
  },
  defaultStyle: "lowercase"
});
function Zu(e) {
  if (e === null) return !1;
  var t = e.length;
  return t === 4 && (e === "true" || e === "True" || e === "TRUE") || t === 5 && (e === "false" || e === "False" || e === "FALSE");
}
d(Zu, "resolveYamlBoolean");
function Ku(e) {
  return e === "true" || e === "True" || e === "TRUE";
}
d(Ku, "constructYamlBoolean");
function Qu(e) {
  return Object.prototype.toString.call(e) === "[object Boolean]";
}
d(Qu, "isBoolean");
var d2 = new Nt("tag:yaml.org,2002:bool", {
  kind: "scalar",
  resolve: Zu,
  construct: Ku,
  predicate: Qu,
  represent: {
    lowercase: /* @__PURE__ */ d(function(e) {
      return e ? "true" : "false";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ d(function(e) {
      return e ? "TRUE" : "FALSE";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ d(function(e) {
      return e ? "True" : "False";
    }, "camelcase")
  },
  defaultStyle: "lowercase"
});
function Ju(e) {
  return 48 <= e && e <= 57 || 65 <= e && e <= 70 || 97 <= e && e <= 102;
}
d(Ju, "isHexCode");
function tf(e) {
  return 48 <= e && e <= 55;
}
d(tf, "isOctCode");
function ef(e) {
  return 48 <= e && e <= 57;
}
d(ef, "isDecCode");
function rf(e) {
  if (e === null) return !1;
  var t = e.length, r = 0, i = !1, n;
  if (!t) return !1;
  if (n = e[r], (n === "-" || n === "+") && (n = e[++r]), n === "0") {
    if (r + 1 === t) return !0;
    if (n = e[++r], n === "b") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (n !== "0" && n !== "1") return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "x") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!Ju(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "o") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!tf(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
  }
  if (n === "_") return !1;
  for (; r < t; r++)
    if (n = e[r], n !== "_") {
      if (!ef(e.charCodeAt(r)))
        return !1;
      i = !0;
    }
  return !(!i || n === "_");
}
d(rf, "resolveYamlInteger");
function nf(e) {
  var t = e, r = 1, i;
  if (t.indexOf("_") !== -1 && (t = t.replace(/_/g, "")), i = t[0], (i === "-" || i === "+") && (i === "-" && (r = -1), t = t.slice(1), i = t[0]), t === "0") return 0;
  if (i === "0") {
    if (t[1] === "b") return r * parseInt(t.slice(2), 2);
    if (t[1] === "x") return r * parseInt(t.slice(2), 16);
    if (t[1] === "o") return r * parseInt(t.slice(2), 8);
  }
  return r * parseInt(t, 10);
}
d(nf, "constructYamlInteger");
function af(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && e % 1 === 0 && !Lt.isNegativeZero(e);
}
d(af, "isInteger");
var g2 = new Nt("tag:yaml.org,2002:int", {
  kind: "scalar",
  resolve: rf,
  construct: nf,
  predicate: af,
  represent: {
    binary: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0b" + e.toString(2) : "-0b" + e.toString(2).slice(1);
    }, "binary"),
    octal: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0o" + e.toString(8) : "-0o" + e.toString(8).slice(1);
    }, "octal"),
    decimal: /* @__PURE__ */ d(function(e) {
      return e.toString(10);
    }, "decimal"),
    /* eslint-disable max-len */
    hexadecimal: /* @__PURE__ */ d(function(e) {
      return e >= 0 ? "0x" + e.toString(16).toUpperCase() : "-0x" + e.toString(16).toUpperCase().slice(1);
    }, "hexadecimal")
  },
  defaultStyle: "decimal",
  styleAliases: {
    binary: [2, "bin"],
    octal: [8, "oct"],
    decimal: [10, "dec"],
    hexadecimal: [16, "hex"]
  }
}), m2 = new RegExp(
  // 2.5e4, 2.5 and integers
  "^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"
);
function sf(e) {
  return !(e === null || !m2.test(e) || // Quick hack to not allow integers end with `_`
  // Probably should update regexp & check speed
  e[e.length - 1] === "_");
}
d(sf, "resolveYamlFloat");
function of(e) {
  var t, r;
  return t = e.replace(/_/g, "").toLowerCase(), r = t[0] === "-" ? -1 : 1, "+-".indexOf(t[0]) >= 0 && (t = t.slice(1)), t === ".inf" ? r === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : t === ".nan" ? NaN : r * parseFloat(t, 10);
}
d(of, "constructYamlFloat");
var y2 = /^[-+]?[0-9]+e/;
function lf(e, t) {
  var r;
  if (isNaN(e))
    switch (t) {
      case "lowercase":
        return ".nan";
      case "uppercase":
        return ".NAN";
      case "camelcase":
        return ".NaN";
    }
  else if (Number.POSITIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return ".inf";
      case "uppercase":
        return ".INF";
      case "camelcase":
        return ".Inf";
    }
  else if (Number.NEGATIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return "-.inf";
      case "uppercase":
        return "-.INF";
      case "camelcase":
        return "-.Inf";
    }
  else if (Lt.isNegativeZero(e))
    return "-0.0";
  return r = e.toString(10), y2.test(r) ? r.replace("e", ".e") : r;
}
d(lf, "representYamlFloat");
function cf(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && (e % 1 !== 0 || Lt.isNegativeZero(e));
}
d(cf, "isFloat");
var x2 = new Nt("tag:yaml.org,2002:float", {
  kind: "scalar",
  resolve: sf,
  construct: of,
  predicate: cf,
  represent: lf,
  defaultStyle: "lowercase"
}), hf = f2.extend({
  implicit: [
    p2,
    d2,
    g2,
    x2
  ]
}), b2 = hf, uf = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"
), ff = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$"
);
function pf(e) {
  return e === null ? !1 : uf.exec(e) !== null || ff.exec(e) !== null;
}
d(pf, "resolveYamlTimestamp");
function df(e) {
  var t, r, i, n, a, o, s, l = 0, c = null, h, u, f;
  if (t = uf.exec(e), t === null && (t = ff.exec(e)), t === null) throw new Error("Date resolve error");
  if (r = +t[1], i = +t[2] - 1, n = +t[3], !t[4])
    return new Date(Date.UTC(r, i, n));
  if (a = +t[4], o = +t[5], s = +t[6], t[7]) {
    for (l = t[7].slice(0, 3); l.length < 3; )
      l += "0";
    l = +l;
  }
  return t[9] && (h = +t[10], u = +(t[11] || 0), c = (h * 60 + u) * 6e4, t[9] === "-" && (c = -c)), f = new Date(Date.UTC(r, i, n, a, o, s, l)), c && f.setTime(f.getTime() - c), f;
}
d(df, "constructYamlTimestamp");
function gf(e) {
  return e.toISOString();
}
d(gf, "representYamlTimestamp");
var C2 = new Nt("tag:yaml.org,2002:timestamp", {
  kind: "scalar",
  resolve: pf,
  construct: df,
  instanceOf: Date,
  represent: gf
});
function mf(e) {
  return e === "<<" || e === null;
}
d(mf, "resolveYamlMerge");
var _2 = new Nt("tag:yaml.org,2002:merge", {
  kind: "scalar",
  resolve: mf
}), Wo = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;
function yf(e) {
  if (e === null) return !1;
  var t, r, i = 0, n = e.length, a = Wo;
  for (r = 0; r < n; r++)
    if (t = a.indexOf(e.charAt(r)), !(t > 64)) {
      if (t < 0) return !1;
      i += 6;
    }
  return i % 8 === 0;
}
d(yf, "resolveYamlBinary");
function xf(e) {
  var t, r, i = e.replace(/[\r\n=]/g, ""), n = i.length, a = Wo, o = 0, s = [];
  for (t = 0; t < n; t++)
    t % 4 === 0 && t && (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)), o = o << 6 | a.indexOf(i.charAt(t));
  return r = n % 4 * 6, r === 0 ? (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)) : r === 18 ? (s.push(o >> 10 & 255), s.push(o >> 2 & 255)) : r === 12 && s.push(o >> 4 & 255), new Uint8Array(s);
}
d(xf, "constructYamlBinary");
function bf(e) {
  var t = "", r = 0, i, n, a = e.length, o = Wo;
  for (i = 0; i < a; i++)
    i % 3 === 0 && i && (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]), r = (r << 8) + e[i];
  return n = a % 3, n === 0 ? (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]) : n === 2 ? (t += o[r >> 10 & 63], t += o[r >> 4 & 63], t += o[r << 2 & 63], t += o[64]) : n === 1 && (t += o[r >> 2 & 63], t += o[r << 4 & 63], t += o[64], t += o[64]), t;
}
d(bf, "representYamlBinary");
function Cf(e) {
  return Object.prototype.toString.call(e) === "[object Uint8Array]";
}
d(Cf, "isBinary");
var w2 = new Nt("tag:yaml.org,2002:binary", {
  kind: "scalar",
  resolve: yf,
  construct: xf,
  predicate: Cf,
  represent: bf
}), v2 = Object.prototype.hasOwnProperty, k2 = Object.prototype.toString;
function _f(e) {
  if (e === null) return !0;
  var t = [], r, i, n, a, o, s = e;
  for (r = 0, i = s.length; r < i; r += 1) {
    if (n = s[r], o = !1, k2.call(n) !== "[object Object]") return !1;
    for (a in n)
      if (v2.call(n, a))
        if (!o) o = !0;
        else return !1;
    if (!o) return !1;
    if (t.indexOf(a) === -1) t.push(a);
    else return !1;
  }
  return !0;
}
d(_f, "resolveYamlOmap");
function wf(e) {
  return e !== null ? e : [];
}
d(wf, "constructYamlOmap");
var S2 = new Nt("tag:yaml.org,2002:omap", {
  kind: "sequence",
  resolve: _f,
  construct: wf
}), T2 = Object.prototype.toString;
function vf(e) {
  if (e === null) return !0;
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1) {
    if (i = o[t], T2.call(i) !== "[object Object]" || (n = Object.keys(i), n.length !== 1)) return !1;
    a[t] = [n[0], i[n[0]]];
  }
  return !0;
}
d(vf, "resolveYamlPairs");
function kf(e) {
  if (e === null) return [];
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1)
    i = o[t], n = Object.keys(i), a[t] = [n[0], i[n[0]]];
  return a;
}
d(kf, "constructYamlPairs");
var B2 = new Nt("tag:yaml.org,2002:pairs", {
  kind: "sequence",
  resolve: vf,
  construct: kf
}), L2 = Object.prototype.hasOwnProperty;
function Sf(e) {
  if (e === null) return !0;
  var t, r = e;
  for (t in r)
    if (L2.call(r, t) && r[t] !== null)
      return !1;
  return !0;
}
d(Sf, "resolveYamlSet");
function Tf(e) {
  return e !== null ? e : {};
}
d(Tf, "constructYamlSet");
var A2 = new Nt("tag:yaml.org,2002:set", {
  kind: "mapping",
  resolve: Sf,
  construct: Tf
}), Bf = b2.extend({
  implicit: [
    C2,
    _2
  ],
  explicit: [
    w2,
    S2,
    B2,
    A2
  ]
}), Ue = Object.prototype.hasOwnProperty, Qn = 1, Lf = 2, Af = 3, Jn = 4, ls = 1, M2 = 2, vc = 3, E2 = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/, $2 = /[\x85\u2028\u2029]/, F2 = /[,\[\]\{\}]/, Mf = /^(?:!|!!|![a-z\-]+!)$/i, Ef = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
function Ps(e) {
  return Object.prototype.toString.call(e);
}
d(Ps, "_class");
function fe(e) {
  return e === 10 || e === 13;
}
d(fe, "is_EOL");
function je(e) {
  return e === 9 || e === 32;
}
d(je, "is_WHITE_SPACE");
function Yt(e) {
  return e === 9 || e === 32 || e === 10 || e === 13;
}
d(Yt, "is_WS_OR_EOL");
function ar(e) {
  return e === 44 || e === 91 || e === 93 || e === 123 || e === 125;
}
d(ar, "is_FLOW_INDICATOR");
function $f(e) {
  var t;
  return 48 <= e && e <= 57 ? e - 48 : (t = e | 32, 97 <= t && t <= 102 ? t - 97 + 10 : -1);
}
d($f, "fromHexCode");
function Ff(e) {
  return e === 120 ? 2 : e === 117 ? 4 : e === 85 ? 8 : 0;
}
d(Ff, "escapedHexLen");
function Df(e) {
  return 48 <= e && e <= 57 ? e - 48 : -1;
}
d(Df, "fromDecimalCode");
function Ns(e) {
  return e === 48 ? "\0" : e === 97 ? "\x07" : e === 98 ? "\b" : e === 116 || e === 9 ? "	" : e === 110 ? `
` : e === 118 ? "\v" : e === 102 ? "\f" : e === 114 ? "\r" : e === 101 ? "\x1B" : e === 32 ? " " : e === 34 ? '"' : e === 47 ? "/" : e === 92 ? "\\" : e === 78 ? "" : e === 95 ? " " : e === 76 ? "\u2028" : e === 80 ? "\u2029" : "";
}
d(Ns, "simpleEscapeSequence");
function Of(e) {
  return e <= 65535 ? String.fromCharCode(e) : String.fromCharCode(
    (e - 65536 >> 10) + 55296,
    (e - 65536 & 1023) + 56320
  );
}
d(Of, "charFromCodepoint");
var Rf = new Array(256), If = new Array(256);
for (Je = 0; Je < 256; Je++)
  Rf[Je] = Ns(Je) ? 1 : 0, If[Je] = Ns(Je);
var Je;
function Pf(e, t) {
  this.input = e, this.filename = t.filename || null, this.schema = t.schema || Bf, this.onWarning = t.onWarning || null, this.legacy = t.legacy || !1, this.json = t.json || !1, this.listener = t.listener || null, this.implicitTypes = this.schema.compiledImplicit, this.typeMap = this.schema.compiledTypeMap, this.length = e.length, this.position = 0, this.line = 0, this.lineStart = 0, this.lineIndent = 0, this.firstTabInLine = -1, this.documents = [];
}
d(Pf, "State$1");
function qo(e, t) {
  var r = {
    name: e.filename,
    buffer: e.input.slice(0, -1),
    // omit trailing \0
    position: e.position,
    line: e.line,
    column: e.position - e.lineStart
  };
  return r.snippet = a2(r), new Qt(t, r);
}
d(qo, "generateError");
function K(e, t) {
  throw qo(e, t);
}
d(K, "throwError");
function Pi(e, t) {
  e.onWarning && e.onWarning.call(null, qo(e, t));
}
d(Pi, "throwWarning");
var kc = {
  YAML: /* @__PURE__ */ d(function(t, r, i) {
    var n, a, o;
    t.version !== null && K(t, "duplication of %YAML directive"), i.length !== 1 && K(t, "YAML directive accepts exactly one argument"), n = /^([0-9]+)\.([0-9]+)$/.exec(i[0]), n === null && K(t, "ill-formed argument of the YAML directive"), a = parseInt(n[1], 10), o = parseInt(n[2], 10), a !== 1 && K(t, "unacceptable YAML version of the document"), t.version = i[0], t.checkLineBreaks = o < 2, o !== 1 && o !== 2 && Pi(t, "unsupported YAML version of the document");
  }, "handleYamlDirective"),
  TAG: /* @__PURE__ */ d(function(t, r, i) {
    var n, a;
    i.length !== 2 && K(t, "TAG directive accepts exactly two arguments"), n = i[0], a = i[1], Mf.test(n) || K(t, "ill-formed tag handle (first argument) of the TAG directive"), Ue.call(t.tagMap, n) && K(t, 'there is a previously declared suffix for "' + n + '" tag handle'), Ef.test(a) || K(t, "ill-formed tag prefix (second argument) of the TAG directive");
    try {
      a = decodeURIComponent(a);
    } catch {
      K(t, "tag prefix is malformed: " + a);
    }
    t.tagMap[n] = a;
  }, "handleTagDirective")
};
function Ie(e, t, r, i) {
  var n, a, o, s;
  if (t < r) {
    if (s = e.input.slice(t, r), i)
      for (n = 0, a = s.length; n < a; n += 1)
        o = s.charCodeAt(n), o === 9 || 32 <= o && o <= 1114111 || K(e, "expected valid JSON character");
    else E2.test(s) && K(e, "the stream contains non-printable characters");
    e.result += s;
  }
}
d(Ie, "captureSegment");
function zs(e, t, r, i) {
  var n, a, o, s;
  for (Lt.isObject(r) || K(e, "cannot merge mappings; the provided source object is unacceptable"), n = Object.keys(r), o = 0, s = n.length; o < s; o += 1)
    a = n[o], Ue.call(t, a) || (t[a] = r[a], i[a] = !0);
}
d(zs, "mergeMappings");
function sr(e, t, r, i, n, a, o, s, l) {
  var c, h;
  if (Array.isArray(n))
    for (n = Array.prototype.slice.call(n), c = 0, h = n.length; c < h; c += 1)
      Array.isArray(n[c]) && K(e, "nested arrays are not supported inside keys"), typeof n == "object" && Ps(n[c]) === "[object Object]" && (n[c] = "[object Object]");
  if (typeof n == "object" && Ps(n) === "[object Object]" && (n = "[object Object]"), n = String(n), t === null && (t = {}), i === "tag:yaml.org,2002:merge")
    if (Array.isArray(a))
      for (c = 0, h = a.length; c < h; c += 1)
        zs(e, t, a[c], r);
    else
      zs(e, t, a, r);
  else
    !e.json && !Ue.call(r, n) && Ue.call(t, n) && (e.line = o || e.line, e.lineStart = s || e.lineStart, e.position = l || e.position, K(e, "duplicated mapping key")), n === "__proto__" ? Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      value: a
    }) : t[n] = a, delete r[n];
  return t;
}
d(sr, "storeMappingPair");
function Ba(e) {
  var t;
  t = e.input.charCodeAt(e.position), t === 10 ? e.position++ : t === 13 ? (e.position++, e.input.charCodeAt(e.position) === 10 && e.position++) : K(e, "a line break is expected"), e.line += 1, e.lineStart = e.position, e.firstTabInLine = -1;
}
d(Ba, "readLineBreak");
function vt(e, t, r) {
  for (var i = 0, n = e.input.charCodeAt(e.position); n !== 0; ) {
    for (; je(n); )
      n === 9 && e.firstTabInLine === -1 && (e.firstTabInLine = e.position), n = e.input.charCodeAt(++e.position);
    if (t && n === 35)
      do
        n = e.input.charCodeAt(++e.position);
      while (n !== 10 && n !== 13 && n !== 0);
    if (fe(n))
      for (Ba(e), n = e.input.charCodeAt(e.position), i++, e.lineIndent = 0; n === 32; )
        e.lineIndent++, n = e.input.charCodeAt(++e.position);
    else
      break;
  }
  return r !== -1 && i !== 0 && e.lineIndent < r && Pi(e, "deficient indentation"), i;
}
d(vt, "skipSeparationSpace");
function Ki(e) {
  var t = e.position, r;
  return r = e.input.charCodeAt(t), !!((r === 45 || r === 46) && r === e.input.charCodeAt(t + 1) && r === e.input.charCodeAt(t + 2) && (t += 3, r = e.input.charCodeAt(t), r === 0 || Yt(r)));
}
d(Ki, "testDocumentSeparator");
function La(e, t) {
  t === 1 ? e.result += " " : t > 1 && (e.result += Lt.repeat(`
`, t - 1));
}
d(La, "writeFoldedLines");
function Nf(e, t, r) {
  var i, n, a, o, s, l, c, h, u = e.kind, f = e.result, p;
  if (p = e.input.charCodeAt(e.position), Yt(p) || ar(p) || p === 35 || p === 38 || p === 42 || p === 33 || p === 124 || p === 62 || p === 39 || p === 34 || p === 37 || p === 64 || p === 96 || (p === 63 || p === 45) && (n = e.input.charCodeAt(e.position + 1), Yt(n) || r && ar(n)))
    return !1;
  for (e.kind = "scalar", e.result = "", a = o = e.position, s = !1; p !== 0; ) {
    if (p === 58) {
      if (n = e.input.charCodeAt(e.position + 1), Yt(n) || r && ar(n))
        break;
    } else if (p === 35) {
      if (i = e.input.charCodeAt(e.position - 1), Yt(i))
        break;
    } else {
      if (e.position === e.lineStart && Ki(e) || r && ar(p))
        break;
      if (fe(p))
        if (l = e.line, c = e.lineStart, h = e.lineIndent, vt(e, !1, -1), e.lineIndent >= t) {
          s = !0, p = e.input.charCodeAt(e.position);
          continue;
        } else {
          e.position = o, e.line = l, e.lineStart = c, e.lineIndent = h;
          break;
        }
    }
    s && (Ie(e, a, o, !1), La(e, e.line - l), a = o = e.position, s = !1), je(p) || (o = e.position + 1), p = e.input.charCodeAt(++e.position);
  }
  return Ie(e, a, o, !1), e.result ? !0 : (e.kind = u, e.result = f, !1);
}
d(Nf, "readPlainScalar");
function zf(e, t) {
  var r, i, n;
  if (r = e.input.charCodeAt(e.position), r !== 39)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, i = n = e.position; (r = e.input.charCodeAt(e.position)) !== 0; )
    if (r === 39)
      if (Ie(e, i, e.position, !0), r = e.input.charCodeAt(++e.position), r === 39)
        i = e.position, e.position++, n = e.position;
      else
        return !0;
    else fe(r) ? (Ie(e, i, n, !0), La(e, vt(e, !1, t)), i = n = e.position) : e.position === e.lineStart && Ki(e) ? K(e, "unexpected end of the document within a single quoted scalar") : (e.position++, n = e.position);
  K(e, "unexpected end of the stream within a single quoted scalar");
}
d(zf, "readSingleQuotedScalar");
function Wf(e, t) {
  var r, i, n, a, o, s;
  if (s = e.input.charCodeAt(e.position), s !== 34)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, r = i = e.position; (s = e.input.charCodeAt(e.position)) !== 0; ) {
    if (s === 34)
      return Ie(e, r, e.position, !0), e.position++, !0;
    if (s === 92) {
      if (Ie(e, r, e.position, !0), s = e.input.charCodeAt(++e.position), fe(s))
        vt(e, !1, t);
      else if (s < 256 && Rf[s])
        e.result += If[s], e.position++;
      else if ((o = Ff(s)) > 0) {
        for (n = o, a = 0; n > 0; n--)
          s = e.input.charCodeAt(++e.position), (o = $f(s)) >= 0 ? a = (a << 4) + o : K(e, "expected hexadecimal character");
        e.result += Of(a), e.position++;
      } else
        K(e, "unknown escape sequence");
      r = i = e.position;
    } else fe(s) ? (Ie(e, r, i, !0), La(e, vt(e, !1, t)), r = i = e.position) : e.position === e.lineStart && Ki(e) ? K(e, "unexpected end of the document within a double quoted scalar") : (e.position++, i = e.position);
  }
  K(e, "unexpected end of the stream within a double quoted scalar");
}
d(Wf, "readDoubleQuotedScalar");
function qf(e, t) {
  var r = !0, i, n, a, o = e.tag, s, l = e.anchor, c, h, u, f, p, g = /* @__PURE__ */ Object.create(null), m, x, y, b;
  if (b = e.input.charCodeAt(e.position), b === 91)
    h = 93, p = !1, s = [];
  else if (b === 123)
    h = 125, p = !0, s = {};
  else
    return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = s), b = e.input.charCodeAt(++e.position); b !== 0; ) {
    if (vt(e, !0, t), b = e.input.charCodeAt(e.position), b === h)
      return e.position++, e.tag = o, e.anchor = l, e.kind = p ? "mapping" : "sequence", e.result = s, !0;
    r ? b === 44 && K(e, "expected the node content, but found ','") : K(e, "missed comma between flow collection entries"), x = m = y = null, u = f = !1, b === 63 && (c = e.input.charCodeAt(e.position + 1), Yt(c) && (u = f = !0, e.position++, vt(e, !0, t))), i = e.line, n = e.lineStart, a = e.position, pr(e, t, Qn, !1, !0), x = e.tag, m = e.result, vt(e, !0, t), b = e.input.charCodeAt(e.position), (f || e.line === i) && b === 58 && (u = !0, b = e.input.charCodeAt(++e.position), vt(e, !0, t), pr(e, t, Qn, !1, !0), y = e.result), p ? sr(e, s, g, x, m, y, i, n, a) : u ? s.push(sr(e, null, g, x, m, y, i, n, a)) : s.push(m), vt(e, !0, t), b = e.input.charCodeAt(e.position), b === 44 ? (r = !0, b = e.input.charCodeAt(++e.position)) : r = !1;
  }
  K(e, "unexpected end of the stream within a flow collection");
}
d(qf, "readFlowCollection");
function Hf(e, t) {
  var r, i, n = ls, a = !1, o = !1, s = t, l = 0, c = !1, h, u;
  if (u = e.input.charCodeAt(e.position), u === 124)
    i = !1;
  else if (u === 62)
    i = !0;
  else
    return !1;
  for (e.kind = "scalar", e.result = ""; u !== 0; )
    if (u = e.input.charCodeAt(++e.position), u === 43 || u === 45)
      ls === n ? n = u === 43 ? vc : M2 : K(e, "repeat of a chomping mode identifier");
    else if ((h = Df(u)) >= 0)
      h === 0 ? K(e, "bad explicit indentation width of a block scalar; it cannot be less than one") : o ? K(e, "repeat of an indentation width identifier") : (s = t + h - 1, o = !0);
    else
      break;
  if (je(u)) {
    do
      u = e.input.charCodeAt(++e.position);
    while (je(u));
    if (u === 35)
      do
        u = e.input.charCodeAt(++e.position);
      while (!fe(u) && u !== 0);
  }
  for (; u !== 0; ) {
    for (Ba(e), e.lineIndent = 0, u = e.input.charCodeAt(e.position); (!o || e.lineIndent < s) && u === 32; )
      e.lineIndent++, u = e.input.charCodeAt(++e.position);
    if (!o && e.lineIndent > s && (s = e.lineIndent), fe(u)) {
      l++;
      continue;
    }
    if (e.lineIndent < s) {
      n === vc ? e.result += Lt.repeat(`
`, a ? 1 + l : l) : n === ls && a && (e.result += `
`);
      break;
    }
    for (i ? je(u) ? (c = !0, e.result += Lt.repeat(`
`, a ? 1 + l : l)) : c ? (c = !1, e.result += Lt.repeat(`
`, l + 1)) : l === 0 ? a && (e.result += " ") : e.result += Lt.repeat(`
`, l) : e.result += Lt.repeat(`
`, a ? 1 + l : l), a = !0, o = !0, l = 0, r = e.position; !fe(u) && u !== 0; )
      u = e.input.charCodeAt(++e.position);
    Ie(e, r, e.position, !1);
  }
  return !0;
}
d(Hf, "readBlockScalar");
function Ws(e, t) {
  var r, i = e.tag, n = e.anchor, a = [], o, s = !1, l;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = a), l = e.input.charCodeAt(e.position); l !== 0 && (e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, K(e, "tab characters must not be used in indentation")), !(l !== 45 || (o = e.input.charCodeAt(e.position + 1), !Yt(o)))); ) {
    if (s = !0, e.position++, vt(e, !0, -1) && e.lineIndent <= t) {
      a.push(null), l = e.input.charCodeAt(e.position);
      continue;
    }
    if (r = e.line, pr(e, t, Af, !1, !0), a.push(e.result), vt(e, !0, -1), l = e.input.charCodeAt(e.position), (e.line === r || e.lineIndent > t) && l !== 0)
      K(e, "bad indentation of a sequence entry");
    else if (e.lineIndent < t)
      break;
  }
  return s ? (e.tag = i, e.anchor = n, e.kind = "sequence", e.result = a, !0) : !1;
}
d(Ws, "readBlockSequence");
function jf(e, t, r) {
  var i, n, a, o, s, l, c = e.tag, h = e.anchor, u = {}, f = /* @__PURE__ */ Object.create(null), p = null, g = null, m = null, x = !1, y = !1, b;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = u), b = e.input.charCodeAt(e.position); b !== 0; ) {
    if (!x && e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, K(e, "tab characters must not be used in indentation")), i = e.input.charCodeAt(e.position + 1), a = e.line, (b === 63 || b === 58) && Yt(i))
      b === 63 ? (x && (sr(e, u, f, p, g, null, o, s, l), p = g = m = null), y = !0, x = !0, n = !0) : x ? (x = !1, n = !0) : K(e, "incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"), e.position += 1, b = i;
    else {
      if (o = e.line, s = e.lineStart, l = e.position, !pr(e, r, Lf, !1, !0))
        break;
      if (e.line === a) {
        for (b = e.input.charCodeAt(e.position); je(b); )
          b = e.input.charCodeAt(++e.position);
        if (b === 58)
          b = e.input.charCodeAt(++e.position), Yt(b) || K(e, "a whitespace character is expected after the key-value separator within a block mapping"), x && (sr(e, u, f, p, g, null, o, s, l), p = g = m = null), y = !0, x = !1, n = !1, p = e.tag, g = e.result;
        else if (y)
          K(e, "can not read an implicit mapping pair; a colon is missed");
        else
          return e.tag = c, e.anchor = h, !0;
      } else if (y)
        K(e, "can not read a block mapping entry; a multiline key may not be an implicit key");
      else
        return e.tag = c, e.anchor = h, !0;
    }
    if ((e.line === a || e.lineIndent > t) && (x && (o = e.line, s = e.lineStart, l = e.position), pr(e, t, Jn, !0, n) && (x ? g = e.result : m = e.result), x || (sr(e, u, f, p, g, m, o, s, l), p = g = m = null), vt(e, !0, -1), b = e.input.charCodeAt(e.position)), (e.line === a || e.lineIndent > t) && b !== 0)
      K(e, "bad indentation of a mapping entry");
    else if (e.lineIndent < t)
      break;
  }
  return x && sr(e, u, f, p, g, null, o, s, l), y && (e.tag = c, e.anchor = h, e.kind = "mapping", e.result = u), y;
}
d(jf, "readBlockMapping");
function Yf(e) {
  var t, r = !1, i = !1, n, a, o;
  if (o = e.input.charCodeAt(e.position), o !== 33) return !1;
  if (e.tag !== null && K(e, "duplication of a tag property"), o = e.input.charCodeAt(++e.position), o === 60 ? (r = !0, o = e.input.charCodeAt(++e.position)) : o === 33 ? (i = !0, n = "!!", o = e.input.charCodeAt(++e.position)) : n = "!", t = e.position, r) {
    do
      o = e.input.charCodeAt(++e.position);
    while (o !== 0 && o !== 62);
    e.position < e.length ? (a = e.input.slice(t, e.position), o = e.input.charCodeAt(++e.position)) : K(e, "unexpected end of the stream within a verbatim tag");
  } else {
    for (; o !== 0 && !Yt(o); )
      o === 33 && (i ? K(e, "tag suffix cannot contain exclamation marks") : (n = e.input.slice(t - 1, e.position + 1), Mf.test(n) || K(e, "named tag handle cannot contain such characters"), i = !0, t = e.position + 1)), o = e.input.charCodeAt(++e.position);
    a = e.input.slice(t, e.position), F2.test(a) && K(e, "tag suffix cannot contain flow indicator characters");
  }
  a && !Ef.test(a) && K(e, "tag name cannot contain such characters: " + a);
  try {
    a = decodeURIComponent(a);
  } catch {
    K(e, "tag name is malformed: " + a);
  }
  return r ? e.tag = a : Ue.call(e.tagMap, n) ? e.tag = e.tagMap[n] + a : n === "!" ? e.tag = "!" + a : n === "!!" ? e.tag = "tag:yaml.org,2002:" + a : K(e, 'undeclared tag handle "' + n + '"'), !0;
}
d(Yf, "readTagProperty");
function Uf(e) {
  var t, r;
  if (r = e.input.charCodeAt(e.position), r !== 38) return !1;
  for (e.anchor !== null && K(e, "duplication of an anchor property"), r = e.input.charCodeAt(++e.position), t = e.position; r !== 0 && !Yt(r) && !ar(r); )
    r = e.input.charCodeAt(++e.position);
  return e.position === t && K(e, "name of an anchor node must contain at least one character"), e.anchor = e.input.slice(t, e.position), !0;
}
d(Uf, "readAnchorProperty");
function Gf(e) {
  var t, r, i;
  if (i = e.input.charCodeAt(e.position), i !== 42) return !1;
  for (i = e.input.charCodeAt(++e.position), t = e.position; i !== 0 && !Yt(i) && !ar(i); )
    i = e.input.charCodeAt(++e.position);
  return e.position === t && K(e, "name of an alias node must contain at least one character"), r = e.input.slice(t, e.position), Ue.call(e.anchorMap, r) || K(e, 'unidentified alias "' + r + '"'), e.result = e.anchorMap[r], vt(e, !0, -1), !0;
}
d(Gf, "readAlias");
function pr(e, t, r, i, n) {
  var a, o, s, l = 1, c = !1, h = !1, u, f, p, g, m, x;
  if (e.listener !== null && e.listener("open", e), e.tag = null, e.anchor = null, e.kind = null, e.result = null, a = o = s = Jn === r || Af === r, i && vt(e, !0, -1) && (c = !0, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)), l === 1)
    for (; Yf(e) || Uf(e); )
      vt(e, !0, -1) ? (c = !0, s = a, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)) : s = !1;
  if (s && (s = c || n), (l === 1 || Jn === r) && (Qn === r || Lf === r ? m = t : m = t + 1, x = e.position - e.lineStart, l === 1 ? s && (Ws(e, x) || jf(e, x, m)) || qf(e, m) ? h = !0 : (o && Hf(e, m) || zf(e, m) || Wf(e, m) ? h = !0 : Gf(e) ? (h = !0, (e.tag !== null || e.anchor !== null) && K(e, "alias node should not have any properties")) : Nf(e, m, Qn === r) && (h = !0, e.tag === null && (e.tag = "?")), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : l === 0 && (h = s && Ws(e, x))), e.tag === null)
    e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
  else if (e.tag === "?") {
    for (e.result !== null && e.kind !== "scalar" && K(e, 'unacceptable node kind for !<?> tag; it should be "scalar", not "' + e.kind + '"'), u = 0, f = e.implicitTypes.length; u < f; u += 1)
      if (g = e.implicitTypes[u], g.resolve(e.result)) {
        e.result = g.construct(e.result), e.tag = g.tag, e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
        break;
      }
  } else if (e.tag !== "!") {
    if (Ue.call(e.typeMap[e.kind || "fallback"], e.tag))
      g = e.typeMap[e.kind || "fallback"][e.tag];
    else
      for (g = null, p = e.typeMap.multi[e.kind || "fallback"], u = 0, f = p.length; u < f; u += 1)
        if (e.tag.slice(0, p[u].tag.length) === p[u].tag) {
          g = p[u];
          break;
        }
    g || K(e, "unknown tag !<" + e.tag + ">"), e.result !== null && g.kind !== e.kind && K(e, "unacceptable node kind for !<" + e.tag + '> tag; it should be "' + g.kind + '", not "' + e.kind + '"'), g.resolve(e.result, e.tag) ? (e.result = g.construct(e.result, e.tag), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : K(e, "cannot resolve a node with !<" + e.tag + "> explicit tag");
  }
  return e.listener !== null && e.listener("close", e), e.tag !== null || e.anchor !== null || h;
}
d(pr, "composeNode");
function Xf(e) {
  var t = e.position, r, i, n, a = !1, o;
  for (e.version = null, e.checkLineBreaks = e.legacy, e.tagMap = /* @__PURE__ */ Object.create(null), e.anchorMap = /* @__PURE__ */ Object.create(null); (o = e.input.charCodeAt(e.position)) !== 0 && (vt(e, !0, -1), o = e.input.charCodeAt(e.position), !(e.lineIndent > 0 || o !== 37)); ) {
    for (a = !0, o = e.input.charCodeAt(++e.position), r = e.position; o !== 0 && !Yt(o); )
      o = e.input.charCodeAt(++e.position);
    for (i = e.input.slice(r, e.position), n = [], i.length < 1 && K(e, "directive name must not be less than one character in length"); o !== 0; ) {
      for (; je(o); )
        o = e.input.charCodeAt(++e.position);
      if (o === 35) {
        do
          o = e.input.charCodeAt(++e.position);
        while (o !== 0 && !fe(o));
        break;
      }
      if (fe(o)) break;
      for (r = e.position; o !== 0 && !Yt(o); )
        o = e.input.charCodeAt(++e.position);
      n.push(e.input.slice(r, e.position));
    }
    o !== 0 && Ba(e), Ue.call(kc, i) ? kc[i](e, i, n) : Pi(e, 'unknown document directive "' + i + '"');
  }
  if (vt(e, !0, -1), e.lineIndent === 0 && e.input.charCodeAt(e.position) === 45 && e.input.charCodeAt(e.position + 1) === 45 && e.input.charCodeAt(e.position + 2) === 45 ? (e.position += 3, vt(e, !0, -1)) : a && K(e, "directives end mark is expected"), pr(e, e.lineIndent - 1, Jn, !1, !0), vt(e, !0, -1), e.checkLineBreaks && $2.test(e.input.slice(t, e.position)) && Pi(e, "non-ASCII line breaks are interpreted as content"), e.documents.push(e.result), e.position === e.lineStart && Ki(e)) {
    e.input.charCodeAt(e.position) === 46 && (e.position += 3, vt(e, !0, -1));
    return;
  }
  if (e.position < e.length - 1)
    K(e, "end of the stream or a document separator is expected");
  else
    return;
}
d(Xf, "readDocument");
function Ho(e, t) {
  e = String(e), t = t || {}, e.length !== 0 && (e.charCodeAt(e.length - 1) !== 10 && e.charCodeAt(e.length - 1) !== 13 && (e += `
`), e.charCodeAt(0) === 65279 && (e = e.slice(1)));
  var r = new Pf(e, t), i = e.indexOf("\0");
  for (i !== -1 && (r.position = i, K(r, "null byte is not allowed in input")), r.input += "\0"; r.input.charCodeAt(r.position) === 32; )
    r.lineIndent += 1, r.position += 1;
  for (; r.position < r.length - 1; )
    Xf(r);
  return r.documents;
}
d(Ho, "loadDocuments");
function D2(e, t, r) {
  t !== null && typeof t == "object" && typeof r > "u" && (r = t, t = null);
  var i = Ho(e, r);
  if (typeof t != "function")
    return i;
  for (var n = 0, a = i.length; n < a; n += 1)
    t(i[n]);
}
d(D2, "loadAll$1");
function Vf(e, t) {
  var r = Ho(e, t);
  if (r.length !== 0) {
    if (r.length === 1)
      return r[0];
    throw new Qt("expected a single document in the stream, but found more");
  }
}
d(Vf, "load$1");
var O2 = Vf, R2 = {
  load: O2
}, Zf = Object.prototype.toString, Kf = Object.prototype.hasOwnProperty, jo = 65279, I2 = 9, Ni = 10, P2 = 13, N2 = 32, z2 = 33, W2 = 34, qs = 35, q2 = 37, H2 = 38, j2 = 39, Y2 = 42, Qf = 44, U2 = 45, ta = 58, G2 = 61, X2 = 62, V2 = 63, Z2 = 64, Jf = 91, tp = 93, K2 = 96, ep = 123, Q2 = 124, rp = 125, Wt = {};
Wt[0] = "\\0";
Wt[7] = "\\a";
Wt[8] = "\\b";
Wt[9] = "\\t";
Wt[10] = "\\n";
Wt[11] = "\\v";
Wt[12] = "\\f";
Wt[13] = "\\r";
Wt[27] = "\\e";
Wt[34] = '\\"';
Wt[92] = "\\\\";
Wt[133] = "\\N";
Wt[160] = "\\_";
Wt[8232] = "\\L";
Wt[8233] = "\\P";
var J2 = [
  "y",
  "Y",
  "yes",
  "Yes",
  "YES",
  "on",
  "On",
  "ON",
  "n",
  "N",
  "no",
  "No",
  "NO",
  "off",
  "Off",
  "OFF"
], tC = /^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;
function ip(e, t) {
  var r, i, n, a, o, s, l;
  if (t === null) return {};
  for (r = {}, i = Object.keys(t), n = 0, a = i.length; n < a; n += 1)
    o = i[n], s = String(t[o]), o.slice(0, 2) === "!!" && (o = "tag:yaml.org,2002:" + o.slice(2)), l = e.compiledTypeMap.fallback[o], l && Kf.call(l.styleAliases, s) && (s = l.styleAliases[s]), r[o] = s;
  return r;
}
d(ip, "compileStyleMap");
function np(e) {
  var t, r, i;
  if (t = e.toString(16).toUpperCase(), e <= 255)
    r = "x", i = 2;
  else if (e <= 65535)
    r = "u", i = 4;
  else if (e <= 4294967295)
    r = "U", i = 8;
  else
    throw new Qt("code point within a string may not be greater than 0xFFFFFFFF");
  return "\\" + r + Lt.repeat("0", i - t.length) + t;
}
d(np, "encodeHex");
var eC = 1, zi = 2;
function ap(e) {
  this.schema = e.schema || Bf, this.indent = Math.max(1, e.indent || 2), this.noArrayIndent = e.noArrayIndent || !1, this.skipInvalid = e.skipInvalid || !1, this.flowLevel = Lt.isNothing(e.flowLevel) ? -1 : e.flowLevel, this.styleMap = ip(this.schema, e.styles || null), this.sortKeys = e.sortKeys || !1, this.lineWidth = e.lineWidth || 80, this.noRefs = e.noRefs || !1, this.noCompatMode = e.noCompatMode || !1, this.condenseFlow = e.condenseFlow || !1, this.quotingType = e.quotingType === '"' ? zi : eC, this.forceQuotes = e.forceQuotes || !1, this.replacer = typeof e.replacer == "function" ? e.replacer : null, this.implicitTypes = this.schema.compiledImplicit, this.explicitTypes = this.schema.compiledExplicit, this.tag = null, this.result = "", this.duplicates = [], this.usedDuplicates = null;
}
d(ap, "State");
function Hs(e, t) {
  for (var r = Lt.repeat(" ", t), i = 0, n = -1, a = "", o, s = e.length; i < s; )
    n = e.indexOf(`
`, i), n === -1 ? (o = e.slice(i), i = s) : (o = e.slice(i, n + 1), i = n + 1), o.length && o !== `
` && (a += r), a += o;
  return a;
}
d(Hs, "indentString");
function ea(e, t) {
  return `
` + Lt.repeat(" ", e.indent * t);
}
d(ea, "generateNextLine");
function sp(e, t) {
  var r, i, n;
  for (r = 0, i = e.implicitTypes.length; r < i; r += 1)
    if (n = e.implicitTypes[r], n.resolve(t))
      return !0;
  return !1;
}
d(sp, "testImplicitResolving");
function Wi(e) {
  return e === N2 || e === I2;
}
d(Wi, "isWhitespace");
function Zr(e) {
  return 32 <= e && e <= 126 || 161 <= e && e <= 55295 && e !== 8232 && e !== 8233 || 57344 <= e && e <= 65533 && e !== jo || 65536 <= e && e <= 1114111;
}
d(Zr, "isPrintable");
function js(e) {
  return Zr(e) && e !== jo && e !== P2 && e !== Ni;
}
d(js, "isNsCharOrWhitespace");
function Ys(e, t, r) {
  var i = js(e), n = i && !Wi(e);
  return (
    // ns-plain-safe
    (r ? (
      // c = flow-in
      i
    ) : i && e !== Qf && e !== Jf && e !== tp && e !== ep && e !== rp) && e !== qs && !(t === ta && !n) || js(t) && !Wi(t) && e === qs || t === ta && n
  );
}
d(Ys, "isPlainSafe");
function op(e) {
  return Zr(e) && e !== jo && !Wi(e) && e !== U2 && e !== V2 && e !== ta && e !== Qf && e !== Jf && e !== tp && e !== ep && e !== rp && e !== qs && e !== H2 && e !== Y2 && e !== z2 && e !== Q2 && e !== G2 && e !== X2 && e !== j2 && e !== W2 && e !== q2 && e !== Z2 && e !== K2;
}
d(op, "isPlainSafeFirst");
function lp(e) {
  return !Wi(e) && e !== ta;
}
d(lp, "isPlainSafeLast");
function $r(e, t) {
  var r = e.charCodeAt(t), i;
  return r >= 55296 && r <= 56319 && t + 1 < e.length && (i = e.charCodeAt(t + 1), i >= 56320 && i <= 57343) ? (r - 55296) * 1024 + i - 56320 + 65536 : r;
}
d($r, "codePointAt");
function Yo(e) {
  var t = /^\n* /;
  return t.test(e);
}
d(Yo, "needIndentIndicator");
var cp = 1, Us = 2, hp = 3, up = 4, Mr = 5;
function fp(e, t, r, i, n, a, o, s) {
  var l, c = 0, h = null, u = !1, f = !1, p = i !== -1, g = -1, m = op($r(e, 0)) && lp($r(e, e.length - 1));
  if (t || o)
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = $r(e, l), !Zr(c))
        return Mr;
      m = m && Ys(c, h, s), h = c;
    }
  else {
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = $r(e, l), c === Ni)
        u = !0, p && (f = f || // Foldable line = too long, and not more-indented.
        l - g - 1 > i && e[g + 1] !== " ", g = l);
      else if (!Zr(c))
        return Mr;
      m = m && Ys(c, h, s), h = c;
    }
    f = f || p && l - g - 1 > i && e[g + 1] !== " ";
  }
  return !u && !f ? m && !o && !n(e) ? cp : a === zi ? Mr : Us : r > 9 && Yo(e) ? Mr : o ? a === zi ? Mr : Us : f ? up : hp;
}
d(fp, "chooseScalarStyle");
function pp(e, t, r, i, n) {
  e.dump = function() {
    if (t.length === 0)
      return e.quotingType === zi ? '""' : "''";
    if (!e.noCompatMode && (J2.indexOf(t) !== -1 || tC.test(t)))
      return e.quotingType === zi ? '"' + t + '"' : "'" + t + "'";
    var a = e.indent * Math.max(1, r), o = e.lineWidth === -1 ? -1 : Math.max(Math.min(e.lineWidth, 40), e.lineWidth - a), s = i || e.flowLevel > -1 && r >= e.flowLevel;
    function l(c) {
      return sp(e, c);
    }
    switch (d(l, "testAmbiguity"), fp(
      t,
      s,
      e.indent,
      o,
      l,
      e.quotingType,
      e.forceQuotes && !i,
      n
    )) {
      case cp:
        return t;
      case Us:
        return "'" + t.replace(/'/g, "''") + "'";
      case hp:
        return "|" + Gs(t, e.indent) + Xs(Hs(t, a));
      case up:
        return ">" + Gs(t, e.indent) + Xs(Hs(dp(t, o), a));
      case Mr:
        return '"' + gp(t) + '"';
      default:
        throw new Qt("impossible error: invalid scalar style");
    }
  }();
}
d(pp, "writeScalar");
function Gs(e, t) {
  var r = Yo(e) ? String(t) : "", i = e[e.length - 1] === `
`, n = i && (e[e.length - 2] === `
` || e === `
`), a = n ? "+" : i ? "" : "-";
  return r + a + `
`;
}
d(Gs, "blockHeader");
function Xs(e) {
  return e[e.length - 1] === `
` ? e.slice(0, -1) : e;
}
d(Xs, "dropEndingNewline");
function dp(e, t) {
  for (var r = /(\n+)([^\n]*)/g, i = function() {
    var c = e.indexOf(`
`);
    return c = c !== -1 ? c : e.length, r.lastIndex = c, Vs(e.slice(0, c), t);
  }(), n = e[0] === `
` || e[0] === " ", a, o; o = r.exec(e); ) {
    var s = o[1], l = o[2];
    a = l[0] === " ", i += s + (!n && !a && l !== "" ? `
` : "") + Vs(l, t), n = a;
  }
  return i;
}
d(dp, "foldString");
function Vs(e, t) {
  if (e === "" || e[0] === " ") return e;
  for (var r = / [^ ]/g, i, n = 0, a, o = 0, s = 0, l = ""; i = r.exec(e); )
    s = i.index, s - n > t && (a = o > n ? o : s, l += `
` + e.slice(n, a), n = a + 1), o = s;
  return l += `
`, e.length - n > t && o > n ? l += e.slice(n, o) + `
` + e.slice(o + 1) : l += e.slice(n), l.slice(1);
}
d(Vs, "foldLine");
function gp(e) {
  for (var t = "", r = 0, i, n = 0; n < e.length; r >= 65536 ? n += 2 : n++)
    r = $r(e, n), i = Wt[r], !i && Zr(r) ? (t += e[n], r >= 65536 && (t += e[n + 1])) : t += i || np(r);
  return t;
}
d(gp, "escapeString");
function mp(e, t, r) {
  var i = "", n = e.tag, a, o, s;
  for (a = 0, o = r.length; a < o; a += 1)
    s = r[a], e.replacer && (s = e.replacer.call(r, String(a), s)), (ve(e, t, s, !1, !1) || typeof s > "u" && ve(e, t, null, !1, !1)) && (i !== "" && (i += "," + (e.condenseFlow ? "" : " ")), i += e.dump);
  e.tag = n, e.dump = "[" + i + "]";
}
d(mp, "writeFlowSequence");
function Zs(e, t, r, i) {
  var n = "", a = e.tag, o, s, l;
  for (o = 0, s = r.length; o < s; o += 1)
    l = r[o], e.replacer && (l = e.replacer.call(r, String(o), l)), (ve(e, t + 1, l, !0, !0, !1, !0) || typeof l > "u" && ve(e, t + 1, null, !0, !0, !1, !0)) && ((!i || n !== "") && (n += ea(e, t)), e.dump && Ni === e.dump.charCodeAt(0) ? n += "-" : n += "- ", n += e.dump);
  e.tag = a, e.dump = n || "[]";
}
d(Zs, "writeBlockSequence");
function yp(e, t, r) {
  var i = "", n = e.tag, a = Object.keys(r), o, s, l, c, h;
  for (o = 0, s = a.length; o < s; o += 1)
    h = "", i !== "" && (h += ", "), e.condenseFlow && (h += '"'), l = a[o], c = r[l], e.replacer && (c = e.replacer.call(r, l, c)), ve(e, t, l, !1, !1) && (e.dump.length > 1024 && (h += "? "), h += e.dump + (e.condenseFlow ? '"' : "") + ":" + (e.condenseFlow ? "" : " "), ve(e, t, c, !1, !1) && (h += e.dump, i += h));
  e.tag = n, e.dump = "{" + i + "}";
}
d(yp, "writeFlowMapping");
function xp(e, t, r, i) {
  var n = "", a = e.tag, o = Object.keys(r), s, l, c, h, u, f;
  if (e.sortKeys === !0)
    o.sort();
  else if (typeof e.sortKeys == "function")
    o.sort(e.sortKeys);
  else if (e.sortKeys)
    throw new Qt("sortKeys must be a boolean or a function");
  for (s = 0, l = o.length; s < l; s += 1)
    f = "", (!i || n !== "") && (f += ea(e, t)), c = o[s], h = r[c], e.replacer && (h = e.replacer.call(r, c, h)), ve(e, t + 1, c, !0, !0, !0) && (u = e.tag !== null && e.tag !== "?" || e.dump && e.dump.length > 1024, u && (e.dump && Ni === e.dump.charCodeAt(0) ? f += "?" : f += "? "), f += e.dump, u && (f += ea(e, t)), ve(e, t + 1, h, !0, u) && (e.dump && Ni === e.dump.charCodeAt(0) ? f += ":" : f += ": ", f += e.dump, n += f));
  e.tag = a, e.dump = n || "{}";
}
d(xp, "writeBlockMapping");
function Ks(e, t, r) {
  var i, n, a, o, s, l;
  for (n = r ? e.explicitTypes : e.implicitTypes, a = 0, o = n.length; a < o; a += 1)
    if (s = n[a], (s.instanceOf || s.predicate) && (!s.instanceOf || typeof t == "object" && t instanceof s.instanceOf) && (!s.predicate || s.predicate(t))) {
      if (r ? s.multi && s.representName ? e.tag = s.representName(t) : e.tag = s.tag : e.tag = "?", s.represent) {
        if (l = e.styleMap[s.tag] || s.defaultStyle, Zf.call(s.represent) === "[object Function]")
          i = s.represent(t, l);
        else if (Kf.call(s.represent, l))
          i = s.represent[l](t, l);
        else
          throw new Qt("!<" + s.tag + '> tag resolver accepts not "' + l + '" style');
        e.dump = i;
      }
      return !0;
    }
  return !1;
}
d(Ks, "detectType");
function ve(e, t, r, i, n, a, o) {
  e.tag = null, e.dump = r, Ks(e, r, !1) || Ks(e, r, !0);
  var s = Zf.call(e.dump), l = i, c;
  i && (i = e.flowLevel < 0 || e.flowLevel > t);
  var h = s === "[object Object]" || s === "[object Array]", u, f;
  if (h && (u = e.duplicates.indexOf(r), f = u !== -1), (e.tag !== null && e.tag !== "?" || f || e.indent !== 2 && t > 0) && (n = !1), f && e.usedDuplicates[u])
    e.dump = "*ref_" + u;
  else {
    if (h && f && !e.usedDuplicates[u] && (e.usedDuplicates[u] = !0), s === "[object Object]")
      i && Object.keys(e.dump).length !== 0 ? (xp(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (yp(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object Array]")
      i && e.dump.length !== 0 ? (e.noArrayIndent && !o && t > 0 ? Zs(e, t - 1, e.dump, n) : Zs(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (mp(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object String]")
      e.tag !== "?" && pp(e, e.dump, t, a, l);
    else {
      if (s === "[object Undefined]")
        return !1;
      if (e.skipInvalid) return !1;
      throw new Qt("unacceptable kind of an object to dump " + s);
    }
    e.tag !== null && e.tag !== "?" && (c = encodeURI(
      e.tag[0] === "!" ? e.tag.slice(1) : e.tag
    ).replace(/!/g, "%21"), e.tag[0] === "!" ? c = "!" + c : c.slice(0, 18) === "tag:yaml.org,2002:" ? c = "!!" + c.slice(18) : c = "!<" + c + ">", e.dump = c + " " + e.dump);
  }
  return !0;
}
d(ve, "writeNode");
function bp(e, t) {
  var r = [], i = [], n, a;
  for (ra(e, r, i), n = 0, a = i.length; n < a; n += 1)
    t.duplicates.push(r[i[n]]);
  t.usedDuplicates = new Array(a);
}
d(bp, "getDuplicateReferences");
function ra(e, t, r) {
  var i, n, a;
  if (e !== null && typeof e == "object")
    if (n = t.indexOf(e), n !== -1)
      r.indexOf(n) === -1 && r.push(n);
    else if (t.push(e), Array.isArray(e))
      for (n = 0, a = e.length; n < a; n += 1)
        ra(e[n], t, r);
    else
      for (i = Object.keys(e), n = 0, a = i.length; n < a; n += 1)
        ra(e[i[n]], t, r);
}
d(ra, "inspectNode");
function rC(e, t) {
  t = t || {};
  var r = new ap(t);
  r.noRefs || bp(e, r);
  var i = e;
  return r.replacer && (i = r.replacer.call({ "": i }, "", i)), ve(r, 0, i, !0, !0) ? r.dump + `
` : "";
}
d(rC, "dump$1");
function iC(e, t) {
  return function() {
    throw new Error("Function yaml." + e + " is removed in js-yaml 4. Use yaml." + t + " instead, which is now safe by default.");
  };
}
d(iC, "renamed");
var nC = hf, aC = R2.load;
/*! Bundled license information:

js-yaml/dist/js-yaml.mjs:
  (*! js-yaml 4.1.0 https://github.com/nodeca/js-yaml @license MIT *)
*/
var ne = {
  aggregation: 18,
  extension: 18,
  composition: 18,
  dependency: 6,
  lollipop: 13.5,
  arrow_point: 4
};
function ki(e, t) {
  if (e === void 0 || t === void 0)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  e = Ct(e), t = Ct(t);
  const [r, i] = [e.x, e.y], [n, a] = [t.x, t.y], o = n - r, s = a - i;
  return { angle: Math.atan(s / o), deltaX: o, deltaY: s };
}
d(ki, "calculateDeltaAndAngle");
var Ct = /* @__PURE__ */ d((e) => Array.isArray(e) ? { x: e[0], y: e[1] } : e, "pointTransformer"), sC = /* @__PURE__ */ d((e) => ({
  x: /* @__PURE__ */ d(function(t, r, i) {
    let n = 0;
    const a = Ct(i[0]).x < Ct(i[i.length - 1]).x ? "left" : "right";
    if (r === 0 && Object.hasOwn(ne, e.arrowTypeStart)) {
      const { angle: p, deltaX: g } = ki(i[0], i[1]);
      n = ne[e.arrowTypeStart] * Math.cos(p) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(ne, e.arrowTypeEnd)) {
      const { angle: p, deltaX: g } = ki(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = ne[e.arrowTypeEnd] * Math.cos(p) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      Ct(t).x - Ct(i[i.length - 1]).x
    ), s = Math.abs(
      Ct(t).y - Ct(i[i.length - 1]).y
    ), l = Math.abs(Ct(t).x - Ct(i[0]).x), c = Math.abs(Ct(t).y - Ct(i[0]).y), h = ne[e.arrowTypeStart], u = ne[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let p = u + f - o;
      p *= a === "right" ? -1 : 1, n -= p;
    }
    if (l < h && l > 0 && c < h) {
      let p = h + f - l;
      p *= a === "right" ? -1 : 1, n += p;
    }
    return Ct(t).x + n;
  }, "x"),
  y: /* @__PURE__ */ d(function(t, r, i) {
    let n = 0;
    const a = Ct(i[0]).y < Ct(i[i.length - 1]).y ? "down" : "up";
    if (r === 0 && Object.hasOwn(ne, e.arrowTypeStart)) {
      const { angle: p, deltaY: g } = ki(i[0], i[1]);
      n = ne[e.arrowTypeStart] * Math.abs(Math.sin(p)) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(ne, e.arrowTypeEnd)) {
      const { angle: p, deltaY: g } = ki(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = ne[e.arrowTypeEnd] * Math.abs(Math.sin(p)) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      Ct(t).y - Ct(i[i.length - 1]).y
    ), s = Math.abs(
      Ct(t).x - Ct(i[i.length - 1]).x
    ), l = Math.abs(Ct(t).y - Ct(i[0]).y), c = Math.abs(Ct(t).x - Ct(i[0]).x), h = ne[e.arrowTypeStart], u = ne[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let p = u + f - o;
      p *= a === "up" ? -1 : 1, n -= p;
    }
    if (l < h && l > 0 && c < h) {
      let p = h + f - l;
      p *= a === "up" ? -1 : 1, n += p;
    }
    return Ct(t).y + n;
  }, "y")
}), "getLineFunctionsWithOffset"), Uo = /* @__PURE__ */ d(({
  flowchart: e
}) => {
  var n, a;
  const t = ((n = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : n.top) ?? 0, r = ((a = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : a.bottom) ?? 0, i = t + r;
  return {
    subGraphTitleTopMargin: t,
    subGraphTitleBottomMargin: r,
    subGraphTitleTotalMargin: i
  };
}, "getSubGraphTitleMargins"), oC = /* @__PURE__ */ d((e) => {
  const { handDrawnSeed: t } = ut();
  return {
    fill: e,
    hachureAngle: 120,
    // angle of hachure,
    hachureGap: 4,
    fillWeight: 2,
    roughness: 0.7,
    stroke: e,
    seed: t
  };
}, "solidStateFill"), ti = /* @__PURE__ */ d((e) => {
  const t = lC([...e.cssCompiledStyles || [], ...e.cssStyles || []]);
  return { stylesMap: t, stylesArray: [...t] };
}, "compileStyles"), lC = /* @__PURE__ */ d((e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((r) => {
    const [i, n] = r.split(":");
    t.set(i.trim(), n == null ? void 0 : n.trim());
  }), t;
}, "styles2Map"), Cp = /* @__PURE__ */ d((e) => e === "color" || e === "font-size" || e === "font-family" || e === "font-weight" || e === "font-style" || e === "text-decoration" || e === "text-align" || e === "text-transform" || e === "line-height" || e === "letter-spacing" || e === "word-spacing" || e === "text-shadow" || e === "text-overflow" || e === "white-space" || e === "word-wrap" || e === "word-break" || e === "overflow-wrap" || e === "hyphens", "isLabelStyle"), G = /* @__PURE__ */ d((e) => {
  const { stylesArray: t } = ti(e), r = [], i = [], n = [], a = [];
  return t.forEach((o) => {
    const s = o[0];
    Cp(s) ? r.push(o.join(":") + " !important") : (i.push(o.join(":") + " !important"), s.includes("stroke") && n.push(o.join(":") + " !important"), s === "fill" && a.push(o.join(":") + " !important"));
  }), {
    labelStyles: r.join(";"),
    nodeStyles: i.join(";"),
    stylesArray: t,
    borderStyles: n,
    backgroundStyles: a
  };
}, "styles2String"), Y = /* @__PURE__ */ d((e, t) => {
  var l;
  const { themeVariables: r, handDrawnSeed: i } = ut(), { nodeBorder: n, mainBkg: a } = r, { stylesMap: o } = ti(e);
  return Object.assign(
    {
      roughness: 0.7,
      fill: o.get("fill") || a,
      fillStyle: "hachure",
      // solid fill
      fillWeight: 4,
      hachureGap: 5.2,
      stroke: o.get("stroke") || n,
      seed: i,
      strokeWidth: ((l = o.get("stroke-width")) == null ? void 0 : l.replace("px", "")) || 1.3,
      fillLineDash: [0, 0],
      strokeLineDash: cC(o.get("stroke-dasharray"))
    },
    t
  );
}, "userNodeOverrides"), cC = /* @__PURE__ */ d((e) => {
  if (!e)
    return [0, 0];
  const t = e.trim().split(/\s+/).map(Number);
  if (t.length === 1) {
    const n = isNaN(t[0]) ? 0 : t[0];
    return [n, n];
  }
  const r = isNaN(t[0]) ? 0 : t[0], i = isNaN(t[1]) ? 0 : t[1];
  return [r, i];
}, "getStrokeDashArray"), Go = {}, Et = {};
Object.defineProperty(Et, "__esModule", { value: !0 });
Et.BLANK_URL = Et.relativeFirstCharacters = Et.whitespaceEscapeCharsRegex = Et.urlSchemeRegex = Et.ctrlCharactersRegex = Et.htmlCtrlEntityRegex = Et.htmlEntitiesRegex = Et.invalidProtocolRegex = void 0;
Et.invalidProtocolRegex = /^([^\w]*)(javascript|data|vbscript)/im;
Et.htmlEntitiesRegex = /&#(\w+)(^\w|;)?/g;
Et.htmlCtrlEntityRegex = /&(newline|tab);/gi;
Et.ctrlCharactersRegex = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim;
Et.urlSchemeRegex = /^.+(:|&colon;)/gim;
Et.whitespaceEscapeCharsRegex = /(\\|%5[cC])((%(6[eE]|72|74))|[nrt])/g;
Et.relativeFirstCharacters = [".", "/"];
Et.BLANK_URL = "about:blank";
Object.defineProperty(Go, "__esModule", { value: !0 });
var _p = Go.sanitizeUrl = void 0, It = Et;
function hC(e) {
  return It.relativeFirstCharacters.indexOf(e[0]) > -1;
}
function uC(e) {
  var t = e.replace(It.ctrlCharactersRegex, "");
  return t.replace(It.htmlEntitiesRegex, function(r, i) {
    return String.fromCharCode(i);
  });
}
function fC(e) {
  return URL.canParse(e);
}
function Sc(e) {
  try {
    return decodeURIComponent(e);
  } catch {
    return e;
  }
}
function pC(e) {
  if (!e)
    return It.BLANK_URL;
  var t, r = Sc(e.trim());
  do
    r = uC(r).replace(It.htmlCtrlEntityRegex, "").replace(It.ctrlCharactersRegex, "").replace(It.whitespaceEscapeCharsRegex, "").trim(), r = Sc(r), t = r.match(It.ctrlCharactersRegex) || r.match(It.htmlEntitiesRegex) || r.match(It.htmlCtrlEntityRegex) || r.match(It.whitespaceEscapeCharsRegex);
  while (t && t.length > 0);
  var i = r;
  if (!i)
    return It.BLANK_URL;
  if (hC(i))
    return i;
  var n = i.trimStart(), a = n.match(It.urlSchemeRegex);
  if (!a)
    return i;
  var o = a[0].toLowerCase().trim();
  if (It.invalidProtocolRegex.test(o))
    return It.BLANK_URL;
  var s = n.replace(/\\/g, "/");
  if (o === "mailto:" || o.includes("://"))
    return s;
  if (o === "http:" || o === "https:") {
    if (!fC(s))
      return It.BLANK_URL;
    var l = new URL(s);
    return l.protocol = l.protocol.toLowerCase(), l.hostname = l.hostname.toLowerCase(), l.toString();
  }
  return s;
}
_p = Go.sanitizeUrl = pC;
var wp = typeof global == "object" && global && global.Object === Object && global, dC = typeof self == "object" && self && self.Object === Object && self, Se = wp || dC || Function("return this")(), ia = Se.Symbol, vp = Object.prototype, gC = vp.hasOwnProperty, mC = vp.toString, di = ia ? ia.toStringTag : void 0;
function yC(e) {
  var t = gC.call(e, di), r = e[di];
  try {
    e[di] = void 0;
    var i = !0;
  } catch {
  }
  var n = mC.call(e);
  return i && (t ? e[di] = r : delete e[di]), n;
}
var xC = Object.prototype, bC = xC.toString;
function CC(e) {
  return bC.call(e);
}
var _C = "[object Null]", wC = "[object Undefined]", Tc = ia ? ia.toStringTag : void 0;
function ei(e) {
  return e == null ? e === void 0 ? wC : _C : Tc && Tc in Object(e) ? yC(e) : CC(e);
}
function yr(e) {
  var t = typeof e;
  return e != null && (t == "object" || t == "function");
}
var vC = "[object AsyncFunction]", kC = "[object Function]", SC = "[object GeneratorFunction]", TC = "[object Proxy]";
function Xo(e) {
  if (!yr(e))
    return !1;
  var t = ei(e);
  return t == kC || t == SC || t == vC || t == TC;
}
var cs = Se["__core-js_shared__"], Bc = function() {
  var e = /[^.]+$/.exec(cs && cs.keys && cs.keys.IE_PROTO || "");
  return e ? "Symbol(src)_1." + e : "";
}();
function BC(e) {
  return !!Bc && Bc in e;
}
var LC = Function.prototype, AC = LC.toString;
function xr(e) {
  if (e != null) {
    try {
      return AC.call(e);
    } catch {
    }
    try {
      return e + "";
    } catch {
    }
  }
  return "";
}
var MC = /[\\^$.*+?()[\]{}|]/g, EC = /^\[object .+?Constructor\]$/, $C = Function.prototype, FC = Object.prototype, DC = $C.toString, OC = FC.hasOwnProperty, RC = RegExp(
  "^" + DC.call(OC).replace(MC, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function IC(e) {
  if (!yr(e) || BC(e))
    return !1;
  var t = Xo(e) ? RC : EC;
  return t.test(xr(e));
}
function PC(e, t) {
  return e == null ? void 0 : e[t];
}
function br(e, t) {
  var r = PC(e, t);
  return IC(r) ? r : void 0;
}
var qi = br(Object, "create");
function NC() {
  this.__data__ = qi ? qi(null) : {}, this.size = 0;
}
function zC(e) {
  var t = this.has(e) && delete this.__data__[e];
  return this.size -= t ? 1 : 0, t;
}
var WC = "__lodash_hash_undefined__", qC = Object.prototype, HC = qC.hasOwnProperty;
function jC(e) {
  var t = this.__data__;
  if (qi) {
    var r = t[e];
    return r === WC ? void 0 : r;
  }
  return HC.call(t, e) ? t[e] : void 0;
}
var YC = Object.prototype, UC = YC.hasOwnProperty;
function GC(e) {
  var t = this.__data__;
  return qi ? t[e] !== void 0 : UC.call(t, e);
}
var XC = "__lodash_hash_undefined__";
function VC(e, t) {
  var r = this.__data__;
  return this.size += this.has(e) ? 0 : 1, r[e] = qi && t === void 0 ? XC : t, this;
}
function dr(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
dr.prototype.clear = NC;
dr.prototype.delete = zC;
dr.prototype.get = jC;
dr.prototype.has = GC;
dr.prototype.set = VC;
function ZC() {
  this.__data__ = [], this.size = 0;
}
function Aa(e, t) {
  return e === t || e !== e && t !== t;
}
function Ma(e, t) {
  for (var r = e.length; r--; )
    if (Aa(e[r][0], t))
      return r;
  return -1;
}
var KC = Array.prototype, QC = KC.splice;
function JC(e) {
  var t = this.__data__, r = Ma(t, e);
  if (r < 0)
    return !1;
  var i = t.length - 1;
  return r == i ? t.pop() : QC.call(t, r, 1), --this.size, !0;
}
function t_(e) {
  var t = this.__data__, r = Ma(t, e);
  return r < 0 ? void 0 : t[r][1];
}
function e_(e) {
  return Ma(this.__data__, e) > -1;
}
function r_(e, t) {
  var r = this.__data__, i = Ma(r, e);
  return i < 0 ? (++this.size, r.push([e, t])) : r[i][1] = t, this;
}
function ze(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
ze.prototype.clear = ZC;
ze.prototype.delete = JC;
ze.prototype.get = t_;
ze.prototype.has = e_;
ze.prototype.set = r_;
var Hi = br(Se, "Map");
function i_() {
  this.size = 0, this.__data__ = {
    hash: new dr(),
    map: new (Hi || ze)(),
    string: new dr()
  };
}
function n_(e) {
  var t = typeof e;
  return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null;
}
function Ea(e, t) {
  var r = e.__data__;
  return n_(t) ? r[typeof t == "string" ? "string" : "hash"] : r.map;
}
function a_(e) {
  var t = Ea(this, e).delete(e);
  return this.size -= t ? 1 : 0, t;
}
function s_(e) {
  return Ea(this, e).get(e);
}
function o_(e) {
  return Ea(this, e).has(e);
}
function l_(e, t) {
  var r = Ea(this, e), i = r.size;
  return r.set(e, t), this.size += r.size == i ? 0 : 1, this;
}
function Ve(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Ve.prototype.clear = i_;
Ve.prototype.delete = a_;
Ve.prototype.get = s_;
Ve.prototype.has = o_;
Ve.prototype.set = l_;
var c_ = "Expected a function";
function Qi(e, t) {
  if (typeof e != "function" || t != null && typeof t != "function")
    throw new TypeError(c_);
  var r = function() {
    var i = arguments, n = t ? t.apply(this, i) : i[0], a = r.cache;
    if (a.has(n))
      return a.get(n);
    var o = e.apply(this, i);
    return r.cache = a.set(n, o) || a, o;
  };
  return r.cache = new (Qi.Cache || Ve)(), r;
}
Qi.Cache = Ve;
function h_() {
  this.__data__ = new ze(), this.size = 0;
}
function u_(e) {
  var t = this.__data__, r = t.delete(e);
  return this.size = t.size, r;
}
function f_(e) {
  return this.__data__.get(e);
}
function p_(e) {
  return this.__data__.has(e);
}
var d_ = 200;
function g_(e, t) {
  var r = this.__data__;
  if (r instanceof ze) {
    var i = r.__data__;
    if (!Hi || i.length < d_ - 1)
      return i.push([e, t]), this.size = ++r.size, this;
    r = this.__data__ = new Ve(i);
  }
  return r.set(e, t), this.size = r.size, this;
}
function ri(e) {
  var t = this.__data__ = new ze(e);
  this.size = t.size;
}
ri.prototype.clear = h_;
ri.prototype.delete = u_;
ri.prototype.get = f_;
ri.prototype.has = p_;
ri.prototype.set = g_;
var na = function() {
  try {
    var e = br(Object, "defineProperty");
    return e({}, "", {}), e;
  } catch {
  }
}();
function Vo(e, t, r) {
  t == "__proto__" && na ? na(e, t, {
    configurable: !0,
    enumerable: !0,
    value: r,
    writable: !0
  }) : e[t] = r;
}
function Qs(e, t, r) {
  (r !== void 0 && !Aa(e[t], r) || r === void 0 && !(t in e)) && Vo(e, t, r);
}
function m_(e) {
  return function(t, r, i) {
    for (var n = -1, a = Object(t), o = i(t), s = o.length; s--; ) {
      var l = o[++n];
      if (r(a[l], l, a) === !1)
        break;
    }
    return t;
  };
}
var y_ = m_(), kp = typeof exports == "object" && exports && !exports.nodeType && exports, Lc = kp && typeof module == "object" && module && !module.nodeType && module, x_ = Lc && Lc.exports === kp, Ac = x_ ? Se.Buffer : void 0, Mc = Ac ? Ac.allocUnsafe : void 0;
function b_(e, t) {
  if (t)
    return e.slice();
  var r = e.length, i = Mc ? Mc(r) : new e.constructor(r);
  return e.copy(i), i;
}
var Ec = Se.Uint8Array;
function C_(e) {
  var t = new e.constructor(e.byteLength);
  return new Ec(t).set(new Ec(e)), t;
}
function __(e, t) {
  var r = t ? C_(e.buffer) : e.buffer;
  return new e.constructor(r, e.byteOffset, e.length);
}
function w_(e, t) {
  var r = -1, i = e.length;
  for (t || (t = Array(i)); ++r < i; )
    t[r] = e[r];
  return t;
}
var $c = Object.create, v_ = /* @__PURE__ */ function() {
  function e() {
  }
  return function(t) {
    if (!yr(t))
      return {};
    if ($c)
      return $c(t);
    e.prototype = t;
    var r = new e();
    return e.prototype = void 0, r;
  };
}();
function Sp(e, t) {
  return function(r) {
    return e(t(r));
  };
}
var Tp = Sp(Object.getPrototypeOf, Object), k_ = Object.prototype;
function $a(e) {
  var t = e && e.constructor, r = typeof t == "function" && t.prototype || k_;
  return e === r;
}
function S_(e) {
  return typeof e.constructor == "function" && !$a(e) ? v_(Tp(e)) : {};
}
function Ji(e) {
  return e != null && typeof e == "object";
}
var T_ = "[object Arguments]";
function Fc(e) {
  return Ji(e) && ei(e) == T_;
}
var Bp = Object.prototype, B_ = Bp.hasOwnProperty, L_ = Bp.propertyIsEnumerable, aa = Fc(/* @__PURE__ */ function() {
  return arguments;
}()) ? Fc : function(e) {
  return Ji(e) && B_.call(e, "callee") && !L_.call(e, "callee");
}, sa = Array.isArray, A_ = 9007199254740991;
function Lp(e) {
  return typeof e == "number" && e > -1 && e % 1 == 0 && e <= A_;
}
function Fa(e) {
  return e != null && Lp(e.length) && !Xo(e);
}
function M_(e) {
  return Ji(e) && Fa(e);
}
function E_() {
  return !1;
}
var Ap = typeof exports == "object" && exports && !exports.nodeType && exports, Dc = Ap && typeof module == "object" && module && !module.nodeType && module, $_ = Dc && Dc.exports === Ap, Oc = $_ ? Se.Buffer : void 0, F_ = Oc ? Oc.isBuffer : void 0, Zo = F_ || E_, D_ = "[object Object]", O_ = Function.prototype, R_ = Object.prototype, Mp = O_.toString, I_ = R_.hasOwnProperty, P_ = Mp.call(Object);
function N_(e) {
  if (!Ji(e) || ei(e) != D_)
    return !1;
  var t = Tp(e);
  if (t === null)
    return !0;
  var r = I_.call(t, "constructor") && t.constructor;
  return typeof r == "function" && r instanceof r && Mp.call(r) == P_;
}
var z_ = "[object Arguments]", W_ = "[object Array]", q_ = "[object Boolean]", H_ = "[object Date]", j_ = "[object Error]", Y_ = "[object Function]", U_ = "[object Map]", G_ = "[object Number]", X_ = "[object Object]", V_ = "[object RegExp]", Z_ = "[object Set]", K_ = "[object String]", Q_ = "[object WeakMap]", J_ = "[object ArrayBuffer]", tw = "[object DataView]", ew = "[object Float32Array]", rw = "[object Float64Array]", iw = "[object Int8Array]", nw = "[object Int16Array]", aw = "[object Int32Array]", sw = "[object Uint8Array]", ow = "[object Uint8ClampedArray]", lw = "[object Uint16Array]", cw = "[object Uint32Array]", xt = {};
xt[ew] = xt[rw] = xt[iw] = xt[nw] = xt[aw] = xt[sw] = xt[ow] = xt[lw] = xt[cw] = !0;
xt[z_] = xt[W_] = xt[J_] = xt[q_] = xt[tw] = xt[H_] = xt[j_] = xt[Y_] = xt[U_] = xt[G_] = xt[X_] = xt[V_] = xt[Z_] = xt[K_] = xt[Q_] = !1;
function hw(e) {
  return Ji(e) && Lp(e.length) && !!xt[ei(e)];
}
function uw(e) {
  return function(t) {
    return e(t);
  };
}
var Ep = typeof exports == "object" && exports && !exports.nodeType && exports, $i = Ep && typeof module == "object" && module && !module.nodeType && module, fw = $i && $i.exports === Ep, hs = fw && wp.process, Rc = function() {
  try {
    var e = $i && $i.require && $i.require("util").types;
    return e || hs && hs.binding && hs.binding("util");
  } catch {
  }
}(), Ic = Rc && Rc.isTypedArray, Ko = Ic ? uw(Ic) : hw;
function Js(e, t) {
  if (!(t === "constructor" && typeof e[t] == "function") && t != "__proto__")
    return e[t];
}
var pw = Object.prototype, dw = pw.hasOwnProperty;
function gw(e, t, r) {
  var i = e[t];
  (!(dw.call(e, t) && Aa(i, r)) || r === void 0 && !(t in e)) && Vo(e, t, r);
}
function mw(e, t, r, i) {
  var n = !r;
  r || (r = {});
  for (var a = -1, o = t.length; ++a < o; ) {
    var s = t[a], l = void 0;
    l === void 0 && (l = e[s]), n ? Vo(r, s, l) : gw(r, s, l);
  }
  return r;
}
function yw(e, t) {
  for (var r = -1, i = Array(e); ++r < e; )
    i[r] = t(r);
  return i;
}
var xw = 9007199254740991, bw = /^(?:0|[1-9]\d*)$/;
function $p(e, t) {
  var r = typeof e;
  return t = t ?? xw, !!t && (r == "number" || r != "symbol" && bw.test(e)) && e > -1 && e % 1 == 0 && e < t;
}
var Cw = Object.prototype, _w = Cw.hasOwnProperty;
function ww(e, t) {
  var r = sa(e), i = !r && aa(e), n = !r && !i && Zo(e), a = !r && !i && !n && Ko(e), o = r || i || n || a, s = o ? yw(e.length, String) : [], l = s.length;
  for (var c in e)
    (t || _w.call(e, c)) && !(o && // Safari 9 has enumerable `arguments.length` in strict mode.
    (c == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    n && (c == "offset" || c == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    a && (c == "buffer" || c == "byteLength" || c == "byteOffset") || // Skip index properties.
    $p(c, l))) && s.push(c);
  return s;
}
function vw(e) {
  var t = [];
  if (e != null)
    for (var r in Object(e))
      t.push(r);
  return t;
}
var kw = Object.prototype, Sw = kw.hasOwnProperty;
function Tw(e) {
  if (!yr(e))
    return vw(e);
  var t = $a(e), r = [];
  for (var i in e)
    i == "constructor" && (t || !Sw.call(e, i)) || r.push(i);
  return r;
}
function Fp(e) {
  return Fa(e) ? ww(e, !0) : Tw(e);
}
function Bw(e) {
  return mw(e, Fp(e));
}
function Lw(e, t, r, i, n, a, o) {
  var s = Js(e, r), l = Js(t, r), c = o.get(l);
  if (c) {
    Qs(e, r, c);
    return;
  }
  var h = a ? a(s, l, r + "", e, t, o) : void 0, u = h === void 0;
  if (u) {
    var f = sa(l), p = !f && Zo(l), g = !f && !p && Ko(l);
    h = l, f || p || g ? sa(s) ? h = s : M_(s) ? h = w_(s) : p ? (u = !1, h = b_(l, !0)) : g ? (u = !1, h = __(l, !0)) : h = [] : N_(l) || aa(l) ? (h = s, aa(s) ? h = Bw(s) : (!yr(s) || Xo(s)) && (h = S_(l))) : u = !1;
  }
  u && (o.set(l, h), n(h, l, i, a, o), o.delete(l)), Qs(e, r, h);
}
function Dp(e, t, r, i, n) {
  e !== t && y_(t, function(a, o) {
    if (n || (n = new ri()), yr(a))
      Lw(e, t, o, r, Dp, i, n);
    else {
      var s = i ? i(Js(e, o), a, o + "", e, t, n) : void 0;
      s === void 0 && (s = a), Qs(e, o, s);
    }
  }, Fp);
}
function Op(e) {
  return e;
}
function Aw(e, t, r) {
  switch (r.length) {
    case 0:
      return e.call(t);
    case 1:
      return e.call(t, r[0]);
    case 2:
      return e.call(t, r[0], r[1]);
    case 3:
      return e.call(t, r[0], r[1], r[2]);
  }
  return e.apply(t, r);
}
var Pc = Math.max;
function Mw(e, t, r) {
  return t = Pc(t === void 0 ? e.length - 1 : t, 0), function() {
    for (var i = arguments, n = -1, a = Pc(i.length - t, 0), o = Array(a); ++n < a; )
      o[n] = i[t + n];
    n = -1;
    for (var s = Array(t + 1); ++n < t; )
      s[n] = i[n];
    return s[t] = r(o), Aw(e, this, s);
  };
}
function Ew(e) {
  return function() {
    return e;
  };
}
var $w = na ? function(e, t) {
  return na(e, "toString", {
    configurable: !0,
    enumerable: !1,
    value: Ew(t),
    writable: !0
  });
} : Op, Fw = 800, Dw = 16, Ow = Date.now;
function Rw(e) {
  var t = 0, r = 0;
  return function() {
    var i = Ow(), n = Dw - (i - r);
    if (r = i, n > 0) {
      if (++t >= Fw)
        return arguments[0];
    } else
      t = 0;
    return e.apply(void 0, arguments);
  };
}
var Iw = Rw($w);
function Pw(e, t) {
  return Iw(Mw(e, t, Op), e + "");
}
function Nw(e, t, r) {
  if (!yr(r))
    return !1;
  var i = typeof t;
  return (i == "number" ? Fa(r) && $p(t, r.length) : i == "string" && t in r) ? Aa(r[t], e) : !1;
}
function zw(e) {
  return Pw(function(t, r) {
    var i = -1, n = r.length, a = n > 1 ? r[n - 1] : void 0, o = n > 2 ? r[2] : void 0;
    for (a = e.length > 3 && typeof a == "function" ? (n--, a) : void 0, o && Nw(r[0], r[1], o) && (a = n < 3 ? void 0 : a, n = 1), t = Object(t); ++i < n; ) {
      var s = r[i];
      s && e(t, s, i, a);
    }
    return t;
  });
}
var Ww = zw(function(e, t, r) {
  Dp(e, t, r);
}), qw = "​", Hw = {
  curveBasis: Bn,
  curveBasisClosed: j1,
  curveBasisOpen: Y1,
  curveBumpX: xu,
  curveBumpY: bu,
  curveBundle: U1,
  curveCardinalClosed: G1,
  curveCardinalOpen: X1,
  curveCardinal: vu,
  curveCatmullRomClosed: V1,
  curveCatmullRomOpen: Z1,
  curveCatmullRom: Su,
  curveLinear: Gn,
  curveLinearClosed: K1,
  curveMonotoneX: Eu,
  curveMonotoneY: $u,
  curveNatural: Du,
  curveStep: Ou,
  curveStepAfter: Iu,
  curveStepBefore: Ru
}, jw = /\s*(?:(\w+)(?=:):|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, Yw = /* @__PURE__ */ d(function(e, t) {
  const r = Rp(e, /(?:init\b)|(?:initialize\b)/);
  let i = {};
  if (Array.isArray(r)) {
    const o = r.map((s) => s.args);
    Rn(o), i = Bt(i, [...o]);
  } else
    i = r.args;
  if (!i)
    return;
  let n = Co(e, t);
  const a = "config";
  return i[a] !== void 0 && (n === "flowchart-v2" && (n = "flowchart"), i[n] = i[a], delete i[a]), i;
}, "detectInit"), Rp = /* @__PURE__ */ d(function(e, t = null) {
  var r, i;
  try {
    const n = new RegExp(
      `[%]{2}(?![{]${jw.source})(?=[}][%]{2}).*
`,
      "ig"
    );
    e = e.trim().replace(n, "").replace(/'/gm, '"'), F.debug(
      `Detecting diagram directive${t !== null ? " type:" + t : ""} based on the text:${e}`
    );
    let a;
    const o = [];
    for (; (a = Mi.exec(e)) !== null; )
      if (a.index === Mi.lastIndex && Mi.lastIndex++, a && !t || t && ((r = a[1]) != null && r.match(t)) || t && ((i = a[2]) != null && i.match(t))) {
        const s = a[1] ? a[1] : a[2], l = a[3] ? a[3].trim() : a[4] ? JSON.parse(a[4].trim()) : null;
        o.push({ type: s, args: l });
      }
    return o.length === 0 ? { type: e, args: null } : o.length === 1 ? o[0] : o;
  } catch (n) {
    return F.error(
      `ERROR: ${n.message} - Unable to parse directive type: '${t}' based on the text: '${e}'`
    ), { type: void 0, args: null };
  }
}, "detectDirective"), Uw = /* @__PURE__ */ d(function(e) {
  return e.replace(Mi, "");
}, "removeDirectives"), Gw = /* @__PURE__ */ d(function(e, t) {
  for (const [r, i] of t.entries())
    if (i.match(e))
      return r;
  return -1;
}, "isSubstringInArray");
function Qo(e, t) {
  if (!e)
    return t;
  const r = `curve${e.charAt(0).toUpperCase() + e.slice(1)}`;
  return Hw[r] ?? t;
}
d(Qo, "interpolateToCurve");
function Ip(e, t) {
  const r = e.trim();
  if (r)
    return t.securityLevel !== "loose" ? _p(r) : r;
}
d(Ip, "formatUrl");
var Xw = /* @__PURE__ */ d((e, ...t) => {
  const r = e.split("."), i = r.length - 1, n = r[i];
  let a = window;
  for (let o = 0; o < i; o++)
    if (a = a[r[o]], !a) {
      F.error(`Function name: ${e} not found in window`);
      return;
    }
  a[n](...t);
}, "runFunc");
function Jo(e, t) {
  return !e || !t ? 0 : Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2));
}
d(Jo, "distance");
function Pp(e) {
  let t, r = 0;
  e.forEach((n) => {
    r += Jo(n, t), t = n;
  });
  const i = r / 2;
  return tl(e, i);
}
d(Pp, "traverseEdge");
function Np(e) {
  return e.length === 1 ? e[0] : Pp(e);
}
d(Np, "calcLabelPosition");
var Nc = /* @__PURE__ */ d((e, t = 2) => {
  const r = Math.pow(10, t);
  return Math.round(e * r) / r;
}, "roundNumber"), tl = /* @__PURE__ */ d((e, t) => {
  let r, i = t;
  for (const n of e) {
    if (r) {
      const a = Jo(n, r);
      if (a === 0)
        return r;
      if (a < i)
        i -= a;
      else {
        const o = i / a;
        if (o <= 0)
          return r;
        if (o >= 1)
          return { x: n.x, y: n.y };
        if (o > 0 && o < 1)
          return {
            x: Nc((1 - o) * r.x + o * n.x, 5),
            y: Nc((1 - o) * r.y + o * n.y, 5)
          };
      }
    }
    r = n;
  }
  throw new Error("Could not find a suitable point for the given distance");
}, "calculatePoint"), Vw = /* @__PURE__ */ d((e, t, r) => {
  F.info(`our points ${JSON.stringify(t)}`), t[0] !== r && (t = t.reverse());
  const n = tl(t, 25), a = e ? 10 : 5, o = Math.atan2(t[0].y - n.y, t[0].x - n.x), s = { x: 0, y: 0 };
  return s.x = Math.sin(o) * a + (t[0].x + n.x) / 2, s.y = -Math.cos(o) * a + (t[0].y + n.y) / 2, s;
}, "calcCardinalityPosition");
function zp(e, t, r) {
  const i = structuredClone(r);
  F.info("our points", i), t !== "start_left" && t !== "start_right" && i.reverse();
  const n = 25 + e, a = tl(i, n), o = 10 + e * 0.5, s = Math.atan2(i[0].y - a.y, i[0].x - a.x), l = { x: 0, y: 0 };
  return t === "start_left" ? (l.x = Math.sin(s + Math.PI) * o + (i[0].x + a.x) / 2, l.y = -Math.cos(s + Math.PI) * o + (i[0].y + a.y) / 2) : t === "end_right" ? (l.x = Math.sin(s - Math.PI) * o + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(s - Math.PI) * o + (i[0].y + a.y) / 2 - 5) : t === "end_left" ? (l.x = Math.sin(s) * o + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(s) * o + (i[0].y + a.y) / 2 - 5) : (l.x = Math.sin(s) * o + (i[0].x + a.x) / 2, l.y = -Math.cos(s) * o + (i[0].y + a.y) / 2), l;
}
d(zp, "calcTerminalLabelPosition");
function Wp(e) {
  let t = "", r = "";
  for (const i of e)
    i !== void 0 && (i.startsWith("color:") || i.startsWith("text-align:") ? r = r + i + ";" : t = t + i + ";");
  return { style: t, labelStyle: r };
}
d(Wp, "getStylesFromArray");
var zc = 0, Zw = /* @__PURE__ */ d(() => (zc++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + zc), "generateId");
function qp(e) {
  let t = "";
  const r = "0123456789abcdef", i = r.length;
  for (let n = 0; n < e; n++)
    t += r.charAt(Math.floor(Math.random() * i));
  return t;
}
d(qp, "makeRandomHex");
var Kw = /* @__PURE__ */ d((e) => qp(e.length), "random"), Qw = /* @__PURE__ */ d(function() {
  return {
    x: 0,
    y: 0,
    fill: void 0,
    anchor: "start",
    style: "#666",
    width: 100,
    height: 100,
    textMargin: 0,
    rx: 0,
    ry: 0,
    valign: void 0,
    text: ""
  };
}, "getTextObj"), Jw = /* @__PURE__ */ d(function(e, t) {
  const r = t.text.replace(Jr.lineBreakRegex, " "), [, i] = Da(t.fontSize), n = e.append("text");
  n.attr("x", t.x), n.attr("y", t.y), n.style("text-anchor", t.anchor), n.style("font-family", t.fontFamily), n.style("font-size", i), n.style("font-weight", t.fontWeight), n.attr("fill", t.fill), t.class !== void 0 && n.attr("class", t.class);
  const a = n.append("tspan");
  return a.attr("x", t.x + t.textMargin * 2), a.attr("fill", t.fill), a.text(r), n;
}, "drawSimpleText"), tv = Qi(
  (e, t, r) => {
    if (!e || (r = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", joinWith: "<br/>" },
      r
    ), Jr.lineBreakRegex.test(e)))
      return e;
    const i = e.split(" ").filter(Boolean), n = [];
    let a = "";
    return i.forEach((o, s) => {
      const l = Ne(`${o} `, r), c = Ne(a, r);
      if (l > t) {
        const { hyphenatedStrings: f, remainingWord: p } = ev(o, t, "-", r);
        n.push(a, ...f), a = p;
      } else c + l >= t ? (n.push(a), a = o) : a = [a, o].filter(Boolean).join(" ");
      s + 1 === i.length && n.push(a);
    }), n.filter((o) => o !== "").join(r.joinWith);
  },
  (e, t, r) => `${e}${t}${r.fontSize}${r.fontWeight}${r.fontFamily}${r.joinWith}`
), ev = Qi(
  (e, t, r = "-", i) => {
    i = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", margin: 0 },
      i
    );
    const n = [...e], a = [];
    let o = "";
    return n.forEach((s, l) => {
      const c = `${o}${s}`;
      if (Ne(c, i) >= t) {
        const u = l + 1, f = n.length === u, p = `${c}${r}`;
        a.push(f ? c : p), o = "";
      } else
        o = c;
    }), { hyphenatedStrings: a, remainingWord: o };
  },
  (e, t, r = "-", i) => `${e}${t}${r}${i.fontSize}${i.fontWeight}${i.fontFamily}`
);
function Hp(e, t) {
  return el(e, t).height;
}
d(Hp, "calculateTextHeight");
function Ne(e, t) {
  return el(e, t).width;
}
d(Ne, "calculateTextWidth");
var el = Qi(
  (e, t) => {
    const { fontSize: r = 12, fontFamily: i = "Arial", fontWeight: n = 400 } = t;
    if (!e)
      return { width: 0, height: 0 };
    const [, a] = Da(r), o = ["sans-serif", i], s = e.split(Jr.lineBreakRegex), l = [], c = ht("body");
    if (!c.remove)
      return { width: 0, height: 0, lineHeight: 0 };
    const h = c.append("svg");
    for (const f of o) {
      let p = 0;
      const g = { width: 0, height: 0, lineHeight: 0 };
      for (const m of s) {
        const x = Qw();
        x.text = m || qw;
        const y = Jw(h, x).style("font-size", a).style("font-weight", n).style("font-family", f), b = (y._groups || y)[0][0].getBBox();
        if (b.width === 0 && b.height === 0)
          throw new Error("svg element not in render tree");
        g.width = Math.round(Math.max(g.width, b.width)), p = Math.round(b.height), g.height += p, g.lineHeight = Math.round(Math.max(g.lineHeight, p));
      }
      l.push(g);
    }
    h.remove();
    const u = isNaN(l[1].height) || isNaN(l[1].width) || isNaN(l[1].lineHeight) || l[0].height > l[1].height && l[0].width > l[1].width && l[0].lineHeight > l[1].lineHeight ? 0 : 1;
    return l[u];
  },
  (e, t) => `${e}${t.fontSize}${t.fontWeight}${t.fontFamily}`
), Hr, rv = (Hr = class {
  constructor(t = !1, r) {
    this.count = 0, this.count = r ? r.length : 0, this.next = t ? () => this.count++ : () => Date.now();
  }
}, d(Hr, "InitIDGenerator"), Hr), gn, iv = /* @__PURE__ */ d(function(e) {
  return gn = gn || document.createElement("div"), e = escape(e).replace(/%26/g, "&").replace(/%23/g, "#").replace(/%3B/g, ";"), gn.innerHTML = e, unescape(gn.textContent);
}, "entityDecode");
function rl(e) {
  return "str" in e;
}
d(rl, "isDetailedError");
var nv = /* @__PURE__ */ d((e, t, r, i) => {
  var a;
  if (!i)
    return;
  const n = (a = e.node()) == null ? void 0 : a.getBBox();
  n && e.append("text").text(i).attr("text-anchor", "middle").attr("x", n.x + n.width / 2).attr("y", -r).attr("class", t);
}, "insertTitle"), Da = /* @__PURE__ */ d((e) => {
  if (typeof e == "number")
    return [e, e + "px"];
  const t = parseInt(e ?? "", 10);
  return Number.isNaN(t) ? [void 0, void 0] : e === String(t) ? [t, e + "px"] : [t, e];
}, "parseFontSize");
function il(e, t) {
  return Ww({}, e, t);
}
d(il, "cleanAndMerge");
var ue = {
  assignWithDepth: Bt,
  wrapLabel: tv,
  calculateTextHeight: Hp,
  calculateTextWidth: Ne,
  calculateTextDimensions: el,
  cleanAndMerge: il,
  detectInit: Yw,
  detectDirective: Rp,
  isSubstringInArray: Gw,
  interpolateToCurve: Qo,
  calcLabelPosition: Np,
  calcCardinalityPosition: Vw,
  calcTerminalLabelPosition: zp,
  formatUrl: Ip,
  getStylesFromArray: Wp,
  generateId: Zw,
  random: Kw,
  runFunc: Xw,
  entityDecode: iv,
  insertTitle: nv,
  isLabelCoordinateInPath: jp,
  parseFontSize: Da,
  InitIDGenerator: rv
}, av = /* @__PURE__ */ d(function(e) {
  let t = e;
  return t = t.replace(/style.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/classDef.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/#\w+;/g, function(r) {
    const i = r.substring(1, r.length - 1);
    return /^\+?\d+$/.test(i) ? "ﬂ°°" + i + "¶ß" : "ﬂ°" + i + "¶ß";
  }), t;
}, "encodeEntities"), Cr = /* @__PURE__ */ d(function(e) {
  return e.replace(/ﬂ°°/g, "&#").replace(/ﬂ°/g, "&").replace(/¶ß/g, ";");
}, "decodeEntities"), nA = /* @__PURE__ */ d((e, t, {
  counter: r = 0,
  prefix: i,
  suffix: n
}, a) => a || `${i ? `${i}_` : ""}${e}_${t}_${r}${n ? `_${n}` : ""}`, "getEdgeId");
function zt(e) {
  return e ?? null;
}
d(zt, "handleUndefinedAttr");
function jp(e, t) {
  const r = Math.round(e.x), i = Math.round(e.y), n = t.replace(
    /(\d+\.\d+)/g,
    (a) => Math.round(parseFloat(a)).toString()
  );
  return n.includes(r.toString()) || n.includes(i.toString());
}
d(jp, "isLabelCoordinateInPath");
const sv = Object.freeze({
  left: 0,
  top: 0,
  width: 16,
  height: 16
}), oa = Object.freeze({
  rotate: 0,
  vFlip: !1,
  hFlip: !1
}), Yp = Object.freeze({
  ...sv,
  ...oa
}), ov = Object.freeze({
  ...Yp,
  body: "",
  hidden: !1
}), lv = Object.freeze({
  width: null,
  height: null
}), cv = Object.freeze({
  ...lv,
  ...oa
}), hv = (e, t, r, i = "") => {
  const n = e.split(":");
  if (e.slice(0, 1) === "@") {
    if (n.length < 2 || n.length > 3) return null;
    i = n.shift().slice(1);
  }
  if (n.length > 3 || !n.length) return null;
  if (n.length > 1) {
    const s = n.pop(), l = n.pop(), c = {
      provider: n.length > 0 ? n[0] : i,
      prefix: l,
      name: s
    };
    return us(c) ? c : null;
  }
  const a = n[0], o = a.split("-");
  if (o.length > 1) {
    const s = {
      provider: i,
      prefix: o.shift(),
      name: o.join("-")
    };
    return us(s) ? s : null;
  }
  if (r && i === "") {
    const s = {
      provider: i,
      prefix: "",
      name: a
    };
    return us(s, r) ? s : null;
  }
  return null;
}, us = (e, t) => e ? !!((t && e.prefix === "" || e.prefix) && e.name) : !1;
function uv(e, t) {
  const r = {};
  !e.hFlip != !t.hFlip && (r.hFlip = !0), !e.vFlip != !t.vFlip && (r.vFlip = !0);
  const i = ((e.rotate || 0) + (t.rotate || 0)) % 4;
  return i && (r.rotate = i), r;
}
function Wc(e, t) {
  const r = uv(e, t);
  for (const i in ov) i in oa ? i in e && !(i in r) && (r[i] = oa[i]) : i in t ? r[i] = t[i] : i in e && (r[i] = e[i]);
  return r;
}
function fv(e, t) {
  const r = e.icons, i = e.aliases || /* @__PURE__ */ Object.create(null), n = /* @__PURE__ */ Object.create(null);
  function a(o) {
    if (r[o]) return n[o] = [];
    if (!(o in n)) {
      n[o] = null;
      const s = i[o] && i[o].parent, l = s && a(s);
      l && (n[o] = [s].concat(l));
    }
    return n[o];
  }
  return (t || Object.keys(r).concat(Object.keys(i))).forEach(a), n;
}
function qc(e, t, r) {
  const i = e.icons, n = e.aliases || /* @__PURE__ */ Object.create(null);
  let a = {};
  function o(s) {
    a = Wc(i[s] || n[s], a);
  }
  return o(t), r.forEach(o), Wc(e, a);
}
function pv(e, t) {
  if (e.icons[t]) return qc(e, t, []);
  const r = fv(e, [t])[t];
  return r ? qc(e, t, r) : null;
}
const dv = /(-?[0-9.]*[0-9]+[0-9.]*)/g, gv = /^-?[0-9.]*[0-9]+[0-9.]*$/g;
function Hc(e, t, r) {
  if (t === 1) return e;
  if (r = r || 100, typeof e == "number") return Math.ceil(e * t * r) / r;
  if (typeof e != "string") return e;
  const i = e.split(dv);
  if (i === null || !i.length) return e;
  const n = [];
  let a = i.shift(), o = gv.test(a);
  for (; ; ) {
    if (o) {
      const s = parseFloat(a);
      isNaN(s) ? n.push(a) : n.push(Math.ceil(s * t * r) / r);
    } else n.push(a);
    if (a = i.shift(), a === void 0) return n.join("");
    o = !o;
  }
}
function mv(e, t = "defs") {
  let r = "";
  const i = e.indexOf("<" + t);
  for (; i >= 0; ) {
    const n = e.indexOf(">", i), a = e.indexOf("</" + t);
    if (n === -1 || a === -1) break;
    const o = e.indexOf(">", a);
    if (o === -1) break;
    r += e.slice(n + 1, a).trim(), e = e.slice(0, i).trim() + e.slice(o + 1);
  }
  return {
    defs: r,
    content: e
  };
}
function yv(e, t) {
  return e ? "<defs>" + e + "</defs>" + t : t;
}
function xv(e, t, r) {
  const i = mv(e);
  return yv(i.defs, t + i.content + r);
}
const bv = (e) => e === "unset" || e === "undefined" || e === "none";
function Cv(e, t) {
  const r = {
    ...Yp,
    ...e
  }, i = {
    ...cv,
    ...t
  }, n = {
    left: r.left,
    top: r.top,
    width: r.width,
    height: r.height
  };
  let a = r.body;
  [r, i].forEach((m) => {
    const x = [], y = m.hFlip, b = m.vFlip;
    let _ = m.rotate;
    y ? b ? _ += 2 : (x.push("translate(" + (n.width + n.left).toString() + " " + (0 - n.top).toString() + ")"), x.push("scale(-1 1)"), n.top = n.left = 0) : b && (x.push("translate(" + (0 - n.left).toString() + " " + (n.height + n.top).toString() + ")"), x.push("scale(1 -1)"), n.top = n.left = 0);
    let k;
    switch (_ < 0 && (_ -= Math.floor(_ / 4) * 4), _ = _ % 4, _) {
      case 1:
        k = n.height / 2 + n.top, x.unshift("rotate(90 " + k.toString() + " " + k.toString() + ")");
        break;
      case 2:
        x.unshift("rotate(180 " + (n.width / 2 + n.left).toString() + " " + (n.height / 2 + n.top).toString() + ")");
        break;
      case 3:
        k = n.width / 2 + n.left, x.unshift("rotate(-90 " + k.toString() + " " + k.toString() + ")");
        break;
    }
    _ % 2 === 1 && (n.left !== n.top && (k = n.left, n.left = n.top, n.top = k), n.width !== n.height && (k = n.width, n.width = n.height, n.height = k)), x.length && (a = xv(a, '<g transform="' + x.join(" ") + '">', "</g>"));
  });
  const o = i.width, s = i.height, l = n.width, c = n.height;
  let h, u;
  o === null ? (u = s === null ? "1em" : s === "auto" ? c : s, h = Hc(u, l / c)) : (h = o === "auto" ? l : o, u = s === null ? Hc(h, c / l) : s === "auto" ? c : s);
  const f = {}, p = (m, x) => {
    bv(x) || (f[m] = x.toString());
  };
  p("width", h), p("height", u);
  const g = [
    n.left,
    n.top,
    l,
    c
  ];
  return f.viewBox = g.join(" "), {
    attributes: f,
    viewBox: g,
    body: a
  };
}
const _v = /\sid="(\S+)"/g, wv = "IconifyId" + Date.now().toString(16) + (Math.random() * 16777216 | 0).toString(16);
let vv = 0;
function kv(e, t = wv) {
  const r = [];
  let i;
  for (; i = _v.exec(e); ) r.push(i[1]);
  if (!r.length) return e;
  const n = "suffix" + (Math.random() * 16777216 | Date.now()).toString(16);
  return r.forEach((a) => {
    const o = typeof t == "function" ? t(a) : t + (vv++).toString(), s = a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    e = e.replace(new RegExp('([#;"])(' + s + ')([")]|\\.[a-z])', "g"), "$1" + o + n + "$3");
  }), e = e.replace(new RegExp(n, "g"), ""), e;
}
function Sv(e, t) {
  let r = e.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
  for (const i in t) r += " " + i + '="' + t[i] + '"';
  return '<svg xmlns="http://www.w3.org/2000/svg"' + r + ">" + e + "</svg>";
}
function nl() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
var _r = nl();
function Up(e) {
  _r = e;
}
var Fi = { exec: () => null };
function pt(e, t = "") {
  let r = typeof e == "string" ? e : e.source;
  const i = {
    replace: (n, a) => {
      let o = typeof a == "string" ? a : a.source;
      return o = o.replace(Ut.caret, "$1"), r = r.replace(n, o), i;
    },
    getRegex: () => new RegExp(r, t)
  };
  return i;
}
var Ut = {
  codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
  outputLinkReplace: /\\([\[\]])/g,
  indentCodeCompensation: /^(\s+)(?:```)/,
  beginningSpace: /^\s+/,
  endingHash: /#$/,
  startingSpaceChar: /^ /,
  endingSpaceChar: / $/,
  nonSpaceChar: /[^ ]/,
  newLineCharGlobal: /\n/g,
  tabCharGlobal: /\t/g,
  multipleSpaceGlobal: /\s+/g,
  blankLine: /^[ \t]*$/,
  doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
  blockquoteStart: /^ {0,3}>/,
  blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
  blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
  listReplaceTabs: /^\t+/,
  listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
  listIsTask: /^\[[ xX]\] /,
  listReplaceTask: /^\[[ xX]\] +/,
  anyLine: /\n.*\n/,
  hrefBrackets: /^<(.*)>$/,
  tableDelimiter: /[:|]/,
  tableAlignChars: /^\||\| *$/g,
  tableRowBlankLine: /\n[ \t]*$/,
  tableAlignRight: /^ *-+: *$/,
  tableAlignCenter: /^ *:-+: *$/,
  tableAlignLeft: /^ *:-+ *$/,
  startATag: /^<a /i,
  endATag: /^<\/a>/i,
  startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
  endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
  startAngleBracket: /^</,
  endAngleBracket: />$/,
  pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
  unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
  escapeTest: /[&<>"']/,
  escapeReplace: /[&<>"']/g,
  escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
  escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
  unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,
  caret: /(^|[^\[])\^/g,
  percentDecode: /%25/g,
  findPipe: /\|/g,
  splitPipe: / \|/,
  slashPipe: /\\\|/g,
  carriageReturn: /\r\n|\r/g,
  spaceLine: /^ +$/gm,
  notSpaceStart: /^\S*/,
  endingNewline: /\n$/,
  listItemRegex: (e) => new RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`),
  nextBulletRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),
  hrRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),
  fencesBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:\`\`\`|~~~)`),
  headingBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}#`),
  htmlBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}<(?:[a-z].*>|!--)`, "i")
}, Tv = /^(?:[ \t]*(?:\n|$))+/, Bv = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, Lv = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, tn = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Av = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, al = /(?:[*+-]|\d{1,9}[.)])/, Gp = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, Xp = pt(Gp).replace(/bull/g, al).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), Mv = pt(Gp).replace(/bull/g, al).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), sl = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Ev = /^[^\n]+/, ol = /(?!\s*\])(?:\\.|[^\[\]\\])+/, $v = pt(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", ol).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Fv = pt(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, al).getRegex(), Oa = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", ll = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Dv = pt(
  "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))",
  "i"
).replace("comment", ll).replace("tag", Oa).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Vp = pt(sl).replace("hr", tn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Oa).getRegex(), Ov = pt(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Vp).getRegex(), cl = {
  blockquote: Ov,
  code: Bv,
  def: $v,
  fences: Lv,
  heading: Av,
  hr: tn,
  html: Dv,
  lheading: Xp,
  list: Fv,
  newline: Tv,
  paragraph: Vp,
  table: Fi,
  text: Ev
}, jc = pt(
  "^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
).replace("hr", tn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Oa).getRegex(), Rv = {
  ...cl,
  lheading: Mv,
  table: jc,
  paragraph: pt(sl).replace("hr", tn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", jc).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Oa).getRegex()
}, Iv = {
  ...cl,
  html: pt(
    `^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`
  ).replace("comment", ll).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Fi,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: pt(sl).replace("hr", tn).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Xp).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Pv = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Nv = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Zp = /^( {2,}|\\)\n(?!\s*$)/, zv = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Ra = /[\p{P}\p{S}]/u, hl = /[\s\p{P}\p{S}]/u, Kp = /[^\s\p{P}\p{S}]/u, Wv = pt(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, hl).getRegex(), Qp = /(?!~)[\p{P}\p{S}]/u, qv = /(?!~)[\s\p{P}\p{S}]/u, Hv = /(?:[^\s\p{P}\p{S}]|~)/u, jv = /\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g, Jp = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, Yv = pt(Jp, "u").replace(/punct/g, Ra).getRegex(), Uv = pt(Jp, "u").replace(/punct/g, Qp).getRegex(), td = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", Gv = pt(td, "gu").replace(/notPunctSpace/g, Kp).replace(/punctSpace/g, hl).replace(/punct/g, Ra).getRegex(), Xv = pt(td, "gu").replace(/notPunctSpace/g, Hv).replace(/punctSpace/g, qv).replace(/punct/g, Qp).getRegex(), Vv = pt(
  "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)",
  "gu"
).replace(/notPunctSpace/g, Kp).replace(/punctSpace/g, hl).replace(/punct/g, Ra).getRegex(), Zv = pt(/\\(punct)/, "gu").replace(/punct/g, Ra).getRegex(), Kv = pt(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Qv = pt(ll).replace("(?:-->|$)", "-->").getRegex(), Jv = pt(
  "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>"
).replace("comment", Qv).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), la = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, tk = pt(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", la).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ed = pt(/^!?\[(label)\]\[(ref)\]/).replace("label", la).replace("ref", ol).getRegex(), rd = pt(/^!?\[(ref)\](?:\[\])?/).replace("ref", ol).getRegex(), ek = pt("reflink|nolink(?!\\()", "g").replace("reflink", ed).replace("nolink", rd).getRegex(), ul = {
  _backpedal: Fi,
  // only used for GFM url
  anyPunctuation: Zv,
  autolink: Kv,
  blockSkip: jv,
  br: Zp,
  code: Nv,
  del: Fi,
  emStrongLDelim: Yv,
  emStrongRDelimAst: Gv,
  emStrongRDelimUnd: Vv,
  escape: Pv,
  link: tk,
  nolink: rd,
  punctuation: Wv,
  reflink: ed,
  reflinkSearch: ek,
  tag: Jv,
  text: zv,
  url: Fi
}, rk = {
  ...ul,
  link: pt(/^!?\[(label)\]\((.*?)\)/).replace("label", la).getRegex(),
  reflink: pt(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", la).getRegex()
}, to = {
  ...ul,
  emStrongRDelimAst: Xv,
  emStrongLDelim: Uv,
  url: pt(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, ik = {
  ...to,
  br: pt(Zp).replace("{2,}", "*").getRegex(),
  text: pt(to.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, mn = {
  normal: cl,
  gfm: Rv,
  pedantic: Iv
}, gi = {
  normal: ul,
  gfm: to,
  breaks: ik,
  pedantic: rk
}, nk = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Yc = (e) => nk[e];
function xe(e, t) {
  if (t) {
    if (Ut.escapeTest.test(e))
      return e.replace(Ut.escapeReplace, Yc);
  } else if (Ut.escapeTestNoEncode.test(e))
    return e.replace(Ut.escapeReplaceNoEncode, Yc);
  return e;
}
function Uc(e) {
  try {
    e = encodeURI(e).replace(Ut.percentDecode, "%");
  } catch {
    return null;
  }
  return e;
}
function Gc(e, t) {
  var a;
  const r = e.replace(Ut.findPipe, (o, s, l) => {
    let c = !1, h = s;
    for (; --h >= 0 && l[h] === "\\"; ) c = !c;
    return c ? "|" : " |";
  }), i = r.split(Ut.splitPipe);
  let n = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !((a = i.at(-1)) != null && a.trim()) && i.pop(), t)
    if (i.length > t)
      i.splice(t);
    else
      for (; i.length < t; ) i.push("");
  for (; n < i.length; n++)
    i[n] = i[n].trim().replace(Ut.slashPipe, "|");
  return i;
}
function mi(e, t, r) {
  const i = e.length;
  if (i === 0)
    return "";
  let n = 0;
  for (; n < i && e.charAt(i - n - 1) === t; )
    n++;
  return e.slice(0, i - n);
}
function ak(e, t) {
  if (e.indexOf(t[1]) === -1)
    return -1;
  let r = 0;
  for (let i = 0; i < e.length; i++)
    if (e[i] === "\\")
      i++;
    else if (e[i] === t[0])
      r++;
    else if (e[i] === t[1] && (r--, r < 0))
      return i;
  return r > 0 ? -2 : -1;
}
function Xc(e, t, r, i, n) {
  const a = t.href, o = t.title || null, s = e[1].replace(n.other.outputLinkReplace, "$1");
  i.state.inLink = !0;
  const l = {
    type: e[0].charAt(0) === "!" ? "image" : "link",
    raw: r,
    href: a,
    title: o,
    text: s,
    tokens: i.inlineTokens(s)
  };
  return i.state.inLink = !1, l;
}
function sk(e, t, r) {
  const i = e.match(r.other.indentCodeCompensation);
  if (i === null)
    return t;
  const n = i[1];
  return t.split(`
`).map((a) => {
    const o = a.match(r.other.beginningSpace);
    if (o === null)
      return a;
    const [s] = o;
    return s.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
var ca = class {
  // set by the lexer
  constructor(e) {
    gt(this, "options");
    gt(this, "rules");
    // set by the lexer
    gt(this, "lexer");
    this.options = e || _r;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const r = t[0].replace(this.rules.other.codeRemoveIndent, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? r : mi(r, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const r = t[0], i = sk(r, t[3] || "", this.rules);
      return {
        type: "code",
        raw: r,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let r = t[2].trim();
      if (this.rules.other.endingHash.test(r)) {
        const i = mi(r, "#");
        (this.options.pedantic || !i || this.rules.other.endingSpaceChar.test(i)) && (r = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: mi(t[0], `
`)
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let r = mi(t[0], `
`).split(`
`), i = "", n = "";
      const a = [];
      for (; r.length > 0; ) {
        let o = !1;
        const s = [];
        let l;
        for (l = 0; l < r.length; l++)
          if (this.rules.other.blockquoteStart.test(r[l]))
            s.push(r[l]), o = !0;
          else if (!o)
            s.push(r[l]);
          else
            break;
        r = r.slice(l);
        const c = s.join(`
`), h = c.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        i = i ? `${i}
${c}` : c, n = n ? `${n}
${h}` : h;
        const u = this.lexer.state.top;
        if (this.lexer.state.top = !0, this.lexer.blockTokens(h, a, !0), this.lexer.state.top = u, r.length === 0)
          break;
        const f = a.at(-1);
        if ((f == null ? void 0 : f.type) === "code")
          break;
        if ((f == null ? void 0 : f.type) === "blockquote") {
          const p = f, g = p.raw + `
` + r.join(`
`), m = this.blockquote(g);
          a[a.length - 1] = m, i = i.substring(0, i.length - p.raw.length) + m.raw, n = n.substring(0, n.length - p.text.length) + m.text;
          break;
        } else if ((f == null ? void 0 : f.type) === "list") {
          const p = f, g = p.raw + `
` + r.join(`
`), m = this.list(g);
          a[a.length - 1] = m, i = i.substring(0, i.length - f.raw.length) + m.raw, n = n.substring(0, n.length - p.raw.length) + m.raw, r = g.substring(a.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return {
        type: "blockquote",
        raw: i,
        tokens: a,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let r = t[1].trim();
      const i = r.length > 1, n = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +r.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      r = i ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = i ? r : "[*+-]");
      const a = this.rules.other.listItemRegex(r);
      let o = !1;
      for (; e; ) {
        let l = !1, c = "", h = "";
        if (!(t = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        c = t[0], e = e.substring(c.length);
        let u = t[2].split(`
`, 1)[0].replace(this.rules.other.listReplaceTabs, (y) => " ".repeat(3 * y.length)), f = e.split(`
`, 1)[0], p = !u.trim(), g = 0;
        if (this.options.pedantic ? (g = 2, h = u.trimStart()) : p ? g = t[1].length + 1 : (g = t[2].search(this.rules.other.nonSpaceChar), g = g > 4 ? 1 : g, h = u.slice(g), g += t[1].length), p && this.rules.other.blankLine.test(f) && (c += f + `
`, e = e.substring(f.length + 1), l = !0), !l) {
          const y = this.rules.other.nextBulletRegex(g), b = this.rules.other.hrRegex(g), _ = this.rules.other.fencesBeginRegex(g), k = this.rules.other.headingBeginRegex(g), v = this.rules.other.htmlBeginRegex(g);
          for (; e; ) {
            const C = e.split(`
`, 1)[0];
            let S;
            if (f = C, this.options.pedantic ? (f = f.replace(this.rules.other.listReplaceNesting, "  "), S = f) : S = f.replace(this.rules.other.tabCharGlobal, "    "), _.test(f) || k.test(f) || v.test(f) || y.test(f) || b.test(f))
              break;
            if (S.search(this.rules.other.nonSpaceChar) >= g || !f.trim())
              h += `
` + S.slice(g);
            else {
              if (p || u.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || _.test(u) || k.test(u) || b.test(u))
                break;
              h += `
` + f;
            }
            !p && !f.trim() && (p = !0), c += C + `
`, e = e.substring(C.length + 1), u = S.slice(g);
          }
        }
        n.loose || (o ? n.loose = !0 : this.rules.other.doubleBlankLine.test(c) && (o = !0));
        let m = null, x;
        this.options.gfm && (m = this.rules.other.listIsTask.exec(h), m && (x = m[0] !== "[ ] ", h = h.replace(this.rules.other.listReplaceTask, ""))), n.items.push({
          type: "list_item",
          raw: c,
          task: !!m,
          checked: x,
          loose: !1,
          text: h,
          tokens: []
        }), n.raw += c;
      }
      const s = n.items.at(-1);
      if (s)
        s.raw = s.raw.trimEnd(), s.text = s.text.trimEnd();
      else
        return;
      n.raw = n.raw.trimEnd();
      for (let l = 0; l < n.items.length; l++)
        if (this.lexer.state.top = !1, n.items[l].tokens = this.lexer.blockTokens(n.items[l].text, []), !n.loose) {
          const c = n.items[l].tokens.filter((u) => u.type === "space"), h = c.length > 0 && c.some((u) => this.rules.other.anyLine.test(u.raw));
          n.loose = h;
        }
      if (n.loose)
        for (let l = 0; l < n.items.length; l++)
          n.items[l].loose = !0;
      return n;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const r = t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), i = t[2] ? t[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", n = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: r,
        raw: t[0],
        href: i,
        title: n
      };
    }
  }
  table(e) {
    var o;
    const t = this.rules.block.table.exec(e);
    if (!t || !this.rules.other.tableDelimiter.test(t[2]))
      return;
    const r = Gc(t[1]), i = t[2].replace(this.rules.other.tableAlignChars, "").split("|"), n = (o = t[3]) != null && o.trim() ? t[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], a = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (r.length === i.length) {
      for (const s of i)
        this.rules.other.tableAlignRight.test(s) ? a.align.push("right") : this.rules.other.tableAlignCenter.test(s) ? a.align.push("center") : this.rules.other.tableAlignLeft.test(s) ? a.align.push("left") : a.align.push(null);
      for (let s = 0; s < r.length; s++)
        a.header.push({
          text: r[s],
          tokens: this.lexer.inline(r[s]),
          header: !0,
          align: a.align[s]
        });
      for (const s of n)
        a.rows.push(Gc(s, a.header.length).map((l, c) => ({
          text: l,
          tokens: this.lexer.inline(l),
          header: !1,
          align: a.align[c]
        })));
      return a;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const r = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: t[1]
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && this.rules.other.startATag.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const r = t[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(r)) {
        if (!this.rules.other.endAngleBracket.test(r))
          return;
        const a = mi(r.slice(0, -1), "\\");
        if ((r.length - a.length) % 2 === 0)
          return;
      } else {
        const a = ak(t[2], "()");
        if (a === -2)
          return;
        if (a > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + a;
          t[2] = t[2].substring(0, a), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], n = "";
      if (this.options.pedantic) {
        const a = this.rules.other.pedanticHrefTitle.exec(i);
        a && (i = a[1], n = a[3]);
      } else
        n = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), this.rules.other.startAngleBracket.test(i) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(r) ? i = i.slice(1) : i = i.slice(1, -1)), Xc(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: n && n.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer, this.rules);
    }
  }
  reflink(e, t) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      const i = (r[2] || r[1]).replace(this.rules.other.multipleSpaceGlobal, " "), n = t[i.toLowerCase()];
      if (!n) {
        const a = r[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return Xc(r, n, r[0], this.lexer, this.rules);
    }
  }
  emStrong(e, t, r = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && r.match(this.rules.other.unicodeAlphaNumeric)) return;
    if (!(i[1] || i[2] || "") || !r || this.rules.inline.punctuation.exec(r)) {
      const a = [...i[0]].length - 1;
      let o, s, l = a, c = 0;
      const h = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (h.lastIndex = 0, t = t.slice(-1 * e.length + a); (i = h.exec(t)) != null; ) {
        if (o = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !o) continue;
        if (s = [...o].length, i[3] || i[4]) {
          l += s;
          continue;
        } else if ((i[5] || i[6]) && a % 3 && !((a + s) % 3)) {
          c += s;
          continue;
        }
        if (l -= s, l > 0) continue;
        s = Math.min(s, s + l + c);
        const u = [...i[0]][0].length, f = e.slice(0, a + i.index + u + s);
        if (Math.min(a, s) % 2) {
          const g = f.slice(1, -1);
          return {
            type: "em",
            raw: f,
            text: g,
            tokens: this.lexer.inlineTokens(g)
          };
        }
        const p = f.slice(2, -2);
        return {
          type: "strong",
          raw: f,
          text: p,
          tokens: this.lexer.inlineTokens(p)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let r = t[2].replace(this.rules.other.newLineCharGlobal, " ");
      const i = this.rules.other.nonSpaceChar.test(r), n = this.rules.other.startingSpaceChar.test(r) && this.rules.other.endingSpaceChar.test(r);
      return i && n && (r = r.substring(1, r.length - 1)), {
        type: "codespan",
        raw: t[0],
        text: r
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let r, i;
      return t[2] === "@" ? (r = t[1], i = "mailto:" + r) : (r = t[1], i = r), {
        type: "link",
        raw: t[0],
        text: r,
        href: i,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  url(e) {
    var r;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, n;
      if (t[2] === "@")
        i = t[0], n = "mailto:" + i;
      else {
        let a;
        do
          a = t[0], t[0] = ((r = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : r[0]) ?? "";
        while (a !== t[0]);
        i = t[0], t[1] === "www." ? n = "http://" + t[0] : n = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: n,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      const r = this.lexer.state.inRawBlock;
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        escaped: r
      };
    }
  }
}, De = class eo {
  constructor(t) {
    gt(this, "tokens");
    gt(this, "options");
    gt(this, "state");
    gt(this, "tokenizer");
    gt(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || _r, this.options.tokenizer = this.options.tokenizer || new ca(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const r = {
      other: Ut,
      block: mn.normal,
      inline: gi.normal
    };
    this.options.pedantic ? (r.block = mn.pedantic, r.inline = gi.pedantic) : this.options.gfm && (r.block = mn.gfm, this.options.breaks ? r.inline = gi.breaks : r.inline = gi.gfm), this.tokenizer.rules = r;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: mn,
      inline: gi
    };
  }
  /**
   * Static Lex Method
   */
  static lex(t, r) {
    return new eo(r).lex(t);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(t, r) {
    return new eo(r).inlineTokens(t);
  }
  /**
   * Preprocessing
   */
  lex(t) {
    t = t.replace(Ut.carriageReturn, `
`), this.blockTokens(t, this.tokens);
    for (let r = 0; r < this.inlineQueue.length; r++) {
      const i = this.inlineQueue[r];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, r = [], i = !1) {
    var n, a, o;
    for (this.options.pedantic && (t = t.replace(Ut.tabCharGlobal, "    ").replace(Ut.spaceLine, "")); t; ) {
      let s;
      if ((a = (n = this.options.extensions) == null ? void 0 : n.block) != null && a.some((c) => (s = c.call({ lexer: this }, t, r)) ? (t = t.substring(s.raw.length), r.push(s), !0) : !1))
        continue;
      if (s = this.tokenizer.space(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        s.raw.length === 1 && c !== void 0 ? c.raw += `
` : r.push(s);
        continue;
      }
      if (s = this.tokenizer.code(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        (c == null ? void 0 : c.type) === "paragraph" || (c == null ? void 0 : c.type) === "text" ? (c.raw += `
` + s.raw, c.text += `
` + s.text, this.inlineQueue.at(-1).src = c.text) : r.push(s);
        continue;
      }
      if (s = this.tokenizer.fences(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.heading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.hr(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.blockquote(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.list(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.html(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.def(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        (c == null ? void 0 : c.type) === "paragraph" || (c == null ? void 0 : c.type) === "text" ? (c.raw += `
` + s.raw, c.text += `
` + s.raw, this.inlineQueue.at(-1).src = c.text) : this.tokens.links[s.tag] || (this.tokens.links[s.tag] = {
          href: s.href,
          title: s.title
        });
        continue;
      }
      if (s = this.tokenizer.table(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.lheading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      let l = t;
      if ((o = this.options.extensions) != null && o.startBlock) {
        let c = 1 / 0;
        const h = t.slice(1);
        let u;
        this.options.extensions.startBlock.forEach((f) => {
          u = f.call({ lexer: this }, h), typeof u == "number" && u >= 0 && (c = Math.min(c, u));
        }), c < 1 / 0 && c >= 0 && (l = t.substring(0, c + 1));
      }
      if (this.state.top && (s = this.tokenizer.paragraph(l))) {
        const c = r.at(-1);
        i && (c == null ? void 0 : c.type) === "paragraph" ? (c.raw += `
` + s.raw, c.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = c.text) : r.push(s), i = l.length !== t.length, t = t.substring(s.raw.length);
        continue;
      }
      if (s = this.tokenizer.text(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        (c == null ? void 0 : c.type) === "text" ? (c.raw += `
` + s.raw, c.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = c.text) : r.push(s);
        continue;
      }
      if (t) {
        const c = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(c);
          break;
        } else
          throw new Error(c);
      }
    }
    return this.state.top = !0, r;
  }
  inline(t, r = []) {
    return this.inlineQueue.push({ src: t, tokens: r }), r;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(t, r = []) {
    var s, l, c;
    let i = t, n = null;
    if (this.tokens.links) {
      const h = Object.keys(this.tokens.links);
      if (h.length > 0)
        for (; (n = this.tokenizer.rules.inline.reflinkSearch.exec(i)) != null; )
          h.includes(n[0].slice(n[0].lastIndexOf("[") + 1, -1)) && (i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (n = this.tokenizer.rules.inline.anyPunctuation.exec(i)) != null; )
      i = i.slice(0, n.index) + "++" + i.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; (n = this.tokenizer.rules.inline.blockSkip.exec(i)) != null; )
      i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    let a = !1, o = "";
    for (; t; ) {
      a || (o = ""), a = !1;
      let h;
      if ((l = (s = this.options.extensions) == null ? void 0 : s.inline) != null && l.some((f) => (h = f.call({ lexer: this }, t, r)) ? (t = t.substring(h.raw.length), r.push(h), !0) : !1))
        continue;
      if (h = this.tokenizer.escape(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.tag(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.link(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.reflink(t, this.tokens.links)) {
        t = t.substring(h.raw.length);
        const f = r.at(-1);
        h.type === "text" && (f == null ? void 0 : f.type) === "text" ? (f.raw += h.raw, f.text += h.text) : r.push(h);
        continue;
      }
      if (h = this.tokenizer.emStrong(t, i, o)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.codespan(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.br(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.del(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.autolink(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (!this.state.inLink && (h = this.tokenizer.url(t))) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      let u = t;
      if ((c = this.options.extensions) != null && c.startInline) {
        let f = 1 / 0;
        const p = t.slice(1);
        let g;
        this.options.extensions.startInline.forEach((m) => {
          g = m.call({ lexer: this }, p), typeof g == "number" && g >= 0 && (f = Math.min(f, g));
        }), f < 1 / 0 && f >= 0 && (u = t.substring(0, f + 1));
      }
      if (h = this.tokenizer.inlineText(u)) {
        t = t.substring(h.raw.length), h.raw.slice(-1) !== "_" && (o = h.raw.slice(-1)), a = !0;
        const f = r.at(-1);
        (f == null ? void 0 : f.type) === "text" ? (f.raw += h.raw, f.text += h.text) : r.push(h);
        continue;
      }
      if (t) {
        const f = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(f);
          break;
        } else
          throw new Error(f);
      }
    }
    return r;
  }
}, ha = class {
  // set by the parser
  constructor(e) {
    gt(this, "options");
    gt(this, "parser");
    this.options = e || _r;
  }
  space(e) {
    return "";
  }
  code({ text: e, lang: t, escaped: r }) {
    var a;
    const i = (a = (t || "").match(Ut.notSpaceStart)) == null ? void 0 : a[0], n = e.replace(Ut.endingNewline, "") + `
`;
    return i ? '<pre><code class="language-' + xe(i) + '">' + (r ? n : xe(n, !0)) + `</code></pre>
` : "<pre><code>" + (r ? n : xe(n, !0)) + `</code></pre>
`;
  }
  blockquote({ tokens: e }) {
    return `<blockquote>
${this.parser.parse(e)}</blockquote>
`;
  }
  html({ text: e }) {
    return e;
  }
  heading({ tokens: e, depth: t }) {
    return `<h${t}>${this.parser.parseInline(e)}</h${t}>
`;
  }
  hr(e) {
    return `<hr>
`;
  }
  list(e) {
    const t = e.ordered, r = e.start;
    let i = "";
    for (let o = 0; o < e.items.length; o++) {
      const s = e.items[o];
      i += this.listitem(s);
    }
    const n = t ? "ol" : "ul", a = t && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + n + a + `>
` + i + "</" + n + `>
`;
  }
  listitem(e) {
    var r;
    let t = "";
    if (e.task) {
      const i = this.checkbox({ checked: !!e.checked });
      e.loose ? ((r = e.tokens[0]) == null ? void 0 : r.type) === "paragraph" ? (e.tokens[0].text = i + " " + e.tokens[0].text, e.tokens[0].tokens && e.tokens[0].tokens.length > 0 && e.tokens[0].tokens[0].type === "text" && (e.tokens[0].tokens[0].text = i + " " + xe(e.tokens[0].tokens[0].text), e.tokens[0].tokens[0].escaped = !0)) : e.tokens.unshift({
        type: "text",
        raw: i + " ",
        text: i + " ",
        escaped: !0
      }) : t += i + " ";
    }
    return t += this.parser.parse(e.tokens, !!e.loose), `<li>${t}</li>
`;
  }
  checkbox({ checked: e }) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens: e }) {
    return `<p>${this.parser.parseInline(e)}</p>
`;
  }
  table(e) {
    let t = "", r = "";
    for (let n = 0; n < e.header.length; n++)
      r += this.tablecell(e.header[n]);
    t += this.tablerow({ text: r });
    let i = "";
    for (let n = 0; n < e.rows.length; n++) {
      const a = e.rows[n];
      r = "";
      for (let o = 0; o < a.length; o++)
        r += this.tablecell(a[o]);
      i += this.tablerow({ text: r });
    }
    return i && (i = `<tbody>${i}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + i + `</table>
`;
  }
  tablerow({ text: e }) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e) {
    const t = this.parser.parseInline(e.tokens), r = e.header ? "th" : "td";
    return (e.align ? `<${r} align="${e.align}">` : `<${r}>`) + t + `</${r}>
`;
  }
  /**
   * span level renderer
   */
  strong({ tokens: e }) {
    return `<strong>${this.parser.parseInline(e)}</strong>`;
  }
  em({ tokens: e }) {
    return `<em>${this.parser.parseInline(e)}</em>`;
  }
  codespan({ text: e }) {
    return `<code>${xe(e, !0)}</code>`;
  }
  br(e) {
    return "<br>";
  }
  del({ tokens: e }) {
    return `<del>${this.parser.parseInline(e)}</del>`;
  }
  link({ href: e, title: t, tokens: r }) {
    const i = this.parser.parseInline(r), n = Uc(e);
    if (n === null)
      return i;
    e = n;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + xe(t) + '"'), a += ">" + i + "</a>", a;
  }
  image({ href: e, title: t, text: r, tokens: i }) {
    i && (r = this.parser.parseInline(i, this.parser.textRenderer));
    const n = Uc(e);
    if (n === null)
      return xe(r);
    e = n;
    let a = `<img src="${e}" alt="${r}"`;
    return t && (a += ` title="${xe(t)}"`), a += ">", a;
  }
  text(e) {
    return "tokens" in e && e.tokens ? this.parser.parseInline(e.tokens) : "escaped" in e && e.escaped ? e.text : xe(e.text);
  }
}, fl = class {
  // no need for block level renderers
  strong({ text: e }) {
    return e;
  }
  em({ text: e }) {
    return e;
  }
  codespan({ text: e }) {
    return e;
  }
  del({ text: e }) {
    return e;
  }
  html({ text: e }) {
    return e;
  }
  text({ text: e }) {
    return e;
  }
  link({ text: e }) {
    return "" + e;
  }
  image({ text: e }) {
    return "" + e;
  }
  br() {
    return "";
  }
}, Oe = class ro {
  constructor(t) {
    gt(this, "options");
    gt(this, "renderer");
    gt(this, "textRenderer");
    this.options = t || _r, this.options.renderer = this.options.renderer || new ha(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new fl();
  }
  /**
   * Static Parse Method
   */
  static parse(t, r) {
    return new ro(r).parse(t);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(t, r) {
    return new ro(r).parseInline(t);
  }
  /**
   * Parse Loop
   */
  parse(t, r = !0) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      const s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        const c = s, h = this.options.extensions.renderers[c.type].call({ parser: this }, c);
        if (h !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(c.type)) {
          i += h || "";
          continue;
        }
      }
      const l = s;
      switch (l.type) {
        case "space": {
          i += this.renderer.space(l);
          continue;
        }
        case "hr": {
          i += this.renderer.hr(l);
          continue;
        }
        case "heading": {
          i += this.renderer.heading(l);
          continue;
        }
        case "code": {
          i += this.renderer.code(l);
          continue;
        }
        case "table": {
          i += this.renderer.table(l);
          continue;
        }
        case "blockquote": {
          i += this.renderer.blockquote(l);
          continue;
        }
        case "list": {
          i += this.renderer.list(l);
          continue;
        }
        case "html": {
          i += this.renderer.html(l);
          continue;
        }
        case "paragraph": {
          i += this.renderer.paragraph(l);
          continue;
        }
        case "text": {
          let c = l, h = this.renderer.text(c);
          for (; o + 1 < t.length && t[o + 1].type === "text"; )
            c = t[++o], h += `
` + this.renderer.text(c);
          r ? i += this.renderer.paragraph({
            type: "paragraph",
            raw: h,
            text: h,
            tokens: [{ type: "text", raw: h, text: h, escaped: !0 }]
          }) : i += h;
          continue;
        }
        default: {
          const c = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(c), "";
          throw new Error(c);
        }
      }
    }
    return i;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(t, r = this.renderer) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      const s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        const c = this.options.extensions.renderers[s.type].call({ parser: this }, s);
        if (c !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(s.type)) {
          i += c || "";
          continue;
        }
      }
      const l = s;
      switch (l.type) {
        case "escape": {
          i += r.text(l);
          break;
        }
        case "html": {
          i += r.html(l);
          break;
        }
        case "link": {
          i += r.link(l);
          break;
        }
        case "image": {
          i += r.image(l);
          break;
        }
        case "strong": {
          i += r.strong(l);
          break;
        }
        case "em": {
          i += r.em(l);
          break;
        }
        case "codespan": {
          i += r.codespan(l);
          break;
        }
        case "br": {
          i += r.br(l);
          break;
        }
        case "del": {
          i += r.del(l);
          break;
        }
        case "text": {
          i += r.text(l);
          break;
        }
        default: {
          const c = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(c), "";
          throw new Error(c);
        }
      }
    }
    return i;
  }
}, Cs, Mn = (Cs = class {
  constructor(e) {
    gt(this, "options");
    gt(this, "block");
    this.options = e || _r;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
  /**
   * Provide function to tokenize markdown
   */
  provideLexer() {
    return this.block ? De.lex : De.lexInline;
  }
  /**
   * Provide function to parse tokens
   */
  provideParser() {
    return this.block ? Oe.parse : Oe.parseInline;
  }
}, gt(Cs, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
])), Cs), ok = class {
  constructor(...e) {
    gt(this, "defaults", nl());
    gt(this, "options", this.setOptions);
    gt(this, "parse", this.parseMarkdown(!0));
    gt(this, "parseInline", this.parseMarkdown(!1));
    gt(this, "Parser", Oe);
    gt(this, "Renderer", ha);
    gt(this, "TextRenderer", fl);
    gt(this, "Lexer", De);
    gt(this, "Tokenizer", ca);
    gt(this, "Hooks", Mn);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, n;
    let r = [];
    for (const a of e)
      switch (r = r.concat(t.call(this, a)), a.type) {
        case "table": {
          const o = a;
          for (const s of o.header)
            r = r.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const l of s)
              r = r.concat(this.walkTokens(l.tokens, t));
          break;
        }
        case "list": {
          const o = a;
          r = r.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = a;
          (n = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && n[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const l = o[s].flat(1 / 0);
            r = r.concat(this.walkTokens(l, t));
          }) : o.tokens && (r = r.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return r;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      const i = { ...r };
      if (i.async = this.defaults.async || i.async || !1, r.extensions && (r.extensions.forEach((n) => {
        if (!n.name)
          throw new Error("extension name required");
        if ("renderer" in n) {
          const a = t.renderers[n.name];
          a ? t.renderers[n.name] = function(...o) {
            let s = n.renderer.apply(this, o);
            return s === !1 && (s = a.apply(this, o)), s;
          } : t.renderers[n.name] = n.renderer;
        }
        if ("tokenizer" in n) {
          if (!n.level || n.level !== "block" && n.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = t[n.level];
          a ? a.unshift(n.tokenizer) : t[n.level] = [n.tokenizer], n.start && (n.level === "block" ? t.startBlock ? t.startBlock.push(n.start) : t.startBlock = [n.start] : n.level === "inline" && (t.startInline ? t.startInline.push(n.start) : t.startInline = [n.start]));
        }
        "childTokens" in n && n.childTokens && (t.childTokens[n.name] = n.childTokens);
      }), i.extensions = t), r.renderer) {
        const n = this.defaults.renderer || new ha(this.defaults);
        for (const a in r.renderer) {
          if (!(a in n))
            throw new Error(`renderer '${a}' does not exist`);
          if (["options", "parser"].includes(a))
            continue;
          const o = a, s = r.renderer[o], l = n[o];
          n[o] = (...c) => {
            let h = s.apply(n, c);
            return h === !1 && (h = l.apply(n, c)), h || "";
          };
        }
        i.renderer = n;
      }
      if (r.tokenizer) {
        const n = this.defaults.tokenizer || new ca(this.defaults);
        for (const a in r.tokenizer) {
          if (!(a in n))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const o = a, s = r.tokenizer[o], l = n[o];
          n[o] = (...c) => {
            let h = s.apply(n, c);
            return h === !1 && (h = l.apply(n, c)), h;
          };
        }
        i.tokenizer = n;
      }
      if (r.hooks) {
        const n = this.defaults.hooks || new Mn();
        for (const a in r.hooks) {
          if (!(a in n))
            throw new Error(`hook '${a}' does not exist`);
          if (["options", "block"].includes(a))
            continue;
          const o = a, s = r.hooks[o], l = n[o];
          Mn.passThroughHooks.has(a) ? n[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(n, c)).then((u) => l.call(n, u));
            const h = s.call(n, c);
            return l.call(n, h);
          } : n[o] = (...c) => {
            let h = s.apply(n, c);
            return h === !1 && (h = l.apply(n, c)), h;
          };
        }
        i.hooks = n;
      }
      if (r.walkTokens) {
        const n = this.defaults.walkTokens, a = r.walkTokens;
        i.walkTokens = function(o) {
          let s = [];
          return s.push(a.call(this, o)), n && (s = s.concat(n.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return De.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Oe.parse(e, t ?? this.defaults);
  }
  parseMarkdown(e) {
    return (r, i) => {
      const n = { ...i }, a = { ...this.defaults, ...n }, o = this.onError(!!a.silent, !!a.async);
      if (this.defaults.async === !0 && n.async === !1)
        return o(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof r > "u" || r === null)
        return o(new Error("marked(): input parameter is undefined or null"));
      if (typeof r != "string")
        return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
      a.hooks && (a.hooks.options = a, a.hooks.block = e);
      const s = a.hooks ? a.hooks.provideLexer() : e ? De.lex : De.lexInline, l = a.hooks ? a.hooks.provideParser() : e ? Oe.parse : Oe.parseInline;
      if (a.async)
        return Promise.resolve(a.hooks ? a.hooks.preprocess(r) : r).then((c) => s(c, a)).then((c) => a.hooks ? a.hooks.processAllTokens(c) : c).then((c) => a.walkTokens ? Promise.all(this.walkTokens(c, a.walkTokens)).then(() => c) : c).then((c) => l(c, a)).then((c) => a.hooks ? a.hooks.postprocess(c) : c).catch(o);
      try {
        a.hooks && (r = a.hooks.preprocess(r));
        let c = s(r, a);
        a.hooks && (c = a.hooks.processAllTokens(c)), a.walkTokens && this.walkTokens(c, a.walkTokens);
        let h = l(c, a);
        return a.hooks && (h = a.hooks.postprocess(h)), h;
      } catch (c) {
        return o(c);
      }
    };
  }
  onError(e, t) {
    return (r) => {
      if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
        const i = "<p>An error occurred:</p><pre>" + xe(r.message + "", !0) + "</pre>";
        return t ? Promise.resolve(i) : i;
      }
      if (t)
        return Promise.reject(r);
      throw r;
    };
  }
}, gr = new ok();
function ft(e, t) {
  return gr.parse(e, t);
}
ft.options = ft.setOptions = function(e) {
  return gr.setOptions(e), ft.defaults = gr.defaults, Up(ft.defaults), ft;
};
ft.getDefaults = nl;
ft.defaults = _r;
ft.use = function(...e) {
  return gr.use(...e), ft.defaults = gr.defaults, Up(ft.defaults), ft;
};
ft.walkTokens = function(e, t) {
  return gr.walkTokens(e, t);
};
ft.parseInline = gr.parseInline;
ft.Parser = Oe;
ft.parser = Oe.parse;
ft.Renderer = ha;
ft.TextRenderer = fl;
ft.Lexer = De;
ft.lexer = De.lex;
ft.Tokenizer = ca;
ft.Hooks = Mn;
ft.parse = ft;
ft.options;
ft.setOptions;
ft.use;
ft.walkTokens;
ft.parseInline;
Oe.parse;
De.lex;
function id(e) {
  for (var t = [], r = 1; r < arguments.length; r++)
    t[r - 1] = arguments[r];
  var i = Array.from(typeof e == "string" ? [e] : e);
  i[i.length - 1] = i[i.length - 1].replace(/\r?\n([\t ]*)$/, "");
  var n = i.reduce(function(s, l) {
    var c = l.match(/\n([\t ]+|(?!\s).)/g);
    return c ? s.concat(c.map(function(h) {
      var u, f;
      return (f = (u = h.match(/[\t ]/g)) === null || u === void 0 ? void 0 : u.length) !== null && f !== void 0 ? f : 0;
    })) : s;
  }, []);
  if (n.length) {
    var a = new RegExp(`
[	 ]{` + Math.min.apply(Math, n) + "}", "g");
    i = i.map(function(s) {
      return s.replace(a, `
`);
    });
  }
  i[0] = i[0].replace(/^\r?\n/, "");
  var o = i[0];
  return t.forEach(function(s, l) {
    var c = o.match(/(?:^|\n)( *)$/), h = c ? c[1] : "", u = s;
    typeof s == "string" && s.includes(`
`) && (u = String(s).split(`
`).map(function(f, p) {
      return p === 0 ? f : "" + h + f;
    }).join(`
`)), o += u + i[l + 1];
  }), o;
}
var lk = {
  body: '<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/><text transform="translate(21.16 64.67)" style="fill: #fff; font-family: ArialMT, Arial; font-size: 67.75px;"><tspan x="0" y="0">?</tspan></text></g>',
  height: 80,
  width: 80
}, io = /* @__PURE__ */ new Map(), nd = /* @__PURE__ */ new Map(), ck = /* @__PURE__ */ d((e) => {
  for (const t of e) {
    if (!t.name)
      throw new Error(
        'Invalid icon loader. Must have a "name" property with non-empty string value.'
      );
    if (F.debug("Registering icon pack:", t.name), "loader" in t)
      nd.set(t.name, t.loader);
    else if ("icons" in t)
      io.set(t.name, t.icons);
    else
      throw F.error("Invalid icon loader:", t), new Error('Invalid icon loader. Must have either "icons" or "loader" property.');
  }
}, "registerIconPacks"), ad = /* @__PURE__ */ d(async (e, t) => {
  const r = hv(e, !0, t !== void 0);
  if (!r)
    throw new Error(`Invalid icon name: ${e}`);
  const i = r.prefix || t;
  if (!i)
    throw new Error(`Icon name must contain a prefix: ${e}`);
  let n = io.get(i);
  if (!n) {
    const o = nd.get(i);
    if (!o)
      throw new Error(`Icon set not found: ${r.prefix}`);
    try {
      n = { ...await o(), prefix: i }, io.set(i, n);
    } catch (s) {
      throw F.error(s), new Error(`Failed to load icon set: ${r.prefix}`);
    }
  }
  const a = pv(n, r.name);
  if (!a)
    throw new Error(`Icon not found: ${e}`);
  return a;
}, "getRegisteredIconData"), hk = /* @__PURE__ */ d(async (e) => {
  try {
    return await ad(e), !0;
  } catch {
    return !1;
  }
}, "isIconAvailable"), en = /* @__PURE__ */ d(async (e, t, r) => {
  let i;
  try {
    i = await ad(e, t == null ? void 0 : t.fallbackPrefix);
  } catch (o) {
    F.error(o), i = lk;
  }
  const n = Cv(i, t), a = Sv(kv(n.body), {
    ...n.attributes,
    ...r
  });
  return se(a, Pt());
}, "getIconSVG");
function sd(e, { markdownAutoWrap: t }) {
  const i = e.replace(/<br\/>/g, `
`).replace(/\n{2,}/g, `
`), n = id(i);
  return t === !1 ? n.replace(/ /g, "&nbsp;") : n;
}
d(sd, "preprocessMarkdown");
function od(e, t = {}) {
  const r = sd(e, t), i = ft.lexer(r), n = [[]];
  let a = 0;
  function o(s, l = "normal") {
    s.type === "text" ? s.text.split(`
`).forEach((h, u) => {
      u !== 0 && (a++, n.push([])), h.split(" ").forEach((f) => {
        f = f.replace(/&#39;/g, "'"), f && n[a].push({ content: f, type: l });
      });
    }) : s.type === "strong" || s.type === "em" ? s.tokens.forEach((c) => {
      o(c, s.type);
    }) : s.type === "html" && n[a].push({ content: s.text, type: "normal" });
  }
  return d(o, "processNode"), i.forEach((s) => {
    var l;
    s.type === "paragraph" ? (l = s.tokens) == null || l.forEach((c) => {
      o(c);
    }) : s.type === "html" ? n[a].push({ content: s.text, type: "normal" }) : n[a].push({ content: s.raw, type: "normal" });
  }), n;
}
d(od, "markdownToLines");
function ld(e, { markdownAutoWrap: t } = {}) {
  const r = ft.lexer(e);
  function i(n) {
    var a, o, s;
    return n.type === "text" ? t === !1 ? n.text.replace(/\n */g, "<br/>").replace(/ /g, "&nbsp;") : n.text.replace(/\n */g, "<br/>") : n.type === "strong" ? `<strong>${(a = n.tokens) == null ? void 0 : a.map(i).join("")}</strong>` : n.type === "em" ? `<em>${(o = n.tokens) == null ? void 0 : o.map(i).join("")}</em>` : n.type === "paragraph" ? `<p>${(s = n.tokens) == null ? void 0 : s.map(i).join("")}</p>` : n.type === "space" ? "" : n.type === "html" ? `${n.text}` : n.type === "escape" ? n.text : (F.warn(`Unsupported markdown: ${n.type}`), n.raw);
  }
  return d(i, "output"), r.map(i).join("");
}
d(ld, "markdownToHTML");
function cd(e) {
  return Intl.Segmenter ? [...new Intl.Segmenter().segment(e)].map((t) => t.segment) : [...e];
}
d(cd, "splitTextToChars");
function hd(e, t) {
  const r = cd(t.content);
  return pl(e, [], r, t.type);
}
d(hd, "splitWordToFitWidth");
function pl(e, t, r, i) {
  if (r.length === 0)
    return [
      { content: t.join(""), type: i },
      { content: "", type: i }
    ];
  const [n, ...a] = r, o = [...t, n];
  return e([{ content: o.join(""), type: i }]) ? pl(e, o, a, i) : (t.length === 0 && n && (t.push(n), r.shift()), [
    { content: t.join(""), type: i },
    { content: r.join(""), type: i }
  ]);
}
d(pl, "splitWordToFitWidthRecursion");
function ud(e, t) {
  if (e.some(({ content: r }) => r.includes(`
`)))
    throw new Error("splitLineToFitWidth does not support newlines in the line");
  return ua(e, t);
}
d(ud, "splitLineToFitWidth");
function ua(e, t, r = [], i = []) {
  if (e.length === 0)
    return i.length > 0 && r.push(i), r.length > 0 ? r : [];
  let n = "";
  e[0].content === " " && (n = " ", e.shift());
  const a = e.shift() ?? { content: " ", type: "normal" }, o = [...i];
  if (n !== "" && o.push({ content: n, type: "normal" }), o.push(a), t(o))
    return ua(e, t, r, o);
  if (i.length > 0)
    r.push(i), e.unshift(a);
  else if (a.content) {
    const [s, l] = hd(t, a);
    r.push([s]), l.content && e.unshift(l);
  }
  return ua(e, t, r);
}
d(ua, "splitLineToFitWidthRecursion");
function no(e, t) {
  t && e.attr("style", t);
}
d(no, "applyStyle");
async function fd(e, t, r, i, n = !1, a = Pt()) {
  const o = e.append("foreignObject");
  o.attr("width", `${10 * r}px`), o.attr("height", `${10 * r}px`);
  const s = o.append("xhtml:div"), l = Ur(t.label) ? await _o(t.label.replace(Jr.lineBreakRegex, `
`), a) : se(t.label, a), c = t.isNode ? "nodeLabel" : "edgeLabel", h = s.append("span");
  h.html(l), no(h, t.labelStyle), h.attr("class", `${c} ${i}`), no(s, t.labelStyle), s.style("display", "table-cell"), s.style("white-space", "nowrap"), s.style("line-height", "1.5"), s.style("max-width", r + "px"), s.style("text-align", "center"), s.attr("xmlns", "http://www.w3.org/1999/xhtml"), n && s.attr("class", "labelBkg");
  let u = s.node().getBoundingClientRect();
  return u.width === r && (s.style("display", "table"), s.style("white-space", "break-spaces"), s.style("width", r + "px"), u = s.node().getBoundingClientRect()), o.node();
}
d(fd, "addHtmlSpan");
function Ia(e, t, r) {
  return e.append("tspan").attr("class", "text-outer-tspan").attr("x", 0).attr("y", t * r - 0.1 + "em").attr("dy", r + "em");
}
d(Ia, "createTspan");
function pd(e, t, r) {
  const i = e.append("text"), n = Ia(i, 1, t);
  Pa(n, r);
  const a = n.node().getComputedTextLength();
  return i.remove(), a;
}
d(pd, "computeWidthOfText");
function uk(e, t, r) {
  var o;
  const i = e.append("text"), n = Ia(i, 1, t);
  Pa(n, [{ content: r, type: "normal" }]);
  const a = (o = n.node()) == null ? void 0 : o.getBoundingClientRect();
  return a && i.remove(), a;
}
d(uk, "computeDimensionOfText");
function dd(e, t, r, i = !1) {
  const a = t.append("g"), o = a.insert("rect").attr("class", "background").attr("style", "stroke: none"), s = a.append("text").attr("y", "-10.1");
  let l = 0;
  for (const c of r) {
    const h = /* @__PURE__ */ d((f) => pd(a, 1.1, f) <= e, "checkWidth"), u = h(c) ? [c] : ud(c, h);
    for (const f of u) {
      const p = Ia(s, l, 1.1);
      Pa(p, f), l++;
    }
  }
  if (i) {
    const c = s.node().getBBox(), h = 2;
    return o.attr("x", c.x - h).attr("y", c.y - h).attr("width", c.width + 2 * h).attr("height", c.height + 2 * h), a.node();
  } else
    return s.node();
}
d(dd, "createFormattedText");
function Pa(e, t) {
  e.text(""), t.forEach((r, i) => {
    const n = e.append("tspan").attr("font-style", r.type === "em" ? "italic" : "normal").attr("class", "text-inner-tspan").attr("font-weight", r.type === "strong" ? "bold" : "normal");
    i === 0 ? n.text(r.content) : n.text(" " + r.content);
  });
}
d(Pa, "updateTextContentAndStyles");
async function gd(e, t = {}) {
  const r = [];
  e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, (n, a, o) => (r.push(
    (async () => {
      const s = `${a}:${o}`;
      return await hk(s) ? await en(s, void 0, { class: "label-icon" }) : `<i class='${se(n, t).replace(":", " ")}'></i>`;
    })()
  ), n));
  const i = await Promise.all(r);
  return e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, () => i.shift() ?? "");
}
d(gd, "replaceIconSubstring");
var Ze = /* @__PURE__ */ d(async (e, t = "", {
  style: r = "",
  isTitle: i = !1,
  classes: n = "",
  useHtmlLabels: a = !0,
  isNode: o = !0,
  width: s = 200,
  addSvgBackground: l = !1
} = {}, c) => {
  if (F.debug(
    "XYZ createText",
    t,
    r,
    i,
    n,
    a,
    o,
    "addSvgBackground: ",
    l
  ), a) {
    const h = ld(t, c), u = await gd(Cr(h), c), f = t.replace(/\\\\/g, "\\"), p = {
      isNode: o,
      label: Ur(t) ? f : u,
      labelStyle: r.replace("fill:", "color:")
    };
    return await fd(e, p, s, n, l, c);
  } else {
    const h = t.replace(/<br\s*\/?>/g, "<br/>"), u = od(h.replace("<br>", "<br/>"), c), f = dd(
      s,
      e,
      u,
      t ? l : !1
    );
    if (o) {
      /stroke:/.exec(r) && (r = r.replace("stroke:", "lineColor:"));
      const p = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      ht(f).attr("style", p);
    } else {
      const p = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/background:/g, "fill:");
      ht(f).select("rect").attr("style", p.replace(/background:/g, "fill:"));
      const g = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      ht(f).select("text").attr("style", g);
    }
    return f;
  }
}, "createText");
function fs(e, t, r) {
  if (e && e.length) {
    const [i, n] = t, a = Math.PI / 180 * r, o = Math.cos(a), s = Math.sin(a);
    for (const l of e) {
      const [c, h] = l;
      l[0] = (c - i) * o - (h - n) * s + i, l[1] = (c - i) * s + (h - n) * o + n;
    }
  }
}
function fk(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}
function pk(e, t, r, i = 1) {
  const n = r, a = Math.max(t, 0.1), o = e[0] && e[0][0] && typeof e[0][0] == "number" ? [e] : e, s = [0, 0];
  if (n) for (const c of o) fs(c, s, n);
  const l = function(c, h, u) {
    const f = [];
    for (const b of c) {
      const _ = [...b];
      fk(_[0], _[_.length - 1]) || _.push([_[0][0], _[0][1]]), _.length > 2 && f.push(_);
    }
    const p = [];
    h = Math.max(h, 0.1);
    const g = [];
    for (const b of f) for (let _ = 0; _ < b.length - 1; _++) {
      const k = b[_], v = b[_ + 1];
      if (k[1] !== v[1]) {
        const C = Math.min(k[1], v[1]);
        g.push({ ymin: C, ymax: Math.max(k[1], v[1]), x: C === k[1] ? k[0] : v[0], islope: (v[0] - k[0]) / (v[1] - k[1]) });
      }
    }
    if (g.sort((b, _) => b.ymin < _.ymin ? -1 : b.ymin > _.ymin ? 1 : b.x < _.x ? -1 : b.x > _.x ? 1 : b.ymax === _.ymax ? 0 : (b.ymax - _.ymax) / Math.abs(b.ymax - _.ymax)), !g.length) return p;
    let m = [], x = g[0].ymin, y = 0;
    for (; m.length || g.length; ) {
      if (g.length) {
        let b = -1;
        for (let _ = 0; _ < g.length && !(g[_].ymin > x); _++) b = _;
        g.splice(0, b + 1).forEach((_) => {
          m.push({ s: x, edge: _ });
        });
      }
      if (m = m.filter((b) => !(b.edge.ymax <= x)), m.sort((b, _) => b.edge.x === _.edge.x ? 0 : (b.edge.x - _.edge.x) / Math.abs(b.edge.x - _.edge.x)), (u !== 1 || y % h == 0) && m.length > 1) for (let b = 0; b < m.length; b += 2) {
        const _ = b + 1;
        if (_ >= m.length) break;
        const k = m[b].edge, v = m[_].edge;
        p.push([[Math.round(k.x), x], [Math.round(v.x), x]]);
      }
      x += u, m.forEach((b) => {
        b.edge.x = b.edge.x + u * b.edge.islope;
      }), y++;
    }
    return p;
  }(o, a, i);
  if (n) {
    for (const c of o) fs(c, s, -n);
    (function(c, h, u) {
      const f = [];
      c.forEach((p) => f.push(...p)), fs(f, h, u);
    })(l, s, -n);
  }
  return l;
}
function rn(e, t) {
  var r;
  const i = t.hachureAngle + 90;
  let n = t.hachureGap;
  n < 0 && (n = 4 * t.strokeWidth), n = Math.round(Math.max(n, 0.1));
  let a = 1;
  return t.roughness >= 1 && (((r = t.randomizer) === null || r === void 0 ? void 0 : r.next()) || Math.random()) > 0.7 && (a = n), pk(e, n, i, a || 1);
}
class dl {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    return this._fillPolygons(t, r);
  }
  _fillPolygons(t, r) {
    const i = rn(t, r);
    return { type: "fillSketch", ops: this.renderLines(i, r) };
  }
  renderLines(t, r) {
    const i = [];
    for (const n of t) i.push(...this.helper.doubleLineOps(n[0][0], n[0][1], n[1][0], n[1][1], r));
    return i;
  }
}
function Na(e) {
  const t = e[0], r = e[1];
  return Math.sqrt(Math.pow(t[0] - r[0], 2) + Math.pow(t[1] - r[1], 2));
}
class dk extends dl {
  fillPolygons(t, r) {
    let i = r.hachureGap;
    i < 0 && (i = 4 * r.strokeWidth), i = Math.max(i, 0.1);
    const n = rn(t, Object.assign({}, r, { hachureGap: i })), a = Math.PI / 180 * r.hachureAngle, o = [], s = 0.5 * i * Math.cos(a), l = 0.5 * i * Math.sin(a);
    for (const [c, h] of n) Na([c, h]) && o.push([[c[0] - s, c[1] + l], [...h]], [[c[0] + s, c[1] - l], [...h]]);
    return { type: "fillSketch", ops: this.renderLines(o, r) };
  }
}
class gk extends dl {
  fillPolygons(t, r) {
    const i = this._fillPolygons(t, r), n = Object.assign({}, r, { hachureAngle: r.hachureAngle + 90 }), a = this._fillPolygons(t, n);
    return i.ops = i.ops.concat(a.ops), i;
  }
}
class mk {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = rn(t, r = Object.assign({}, r, { hachureAngle: 0 }));
    return this.dotsOnLines(i, r);
  }
  dotsOnLines(t, r) {
    const i = [];
    let n = r.hachureGap;
    n < 0 && (n = 4 * r.strokeWidth), n = Math.max(n, 0.1);
    let a = r.fillWeight;
    a < 0 && (a = r.strokeWidth / 2);
    const o = n / 4;
    for (const s of t) {
      const l = Na(s), c = l / n, h = Math.ceil(c) - 1, u = l - h * n, f = (s[0][0] + s[1][0]) / 2 - n / 4, p = Math.min(s[0][1], s[1][1]);
      for (let g = 0; g < h; g++) {
        const m = p + u + g * n, x = f - o + 2 * Math.random() * o, y = m - o + 2 * Math.random() * o, b = this.helper.ellipse(x, y, a, a, r);
        i.push(...b.ops);
      }
    }
    return { type: "fillSketch", ops: i };
  }
}
class yk {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = rn(t, r);
    return { type: "fillSketch", ops: this.dashedLine(i, r) };
  }
  dashedLine(t, r) {
    const i = r.dashOffset < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashOffset, n = r.dashGap < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashGap, a = [];
    return t.forEach((o) => {
      const s = Na(o), l = Math.floor(s / (i + n)), c = (s + n - l * (i + n)) / 2;
      let h = o[0], u = o[1];
      h[0] > u[0] && (h = o[1], u = o[0]);
      const f = Math.atan((u[1] - h[1]) / (u[0] - h[0]));
      for (let p = 0; p < l; p++) {
        const g = p * (i + n), m = g + i, x = [h[0] + g * Math.cos(f) + c * Math.cos(f), h[1] + g * Math.sin(f) + c * Math.sin(f)], y = [h[0] + m * Math.cos(f) + c * Math.cos(f), h[1] + m * Math.sin(f) + c * Math.sin(f)];
        a.push(...this.helper.doubleLineOps(x[0], x[1], y[0], y[1], r));
      }
    }), a;
  }
}
class xk {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap, n = r.zigzagOffset < 0 ? i : r.zigzagOffset, a = rn(t, r = Object.assign({}, r, { hachureGap: i + n }));
    return { type: "fillSketch", ops: this.zigzagLines(a, n, r) };
  }
  zigzagLines(t, r, i) {
    const n = [];
    return t.forEach((a) => {
      const o = Na(a), s = Math.round(o / (2 * r));
      let l = a[0], c = a[1];
      l[0] > c[0] && (l = a[1], c = a[0]);
      const h = Math.atan((c[1] - l[1]) / (c[0] - l[0]));
      for (let u = 0; u < s; u++) {
        const f = 2 * u * r, p = 2 * (u + 1) * r, g = Math.sqrt(2 * Math.pow(r, 2)), m = [l[0] + f * Math.cos(h), l[1] + f * Math.sin(h)], x = [l[0] + p * Math.cos(h), l[1] + p * Math.sin(h)], y = [m[0] + g * Math.cos(h + Math.PI / 4), m[1] + g * Math.sin(h + Math.PI / 4)];
        n.push(...this.helper.doubleLineOps(m[0], m[1], y[0], y[1], i), ...this.helper.doubleLineOps(y[0], y[1], x[0], x[1], i));
      }
    }), n;
  }
}
const Zt = {};
class bk {
  constructor(t) {
    this.seed = t;
  }
  next() {
    return this.seed ? (2 ** 31 - 1 & (this.seed = Math.imul(48271, this.seed))) / 2 ** 31 : Math.random();
  }
}
const Ck = 0, ps = 1, Vc = 2, yn = { A: 7, a: 7, C: 6, c: 6, H: 1, h: 1, L: 2, l: 2, M: 2, m: 2, Q: 4, q: 4, S: 4, s: 4, T: 2, t: 2, V: 1, v: 1, Z: 0, z: 0 };
function ds(e, t) {
  return e.type === t;
}
function gl(e) {
  const t = [], r = function(o) {
    const s = new Array();
    for (; o !== ""; ) if (o.match(/^([ \t\r\n,]+)/)) o = o.substr(RegExp.$1.length);
    else if (o.match(/^([aAcChHlLmMqQsStTvVzZ])/)) s[s.length] = { type: Ck, text: RegExp.$1 }, o = o.substr(RegExp.$1.length);
    else {
      if (!o.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/)) return [];
      s[s.length] = { type: ps, text: `${parseFloat(RegExp.$1)}` }, o = o.substr(RegExp.$1.length);
    }
    return s[s.length] = { type: Vc, text: "" }, s;
  }(e);
  let i = "BOD", n = 0, a = r[n];
  for (; !ds(a, Vc); ) {
    let o = 0;
    const s = [];
    if (i === "BOD") {
      if (a.text !== "M" && a.text !== "m") return gl("M0,0" + e);
      n++, o = yn[a.text], i = a.text;
    } else ds(a, ps) ? o = yn[i] : (n++, o = yn[a.text], i = a.text);
    if (!(n + o < r.length)) throw new Error("Path data ended short");
    for (let l = n; l < n + o; l++) {
      const c = r[l];
      if (!ds(c, ps)) throw new Error("Param not a number: " + i + "," + c.text);
      s[s.length] = +c.text;
    }
    if (typeof yn[i] != "number") throw new Error("Bad segment: " + i);
    {
      const l = { key: i, data: s };
      t.push(l), n += o, a = r[n], i === "M" && (i = "L"), i === "m" && (i = "l");
    }
  }
  return t;
}
function md(e) {
  let t = 0, r = 0, i = 0, n = 0;
  const a = [];
  for (const { key: o, data: s } of e) switch (o) {
    case "M":
      a.push({ key: "M", data: [...s] }), [t, r] = s, [i, n] = s;
      break;
    case "m":
      t += s[0], r += s[1], a.push({ key: "M", data: [t, r] }), i = t, n = r;
      break;
    case "L":
      a.push({ key: "L", data: [...s] }), [t, r] = s;
      break;
    case "l":
      t += s[0], r += s[1], a.push({ key: "L", data: [t, r] });
      break;
    case "C":
      a.push({ key: "C", data: [...s] }), t = s[4], r = s[5];
      break;
    case "c": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "C", data: l }), t = l[4], r = l[5];
      break;
    }
    case "Q":
      a.push({ key: "Q", data: [...s] }), t = s[2], r = s[3];
      break;
    case "q": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "Q", data: l }), t = l[2], r = l[3];
      break;
    }
    case "A":
      a.push({ key: "A", data: [...s] }), t = s[5], r = s[6];
      break;
    case "a":
      t += s[5], r += s[6], a.push({ key: "A", data: [s[0], s[1], s[2], s[3], s[4], t, r] });
      break;
    case "H":
      a.push({ key: "H", data: [...s] }), t = s[0];
      break;
    case "h":
      t += s[0], a.push({ key: "H", data: [t] });
      break;
    case "V":
      a.push({ key: "V", data: [...s] }), r = s[0];
      break;
    case "v":
      r += s[0], a.push({ key: "V", data: [r] });
      break;
    case "S":
      a.push({ key: "S", data: [...s] }), t = s[2], r = s[3];
      break;
    case "s": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "S", data: l }), t = l[2], r = l[3];
      break;
    }
    case "T":
      a.push({ key: "T", data: [...s] }), t = s[0], r = s[1];
      break;
    case "t":
      t += s[0], r += s[1], a.push({ key: "T", data: [t, r] });
      break;
    case "Z":
    case "z":
      a.push({ key: "Z", data: [] }), t = i, r = n;
  }
  return a;
}
function yd(e) {
  const t = [];
  let r = "", i = 0, n = 0, a = 0, o = 0, s = 0, l = 0;
  for (const { key: c, data: h } of e) {
    switch (c) {
      case "M":
        t.push({ key: "M", data: [...h] }), [i, n] = h, [a, o] = h;
        break;
      case "C":
        t.push({ key: "C", data: [...h] }), i = h[4], n = h[5], s = h[2], l = h[3];
        break;
      case "L":
        t.push({ key: "L", data: [...h] }), [i, n] = h;
        break;
      case "H":
        i = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "V":
        n = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "S": {
        let u = 0, f = 0;
        r === "C" || r === "S" ? (u = i + (i - s), f = n + (n - l)) : (u = i, f = n), t.push({ key: "C", data: [u, f, ...h] }), s = h[0], l = h[1], i = h[2], n = h[3];
        break;
      }
      case "T": {
        const [u, f] = h;
        let p = 0, g = 0;
        r === "Q" || r === "T" ? (p = i + (i - s), g = n + (n - l)) : (p = i, g = n);
        const m = i + 2 * (p - i) / 3, x = n + 2 * (g - n) / 3, y = u + 2 * (p - u) / 3, b = f + 2 * (g - f) / 3;
        t.push({ key: "C", data: [m, x, y, b, u, f] }), s = p, l = g, i = u, n = f;
        break;
      }
      case "Q": {
        const [u, f, p, g] = h, m = i + 2 * (u - i) / 3, x = n + 2 * (f - n) / 3, y = p + 2 * (u - p) / 3, b = g + 2 * (f - g) / 3;
        t.push({ key: "C", data: [m, x, y, b, p, g] }), s = u, l = f, i = p, n = g;
        break;
      }
      case "A": {
        const u = Math.abs(h[0]), f = Math.abs(h[1]), p = h[2], g = h[3], m = h[4], x = h[5], y = h[6];
        u === 0 || f === 0 ? (t.push({ key: "C", data: [i, n, x, y, x, y] }), i = x, n = y) : (i !== x || n !== y) && (xd(i, n, x, y, u, f, p, g, m).forEach(function(b) {
          t.push({ key: "C", data: b });
        }), i = x, n = y);
        break;
      }
      case "Z":
        t.push({ key: "Z", data: [] }), i = a, n = o;
    }
    r = c;
  }
  return t;
}
function yi(e, t, r) {
  return [e * Math.cos(r) - t * Math.sin(r), e * Math.sin(r) + t * Math.cos(r)];
}
function xd(e, t, r, i, n, a, o, s, l, c) {
  const h = (u = o, Math.PI * u / 180);
  var u;
  let f = [], p = 0, g = 0, m = 0, x = 0;
  if (c) [p, g, m, x] = c;
  else {
    [e, t] = yi(e, t, -h), [r, i] = yi(r, i, -h);
    const D = (e - r) / 2, L = (t - i) / 2;
    let A = D * D / (n * n) + L * L / (a * a);
    A > 1 && (A = Math.sqrt(A), n *= A, a *= A);
    const B = n * n, $ = a * a, M = B * $ - B * L * L - $ * D * D, q = B * L * L + $ * D * D, Z = (s === l ? -1 : 1) * Math.sqrt(Math.abs(M / q));
    m = Z * n * L / a + (e + r) / 2, x = Z * -a * D / n + (t + i) / 2, p = Math.asin(parseFloat(((t - x) / a).toFixed(9))), g = Math.asin(parseFloat(((i - x) / a).toFixed(9))), e < m && (p = Math.PI - p), r < m && (g = Math.PI - g), p < 0 && (p = 2 * Math.PI + p), g < 0 && (g = 2 * Math.PI + g), l && p > g && (p -= 2 * Math.PI), !l && g > p && (g -= 2 * Math.PI);
  }
  let y = g - p;
  if (Math.abs(y) > 120 * Math.PI / 180) {
    const D = g, L = r, A = i;
    g = l && g > p ? p + 120 * Math.PI / 180 * 1 : p + 120 * Math.PI / 180 * -1, f = xd(r = m + n * Math.cos(g), i = x + a * Math.sin(g), L, A, n, a, o, 0, l, [g, D, m, x]);
  }
  y = g - p;
  const b = Math.cos(p), _ = Math.sin(p), k = Math.cos(g), v = Math.sin(g), C = Math.tan(y / 4), S = 4 / 3 * n * C, O = 4 / 3 * a * C, P = [e, t], R = [e + S * _, t - O * b], E = [r + S * v, i - O * k], N = [r, i];
  if (R[0] = 2 * P[0] - R[0], R[1] = 2 * P[1] - R[1], c) return [R, E, N].concat(f);
  {
    f = [R, E, N].concat(f);
    const D = [];
    for (let L = 0; L < f.length; L += 3) {
      const A = yi(f[L][0], f[L][1], h), B = yi(f[L + 1][0], f[L + 1][1], h), $ = yi(f[L + 2][0], f[L + 2][1], h);
      D.push([A[0], A[1], B[0], B[1], $[0], $[1]]);
    }
    return D;
  }
}
const _k = { randOffset: function(e, t) {
  return rt(e, t);
}, randOffsetWithRange: function(e, t, r) {
  return fa(e, t, r);
}, ellipse: function(e, t, r, i, n) {
  const a = Cd(r, i, n);
  return ao(e, t, n, a).opset;
}, doubleLineOps: function(e, t, r, i, n) {
  return Ge(e, t, r, i, n, !0);
} };
function bd(e, t, r, i, n) {
  return { type: "path", ops: Ge(e, t, r, i, n) };
}
function En(e, t, r) {
  const i = (e || []).length;
  if (i > 2) {
    const n = [];
    for (let a = 0; a < i - 1; a++) n.push(...Ge(e[a][0], e[a][1], e[a + 1][0], e[a + 1][1], r));
    return t && n.push(...Ge(e[i - 1][0], e[i - 1][1], e[0][0], e[0][1], r)), { type: "path", ops: n };
  }
  return i === 2 ? bd(e[0][0], e[0][1], e[1][0], e[1][1], r) : { type: "path", ops: [] };
}
function wk(e, t, r, i, n) {
  return function(a, o) {
    return En(a, !0, o);
  }([[e, t], [e + r, t], [e + r, t + i], [e, t + i]], n);
}
function Zc(e, t) {
  if (e.length) {
    const r = typeof e[0][0] == "number" ? [e] : e, i = xn(r[0], 1 * (1 + 0.2 * t.roughness), t), n = t.disableMultiStroke ? [] : xn(r[0], 1.5 * (1 + 0.22 * t.roughness), Jc(t));
    for (let a = 1; a < r.length; a++) {
      const o = r[a];
      if (o.length) {
        const s = xn(o, 1 * (1 + 0.2 * t.roughness), t), l = t.disableMultiStroke ? [] : xn(o, 1.5 * (1 + 0.22 * t.roughness), Jc(t));
        for (const c of s) c.op !== "move" && i.push(c);
        for (const c of l) c.op !== "move" && n.push(c);
      }
    }
    return { type: "path", ops: i.concat(n) };
  }
  return { type: "path", ops: [] };
}
function Cd(e, t, r) {
  const i = Math.sqrt(2 * Math.PI * Math.sqrt((Math.pow(e / 2, 2) + Math.pow(t / 2, 2)) / 2)), n = Math.ceil(Math.max(r.curveStepCount, r.curveStepCount / Math.sqrt(200) * i)), a = 2 * Math.PI / n;
  let o = Math.abs(e / 2), s = Math.abs(t / 2);
  const l = 1 - r.curveFitting;
  return o += rt(o * l, r), s += rt(s * l, r), { increment: a, rx: o, ry: s };
}
function ao(e, t, r, i) {
  const [n, a] = th(i.increment, e, t, i.rx, i.ry, 1, i.increment * fa(0.1, fa(0.4, 1, r), r), r);
  let o = pa(n, null, r);
  if (!r.disableMultiStroke && r.roughness !== 0) {
    const [s] = th(i.increment, e, t, i.rx, i.ry, 1.5, 0, r), l = pa(s, null, r);
    o = o.concat(l);
  }
  return { estimatedPoints: a, opset: { type: "path", ops: o } };
}
function Kc(e, t, r, i, n, a, o, s, l) {
  const c = e, h = t;
  let u = Math.abs(r / 2), f = Math.abs(i / 2);
  u += rt(0.01 * u, l), f += rt(0.01 * f, l);
  let p = n, g = a;
  for (; p < 0; ) p += 2 * Math.PI, g += 2 * Math.PI;
  g - p > 2 * Math.PI && (p = 0, g = 2 * Math.PI);
  const m = 2 * Math.PI / l.curveStepCount, x = Math.min(m / 2, (g - p) / 2), y = eh(x, c, h, u, f, p, g, 1, l);
  if (!l.disableMultiStroke) {
    const b = eh(x, c, h, u, f, p, g, 1.5, l);
    y.push(...b);
  }
  return o && (s ? y.push(...Ge(c, h, c + u * Math.cos(p), h + f * Math.sin(p), l), ...Ge(c, h, c + u * Math.cos(g), h + f * Math.sin(g), l)) : y.push({ op: "lineTo", data: [c, h] }, { op: "lineTo", data: [c + u * Math.cos(p), h + f * Math.sin(p)] })), { type: "path", ops: y };
}
function Qc(e, t) {
  const r = yd(md(gl(e))), i = [];
  let n = [0, 0], a = [0, 0];
  for (const { key: o, data: s } of r) switch (o) {
    case "M":
      a = [s[0], s[1]], n = [s[0], s[1]];
      break;
    case "L":
      i.push(...Ge(a[0], a[1], s[0], s[1], t)), a = [s[0], s[1]];
      break;
    case "C": {
      const [l, c, h, u, f, p] = s;
      i.push(...vk(l, c, h, u, f, p, a, t)), a = [f, p];
      break;
    }
    case "Z":
      i.push(...Ge(a[0], a[1], n[0], n[1], t)), a = [n[0], n[1]];
  }
  return { type: "path", ops: i };
}
function gs(e, t) {
  const r = [];
  for (const i of e) if (i.length) {
    const n = t.maxRandomnessOffset || 0, a = i.length;
    if (a > 2) {
      r.push({ op: "move", data: [i[0][0] + rt(n, t), i[0][1] + rt(n, t)] });
      for (let o = 1; o < a; o++) r.push({ op: "lineTo", data: [i[o][0] + rt(n, t), i[o][1] + rt(n, t)] });
    }
  }
  return { type: "fillPath", ops: r };
}
function Ar(e, t) {
  return function(r, i) {
    let n = r.fillStyle || "hachure";
    if (!Zt[n]) switch (n) {
      case "zigzag":
        Zt[n] || (Zt[n] = new dk(i));
        break;
      case "cross-hatch":
        Zt[n] || (Zt[n] = new gk(i));
        break;
      case "dots":
        Zt[n] || (Zt[n] = new mk(i));
        break;
      case "dashed":
        Zt[n] || (Zt[n] = new yk(i));
        break;
      case "zigzag-line":
        Zt[n] || (Zt[n] = new xk(i));
        break;
      default:
        n = "hachure", Zt[n] || (Zt[n] = new dl(i));
    }
    return Zt[n];
  }(t, _k).fillPolygons(e, t);
}
function Jc(e) {
  const t = Object.assign({}, e);
  return t.randomizer = void 0, e.seed && (t.seed = e.seed + 1), t;
}
function _d(e) {
  return e.randomizer || (e.randomizer = new bk(e.seed || 0)), e.randomizer.next();
}
function fa(e, t, r, i = 1) {
  return r.roughness * i * (_d(r) * (t - e) + e);
}
function rt(e, t, r = 1) {
  return fa(-e, e, t, r);
}
function Ge(e, t, r, i, n, a = !1) {
  const o = a ? n.disableMultiStrokeFill : n.disableMultiStroke, s = so(e, t, r, i, n, !0, !1);
  if (o) return s;
  const l = so(e, t, r, i, n, !0, !0);
  return s.concat(l);
}
function so(e, t, r, i, n, a, o) {
  const s = Math.pow(e - r, 2) + Math.pow(t - i, 2), l = Math.sqrt(s);
  let c = 1;
  c = l < 200 ? 1 : l > 500 ? 0.4 : -16668e-7 * l + 1.233334;
  let h = n.maxRandomnessOffset || 0;
  h * h * 100 > s && (h = l / 10);
  const u = h / 2, f = 0.2 + 0.2 * _d(n);
  let p = n.bowing * n.maxRandomnessOffset * (i - t) / 200, g = n.bowing * n.maxRandomnessOffset * (e - r) / 200;
  p = rt(p, n, c), g = rt(g, n, c);
  const m = [], x = () => rt(u, n, c), y = () => rt(h, n, c), b = n.preserveVertices;
  return o ? m.push({ op: "move", data: [e + (b ? 0 : x()), t + (b ? 0 : x())] }) : m.push({ op: "move", data: [e + (b ? 0 : rt(h, n, c)), t + (b ? 0 : rt(h, n, c))] }), o ? m.push({ op: "bcurveTo", data: [p + e + (r - e) * f + x(), g + t + (i - t) * f + x(), p + e + 2 * (r - e) * f + x(), g + t + 2 * (i - t) * f + x(), r + (b ? 0 : x()), i + (b ? 0 : x())] }) : m.push({ op: "bcurveTo", data: [p + e + (r - e) * f + y(), g + t + (i - t) * f + y(), p + e + 2 * (r - e) * f + y(), g + t + 2 * (i - t) * f + y(), r + (b ? 0 : y()), i + (b ? 0 : y())] }), m;
}
function xn(e, t, r) {
  if (!e.length) return [];
  const i = [];
  i.push([e[0][0] + rt(t, r), e[0][1] + rt(t, r)]), i.push([e[0][0] + rt(t, r), e[0][1] + rt(t, r)]);
  for (let n = 1; n < e.length; n++) i.push([e[n][0] + rt(t, r), e[n][1] + rt(t, r)]), n === e.length - 1 && i.push([e[n][0] + rt(t, r), e[n][1] + rt(t, r)]);
  return pa(i, null, r);
}
function pa(e, t, r) {
  const i = e.length, n = [];
  if (i > 3) {
    const a = [], o = 1 - r.curveTightness;
    n.push({ op: "move", data: [e[1][0], e[1][1]] });
    for (let s = 1; s + 2 < i; s++) {
      const l = e[s];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (o * e[s + 1][0] - o * e[s - 1][0]) / 6, l[1] + (o * e[s + 1][1] - o * e[s - 1][1]) / 6], a[2] = [e[s + 1][0] + (o * e[s][0] - o * e[s + 2][0]) / 6, e[s + 1][1] + (o * e[s][1] - o * e[s + 2][1]) / 6], a[3] = [e[s + 1][0], e[s + 1][1]], n.push({ op: "bcurveTo", data: [a[1][0], a[1][1], a[2][0], a[2][1], a[3][0], a[3][1]] });
    }
  } else i === 3 ? (n.push({ op: "move", data: [e[1][0], e[1][1]] }), n.push({ op: "bcurveTo", data: [e[1][0], e[1][1], e[2][0], e[2][1], e[2][0], e[2][1]] })) : i === 2 && n.push(...so(e[0][0], e[0][1], e[1][0], e[1][1], r, !0, !0));
  return n;
}
function th(e, t, r, i, n, a, o, s) {
  const l = [], c = [];
  if (s.roughness === 0) {
    e /= 4, c.push([t + i * Math.cos(-e), r + n * Math.sin(-e)]);
    for (let h = 0; h <= 2 * Math.PI; h += e) {
      const u = [t + i * Math.cos(h), r + n * Math.sin(h)];
      l.push(u), c.push(u);
    }
    c.push([t + i * Math.cos(0), r + n * Math.sin(0)]), c.push([t + i * Math.cos(e), r + n * Math.sin(e)]);
  } else {
    const h = rt(0.5, s) - Math.PI / 2;
    c.push([rt(a, s) + t + 0.9 * i * Math.cos(h - e), rt(a, s) + r + 0.9 * n * Math.sin(h - e)]);
    const u = 2 * Math.PI + h - 0.01;
    for (let f = h; f < u; f += e) {
      const p = [rt(a, s) + t + i * Math.cos(f), rt(a, s) + r + n * Math.sin(f)];
      l.push(p), c.push(p);
    }
    c.push([rt(a, s) + t + i * Math.cos(h + 2 * Math.PI + 0.5 * o), rt(a, s) + r + n * Math.sin(h + 2 * Math.PI + 0.5 * o)]), c.push([rt(a, s) + t + 0.98 * i * Math.cos(h + o), rt(a, s) + r + 0.98 * n * Math.sin(h + o)]), c.push([rt(a, s) + t + 0.9 * i * Math.cos(h + 0.5 * o), rt(a, s) + r + 0.9 * n * Math.sin(h + 0.5 * o)]);
  }
  return [c, l];
}
function eh(e, t, r, i, n, a, o, s, l) {
  const c = a + rt(0.1, l), h = [];
  h.push([rt(s, l) + t + 0.9 * i * Math.cos(c - e), rt(s, l) + r + 0.9 * n * Math.sin(c - e)]);
  for (let u = c; u <= o; u += e) h.push([rt(s, l) + t + i * Math.cos(u), rt(s, l) + r + n * Math.sin(u)]);
  return h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), pa(h, null, l);
}
function vk(e, t, r, i, n, a, o, s) {
  const l = [], c = [s.maxRandomnessOffset || 1, (s.maxRandomnessOffset || 1) + 0.3];
  let h = [0, 0];
  const u = s.disableMultiStroke ? 1 : 2, f = s.preserveVertices;
  for (let p = 0; p < u; p++) p === 0 ? l.push({ op: "move", data: [o[0], o[1]] }) : l.push({ op: "move", data: [o[0] + (f ? 0 : rt(c[0], s)), o[1] + (f ? 0 : rt(c[0], s))] }), h = f ? [n, a] : [n + rt(c[p], s), a + rt(c[p], s)], l.push({ op: "bcurveTo", data: [e + rt(c[p], s), t + rt(c[p], s), r + rt(c[p], s), i + rt(c[p], s), h[0], h[1]] });
  return l;
}
function xi(e) {
  return [...e];
}
function rh(e, t = 0) {
  const r = e.length;
  if (r < 3) throw new Error("A curve must have at least three points.");
  const i = [];
  if (r === 3) i.push(xi(e[0]), xi(e[1]), xi(e[2]), xi(e[2]));
  else {
    const n = [];
    n.push(e[0], e[0]);
    for (let s = 1; s < e.length; s++) n.push(e[s]), s === e.length - 1 && n.push(e[s]);
    const a = [], o = 1 - t;
    i.push(xi(n[0]));
    for (let s = 1; s + 2 < n.length; s++) {
      const l = n[s];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (o * n[s + 1][0] - o * n[s - 1][0]) / 6, l[1] + (o * n[s + 1][1] - o * n[s - 1][1]) / 6], a[2] = [n[s + 1][0] + (o * n[s][0] - o * n[s + 2][0]) / 6, n[s + 1][1] + (o * n[s][1] - o * n[s + 2][1]) / 6], a[3] = [n[s + 1][0], n[s + 1][1]], i.push(a[1], a[2], a[3]);
    }
  }
  return i;
}
function $n(e, t) {
  return Math.pow(e[0] - t[0], 2) + Math.pow(e[1] - t[1], 2);
}
function kk(e, t, r) {
  const i = $n(t, r);
  if (i === 0) return $n(e, t);
  let n = ((e[0] - t[0]) * (r[0] - t[0]) + (e[1] - t[1]) * (r[1] - t[1])) / i;
  return n = Math.max(0, Math.min(1, n)), $n(e, er(t, r, n));
}
function er(e, t, r) {
  return [e[0] + (t[0] - e[0]) * r, e[1] + (t[1] - e[1]) * r];
}
function oo(e, t, r, i) {
  const n = i || [];
  if (function(s, l) {
    const c = s[l + 0], h = s[l + 1], u = s[l + 2], f = s[l + 3];
    let p = 3 * h[0] - 2 * c[0] - f[0];
    p *= p;
    let g = 3 * h[1] - 2 * c[1] - f[1];
    g *= g;
    let m = 3 * u[0] - 2 * f[0] - c[0];
    m *= m;
    let x = 3 * u[1] - 2 * f[1] - c[1];
    return x *= x, p < m && (p = m), g < x && (g = x), p + g;
  }(e, t) < r) {
    const s = e[t + 0];
    n.length ? (a = n[n.length - 1], o = s, Math.sqrt($n(a, o)) > 1 && n.push(s)) : n.push(s), n.push(e[t + 3]);
  } else {
    const l = e[t + 0], c = e[t + 1], h = e[t + 2], u = e[t + 3], f = er(l, c, 0.5), p = er(c, h, 0.5), g = er(h, u, 0.5), m = er(f, p, 0.5), x = er(p, g, 0.5), y = er(m, x, 0.5);
    oo([l, f, m, y], 0, r, n), oo([y, x, g, u], 0, r, n);
  }
  var a, o;
  return n;
}
function Sk(e, t) {
  return da(e, 0, e.length, t);
}
function da(e, t, r, i, n) {
  const a = n || [], o = e[t], s = e[r - 1];
  let l = 0, c = 1;
  for (let h = t + 1; h < r - 1; ++h) {
    const u = kk(e[h], o, s);
    u > l && (l = u, c = h);
  }
  return Math.sqrt(l) > i ? (da(e, t, c + 1, i, a), da(e, c, r, i, a)) : (a.length || a.push(o), a.push(s)), a;
}
function ms(e, t = 0.15, r) {
  const i = [], n = (e.length - 1) / 3;
  for (let a = 0; a < n; a++)
    oo(e, 3 * a, t, i);
  return r && r > 0 ? da(i, 0, i.length, r) : i;
}
const te = "none";
class ga {
  constructor(t) {
    this.defaultOptions = { maxRandomnessOffset: 2, roughness: 1, bowing: 1, stroke: "#000", strokeWidth: 1, curveTightness: 0, curveFitting: 0.95, curveStepCount: 9, fillStyle: "hachure", fillWeight: -1, hachureAngle: -41, hachureGap: -1, dashOffset: -1, dashGap: -1, zigzagOffset: -1, seed: 0, disableMultiStroke: !1, disableMultiStrokeFill: !1, preserveVertices: !1, fillShapeRoughnessGain: 0.8 }, this.config = t || {}, this.config.options && (this.defaultOptions = this._o(this.config.options));
  }
  static newSeed() {
    return Math.floor(Math.random() * 2 ** 31);
  }
  _o(t) {
    return t ? Object.assign({}, this.defaultOptions, t) : this.defaultOptions;
  }
  _d(t, r, i) {
    return { shape: t, sets: r || [], options: i || this.defaultOptions };
  }
  line(t, r, i, n, a) {
    const o = this._o(a);
    return this._d("line", [bd(t, r, i, n, o)], o);
  }
  rectangle(t, r, i, n, a) {
    const o = this._o(a), s = [], l = wk(t, r, i, n, o);
    if (o.fill) {
      const c = [[t, r], [t + i, r], [t + i, r + n], [t, r + n]];
      o.fillStyle === "solid" ? s.push(gs([c], o)) : s.push(Ar([c], o));
    }
    return o.stroke !== te && s.push(l), this._d("rectangle", s, o);
  }
  ellipse(t, r, i, n, a) {
    const o = this._o(a), s = [], l = Cd(i, n, o), c = ao(t, r, o, l);
    if (o.fill) if (o.fillStyle === "solid") {
      const h = ao(t, r, o, l).opset;
      h.type = "fillPath", s.push(h);
    } else s.push(Ar([c.estimatedPoints], o));
    return o.stroke !== te && s.push(c.opset), this._d("ellipse", s, o);
  }
  circle(t, r, i, n) {
    const a = this.ellipse(t, r, i, i, n);
    return a.shape = "circle", a;
  }
  linearPath(t, r) {
    const i = this._o(r);
    return this._d("linearPath", [En(t, !1, i)], i);
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this._o(l), h = [], u = Kc(t, r, i, n, a, o, s, !0, c);
    if (s && c.fill) if (c.fillStyle === "solid") {
      const f = Object.assign({}, c);
      f.disableMultiStroke = !0;
      const p = Kc(t, r, i, n, a, o, !0, !1, f);
      p.type = "fillPath", h.push(p);
    } else h.push(function(f, p, g, m, x, y, b) {
      const _ = f, k = p;
      let v = Math.abs(g / 2), C = Math.abs(m / 2);
      v += rt(0.01 * v, b), C += rt(0.01 * C, b);
      let S = x, O = y;
      for (; S < 0; ) S += 2 * Math.PI, O += 2 * Math.PI;
      O - S > 2 * Math.PI && (S = 0, O = 2 * Math.PI);
      const P = (O - S) / b.curveStepCount, R = [];
      for (let E = S; E <= O; E += P) R.push([_ + v * Math.cos(E), k + C * Math.sin(E)]);
      return R.push([_ + v * Math.cos(O), k + C * Math.sin(O)]), R.push([_, k]), Ar([R], b);
    }(t, r, i, n, a, o, c));
    return c.stroke !== te && h.push(u), this._d("arc", h, c);
  }
  curve(t, r) {
    const i = this._o(r), n = [], a = Zc(t, i);
    if (i.fill && i.fill !== te) if (i.fillStyle === "solid") {
      const o = Zc(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(o.ops) });
    } else {
      const o = [], s = t;
      if (s.length) {
        const l = typeof s[0][0] == "number" ? [s] : s;
        for (const c of l) c.length < 3 ? o.push(...c) : c.length === 3 ? o.push(...ms(rh([c[0], c[0], c[1], c[2]]), 10, (1 + i.roughness) / 2)) : o.push(...ms(rh(c), 10, (1 + i.roughness) / 2));
      }
      o.length && n.push(Ar([o], i));
    }
    return i.stroke !== te && n.push(a), this._d("curve", n, i);
  }
  polygon(t, r) {
    const i = this._o(r), n = [], a = En(t, !0, i);
    return i.fill && (i.fillStyle === "solid" ? n.push(gs([t], i)) : n.push(Ar([t], i))), i.stroke !== te && n.push(a), this._d("polygon", n, i);
  }
  path(t, r) {
    const i = this._o(r), n = [];
    if (!t) return this._d("path", n, i);
    t = (t || "").replace(/\n/g, " ").replace(/(-\s)/g, "-").replace("/(ss)/g", " ");
    const a = i.fill && i.fill !== "transparent" && i.fill !== te, o = i.stroke !== te, s = !!(i.simplification && i.simplification < 1), l = function(h, u, f) {
      const p = yd(md(gl(h))), g = [];
      let m = [], x = [0, 0], y = [];
      const b = () => {
        y.length >= 4 && m.push(...ms(y, u)), y = [];
      }, _ = () => {
        b(), m.length && (g.push(m), m = []);
      };
      for (const { key: v, data: C } of p) switch (v) {
        case "M":
          _(), x = [C[0], C[1]], m.push(x);
          break;
        case "L":
          b(), m.push([C[0], C[1]]);
          break;
        case "C":
          if (!y.length) {
            const S = m.length ? m[m.length - 1] : x;
            y.push([S[0], S[1]]);
          }
          y.push([C[0], C[1]]), y.push([C[2], C[3]]), y.push([C[4], C[5]]);
          break;
        case "Z":
          b(), m.push([x[0], x[1]]);
      }
      if (_(), !f) return g;
      const k = [];
      for (const v of g) {
        const C = Sk(v, f);
        C.length && k.push(C);
      }
      return k;
    }(t, 1, s ? 4 - 4 * (i.simplification || 1) : (1 + i.roughness) / 2), c = Qc(t, i);
    if (a) if (i.fillStyle === "solid") if (l.length === 1) {
      const h = Qc(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(h.ops) });
    } else n.push(gs(l, i));
    else n.push(Ar(l, i));
    return o && (s ? l.forEach((h) => {
      n.push(En(h, !1, i));
    }) : n.push(c)), this._d("path", n, i);
  }
  opsToPath(t, r) {
    let i = "";
    for (const n of t.ops) {
      const a = typeof r == "number" && r >= 0 ? n.data.map((o) => +o.toFixed(r)) : n.data;
      switch (n.op) {
        case "move":
          i += `M${a[0]} ${a[1]} `;
          break;
        case "bcurveTo":
          i += `C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;
          break;
        case "lineTo":
          i += `L${a[0]} ${a[1]} `;
      }
    }
    return i.trim();
  }
  toPaths(t) {
    const r = t.sets || [], i = t.options || this.defaultOptions, n = [];
    for (const a of r) {
      let o = null;
      switch (a.type) {
        case "path":
          o = { d: this.opsToPath(a), stroke: i.stroke, strokeWidth: i.strokeWidth, fill: te };
          break;
        case "fillPath":
          o = { d: this.opsToPath(a), stroke: te, strokeWidth: 0, fill: i.fill || te };
          break;
        case "fillSketch":
          o = this.fillSketch(a, i);
      }
      o && n.push(o);
    }
    return n;
  }
  fillSketch(t, r) {
    let i = r.fillWeight;
    return i < 0 && (i = r.strokeWidth / 2), { d: this.opsToPath(t), stroke: r.fill || te, strokeWidth: i, fill: te };
  }
  _mergedShape(t) {
    return t.filter((r, i) => i === 0 || r.op !== "move");
  }
}
class Tk {
  constructor(t, r) {
    this.canvas = t, this.ctx = this.canvas.getContext("2d"), this.gen = new ga(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.ctx, a = t.options.fixedDecimalPlaceDigits;
    for (const o of r) switch (o.type) {
      case "path":
        n.save(), n.strokeStyle = i.stroke === "none" ? "transparent" : i.stroke, n.lineWidth = i.strokeWidth, i.strokeLineDash && n.setLineDash(i.strokeLineDash), i.strokeLineDashOffset && (n.lineDashOffset = i.strokeLineDashOffset), this._drawToContext(n, o, a), n.restore();
        break;
      case "fillPath": {
        n.save(), n.fillStyle = i.fill || "";
        const s = t.shape === "curve" || t.shape === "polygon" || t.shape === "path" ? "evenodd" : "nonzero";
        this._drawToContext(n, o, a, s), n.restore();
        break;
      }
      case "fillSketch":
        this.fillSketch(n, o, i);
    }
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2), t.save(), i.fillLineDash && t.setLineDash(i.fillLineDash), i.fillLineDashOffset && (t.lineDashOffset = i.fillLineDashOffset), t.strokeStyle = i.fill || "", t.lineWidth = n, this._drawToContext(t, r, i.fixedDecimalPlaceDigits), t.restore();
  }
  _drawToContext(t, r, i, n = "nonzero") {
    t.beginPath();
    for (const a of r.ops) {
      const o = typeof i == "number" && i >= 0 ? a.data.map((s) => +s.toFixed(i)) : a.data;
      switch (a.op) {
        case "move":
          t.moveTo(o[0], o[1]);
          break;
        case "bcurveTo":
          t.bezierCurveTo(o[0], o[1], o[2], o[3], o[4], o[5]);
          break;
        case "lineTo":
          t.lineTo(o[0], o[1]);
      }
    }
    r.type === "fillPath" ? t.fill(n) : t.stroke();
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o), o;
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o), o;
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o), o;
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a), a;
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i), i;
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i), i;
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, o, s, l);
    return this.draw(c), c;
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i), i;
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i), i;
  }
}
const bn = "http://www.w3.org/2000/svg";
class Bk {
  constructor(t, r) {
    this.svg = t, this.gen = new ga(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.svg.ownerDocument || window.document, a = n.createElementNS(bn, "g"), o = t.options.fixedDecimalPlaceDigits;
    for (const s of r) {
      let l = null;
      switch (s.type) {
        case "path":
          l = n.createElementNS(bn, "path"), l.setAttribute("d", this.opsToPath(s, o)), l.setAttribute("stroke", i.stroke), l.setAttribute("stroke-width", i.strokeWidth + ""), l.setAttribute("fill", "none"), i.strokeLineDash && l.setAttribute("stroke-dasharray", i.strokeLineDash.join(" ").trim()), i.strokeLineDashOffset && l.setAttribute("stroke-dashoffset", `${i.strokeLineDashOffset}`);
          break;
        case "fillPath":
          l = n.createElementNS(bn, "path"), l.setAttribute("d", this.opsToPath(s, o)), l.setAttribute("stroke", "none"), l.setAttribute("stroke-width", "0"), l.setAttribute("fill", i.fill || ""), t.shape !== "curve" && t.shape !== "polygon" || l.setAttribute("fill-rule", "evenodd");
          break;
        case "fillSketch":
          l = this.fillSketch(n, s, i);
      }
      l && a.appendChild(l);
    }
    return a;
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2);
    const a = t.createElementNS(bn, "path");
    return a.setAttribute("d", this.opsToPath(r, i.fixedDecimalPlaceDigits)), a.setAttribute("stroke", i.fill || ""), a.setAttribute("stroke-width", n + ""), a.setAttribute("fill", "none"), i.fillLineDash && a.setAttribute("stroke-dasharray", i.fillLineDash.join(" ").trim()), i.fillLineDashOffset && a.setAttribute("stroke-dashoffset", `${i.fillLineDashOffset}`), a;
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  opsToPath(t, r) {
    return this.gen.opsToPath(t, r);
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o);
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o);
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o);
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a);
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i);
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i);
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, o, s, l);
    return this.draw(c);
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i);
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i);
  }
}
var j = { canvas: (e, t) => new Tk(e, t), svg: (e, t) => new Bk(e, t), generator: (e) => new ga(e), newSeed: () => ga.newSeed() }, et = /* @__PURE__ */ d(async (e, t, r) => {
  var u, f;
  let i;
  const n = t.useHtmlLabels || At((u = ut()) == null ? void 0 : u.htmlLabels);
  r ? i = r : i = "node default";
  const a = e.insert("g").attr("class", i).attr("id", t.domId || t.id), o = a.insert("g").attr("class", "label").attr("style", zt(t.labelStyle));
  let s;
  t.label === void 0 ? s = "" : s = typeof t.label == "string" ? t.label : t.label[0];
  const l = await Ze(o, se(Cr(s), ut()), {
    useHtmlLabels: n,
    width: t.width || ((f = ut().flowchart) == null ? void 0 : f.wrappingWidth),
    // @ts-expect-error -- This is currently not used. Should this be `classes` instead?
    cssClasses: "markdown-node-label",
    style: t.labelStyle,
    addSvgBackground: !!t.icon || !!t.img
  });
  let c = l.getBBox();
  const h = ((t == null ? void 0 : t.padding) ?? 0) / 2;
  if (n) {
    const p = l.children[0], g = ht(l), m = p.getElementsByTagName("img");
    if (m) {
      const x = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...m].map(
          (y) => new Promise((b) => {
            function _() {
              if (y.style.display = "flex", y.style.flexDirection = "column", x) {
                const k = ut().fontSize ? ut().fontSize : window.getComputedStyle(document.body).fontSize, v = 5, [C = $h.fontSize] = Da(k), S = C * v + "px";
                y.style.minWidth = S, y.style.maxWidth = S;
              } else
                y.style.width = "100%";
              b(y);
            }
            d(_, "setupImage"), setTimeout(() => {
              y.complete && _();
            }), y.addEventListener("error", _), y.addEventListener("load", _);
          })
        )
      );
    }
    c = p.getBoundingClientRect(), g.attr("width", c.width), g.attr("height", c.height);
  }
  return n ? o.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")") : o.attr("transform", "translate(0, " + -c.height / 2 + ")"), t.centerLabel && o.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")"), o.insert("rect", ":first-child"), { shapeSvg: a, bbox: c, halfPadding: h, label: o };
}, "labelHelper"), ys = /* @__PURE__ */ d(async (e, t, r) => {
  var l, c, h, u, f, p;
  const i = r.useHtmlLabels || At((c = (l = ut()) == null ? void 0 : l.flowchart) == null ? void 0 : c.htmlLabels), n = e.insert("g").attr("class", "label").attr("style", r.labelStyle || ""), a = await Ze(n, se(Cr(t), ut()), {
    useHtmlLabels: i,
    width: r.width || ((u = (h = ut()) == null ? void 0 : h.flowchart) == null ? void 0 : u.wrappingWidth),
    style: r.labelStyle,
    addSvgBackground: !!r.icon || !!r.img
  });
  let o = a.getBBox();
  const s = r.padding / 2;
  if (At((p = (f = ut()) == null ? void 0 : f.flowchart) == null ? void 0 : p.htmlLabels)) {
    const g = a.children[0], m = ht(a);
    o = g.getBoundingClientRect(), m.attr("width", o.width), m.attr("height", o.height);
  }
  return i ? n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")") : n.attr("transform", "translate(0, " + -o.height / 2 + ")"), r.centerLabel && n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), n.insert("rect", ":first-child"), { shapeSvg: e, bbox: o, halfPadding: s, label: n };
}, "insertLabel"), U = /* @__PURE__ */ d((e, t) => {
  const r = t.node().getBBox();
  e.width = r.width, e.height = r.height;
}, "updateNodeBounds"), tt = /* @__PURE__ */ d((e, t) => (e.look === "handDrawn" ? "rough-node" : "node") + " " + e.cssClasses + " " + (t || ""), "getNodeClasses");
function lt(e) {
  const t = e.map((r, i) => `${i === 0 ? "M" : "L"}${r.x},${r.y}`);
  return t.push("Z"), t.join(" ");
}
d(lt, "createPathFromPoints");
function Xe(e, t, r, i, n, a) {
  const o = [], l = r - e, c = i - t, h = l / a, u = 2 * Math.PI / h, f = t + c / 2;
  for (let p = 0; p <= 50; p++) {
    const g = p / 50, m = e + g * l, x = f + n * Math.sin(u * (m - e));
    o.push({ x: m, y: x });
  }
  return o;
}
d(Xe, "generateFullSineWavePoints");
function ji(e, t, r, i, n, a) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d(ji, "generateCirclePoints");
var Lk = /* @__PURE__ */ d((e, t) => {
  var r = e.x, i = e.y, n = t.x - r, a = t.y - i, o = e.width / 2, s = e.height / 2, l, c;
  return Math.abs(a) * o > Math.abs(n) * s ? (a < 0 && (s = -s), l = a === 0 ? 0 : s * n / a, c = s) : (n < 0 && (o = -o), l = o, c = n === 0 ? 0 : o * a / n), { x: r + l, y: i + c };
}, "intersectRect"), ii = Lk;
function wd(e, t) {
  t && e.attr("style", t);
}
d(wd, "applyStyle");
async function vd(e) {
  const t = ht(document.createElementNS("http://www.w3.org/2000/svg", "foreignObject")), r = t.append("xhtml:div"), i = ut();
  let n = e.label;
  e.label && Ur(e.label) && (n = await _o(e.label.replace(Jr.lineBreakRegex, `
`), i));
  const o = '<span class="' + (e.isNode ? "nodeLabel" : "edgeLabel") + '" ' + (e.labelStyle ? 'style="' + e.labelStyle + '"' : "") + // codeql [js/html-constructed-from-input] : false positive
  ">" + n + "</span>";
  return r.html(se(o, i)), wd(r, e.labelStyle), r.style("display", "inline-block"), r.style("padding-right", "1px"), r.style("white-space", "nowrap"), r.attr("xmlns", "http://www.w3.org/1999/xhtml"), t.node();
}
d(vd, "addHtmlLabel");
var Ak = /* @__PURE__ */ d(async (e, t, r, i) => {
  let n = e || "";
  if (typeof n == "object" && (n = n[0]), At(ut().flowchart.htmlLabels)) {
    n = n.replace(/\\n|\n/g, "<br />"), F.info("vertexText" + n);
    const a = {
      isNode: i,
      label: Cr(n).replace(
        /fa[blrs]?:fa-[\w-]+/g,
        (s) => `<i class='${s.replace(":", " ")}'></i>`
      ),
      labelStyle: t && t.replace("fill:", "color:")
    };
    return await vd(a);
  } else {
    const a = document.createElementNS("http://www.w3.org/2000/svg", "text");
    a.setAttribute("style", t.replace("color:", "fill:"));
    let o = [];
    typeof n == "string" ? o = n.split(/\\n|\n|<br\s*\/?>/gi) : Array.isArray(n) ? o = n : o = [];
    for (const s of o) {
      const l = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
      l.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), l.setAttribute("dy", "1em"), l.setAttribute("x", "0"), r ? l.setAttribute("class", "title-row") : l.setAttribute("class", "row"), l.textContent = s.trim(), a.appendChild(l);
    }
    return a;
  }
}, "createLabel"), or = Ak, Ke = /* @__PURE__ */ d((e, t, r, i, n) => [
  "M",
  e + n,
  t,
  // Move to the first point
  "H",
  e + r - n,
  // Draw horizontal line to the beginning of the right corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r,
  t + n,
  // Draw arc to the right top corner
  "V",
  t + i - n,
  // Draw vertical line down to the beginning of the right bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r - n,
  t + i,
  // Draw arc to the right bottom corner
  "H",
  e + n,
  // Draw horizontal line to the beginning of the left bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e,
  t + i - n,
  // Draw arc to the left bottom corner
  "V",
  t + n,
  // Draw vertical line up to the beginning of the left top corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + n,
  t,
  // Draw arc to the left top corner
  "Z"
  // Close the path
].join(" "), "createRoundedRectPathD"), kd = /* @__PURE__ */ d(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = ut(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: l, borderStyles: c, backgroundStyles: h } = G(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = At(r.flowchart.htmlLabels), p = u.insert("g").attr("class", "cluster-label "), g = await Ze(p, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0
  });
  let m = g.getBBox();
  if (At(r.flowchart.htmlLabels)) {
    const S = g.children[0], O = ht(g);
    m = S.getBoundingClientRect(), O.attr("width", m.width), O.attr("height", m.height);
  }
  const x = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (x - t.width) / 2 - t.padding : t.diff = -t.padding;
  const y = t.height, b = t.x - x / 2, _ = t.y - y / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let k;
  if (t.look === "handDrawn") {
    const S = j.svg(u), O = Y(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 3,
      seed: n
    }), P = S.path(Ke(b, _, x, y, 0), O);
    k = u.insert(() => (F.debug("Rough node insert CXC", P), P), ":first-child"), k.select("path:nth-child(2)").attr("style", c.join(";")), k.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    k = u.insert("rect", ":first-child"), k.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", x).attr("height", y);
  const { subGraphTitleTopMargin: v } = Uo(r);
  if (p.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + v})`
  ), s) {
    const S = p.select("span");
    S && S.attr("style", s);
  }
  const C = k.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(S) {
    return ii(t, S);
  }, { cluster: u, labelBBox: m };
}, "rect"), Mk = /* @__PURE__ */ d((e, t) => {
  const r = e.insert("g").attr("class", "note-cluster").attr("id", t.id), i = r.insert("rect", ":first-child"), n = 0 * t.padding, a = n / 2;
  i.attr("rx", t.rx).attr("ry", t.ry).attr("x", t.x - t.width / 2 - a).attr("y", t.y - t.height / 2 - a).attr("width", t.width + n).attr("height", t.height + n).attr("fill", "none");
  const o = i.node().getBBox();
  return t.width = o.width, t.height = o.height, t.intersect = function(s) {
    return ii(t, s);
  }, { cluster: r, labelBBox: { width: 0, height: 0 } };
}, "noteGroup"), Ek = /* @__PURE__ */ d(async (e, t) => {
  const r = ut(), { themeVariables: i, handDrawnSeed: n } = r, { altBackground: a, compositeBackground: o, compositeTitleBackground: s, nodeBorder: l } = i, c = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-id", t.id).attr("data-look", t.look), h = c.insert("g", ":first-child"), u = c.insert("g").attr("class", "cluster-label");
  let f = c.append("rect");
  const p = u.node().appendChild(await or(t.label, t.labelStyle, void 0, !0));
  let g = p.getBBox();
  if (At(r.flowchart.htmlLabels)) {
    const P = p.children[0], R = ht(p);
    g = P.getBoundingClientRect(), R.attr("width", g.width), R.attr("height", g.height);
  }
  const m = 0 * t.padding, x = m / 2, y = (t.width <= g.width + t.padding ? g.width + t.padding : t.width) + m;
  t.width <= g.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const b = t.height + m, _ = t.height + m - g.height - 6, k = t.x - y / 2, v = t.y - b / 2;
  t.width = y;
  const C = t.y - t.height / 2 - x + g.height + 2;
  let S;
  if (t.look === "handDrawn") {
    const P = t.cssClasses.includes("statediagram-cluster-alt"), R = j.svg(c), E = t.rx || t.ry ? R.path(Ke(k, v, y, b, 10), {
      roughness: 0.7,
      fill: s,
      fillStyle: "solid",
      stroke: l,
      seed: n
    }) : R.rectangle(k, v, y, b, { seed: n });
    S = c.insert(() => E, ":first-child");
    const N = R.rectangle(k, C, y, _, {
      fill: P ? a : o,
      fillStyle: P ? "hachure" : "solid",
      stroke: l,
      seed: n
    });
    S = c.insert(() => E, ":first-child"), f = c.insert(() => N);
  } else
    S = h.insert("rect", ":first-child"), S.attr("class", "outer").attr("x", k).attr("y", v).attr("width", y).attr("height", b).attr("data-look", t.look), f.attr("class", "inner").attr("x", k).attr("y", C).attr("width", y).attr("height", _);
  u.attr(
    "transform",
    `translate(${t.x - g.width / 2}, ${v + 1 - (At(r.flowchart.htmlLabels) ? 0 : 3)})`
  );
  const O = S.node().getBBox();
  return t.height = O.height, t.offsetX = 0, t.offsetY = g.height - t.padding / 2, t.labelBBox = g, t.intersect = function(P) {
    return ii(t, P);
  }, { cluster: c, labelBBox: g };
}, "roundedWithTitle"), $k = /* @__PURE__ */ d(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = ut(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: l, borderStyles: c, backgroundStyles: h } = G(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = At(r.flowchart.htmlLabels), p = u.insert("g").attr("class", "cluster-label "), g = await Ze(p, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0,
    width: t.width
  });
  let m = g.getBBox();
  if (At(r.flowchart.htmlLabels)) {
    const S = g.children[0], O = ht(g);
    m = S.getBoundingClientRect(), O.attr("width", m.width), O.attr("height", m.height);
  }
  const x = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (x - t.width) / 2 - t.padding : t.diff = -t.padding;
  const y = t.height, b = t.x - x / 2, _ = t.y - y / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let k;
  if (t.look === "handDrawn") {
    const S = j.svg(u), O = Y(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 4,
      seed: n
    }), P = S.path(Ke(b, _, x, y, t.rx), O);
    k = u.insert(() => (F.debug("Rough node insert CXC", P), P), ":first-child"), k.select("path:nth-child(2)").attr("style", c.join(";")), k.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    k = u.insert("rect", ":first-child"), k.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", x).attr("height", y);
  const { subGraphTitleTopMargin: v } = Uo(r);
  if (p.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + v})`
  ), s) {
    const S = p.select("span");
    S && S.attr("style", s);
  }
  const C = k.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(S) {
    return ii(t, S);
  }, { cluster: u, labelBBox: m };
}, "kanbanSection"), Fk = /* @__PURE__ */ d((e, t) => {
  const r = ut(), { themeVariables: i, handDrawnSeed: n } = r, { nodeBorder: a } = i, o = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-look", t.look), s = o.insert("g", ":first-child"), l = 0 * t.padding, c = t.width + l;
  t.diff = -t.padding;
  const h = t.height + l, u = t.x - c / 2, f = t.y - h / 2;
  t.width = c;
  let p;
  if (t.look === "handDrawn") {
    const x = j.svg(o).rectangle(u, f, c, h, {
      fill: "lightgrey",
      roughness: 0.5,
      strokeLineDash: [5],
      stroke: a,
      seed: n
    });
    p = o.insert(() => x, ":first-child");
  } else
    p = s.insert("rect", ":first-child"), p.attr("class", "divider").attr("x", u).attr("y", f).attr("width", c).attr("height", h).attr("data-look", t.look);
  const g = p.node().getBBox();
  return t.height = g.height, t.offsetX = 0, t.offsetY = 0, t.intersect = function(m) {
    return ii(t, m);
  }, { cluster: o, labelBBox: {} };
}, "divider"), Dk = kd, Ok = {
  rect: kd,
  squareRect: Dk,
  roundedWithTitle: Ek,
  noteGroup: Mk,
  divider: Fk,
  kanbanSection: $k
}, Sd = /* @__PURE__ */ new Map(), Rk = /* @__PURE__ */ d(async (e, t) => {
  const r = t.shape || "rect", i = await Ok[r](e, t);
  return Sd.set(t.id, i), i;
}, "insertCluster"), aA = /* @__PURE__ */ d(() => {
  Sd = /* @__PURE__ */ new Map();
}, "clear");
function Td(e, t) {
  return e.intersect(t);
}
d(Td, "intersectNode");
var Ik = Td;
function Bd(e, t, r, i) {
  var n = e.x, a = e.y, o = n - i.x, s = a - i.y, l = Math.sqrt(t * t * s * s + r * r * o * o), c = Math.abs(t * r * o / l);
  i.x < n && (c = -c);
  var h = Math.abs(t * r * s / l);
  return i.y < a && (h = -h), { x: n + c, y: a + h };
}
d(Bd, "intersectEllipse");
var Ld = Bd;
function Ad(e, t, r) {
  return Ld(e, t, t, r);
}
d(Ad, "intersectCircle");
var Pk = Ad;
function Md(e, t, r, i) {
  {
    const n = t.y - e.y, a = e.x - t.x, o = t.x * e.y - e.x * t.y, s = n * r.x + a * r.y + o, l = n * i.x + a * i.y + o, c = 1e-6;
    if (s !== 0 && l !== 0 && lo(s, l))
      return;
    const h = i.y - r.y, u = r.x - i.x, f = i.x * r.y - r.x * i.y, p = h * e.x + u * e.y + f, g = h * t.x + u * t.y + f;
    if (Math.abs(p) < c && Math.abs(g) < c && lo(p, g))
      return;
    const m = n * u - h * a;
    if (m === 0)
      return;
    const x = Math.abs(m / 2);
    let y = a * f - u * o;
    const b = y < 0 ? (y - x) / m : (y + x) / m;
    y = h * o - n * f;
    const _ = y < 0 ? (y - x) / m : (y + x) / m;
    return { x: b, y: _ };
  }
}
d(Md, "intersectLine");
function lo(e, t) {
  return e * t > 0;
}
d(lo, "sameSign");
var Nk = Md;
function Ed(e, t, r) {
  let i = e.x, n = e.y, a = [], o = Number.POSITIVE_INFINITY, s = Number.POSITIVE_INFINITY;
  typeof t.forEach == "function" ? t.forEach(function(h) {
    o = Math.min(o, h.x), s = Math.min(s, h.y);
  }) : (o = Math.min(o, t.x), s = Math.min(s, t.y));
  let l = i - e.width / 2 - o, c = n - e.height / 2 - s;
  for (let h = 0; h < t.length; h++) {
    let u = t[h], f = t[h < t.length - 1 ? h + 1 : 0], p = Nk(
      e,
      r,
      { x: l + u.x, y: c + u.y },
      { x: l + f.x, y: c + f.y }
    );
    p && a.push(p);
  }
  return a.length ? (a.length > 1 && a.sort(function(h, u) {
    let f = h.x - r.x, p = h.y - r.y, g = Math.sqrt(f * f + p * p), m = u.x - r.x, x = u.y - r.y, y = Math.sqrt(m * m + x * x);
    return g < y ? -1 : g === y ? 0 : 1;
  }), a[0]) : e;
}
d(Ed, "intersectPolygon");
var zk = Ed, W = {
  node: Ik,
  circle: Pk,
  ellipse: Ld,
  polygon: zk,
  rect: ii
};
function $d(e, t) {
  const { labelStyles: r } = G(t);
  t.labelStyle = r;
  const i = tt(t);
  let n = i;
  i || (n = "anchor");
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = 1, { cssStyles: s } = t, l = j.svg(a), c = Y(t, { fill: "black", stroke: "none", fillStyle: "solid" });
  t.look !== "handDrawn" && (c.roughness = 0);
  const h = l.circle(0, 0, o * 2, c), u = a.insert(() => h, ":first-child");
  return u.attr("class", "anchor").attr("style", zt(s)), U(t, u), t.intersect = function(f) {
    return F.info("Circle intersect", t, o, f), W.circle(t, o, f);
  }, a;
}
d($d, "anchor");
function co(e, t, r, i, n, a, o) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, p = u / n, g = f / a, m = Math.sqrt(p ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const x = Math.sqrt(1 - m ** 2), y = l + x * a * Math.sin(h) * (o ? -1 : 1), b = c - x * n * Math.cos(h) * (o ? -1 : 1), _ = Math.atan2((t - b) / a, (e - y) / n);
  let v = Math.atan2((i - b) / a, (r - y) / n) - _;
  o && v < 0 && (v += 2 * Math.PI), !o && v > 0 && (v -= 2 * Math.PI);
  const C = [];
  for (let S = 0; S < 20; S++) {
    const O = S / 19, P = _ + O * v, R = y + n * Math.cos(P), E = b + a * Math.sin(P);
    C.push({ x: R, y: E });
  }
  return C;
}
d(co, "generateArcPoints");
async function Fd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.width + t.padding + 20, s = a.height + t.padding, l = s / 2, c = l / (2.5 + s / 50), { cssStyles: h } = t, u = [
    { x: o / 2, y: -s / 2 },
    { x: -o / 2, y: -s / 2 },
    ...co(-o / 2, -s / 2, -o / 2, s / 2, c, l, !1),
    { x: o / 2, y: s / 2 },
    ...co(o / 2, s / 2, o / 2, -s / 2, c, l, !0)
  ], f = j.svg(n), p = Y(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = lt(u), m = f.path(g, p), x = n.insert(() => m, ":first-child");
  return x.attr("class", "basic label-container"), h && t.look !== "handDrawn" && x.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), x.attr("transform", `translate(${c / 2}, 0)`), U(t, x), t.intersect = function(y) {
    return W.polygon(t, u, y);
  }, n;
}
d(Fd, "bowTieRect");
function Qe(e, t, r, i) {
  return e.insert("polygon", ":first-child").attr(
    "points",
    i.map(function(n) {
      return n.x + "," + n.y;
    }).join(" ")
  ).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + r / 2 + ")");
}
d(Qe, "insertPolygonShape");
async function Dd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.height + t.padding, s = 12, l = a.width + t.padding + s, c = 0, h = l, u = -o, f = 0, p = [
    { x: c + s, y: u },
    { x: h, y: u },
    { x: h, y: f },
    { x: c, y: f },
    { x: c, y: u + s },
    { x: c + s, y: u }
  ];
  let g;
  const { cssStyles: m } = t;
  if (t.look === "handDrawn") {
    const x = j.svg(n), y = Y(t, {}), b = lt(p), _ = x.path(b, y);
    g = n.insert(() => _, ":first-child").attr("transform", `translate(${-l / 2}, ${o / 2})`), m && g.attr("style", m);
  } else
    g = Qe(n, l, o, p);
  return i && g.attr("style", i), U(t, g), t.intersect = function(x) {
    return W.polygon(t, p, x);
  }, n;
}
d(Dd, "card");
function Od(e, t) {
  const { nodeStyles: r } = G(t);
  t.label = "";
  const i = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), { cssStyles: n } = t, a = Math.max(28, t.width ?? 0), o = [
    { x: 0, y: a / 2 },
    { x: a / 2, y: 0 },
    { x: 0, y: -a / 2 },
    { x: -a / 2, y: 0 }
  ], s = j.svg(i), l = Y(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = lt(o), h = s.path(c, l), u = i.insert(() => h, ":first-child");
  return n && t.look !== "handDrawn" && u.selectAll("path").attr("style", n), r && t.look !== "handDrawn" && u.selectAll("path").attr("style", r), t.width = 28, t.height = 28, t.intersect = function(f) {
    return W.polygon(t, o, f);
  }, i;
}
d(Od, "choice");
async function ml(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: o, halfPadding: s } = await et(e, t, tt(t)), l = (r == null ? void 0 : r.padding) ?? s, c = o.width / 2 + l;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const f = j.svg(a), p = Y(t, {}), g = f.circle(0, 0, c * 2, p);
    h = a.insert(() => g, ":first-child"), h.attr("class", "basic label-container").attr("style", zt(u));
  } else
    h = a.insert("circle", ":first-child").attr("class", "basic label-container").attr("style", n).attr("r", c).attr("cx", 0).attr("cy", 0);
  return U(t, h), t.calcIntersect = function(f, p) {
    const g = f.width / 2;
    return W.circle(f, g, p);
  }, t.intersect = function(f) {
    return F.info("Circle intersect", t, c, f), W.circle(t, c, f);
  }, a;
}
d(ml, "circle");
function Rd(e) {
  const t = Math.cos(Math.PI / 4), r = Math.sin(Math.PI / 4), i = e * 2, n = { x: i / 2 * t, y: i / 2 * r }, a = { x: -(i / 2) * t, y: i / 2 * r }, o = { x: -(i / 2) * t, y: -(i / 2) * r }, s = { x: i / 2 * t, y: -(i / 2) * r };
  return `M ${a.x},${a.y} L ${s.x},${s.y}
                   M ${n.x},${n.y} L ${o.x},${o.y}`;
}
d(Rd, "createLine");
function Id(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r, t.label = "";
  const n = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), { cssStyles: o } = t, s = j.svg(n), l = Y(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = s.circle(0, 0, a * 2, l), h = Rd(a), u = s.path(h, l), f = n.insert(() => c, ":first-child");
  return f.insert(() => u), o && t.look !== "handDrawn" && f.selectAll("path").attr("style", o), i && t.look !== "handDrawn" && f.selectAll("path").attr("style", i), U(t, f), t.intersect = function(p) {
    return F.info("crossedCircle intersect", t, { radius: a, point: p }), W.circle(t, a, p);
  }, n;
}
d(Id, "crossedCircle");
function $e(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d($e, "generateCirclePoints");
async function Pd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...$e(s / 2, -l / 2, c, 30, -90, 0),
    { x: -s / 2 - c, y: c },
    ...$e(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...$e(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: -l / 2 },
    ...$e(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: s / 2, y: -l / 2 - c },
    { x: -s / 2, y: -l / 2 - c },
    ...$e(s / 2, -l / 2, c, 20, -90, 0),
    { x: -s / 2 - c, y: -c },
    ...$e(s / 2 + s * 0.1, -c, c, 20, -180, -270),
    ...$e(s / 2 + s * 0.1, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: l / 2 },
    ...$e(s / 2, l / 2, c, 20, 0, 90),
    { x: -s / 2, y: l / 2 + c },
    { x: s / 2, y: l / 2 + c }
  ], p = j.svg(n), g = Y(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = lt(u).replace("Z", ""), y = p.path(x, g), b = lt(f), _ = p.path(b, { ...g }), k = n.insert("g", ":first-child");
  return k.insert(() => _, ":first-child").attr("stroke-opacity", 0), k.insert(() => y, ":first-child"), k.attr("class", "text"), h && t.look !== "handDrawn" && k.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(${c}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + c - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), U(t, k), t.intersect = function(v) {
    return W.polygon(t, f, v);
  }, n;
}
d(Pd, "curlyBraceLeft");
function Fe(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: p, y: g });
  }
  return o;
}
d(Fe, "generateCirclePoints");
async function Nd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...Fe(s / 2, -l / 2, c, 20, -90, 0),
    { x: s / 2 + c, y: -c },
    ...Fe(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...Fe(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: s / 2 + c, y: l / 2 },
    ...Fe(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: -s / 2, y: -l / 2 - c },
    { x: s / 2, y: -l / 2 - c },
    ...Fe(s / 2, -l / 2, c, 20, -90, 0),
    { x: s / 2 + c, y: -c },
    ...Fe(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...Fe(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: s / 2 + c, y: l / 2 },
    ...Fe(s / 2, l / 2, c, 20, 0, 90),
    { x: s / 2, y: l / 2 + c },
    { x: -s / 2, y: l / 2 + c }
  ], p = j.svg(n), g = Y(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = lt(u).replace("Z", ""), y = p.path(x, g), b = lt(f), _ = p.path(b, { ...g }), k = n.insert("g", ":first-child");
  return k.insert(() => _, ":first-child").attr("stroke-opacity", 0), k.insert(() => y, ":first-child"), k.attr("class", "text"), h && t.look !== "handDrawn" && k.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(${-c}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), U(t, k), t.intersect = function(v) {
    return W.polygon(t, f, v);
  }, n;
}
d(Nd, "curlyBraceRight");
function $t(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, p = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -p, y: -g });
  }
  return o;
}
d($t, "generateCirclePoints");
async function zd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...$t(s / 2, -l / 2, c, 30, -90, 0),
    { x: -s / 2 - c, y: c },
    ...$t(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...$t(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: -l / 2 },
    ...$t(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    ...$t(-s / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: s / 2 - c / 2, y: c },
    ...$t(-s / 2 - c / 2, -c, c, 20, 0, 90),
    ...$t(-s / 2 - c / 2, c, c, 20, -90, 0),
    { x: s / 2 - c / 2, y: -c },
    ...$t(-s / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], p = [
    { x: s / 2, y: -l / 2 - c },
    { x: -s / 2, y: -l / 2 - c },
    ...$t(s / 2, -l / 2, c, 20, -90, 0),
    { x: -s / 2 - c, y: -c },
    ...$t(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...$t(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: l / 2 },
    ...$t(s / 2, l / 2, c, 20, 0, 90),
    { x: -s / 2, y: l / 2 + c },
    { x: s / 2 - c - c / 2, y: l / 2 + c },
    ...$t(-s / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: s / 2 - c / 2, y: c },
    ...$t(-s / 2 - c / 2, -c, c, 20, 0, 90),
    ...$t(-s / 2 - c / 2, c, c, 20, -90, 0),
    { x: s / 2 - c / 2, y: -c },
    ...$t(-s / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], g = j.svg(n), m = Y(t, { fill: "none" });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = lt(u).replace("Z", ""), b = g.path(y, m), k = lt(f).replace("Z", ""), v = g.path(k, m), C = lt(p), S = g.path(C, { ...m }), O = n.insert("g", ":first-child");
  return O.insert(() => S, ":first-child").attr("stroke-opacity", 0), O.insert(() => b, ":first-child"), O.insert(() => v, ":first-child"), O.attr("class", "text"), h && t.look !== "handDrawn" && O.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && O.selectAll("path").attr("style", i), O.attr("transform", `translate(${c - c / 4}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), U(t, O), t.intersect = function(P) {
    return W.polygon(t, p, P);
  }, n;
}
d(zd, "curlyBraces");
async function Wd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = 80, s = 20, l = Math.max(o, (a.width + (t.padding ?? 0) * 2) * 1.25, (t == null ? void 0 : t.width) ?? 0), c = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = c / 2, { cssStyles: u } = t, f = j.svg(n), p = Y(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = l, m = c, x = g - h, y = m / 4, b = [
    { x, y: 0 },
    { x: y, y: 0 },
    { x: 0, y: m / 2 },
    { x: y, y: m },
    { x, y: m },
    ...ji(-x, -m / 2, h, 50, 270, 90)
  ], _ = lt(b), k = f.path(_, p), v = n.insert(() => k, ":first-child");
  return v.attr("class", "basic label-container"), u && t.look !== "handDrawn" && v.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && v.selectChildren("path").attr("style", i), v.attr("transform", `translate(${-l / 2}, ${-c / 2})`), U(t, v), t.intersect = function(C) {
    return W.polygon(t, b, C);
  }, n;
}
d(Wd, "curvedTrapezoid");
var Wk = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createCylinderPathD"), qk = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createOuterCylinderPathD"), Hk = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function qd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + t.padding, t.width ?? 0), l = s / 2, c = l / (2.5 + s / 50), h = Math.max(a.height + c + t.padding, t.height ?? 0);
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const p = j.svg(n), g = qk(0, 0, s, h, l, c), m = Hk(0, c, s, h, l, c), x = p.path(g, Y(t, {})), y = p.path(m, Y(t, { fill: "none" }));
    u = n.insert(() => y, ":first-child"), u = n.insert(() => x, ":first-child"), u.attr("class", "basic label-container"), f && u.attr("style", f);
  } else {
    const p = Wk(0, 0, s, h, l, c);
    u = n.insert("path", ":first-child").attr("d", p).attr("class", "basic label-container").attr("style", zt(f)).attr("style", i);
  }
  return u.attr("label-offset-y", c), u.attr("transform", `translate(${-s / 2}, ${-(h / 2 + c)})`), U(t, u), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + (t.padding ?? 0) / 1.5 - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(p) {
    const g = W.rect(t, p), m = g.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(m) < (t.width ?? 0) / 2 || Math.abs(m) == (t.width ?? 0) / 2 && Math.abs(g.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let x = c * c * (1 - m * m / (l * l));
      x > 0 && (x = Math.sqrt(x)), x = c - x, p.y - (t.y ?? 0) > 0 && (x = -x), g.y += x;
    }
    return g;
  }, n;
}
d(qd, "cylinder");
async function Hd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + t.padding, l = a.height + t.padding, c = l * 0.2, h = -s / 2, u = -l / 2 - c / 2, { cssStyles: f } = t, p = j.svg(n), g = Y(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u + c },
    { x: -h, y: u + c },
    { x: -h, y: -u },
    { x: h, y: -u },
    { x: h, y: u },
    { x: -h, y: u },
    { x: -h, y: u + c }
  ], x = p.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), y = n.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container"), f && t.look !== "handDrawn" && y.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${h + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))}, ${u + c + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), U(t, y), t.intersect = function(b) {
    return W.rect(t, b);
  }, n;
}
d(Hd, "dividedRectangle");
async function jd(e, t) {
  var f, p;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o } = await et(e, t, tt(t)), l = a.width / 2 + o + 5, c = a.width / 2 + o;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const g = j.svg(n), m = Y(t, { roughness: 0.2, strokeWidth: 2.5 }), x = Y(t, { roughness: 0.2, strokeWidth: 1.5 }), y = g.circle(0, 0, l * 2, m), b = g.circle(0, 0, c * 2, x);
    h = n.insert("g", ":first-child"), h.attr("class", zt(t.cssClasses)).attr("style", zt(u)), (f = h.node()) == null || f.appendChild(y), (p = h.node()) == null || p.appendChild(b);
  } else {
    h = n.insert("g", ":first-child");
    const g = h.insert("circle", ":first-child"), m = h.insert("circle");
    h.attr("class", "basic label-container").attr("style", i), g.attr("class", "outer-circle").attr("style", i).attr("r", l).attr("cx", 0).attr("cy", 0), m.attr("class", "inner-circle").attr("style", i).attr("r", c).attr("cx", 0).attr("cy", 0);
  }
  return U(t, h), t.intersect = function(g) {
    return F.info("DoubleCircle intersect", t, l, g), W.circle(t, l, g);
  }, n;
}
d(jd, "doublecircle");
function Yd(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.label = "", t.labelStyle = i;
  const a = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), o = 7, { cssStyles: s } = t, l = j.svg(a), { nodeBorder: c } = r, h = Y(t, { fillStyle: "solid" });
  t.look !== "handDrawn" && (h.roughness = 0);
  const u = l.circle(0, 0, o * 2, h), f = a.insert(() => u, ":first-child");
  return f.selectAll("path").attr("style", `fill: ${c} !important;`), s && s.length > 0 && t.look !== "handDrawn" && f.selectAll("path").attr("style", s), n && t.look !== "handDrawn" && f.selectAll("path").attr("style", n), U(t, f), t.intersect = function(p) {
    return F.info("filledCircle intersect", t, { radius: o, point: p }), W.circle(t, o, p);
  }, a;
}
d(Yd, "filledCircle");
async function Ud(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = a.width + (t.padding ?? 0), l = s + a.height, c = s + a.height, h = [
    { x: 0, y: -l },
    { x: c, y: -l },
    { x: c / 2, y: 0 }
  ], { cssStyles: u } = t, f = j.svg(n), p = Y(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = lt(h), m = f.path(g, p), x = n.insert(() => m, ":first-child").attr("transform", `translate(${-l / 2}, ${l / 2})`);
  return u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), t.width = s, t.height = l, U(t, x), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${-l / 2 + (t.padding ?? 0) / 2 + (a.y - (a.top ?? 0))})`
  ), t.intersect = function(y) {
    return F.info("Triangle intersect", t, h, y), W.polygon(t, h, y);
  }, n;
}
d(Ud, "flippedTriangle");
function Gd(e, t, { dir: r, config: { state: i, themeVariables: n } }) {
  const { nodeStyles: a } = G(t);
  t.label = "";
  const o = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), { cssStyles: s } = t;
  let l = Math.max(70, (t == null ? void 0 : t.width) ?? 0), c = Math.max(10, (t == null ? void 0 : t.height) ?? 0);
  r === "LR" && (l = Math.max(10, (t == null ? void 0 : t.width) ?? 0), c = Math.max(70, (t == null ? void 0 : t.height) ?? 0));
  const h = -1 * l / 2, u = -1 * c / 2, f = j.svg(o), p = Y(t, {
    stroke: n.lineColor,
    fill: n.lineColor
  });
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = f.rectangle(h, u, l, c, p), m = o.insert(() => g, ":first-child");
  s && t.look !== "handDrawn" && m.selectAll("path").attr("style", s), a && t.look !== "handDrawn" && m.selectAll("path").attr("style", a), U(t, m);
  const x = (i == null ? void 0 : i.padding) ?? 0;
  return t.width && t.height && (t.width += x / 2 || 0, t.height += x / 2 || 0), t.intersect = function(y) {
    return W.rect(t, y);
  }, o;
}
d(Gd, "forkJoin");
async function Xd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const n = 80, a = 50, { shapeSvg: o, bbox: s } = await et(e, t, tt(t)), l = Math.max(n, s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a, s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = c / 2, { cssStyles: u } = t, f = j.svg(o), p = Y(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: -l / 2, y: -c / 2 },
    { x: l / 2 - h, y: -c / 2 },
    ...ji(-l / 2 + h, 0, h, 50, 90, 270),
    { x: l / 2 - h, y: c / 2 },
    { x: -l / 2, y: c / 2 }
  ], m = lt(g), x = f.path(m, p), y = o.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container"), u && t.look !== "handDrawn" && y.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), U(t, y), t.intersect = function(b) {
    return F.info("Pill intersect", t, { radius: h, point: b }), W.polygon(t, g, b);
  }, o;
}
d(Xd, "halfRoundedRectangle");
async function Vd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.height + (t.padding ?? 0), s = a.width + (t.padding ?? 0) * 2.5, { cssStyles: l } = t, c = j.svg(n), h = Y(t, {});
  t.look !== "handDrawn" && (h.roughness = 0, h.fillStyle = "solid");
  let u = s / 2;
  const f = u / 6;
  u = u + f;
  const p = o / 2, g = p / 2, m = u - g, x = [
    { x: -m, y: -p },
    { x: 0, y: -p },
    { x: m, y: -p },
    { x: u, y: 0 },
    { x: m, y: p },
    { x: 0, y: p },
    { x: -m, y: p },
    { x: -u, y: 0 }
  ], y = lt(x), b = c.path(y, h), _ = n.insert(() => b, ":first-child");
  return _.attr("class", "basic label-container"), l && t.look !== "handDrawn" && _.selectChildren("path").attr("style", l), i && t.look !== "handDrawn" && _.selectChildren("path").attr("style", i), t.width = s, t.height = o, U(t, _), t.intersect = function(k) {
    return W.polygon(t, x, k);
  }, n;
}
d(Vd, "hexagon");
async function Zd(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.label = "", t.labelStyle = r;
  const { shapeSvg: n } = await et(e, t, tt(t)), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), o = Math.max(30, (t == null ? void 0 : t.height) ?? 0), { cssStyles: s } = t, l = j.svg(n), c = Y(t, {});
  t.look !== "handDrawn" && (c.roughness = 0, c.fillStyle = "solid");
  const h = [
    { x: 0, y: 0 },
    { x: a, y: 0 },
    { x: 0, y: o },
    { x: a, y: o }
  ], u = lt(h), f = l.path(u, c), p = n.insert(() => f, ":first-child");
  return p.attr("class", "basic label-container"), s && t.look !== "handDrawn" && p.selectChildren("path").attr("style", s), i && t.look !== "handDrawn" && p.selectChildren("path").attr("style", i), p.attr("transform", `translate(${-a / 2}, ${-o / 2})`), U(t, p), t.intersect = function(g) {
    return F.info("Pill intersect", t, { points: h }), W.polygon(t, h, g);
  }, n;
}
d(Zd, "hourglass");
async function Kd(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await et(e, t, "icon-shape default"), f = t.pos === "t", p = s, g = s, { nodeBorder: m } = r, { stylesMap: x } = ti(t), y = -g / 2, b = -p / 2, _ = t.label ? 8 : 0, k = j.svg(c), v = Y(t, { stroke: "none", fill: "none" });
  t.look !== "handDrawn" && (v.roughness = 0, v.fillStyle = "solid");
  const C = k.rectangle(y, b, g, p, v), S = Math.max(g, h.width), O = p + h.height + _, P = k.rectangle(-S / 2, -O / 2, S, O, {
    ...v,
    fill: "transparent",
    stroke: "none"
  }), R = c.insert(() => C, ":first-child"), E = c.insert(() => P);
  if (t.icon) {
    const N = c.append("g");
    N.html(
      `<g>${await en(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const D = N.node().getBBox(), L = D.width, A = D.height, B = D.x, $ = D.y;
    N.attr(
      "transform",
      `translate(${-L / 2 - B},${f ? h.height / 2 + _ / 2 - A / 2 - $ : -h.height / 2 - _ / 2 - A / 2 - $})`
    ), N.attr("style", `color: ${x.get("stroke") ?? m};`);
  }
  return u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${f ? -O / 2 : O / 2 - h.height})`
  ), R.attr(
    "transform",
    `translate(0,${f ? h.height / 2 + _ / 2 : -h.height / 2 - _ / 2})`
  ), U(t, E), t.intersect = function(N) {
    if (F.info("iconSquare intersect", t, N), !t.label)
      return W.rect(t, N);
    const D = t.x ?? 0, L = t.y ?? 0, A = t.height ?? 0;
    let B = [];
    return f ? B = [
      { x: D - h.width / 2, y: L - A / 2 },
      { x: D + h.width / 2, y: L - A / 2 },
      { x: D + h.width / 2, y: L - A / 2 + h.height + _ },
      { x: D + g / 2, y: L - A / 2 + h.height + _ },
      { x: D + g / 2, y: L + A / 2 },
      { x: D - g / 2, y: L + A / 2 },
      { x: D - g / 2, y: L - A / 2 + h.height + _ },
      { x: D - h.width / 2, y: L - A / 2 + h.height + _ }
    ] : B = [
      { x: D - g / 2, y: L - A / 2 },
      { x: D + g / 2, y: L - A / 2 },
      { x: D + g / 2, y: L - A / 2 + p },
      { x: D + h.width / 2, y: L - A / 2 + p },
      { x: D + h.width / 2 / 2, y: L + A / 2 },
      { x: D - h.width / 2, y: L + A / 2 },
      { x: D - h.width / 2, y: L - A / 2 + p },
      { x: D - g / 2, y: L - A / 2 + p }
    ], W.polygon(t, B, N);
  }, c;
}
d(Kd, "icon");
async function Qd(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await et(e, t, "icon-shape default"), f = 20, p = t.label ? 8 : 0, g = t.pos === "t", { nodeBorder: m, mainBkg: x } = r, { stylesMap: y } = ti(t), b = j.svg(c), _ = Y(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const k = y.get("fill");
  _.stroke = k ?? x;
  const v = c.append("g");
  t.icon && v.html(
    `<g>${await en(t.icon, {
      height: s,
      width: s,
      fallbackPrefix: ""
    })}</g>`
  );
  const C = v.node().getBBox(), S = C.width, O = C.height, P = C.x, R = C.y, E = Math.max(S, O) * Math.SQRT2 + f * 2, N = b.circle(0, 0, E, _), D = Math.max(E, h.width), L = E + h.height + p, A = b.rectangle(-D / 2, -L / 2, D, L, {
    ..._,
    fill: "transparent",
    stroke: "none"
  }), B = c.insert(() => N, ":first-child"), $ = c.insert(() => A);
  return v.attr(
    "transform",
    `translate(${-S / 2 - P},${g ? h.height / 2 + p / 2 - O / 2 - R : -h.height / 2 - p / 2 - O / 2 - R})`
  ), v.attr("style", `color: ${y.get("stroke") ?? m};`), u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${g ? -L / 2 : L / 2 - h.height})`
  ), B.attr(
    "transform",
    `translate(0,${g ? h.height / 2 + p / 2 : -h.height / 2 - p / 2})`
  ), U(t, $), t.intersect = function(M) {
    return F.info("iconSquare intersect", t, M), W.rect(t, M);
  }, c;
}
d(Qd, "iconCircle");
async function Jd(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await et(
    e,
    t,
    "icon-shape default"
  ), p = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: x, mainBkg: y } = r, { stylesMap: b } = ti(t), _ = -m / 2, k = -g / 2, v = t.label ? 8 : 0, C = j.svg(c), S = Y(t, {});
  t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid");
  const O = b.get("fill");
  S.stroke = O ?? y;
  const P = C.path(Ke(_, k, m, g, 5), S), R = Math.max(m, h.width), E = g + h.height + v, N = C.rectangle(-R / 2, -E / 2, R, E, {
    ...S,
    fill: "transparent",
    stroke: "none"
  }), D = c.insert(() => P, ":first-child").attr("class", "icon-shape2"), L = c.insert(() => N);
  if (t.icon) {
    const A = c.append("g");
    A.html(
      `<g>${await en(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const B = A.node().getBBox(), $ = B.width, M = B.height, q = B.x, Z = B.y;
    A.attr(
      "transform",
      `translate(${-$ / 2 - q},${p ? h.height / 2 + v / 2 - M / 2 - Z : -h.height / 2 - v / 2 - M / 2 - Z})`
    ), A.attr("style", `color: ${b.get("stroke") ?? x};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${p ? -E / 2 : E / 2 - h.height})`
  ), D.attr(
    "transform",
    `translate(0,${p ? h.height / 2 + v / 2 : -h.height / 2 - v / 2})`
  ), U(t, L), t.intersect = function(A) {
    if (F.info("iconSquare intersect", t, A), !t.label)
      return W.rect(t, A);
    const B = t.x ?? 0, $ = t.y ?? 0, M = t.height ?? 0;
    let q = [];
    return p ? q = [
      { x: B - h.width / 2, y: $ - M / 2 },
      { x: B + h.width / 2, y: $ - M / 2 },
      { x: B + h.width / 2, y: $ - M / 2 + h.height + v },
      { x: B + m / 2, y: $ - M / 2 + h.height + v },
      { x: B + m / 2, y: $ + M / 2 },
      { x: B - m / 2, y: $ + M / 2 },
      { x: B - m / 2, y: $ - M / 2 + h.height + v },
      { x: B - h.width / 2, y: $ - M / 2 + h.height + v }
    ] : q = [
      { x: B - m / 2, y: $ - M / 2 },
      { x: B + m / 2, y: $ - M / 2 },
      { x: B + m / 2, y: $ - M / 2 + g },
      { x: B + h.width / 2, y: $ - M / 2 + g },
      { x: B + h.width / 2 / 2, y: $ + M / 2 },
      { x: B - h.width / 2, y: $ + M / 2 },
      { x: B - h.width / 2, y: $ - M / 2 + g },
      { x: B - m / 2, y: $ - M / 2 + g }
    ], W.polygon(t, q, A);
  }, c;
}
d(Jd, "iconRounded");
async function tg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await et(
    e,
    t,
    "icon-shape default"
  ), p = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: x, mainBkg: y } = r, { stylesMap: b } = ti(t), _ = -m / 2, k = -g / 2, v = t.label ? 8 : 0, C = j.svg(c), S = Y(t, {});
  t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid");
  const O = b.get("fill");
  S.stroke = O ?? y;
  const P = C.path(Ke(_, k, m, g, 0.1), S), R = Math.max(m, h.width), E = g + h.height + v, N = C.rectangle(-R / 2, -E / 2, R, E, {
    ...S,
    fill: "transparent",
    stroke: "none"
  }), D = c.insert(() => P, ":first-child"), L = c.insert(() => N);
  if (t.icon) {
    const A = c.append("g");
    A.html(
      `<g>${await en(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const B = A.node().getBBox(), $ = B.width, M = B.height, q = B.x, Z = B.y;
    A.attr(
      "transform",
      `translate(${-$ / 2 - q},${p ? h.height / 2 + v / 2 - M / 2 - Z : -h.height / 2 - v / 2 - M / 2 - Z})`
    ), A.attr("style", `color: ${b.get("stroke") ?? x};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${p ? -E / 2 : E / 2 - h.height})`
  ), D.attr(
    "transform",
    `translate(0,${p ? h.height / 2 + v / 2 : -h.height / 2 - v / 2})`
  ), U(t, L), t.intersect = function(A) {
    if (F.info("iconSquare intersect", t, A), !t.label)
      return W.rect(t, A);
    const B = t.x ?? 0, $ = t.y ?? 0, M = t.height ?? 0;
    let q = [];
    return p ? q = [
      { x: B - h.width / 2, y: $ - M / 2 },
      { x: B + h.width / 2, y: $ - M / 2 },
      { x: B + h.width / 2, y: $ - M / 2 + h.height + v },
      { x: B + m / 2, y: $ - M / 2 + h.height + v },
      { x: B + m / 2, y: $ + M / 2 },
      { x: B - m / 2, y: $ + M / 2 },
      { x: B - m / 2, y: $ - M / 2 + h.height + v },
      { x: B - h.width / 2, y: $ - M / 2 + h.height + v }
    ] : q = [
      { x: B - m / 2, y: $ - M / 2 },
      { x: B + m / 2, y: $ - M / 2 },
      { x: B + m / 2, y: $ - M / 2 + g },
      { x: B + h.width / 2, y: $ - M / 2 + g },
      { x: B + h.width / 2 / 2, y: $ + M / 2 },
      { x: B - h.width / 2, y: $ + M / 2 },
      { x: B - h.width / 2, y: $ - M / 2 + g },
      { x: B - m / 2, y: $ - M / 2 + g }
    ], W.polygon(t, q, A);
  }, c;
}
d(tg, "iconSquare");
async function eg(e, t, { config: { flowchart: r } }) {
  const i = new Image();
  i.src = (t == null ? void 0 : t.img) ?? "", await i.decode();
  const n = Number(i.naturalWidth.toString().replace("px", "")), a = Number(i.naturalHeight.toString().replace("px", ""));
  t.imageAspectRatio = n / a;
  const { labelStyles: o } = G(t);
  t.labelStyle = o;
  const s = r == null ? void 0 : r.wrappingWidth;
  t.defaultWidth = r == null ? void 0 : r.wrappingWidth;
  const l = Math.max(
    t.label ? s ?? 0 : 0,
    (t == null ? void 0 : t.assetWidth) ?? n
  ), c = t.constraint === "on" && t != null && t.assetHeight ? t.assetHeight * t.imageAspectRatio : l, h = t.constraint === "on" ? c / t.imageAspectRatio : (t == null ? void 0 : t.assetHeight) ?? a;
  t.width = Math.max(c, s ?? 0);
  const { shapeSvg: u, bbox: f, label: p } = await et(e, t, "image-shape default"), g = t.pos === "t", m = -c / 2, x = -h / 2, y = t.label ? 8 : 0, b = j.svg(u), _ = Y(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const k = b.rectangle(m, x, c, h, _), v = Math.max(c, f.width), C = h + f.height + y, S = b.rectangle(-v / 2, -C / 2, v, C, {
    ..._,
    fill: "none",
    stroke: "none"
  }), O = u.insert(() => k, ":first-child"), P = u.insert(() => S);
  if (t.img) {
    const R = u.append("image");
    R.attr("href", t.img), R.attr("width", c), R.attr("height", h), R.attr("preserveAspectRatio", "none"), R.attr(
      "transform",
      `translate(${-c / 2},${g ? C / 2 - h : -C / 2})`
    );
  }
  return p.attr(
    "transform",
    `translate(${-f.width / 2 - (f.x - (f.left ?? 0))},${g ? -h / 2 - f.height / 2 - y / 2 : h / 2 - f.height / 2 + y / 2})`
  ), O.attr(
    "transform",
    `translate(0,${g ? f.height / 2 + y / 2 : -f.height / 2 - y / 2})`
  ), U(t, P), t.intersect = function(R) {
    if (F.info("iconSquare intersect", t, R), !t.label)
      return W.rect(t, R);
    const E = t.x ?? 0, N = t.y ?? 0, D = t.height ?? 0;
    let L = [];
    return g ? L = [
      { x: E - f.width / 2, y: N - D / 2 },
      { x: E + f.width / 2, y: N - D / 2 },
      { x: E + f.width / 2, y: N - D / 2 + f.height + y },
      { x: E + c / 2, y: N - D / 2 + f.height + y },
      { x: E + c / 2, y: N + D / 2 },
      { x: E - c / 2, y: N + D / 2 },
      { x: E - c / 2, y: N - D / 2 + f.height + y },
      { x: E - f.width / 2, y: N - D / 2 + f.height + y }
    ] : L = [
      { x: E - c / 2, y: N - D / 2 },
      { x: E + c / 2, y: N - D / 2 },
      { x: E + c / 2, y: N - D / 2 + h },
      { x: E + f.width / 2, y: N - D / 2 + h },
      { x: E + f.width / 2 / 2, y: N + D / 2 },
      { x: E - f.width / 2, y: N + D / 2 },
      { x: E - f.width / 2, y: N - D / 2 + h },
      { x: E - c / 2, y: N - D / 2 + h }
    ], W.polygon(t, L, R);
  }, u;
}
d(eg, "imageSquare");
async function rg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = [
    { x: 0, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: -3 * s / 6, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), f = Y(t, {}), p = lt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Qe(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, U(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
d(rg, "inv_trapezoid");
async function za(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: o } = await et(e, t, tt(t)), s = Math.max(o.width + r.labelPaddingX * 2, (t == null ? void 0 : t.width) || 0), l = Math.max(o.height + r.labelPaddingY * 2, (t == null ? void 0 : t.height) || 0), c = -s / 2, h = -l / 2;
  let u, { rx: f, ry: p } = t;
  const { cssStyles: g } = t;
  if (r != null && r.rx && r.ry && (f = r.rx, p = r.ry), t.look === "handDrawn") {
    const m = j.svg(a), x = Y(t, {}), y = f || p ? m.path(Ke(c, h, s, l, f || 0), x) : m.rectangle(c, h, s, l, x);
    u = a.insert(() => y, ":first-child"), u.attr("class", "basic label-container").attr("style", zt(g));
  } else
    u = a.insert("rect", ":first-child"), u.attr("class", "basic label-container").attr("style", n).attr("rx", zt(f)).attr("ry", zt(p)).attr("x", c).attr("y", h).attr("width", s).attr("height", l);
  return U(t, u), t.calcIntersect = function(m, x) {
    return W.rect(m, x);
  }, t.intersect = function(m) {
    return W.rect(t, m);
  }, a;
}
d(za, "drawRect");
async function ig(e, t) {
  const { shapeSvg: r, bbox: i, label: n } = await et(e, t, "label"), a = r.insert("rect", ":first-child");
  return a.attr("width", 0.1).attr("height", 0.1), r.attr("class", "label edgeLabel"), n.attr(
    "transform",
    `translate(${-(i.width / 2) - (i.x - (i.left ?? 0))}, ${-(i.height / 2) - (i.y - (i.top ?? 0))})`
  ), U(t, a), t.intersect = function(l) {
    return W.rect(t, l);
  }, r;
}
d(ig, "labelRect");
async function ng(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), l = [
    { x: 0, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: -(3 * s) / 6, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), f = Y(t, {}), p = lt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Qe(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, U(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
d(ng, "lean_left");
async function ag(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), l = [
    { x: -3 * s / 6, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: 0, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), f = Y(t, {}), p = lt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Qe(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, U(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
d(ag, "lean_right");
function sg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.label = "", t.labelStyle = r;
  const n = e.insert("g").attr("class", tt(t)).attr("id", t.domId ?? t.id), { cssStyles: a } = t, o = Math.max(35, (t == null ? void 0 : t.width) ?? 0), s = Math.max(35, (t == null ? void 0 : t.height) ?? 0), l = 7, c = [
    { x: o, y: 0 },
    { x: 0, y: s + l / 2 },
    { x: o - 2 * l, y: s + l / 2 },
    { x: 0, y: 2 * s },
    { x: o, y: s - l / 2 },
    { x: 2 * l, y: s - l / 2 }
  ], h = j.svg(n), u = Y(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = lt(c), p = h.path(f, u), g = n.insert(() => p, ":first-child");
  return a && t.look !== "handDrawn" && g.selectAll("path").attr("style", a), i && t.look !== "handDrawn" && g.selectAll("path").attr("style", i), g.attr("transform", `translate(-${o / 2},${-s})`), U(t, g), t.intersect = function(m) {
    return F.info("lightningBolt intersect", t, m), W.polygon(t, c, m);
  }, n;
}
d(sg, "lightningBolt");
var jk = /* @__PURE__ */ d((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createCylinderPathD"), Yk = /* @__PURE__ */ d((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createOuterCylinderPathD"), Uk = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function og(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0), t.width ?? 0), l = s / 2, c = l / (2.5 + s / 50), h = Math.max(a.height + c + (t.padding ?? 0), t.height ?? 0), u = h * 0.1;
  let f;
  const { cssStyles: p } = t;
  if (t.look === "handDrawn") {
    const g = j.svg(n), m = Yk(0, 0, s, h, l, c, u), x = Uk(0, c, s, h, l, c), y = Y(t, {}), b = g.path(m, y), _ = g.path(x, y);
    n.insert(() => _, ":first-child").attr("class", "line"), f = n.insert(() => b, ":first-child"), f.attr("class", "basic label-container"), p && f.attr("style", p);
  } else {
    const g = jk(0, 0, s, h, l, c, u);
    f = n.insert("path", ":first-child").attr("d", g).attr("class", "basic label-container").attr("style", zt(p)).attr("style", i);
  }
  return f.attr("label-offset-y", c), f.attr("transform", `translate(${-s / 2}, ${-(h / 2 + c)})`), U(t, f), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(g) {
    const m = W.rect(t, g), x = m.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(x) < (t.width ?? 0) / 2 || Math.abs(x) == (t.width ?? 0) / 2 && Math.abs(m.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let y = c * c * (1 - x * x / (l * l));
      y > 0 && (y = Math.sqrt(y)), y = c - y, g.y - (t.y ?? 0) > 0 && (y = -y), m.y += y;
    }
    return m;
  }, n;
}
d(og, "linedCylinder");
async function lg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = l + c, { cssStyles: u } = t, f = j.svg(n), p = Y(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: h / 2 },
    ...Xe(
      -s / 2 - s / 2 * 0.1,
      h / 2,
      s / 2 + s / 2 * 0.1,
      h / 2,
      c,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2, y: -h / 2 },
    { x: -s / 2, y: h / 2 * 1.1 },
    { x: -s / 2, y: -h / 2 }
  ], m = f.polygon(
    g.map((y) => [y.x, y.y]),
    p
  ), x = n.insert(() => m, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), x.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) + s / 2 * 0.1 / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), U(t, x), t.intersect = function(y) {
    return W.polygon(t, g, y);
  }, n;
}
d(lg, "linedWaveEdgedRect");
async function cg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = 5, h = -s / 2, u = -l / 2, { cssStyles: f } = t, p = j.svg(n), g = Y(t, {}), m = [
    { x: h - c, y: u + c },
    { x: h - c, y: u + l + c },
    { x: h + s - c, y: u + l + c },
    { x: h + s - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u + l - c },
    { x: h + s + c, y: u + l - c },
    { x: h + s + c, y: u - c },
    { x: h + c, y: u - c },
    { x: h + c, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], x = [
    { x: h, y: u + c },
    { x: h + s - c, y: u + c },
    { x: h + s - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u },
    { x: h, y: u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = lt(m), b = p.path(y, g), _ = lt(x), k = p.path(_, { ...g, fill: "none" }), v = n.insert(() => k, ":first-child");
  return v.insert(() => b, ":first-child"), v.attr("class", "basic label-container"), f && t.look !== "handDrawn" && v.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && v.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) - c - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), U(t, v), t.intersect = function(C) {
    return W.polygon(t, m, C);
  }, n;
}
d(cg, "multiRect");
async function hg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = l + c, u = -s / 2, f = -h / 2, p = 5, { cssStyles: g } = t, m = Xe(
    u - p,
    f + h + p,
    u + s - p,
    f + h + p,
    c,
    0.8
  ), x = m == null ? void 0 : m[m.length - 1], y = [
    { x: u - p, y: f + p },
    { x: u - p, y: f + h + p },
    ...m,
    { x: u + s - p, y: x.y - p },
    { x: u + s, y: x.y - p },
    { x: u + s, y: x.y - 2 * p },
    { x: u + s + p, y: x.y - 2 * p },
    { x: u + s + p, y: f - p },
    { x: u + p, y: f - p },
    { x: u + p, y: f },
    { x: u, y: f },
    { x: u, y: f + p }
  ], b = [
    { x: u, y: f + p },
    { x: u + s - p, y: f + p },
    { x: u + s - p, y: x.y - p },
    { x: u + s, y: x.y - p },
    { x: u + s, y: f },
    { x: u, y: f }
  ], _ = j.svg(n), k = Y(t, {});
  t.look !== "handDrawn" && (k.roughness = 0, k.fillStyle = "solid");
  const v = lt(y), C = _.path(v, k), S = lt(b), O = _.path(S, k), P = n.insert(() => C, ":first-child");
  return P.insert(() => O), P.attr("class", "basic label-container"), g && t.look !== "handDrawn" && P.selectAll("path").attr("style", g), i && t.look !== "handDrawn" && P.selectAll("path").attr("style", i), P.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - p - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + p - c / 2 - (a.y - (a.top ?? 0))})`
  ), U(t, P), t.intersect = function(R) {
    return W.polygon(t, y, R);
  }, n;
}
d(hg, "multiWaveEdgedRectangle");
async function ug(e, t, { config: { themeVariables: r } }) {
  var b;
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i, t.useHtmlLabels || ((b = Pt().flowchart) == null ? void 0 : b.htmlLabels) !== !1 || (t.centerLabel = !0);
  const { shapeSvg: o, bbox: s, label: l } = await et(e, t, tt(t)), c = Math.max(s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), h = Math.max(s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), u = -c / 2, f = -h / 2, { cssStyles: p } = t, g = j.svg(o), m = Y(t, {
    fill: r.noteBkgColor,
    stroke: r.noteBorderColor
  });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = g.rectangle(u, f, c, h, m), y = o.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container"), p && t.look !== "handDrawn" && y.selectAll("path").attr("style", p), n && t.look !== "handDrawn" && y.selectAll("path").attr("style", n), l.attr(
    "transform",
    `translate(${-s.width / 2 - (s.x - (s.left ?? 0))}, ${-(s.height / 2) - (s.y - (s.top ?? 0))})`
  ), U(t, y), t.intersect = function(_) {
    return W.rect(t, _);
  }, o;
}
d(ug, "note");
var Gk = /* @__PURE__ */ d((e, t, r) => [
  `M${e + r / 2},${t}`,
  `L${e + r},${t - r / 2}`,
  `L${e + r / 2},${t - r}`,
  `L${e},${t - r / 2}`,
  "Z"
].join(" "), "createDecisionBoxPathD");
async function fg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.width + t.padding, s = a.height + t.padding, l = o + s, c = 0.5, h = [
    { x: l / 2, y: 0 },
    { x: l, y: -l / 2 },
    { x: l / 2, y: -l },
    { x: 0, y: -l / 2 }
  ];
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const p = j.svg(n), g = Y(t, {}), m = Gk(0, 0, l), x = p.path(m, g);
    u = n.insert(() => x, ":first-child").attr("transform", `translate(${-l / 2 + c}, ${l / 2})`), f && u.attr("style", f);
  } else
    u = Qe(n, l, l, h), u.attr("transform", `translate(${-l / 2 + c}, ${l / 2})`);
  return i && u.attr("style", i), U(t, u), t.calcIntersect = function(p, g) {
    const m = p.width, x = [
      { x: m / 2, y: 0 },
      { x: m, y: -m / 2 },
      { x: m / 2, y: -m },
      { x: 0, y: -m / 2 }
    ], y = W.polygon(p, x, g);
    return { x: y.x - 0.5, y: y.y - 0.5 };
  }, t.intersect = function(p) {
    return this.calcIntersect(t, p);
  }, n;
}
d(fg, "question");
async function pg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), c = -s / 2, h = -l / 2, u = h / 2, f = [
    { x: c + u, y: h },
    { x: c, y: 0 },
    { x: c + u, y: -h },
    { x: -c, y: -h },
    { x: -c, y: h }
  ], { cssStyles: p } = t, g = j.svg(n), m = Y(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = lt(f), y = g.path(x, m), b = n.insert(() => y, ":first-child");
  return b.attr("class", "basic label-container"), p && t.look !== "handDrawn" && b.selectAll("path").attr("style", p), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), b.attr("transform", `translate(${-u / 2},0)`), o.attr(
    "transform",
    `translate(${-u / 2 - a.width / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), U(t, b), t.intersect = function(_) {
    return W.polygon(t, f, _);
  }, n;
}
d(pg, "rect_left_inv_arrow");
async function dg(e, t) {
  var O, P;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  let n;
  t.cssClasses ? n = "node " + t.cssClasses : n = "node default";
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = a.insert("g"), s = a.insert("g").attr("class", "label").attr("style", i), l = t.description, c = t.label, h = s.node().appendChild(await or(c, t.labelStyle, !0, !0));
  let u = { width: 0, height: 0 };
  if (At((P = (O = ut()) == null ? void 0 : O.flowchart) == null ? void 0 : P.htmlLabels)) {
    const R = h.children[0], E = ht(h);
    u = R.getBoundingClientRect(), E.attr("width", u.width), E.attr("height", u.height);
  }
  F.info("Text 2", l);
  const f = l || [], p = h.getBBox(), g = s.node().appendChild(
    await or(
      f.join ? f.join("<br/>") : f,
      t.labelStyle,
      !0,
      !0
    )
  ), m = g.children[0], x = ht(g);
  u = m.getBoundingClientRect(), x.attr("width", u.width), x.attr("height", u.height);
  const y = (t.padding || 0) / 2;
  ht(g).attr(
    "transform",
    "translate( " + (u.width > p.width ? 0 : (p.width - u.width) / 2) + ", " + (p.height + y + 5) + ")"
  ), ht(h).attr(
    "transform",
    "translate( " + (u.width < p.width ? 0 : -(p.width - u.width) / 2) + ", 0)"
  ), u = s.node().getBBox(), s.attr(
    "transform",
    "translate(" + -u.width / 2 + ", " + (-u.height / 2 - y + 3) + ")"
  );
  const b = u.width + (t.padding || 0), _ = u.height + (t.padding || 0), k = -u.width / 2 - y, v = -u.height / 2 - y;
  let C, S;
  if (t.look === "handDrawn") {
    const R = j.svg(a), E = Y(t, {}), N = R.path(
      Ke(k, v, b, _, t.rx || 0),
      E
    ), D = R.line(
      -u.width / 2 - y,
      -u.height / 2 - y + p.height + y,
      u.width / 2 + y,
      -u.height / 2 - y + p.height + y,
      E
    );
    S = a.insert(() => (F.debug("Rough node insert CXC", N), D), ":first-child"), C = a.insert(() => (F.debug("Rough node insert CXC", N), N), ":first-child");
  } else
    C = o.insert("rect", ":first-child"), S = o.insert("line"), C.attr("class", "outer title-state").attr("style", i).attr("x", -u.width / 2 - y).attr("y", -u.height / 2 - y).attr("width", u.width + (t.padding || 0)).attr("height", u.height + (t.padding || 0)), S.attr("class", "divider").attr("x1", -u.width / 2 - y).attr("x2", u.width / 2 + y).attr("y1", -u.height / 2 - y + p.height + y).attr("y2", -u.height / 2 - y + p.height + y);
  return U(t, C), t.intersect = function(R) {
    return W.rect(t, R);
  }, a;
}
d(dg, "rectWithTitle");
function Si(e, t, r, i, n, a, o) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, p = u / n, g = f / a, m = Math.sqrt(p ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const x = Math.sqrt(1 - m ** 2), y = l + x * a * Math.sin(h) * (o ? -1 : 1), b = c - x * n * Math.cos(h) * (o ? -1 : 1), _ = Math.atan2((t - b) / a, (e - y) / n);
  let v = Math.atan2((i - b) / a, (r - y) / n) - _;
  o && v < 0 && (v += 2 * Math.PI), !o && v > 0 && (v -= 2 * Math.PI);
  const C = [];
  for (let S = 0; S < 20; S++) {
    const O = S / 19, P = _ + O * v, R = y + n * Math.cos(P), E = b + a * Math.sin(P);
    C.push({ x: R, y: E });
  }
  return C;
}
d(Si, "generateArcPoints");
async function gg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = (t == null ? void 0 : t.padding) ?? 0, s = (t == null ? void 0 : t.padding) ?? 0, l = (t != null && t.width ? t == null ? void 0 : t.width : a.width) + o * 2, c = (t != null && t.height ? t == null ? void 0 : t.height : a.height) + s * 2, h = t.radius || 5, u = t.taper || 5, { cssStyles: f } = t, p = j.svg(n), g = Y(t, {});
  t.stroke && (g.stroke = t.stroke), t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    // Top edge (left to right)
    { x: -l / 2 + u, y: -c / 2 },
    // Top-left corner start (1)
    { x: l / 2 - u, y: -c / 2 },
    // Top-right corner start (2)
    ...Si(l / 2 - u, -c / 2, l / 2, -c / 2 + u, h, h, !0),
    // Top-left arc (2 to 3)
    // Right edge (top to bottom)
    { x: l / 2, y: -c / 2 + u },
    // Top-right taper point (3)
    { x: l / 2, y: c / 2 - u },
    // Bottom-right taper point (4)
    ...Si(l / 2, c / 2 - u, l / 2 - u, c / 2, h, h, !0),
    // Top-left arc (4 to 5)
    // Bottom edge (right to left)
    { x: l / 2 - u, y: c / 2 },
    // Bottom-right corner start (5)
    { x: -l / 2 + u, y: c / 2 },
    // Bottom-left corner start (6)
    ...Si(-l / 2 + u, c / 2, -l / 2, c / 2 - u, h, h, !0),
    // Top-left arc (4 to 5)
    // Left edge (bottom to top)
    { x: -l / 2, y: c / 2 - u },
    // Bottom-left taper point (7)
    { x: -l / 2, y: -c / 2 + u },
    // Top-left taper point (8)
    ...Si(-l / 2, -c / 2 + u, -l / 2 + u, -c / 2, h, h, !0)
    // Top-left arc (4 to 5)
  ], x = lt(m), y = p.path(x, g), b = n.insert(() => y, ":first-child");
  return b.attr("class", "basic label-container outer-path"), f && t.look !== "handDrawn" && b.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && b.selectChildren("path").attr("style", i), U(t, b), t.intersect = function(_) {
    return W.polygon(t, m, _);
  }, n;
}
d(gg, "roundedRect");
async function mg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = (t == null ? void 0 : t.padding) ?? 0, l = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = -a.width / 2 - s, u = -a.height / 2 - s, { cssStyles: f } = t, p = j.svg(n), g = Y(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u },
    { x: h + l + 8, y: u },
    { x: h + l + 8, y: u + c },
    { x: h - 8, y: u + c },
    { x: h - 8, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], x = p.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), y = n.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container").attr("style", zt(f)), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), f && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-l / 2 + 4 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), U(t, y), t.intersect = function(b) {
    return W.rect(t, b);
  }, n;
}
d(mg, "shadedProcess");
async function yg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = -s / 2, h = -l / 2, { cssStyles: u } = t, f = j.svg(n), p = Y(t, {});
  t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
  const g = [
    { x: c, y: h },
    { x: c, y: h + l },
    { x: c + s, y: h + l },
    { x: c + s, y: h - l / 2 }
  ], m = lt(g), x = f.path(m, p), y = n.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container"), u && t.look !== "handDrawn" && y.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), y.attr("transform", `translate(0, ${l / 4})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))}, ${-l / 4 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), U(t, y), t.intersect = function(b) {
    return W.polygon(t, g, b);
  }, n;
}
d(yg, "slopedRect");
async function xg(e, t) {
  const r = {
    rx: 0,
    ry: 0,
    labelPaddingX: t.labelPaddingX ?? ((t == null ? void 0 : t.padding) || 0) * 2,
    labelPaddingY: ((t == null ? void 0 : t.padding) || 0) * 1
  };
  return za(e, t, r);
}
d(xg, "squareRect");
async function bg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.height + t.padding, s = a.width + o / 4 + t.padding, l = o / 2, { cssStyles: c } = t, h = j.svg(n), u = Y(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = [
    { x: -s / 2 + l, y: -o / 2 },
    { x: s / 2 - l, y: -o / 2 },
    ...ji(-s / 2 + l, 0, l, 50, 90, 270),
    { x: s / 2 - l, y: o / 2 },
    ...ji(s / 2 - l, 0, l, 50, 270, 450)
  ], p = lt(f), g = h.path(p, u), m = n.insert(() => g, ":first-child");
  return m.attr("class", "basic label-container outer-path"), c && t.look !== "handDrawn" && m.selectChildren("path").attr("style", c), i && t.look !== "handDrawn" && m.selectChildren("path").attr("style", i), U(t, m), t.intersect = function(x) {
    return W.polygon(t, f, x);
  }, n;
}
d(bg, "stadium");
async function Cg(e, t) {
  return za(e, t, {
    rx: 5,
    ry: 5
  });
}
d(Cg, "state");
function _g(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { cssStyles: a } = t, { lineColor: o, stateBorder: s, nodeBorder: l } = r, c = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), h = j.svg(c), u = Y(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = h.circle(0, 0, 14, {
    ...u,
    stroke: o,
    strokeWidth: 2
  }), p = s ?? l, g = h.circle(0, 0, 5, {
    ...u,
    fill: p,
    stroke: p,
    strokeWidth: 2,
    fillStyle: "solid"
  }), m = c.insert(() => f, ":first-child");
  return m.insert(() => g), a && m.selectAll("path").attr("style", a), n && m.selectAll("path").attr("style", n), U(t, m), t.intersect = function(x) {
    return W.circle(t, 7, x);
  }, c;
}
d(_g, "stateEnd");
function wg(e, t, { config: { themeVariables: r } }) {
  const { lineColor: i } = r, n = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id);
  let a;
  if (t.look === "handDrawn") {
    const s = j.svg(n).circle(0, 0, 14, oC(i));
    a = n.insert(() => s), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  } else
    a = n.insert("circle", ":first-child"), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  return U(t, a), t.intersect = function(o) {
    return W.circle(t, 7, o);
  }, n;
}
d(wg, "stateStart");
async function vg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = ((t == null ? void 0 : t.padding) || 0) / 2, s = a.width + t.padding, l = a.height + t.padding, c = -a.width / 2 - o, h = -a.height / 2 - o, u = [
    { x: 0, y: 0 },
    { x: s, y: 0 },
    { x: s, y: -l },
    { x: 0, y: -l },
    { x: 0, y: 0 },
    { x: -8, y: 0 },
    { x: s + 8, y: 0 },
    { x: s + 8, y: -l },
    { x: -8, y: -l },
    { x: -8, y: 0 }
  ];
  if (t.look === "handDrawn") {
    const f = j.svg(n), p = Y(t, {}), g = f.rectangle(c - 8, h, s + 16, l, p), m = f.line(c, h, c, h + l, p), x = f.line(c + s, h, c + s, h + l, p);
    n.insert(() => m, ":first-child"), n.insert(() => x, ":first-child");
    const y = n.insert(() => g, ":first-child"), { cssStyles: b } = t;
    y.attr("class", "basic label-container").attr("style", zt(b)), U(t, y);
  } else {
    const f = Qe(n, s, l, u);
    i && f.attr("style", i), U(t, f);
  }
  return t.intersect = function(f) {
    return W.polygon(t, u, f);
  }, n;
}
d(vg, "subroutine");
async function kg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = -o / 2, c = -s / 2, h = 0.2 * s, u = 0.2 * s, { cssStyles: f } = t, p = j.svg(n), g = Y(t, {}), m = [
    { x: l - h / 2, y: c },
    { x: l + o + h / 2, y: c },
    { x: l + o + h / 2, y: c + s },
    { x: l - h / 2, y: c + s }
  ], x = [
    { x: l + o - h / 2, y: c + s },
    { x: l + o + h / 2, y: c + s },
    { x: l + o + h / 2, y: c + s - u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = lt(m), b = p.path(y, g), _ = lt(x), k = p.path(_, { ...g, fillStyle: "solid" }), v = n.insert(() => k, ":first-child");
  return v.insert(() => b, ":first-child"), v.attr("class", "basic label-container"), f && t.look !== "handDrawn" && v.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && v.selectAll("path").attr("style", i), U(t, v), t.intersect = function(C) {
    return W.polygon(t, m, C);
  }, n;
}
d(kg, "taggedRect");
async function Sg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = 0.2 * s, u = 0.2 * l, f = l + c, { cssStyles: p } = t, g = j.svg(n), m = Y(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = [
    { x: -s / 2 - s / 2 * 0.1, y: f / 2 },
    ...Xe(
      -s / 2 - s / 2 * 0.1,
      f / 2,
      s / 2 + s / 2 * 0.1,
      f / 2,
      c,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -f / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -f / 2 }
  ], y = -s / 2 + s / 2 * 0.1, b = -f / 2 - u * 0.4, _ = [
    { x: y + s - h, y: (b + l) * 1.4 },
    { x: y + s, y: b + l - u },
    { x: y + s, y: (b + l) * 0.9 },
    ...Xe(
      y + s,
      (b + l) * 1.3,
      y + s - h,
      (b + l) * 1.5,
      -l * 0.03,
      0.5
    )
  ], k = lt(x), v = g.path(k, m), C = lt(_), S = g.path(C, {
    ...m,
    fillStyle: "solid"
  }), O = n.insert(() => S, ":first-child");
  return O.insert(() => v, ":first-child"), O.attr("class", "basic label-container"), p && t.look !== "handDrawn" && O.selectAll("path").attr("style", p), i && t.look !== "handDrawn" && O.selectAll("path").attr("style", i), O.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), U(t, O), t.intersect = function(P) {
    return W.polygon(t, x, P);
  }, n;
}
d(Sg, "taggedWaveEdgedRectangle");
async function Tg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = Math.max(a.width + t.padding, (t == null ? void 0 : t.width) || 0), s = Math.max(a.height + t.padding, (t == null ? void 0 : t.height) || 0), l = -o / 2, c = -s / 2, h = n.insert("rect", ":first-child");
  return h.attr("class", "text").attr("style", i).attr("rx", 0).attr("ry", 0).attr("x", l).attr("y", c).attr("width", o).attr("height", s), U(t, h), t.intersect = function(u) {
    return W.rect(t, u);
  }, n;
}
d(Tg, "text");
var Xk = /* @__PURE__ */ d((e, t, r, i, n, a) => `M${e},${t}
    a${n},${a} 0,0,1 0,${-i}
    l${r},0
    a${n},${a} 0,0,1 0,${i}
    M${r},${-i}
    a${n},${a} 0,0,0 0,${i}
    l${-r},0`, "createCylinderPathD"), Vk = /* @__PURE__ */ d((e, t, r, i, n, a) => [
  `M${e},${t}`,
  `M${e + r},${t}`,
  `a${n},${a} 0,0,0 0,${-i}`,
  `l${-r},0`,
  `a${n},${a} 0,0,0 0,${i}`,
  `l${r},0`
].join(" "), "createOuterCylinderPathD"), Zk = /* @__PURE__ */ d((e, t, r, i, n, a) => [`M${e + r / 2},${-i / 2}`, `a${n},${a} 0,0,0 0,${i}`].join(" "), "createInnerCylinderPathD");
async function Bg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o, halfPadding: s } = await et(
    e,
    t,
    tt(t)
  ), l = t.look === "neo" ? s * 2 : s, c = a.height + l, h = c / 2, u = h / (2.5 + c / 50), f = a.width + u + l, { cssStyles: p } = t;
  let g;
  if (t.look === "handDrawn") {
    const m = j.svg(n), x = Vk(0, 0, f, c, u, h), y = Zk(0, 0, f, c, u, h), b = m.path(x, Y(t, {})), _ = m.path(y, Y(t, { fill: "none" }));
    g = n.insert(() => _, ":first-child"), g = n.insert(() => b, ":first-child"), g.attr("class", "basic label-container"), p && g.attr("style", p);
  } else {
    const m = Xk(0, 0, f, c, u, h);
    g = n.insert("path", ":first-child").attr("d", m).attr("class", "basic label-container").attr("style", zt(p)).attr("style", i), g.attr("class", "basic label-container"), p && g.selectAll("path").attr("style", p), i && g.selectAll("path").attr("style", i);
  }
  return g.attr("label-offset-x", u), g.attr("transform", `translate(${-f / 2}, ${c / 2} )`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - u - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), U(t, g), t.intersect = function(m) {
    const x = W.rect(t, m), y = x.y - (t.y ?? 0);
    if (h != 0 && (Math.abs(y) < (t.height ?? 0) / 2 || Math.abs(y) == (t.height ?? 0) / 2 && Math.abs(x.x - (t.x ?? 0)) > (t.width ?? 0) / 2 - u)) {
      let b = u * u * (1 - y * y / (h * h));
      b != 0 && (b = Math.sqrt(Math.abs(b))), b = u - b, m.x - (t.x ?? 0) > 0 && (b = -b), x.x += b;
    }
    return x;
  }, n;
}
d(Bg, "tiltedCylinder");
async function Lg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = a.width + t.padding, s = a.height + t.padding, l = [
    { x: -3 * s / 6, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: 0, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), f = Y(t, {}), p = lt(l), g = u.path(p, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Qe(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, U(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
d(Lg, "trapezoid");
async function Ag(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = 60, s = 20, l = Math.max(o, a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), { cssStyles: h } = t, u = j.svg(n), f = Y(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const p = [
    { x: -l / 2 * 0.8, y: -c / 2 },
    { x: l / 2 * 0.8, y: -c / 2 },
    { x: l / 2, y: -c / 2 * 0.6 },
    { x: l / 2, y: c / 2 },
    { x: -l / 2, y: c / 2 },
    { x: -l / 2, y: -c / 2 * 0.6 }
  ], g = lt(p), m = u.path(g, f), x = n.insert(() => m, ":first-child");
  return x.attr("class", "basic label-container"), h && t.look !== "handDrawn" && x.selectChildren("path").attr("style", h), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), U(t, x), t.intersect = function(y) {
    return W.polygon(t, p, y);
  }, n;
}
d(Ag, "trapezoidalPentagon");
async function Mg(e, t) {
  var b;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = At((b = ut().flowchart) == null ? void 0 : b.htmlLabels), l = a.width + (t.padding ?? 0), c = l + a.height, h = l + a.height, u = [
    { x: 0, y: 0 },
    { x: h, y: 0 },
    { x: h / 2, y: -c }
  ], { cssStyles: f } = t, p = j.svg(n), g = Y(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = lt(u), x = p.path(m, g), y = n.insert(() => x, ":first-child").attr("transform", `translate(${-c / 2}, ${c / 2})`);
  return f && t.look !== "handDrawn" && y.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), t.width = l, t.height = c, U(t, y), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${c / 2 - (a.height + (t.padding ?? 0) / (s ? 2 : 1) - (a.y - (a.top ?? 0)))})`
  ), t.intersect = function(_) {
    return F.info("Triangle intersect", t, u, _), W.polygon(t, u, _);
  }, n;
}
d(Mg, "triangle");
async function Eg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 8, h = l + c, { cssStyles: u } = t, p = 70 - s, g = p > 0 ? p / 2 : 0, m = j.svg(n), x = Y(t, {});
  t.look !== "handDrawn" && (x.roughness = 0, x.fillStyle = "solid");
  const y = [
    { x: -s / 2 - g, y: h / 2 },
    ...Xe(
      -s / 2 - g,
      h / 2,
      s / 2 + g,
      h / 2,
      c,
      0.8
    ),
    { x: s / 2 + g, y: -h / 2 },
    { x: -s / 2 - g, y: -h / 2 }
  ], b = lt(y), _ = m.path(b, x), k = n.insert(() => _, ":first-child");
  return k.attr("class", "basic label-container"), u && t.look !== "handDrawn" && k.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c - (a.y - (a.top ?? 0))})`
  ), U(t, k), t.intersect = function(v) {
    return W.polygon(t, y, v);
  }, n;
}
d(Eg, "waveEdgedRectangle");
async function $g(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await et(e, t, tt(t)), o = 100, s = 50, l = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = l / c;
  let u = l, f = c;
  u > f * h ? f = u / h : u = f * h, u = Math.max(u, o), f = Math.max(f, s);
  const p = Math.min(f * 0.2, f / 4), g = f + p * 2, { cssStyles: m } = t, x = j.svg(n), y = Y(t, {});
  t.look !== "handDrawn" && (y.roughness = 0, y.fillStyle = "solid");
  const b = [
    { x: -u / 2, y: g / 2 },
    ...Xe(-u / 2, g / 2, u / 2, g / 2, p, 1),
    { x: u / 2, y: -g / 2 },
    ...Xe(u / 2, -g / 2, -u / 2, -g / 2, p, -1)
  ], _ = lt(b), k = x.path(_, y), v = n.insert(() => k, ":first-child");
  return v.attr("class", "basic label-container"), m && t.look !== "handDrawn" && v.selectAll("path").attr("style", m), i && t.look !== "handDrawn" && v.selectAll("path").attr("style", i), U(t, v), t.intersect = function(C) {
    return W.polygon(t, b, C);
  }, n;
}
d($g, "waveRectangle");
async function Fg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await et(e, t, tt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = 5, h = -s / 2, u = -l / 2, { cssStyles: f } = t, p = j.svg(n), g = Y(t, {}), m = [
    { x: h - c, y: u - c },
    { x: h - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u - c }
  ], x = `M${h - c},${u - c} L${h + s},${u - c} L${h + s},${u + l} L${h - c},${u + l} L${h - c},${u - c}
                M${h - c},${u} L${h + s},${u}
                M${h},${u - c} L${h},${u + l}`;
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = p.path(x, g), b = n.insert(() => y, ":first-child");
  return b.attr("transform", `translate(${c / 2}, ${c / 2})`), b.attr("class", "basic label-container"), f && t.look !== "handDrawn" && b.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) + c / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c / 2 - (a.y - (a.top ?? 0))})`
  ), U(t, b), t.intersect = function(_) {
    return W.polygon(t, m, _);
  }, n;
}
d(Fg, "windowPane");
async function yl(e, t) {
  var dt, at, wt, st;
  const r = t;
  if (r.alias && (t.label = r.alias), t.look === "handDrawn") {
    const { themeVariables: nt } = Pt(), { background: ct } = nt, _t = {
      ...t,
      id: t.id + "-background",
      look: "default",
      cssStyles: ["stroke: none", `fill: ${ct}`]
    };
    await yl(e, _t);
  }
  const i = Pt();
  t.useHtmlLabels = i.htmlLabels;
  let n = ((dt = i.er) == null ? void 0 : dt.diagramPadding) ?? 10, a = ((at = i.er) == null ? void 0 : at.entityPadding) ?? 6;
  const { cssStyles: o } = t, { labelStyles: s, nodeStyles: l } = G(t);
  if (r.attributes.length === 0 && t.label) {
    const nt = {
      rx: 0,
      ry: 0,
      labelPaddingX: n,
      labelPaddingY: n * 1.5
    };
    Ne(t.label, i) + nt.labelPaddingX * 2 < i.er.minEntityWidth && (t.width = i.er.minEntityWidth);
    const ct = await za(e, t, nt);
    if (!At(i.htmlLabels)) {
      const _t = ct.select("text"), mt = (wt = _t.node()) == null ? void 0 : wt.getBBox();
      _t.attr("transform", `translate(${-mt.width / 2}, 0)`);
    }
    return ct;
  }
  i.htmlLabels || (n *= 1.25, a *= 1.25);
  let c = tt(t);
  c || (c = "node default");
  const h = e.insert("g").attr("class", c).attr("id", t.domId || t.id), u = await Er(h, t.label ?? "", i, 0, 0, ["name"], s);
  u.height += a;
  let f = 0;
  const p = [], g = [];
  let m = 0, x = 0, y = 0, b = 0, _ = !0, k = !0;
  for (const nt of r.attributes) {
    const ct = await Er(
      h,
      nt.type,
      i,
      0,
      f,
      ["attribute-type"],
      s
    );
    m = Math.max(m, ct.width + n);
    const _t = await Er(
      h,
      nt.name,
      i,
      0,
      f,
      ["attribute-name"],
      s
    );
    x = Math.max(x, _t.width + n);
    const mt = await Er(
      h,
      nt.keys.join(),
      i,
      0,
      f,
      ["attribute-keys"],
      s
    );
    y = Math.max(y, mt.width + n);
    const yt = await Er(
      h,
      nt.comment,
      i,
      0,
      f,
      ["attribute-comment"],
      s
    );
    b = Math.max(b, yt.width + n);
    const kt = Math.max(ct.height, _t.height, mt.height, yt.height) + a;
    g.push({ yOffset: f, rowHeight: kt }), f += kt;
  }
  let v = 4;
  y <= n && (_ = !1, y = 0, v--), b <= n && (k = !1, b = 0, v--);
  const C = h.node().getBBox();
  if (u.width + n * 2 - (m + x + y + b) > 0) {
    const nt = u.width + n * 2 - (m + x + y + b);
    m += nt / v, x += nt / v, y > 0 && (y += nt / v), b > 0 && (b += nt / v);
  }
  const S = m + x + y + b, O = j.svg(h), P = Y(t, {});
  t.look !== "handDrawn" && (P.roughness = 0, P.fillStyle = "solid");
  let R = 0;
  g.length > 0 && (R = g.reduce((nt, ct) => nt + ((ct == null ? void 0 : ct.rowHeight) ?? 0), 0));
  const E = Math.max(C.width + n * 2, (t == null ? void 0 : t.width) || 0, S), N = Math.max((R ?? 0) + u.height, (t == null ? void 0 : t.height) || 0), D = -E / 2, L = -N / 2;
  h.selectAll("g:not(:first-child)").each((nt, ct, _t) => {
    const mt = ht(_t[ct]), yt = mt.attr("transform");
    let kt = 0, qt = 0;
    if (yt) {
      const le = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(yt);
      le && (kt = parseFloat(le[1]), qt = parseFloat(le[2]), mt.attr("class").includes("attribute-name") ? kt += m : mt.attr("class").includes("attribute-keys") ? kt += m + x : mt.attr("class").includes("attribute-comment") && (kt += m + x + y));
    }
    mt.attr(
      "transform",
      `translate(${D + n / 2 + kt}, ${qt + L + u.height + a / 2})`
    );
  }), h.select(".name").attr("transform", "translate(" + -u.width / 2 + ", " + (L + a / 2) + ")");
  const A = O.rectangle(D, L, E, N, P), B = h.insert(() => A, ":first-child").attr("style", o.join("")), { themeVariables: $ } = Pt(), { rowEven: M, rowOdd: q, nodeBorder: Z } = $;
  p.push(0);
  for (const [nt, ct] of g.entries()) {
    const mt = (nt + 1) % 2 === 0 && ct.yOffset !== 0, yt = O.rectangle(D, u.height + L + (ct == null ? void 0 : ct.yOffset), E, ct == null ? void 0 : ct.rowHeight, {
      ...P,
      fill: mt ? M : q,
      stroke: Z
    });
    h.insert(() => yt, "g.label").attr("style", o.join("")).attr("class", `row-rect-${mt ? "even" : "odd"}`);
  }
  let X = O.line(D, u.height + L, E + D, u.height + L, P);
  h.insert(() => X).attr("class", "divider"), X = O.line(m + D, u.height + L, m + D, N + L, P), h.insert(() => X).attr("class", "divider"), _ && (X = O.line(
    m + x + D,
    u.height + L,
    m + x + D,
    N + L,
    P
  ), h.insert(() => X).attr("class", "divider")), k && (X = O.line(
    m + x + y + D,
    u.height + L,
    m + x + y + D,
    N + L,
    P
  ), h.insert(() => X).attr("class", "divider"));
  for (const nt of p)
    X = O.line(
      D,
      u.height + L + nt,
      E + D,
      u.height + L + nt,
      P
    ), h.insert(() => X).attr("class", "divider");
  if (U(t, B), l && t.look !== "handDrawn") {
    const nt = l.split(";"), ct = (st = nt == null ? void 0 : nt.filter((_t) => _t.includes("stroke"))) == null ? void 0 : st.map((_t) => `${_t}`).join("; ");
    h.selectAll("path").attr("style", ct ?? ""), h.selectAll(".row-rect-even path").attr("style", l);
  }
  return t.intersect = function(nt) {
    return W.rect(t, nt);
  }, h;
}
d(yl, "erBox");
async function Er(e, t, r, i = 0, n = 0, a = [], o = "") {
  const s = e.insert("g").attr("class", `label ${a.join(" ")}`).attr("transform", `translate(${i}, ${n})`).attr("style", o);
  t !== Ql(t) && (t = Ql(t), t = t.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
  const l = s.node().appendChild(
    await Ze(
      s,
      t,
      {
        width: Ne(t, r) + 100,
        style: o,
        useHtmlLabels: r.htmlLabels
      },
      r
    )
  );
  if (t.includes("&lt;") || t.includes("&gt;")) {
    let h = l.children[0];
    for (h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">"); h.childNodes[0]; )
      h = h.childNodes[0], h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
  }
  let c = l.getBBox();
  if (At(r.htmlLabels)) {
    const h = l.children[0];
    h.style.textAlign = "start";
    const u = ht(l);
    c = h.getBoundingClientRect(), u.attr("width", c.width), u.attr("height", c.height);
  }
  return c;
}
d(Er, "addText");
async function Dg(e, t, r, i, n = r.class.padding ?? 12) {
  const a = i ? 0 : 3, o = e.insert("g").attr("class", tt(t)).attr("id", t.domId || t.id);
  let s = null, l = null, c = null, h = null, u = 0, f = 0, p = 0;
  if (s = o.insert("g").attr("class", "annotation-group text"), t.annotations.length > 0) {
    const b = t.annotations[0];
    await Ti(s, { text: `«${b}»` }, 0), u = s.node().getBBox().height;
  }
  l = o.insert("g").attr("class", "label-group text"), await Ti(l, t, 0, ["font-weight: bolder"]);
  const g = l.node().getBBox();
  f = g.height, c = o.insert("g").attr("class", "members-group text");
  let m = 0;
  for (const b of t.members) {
    const _ = await Ti(c, b, m, [b.parseClassifier()]);
    m += _ + a;
  }
  p = c.node().getBBox().height, p <= 0 && (p = n / 2), h = o.insert("g").attr("class", "methods-group text");
  let x = 0;
  for (const b of t.methods) {
    const _ = await Ti(h, b, x, [b.parseClassifier()]);
    x += _ + a;
  }
  let y = o.node().getBBox();
  if (s !== null) {
    const b = s.node().getBBox();
    s.attr("transform", `translate(${-b.width / 2})`);
  }
  return l.attr("transform", `translate(${-g.width / 2}, ${u})`), y = o.node().getBBox(), c.attr(
    "transform",
    `translate(0, ${u + f + n * 2})`
  ), y = o.node().getBBox(), h.attr(
    "transform",
    `translate(0, ${u + f + (p ? p + n * 4 : n * 2)})`
  ), y = o.node().getBBox(), { shapeSvg: o, bbox: y };
}
d(Dg, "textHelper");
async function Ti(e, t, r, i = []) {
  const n = e.insert("g").attr("class", "label").attr("style", i.join("; ")), a = Pt();
  let o = "useHtmlLabels" in t ? t.useHtmlLabels : At(a.htmlLabels) ?? !0, s = "";
  "text" in t ? s = t.text : s = t.label, !o && s.startsWith("\\") && (s = s.substring(1)), Ur(s) && (o = !0);
  const l = await Ze(
    n,
    To(Cr(s)),
    {
      width: Ne(s, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o
    },
    a
  );
  let c, h = 1;
  if (o) {
    const u = l.children[0], f = ht(l);
    h = u.innerHTML.split("<br>").length, u.innerHTML.includes("</math>") && (h += u.innerHTML.split("<mrow>").length - 1);
    const p = u.getElementsByTagName("img");
    if (p) {
      const g = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...p].map(
          (m) => new Promise((x) => {
            function y() {
              var b;
              if (m.style.display = "flex", m.style.flexDirection = "column", g) {
                const _ = ((b = a.fontSize) == null ? void 0 : b.toString()) ?? window.getComputedStyle(document.body).fontSize, v = parseInt(_, 10) * 5 + "px";
                m.style.minWidth = v, m.style.maxWidth = v;
              } else
                m.style.width = "100%";
              x(m);
            }
            d(y, "setupImage"), setTimeout(() => {
              m.complete && y();
            }), m.addEventListener("error", y), m.addEventListener("load", y);
          })
        )
      );
    }
    c = u.getBoundingClientRect(), f.attr("width", c.width), f.attr("height", c.height);
  } else {
    i.includes("font-weight: bolder") && ht(l).selectAll("tspan").attr("font-weight", ""), h = l.children.length;
    const u = l.children[0];
    (l.textContent === "" || l.textContent.includes("&gt")) && (u.textContent = s[0] + s.substring(1).replaceAll("&gt;", ">").replaceAll("&lt;", "<").trim(), s[1] === " " && (u.textContent = u.textContent[0] + " " + u.textContent.substring(1))), u.textContent === "undefined" && (u.textContent = ""), c = l.getBBox();
  }
  return n.attr("transform", "translate(0," + (-c.height / (2 * h) + r) + ")"), c.height;
}
d(Ti, "addText");
async function Og(e, t) {
  var P, R;
  const r = ut(), i = r.class.padding ?? 12, n = i, a = t.useHtmlLabels ?? At(r.htmlLabels) ?? !0, o = t;
  o.annotations = o.annotations ?? [], o.members = o.members ?? [], o.methods = o.methods ?? [];
  const { shapeSvg: s, bbox: l } = await Dg(e, t, r, a, n), { labelStyles: c, nodeStyles: h } = G(t);
  t.labelStyle = c, t.cssStyles = o.styles || "";
  const u = ((P = o.styles) == null ? void 0 : P.join(";")) || h || "";
  t.cssStyles || (t.cssStyles = u.replaceAll("!important", "").split(";"));
  const f = o.members.length === 0 && o.methods.length === 0 && !((R = r.class) != null && R.hideEmptyMembersBox), p = j.svg(s), g = Y(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = l.width;
  let x = l.height;
  o.members.length === 0 && o.methods.length === 0 ? x += n : o.members.length > 0 && o.methods.length === 0 && (x += n * 2);
  const y = -m / 2, b = -x / 2, _ = p.rectangle(
    y - i,
    b - i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0),
    m + 2 * i,
    x + 2 * i + (f ? i * 2 : o.members.length === 0 && o.methods.length === 0 ? -i : 0),
    g
  ), k = s.insert(() => _, ":first-child");
  k.attr("class", "basic label-container");
  const v = k.node().getBBox();
  s.selectAll(".text").each((E, N, D) => {
    var q;
    const L = ht(D[N]), A = L.attr("transform");
    let B = 0;
    if (A) {
      const X = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(A);
      X && (B = parseFloat(X[2]));
    }
    let $ = B + b + i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0);
    a || ($ -= 4);
    let M = y;
    (L.attr("class").includes("label-group") || L.attr("class").includes("annotation-group")) && (M = -((q = L.node()) == null ? void 0 : q.getBBox().width) / 2 || 0, s.selectAll("text").each(function(Z, X, dt) {
      window.getComputedStyle(dt[X]).textAnchor === "middle" && (M = 0);
    })), L.attr("transform", `translate(${M}, ${$})`);
  });
  const C = s.select(".annotation-group").node().getBBox().height - (f ? i / 2 : 0) || 0, S = s.select(".label-group").node().getBBox().height - (f ? i / 2 : 0) || 0, O = s.select(".members-group").node().getBBox().height - (f ? i / 2 : 0) || 0;
  if (o.members.length > 0 || o.methods.length > 0 || f) {
    const E = p.line(
      v.x,
      C + S + b + i,
      v.x + v.width,
      C + S + b + i,
      g
    );
    s.insert(() => E).attr("class", "divider").attr("style", u);
  }
  if (f || o.members.length > 0 || o.methods.length > 0) {
    const E = p.line(
      v.x,
      C + S + O + b + n * 2 + i,
      v.x + v.width,
      C + S + O + b + i + n * 2,
      g
    );
    s.insert(() => E).attr("class", "divider").attr("style", u);
  }
  if (o.look !== "handDrawn" && s.selectAll("path").attr("style", u), k.select(":nth-child(2)").attr("style", u), s.selectAll(".divider").select("path").attr("style", u), t.labelStyle ? s.selectAll("span").attr("style", t.labelStyle) : s.selectAll("span").attr("style", u), !a) {
    const E = RegExp(/color\s*:\s*([^;]*)/), N = E.exec(u);
    if (N) {
      const D = N[0].replace("color", "fill");
      s.selectAll("tspan").attr("style", D);
    } else if (c) {
      const D = E.exec(c);
      if (D) {
        const L = D[0].replace("color", "fill");
        s.selectAll("tspan").attr("style", L);
      }
    }
  }
  return U(t, k), t.intersect = function(E) {
    return W.rect(t, E);
  }, s;
}
d(Og, "classBox");
async function Rg(e, t) {
  var C, S;
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const n = t, a = t, o = 20, s = 20, l = "verifyMethod" in t, c = tt(t), h = e.insert("g").attr("class", c).attr("id", t.domId ?? t.id);
  let u;
  l ? u = await be(
    h,
    `&lt;&lt;${n.type}&gt;&gt;`,
    0,
    t.labelStyle
  ) : u = await be(h, "&lt;&lt;Element&gt;&gt;", 0, t.labelStyle);
  let f = u;
  const p = await be(
    h,
    n.name,
    f,
    t.labelStyle + "; font-weight: bold;"
  );
  if (f += p + s, l) {
    const O = await be(
      h,
      `${n.requirementId ? `ID: ${n.requirementId}` : ""}`,
      f,
      t.labelStyle
    );
    f += O;
    const P = await be(
      h,
      `${n.text ? `Text: ${n.text}` : ""}`,
      f,
      t.labelStyle
    );
    f += P;
    const R = await be(
      h,
      `${n.risk ? `Risk: ${n.risk}` : ""}`,
      f,
      t.labelStyle
    );
    f += R, await be(
      h,
      `${n.verifyMethod ? `Verification: ${n.verifyMethod}` : ""}`,
      f,
      t.labelStyle
    );
  } else {
    const O = await be(
      h,
      `${a.type ? `Type: ${a.type}` : ""}`,
      f,
      t.labelStyle
    );
    f += O, await be(
      h,
      `${a.docRef ? `Doc Ref: ${a.docRef}` : ""}`,
      f,
      t.labelStyle
    );
  }
  const g = (((C = h.node()) == null ? void 0 : C.getBBox().width) ?? 200) + o, m = (((S = h.node()) == null ? void 0 : S.getBBox().height) ?? 200) + o, x = -g / 2, y = -m / 2, b = j.svg(h), _ = Y(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const k = b.rectangle(x, y, g, m, _), v = h.insert(() => k, ":first-child");
  if (v.attr("class", "basic label-container").attr("style", i), h.selectAll(".label").each((O, P, R) => {
    const E = ht(R[P]), N = E.attr("transform");
    let D = 0, L = 0;
    if (N) {
      const M = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(N);
      M && (D = parseFloat(M[1]), L = parseFloat(M[2]));
    }
    const A = L - m / 2;
    let B = x + o / 2;
    (P === 0 || P === 1) && (B = D), E.attr("transform", `translate(${B}, ${A + o})`);
  }), f > u + p + s) {
    const O = b.line(
      x,
      y + u + p + s,
      x + g,
      y + u + p + s,
      _
    );
    h.insert(() => O).attr("style", i);
  }
  return U(t, v), t.intersect = function(O) {
    return W.rect(t, O);
  }, h;
}
d(Rg, "requirementBox");
async function be(e, t, r, i = "") {
  if (t === "")
    return 0;
  const n = e.insert("g").attr("class", "label").attr("style", i), a = ut(), o = a.htmlLabels ?? !0, s = await Ze(
    n,
    To(Cr(t)),
    {
      width: Ne(t, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o,
      style: i
    },
    a
  );
  let l;
  if (o) {
    const c = s.children[0], h = ht(s);
    l = c.getBoundingClientRect(), h.attr("width", l.width), h.attr("height", l.height);
  } else {
    const c = s.children[0];
    for (const h of c.children)
      h.textContent = h.textContent.replaceAll("&gt;", ">").replaceAll("&lt;", "<"), i && h.setAttribute("style", i);
    l = s.getBBox(), l.height += 6;
  }
  return n.attr("transform", `translate(${-l.width / 2},${-l.height / 2 + r})`), l.height;
}
d(be, "addText");
var Kk = /* @__PURE__ */ d((e) => {
  switch (e) {
    case "Very High":
      return "red";
    case "High":
      return "orange";
    case "Medium":
      return null;
    case "Low":
      return "blue";
    case "Very Low":
      return "lightblue";
  }
}, "colorFromPriority");
async function Ig(e, t, { config: r }) {
  var N, D;
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i || "";
  const a = 10, o = t.width;
  t.width = (t.width ?? 200) - 10;
  const {
    shapeSvg: s,
    bbox: l,
    label: c
  } = await et(e, t, tt(t)), h = t.padding || 10;
  let u = "", f;
  "ticket" in t && t.ticket && ((N = r == null ? void 0 : r.kanban) != null && N.ticketBaseUrl) && (u = (D = r == null ? void 0 : r.kanban) == null ? void 0 : D.ticketBaseUrl.replace("#TICKET#", t.ticket), f = s.insert("svg:a", ":first-child").attr("class", "kanban-ticket-link").attr("xlink:href", u).attr("target", "_blank"));
  const p = {
    useHtmlLabels: t.useHtmlLabels,
    labelStyle: t.labelStyle || "",
    width: t.width,
    img: t.img,
    padding: t.padding || 8,
    centerLabel: !1
  };
  let g, m;
  f ? { label: g, bbox: m } = await ys(
    f,
    "ticket" in t && t.ticket || "",
    p
  ) : { label: g, bbox: m } = await ys(
    s,
    "ticket" in t && t.ticket || "",
    p
  );
  const { label: x, bbox: y } = await ys(
    s,
    "assigned" in t && t.assigned || "",
    p
  );
  t.width = o;
  const b = 10, _ = (t == null ? void 0 : t.width) || 0, k = Math.max(m.height, y.height) / 2, v = Math.max(l.height + b * 2, (t == null ? void 0 : t.height) || 0) + k, C = -_ / 2, S = -v / 2;
  c.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-k - l.height / 2) + ")"
  ), g.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-k + l.height / 2) + ")"
  ), x.attr(
    "transform",
    "translate(" + (h + _ / 2 - y.width - 2 * a) + ", " + (-k + l.height / 2) + ")"
  );
  let O;
  const { rx: P, ry: R } = t, { cssStyles: E } = t;
  if (t.look === "handDrawn") {
    const L = j.svg(s), A = Y(t, {}), B = P || R ? L.path(Ke(C, S, _, v, P || 0), A) : L.rectangle(C, S, _, v, A);
    O = s.insert(() => B, ":first-child"), O.attr("class", "basic label-container").attr("style", E || null);
  } else {
    O = s.insert("rect", ":first-child"), O.attr("class", "basic label-container __APA__").attr("style", n).attr("rx", P ?? 5).attr("ry", R ?? 5).attr("x", C).attr("y", S).attr("width", _).attr("height", v);
    const L = "priority" in t && t.priority;
    if (L) {
      const A = s.append("line"), B = C + 2, $ = S + Math.floor((P ?? 0) / 2), M = S + v - Math.floor((P ?? 0) / 2);
      A.attr("x1", B).attr("y1", $).attr("x2", B).attr("y2", M).attr("stroke-width", "4").attr("stroke", Kk(L));
    }
  }
  return U(t, O), t.height = v, t.intersect = function(L) {
    return W.rect(t, L);
  }, s;
}
d(Ig, "kanbanItem");
async function Pg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await et(
    e,
    t,
    tt(t)
  ), l = a.width + 10 * o, c = a.height + 8 * o, h = 0.15 * l, { cssStyles: u } = t, f = a.width + 20, p = a.height + 20, g = Math.max(l, f), m = Math.max(c, p);
  s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`);
  let x;
  const y = `M0 0 
    a${h},${h} 1 0,0 ${g * 0.25},${-1 * m * 0.1}
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},${m * 0.1}

    a${h},${h} 1 0,0 ${g * 0.15},${m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${m * 0.34}
    a${h},${h} 1 0,0 ${-1 * g * 0.15},${m * 0.33}

    a${h},${h} 1 0,0 ${-1 * g * 0.25},${m * 0.15}
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},${-1 * m * 0.15}

    a${h},${h} 1 0,0 ${-1 * g * 0.1},${-1 * m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${-1 * m * 0.34}
    a${h},${h} 1 0,0 ${g * 0.1},${-1 * m * 0.33}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const b = j.svg(n), _ = Y(t, {}), k = b.path(y, _);
    x = n.insert(() => k, ":first-child"), x.attr("class", "basic label-container").attr("style", zt(u));
  } else
    x = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", y);
  return x.attr("transform", `translate(${-g / 2}, ${-m / 2})`), U(t, x), t.calcIntersect = function(b, _) {
    return W.rect(b, _);
  }, t.intersect = function(b) {
    return F.info("Bang intersect", t, b), W.rect(t, b);
  }, n;
}
d(Pg, "bang");
async function Ng(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await et(
    e,
    t,
    tt(t)
  ), l = a.width + 2 * o, c = a.height + 2 * o, h = 0.15 * l, u = 0.25 * l, f = 0.35 * l, p = 0.2 * l, { cssStyles: g } = t;
  let m;
  const x = `M0 0 
    a${h},${h} 0 0,1 ${l * 0.25},${-1 * l * 0.1}
    a${f},${f} 1 0,1 ${l * 0.4},${-1 * l * 0.1}
    a${u},${u} 1 0,1 ${l * 0.35},${l * 0.2}

    a${h},${h} 1 0,1 ${l * 0.15},${c * 0.35}
    a${p},${p} 1 0,1 ${-1 * l * 0.15},${c * 0.65}

    a${u},${h} 1 0,1 ${-1 * l * 0.25},${l * 0.15}
    a${f},${f} 1 0,1 ${-1 * l * 0.5},0
    a${h},${h} 1 0,1 ${-1 * l * 0.25},${-1 * l * 0.15}

    a${h},${h} 1 0,1 ${-1 * l * 0.1},${-1 * c * 0.35}
    a${p},${p} 1 0,1 ${l * 0.1},${-1 * c * 0.65}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const y = j.svg(n), b = Y(t, {}), _ = y.path(x, b);
    m = n.insert(() => _, ":first-child"), m.attr("class", "basic label-container").attr("style", zt(g));
  } else
    m = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", x);
  return s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), m.attr("transform", `translate(${-l / 2}, ${-c / 2})`), U(t, m), t.calcIntersect = function(y, b) {
    return W.rect(y, b);
  }, t.intersect = function(y) {
    return F.info("Cloud intersect", t, y), W.rect(t, y);
  }, n;
}
d(Ng, "cloud");
async function zg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await et(
    e,
    t,
    tt(t)
  ), l = a.width + 8 * o, c = a.height + 2 * o, h = 5, u = `
    M${-l / 2} ${c / 2 - h}
    v${-c + 2 * h}
    q0,-${h} ${h},-${h}
    h${l - 2 * h}
    q${h},0 ${h},${h}
    v${c - 2 * h}
    q0,${h} -${h},${h}
    h${-l + 2 * h}
    q-${h},0 -${h},-${h}
    Z
  `, f = n.append("path").attr("id", "node-" + t.id).attr("class", "node-bkg node-" + t.type).attr("style", i).attr("d", u);
  return n.append("line").attr("class", "node-line-").attr("x1", -l / 2).attr("y1", c / 2).attr("x2", l / 2).attr("y2", c / 2), s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), n.append(() => s.node()), U(t, f), t.calcIntersect = function(p, g) {
    return W.rect(p, g);
  }, t.intersect = function(p) {
    return W.rect(t, p);
  }, n;
}
d(zg, "defaultMindmapNode");
async function Wg(e, t) {
  const r = {
    padding: t.padding ?? 0
  };
  return ml(e, t, r);
}
d(Wg, "mindmapCircle");
var Qk = [
  {
    semanticName: "Process",
    name: "Rectangle",
    shortName: "rect",
    description: "Standard process shape",
    aliases: ["proc", "process", "rectangle"],
    internalAliases: ["squareRect"],
    handler: xg
  },
  {
    semanticName: "Event",
    name: "Rounded Rectangle",
    shortName: "rounded",
    description: "Represents an event",
    aliases: ["event"],
    internalAliases: ["roundedRect"],
    handler: gg
  },
  {
    semanticName: "Terminal Point",
    name: "Stadium",
    shortName: "stadium",
    description: "Terminal point",
    aliases: ["terminal", "pill"],
    handler: bg
  },
  {
    semanticName: "Subprocess",
    name: "Framed Rectangle",
    shortName: "fr-rect",
    description: "Subprocess",
    aliases: ["subprocess", "subproc", "framed-rectangle", "subroutine"],
    handler: vg
  },
  {
    semanticName: "Database",
    name: "Cylinder",
    shortName: "cyl",
    description: "Database storage",
    aliases: ["db", "database", "cylinder"],
    handler: qd
  },
  {
    semanticName: "Start",
    name: "Circle",
    shortName: "circle",
    description: "Starting point",
    aliases: ["circ"],
    handler: ml
  },
  {
    semanticName: "Bang",
    name: "Bang",
    shortName: "bang",
    description: "Bang",
    aliases: ["bang"],
    handler: Pg
  },
  {
    semanticName: "Cloud",
    name: "Cloud",
    shortName: "cloud",
    description: "cloud",
    aliases: ["cloud"],
    handler: Ng
  },
  {
    semanticName: "Decision",
    name: "Diamond",
    shortName: "diam",
    description: "Decision-making step",
    aliases: ["decision", "diamond", "question"],
    handler: fg
  },
  {
    semanticName: "Prepare Conditional",
    name: "Hexagon",
    shortName: "hex",
    description: "Preparation or condition step",
    aliases: ["hexagon", "prepare"],
    handler: Vd
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Right",
    shortName: "lean-r",
    description: "Represents input or output",
    aliases: ["lean-right", "in-out"],
    internalAliases: ["lean_right"],
    handler: ag
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Left",
    shortName: "lean-l",
    description: "Represents output or input",
    aliases: ["lean-left", "out-in"],
    internalAliases: ["lean_left"],
    handler: ng
  },
  {
    semanticName: "Priority Action",
    name: "Trapezoid Base Bottom",
    shortName: "trap-b",
    description: "Priority action",
    aliases: ["priority", "trapezoid-bottom", "trapezoid"],
    handler: Lg
  },
  {
    semanticName: "Manual Operation",
    name: "Trapezoid Base Top",
    shortName: "trap-t",
    description: "Represents a manual task",
    aliases: ["manual", "trapezoid-top", "inv-trapezoid"],
    internalAliases: ["inv_trapezoid"],
    handler: rg
  },
  {
    semanticName: "Stop",
    name: "Double Circle",
    shortName: "dbl-circ",
    description: "Represents a stop point",
    aliases: ["double-circle"],
    internalAliases: ["doublecircle"],
    handler: jd
  },
  {
    semanticName: "Text Block",
    name: "Text Block",
    shortName: "text",
    description: "Text block",
    handler: Tg
  },
  {
    semanticName: "Card",
    name: "Notched Rectangle",
    shortName: "notch-rect",
    description: "Represents a card",
    aliases: ["card", "notched-rectangle"],
    handler: Dd
  },
  {
    semanticName: "Lined/Shaded Process",
    name: "Lined Rectangle",
    shortName: "lin-rect",
    description: "Lined process shape",
    aliases: ["lined-rectangle", "lined-process", "lin-proc", "shaded-process"],
    handler: mg
  },
  {
    semanticName: "Start",
    name: "Small Circle",
    shortName: "sm-circ",
    description: "Small starting point",
    aliases: ["start", "small-circle"],
    internalAliases: ["stateStart"],
    handler: wg
  },
  {
    semanticName: "Stop",
    name: "Framed Circle",
    shortName: "fr-circ",
    description: "Stop point",
    aliases: ["stop", "framed-circle"],
    internalAliases: ["stateEnd"],
    handler: _g
  },
  {
    semanticName: "Fork/Join",
    name: "Filled Rectangle",
    shortName: "fork",
    description: "Fork or join in process flow",
    aliases: ["join"],
    internalAliases: ["forkJoin"],
    handler: Gd
  },
  {
    semanticName: "Collate",
    name: "Hourglass",
    shortName: "hourglass",
    description: "Represents a collate operation",
    aliases: ["hourglass", "collate"],
    handler: Zd
  },
  {
    semanticName: "Comment",
    name: "Curly Brace",
    shortName: "brace",
    description: "Adds a comment",
    aliases: ["comment", "brace-l"],
    handler: Pd
  },
  {
    semanticName: "Comment Right",
    name: "Curly Brace",
    shortName: "brace-r",
    description: "Adds a comment",
    handler: Nd
  },
  {
    semanticName: "Comment with braces on both sides",
    name: "Curly Braces",
    shortName: "braces",
    description: "Adds a comment",
    handler: zd
  },
  {
    semanticName: "Com Link",
    name: "Lightning Bolt",
    shortName: "bolt",
    description: "Communication link",
    aliases: ["com-link", "lightning-bolt"],
    handler: sg
  },
  {
    semanticName: "Document",
    name: "Document",
    shortName: "doc",
    description: "Represents a document",
    aliases: ["doc", "document"],
    handler: Eg
  },
  {
    semanticName: "Delay",
    name: "Half-Rounded Rectangle",
    shortName: "delay",
    description: "Represents a delay",
    aliases: ["half-rounded-rectangle"],
    handler: Xd
  },
  {
    semanticName: "Direct Access Storage",
    name: "Horizontal Cylinder",
    shortName: "h-cyl",
    description: "Direct access storage",
    aliases: ["das", "horizontal-cylinder"],
    handler: Bg
  },
  {
    semanticName: "Disk Storage",
    name: "Lined Cylinder",
    shortName: "lin-cyl",
    description: "Disk storage",
    aliases: ["disk", "lined-cylinder"],
    handler: og
  },
  {
    semanticName: "Display",
    name: "Curved Trapezoid",
    shortName: "curv-trap",
    description: "Represents a display",
    aliases: ["curved-trapezoid", "display"],
    handler: Wd
  },
  {
    semanticName: "Divided Process",
    name: "Divided Rectangle",
    shortName: "div-rect",
    description: "Divided process shape",
    aliases: ["div-proc", "divided-rectangle", "divided-process"],
    handler: Hd
  },
  {
    semanticName: "Extract",
    name: "Triangle",
    shortName: "tri",
    description: "Extraction process",
    aliases: ["extract", "triangle"],
    handler: Mg
  },
  {
    semanticName: "Internal Storage",
    name: "Window Pane",
    shortName: "win-pane",
    description: "Internal storage",
    aliases: ["internal-storage", "window-pane"],
    handler: Fg
  },
  {
    semanticName: "Junction",
    name: "Filled Circle",
    shortName: "f-circ",
    description: "Junction point",
    aliases: ["junction", "filled-circle"],
    handler: Yd
  },
  {
    semanticName: "Loop Limit",
    name: "Trapezoidal Pentagon",
    shortName: "notch-pent",
    description: "Loop limit step",
    aliases: ["loop-limit", "notched-pentagon"],
    handler: Ag
  },
  {
    semanticName: "Manual File",
    name: "Flipped Triangle",
    shortName: "flip-tri",
    description: "Manual file operation",
    aliases: ["manual-file", "flipped-triangle"],
    handler: Ud
  },
  {
    semanticName: "Manual Input",
    name: "Sloped Rectangle",
    shortName: "sl-rect",
    description: "Manual input step",
    aliases: ["manual-input", "sloped-rectangle"],
    handler: yg
  },
  {
    semanticName: "Multi-Document",
    name: "Stacked Document",
    shortName: "docs",
    description: "Multiple documents",
    aliases: ["documents", "st-doc", "stacked-document"],
    handler: hg
  },
  {
    semanticName: "Multi-Process",
    name: "Stacked Rectangle",
    shortName: "st-rect",
    description: "Multiple processes",
    aliases: ["procs", "processes", "stacked-rectangle"],
    handler: cg
  },
  {
    semanticName: "Stored Data",
    name: "Bow Tie Rectangle",
    shortName: "bow-rect",
    description: "Stored data",
    aliases: ["stored-data", "bow-tie-rectangle"],
    handler: Fd
  },
  {
    semanticName: "Summary",
    name: "Crossed Circle",
    shortName: "cross-circ",
    description: "Summary",
    aliases: ["summary", "crossed-circle"],
    handler: Id
  },
  {
    semanticName: "Tagged Document",
    name: "Tagged Document",
    shortName: "tag-doc",
    description: "Tagged document",
    aliases: ["tag-doc", "tagged-document"],
    handler: Sg
  },
  {
    semanticName: "Tagged Process",
    name: "Tagged Rectangle",
    shortName: "tag-rect",
    description: "Tagged process",
    aliases: ["tagged-rectangle", "tag-proc", "tagged-process"],
    handler: kg
  },
  {
    semanticName: "Paper Tape",
    name: "Flag",
    shortName: "flag",
    description: "Paper tape",
    aliases: ["paper-tape"],
    handler: $g
  },
  {
    semanticName: "Odd",
    name: "Odd",
    shortName: "odd",
    description: "Odd shape",
    internalAliases: ["rect_left_inv_arrow"],
    handler: pg
  },
  {
    semanticName: "Lined Document",
    name: "Lined Document",
    shortName: "lin-doc",
    description: "Lined document",
    aliases: ["lined-document"],
    handler: lg
  }
], Jk = /* @__PURE__ */ d(() => {
  const t = [
    ...Object.entries({
      // States
      state: Cg,
      choice: Od,
      note: ug,
      // Rectangles
      rectWithTitle: dg,
      labelRect: ig,
      // Icons
      iconSquare: tg,
      iconCircle: Qd,
      icon: Kd,
      iconRounded: Jd,
      imageSquare: eg,
      anchor: $d,
      // Kanban diagram
      kanbanItem: Ig,
      //Mindmap diagram
      mindmapCircle: Wg,
      defaultMindmapNode: zg,
      // class diagram
      classBox: Og,
      // er diagram
      erBox: yl,
      // Requirement diagram
      requirementBox: Rg
    }),
    ...Qk.flatMap((r) => [
      r.shortName,
      ..."aliases" in r ? r.aliases : [],
      ..."internalAliases" in r ? r.internalAliases : []
    ].map((n) => [n, r.handler]))
  ];
  return Object.fromEntries(t);
}, "generateShapeMap"), qg = Jk();
function tS(e) {
  return e in qg;
}
d(tS, "isValidShape");
var Wa = /* @__PURE__ */ new Map();
async function Hg(e, t, r) {
  let i, n;
  t.shape === "rect" && (t.rx && t.ry ? t.shape = "roundedRect" : t.shape = "squareRect");
  const a = t.shape ? qg[t.shape] : void 0;
  if (!a)
    throw new Error(`No such shape: ${t.shape}. Please check your syntax.`);
  if (t.link) {
    let o;
    r.config.securityLevel === "sandbox" ? o = "_top" : t.linkTarget && (o = t.linkTarget || "_blank"), i = e.insert("svg:a").attr("xlink:href", t.link).attr("target", o ?? null), n = await a(i, t, r);
  } else
    n = await a(e, t, r), i = n;
  return t.tooltip && n.attr("title", t.tooltip), Wa.set(t.id, i), t.haveCallback && i.attr("class", i.attr("class") + " clickable"), i;
}
d(Hg, "insertNode");
var sA = /* @__PURE__ */ d((e, t) => {
  Wa.set(t.id, e);
}, "setNodeElem"), oA = /* @__PURE__ */ d(() => {
  Wa.clear();
}, "clear"), lA = /* @__PURE__ */ d((e) => {
  const t = Wa.get(e.id);
  F.trace(
    "Transforming node",
    e.diff,
    e,
    "translate(" + (e.x - e.width / 2 - 5) + ", " + e.width / 2 + ")"
  );
  const r = 8, i = e.diff || 0;
  return e.clusterNode ? t.attr(
    "transform",
    "translate(" + (e.x + i - e.width / 2) + ", " + (e.y - e.height / 2 - r) + ")"
  ) : t.attr("transform", "translate(" + e.x + ", " + e.y + ")"), i;
}, "positionNode"), eS = /* @__PURE__ */ d((e, t, r, i, n, a) => {
  t.arrowTypeStart && ih(e, "start", t.arrowTypeStart, r, i, n, a), t.arrowTypeEnd && ih(e, "end", t.arrowTypeEnd, r, i, n, a);
}, "addEdgeMarkers"), rS = {
  arrow_cross: { type: "cross", fill: !1 },
  arrow_point: { type: "point", fill: !0 },
  arrow_barb: { type: "barb", fill: !0 },
  arrow_circle: { type: "circle", fill: !1 },
  aggregation: { type: "aggregation", fill: !1 },
  extension: { type: "extension", fill: !1 },
  composition: { type: "composition", fill: !0 },
  dependency: { type: "dependency", fill: !0 },
  lollipop: { type: "lollipop", fill: !1 },
  only_one: { type: "onlyOne", fill: !1 },
  zero_or_one: { type: "zeroOrOne", fill: !1 },
  one_or_more: { type: "oneOrMore", fill: !1 },
  zero_or_more: { type: "zeroOrMore", fill: !1 },
  requirement_arrow: { type: "requirement_arrow", fill: !1 },
  requirement_contains: { type: "requirement_contains", fill: !1 }
}, ih = /* @__PURE__ */ d((e, t, r, i, n, a, o) => {
  var u;
  const s = rS[r];
  if (!s) {
    F.warn(`Unknown arrow type: ${r}`);
    return;
  }
  const l = s.type, h = `${n}_${a}-${l}${t === "start" ? "Start" : "End"}`;
  if (o && o.trim() !== "") {
    const f = o.replace(/[^\dA-Za-z]/g, "_"), p = `${h}_${f}`;
    if (!document.getElementById(p)) {
      const g = document.getElementById(h);
      if (g) {
        const m = g.cloneNode(!0);
        m.id = p, m.querySelectorAll("path, circle, line").forEach((y) => {
          y.setAttribute("stroke", o), s.fill && y.setAttribute("fill", o);
        }), (u = g.parentNode) == null || u.appendChild(m);
      }
    }
    e.attr(`marker-${t}`, `url(${i}#${p})`);
  } else
    e.attr(`marker-${t}`, `url(${i}#${h})`);
}, "addEdgeMarker"), ma = /* @__PURE__ */ new Map(), Ft = /* @__PURE__ */ new Map(), cA = /* @__PURE__ */ d(() => {
  ma.clear(), Ft.clear();
}, "clear"), bi = /* @__PURE__ */ d((e) => e ? e.reduce((r, i) => r + ";" + i, "") : "", "getLabelStyles"), iS = /* @__PURE__ */ d(async (e, t) => {
  let r = At(ut().flowchart.htmlLabels);
  const i = await Ze(e, t.label, {
    style: bi(t.labelStyle),
    useHtmlLabels: r,
    addSvgBackground: !0,
    isNode: !1
  });
  F.info("abc82", t, t.labelType);
  const n = e.insert("g").attr("class", "edgeLabel"), a = n.insert("g").attr("class", "label");
  a.node().appendChild(i);
  let o = i.getBBox();
  if (r) {
    const l = i.children[0], c = ht(i);
    o = l.getBoundingClientRect(), c.attr("width", o.width), c.attr("height", o.height);
  }
  a.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), ma.set(t.id, n), t.width = o.width, t.height = o.height;
  let s;
  if (t.startLabelLeft) {
    const l = await or(
      t.startLabelLeft,
      bi(t.labelStyle)
    ), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), Ft.get(t.id) || Ft.set(t.id, {}), Ft.get(t.id).startLeft = c, Bi(s, t.startLabelLeft);
  }
  if (t.startLabelRight) {
    const l = await or(
      t.startLabelRight,
      bi(t.labelStyle)
    ), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = c.node().appendChild(l), h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), Ft.get(t.id) || Ft.set(t.id, {}), Ft.get(t.id).startRight = c, Bi(s, t.startLabelRight);
  }
  if (t.endLabelLeft) {
    const l = await or(t.endLabelLeft, bi(t.labelStyle)), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), c.node().appendChild(l), Ft.get(t.id) || Ft.set(t.id, {}), Ft.get(t.id).endLeft = c, Bi(s, t.endLabelLeft);
  }
  if (t.endLabelRight) {
    const l = await or(t.endLabelRight, bi(t.labelStyle)), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), c.node().appendChild(l), Ft.get(t.id) || Ft.set(t.id, {}), Ft.get(t.id).endRight = c, Bi(s, t.endLabelRight);
  }
  return i;
}, "insertEdgeLabel");
function Bi(e, t) {
  ut().flowchart.htmlLabels && e && (e.style.width = t.length * 9 + "px", e.style.height = "12px");
}
d(Bi, "setTerminalWidth");
var nS = /* @__PURE__ */ d((e, t) => {
  F.debug("Moving label abc88 ", e.id, e.label, ma.get(e.id), t);
  let r = t.updatedPath ? t.updatedPath : t.originalPath;
  const i = ut(), { subGraphTitleTotalMargin: n } = Uo(i);
  if (e.label) {
    const a = ma.get(e.id);
    let o = e.x, s = e.y;
    if (r) {
      const l = ue.calcLabelPosition(r);
      F.debug(
        "Moving label " + e.label + " from (",
        o,
        ",",
        s,
        ") to (",
        l.x,
        ",",
        l.y,
        ") abc88"
      ), t.updatedPath && (o = l.x, s = l.y);
    }
    a.attr("transform", `translate(${o}, ${s + n / 2})`);
  }
  if (e.startLabelLeft) {
    const a = Ft.get(e.id).startLeft;
    let o = e.x, s = e.y;
    if (r) {
      const l = ue.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.startLabelRight) {
    const a = Ft.get(e.id).startRight;
    let o = e.x, s = e.y;
    if (r) {
      const l = ue.calcTerminalLabelPosition(
        e.arrowTypeStart ? 10 : 0,
        "start_right",
        r
      );
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelLeft) {
    const a = Ft.get(e.id).endLeft;
    let o = e.x, s = e.y;
    if (r) {
      const l = ue.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelRight) {
    const a = Ft.get(e.id).endRight;
    let o = e.x, s = e.y;
    if (r) {
      const l = ue.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
}, "positionEdgeLabel"), aS = /* @__PURE__ */ d((e, t) => {
  const r = e.x, i = e.y, n = Math.abs(t.x - r), a = Math.abs(t.y - i), o = e.width / 2, s = e.height / 2;
  return n >= o || a >= s;
}, "outsideNode"), sS = /* @__PURE__ */ d((e, t, r) => {
  F.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(r)}
  node        : x:${e.x} y:${e.y} w:${e.width} h:${e.height}`);
  const i = e.x, n = e.y, a = Math.abs(i - r.x), o = e.width / 2;
  let s = r.x < t.x ? o - a : o + a;
  const l = e.height / 2, c = Math.abs(t.y - r.y), h = Math.abs(t.x - r.x);
  if (Math.abs(n - t.y) * o > Math.abs(i - t.x) * l) {
    let u = r.y < t.y ? t.y - l - n : n - l - t.y;
    s = h * u / c;
    const f = {
      x: r.x < t.x ? r.x + s : r.x - h + s,
      y: r.y < t.y ? r.y + c - u : r.y - c + u
    };
    return s === 0 && (f.x = t.x, f.y = t.y), h === 0 && (f.x = t.x), c === 0 && (f.y = t.y), F.debug(`abc89 top/bottom calc, Q ${c}, q ${u}, R ${h}, r ${s}`, f), f;
  } else {
    r.x < t.x ? s = t.x - o - i : s = i - o - t.x;
    let u = c * s / h, f = r.x < t.x ? r.x + h - s : r.x - h + s, p = r.y < t.y ? r.y + u : r.y - u;
    return F.debug(`sides calc abc89, Q ${c}, q ${u}, R ${h}, r ${s}`, { _x: f, _y: p }), s === 0 && (f = t.x, p = t.y), h === 0 && (f = t.x), c === 0 && (p = t.y), { x: f, y: p };
  }
}, "intersection"), nh = /* @__PURE__ */ d((e, t) => {
  F.warn("abc88 cutPathAtIntersect", e, t);
  let r = [], i = e[0], n = !1;
  return e.forEach((a) => {
    if (F.info("abc88 checking point", a, t), !aS(t, a) && !n) {
      const o = sS(t, i, a);
      F.debug("abc88 inside", a, i, o), F.debug("abc88 intersection", o, t);
      let s = !1;
      r.forEach((l) => {
        s = s || l.x === o.x && l.y === o.y;
      }), r.some((l) => l.x === o.x && l.y === o.y) ? F.warn("abc88 no intersect", o, r) : r.push(o), n = !0;
    } else
      F.warn("abc88 outside", a, i), i = a, n || r.push(a);
  }), F.debug("returning points", r), r;
}, "cutPathAtIntersect");
function jg(e) {
  const t = [], r = [];
  for (let i = 1; i < e.length - 1; i++) {
    const n = e[i - 1], a = e[i], o = e[i + 1];
    (n.x === a.x && a.y === o.y && Math.abs(a.x - o.x) > 5 && Math.abs(a.y - n.y) > 5 || n.y === a.y && a.x === o.x && Math.abs(a.x - n.x) > 5 && Math.abs(a.y - o.y) > 5) && (t.push(a), r.push(i));
  }
  return { cornerPoints: t, cornerPointPositions: r };
}
d(jg, "extractCornerPoints");
var ah = /* @__PURE__ */ d(function(e, t, r) {
  const i = t.x - e.x, n = t.y - e.y, a = Math.sqrt(i * i + n * n), o = r / a;
  return { x: t.x - o * i, y: t.y - o * n };
}, "findAdjacentPoint"), oS = /* @__PURE__ */ d(function(e) {
  const { cornerPointPositions: t } = jg(e), r = [];
  for (let i = 0; i < e.length; i++)
    if (t.includes(i)) {
      const n = e[i - 1], a = e[i + 1], o = e[i], s = ah(n, o, 5), l = ah(a, o, 5), c = l.x - s.x, h = l.y - s.y;
      r.push(s);
      const u = Math.sqrt(2) * 2;
      let f = { x: o.x, y: o.y };
      if (Math.abs(a.x - n.x) > 10 && Math.abs(a.y - n.y) >= 10) {
        F.debug(
          "Corner point fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
        const p = 5;
        o.x === s.x ? f = {
          x: c < 0 ? s.x - p + u : s.x + p - u,
          y: h < 0 ? s.y - u : s.y + u
        } : f = {
          x: c < 0 ? s.x - u : s.x + u,
          y: h < 0 ? s.y - p + u : s.y + p - u
        };
      } else
        F.debug(
          "Corner point skipping fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
      r.push(f, l);
    } else
      r.push(e[i]);
  return r;
}, "fixCorners"), lS = /* @__PURE__ */ d(function(e, t, r, i, n, a, o) {
  var E;
  const { handDrawnSeed: s } = ut();
  let l = t.points, c = !1;
  const h = n;
  var u = a;
  const f = [];
  for (const N in t.cssCompiledStyles)
    Cp(N) || f.push(t.cssCompiledStyles[N]);
  u.intersect && h.intersect && (l = l.slice(1, t.points.length - 1), l.unshift(h.intersect(l[0])), F.debug(
    "Last point APA12",
    t.start,
    "-->",
    t.end,
    l[l.length - 1],
    u,
    u.intersect(l[l.length - 1])
  ), l.push(u.intersect(l[l.length - 1]))), t.toCluster && (F.info("to cluster abc88", r.get(t.toCluster)), l = nh(t.points, r.get(t.toCluster).node), c = !0), t.fromCluster && (F.debug(
    "from cluster abc88",
    r.get(t.fromCluster),
    JSON.stringify(l, null, 2)
  ), l = nh(l.reverse(), r.get(t.fromCluster).node).reverse(), c = !0);
  let p = l.filter((N) => !Number.isNaN(N.y));
  p = oS(p);
  let g = Bn;
  switch (g = Gn, t.curve) {
    case "linear":
      g = Gn;
      break;
    case "basis":
      g = Bn;
      break;
    case "cardinal":
      g = vu;
      break;
    case "bumpX":
      g = xu;
      break;
    case "bumpY":
      g = bu;
      break;
    case "catmullRom":
      g = Su;
      break;
    case "monotoneX":
      g = Eu;
      break;
    case "monotoneY":
      g = $u;
      break;
    case "natural":
      g = Du;
      break;
    case "step":
      g = Ou;
      break;
    case "stepAfter":
      g = Iu;
      break;
    case "stepBefore":
      g = Ru;
      break;
    default:
      g = Bn;
  }
  const { x: m, y: x } = sC(t), y = H1().x(m).y(x).curve(g);
  let b;
  switch (t.thickness) {
    case "normal":
      b = "edge-thickness-normal";
      break;
    case "thick":
      b = "edge-thickness-thick";
      break;
    case "invisible":
      b = "edge-thickness-invisible";
      break;
    default:
      b = "edge-thickness-normal";
  }
  switch (t.pattern) {
    case "solid":
      b += " edge-pattern-solid";
      break;
    case "dotted":
      b += " edge-pattern-dotted";
      break;
    case "dashed":
      b += " edge-pattern-dashed";
      break;
    default:
      b += " edge-pattern-solid";
  }
  let _, k = y(p);
  const v = Array.isArray(t.style) ? t.style : t.style ? [t.style] : [];
  let C = v.find((N) => N == null ? void 0 : N.startsWith("stroke:"));
  if (t.look === "handDrawn") {
    const N = j.svg(e);
    Object.assign([], p);
    const D = N.path(k, {
      roughness: 0.3,
      seed: s
    });
    b += " transition", _ = ht(D).select("path").attr("id", t.id).attr("class", " " + b + (t.classes ? " " + t.classes : "")).attr("style", v ? v.reduce((A, B) => A + ";" + B, "") : "");
    let L = _.attr("d");
    _.attr("d", L), e.node().appendChild(_.node());
  } else {
    const N = f.join(";"), D = v ? v.reduce((B, $) => B + $ + ";", "") : "";
    let L = "";
    t.animate && (L = " edge-animation-fast"), t.animation && (L = " edge-animation-" + t.animation);
    const A = N ? N + ";" + D + ";" : D;
    _ = e.append("path").attr("d", k).attr("id", t.id).attr(
      "class",
      " " + b + (t.classes ? " " + t.classes : "") + (L ?? "")
    ).attr("style", A), C = (E = A.match(/stroke:([^;]+)/)) == null ? void 0 : E[1];
  }
  let S = "";
  (ut().flowchart.arrowMarkerAbsolute || ut().state.arrowMarkerAbsolute) && (S = zh(!0)), F.info("arrowTypeStart", t.arrowTypeStart), F.info("arrowTypeEnd", t.arrowTypeEnd), eS(_, t, S, o, i, C);
  const O = Math.floor(l.length / 2), P = l[O];
  ue.isLabelCoordinateInPath(P, _.attr("d")) || (c = !0);
  let R = {};
  return c && (R.updatedPath = l), R.originalPath = t.points, R;
}, "insertEdge"), cS = /* @__PURE__ */ d((e, t, r, i) => {
  t.forEach((n) => {
    SS[n](e, r, i);
  });
}, "insertMarkers"), hS = /* @__PURE__ */ d((e, t, r) => {
  F.trace("Making markers for ", r), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
}, "extension"), uS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "composition"), fS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "aggregation"), pS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "dependency"), dS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
}, "lollipop"), gS = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "point"), mS = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "circle"), yS = /* @__PURE__ */ d((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
}, "cross"), xS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "barb"), bS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneStart").attr("class", "marker onlyOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M9,0 L9,18 M15,0 L15,18"), e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneEnd").attr("class", "marker onlyOne " + t).attr("refX", 18).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M3,0 L3,18 M9,0 L9,18");
}, "only_one"), CS = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneStart").attr("class", "marker zeroOrOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 21).attr("cy", 9).attr("r", 6), i.append("path").attr("d", "M9,0 L9,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneEnd").attr("class", "marker zeroOrOne " + t).attr("refX", 30).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 9).attr("r", 6), n.append("path").attr("d", "M21,0 L21,18");
}, "zero_or_one"), _S = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreStart").attr("class", "marker oneOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M0,18 Q 18,0 36,18 Q 18,36 0,18 M42,9 L42,27"), e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreEnd").attr("class", "marker oneOrMore " + t).attr("refX", 27).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M3,9 L3,27 M9,18 Q27,0 45,18 Q27,36 9,18");
}, "one_or_more"), wS = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreStart").attr("class", "marker zeroOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 48).attr("cy", 18).attr("r", 6), i.append("path").attr("d", "M0,18 Q18,0 36,18 Q18,36 0,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreEnd").attr("class", "marker zeroOrMore " + t).attr("refX", 39).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 18).attr("r", 6), n.append("path").attr("d", "M21,18 Q39,0 57,18 Q39,36 21,18");
}, "zero_or_more"), vS = /* @__PURE__ */ d((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_arrowEnd").attr("refX", 20).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("path").attr(
    "d",
    `M0,0
      L20,10
      M20,10
      L0,20`
  );
}, "requirement_arrow"), kS = /* @__PURE__ */ d((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_containsStart").attr("refX", 0).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("g");
  i.append("circle").attr("cx", 10).attr("cy", 10).attr("r", 9).attr("fill", "none"), i.append("line").attr("x1", 1).attr("x2", 19).attr("y1", 10).attr("y2", 10), i.append("line").attr("y1", 1).attr("y2", 19).attr("x1", 10).attr("x2", 10);
}, "requirement_contains"), SS = {
  extension: hS,
  composition: uS,
  aggregation: fS,
  dependency: pS,
  lollipop: dS,
  point: gS,
  circle: mS,
  cross: yS,
  barb: xS,
  only_one: bS,
  zero_or_one: CS,
  one_or_more: _S,
  zero_or_more: wS,
  requirement_arrow: vS,
  requirement_contains: kS
}, TS = cS, BS = {
  common: Jr,
  getConfig: Pt,
  insertCluster: Rk,
  insertEdge: lS,
  insertEdgeLabel: iS,
  insertMarkers: TS,
  insertNode: Hg,
  interpolateToCurve: Qo,
  labelHelper: et,
  log: F,
  positionEdgeLabel: nS
}, Yi = {}, Yg = /* @__PURE__ */ d((e) => {
  for (const t of e)
    Yi[t.name] = t;
}, "registerLayoutLoaders"), LS = /* @__PURE__ */ d(() => {
  Yg([
    {
      name: "dagre",
      loader: /* @__PURE__ */ d(async () => await import("./dagre-5GWH7T2D-WRvLp7w5.js"), "loader")
    },
    {
      name: "cose-bilkent",
      loader: /* @__PURE__ */ d(async () => await import("./cose-bilkent-S5V4N54A-C_aPH9FS.js"), "loader")
    }
  ]);
}, "registerDefaultLayoutLoaders");
LS();
var hA = /* @__PURE__ */ d(async (e, t) => {
  if (!(e.layoutAlgorithm in Yi))
    throw new Error(`Unknown layout algorithm: ${e.layoutAlgorithm}`);
  const r = Yi[e.layoutAlgorithm];
  return (await r.loader()).render(e, t, BS, {
    algorithm: r.algorithm
  });
}, "render"), uA = /* @__PURE__ */ d((e = "", { fallback: t = "dagre" } = {}) => {
  if (e in Yi)
    return e;
  if (t in Yi)
    return F.warn(`Layout algorithm ${e} is not registered. Using ${t} as fallback.`), t;
  throw new Error(`Both layout algorithms ${e} and ${t} are not registered.`);
}, "getRegisteredLayoutAlgorithm"), Ug = "comm", Gg = "rule", Xg = "decl", AS = "@import", MS = "@namespace", ES = "@keyframes", $S = "@layer", Vg = Math.abs, xl = String.fromCharCode;
function Zg(e) {
  return e.trim();
}
function Fn(e, t, r) {
  return e.replace(t, r);
}
function FS(e, t, r) {
  return e.indexOf(t, r);
}
function Or(e, t) {
  return e.charCodeAt(t) | 0;
}
function Kr(e, t, r) {
  return e.slice(t, r);
}
function Ce(e) {
  return e.length;
}
function DS(e) {
  return e.length;
}
function Cn(e, t) {
  return t.push(e), e;
}
var qa = 1, Qr = 1, Kg = 0, oe = 0, St = 0, ni = "";
function bl(e, t, r, i, n, a, o, s) {
  return { value: e, root: t, parent: r, type: i, props: n, children: a, line: qa, column: Qr, length: o, return: "", siblings: s };
}
function OS() {
  return St;
}
function RS() {
  return St = oe > 0 ? Or(ni, --oe) : 0, Qr--, St === 10 && (Qr = 1, qa--), St;
}
function pe() {
  return St = oe < Kg ? Or(ni, oe++) : 0, Qr++, St === 10 && (Qr = 1, qa++), St;
}
function He() {
  return Or(ni, oe);
}
function Dn() {
  return oe;
}
function Ha(e, t) {
  return Kr(ni, e, t);
}
function Ui(e) {
  switch (e) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function IS(e) {
  return qa = Qr = 1, Kg = Ce(ni = e), oe = 0, [];
}
function PS(e) {
  return ni = "", e;
}
function xs(e) {
  return Zg(Ha(oe - 1, ho(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
}
function NS(e) {
  for (; (St = He()) && St < 33; )
    pe();
  return Ui(e) > 2 || Ui(St) > 3 ? "" : " ";
}
function zS(e, t) {
  for (; --t && pe() && !(St < 48 || St > 102 || St > 57 && St < 65 || St > 70 && St < 97); )
    ;
  return Ha(e, Dn() + (t < 6 && He() == 32 && pe() == 32));
}
function ho(e) {
  for (; pe(); )
    switch (St) {
      case e:
        return oe;
      case 34:
      case 39:
        e !== 34 && e !== 39 && ho(St);
        break;
      case 40:
        e === 41 && ho(e);
        break;
      case 92:
        pe();
        break;
    }
  return oe;
}
function WS(e, t) {
  for (; pe() && e + St !== 57; )
    if (e + St === 84 && He() === 47)
      break;
  return "/*" + Ha(t, oe - 1) + "*" + xl(e === 47 ? e : pe());
}
function qS(e) {
  for (; !Ui(He()); )
    pe();
  return Ha(e, oe);
}
function HS(e) {
  return PS(On("", null, null, null, [""], e = IS(e), 0, [0], e));
}
function On(e, t, r, i, n, a, o, s, l) {
  for (var c = 0, h = 0, u = o, f = 0, p = 0, g = 0, m = 1, x = 1, y = 1, b = 0, _ = "", k = n, v = a, C = i, S = _; x; )
    switch (g = b, b = pe()) {
      case 40:
        if (g != 108 && Or(S, u - 1) == 58) {
          FS(S += Fn(xs(b), "&", "&\f"), "&\f", Vg(c ? s[c - 1] : 0)) != -1 && (y = -1);
          break;
        }
      case 34:
      case 39:
      case 91:
        S += xs(b);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        S += NS(g);
        break;
      case 92:
        S += zS(Dn() - 1, 7);
        continue;
      case 47:
        switch (He()) {
          case 42:
          case 47:
            Cn(jS(WS(pe(), Dn()), t, r, l), l), (Ui(g || 1) == 5 || Ui(He() || 1) == 5) && Ce(S) && Kr(S, -1, void 0) !== " " && (S += " ");
            break;
          default:
            S += "/";
        }
        break;
      case 123 * m:
        s[c++] = Ce(S) * y;
      case 125 * m:
      case 59:
      case 0:
        switch (b) {
          case 0:
          case 125:
            x = 0;
          case 59 + h:
            y == -1 && (S = Fn(S, /\f/g, "")), p > 0 && (Ce(S) - u || m === 0 && g === 47) && Cn(p > 32 ? oh(S + ";", i, r, u - 1, l) : oh(Fn(S, " ", "") + ";", i, r, u - 2, l), l);
            break;
          case 59:
            S += ";";
          default:
            if (Cn(C = sh(S, t, r, c, h, n, s, _, k = [], v = [], u, a), a), b === 123)
              if (h === 0)
                On(S, t, C, C, k, a, u, s, v);
              else {
                switch (f) {
                  case 99:
                    if (Or(S, 3) === 110) break;
                  case 108:
                    if (Or(S, 2) === 97) break;
                  default:
                    h = 0;
                  case 100:
                  case 109:
                  case 115:
                }
                h ? On(e, C, C, i && Cn(sh(e, C, C, 0, 0, n, s, _, n, k = [], u, v), v), n, v, u, s, i ? k : v) : On(S, C, C, C, [""], v, 0, s, v);
              }
        }
        c = h = p = 0, m = y = 1, _ = S = "", u = o;
        break;
      case 58:
        u = 1 + Ce(S), p = g;
      default:
        if (m < 1) {
          if (b == 123)
            --m;
          else if (b == 125 && m++ == 0 && RS() == 125)
            continue;
        }
        switch (S += xl(b), b * m) {
          case 38:
            y = h > 0 ? 1 : (S += "\f", -1);
            break;
          case 44:
            s[c++] = (Ce(S) - 1) * y, y = 1;
            break;
          case 64:
            He() === 45 && (S += xs(pe())), f = He(), h = u = Ce(_ = S += qS(Dn())), b++;
            break;
          case 45:
            g === 45 && Ce(S) == 2 && (m = 0);
        }
    }
  return a;
}
function sh(e, t, r, i, n, a, o, s, l, c, h, u) {
  for (var f = n - 1, p = n === 0 ? a : [""], g = DS(p), m = 0, x = 0, y = 0; m < i; ++m)
    for (var b = 0, _ = Kr(e, f + 1, f = Vg(x = o[m])), k = e; b < g; ++b)
      (k = Zg(x > 0 ? p[b] + " " + _ : Fn(_, /&\f/g, p[b]))) && (l[y++] = k);
  return bl(e, t, r, n === 0 ? Gg : s, l, c, h, u);
}
function jS(e, t, r, i) {
  return bl(e, t, r, Ug, xl(OS()), Kr(e, 2, -2), 0, i);
}
function oh(e, t, r, i, n) {
  return bl(e, t, r, Xg, Kr(e, 0, i), Kr(e, i + 1, -1), i, n);
}
function uo(e, t) {
  for (var r = "", i = 0; i < e.length; i++)
    r += t(e[i], i, e, t) || "";
  return r;
}
function YS(e, t, r, i) {
  switch (e.type) {
    case $S:
      if (e.children.length) break;
    case AS:
    case MS:
    case Xg:
      return e.return = e.return || e.value;
    case Ug:
      return "";
    case ES:
      return e.return = e.value + "{" + uo(e.children, i) + "}";
    case Gg:
      if (!Ce(e.value = e.props.join(","))) return "";
  }
  return Ce(r = uo(e.children, i)) ? e.return = e.value + "{" + r + "}" : "";
}
var US = Sp(Object.keys, Object), GS = Object.prototype, XS = GS.hasOwnProperty;
function VS(e) {
  if (!$a(e))
    return US(e);
  var t = [];
  for (var r in Object(e))
    XS.call(e, r) && r != "constructor" && t.push(r);
  return t;
}
var fo = br(Se, "DataView"), po = br(Se, "Promise"), go = br(Se, "Set"), mo = br(Se, "WeakMap"), lh = "[object Map]", ZS = "[object Object]", ch = "[object Promise]", hh = "[object Set]", uh = "[object WeakMap]", fh = "[object DataView]", KS = xr(fo), QS = xr(Hi), JS = xr(po), tT = xr(go), eT = xr(mo), rr = ei;
(fo && rr(new fo(new ArrayBuffer(1))) != fh || Hi && rr(new Hi()) != lh || po && rr(po.resolve()) != ch || go && rr(new go()) != hh || mo && rr(new mo()) != uh) && (rr = function(e) {
  var t = ei(e), r = t == ZS ? e.constructor : void 0, i = r ? xr(r) : "";
  if (i)
    switch (i) {
      case KS:
        return fh;
      case QS:
        return lh;
      case JS:
        return ch;
      case tT:
        return hh;
      case eT:
        return uh;
    }
  return t;
});
var rT = "[object Map]", iT = "[object Set]", nT = Object.prototype, aT = nT.hasOwnProperty;
function ph(e) {
  if (e == null)
    return !0;
  if (Fa(e) && (sa(e) || typeof e == "string" || typeof e.splice == "function" || Zo(e) || Ko(e) || aa(e)))
    return !e.length;
  var t = rr(e);
  if (t == rT || t == iT)
    return !e.size;
  if ($a(e))
    return !VS(e).length;
  for (var r in e)
    if (aT.call(e, r))
      return !1;
  return !0;
}
var Qg = "c4", sT = /* @__PURE__ */ d((e) => /^\s*C4Context|C4Container|C4Component|C4Dynamic|C4Deployment/.test(e), "detector"), oT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./c4Diagram-FPNF74CW-BnnI8Eku.js");
  return { id: Qg, diagram: e };
}, "loader"), lT = {
  id: Qg,
  detector: sT,
  loader: oT
}, cT = lT, Jg = "flowchart", hT = /* @__PURE__ */ d((e, t) => {
  var r, i;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" || ((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" ? !1 : /^\s*graph/.test(e);
}, "detector"), uT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-PVAE7QVJ-BE0sp54G.js");
  return { id: Jg, diagram: e };
}, "loader"), fT = {
  id: Jg,
  detector: hT,
  loader: uT
}, pT = fT, tm = "flowchart-v2", dT = /* @__PURE__ */ d((e, t) => {
  var r, i, n;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-d3" ? !1 : (((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" && (t.layout = "elk"), /^\s*graph/.test(e) && ((n = t == null ? void 0 : t.flowchart) == null ? void 0 : n.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*flowchart/.test(e));
}, "detector"), gT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-PVAE7QVJ-BE0sp54G.js");
  return { id: tm, diagram: e };
}, "loader"), mT = {
  id: tm,
  detector: dT,
  loader: gT
}, yT = mT, em = "er", xT = /* @__PURE__ */ d((e) => /^\s*erDiagram/.test(e), "detector"), bT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./erDiagram-AWTI2OKA-CoMw9LCm.js");
  return { id: em, diagram: e };
}, "loader"), CT = {
  id: em,
  detector: xT,
  loader: bT
}, _T = CT, rm = "gitGraph", wT = /* @__PURE__ */ d((e) => /^\s*gitGraph/.test(e), "detector"), vT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./gitGraphDiagram-NY62KEGX-Bvlg9d6N.js");
  return { id: rm, diagram: e };
}, "loader"), kT = {
  id: rm,
  detector: wT,
  loader: vT
}, ST = kT, im = "gantt", TT = /* @__PURE__ */ d((e) => /^\s*gantt/.test(e), "detector"), BT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./ganttDiagram-OWAHRB6G-vXPfpAS8.js");
  return { id: im, diagram: e };
}, "loader"), LT = {
  id: im,
  detector: TT,
  loader: BT
}, AT = LT, nm = "info", MT = /* @__PURE__ */ d((e) => /^\s*info/.test(e), "detector"), ET = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./infoDiagram-STP46IZ2-CTBNuu_r.js");
  return { id: nm, diagram: e };
}, "loader"), $T = {
  id: nm,
  detector: MT,
  loader: ET
}, am = "pie", FT = /* @__PURE__ */ d((e) => /^\s*pie/.test(e), "detector"), DT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./pieDiagram-ADFJNKIX-DFM2SaIZ.js");
  return { id: am, diagram: e };
}, "loader"), OT = {
  id: am,
  detector: FT,
  loader: DT
}, sm = "quadrantChart", RT = /* @__PURE__ */ d((e) => /^\s*quadrantChart/.test(e), "detector"), IT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./quadrantDiagram-LMRXKWRM-DVDu4WdN.js");
  return { id: sm, diagram: e };
}, "loader"), PT = {
  id: sm,
  detector: RT,
  loader: IT
}, NT = PT, om = "xychart", zT = /* @__PURE__ */ d((e) => /^\s*xychart(-beta)?/.test(e), "detector"), WT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./xychartDiagram-6GGTOJPD-BszOtTk4.js");
  return { id: om, diagram: e };
}, "loader"), qT = {
  id: om,
  detector: zT,
  loader: WT
}, HT = qT, lm = "requirement", jT = /* @__PURE__ */ d((e) => /^\s*requirement(Diagram)?/.test(e), "detector"), YT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./requirementDiagram-4UW4RH46-BwiYaKrB.js");
  return { id: lm, diagram: e };
}, "loader"), UT = {
  id: lm,
  detector: jT,
  loader: YT
}, GT = UT, cm = "sequence", XT = /* @__PURE__ */ d((e) => /^\s*sequenceDiagram/.test(e), "detector"), VT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./sequenceDiagram-C3RYC4MD-DvOK9Ovy.js");
  return { id: cm, diagram: e };
}, "loader"), ZT = {
  id: cm,
  detector: XT,
  loader: VT
}, KT = ZT, hm = "class", QT = /* @__PURE__ */ d((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*classDiagram/.test(e);
}, "detector"), JT = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./classDiagram-KNZD7YFC-sbUaABO0.js");
  return { id: hm, diagram: e };
}, "loader"), tB = {
  id: hm,
  detector: QT,
  loader: JT
}, eB = tB, um = "classDiagram", rB = /* @__PURE__ */ d((e, t) => {
  var r;
  return /^\s*classDiagram/.test(e) && ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*classDiagram-v2/.test(e);
}, "detector"), iB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./classDiagram-v2-RKCZMP56-sbUaABO0.js");
  return { id: um, diagram: e };
}, "loader"), nB = {
  id: um,
  detector: rB,
  loader: iB
}, aB = nB, fm = "state", sB = /* @__PURE__ */ d((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*stateDiagram/.test(e);
}, "detector"), oB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./stateDiagram-KXAO66HF-BxLQqLN3.js");
  return { id: fm, diagram: e };
}, "loader"), lB = {
  id: fm,
  detector: sB,
  loader: oB
}, cB = lB, pm = "stateDiagram", hB = /* @__PURE__ */ d((e, t) => {
  var r;
  return !!(/^\s*stateDiagram-v2/.test(e) || /^\s*stateDiagram/.test(e) && ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper");
}, "detector"), uB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./stateDiagram-v2-UMBNRL4Z-U0kXwrOI.js");
  return { id: pm, diagram: e };
}, "loader"), fB = {
  id: pm,
  detector: hB,
  loader: uB
}, pB = fB, dm = "journey", dB = /* @__PURE__ */ d((e) => /^\s*journey/.test(e), "detector"), gB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./journeyDiagram-BIP6EPQ6-BOcgjJkc.js");
  return { id: dm, diagram: e };
}, "loader"), mB = {
  id: dm,
  detector: dB,
  loader: gB
}, yB = mB, xB = /* @__PURE__ */ d((e, t, r) => {
  F.debug(`rendering svg for syntax error
`);
  const i = Q1(t), n = i.append("g");
  i.attr("viewBox", "0 0 2412 512"), Wh(i, 100, 512, !0), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m411.313,123.313c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32-9.375,9.375-20.688-20.688c-12.484-12.5-32.766-12.5-45.25,0l-16,16c-1.261,1.261-2.304,2.648-3.31,4.051-21.739-8.561-45.324-13.426-70.065-13.426-105.867,0-192,86.133-192,192s86.133,192 192,192 192-86.133 192-192c0-24.741-4.864-48.327-13.426-70.065 1.402-1.007 2.79-2.049 4.051-3.31l16-16c12.5-12.492 12.5-32.758 0-45.25l-20.688-20.688 9.375-9.375 32.001-31.999zm-219.313,100.687c-52.938,0-96,43.063-96,96 0,8.836-7.164,16-16,16s-16-7.164-16-16c0-70.578 57.422-128 128-128 8.836,0 16,7.164 16,16s-7.164,16-16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m459.02,148.98c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l16,16c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16.001-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m340.395,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16-16c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l15.999,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m400,64c8.844,0 16-7.164 16-16v-32c0-8.836-7.156-16-16-16-8.844,0-16,7.164-16,16v32c0,8.836 7.156,16 16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m496,96.586h-32c-8.844,0-16,7.164-16,16 0,8.836 7.156,16 16,16h32c8.844,0 16-7.164 16-16 0-8.836-7.156-16-16-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m436.98,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688l32-32c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32c-6.251,6.25-6.251,16.375-0.001,22.625z"
  ), n.append("text").attr("class", "error-text").attr("x", 1440).attr("y", 250).attr("font-size", "150px").style("text-anchor", "middle").text("Syntax error in text"), n.append("text").attr("class", "error-text").attr("x", 1250).attr("y", 400).attr("font-size", "100px").style("text-anchor", "middle").text(`mermaid version ${r}`);
}, "draw"), gm = { draw: xB }, bB = gm, CB = {
  db: {},
  renderer: gm,
  parser: {
    parse: /* @__PURE__ */ d(() => {
    }, "parse")
  }
}, _B = CB, mm = "flowchart-elk", wB = /* @__PURE__ */ d((e, t = {}) => {
  var r;
  return (
    // If diagram explicitly states flowchart-elk
    /^\s*flowchart-elk/.test(e) || // If a flowchart/graph diagram has their default renderer set to elk
    /^\s*(flowchart|graph)/.test(e) && ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "elk" ? (t.layout = "elk", !0) : !1
  );
}, "detector"), vB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./flowDiagram-PVAE7QVJ-BE0sp54G.js");
  return { id: mm, diagram: e };
}, "loader"), kB = {
  id: mm,
  detector: wB,
  loader: vB
}, SB = kB, ym = "timeline", TB = /* @__PURE__ */ d((e) => /^\s*timeline/.test(e), "detector"), BB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./timeline-definition-XQNQX7LJ-DnNxqkw1.js");
  return { id: ym, diagram: e };
}, "loader"), LB = {
  id: ym,
  detector: TB,
  loader: BB
}, AB = LB, xm = "mindmap", MB = /* @__PURE__ */ d((e) => /^\s*mindmap/.test(e), "detector"), EB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./mindmap-definition-Q6HEUPPD-DeCkm_jV.js");
  return { id: xm, diagram: e };
}, "loader"), $B = {
  id: xm,
  detector: MB,
  loader: EB
}, FB = $B, bm = "kanban", DB = /* @__PURE__ */ d((e) => /^\s*kanban/.test(e), "detector"), OB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./kanban-definition-6OIFK2YF-_yCX4_WP.js");
  return { id: bm, diagram: e };
}, "loader"), RB = {
  id: bm,
  detector: DB,
  loader: OB
}, IB = RB, Cm = "sankey", PB = /* @__PURE__ */ d((e) => /^\s*sankey(-beta)?/.test(e), "detector"), NB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./sankeyDiagram-GR3RE2ED-B_Rp37KX.js");
  return { id: Cm, diagram: e };
}, "loader"), zB = {
  id: Cm,
  detector: PB,
  loader: NB
}, WB = zB, _m = "packet", qB = /* @__PURE__ */ d((e) => /^\s*packet(-beta)?/.test(e), "detector"), HB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-S2PKOQOG-nfHKbJWD.js");
  return { id: _m, diagram: e };
}, "loader"), jB = {
  id: _m,
  detector: qB,
  loader: HB
}, wm = "radar", YB = /* @__PURE__ */ d((e) => /^\s*radar-beta/.test(e), "detector"), UB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-QEK2KX5R-Dpc-7VOI.js");
  return { id: wm, diagram: e };
}, "loader"), GB = {
  id: wm,
  detector: YB,
  loader: UB
}, vm = "block", XB = /* @__PURE__ */ d((e) => /^\s*block(-beta)?/.test(e), "detector"), VB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./blockDiagram-QIGZ2CNN-BCOJOmin.js");
  return { id: vm, diagram: e };
}, "loader"), ZB = {
  id: vm,
  detector: XB,
  loader: VB
}, KB = ZB, km = "architecture", QB = /* @__PURE__ */ d((e) => /^\s*architecture/.test(e), "detector"), JB = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./architectureDiagram-W76B3OCA-DPfmNWqC.js");
  return { id: km, diagram: e };
}, "loader"), tL = {
  id: km,
  detector: QB,
  loader: JB
}, eL = tL, Sm = "treemap", rL = /* @__PURE__ */ d((e) => /^\s*treemap/.test(e), "detector"), iL = /* @__PURE__ */ d(async () => {
  const { diagram: e } = await import("./diagram-N5W7TBWH-6podkyWe.js");
  return { id: Sm, diagram: e };
}, "loader"), nL = {
  id: Sm,
  detector: rL,
  loader: iL
}, dh = !1, ja = /* @__PURE__ */ d(() => {
  dh || (dh = !0, zn("error", _B, (e) => e.toLowerCase().trim() === "error"), zn(
    "---",
    // --- diagram type may appear if YAML front-matter is not parsed correctly
    {
      db: {
        clear: /* @__PURE__ */ d(() => {
        }, "clear")
      },
      styles: {},
      // should never be used
      renderer: {
        draw: /* @__PURE__ */ d(() => {
        }, "draw")
      },
      parser: {
        parse: /* @__PURE__ */ d(() => {
          throw new Error(
            "Diagrams beginning with --- are not valid. If you were trying to use a YAML front-matter, please ensure that you've correctly opened and closed the YAML front-matter with un-indented `---` blocks"
          );
        }, "parse")
      },
      init: /* @__PURE__ */ d(() => null, "init")
      // no op
    },
    (e) => e.toLowerCase().trimStart().startsWith("---")
  ), vs(SB, FB, eL), vs(
    cT,
    IB,
    aB,
    eB,
    _T,
    AT,
    $T,
    OT,
    GT,
    KT,
    yT,
    pT,
    AB,
    ST,
    pB,
    cB,
    yB,
    NT,
    WB,
    jB,
    HT,
    KB,
    GB,
    nL
  ));
}, "addDiagrams"), aL = /* @__PURE__ */ d(async () => {
  F.debug("Loading registered diagrams");
  const t = (await Promise.allSettled(
    Object.entries(hr).map(async ([r, { detector: i, loader: n }]) => {
      if (n)
        try {
          Bs(r);
        } catch {
          try {
            const { diagram: a, id: o } = await n();
            zn(o, a, i);
          } catch (a) {
            throw F.error(`Failed to load external diagram with key ${r}. Removing from detectors.`), delete hr[r], a;
          }
        }
    })
  )).filter((r) => r.status === "rejected");
  if (t.length > 0) {
    F.error(`Failed to load ${t.length} external diagrams`);
    for (const r of t)
      F.error(r);
    throw new Error(`Failed to load ${t.length} external diagrams`);
  }
}, "loadRegisteredDiagrams"), sL = "graphics-document document";
function Tm(e, t) {
  e.attr("role", sL), t !== "" && e.attr("aria-roledescription", t);
}
d(Tm, "setA11yDiagramInfo");
function Bm(e, t, r, i) {
  if (e.insert !== void 0) {
    if (r) {
      const n = `chart-desc-${i}`;
      e.attr("aria-describedby", n), e.insert("desc", ":first-child").attr("id", n).text(r);
    }
    if (t) {
      const n = `chart-title-${i}`;
      e.attr("aria-labelledby", n), e.insert("title", ":first-child").attr("id", n).text(t);
    }
  }
}
d(Bm, "addSVGa11yTitleDescription");
var cr, yo = (cr = class {
  constructor(t, r, i, n, a) {
    this.type = t, this.text = r, this.db = i, this.parser = n, this.renderer = a;
  }
  static async fromText(t, r = {}) {
    var c, h;
    const i = Pt(), n = Co(t, i);
    t = av(t) + `
`;
    try {
      Bs(n);
    } catch {
      const u = A0(n);
      if (!u)
        throw new Lh(`Diagram ${n} not found.`);
      const { id: f, diagram: p } = await u();
      zn(f, p);
    }
    const { db: a, parser: o, renderer: s, init: l } = Bs(n);
    return o.parser && (o.parser.yy = a), (c = a.clear) == null || c.call(a), l == null || l(i), r.title && ((h = a.setDiagramTitle) == null || h.call(a, r.title)), await o.parse(t), new cr(n, t, a, o, s);
  }
  async render(t, r) {
    await this.renderer.draw(this.text, t, r, this);
  }
  getParser() {
    return this.parser;
  }
  getType() {
    return this.type;
  }
}, d(cr, "Diagram"), cr), gh = [], oL = /* @__PURE__ */ d(() => {
  gh.forEach((e) => {
    e();
  }), gh = [];
}, "attachFunctions"), lL = /* @__PURE__ */ d((e) => e.replace(/^\s*%%(?!{)[^\n]+\n?/gm, "").trimStart(), "cleanupComments");
function Lm(e) {
  const t = e.match(Bh);
  if (!t)
    return {
      text: e,
      metadata: {}
    };
  let r = aC(t[1], {
    // To support config, we need JSON schema.
    // https://www.yaml.org/spec/1.2/spec.html#id2803231
    schema: nC
  }) ?? {};
  r = typeof r == "object" && !Array.isArray(r) ? r : {};
  const i = {};
  return r.displayMode && (i.displayMode = r.displayMode.toString()), r.title && (i.title = r.title.toString()), r.config && (i.config = r.config), {
    text: e.slice(t[0].length),
    metadata: i
  };
}
d(Lm, "extractFrontMatter");
var cL = /* @__PURE__ */ d((e) => e.replace(/\r\n?/g, `
`).replace(
  /<(\w+)([^>]*)>/g,
  (t, r, i) => "<" + r + i.replace(/="([^"]*)"/g, "='$1'") + ">"
), "cleanupText"), hL = /* @__PURE__ */ d((e) => {
  const { text: t, metadata: r } = Lm(e), { displayMode: i, title: n, config: a = {} } = r;
  return i && (a.gantt || (a.gantt = {}), a.gantt.displayMode = i), { title: n, config: a, text: t };
}, "processFrontmatter"), uL = /* @__PURE__ */ d((e) => {
  const t = ue.detectInit(e) ?? {}, r = ue.detectDirective(e, "wrap");
  return Array.isArray(r) ? t.wrap = r.some(({ type: i }) => i === "wrap") : (r == null ? void 0 : r.type) === "wrap" && (t.wrap = !0), {
    text: Uw(e),
    directive: t
  };
}, "processDirectives");
function Cl(e) {
  const t = cL(e), r = hL(t), i = uL(r.text), n = il(r.config, i.directive);
  return e = lL(i.text), {
    code: e,
    title: r.title,
    config: n
  };
}
d(Cl, "preprocessDiagram");
function Am(e) {
  const t = new TextEncoder().encode(e), r = Array.from(t, (i) => String.fromCodePoint(i)).join("");
  return btoa(r);
}
d(Am, "toBase64");
var fL = 5e4, pL = "graph TB;a[Maximum text size in diagram exceeded];style a fill:#faa", dL = "sandbox", gL = "loose", mL = "http://www.w3.org/2000/svg", yL = "http://www.w3.org/1999/xlink", xL = "http://www.w3.org/1999/xhtml", bL = "100%", CL = "100%", _L = "border:0;margin:0;", wL = "margin:0", vL = "allow-top-navigation-by-user-activation allow-popups", kL = 'The "iframe" tag is not supported by your browser.', SL = ["foreignobject"], TL = ["dominant-baseline"];
function _l(e) {
  const t = Cl(e);
  return Pn(), Y0(t.config ?? {}), t;
}
d(_l, "processAndSetConfigs");
async function Mm(e, t) {
  ja();
  try {
    const { code: r, config: i } = _l(e);
    return { diagramType: (await $m(r)).type, config: i };
  } catch (r) {
    if (t != null && t.suppressErrors)
      return !1;
    throw r;
  }
}
d(Mm, "parse");
var mh = /* @__PURE__ */ d((e, t, r = []) => `
.${e} ${t} { ${r.join(" !important; ")} !important; }`, "cssImportantStyles"), BL = /* @__PURE__ */ d((e, t = /* @__PURE__ */ new Map()) => {
  var i;
  let r = "";
  if (e.themeCSS !== void 0 && (r += `
${e.themeCSS}`), e.fontFamily !== void 0 && (r += `
:root { --mermaid-font-family: ${e.fontFamily}}`), e.altFontFamily !== void 0 && (r += `
:root { --mermaid-alt-font-family: ${e.altFontFamily}}`), t instanceof Map) {
    const s = e.htmlLabels ?? ((i = e.flowchart) == null ? void 0 : i.htmlLabels) ? ["> *", "span"] : ["rect", "polygon", "ellipse", "circle", "path"];
    t.forEach((l) => {
      ph(l.styles) || s.forEach((c) => {
        r += mh(l.id, c, l.styles);
      }), ph(l.textStyles) || (r += mh(
        l.id,
        "tspan",
        ((l == null ? void 0 : l.textStyles) || []).map((c) => c.replace("color", "fill"))
      ));
    });
  }
  return r;
}, "createCssStyles"), LL = /* @__PURE__ */ d((e, t, r, i) => {
  const n = BL(e, r), a = hy(t, n, e.themeVariables);
  return uo(HS(`${i}{${a}}`), YS);
}, "createUserStyles"), AL = /* @__PURE__ */ d((e = "", t, r) => {
  let i = e;
  return !r && !t && (i = i.replace(
    /marker-end="url\([\d+./:=?A-Za-z-]*?#/g,
    'marker-end="url(#'
  )), i = Cr(i), i = i.replace(/<br>/g, "<br/>"), i;
}, "cleanUpSvgCode"), ML = /* @__PURE__ */ d((e = "", t) => {
  var n, a;
  const r = (a = (n = t == null ? void 0 : t.viewBox) == null ? void 0 : n.baseVal) != null && a.height ? t.viewBox.baseVal.height + "px" : CL, i = Am(`<body style="${wL}">${e}</body>`);
  return `<iframe style="width:${bL};height:${r};${_L}" src="data:text/html;charset=UTF-8;base64,${i}" sandbox="${vL}">
  ${kL}
</iframe>`;
}, "putIntoIFrame"), yh = /* @__PURE__ */ d((e, t, r, i, n) => {
  const a = e.append("div");
  a.attr("id", r), i && a.attr("style", i);
  const o = a.append("svg").attr("id", t).attr("width", "100%").attr("xmlns", mL);
  return n && o.attr("xmlns:xlink", n), o.append("g"), e;
}, "appendDivSvgG");
function xo(e, t) {
  return e.append("iframe").attr("id", t).attr("style", "width: 100%; height: 100%;").attr("sandbox", "");
}
d(xo, "sandboxedIframe");
var EL = /* @__PURE__ */ d((e, t, r, i) => {
  var n, a, o;
  (n = e.getElementById(t)) == null || n.remove(), (a = e.getElementById(r)) == null || a.remove(), (o = e.getElementById(i)) == null || o.remove();
}, "removeExistingElements"), $L = /* @__PURE__ */ d(async function(e, t, r) {
  var N, D, L, A, B, $;
  ja();
  const i = _l(t);
  t = i.code;
  const n = Pt();
  F.debug(n), t.length > ((n == null ? void 0 : n.maxTextSize) ?? fL) && (t = pL);
  const a = "#" + e, o = "i" + e, s = "#" + o, l = "d" + e, c = "#" + l, h = /* @__PURE__ */ d(() => {
    const q = ht(f ? s : c).node();
    q && "remove" in q && q.remove();
  }, "removeTempElements");
  let u = ht("body");
  const f = n.securityLevel === dL, p = n.securityLevel === gL, g = n.fontFamily;
  if (r !== void 0) {
    if (r && (r.innerHTML = ""), f) {
      const M = xo(ht(r), o);
      u = ht(M.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = ht(r);
    yh(u, e, l, `font-family: ${g}`, yL);
  } else {
    if (EL(document, e, l, o), f) {
      const M = xo(ht("body"), o);
      u = ht(M.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = ht("body");
    yh(u, e, l);
  }
  let m, x;
  try {
    m = await yo.fromText(t, { title: i.title });
  } catch (M) {
    if (n.suppressErrorRendering)
      throw h(), M;
    m = await yo.fromText("error"), x = M;
  }
  const y = u.select(c).node(), b = m.type, _ = y.firstChild, k = _.firstChild, v = (D = (N = m.renderer).getClasses) == null ? void 0 : D.call(N, t, m), C = LL(n, b, v, a), S = document.createElement("style");
  S.innerHTML = C, _.insertBefore(S, k);
  try {
    await m.renderer.draw(t, e, zl.version, m);
  } catch (M) {
    throw n.suppressErrorRendering ? h() : bB.draw(t, e, zl.version), M;
  }
  const O = u.select(`${c} svg`), P = (A = (L = m.db).getAccTitle) == null ? void 0 : A.call(L), R = ($ = (B = m.db).getAccDescription) == null ? void 0 : $.call(B);
  Fm(b, O, P, R), u.select(`[id="${e}"]`).selectAll("foreignobject > *").attr("xmlns", xL);
  let E = u.select(c).node().innerHTML;
  if (F.debug("config.arrowMarkerAbsolute", n.arrowMarkerAbsolute), E = AL(E, f, At(n.arrowMarkerAbsolute)), f) {
    const M = u.select(c + " svg").node();
    E = ML(E, M);
  } else p || (E = jr.sanitize(E, {
    ADD_TAGS: SL,
    ADD_ATTR: TL,
    HTML_INTEGRATION_POINTS: { foreignobject: !0 }
  }));
  if (oL(), x)
    throw x;
  return h(), {
    diagramType: b,
    svg: E,
    bindFunctions: m.db.bindFunctions
  };
}, "render");
function Em(e = {}) {
  var i;
  const t = Bt({}, e);
  t != null && t.fontFamily && !((i = t.themeVariables) != null && i.fontFamily) && (t.themeVariables || (t.themeVariables = {}), t.themeVariables.fontFamily = t.fontFamily), H0(t), t != null && t.theme && t.theme in Re ? t.themeVariables = Re[t.theme].getThemeVariables(
    t.themeVariables
  ) : t && (t.themeVariables = Re.default.getThemeVariables(t.themeVariables));
  const r = typeof t == "object" ? q0(t) : Fh();
  bo(r.logLevel), ja();
}
d(Em, "initialize");
var $m = /* @__PURE__ */ d((e, t = {}) => {
  const { code: r } = Cl(e);
  return yo.fromText(r, t);
}, "getDiagramFromText");
function Fm(e, t, r, i) {
  Tm(t, e), Bm(t, r, i, t.attr("id"));
}
d(Fm, "addA11yInfo");
var mr = Object.freeze({
  render: $L,
  parse: Mm,
  getDiagramFromText: $m,
  initialize: Em,
  getConfig: Pt,
  setConfig: Dh,
  getSiteConfig: Fh,
  updateSiteConfig: j0,
  reset: /* @__PURE__ */ d(() => {
    Pn();
  }, "reset"),
  globalReset: /* @__PURE__ */ d(() => {
    Pn(Yr);
  }, "globalReset"),
  defaultConfig: Yr
});
bo(Pt().logLevel);
Pn(Pt());
var FL = /* @__PURE__ */ d((e, t, r) => {
  F.warn(e), rl(e) ? (r && r(e.str, e.hash), t.push({ ...e, message: e.str, error: e })) : (r && r(e), e instanceof Error && t.push({
    str: e.message,
    message: e.message,
    hash: e.name,
    error: e
  }));
}, "handleError"), Dm = /* @__PURE__ */ d(async function(e = {
  querySelector: ".mermaid"
}) {
  try {
    await DL(e);
  } catch (t) {
    if (rl(t) && F.error(t.str), ee.parseError && ee.parseError(t), !e.suppressErrors)
      throw F.error("Use the suppressErrors option to suppress these errors"), t;
  }
}, "run"), DL = /* @__PURE__ */ d(async function({ postRenderCallback: e, querySelector: t, nodes: r } = {
  querySelector: ".mermaid"
}) {
  const i = mr.getConfig();
  F.debug(`${e ? "" : "No "}Callback function found`);
  let n;
  if (r)
    n = r;
  else if (t)
    n = document.querySelectorAll(t);
  else
    throw new Error("Nodes and querySelector are both undefined");
  F.debug(`Found ${n.length} diagrams`), (i == null ? void 0 : i.startOnLoad) !== void 0 && (F.debug("Start On Load: " + (i == null ? void 0 : i.startOnLoad)), mr.updateSiteConfig({ startOnLoad: i == null ? void 0 : i.startOnLoad }));
  const a = new ue.InitIDGenerator(i.deterministicIds, i.deterministicIDSeed);
  let o;
  const s = [];
  for (const l of Array.from(n)) {
    if (F.info("Rendering diagram: " + l.id), l.getAttribute("data-processed"))
      continue;
    l.setAttribute("data-processed", "true");
    const c = `mermaid-${a.next()}`;
    o = l.innerHTML, o = id(ue.entityDecode(o)).trim().replace(/<br\s*\/?>/gi, "<br/>");
    const h = ue.detectInit(o);
    h && F.debug("Detected early reinit: ", h);
    try {
      const { svg: u, bindFunctions: f } = await Pm(c, o, l);
      l.innerHTML = u, e && await e(c), f && f(l);
    } catch (u) {
      FL(u, s, ee.parseError);
    }
  }
  if (s.length > 0)
    throw s[0];
}, "runThrowsErrors"), Om = /* @__PURE__ */ d(function(e) {
  mr.initialize(e);
}, "initialize"), OL = /* @__PURE__ */ d(async function(e, t, r) {
  F.warn("mermaid.init is deprecated. Please use run instead."), e && Om(e);
  const i = { postRenderCallback: r, querySelector: ".mermaid" };
  typeof t == "string" ? i.querySelector = t : t && (t instanceof HTMLElement ? i.nodes = [t] : i.nodes = t), await Dm(i);
}, "init"), RL = /* @__PURE__ */ d(async (e, {
  lazyLoad: t = !0
} = {}) => {
  ja(), vs(...e), t === !1 && await aL();
}, "registerExternalDiagrams"), Rm = /* @__PURE__ */ d(function() {
  if (ee.startOnLoad) {
    const { startOnLoad: e } = mr.getConfig();
    e && ee.run().catch((t) => F.error("Mermaid failed to initialize", t));
  }
}, "contentLoaded");
typeof document < "u" && window.addEventListener("load", Rm, !1);
var IL = /* @__PURE__ */ d(function(e) {
  ee.parseError = e;
}, "setParseErrorHandler"), ya = [], bs = !1, Im = /* @__PURE__ */ d(async () => {
  if (!bs) {
    for (bs = !0; ya.length > 0; ) {
      const e = ya.shift();
      if (e)
        try {
          await e();
        } catch (t) {
          F.error("Error executing queue", t);
        }
    }
    bs = !1;
  }
}, "executeQueue"), PL = /* @__PURE__ */ d(async (e, t) => new Promise((r, i) => {
  const n = /* @__PURE__ */ d(() => new Promise((a, o) => {
    mr.parse(e, t).then(
      (s) => {
        a(s), r(s);
      },
      (s) => {
        var l;
        F.error("Error parsing", s), (l = ee.parseError) == null || l.call(ee, s), o(s), i(s);
      }
    );
  }), "performCall");
  ya.push(n), Im().catch(i);
}), "parse"), Pm = /* @__PURE__ */ d((e, t, r) => new Promise((i, n) => {
  const a = /* @__PURE__ */ d(() => new Promise((o, s) => {
    mr.render(e, t, r).then(
      (l) => {
        o(l), i(l);
      },
      (l) => {
        var c;
        F.error("Error parsing", l), (c = ee.parseError) == null || c.call(ee, l), s(l), n(l);
      }
    );
  }), "performCall");
  ya.push(a), Im().catch(n);
}), "render"), NL = /* @__PURE__ */ d(() => Object.keys(hr).map((e) => ({
  id: e
})), "getRegisteredDiagramsMetadata"), ee = {
  startOnLoad: !0,
  mermaidAPI: mr,
  parse: PL,
  render: Pm,
  init: OL,
  run: Dm,
  registerExternalDiagrams: RL,
  registerLayoutLoaders: Yg,
  initialize: Om,
  parseError: void 0,
  contentLoaded: Rm,
  setParseErrorHandler: IL,
  detectType: Co,
  registerIconPacks: ck,
  getRegisteredDiagramsMetadata: NL
}, zL = ee;
/*! Check if previously processed */
/*!
 * Wait for document loaded before starting the execution
 */
const fA = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: zL
}, Symbol.toStringTag, { value: "Module" }));
export {
  qh as $,
  Ai as A,
  Jm as B,
  by as C,
  il as D,
  Pt as E,
  $h as F,
  Kw as G,
  Q1 as H,
  zl as I,
  nC as J,
  O0 as K,
  Ur as L,
  jL as M,
  Da as N,
  zh as O,
  _o as P,
  Ql as Q,
  H1 as R,
  Bn as S,
  Zw as T,
  Xi as U,
  oy as V,
  Gi as W,
  H as X,
  J as Y,
  qw as Z,
  d as _,
  py as a,
  Jt as a$,
  N1 as a0,
  Do as a1,
  ZL as a2,
  JL as a3,
  Lr as a4,
  xc as a5,
  yc as a6,
  eA as a7,
  tA as a8,
  QL as a9,
  Pw as aA,
  M_ as aB,
  Ew as aC,
  Xo as aD,
  ph as aE,
  uk as aF,
  z1 as aG,
  HL as aH,
  en as aI,
  ck as aJ,
  lk as aK,
  Mo as aL,
  qe as aM,
  uc as aN,
  bb as aO,
  Ri as aP,
  yr as aQ,
  Nw as aR,
  Fp as aS,
  Aa as aT,
  Fa as aU,
  sa as aV,
  Op as aW,
  $p as aX,
  gw as aY,
  G as aZ,
  Cp as a_,
  XL as aa,
  VL as ab,
  iA as ac,
  KL as ad,
  rA as ae,
  Rk as af,
  Hg as ag,
  lA as ah,
  sC as ai,
  At as aj,
  Ze as ak,
  Uo as al,
  gd as am,
  Cr as an,
  Wp as ao,
  it as ap,
  we as aq,
  TS as ar,
  oA as as,
  cA as at,
  aA as au,
  U as av,
  sA as aw,
  lS as ax,
  nS as ay,
  iS as az,
  fy as b,
  fb as b0,
  Ao as b1,
  ru as b2,
  Zi as b3,
  au as b4,
  GL as b5,
  Qm as b6,
  Iw as b7,
  Mw as b8,
  y_ as b9,
  zw as bA,
  $a as bB,
  fA as bC,
  Vo as ba,
  uw as bb,
  Ww as bc,
  Ji as bd,
  ei as be,
  ia as bf,
  ww as bg,
  VS as bh,
  Qi as bi,
  aa as bj,
  mw as bk,
  Tp as bl,
  C_ as bm,
  __ as bn,
  rr as bo,
  Rc as bp,
  w_ as bq,
  Zo as br,
  b_ as bs,
  S_ as bt,
  ri as bu,
  Ve as bv,
  Ec as bw,
  Ko as bx,
  Lp as by,
  go as bz,
  ut as c,
  ht as d,
  Wh as e,
  Bt as f,
  gy as g,
  Ne as h,
  se as i,
  _p as j,
  Jr as k,
  F as l,
  Hp as m,
  YL as n,
  uA as o,
  my as p,
  yy as q,
  hA as r,
  dy as s,
  aC as t,
  ue as u,
  tS as v,
  tv as w,
  nA as x,
  uy as y,
  UL as z
};
