import { C as e, I as o } from "./Index-I0QmpPNJ.js";
export {
  e as BaseChatBot,
  o as default
};
