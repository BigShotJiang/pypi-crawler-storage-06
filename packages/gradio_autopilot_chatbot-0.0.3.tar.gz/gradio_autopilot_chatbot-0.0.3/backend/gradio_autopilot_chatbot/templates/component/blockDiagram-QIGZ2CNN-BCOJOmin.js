import { g as de } from "./chunk-FMBD7UC4-Dtd6pXlW.js";
import { _ as d, E as st, d as R, e as ge, l as m, y as ue, A as pe, c as z, ai as fe, R as xe, S as ye, O as be, aj as Z, ak as Ht, al as we, u as et, k as me, am as Le, an as yt, i as bt, ao as Se } from "./mermaid.core-CHMKJPd9.js";
import { c as ve } from "./clone-DTVWAW6i.js";
import { G as Ee } from "./graph-CkptT_aW.js";
import { c as _e } from "./channel-CcBVYDAo.js";
var wt = function() {
  var e = /* @__PURE__ */ d(function(N, x, g, p) {
    for (g = g || {}, p = N.length; p--; g[N[p]] = x) ;
    return g;
  }, "o"), t = [1, 15], a = [1, 7], i = [1, 13], l = [1, 14], s = [1, 19], r = [1, 16], n = [1, 17], o = [1, 18], u = [8, 30], h = [8, 10, 21, 28, 29, 30, 31, 39, 43, 46], y = [1, 23], b = [1, 24], L = [8, 10, 15, 16, 21, 28, 29, 30, 31, 39, 43, 46], E = [8, 10, 15, 16, 21, 27, 28, 29, 30, 31, 39, 43, 46], D = [1, 49], v = {
    trace: /* @__PURE__ */ d(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, spaceLines: 3, SPACELINE: 4, NL: 5, separator: 6, SPACE: 7, EOF: 8, start: 9, BLOCK_DIAGRAM_KEY: 10, document: 11, stop: 12, statement: 13, link: 14, LINK: 15, START_LINK: 16, LINK_LABEL: 17, STR: 18, nodeStatement: 19, columnsStatement: 20, SPACE_BLOCK: 21, blockStatement: 22, classDefStatement: 23, cssClassStatement: 24, styleStatement: 25, node: 26, SIZE: 27, COLUMNS: 28, "id-block": 29, end: 30, NODE_ID: 31, nodeShapeNLabel: 32, dirList: 33, DIR: 34, NODE_DSTART: 35, NODE_DEND: 36, BLOCK_ARROW_START: 37, BLOCK_ARROW_END: 38, classDef: 39, CLASSDEF_ID: 40, CLASSDEF_STYLEOPTS: 41, DEFAULT: 42, class: 43, CLASSENTITY_IDS: 44, STYLECLASS: 45, style: 46, STYLE_ENTITY_IDS: 47, STYLE_DEFINITION_DATA: 48, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 4: "SPACELINE", 5: "NL", 7: "SPACE", 8: "EOF", 10: "BLOCK_DIAGRAM_KEY", 15: "LINK", 16: "START_LINK", 17: "LINK_LABEL", 18: "STR", 21: "SPACE_BLOCK", 27: "SIZE", 28: "COLUMNS", 29: "id-block", 30: "end", 31: "NODE_ID", 34: "DIR", 35: "NODE_DSTART", 36: "NODE_DEND", 37: "BLOCK_ARROW_START", 38: "BLOCK_ARROW_END", 39: "classDef", 40: "CLASSDEF_ID", 41: "CLASSDEF_STYLEOPTS", 42: "DEFAULT", 43: "class", 44: "CLASSENTITY_IDS", 45: "STYLECLASS", 46: "style", 47: "STYLE_ENTITY_IDS", 48: "STYLE_DEFINITION_DATA" },
    productions_: [0, [3, 1], [3, 2], [3, 2], [6, 1], [6, 1], [6, 1], [9, 3], [12, 1], [12, 1], [12, 2], [12, 2], [11, 1], [11, 2], [14, 1], [14, 4], [13, 1], [13, 1], [13, 1], [13, 1], [13, 1], [13, 1], [13, 1], [19, 3], [19, 2], [19, 1], [20, 1], [22, 4], [22, 3], [26, 1], [26, 2], [33, 1], [33, 2], [32, 3], [32, 4], [23, 3], [23, 3], [24, 3], [25, 3]],
    performAction: /* @__PURE__ */ d(function(x, g, p, w, S, c, _) {
      var f = c.length - 1;
      switch (S) {
        case 4:
          w.getLogger().debug("Rule: separator (NL) ");
          break;
        case 5:
          w.getLogger().debug("Rule: separator (Space) ");
          break;
        case 6:
          w.getLogger().debug("Rule: separator (EOF) ");
          break;
        case 7:
          w.getLogger().debug("Rule: hierarchy: ", c[f - 1]), w.setHierarchy(c[f - 1]);
          break;
        case 8:
          w.getLogger().debug("Stop NL ");
          break;
        case 9:
          w.getLogger().debug("Stop EOF ");
          break;
        case 10:
          w.getLogger().debug("Stop NL2 ");
          break;
        case 11:
          w.getLogger().debug("Stop EOF2 ");
          break;
        case 12:
          w.getLogger().debug("Rule: statement: ", c[f]), typeof c[f].length == "number" ? this.$ = c[f] : this.$ = [c[f]];
          break;
        case 13:
          w.getLogger().debug("Rule: statement #2: ", c[f - 1]), this.$ = [c[f - 1]].concat(c[f]);
          break;
        case 14:
          w.getLogger().debug("Rule: link: ", c[f], x), this.$ = { edgeTypeStr: c[f], label: "" };
          break;
        case 15:
          w.getLogger().debug("Rule: LABEL link: ", c[f - 3], c[f - 1], c[f]), this.$ = { edgeTypeStr: c[f], label: c[f - 1] };
          break;
        case 18:
          const A = parseInt(c[f]), O = w.generateId();
          this.$ = { id: O, type: "space", label: "", width: A, children: [] };
          break;
        case 23:
          w.getLogger().debug("Rule: (nodeStatement link node) ", c[f - 2], c[f - 1], c[f], " typestr: ", c[f - 1].edgeTypeStr);
          const X = w.edgeStrToEdgeData(c[f - 1].edgeTypeStr);
          this.$ = [
            { id: c[f - 2].id, label: c[f - 2].label, type: c[f - 2].type, directions: c[f - 2].directions },
            { id: c[f - 2].id + "-" + c[f].id, start: c[f - 2].id, end: c[f].id, label: c[f - 1].label, type: "edge", directions: c[f].directions, arrowTypeEnd: X, arrowTypeStart: "arrow_open" },
            { id: c[f].id, label: c[f].label, type: w.typeStr2Type(c[f].typeStr), directions: c[f].directions }
          ];
          break;
        case 24:
          w.getLogger().debug("Rule: nodeStatement (abc88 node size) ", c[f - 1], c[f]), this.$ = { id: c[f - 1].id, label: c[f - 1].label, type: w.typeStr2Type(c[f - 1].typeStr), directions: c[f - 1].directions, widthInColumns: parseInt(c[f], 10) };
          break;
        case 25:
          w.getLogger().debug("Rule: nodeStatement (node) ", c[f]), this.$ = { id: c[f].id, label: c[f].label, type: w.typeStr2Type(c[f].typeStr), directions: c[f].directions, widthInColumns: 1 };
          break;
        case 26:
          w.getLogger().debug("APA123", this ? this : "na"), w.getLogger().debug("COLUMNS: ", c[f]), this.$ = { type: "column-setting", columns: c[f] === "auto" ? -1 : parseInt(c[f]) };
          break;
        case 27:
          w.getLogger().debug("Rule: id-block statement : ", c[f - 2], c[f - 1]), w.generateId(), this.$ = { ...c[f - 2], type: "composite", children: c[f - 1] };
          break;
        case 28:
          w.getLogger().debug("Rule: blockStatement : ", c[f - 2], c[f - 1], c[f]);
          const P = w.generateId();
          this.$ = { id: P, type: "composite", label: "", children: c[f - 1] };
          break;
        case 29:
          w.getLogger().debug("Rule: node (NODE_ID separator): ", c[f]), this.$ = { id: c[f] };
          break;
        case 30:
          w.getLogger().debug("Rule: node (NODE_ID nodeShapeNLabel separator): ", c[f - 1], c[f]), this.$ = { id: c[f - 1], label: c[f].label, typeStr: c[f].typeStr, directions: c[f].directions };
          break;
        case 31:
          w.getLogger().debug("Rule: dirList: ", c[f]), this.$ = [c[f]];
          break;
        case 32:
          w.getLogger().debug("Rule: dirList: ", c[f - 1], c[f]), this.$ = [c[f - 1]].concat(c[f]);
          break;
        case 33:
          w.getLogger().debug("Rule: nodeShapeNLabel: ", c[f - 2], c[f - 1], c[f]), this.$ = { typeStr: c[f - 2] + c[f], label: c[f - 1] };
          break;
        case 34:
          w.getLogger().debug("Rule: BLOCK_ARROW nodeShapeNLabel: ", c[f - 3], c[f - 2], " #3:", c[f - 1], c[f]), this.$ = { typeStr: c[f - 3] + c[f], label: c[f - 2], directions: c[f - 1] };
          break;
        case 35:
        case 36:
          this.$ = { type: "classDef", id: c[f - 1].trim(), css: c[f].trim() };
          break;
        case 37:
          this.$ = { type: "applyClass", id: c[f - 1].trim(), styleClass: c[f].trim() };
          break;
        case 38:
          this.$ = { type: "applyStyles", id: c[f - 1].trim(), stylesStr: c[f].trim() };
          break;
      }
    }, "anonymous"),
    table: [{ 9: 1, 10: [1, 2] }, { 1: [3] }, { 10: t, 11: 3, 13: 4, 19: 5, 20: 6, 21: a, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 28: i, 29: l, 31: s, 39: r, 43: n, 46: o }, { 8: [1, 20] }, e(u, [2, 12], { 13: 4, 19: 5, 20: 6, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 11: 21, 10: t, 21: a, 28: i, 29: l, 31: s, 39: r, 43: n, 46: o }), e(h, [2, 16], { 14: 22, 15: y, 16: b }), e(h, [2, 17]), e(h, [2, 18]), e(h, [2, 19]), e(h, [2, 20]), e(h, [2, 21]), e(h, [2, 22]), e(L, [2, 25], { 27: [1, 25] }), e(h, [2, 26]), { 19: 26, 26: 12, 31: s }, { 10: t, 11: 27, 13: 4, 19: 5, 20: 6, 21: a, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 28: i, 29: l, 31: s, 39: r, 43: n, 46: o }, { 40: [1, 28], 42: [1, 29] }, { 44: [1, 30] }, { 47: [1, 31] }, e(E, [2, 29], { 32: 32, 35: [1, 33], 37: [1, 34] }), { 1: [2, 7] }, e(u, [2, 13]), { 26: 35, 31: s }, { 31: [2, 14] }, { 17: [1, 36] }, e(L, [2, 24]), { 10: t, 11: 37, 13: 4, 14: 22, 15: y, 16: b, 19: 5, 20: 6, 21: a, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 28: i, 29: l, 31: s, 39: r, 43: n, 46: o }, { 30: [1, 38] }, { 41: [1, 39] }, { 41: [1, 40] }, { 45: [1, 41] }, { 48: [1, 42] }, e(E, [2, 30]), { 18: [1, 43] }, { 18: [1, 44] }, e(L, [2, 23]), { 18: [1, 45] }, { 30: [1, 46] }, e(h, [2, 28]), e(h, [2, 35]), e(h, [2, 36]), e(h, [2, 37]), e(h, [2, 38]), { 36: [1, 47] }, { 33: 48, 34: D }, { 15: [1, 50] }, e(h, [2, 27]), e(E, [2, 33]), { 38: [1, 51] }, { 33: 52, 34: D, 38: [2, 31] }, { 31: [2, 15] }, e(E, [2, 34]), { 38: [2, 32] }],
    defaultActions: { 20: [2, 7], 23: [2, 14], 50: [2, 15], 52: [2, 32] },
    parseError: /* @__PURE__ */ d(function(x, g) {
      if (g.recoverable)
        this.trace(x);
      else {
        var p = new Error(x);
        throw p.hash = g, p;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ d(function(x) {
      var g = this, p = [0], w = [], S = [null], c = [], _ = this.table, f = "", A = 0, O = 0, X = 2, P = 1, J = c.slice.call(arguments, 1), M = Object.create(this.lexer), Q = { yy: {} };
      for (var ut in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, ut) && (Q.yy[ut] = this.yy[ut]);
      M.setInput(x, Q.yy), Q.yy.lexer = M, Q.yy.parser = this, typeof M.yylloc > "u" && (M.yylloc = {});
      var pt = M.yylloc;
      c.push(pt);
      var oe = M.options && M.options.ranges;
      typeof Q.yy.parseError == "function" ? this.parseError = Q.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function he(H) {
        p.length = p.length - 2 * H, S.length = S.length - H, c.length = c.length - H;
      }
      d(he, "popStack");
      function Tt() {
        var H;
        return H = w.pop() || M.lex() || P, typeof H != "number" && (H instanceof Array && (w = H, H = w.pop()), H = g.symbols_[H] || H), H;
      }
      d(Tt, "lex");
      for (var Y, $, U, ft, tt = {}, it, q, Ct, nt; ; ) {
        if ($ = p[p.length - 1], this.defaultActions[$] ? U = this.defaultActions[$] : ((Y === null || typeof Y > "u") && (Y = Tt()), U = _[$] && _[$][Y]), typeof U > "u" || !U.length || !U[0]) {
          var xt = "";
          nt = [];
          for (it in _[$])
            this.terminals_[it] && it > X && nt.push("'" + this.terminals_[it] + "'");
          M.showPosition ? xt = "Parse error on line " + (A + 1) + `:
` + M.showPosition() + `
Expecting ` + nt.join(", ") + ", got '" + (this.terminals_[Y] || Y) + "'" : xt = "Parse error on line " + (A + 1) + ": Unexpected " + (Y == P ? "end of input" : "'" + (this.terminals_[Y] || Y) + "'"), this.parseError(xt, {
            text: M.match,
            token: this.terminals_[Y] || Y,
            line: M.yylineno,
            loc: pt,
            expected: nt
          });
        }
        if (U[0] instanceof Array && U.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + $ + ", token: " + Y);
        switch (U[0]) {
          case 1:
            p.push(Y), S.push(M.yytext), c.push(M.yylloc), p.push(U[1]), Y = null, O = M.yyleng, f = M.yytext, A = M.yylineno, pt = M.yylloc;
            break;
          case 2:
            if (q = this.productions_[U[1]][1], tt.$ = S[S.length - q], tt._$ = {
              first_line: c[c.length - (q || 1)].first_line,
              last_line: c[c.length - 1].last_line,
              first_column: c[c.length - (q || 1)].first_column,
              last_column: c[c.length - 1].last_column
            }, oe && (tt._$.range = [
              c[c.length - (q || 1)].range[0],
              c[c.length - 1].range[1]
            ]), ft = this.performAction.apply(tt, [
              f,
              O,
              A,
              Q.yy,
              U[1],
              S,
              c
            ].concat(J)), typeof ft < "u")
              return ft;
            q && (p = p.slice(0, -1 * q * 2), S = S.slice(0, -1 * q), c = c.slice(0, -1 * q)), p.push(this.productions_[U[1]][0]), S.push(tt.$), c.push(tt._$), Ct = _[p[p.length - 2]][p[p.length - 1]], p.push(Ct);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, T = /* @__PURE__ */ function() {
    var N = {
      EOF: 1,
      parseError: /* @__PURE__ */ d(function(g, p) {
        if (this.yy.parser)
          this.yy.parser.parseError(g, p);
        else
          throw new Error(g);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ d(function(x, g) {
        return this.yy = g || this.yy || {}, this._input = x, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ d(function() {
        var x = this._input[0];
        this.yytext += x, this.yyleng++, this.offset++, this.match += x, this.matched += x;
        var g = x.match(/(?:\r\n?|\n).*/g);
        return g ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), x;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ d(function(x) {
        var g = x.length, p = x.split(/(?:\r\n?|\n)/g);
        this._input = x + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - g), this.offset -= g;
        var w = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), p.length - 1 && (this.yylineno -= p.length - 1);
        var S = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: p ? (p.length === w.length ? this.yylloc.first_column : 0) + w[w.length - p.length].length - p[0].length : this.yylloc.first_column - g
        }, this.options.ranges && (this.yylloc.range = [S[0], S[0] + this.yyleng - g]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ d(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ d(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ d(function(x) {
        this.unput(this.match.slice(x));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ d(function() {
        var x = this.matched.substr(0, this.matched.length - this.match.length);
        return (x.length > 20 ? "..." : "") + x.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ d(function() {
        var x = this.match;
        return x.length < 20 && (x += this._input.substr(0, 20 - x.length)), (x.substr(0, 20) + (x.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ d(function() {
        var x = this.pastInput(), g = new Array(x.length + 1).join("-");
        return x + this.upcomingInput() + `
` + g + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ d(function(x, g) {
        var p, w, S;
        if (this.options.backtrack_lexer && (S = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (S.yylloc.range = this.yylloc.range.slice(0))), w = x[0].match(/(?:\r\n?|\n).*/g), w && (this.yylineno += w.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: w ? w[w.length - 1].length - w[w.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + x[0].length
        }, this.yytext += x[0], this.match += x[0], this.matches = x, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(x[0].length), this.matched += x[0], p = this.performAction.call(this, this.yy, this, g, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), p)
          return p;
        if (this._backtrack) {
          for (var c in S)
            this[c] = S[c];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ d(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var x, g, p, w;
        this._more || (this.yytext = "", this.match = "");
        for (var S = this._currentRules(), c = 0; c < S.length; c++)
          if (p = this._input.match(this.rules[S[c]]), p && (!g || p[0].length > g[0].length)) {
            if (g = p, w = c, this.options.backtrack_lexer) {
              if (x = this.test_match(p, S[c]), x !== !1)
                return x;
              if (this._backtrack) {
                g = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return g ? (x = this.test_match(g, S[w]), x !== !1 ? x : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ d(function() {
        var g = this.next();
        return g || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ d(function(g) {
        this.conditionStack.push(g);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ d(function() {
        var g = this.conditionStack.length - 1;
        return g > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ d(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ d(function(g) {
        return g = this.conditionStack.length - 1 - Math.abs(g || 0), g >= 0 ? this.conditionStack[g] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ d(function(g) {
        this.begin(g);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ d(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: {},
      performAction: /* @__PURE__ */ d(function(g, p, w, S) {
        switch (w) {
          case 0:
            return g.getLogger().debug("Found block-beta"), 10;
          case 1:
            return g.getLogger().debug("Found id-block"), 29;
          case 2:
            return g.getLogger().debug("Found block"), 10;
          case 3:
            g.getLogger().debug(".", p.yytext);
            break;
          case 4:
            g.getLogger().debug("_", p.yytext);
            break;
          case 5:
            return 5;
          case 6:
            return p.yytext = -1, 28;
          case 7:
            return p.yytext = p.yytext.replace(/columns\s+/, ""), g.getLogger().debug("COLUMNS (LEX)", p.yytext), 28;
          case 8:
            this.pushState("md_string");
            break;
          case 9:
            return "MD_STR";
          case 10:
            this.popState();
            break;
          case 11:
            this.pushState("string");
            break;
          case 12:
            g.getLogger().debug("LEX: POPPING STR:", p.yytext), this.popState();
            break;
          case 13:
            return g.getLogger().debug("LEX: STR end:", p.yytext), "STR";
          case 14:
            return p.yytext = p.yytext.replace(/space\:/, ""), g.getLogger().debug("SPACE NUM (LEX)", p.yytext), 21;
          case 15:
            return p.yytext = "1", g.getLogger().debug("COLUMNS (LEX)", p.yytext), 21;
          case 16:
            return 42;
          case 17:
            return "LINKSTYLE";
          case 18:
            return "INTERPOLATE";
          case 19:
            return this.pushState("CLASSDEF"), 39;
          case 20:
            return this.popState(), this.pushState("CLASSDEFID"), "DEFAULT_CLASSDEF_ID";
          case 21:
            return this.popState(), this.pushState("CLASSDEFID"), 40;
          case 22:
            return this.popState(), 41;
          case 23:
            return this.pushState("CLASS"), 43;
          case 24:
            return this.popState(), this.pushState("CLASS_STYLE"), 44;
          case 25:
            return this.popState(), 45;
          case 26:
            return this.pushState("STYLE_STMNT"), 46;
          case 27:
            return this.popState(), this.pushState("STYLE_DEFINITION"), 47;
          case 28:
            return this.popState(), 48;
          case 29:
            return this.pushState("acc_title"), "acc_title";
          case 30:
            return this.popState(), "acc_title_value";
          case 31:
            return this.pushState("acc_descr"), "acc_descr";
          case 32:
            return this.popState(), "acc_descr_value";
          case 33:
            this.pushState("acc_descr_multiline");
            break;
          case 34:
            this.popState();
            break;
          case 35:
            return "acc_descr_multiline_value";
          case 36:
            return 30;
          case 37:
            return this.popState(), g.getLogger().debug("Lex: (("), "NODE_DEND";
          case 38:
            return this.popState(), g.getLogger().debug("Lex: (("), "NODE_DEND";
          case 39:
            return this.popState(), g.getLogger().debug("Lex: ))"), "NODE_DEND";
          case 40:
            return this.popState(), g.getLogger().debug("Lex: (("), "NODE_DEND";
          case 41:
            return this.popState(), g.getLogger().debug("Lex: (("), "NODE_DEND";
          case 42:
            return this.popState(), g.getLogger().debug("Lex: (-"), "NODE_DEND";
          case 43:
            return this.popState(), g.getLogger().debug("Lex: -)"), "NODE_DEND";
          case 44:
            return this.popState(), g.getLogger().debug("Lex: (("), "NODE_DEND";
          case 45:
            return this.popState(), g.getLogger().debug("Lex: ]]"), "NODE_DEND";
          case 46:
            return this.popState(), g.getLogger().debug("Lex: ("), "NODE_DEND";
          case 47:
            return this.popState(), g.getLogger().debug("Lex: ])"), "NODE_DEND";
          case 48:
            return this.popState(), g.getLogger().debug("Lex: /]"), "NODE_DEND";
          case 49:
            return this.popState(), g.getLogger().debug("Lex: /]"), "NODE_DEND";
          case 50:
            return this.popState(), g.getLogger().debug("Lex: )]"), "NODE_DEND";
          case 51:
            return this.popState(), g.getLogger().debug("Lex: )"), "NODE_DEND";
          case 52:
            return this.popState(), g.getLogger().debug("Lex: ]>"), "NODE_DEND";
          case 53:
            return this.popState(), g.getLogger().debug("Lex: ]"), "NODE_DEND";
          case 54:
            return g.getLogger().debug("Lexa: -)"), this.pushState("NODE"), 35;
          case 55:
            return g.getLogger().debug("Lexa: (-"), this.pushState("NODE"), 35;
          case 56:
            return g.getLogger().debug("Lexa: ))"), this.pushState("NODE"), 35;
          case 57:
            return g.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 58:
            return g.getLogger().debug("Lex: ((("), this.pushState("NODE"), 35;
          case 59:
            return g.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 60:
            return g.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 61:
            return g.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 62:
            return g.getLogger().debug("Lexc: >"), this.pushState("NODE"), 35;
          case 63:
            return g.getLogger().debug("Lexa: (["), this.pushState("NODE"), 35;
          case 64:
            return g.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 65:
            return this.pushState("NODE"), 35;
          case 66:
            return this.pushState("NODE"), 35;
          case 67:
            return this.pushState("NODE"), 35;
          case 68:
            return this.pushState("NODE"), 35;
          case 69:
            return this.pushState("NODE"), 35;
          case 70:
            return this.pushState("NODE"), 35;
          case 71:
            return this.pushState("NODE"), 35;
          case 72:
            return g.getLogger().debug("Lexa: ["), this.pushState("NODE"), 35;
          case 73:
            return this.pushState("BLOCK_ARROW"), g.getLogger().debug("LEX ARR START"), 37;
          case 74:
            return g.getLogger().debug("Lex: NODE_ID", p.yytext), 31;
          case 75:
            return g.getLogger().debug("Lex: EOF", p.yytext), 8;
          case 76:
            this.pushState("md_string");
            break;
          case 77:
            this.pushState("md_string");
            break;
          case 78:
            return "NODE_DESCR";
          case 79:
            this.popState();
            break;
          case 80:
            g.getLogger().debug("Lex: Starting string"), this.pushState("string");
            break;
          case 81:
            g.getLogger().debug("LEX ARR: Starting string"), this.pushState("string");
            break;
          case 82:
            return g.getLogger().debug("LEX: NODE_DESCR:", p.yytext), "NODE_DESCR";
          case 83:
            g.getLogger().debug("LEX POPPING"), this.popState();
            break;
          case 84:
            g.getLogger().debug("Lex: =>BAE"), this.pushState("ARROW_DIR");
            break;
          case 85:
            return p.yytext = p.yytext.replace(/^,\s*/, ""), g.getLogger().debug("Lex (right): dir:", p.yytext), "DIR";
          case 86:
            return p.yytext = p.yytext.replace(/^,\s*/, ""), g.getLogger().debug("Lex (left):", p.yytext), "DIR";
          case 87:
            return p.yytext = p.yytext.replace(/^,\s*/, ""), g.getLogger().debug("Lex (x):", p.yytext), "DIR";
          case 88:
            return p.yytext = p.yytext.replace(/^,\s*/, ""), g.getLogger().debug("Lex (y):", p.yytext), "DIR";
          case 89:
            return p.yytext = p.yytext.replace(/^,\s*/, ""), g.getLogger().debug("Lex (up):", p.yytext), "DIR";
          case 90:
            return p.yytext = p.yytext.replace(/^,\s*/, ""), g.getLogger().debug("Lex (down):", p.yytext), "DIR";
          case 91:
            return p.yytext = "]>", g.getLogger().debug("Lex (ARROW_DIR end):", p.yytext), this.popState(), this.popState(), "BLOCK_ARROW_END";
          case 92:
            return g.getLogger().debug("Lex: LINK", "#" + p.yytext + "#"), 15;
          case 93:
            return g.getLogger().debug("Lex: LINK", p.yytext), 15;
          case 94:
            return g.getLogger().debug("Lex: LINK", p.yytext), 15;
          case 95:
            return g.getLogger().debug("Lex: LINK", p.yytext), 15;
          case 96:
            return g.getLogger().debug("Lex: START_LINK", p.yytext), this.pushState("LLABEL"), 16;
          case 97:
            return g.getLogger().debug("Lex: START_LINK", p.yytext), this.pushState("LLABEL"), 16;
          case 98:
            return g.getLogger().debug("Lex: START_LINK", p.yytext), this.pushState("LLABEL"), 16;
          case 99:
            this.pushState("md_string");
            break;
          case 100:
            return g.getLogger().debug("Lex: Starting string"), this.pushState("string"), "LINK_LABEL";
          case 101:
            return this.popState(), g.getLogger().debug("Lex: LINK", "#" + p.yytext + "#"), 15;
          case 102:
            return this.popState(), g.getLogger().debug("Lex: LINK", p.yytext), 15;
          case 103:
            return this.popState(), g.getLogger().debug("Lex: LINK", p.yytext), 15;
          case 104:
            return g.getLogger().debug("Lex: COLON", p.yytext), p.yytext = p.yytext.slice(1), 27;
        }
      }, "anonymous"),
      rules: [/^(?:block-beta\b)/, /^(?:block:)/, /^(?:block\b)/, /^(?:[\s]+)/, /^(?:[\n]+)/, /^(?:((\u000D\u000A)|(\u000A)))/, /^(?:columns\s+auto\b)/, /^(?:columns\s+[\d]+)/, /^(?:["][`])/, /^(?:[^`"]+)/, /^(?:[`]["])/, /^(?:["])/, /^(?:["])/, /^(?:[^"]*)/, /^(?:space[:]\d+)/, /^(?:space\b)/, /^(?:default\b)/, /^(?:linkStyle\b)/, /^(?:interpolate\b)/, /^(?:classDef\s+)/, /^(?:DEFAULT\s+)/, /^(?:\w+\s+)/, /^(?:[^\n]*)/, /^(?:class\s+)/, /^(?:(\w+)+((,\s*\w+)*))/, /^(?:[^\n]*)/, /^(?:style\s+)/, /^(?:(\w+)+((,\s*\w+)*))/, /^(?:[^\n]*)/, /^(?:accTitle\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*\{\s*)/, /^(?:[\}])/, /^(?:[^\}]*)/, /^(?:end\b\s*)/, /^(?:\(\(\()/, /^(?:\)\)\))/, /^(?:[\)]\))/, /^(?:\}\})/, /^(?:\})/, /^(?:\(-)/, /^(?:-\))/, /^(?:\(\()/, /^(?:\]\])/, /^(?:\()/, /^(?:\]\))/, /^(?:\\\])/, /^(?:\/\])/, /^(?:\)\])/, /^(?:[\)])/, /^(?:\]>)/, /^(?:[\]])/, /^(?:-\))/, /^(?:\(-)/, /^(?:\)\))/, /^(?:\))/, /^(?:\(\(\()/, /^(?:\(\()/, /^(?:\{\{)/, /^(?:\{)/, /^(?:>)/, /^(?:\(\[)/, /^(?:\()/, /^(?:\[\[)/, /^(?:\[\|)/, /^(?:\[\()/, /^(?:\)\)\))/, /^(?:\[\\)/, /^(?:\[\/)/, /^(?:\[\\)/, /^(?:\[)/, /^(?:<\[)/, /^(?:[^\(\[\n\-\)\{\}\s\<\>:]+)/, /^(?:$)/, /^(?:["][`])/, /^(?:["][`])/, /^(?:[^`"]+)/, /^(?:[`]["])/, /^(?:["])/, /^(?:["])/, /^(?:[^"]+)/, /^(?:["])/, /^(?:\]>\s*\()/, /^(?:,?\s*right\s*)/, /^(?:,?\s*left\s*)/, /^(?:,?\s*x\s*)/, /^(?:,?\s*y\s*)/, /^(?:,?\s*up\s*)/, /^(?:,?\s*down\s*)/, /^(?:\)\s*)/, /^(?:\s*[xo<]?--+[-xo>]\s*)/, /^(?:\s*[xo<]?==+[=xo>]\s*)/, /^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/, /^(?:\s*~~[\~]+\s*)/, /^(?:\s*[xo<]?--\s*)/, /^(?:\s*[xo<]?==\s*)/, /^(?:\s*[xo<]?-\.\s*)/, /^(?:["][`])/, /^(?:["])/, /^(?:\s*[xo<]?--+[-xo>]\s*)/, /^(?:\s*[xo<]?==+[=xo>]\s*)/, /^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/, /^(?::\d+)/],
      conditions: { STYLE_DEFINITION: { rules: [28], inclusive: !1 }, STYLE_STMNT: { rules: [27], inclusive: !1 }, CLASSDEFID: { rules: [22], inclusive: !1 }, CLASSDEF: { rules: [20, 21], inclusive: !1 }, CLASS_STYLE: { rules: [25], inclusive: !1 }, CLASS: { rules: [24], inclusive: !1 }, LLABEL: { rules: [99, 100, 101, 102, 103], inclusive: !1 }, ARROW_DIR: { rules: [85, 86, 87, 88, 89, 90, 91], inclusive: !1 }, BLOCK_ARROW: { rules: [76, 81, 84], inclusive: !1 }, NODE: { rules: [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 77, 80], inclusive: !1 }, md_string: { rules: [9, 10, 78, 79], inclusive: !1 }, space: { rules: [], inclusive: !1 }, string: { rules: [12, 13, 82, 83], inclusive: !1 }, acc_descr_multiline: { rules: [34, 35], inclusive: !1 }, acc_descr: { rules: [32], inclusive: !1 }, acc_title: { rules: [30], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 14, 15, 16, 17, 18, 19, 23, 26, 29, 31, 33, 36, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 92, 93, 94, 95, 96, 97, 98, 104], inclusive: !0 } }
    };
    return N;
  }();
  v.lexer = T;
  function k() {
    this.yy = {};
  }
  return d(k, "Parser"), k.prototype = v, v.Parser = k, new k();
}();
wt.parser = wt;
var ke = wt, V = /* @__PURE__ */ new Map(), Et = [], mt = /* @__PURE__ */ new Map(), It = "color", Bt = "fill", De = "bgFill", Kt = ",", Ne = z(), ot = /* @__PURE__ */ new Map(), Te = /* @__PURE__ */ d((e) => me.sanitizeText(e, Ne), "sanitizeText"), Ce = /* @__PURE__ */ d(function(e, t = "") {
  let a = ot.get(e);
  a || (a = { id: e, styles: [], textStyles: [] }, ot.set(e, a)), t != null && t.split(Kt).forEach((i) => {
    const l = i.replace(/([^;]*);/, "$1").trim();
    if (RegExp(It).exec(i)) {
      const r = l.replace(Bt, De).replace(It, Bt);
      a.textStyles.push(r);
    }
    a.styles.push(l);
  });
}, "addStyleClass"), Ie = /* @__PURE__ */ d(function(e, t = "") {
  const a = V.get(e);
  t != null && (a.styles = t.split(Kt));
}, "addStyle2Node"), Be = /* @__PURE__ */ d(function(e, t) {
  e.split(",").forEach(function(a) {
    let i = V.get(a);
    if (i === void 0) {
      const l = a.trim();
      i = { id: l, type: "na", children: [] }, V.set(l, i);
    }
    i.classes || (i.classes = []), i.classes.push(t);
  });
}, "setCssClass"), Xt = /* @__PURE__ */ d((e, t) => {
  const a = e.flat(), i = [], l = a.find((r) => (r == null ? void 0 : r.type) === "column-setting"), s = (l == null ? void 0 : l.columns) ?? -1;
  for (const r of a) {
    if (typeof s == "number" && s > 0 && r.type !== "column-setting" && typeof r.widthInColumns == "number" && r.widthInColumns > s && m.warn(
      `Block ${r.id} width ${r.widthInColumns} exceeds configured column width ${s}`
    ), r.label && (r.label = Te(r.label)), r.type === "classDef") {
      Ce(r.id, r.css);
      continue;
    }
    if (r.type === "applyClass") {
      Be(r.id, (r == null ? void 0 : r.styleClass) ?? "");
      continue;
    }
    if (r.type === "applyStyles") {
      r != null && r.stylesStr && Ie(r.id, r == null ? void 0 : r.stylesStr);
      continue;
    }
    if (r.type === "column-setting")
      t.columns = r.columns ?? -1;
    else if (r.type === "edge") {
      const n = (mt.get(r.id) ?? 0) + 1;
      mt.set(r.id, n), r.id = n + "-" + r.id, Et.push(r);
    } else {
      r.label || (r.type === "composite" ? r.label = "" : r.label = r.id);
      const n = V.get(r.id);
      if (n === void 0 ? V.set(r.id, r) : (r.type !== "na" && (n.type = r.type), r.label !== r.id && (n.label = r.label)), r.children && Xt(r.children, r), r.type === "space") {
        const o = r.width ?? 1;
        for (let u = 0; u < o; u++) {
          const h = ve(r);
          h.id = h.id + "-" + u, V.set(h.id, h), i.push(h);
        }
      } else n === void 0 && i.push(r);
    }
  }
  t.children = i;
}, "populateBlockDatabase"), _t = [], at = { id: "root", type: "composite", children: [], columns: -1 }, Oe = /* @__PURE__ */ d(() => {
  m.debug("Clear called"), ue(), at = { id: "root", type: "composite", children: [], columns: -1 }, V = /* @__PURE__ */ new Map([["root", at]]), _t = [], ot = /* @__PURE__ */ new Map(), Et = [], mt = /* @__PURE__ */ new Map();
}, "clear");
function Ut(e) {
  switch (m.debug("typeStr2Type", e), e) {
    case "[]":
      return "square";
    case "()":
      return m.debug("we have a round"), "round";
    case "(())":
      return "circle";
    case ">]":
      return "rect_left_inv_arrow";
    case "{}":
      return "diamond";
    case "{{}}":
      return "hexagon";
    case "([])":
      return "stadium";
    case "[[]]":
      return "subroutine";
    case "[()]":
      return "cylinder";
    case "((()))":
      return "doublecircle";
    case "[//]":
      return "lean_right";
    case "[\\\\]":
      return "lean_left";
    case "[/\\]":
      return "trapezoid";
    case "[\\/]":
      return "inv_trapezoid";
    case "<[]>":
      return "block_arrow";
    default:
      return "na";
  }
}
d(Ut, "typeStr2Type");
function jt(e) {
  switch (m.debug("typeStr2Type", e), e) {
    case "==":
      return "thick";
    default:
      return "normal";
  }
}
d(jt, "edgeTypeStr2Type");
function Vt(e) {
  switch (e.replace(/^[\s-]+|[\s-]+$/g, "")) {
    case "x":
      return "arrow_cross";
    case "o":
      return "arrow_circle";
    case ">":
      return "arrow_point";
    default:
      return "";
  }
}
d(Vt, "edgeStrToEdgeData");
var Ot = 0, Re = /* @__PURE__ */ d(() => (Ot++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + Ot), "generateId"), ze = /* @__PURE__ */ d((e) => {
  at.children = e, Xt(e, at), _t = at.children;
}, "setHierarchy"), Ae = /* @__PURE__ */ d((e) => {
  const t = V.get(e);
  return t ? t.columns ? t.columns : t.children ? t.children.length : -1 : -1;
}, "getColumns"), Me = /* @__PURE__ */ d(() => [...V.values()], "getBlocksFlat"), Fe = /* @__PURE__ */ d(() => _t || [], "getBlocks"), We = /* @__PURE__ */ d(() => Et, "getEdges"), Pe = /* @__PURE__ */ d((e) => V.get(e), "getBlock"), Ye = /* @__PURE__ */ d((e) => {
  V.set(e.id, e);
}, "setBlock"), He = /* @__PURE__ */ d(() => m, "getLogger"), Ke = /* @__PURE__ */ d(function() {
  return ot;
}, "getClasses"), Xe = {
  getConfig: /* @__PURE__ */ d(() => st().block, "getConfig"),
  typeStr2Type: Ut,
  edgeTypeStr2Type: jt,
  edgeStrToEdgeData: Vt,
  getLogger: He,
  getBlocksFlat: Me,
  getBlocks: Fe,
  getEdges: We,
  setHierarchy: ze,
  getBlock: Pe,
  setBlock: Ye,
  getColumns: Ae,
  getClasses: Ke,
  clear: Oe,
  generateId: Re
}, Ue = Xe, lt = /* @__PURE__ */ d((e, t) => {
  const a = _e, i = a(e, "r"), l = a(e, "g"), s = a(e, "b");
  return pe(i, l, s, t);
}, "fade"), je = /* @__PURE__ */ d((e) => `.label {
    font-family: ${e.fontFamily};
    color: ${e.nodeTextColor || e.textColor};
  }
  .cluster-label text {
    fill: ${e.titleColor};
  }
  .cluster-label span,p {
    color: ${e.titleColor};
  }



  .label text,span,p {
    fill: ${e.nodeTextColor || e.textColor};
    color: ${e.nodeTextColor || e.textColor};
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${e.mainBkg};
    stroke: ${e.nodeBorder};
    stroke-width: 1px;
  }
  .flowchart-label text {
    text-anchor: middle;
  }
  // .flowchart-label .text-outer-tspan {
  //   text-anchor: middle;
  // }
  // .flowchart-label .text-inner-tspan {
  //   text-anchor: start;
  // }

  .node .label {
    text-align: center;
  }
  .node.clickable {
    cursor: pointer;
  }

  .arrowheadPath {
    fill: ${e.arrowheadColor};
  }

  .edgePath .path {
    stroke: ${e.lineColor};
    stroke-width: 2.0px;
  }

  .flowchart-link {
    stroke: ${e.lineColor};
    fill: none;
  }

  .edgeLabel {
    background-color: ${e.edgeLabelBackground};
    rect {
      opacity: 0.5;
      background-color: ${e.edgeLabelBackground};
      fill: ${e.edgeLabelBackground};
    }
    text-align: center;
  }

  /* For html labels only */
  .labelBkg {
    background-color: ${lt(e.edgeLabelBackground, 0.5)};
    // background-color:
  }

  .node .cluster {
    // fill: ${lt(e.mainBkg, 0.5)};
    fill: ${lt(e.clusterBkg, 0.5)};
    stroke: ${lt(e.clusterBorder, 0.2)};
    box-shadow: rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${e.titleColor};
  }

  .cluster span,p {
    color: ${e.titleColor};
  }
  /* .cluster div {
    color: ${e.titleColor};
  } */

  div.mermaidTooltip {
    position: absolute;
    text-align: center;
    max-width: 200px;
    padding: 2px;
    font-family: ${e.fontFamily};
    font-size: 12px;
    background: ${e.tertiaryColor};
    border: 1px solid ${e.border2};
    border-radius: 2px;
    pointer-events: none;
    z-index: 100;
  }

  .flowchartTitleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${e.textColor};
  }
  ${de()}
`, "getStyles"), Ve = je, Ge = /* @__PURE__ */ d((e, t, a, i) => {
  t.forEach((l) => {
    sr[l](e, a, i);
  });
}, "insertMarkers"), Ze = /* @__PURE__ */ d((e, t, a) => {
  m.trace("Making markers for ", a), e.append("defs").append("marker").attr("id", a + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), e.append("defs").append("marker").attr("id", a + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
}, "extension"), qe = /* @__PURE__ */ d((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", a + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "composition"), Je = /* @__PURE__ */ d((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", a + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "aggregation"), Qe = /* @__PURE__ */ d((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", a + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "dependency"), $e = /* @__PURE__ */ d((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), e.append("defs").append("marker").attr("id", a + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
}, "lollipop"), tr = /* @__PURE__ */ d((e, t, a) => {
  e.append("marker").attr("id", a + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 6).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", a + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "point"), er = /* @__PURE__ */ d((e, t, a) => {
  e.append("marker").attr("id", a + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", a + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "circle"), rr = /* @__PURE__ */ d((e, t, a) => {
  e.append("marker").attr("id", a + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", a + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
}, "cross"), ar = /* @__PURE__ */ d((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "strokeWidth").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "barb"), sr = {
  extension: Ze,
  composition: qe,
  aggregation: Je,
  dependency: Qe,
  lollipop: $e,
  point: tr,
  circle: er,
  cross: rr,
  barb: ar
}, ir = Ge, Pt, Yt, B = ((Yt = (Pt = z()) == null ? void 0 : Pt.block) == null ? void 0 : Yt.padding) ?? 8;
function Gt(e, t) {
  if (e === 0 || !Number.isInteger(e))
    throw new Error("Columns must be an integer !== 0.");
  if (t < 0 || !Number.isInteger(t))
    throw new Error("Position must be a non-negative integer." + t);
  if (e < 0)
    return { px: t, py: 0 };
  if (e === 1)
    return { px: 0, py: t };
  const a = t % e, i = Math.floor(t / e);
  return { px: a, py: i };
}
d(Gt, "calculateBlockPosition");
var nr = /* @__PURE__ */ d((e) => {
  let t = 0, a = 0;
  for (const i of e.children) {
    const { width: l, height: s, x: r, y: n } = i.size ?? { width: 0, height: 0, x: 0, y: 0 };
    m.debug(
      "getMaxChildSize abc95 child:",
      i.id,
      "width:",
      l,
      "height:",
      s,
      "x:",
      r,
      "y:",
      n,
      i.type
    ), i.type !== "space" && (l > t && (t = l / (e.widthInColumns ?? 1)), s > a && (a = s));
  }
  return { width: t, height: a };
}, "getMaxChildSize");
function ht(e, t, a = 0, i = 0) {
  var r, n, o, u, h, y, b, L, E, D, v;
  m.debug(
    "setBlockSizes abc95 (start)",
    e.id,
    (r = e == null ? void 0 : e.size) == null ? void 0 : r.x,
    "block width =",
    e == null ? void 0 : e.size,
    "siblingWidth",
    a
  ), (n = e == null ? void 0 : e.size) != null && n.width || (e.size = {
    width: a,
    height: i,
    x: 0,
    y: 0
  });
  let l = 0, s = 0;
  if (((o = e.children) == null ? void 0 : o.length) > 0) {
    for (const S of e.children)
      ht(S, t);
    const T = nr(e);
    l = T.width, s = T.height, m.debug("setBlockSizes abc95 maxWidth of", e.id, ":s children is ", l, s);
    for (const S of e.children)
      S.size && (m.debug(
        `abc95 Setting size of children of ${e.id} id=${S.id} ${l} ${s} ${JSON.stringify(S.size)}`
      ), S.size.width = l * (S.widthInColumns ?? 1) + B * ((S.widthInColumns ?? 1) - 1), S.size.height = s, S.size.x = 0, S.size.y = 0, m.debug(
        `abc95 updating size of ${e.id} children child:${S.id} maxWidth:${l} maxHeight:${s}`
      ));
    for (const S of e.children)
      ht(S, t, l, s);
    const k = e.columns ?? -1;
    let N = 0;
    for (const S of e.children)
      N += S.widthInColumns ?? 1;
    let x = e.children.length;
    k > 0 && k < N && (x = k);
    const g = Math.ceil(N / x);
    let p = x * (l + B) + B, w = g * (s + B) + B;
    if (p < a) {
      m.debug(
        `Detected to small sibling: abc95 ${e.id} siblingWidth ${a} siblingHeight ${i} width ${p}`
      ), p = a, w = i;
      const S = (a - x * B - B) / x, c = (i - g * B - B) / g;
      m.debug("Size indata abc88", e.id, "childWidth", S, "maxWidth", l), m.debug("Size indata abc88", e.id, "childHeight", c, "maxHeight", s), m.debug("Size indata abc88 xSize", x, "padding", B);
      for (const _ of e.children)
        _.size && (_.size.width = S, _.size.height = c, _.size.x = 0, _.size.y = 0);
    }
    if (m.debug(
      `abc95 (finale calc) ${e.id} xSize ${x} ySize ${g} columns ${k}${e.children.length} width=${Math.max(p, ((u = e.size) == null ? void 0 : u.width) || 0)}`
    ), p < (((h = e == null ? void 0 : e.size) == null ? void 0 : h.width) || 0)) {
      p = ((y = e == null ? void 0 : e.size) == null ? void 0 : y.width) || 0;
      const S = k > 0 ? Math.min(e.children.length, k) : e.children.length;
      if (S > 0) {
        const c = (p - S * B - B) / S;
        m.debug("abc95 (growing to fit) width", e.id, p, (b = e.size) == null ? void 0 : b.width, c);
        for (const _ of e.children)
          _.size && (_.size.width = c);
      }
    }
    e.size = {
      width: p,
      height: w,
      x: 0,
      y: 0
    };
  }
  m.debug(
    "setBlockSizes abc94 (done)",
    e.id,
    (L = e == null ? void 0 : e.size) == null ? void 0 : L.x,
    (E = e == null ? void 0 : e.size) == null ? void 0 : E.width,
    (D = e == null ? void 0 : e.size) == null ? void 0 : D.y,
    (v = e == null ? void 0 : e.size) == null ? void 0 : v.height
  );
}
d(ht, "setBlockSizes");
function kt(e, t) {
  var i, l, s, r, n, o, u, h, y, b, L, E, D, v, T, k, N;
  m.debug(
    `abc85 layout blocks (=>layoutBlocks) ${e.id} x: ${(i = e == null ? void 0 : e.size) == null ? void 0 : i.x} y: ${(l = e == null ? void 0 : e.size) == null ? void 0 : l.y} width: ${(s = e == null ? void 0 : e.size) == null ? void 0 : s.width}`
  );
  const a = e.columns ?? -1;
  if (m.debug("layoutBlocks columns abc95", e.id, "=>", a, e), e.children && // find max width of children
  e.children.length > 0) {
    const x = ((n = (r = e == null ? void 0 : e.children[0]) == null ? void 0 : r.size) == null ? void 0 : n.width) ?? 0, g = e.children.length * x + (e.children.length - 1) * B;
    m.debug("widthOfChildren 88", g, "posX");
    let p = 0;
    m.debug("abc91 block?.size?.x", e.id, (o = e == null ? void 0 : e.size) == null ? void 0 : o.x);
    let w = (u = e == null ? void 0 : e.size) != null && u.x ? ((h = e == null ? void 0 : e.size) == null ? void 0 : h.x) + (-((y = e == null ? void 0 : e.size) == null ? void 0 : y.width) / 2 || 0) : -B, S = 0;
    for (const c of e.children) {
      const _ = e;
      if (!c.size)
        continue;
      const { width: f, height: A } = c.size, { px: O, py: X } = Gt(a, p);
      if (X != S && (S = X, w = (b = e == null ? void 0 : e.size) != null && b.x ? ((L = e == null ? void 0 : e.size) == null ? void 0 : L.x) + (-((E = e == null ? void 0 : e.size) == null ? void 0 : E.width) / 2 || 0) : -B, m.debug("New row in layout for block", e.id, " and child ", c.id, S)), m.debug(
        `abc89 layout blocks (child) id: ${c.id} Pos: ${p} (px, py) ${O},${X} (${(D = _ == null ? void 0 : _.size) == null ? void 0 : D.x},${(v = _ == null ? void 0 : _.size) == null ? void 0 : v.y}) parent: ${_.id} width: ${f}${B}`
      ), _.size) {
        const J = f / 2;
        c.size.x = w + B + J, m.debug(
          `abc91 layout blocks (calc) px, pyid:${c.id} startingPos=X${w} new startingPosX${c.size.x} ${J} padding=${B} width=${f} halfWidth=${J} => x:${c.size.x} y:${c.size.y} ${c.widthInColumns} (width * (child?.w || 1)) / 2 ${f * ((c == null ? void 0 : c.widthInColumns) ?? 1) / 2}`
        ), w = c.size.x + J, c.size.y = _.size.y - _.size.height / 2 + X * (A + B) + A / 2 + B, m.debug(
          `abc88 layout blocks (calc) px, pyid:${c.id}startingPosX${w}${B}${J}=>x:${c.size.x}y:${c.size.y}${c.widthInColumns}(width * (child?.w || 1)) / 2${f * ((c == null ? void 0 : c.widthInColumns) ?? 1) / 2}`
        );
      }
      c.children && kt(c);
      let P = (c == null ? void 0 : c.widthInColumns) ?? 1;
      a > 0 && (P = Math.min(P, a - p % a)), p += P, m.debug("abc88 columnsPos", c, p);
    }
  }
  m.debug(
    `layout blocks (<==layoutBlocks) ${e.id} x: ${(T = e == null ? void 0 : e.size) == null ? void 0 : T.x} y: ${(k = e == null ? void 0 : e.size) == null ? void 0 : k.y} width: ${(N = e == null ? void 0 : e.size) == null ? void 0 : N.width}`
  );
}
d(kt, "layoutBlocks");
function Dt(e, { minX: t, minY: a, maxX: i, maxY: l } = { minX: 0, minY: 0, maxX: 0, maxY: 0 }) {
  if (e.size && e.id !== "root") {
    const { x: s, y: r, width: n, height: o } = e.size;
    s - n / 2 < t && (t = s - n / 2), r - o / 2 < a && (a = r - o / 2), s + n / 2 > i && (i = s + n / 2), r + o / 2 > l && (l = r + o / 2);
  }
  if (e.children)
    for (const s of e.children)
      ({ minX: t, minY: a, maxX: i, maxY: l } = Dt(s, { minX: t, minY: a, maxX: i, maxY: l }));
  return { minX: t, minY: a, maxX: i, maxY: l };
}
d(Dt, "findBounds");
function Zt(e) {
  const t = e.getBlock("root");
  if (!t)
    return;
  ht(t, e, 0, 0), kt(t), m.debug("getBlocks", JSON.stringify(t, null, 2));
  const { minX: a, minY: i, maxX: l, maxY: s } = Dt(t), r = s - i, n = l - a;
  return { x: a, y: i, width: n, height: r };
}
d(Zt, "layout");
function Lt(e, t) {
  t && e.attr("style", t);
}
d(Lt, "applyStyle");
function qt(e, t) {
  const a = R(document.createElementNS("http://www.w3.org/2000/svg", "foreignObject")), i = a.append("xhtml:div"), l = e.label, s = e.isNode ? "nodeLabel" : "edgeLabel", r = i.append("span");
  return r.html(bt(l, t)), Lt(r, e.labelStyle), r.attr("class", s), Lt(i, e.labelStyle), i.style("display", "inline-block"), i.style("white-space", "nowrap"), i.attr("xmlns", "http://www.w3.org/1999/xhtml"), a.node();
}
d(qt, "addHtmlLabel");
var lr = /* @__PURE__ */ d(async (e, t, a, i) => {
  let l = e || "";
  typeof l == "object" && (l = l[0]);
  const s = z();
  if (Z(s.flowchart.htmlLabels)) {
    l = l.replace(/\\n|\n/g, "<br />"), m.debug("vertexText" + l);
    const r = await Le(yt(l)), n = {
      isNode: i,
      label: r,
      labelStyle: t.replace("fill:", "color:")
    };
    return qt(n, s);
  } else {
    const r = document.createElementNS("http://www.w3.org/2000/svg", "text");
    r.setAttribute("style", t.replace("color:", "fill:"));
    let n = [];
    typeof l == "string" ? n = l.split(/\\n|\n|<br\s*\/?>/gi) : Array.isArray(l) ? n = l : n = [];
    for (const o of n) {
      const u = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
      u.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), u.setAttribute("dy", "1em"), u.setAttribute("x", "0"), a ? u.setAttribute("class", "title-row") : u.setAttribute("class", "row"), u.textContent = o.trim(), r.appendChild(u);
    }
    return r;
  }
}, "createLabel"), j = lr, cr = /* @__PURE__ */ d((e, t, a, i, l) => {
  t.arrowTypeStart && Rt(e, "start", t.arrowTypeStart, a, i, l), t.arrowTypeEnd && Rt(e, "end", t.arrowTypeEnd, a, i, l);
}, "addEdgeMarkers"), or = {
  arrow_cross: "cross",
  arrow_point: "point",
  arrow_barb: "barb",
  arrow_circle: "circle",
  aggregation: "aggregation",
  extension: "extension",
  composition: "composition",
  dependency: "dependency",
  lollipop: "lollipop"
}, Rt = /* @__PURE__ */ d((e, t, a, i, l, s) => {
  const r = or[a];
  if (!r) {
    m.warn(`Unknown arrow type: ${a}`);
    return;
  }
  const n = t === "start" ? "Start" : "End";
  e.attr(`marker-${t}`, `url(${i}#${l}_${s}-${r}${n})`);
}, "addEdgeMarker"), St = {}, W = {}, hr = /* @__PURE__ */ d(async (e, t) => {
  const a = z(), i = Z(a.flowchart.htmlLabels), l = t.labelType === "markdown" ? Ht(
    e,
    t.label,
    {
      style: t.labelStyle,
      useHtmlLabels: i,
      addSvgBackground: !0
    },
    a
  ) : await j(t.label, t.labelStyle), s = e.insert("g").attr("class", "edgeLabel"), r = s.insert("g").attr("class", "label");
  r.node().appendChild(l);
  let n = l.getBBox();
  if (i) {
    const u = l.children[0], h = R(l);
    n = u.getBoundingClientRect(), h.attr("width", n.width), h.attr("height", n.height);
  }
  r.attr("transform", "translate(" + -n.width / 2 + ", " + -n.height / 2 + ")"), St[t.id] = s, t.width = n.width, t.height = n.height;
  let o;
  if (t.startLabelLeft) {
    const u = await j(t.startLabelLeft, t.labelStyle), h = e.insert("g").attr("class", "edgeTerminals"), y = h.insert("g").attr("class", "inner");
    o = y.node().appendChild(u);
    const b = u.getBBox();
    y.attr("transform", "translate(" + -b.width / 2 + ", " + -b.height / 2 + ")"), W[t.id] || (W[t.id] = {}), W[t.id].startLeft = h, rt(o, t.startLabelLeft);
  }
  if (t.startLabelRight) {
    const u = await j(t.startLabelRight, t.labelStyle), h = e.insert("g").attr("class", "edgeTerminals"), y = h.insert("g").attr("class", "inner");
    o = h.node().appendChild(u), y.node().appendChild(u);
    const b = u.getBBox();
    y.attr("transform", "translate(" + -b.width / 2 + ", " + -b.height / 2 + ")"), W[t.id] || (W[t.id] = {}), W[t.id].startRight = h, rt(o, t.startLabelRight);
  }
  if (t.endLabelLeft) {
    const u = await j(t.endLabelLeft, t.labelStyle), h = e.insert("g").attr("class", "edgeTerminals"), y = h.insert("g").attr("class", "inner");
    o = y.node().appendChild(u);
    const b = u.getBBox();
    y.attr("transform", "translate(" + -b.width / 2 + ", " + -b.height / 2 + ")"), h.node().appendChild(u), W[t.id] || (W[t.id] = {}), W[t.id].endLeft = h, rt(o, t.endLabelLeft);
  }
  if (t.endLabelRight) {
    const u = await j(t.endLabelRight, t.labelStyle), h = e.insert("g").attr("class", "edgeTerminals"), y = h.insert("g").attr("class", "inner");
    o = y.node().appendChild(u);
    const b = u.getBBox();
    y.attr("transform", "translate(" + -b.width / 2 + ", " + -b.height / 2 + ")"), h.node().appendChild(u), W[t.id] || (W[t.id] = {}), W[t.id].endRight = h, rt(o, t.endLabelRight);
  }
  return l;
}, "insertEdgeLabel");
function rt(e, t) {
  z().flowchart.htmlLabels && e && (e.style.width = t.length * 9 + "px", e.style.height = "12px");
}
d(rt, "setTerminalWidth");
var dr = /* @__PURE__ */ d((e, t) => {
  m.debug("Moving label abc88 ", e.id, e.label, St[e.id], t);
  let a = t.updatedPath ? t.updatedPath : t.originalPath;
  const i = z(), { subGraphTitleTotalMargin: l } = we(i);
  if (e.label) {
    const s = St[e.id];
    let r = e.x, n = e.y;
    if (a) {
      const o = et.calcLabelPosition(a);
      m.debug(
        "Moving label " + e.label + " from (",
        r,
        ",",
        n,
        ") to (",
        o.x,
        ",",
        o.y,
        ") abc88"
      ), t.updatedPath && (r = o.x, n = o.y);
    }
    s.attr("transform", `translate(${r}, ${n + l / 2})`);
  }
  if (e.startLabelLeft) {
    const s = W[e.id].startLeft;
    let r = e.x, n = e.y;
    if (a) {
      const o = et.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", a);
      r = o.x, n = o.y;
    }
    s.attr("transform", `translate(${r}, ${n})`);
  }
  if (e.startLabelRight) {
    const s = W[e.id].startRight;
    let r = e.x, n = e.y;
    if (a) {
      const o = et.calcTerminalLabelPosition(
        e.arrowTypeStart ? 10 : 0,
        "start_right",
        a
      );
      r = o.x, n = o.y;
    }
    s.attr("transform", `translate(${r}, ${n})`);
  }
  if (e.endLabelLeft) {
    const s = W[e.id].endLeft;
    let r = e.x, n = e.y;
    if (a) {
      const o = et.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", a);
      r = o.x, n = o.y;
    }
    s.attr("transform", `translate(${r}, ${n})`);
  }
  if (e.endLabelRight) {
    const s = W[e.id].endRight;
    let r = e.x, n = e.y;
    if (a) {
      const o = et.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", a);
      r = o.x, n = o.y;
    }
    s.attr("transform", `translate(${r}, ${n})`);
  }
}, "positionEdgeLabel"), gr = /* @__PURE__ */ d((e, t) => {
  const a = e.x, i = e.y, l = Math.abs(t.x - a), s = Math.abs(t.y - i), r = e.width / 2, n = e.height / 2;
  return l >= r || s >= n;
}, "outsideNode"), ur = /* @__PURE__ */ d((e, t, a) => {
  m.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(a)}
  node        : x:${e.x} y:${e.y} w:${e.width} h:${e.height}`);
  const i = e.x, l = e.y, s = Math.abs(i - a.x), r = e.width / 2;
  let n = a.x < t.x ? r - s : r + s;
  const o = e.height / 2, u = Math.abs(t.y - a.y), h = Math.abs(t.x - a.x);
  if (Math.abs(l - t.y) * r > Math.abs(i - t.x) * o) {
    let y = a.y < t.y ? t.y - o - l : l - o - t.y;
    n = h * y / u;
    const b = {
      x: a.x < t.x ? a.x + n : a.x - h + n,
      y: a.y < t.y ? a.y + u - y : a.y - u + y
    };
    return n === 0 && (b.x = t.x, b.y = t.y), h === 0 && (b.x = t.x), u === 0 && (b.y = t.y), m.debug(`abc89 topp/bott calc, Q ${u}, q ${y}, R ${h}, r ${n}`, b), b;
  } else {
    a.x < t.x ? n = t.x - r - i : n = i - r - t.x;
    let y = u * n / h, b = a.x < t.x ? a.x + h - n : a.x - h + n, L = a.y < t.y ? a.y + y : a.y - y;
    return m.debug(`sides calc abc89, Q ${u}, q ${y}, R ${h}, r ${n}`, { _x: b, _y: L }), n === 0 && (b = t.x, L = t.y), h === 0 && (b = t.x), u === 0 && (L = t.y), { x: b, y: L };
  }
}, "intersection"), zt = /* @__PURE__ */ d((e, t) => {
  m.debug("abc88 cutPathAtIntersect", e, t);
  let a = [], i = e[0], l = !1;
  return e.forEach((s) => {
    if (!gr(t, s) && !l) {
      const r = ur(t, i, s);
      let n = !1;
      a.forEach((o) => {
        n = n || o.x === r.x && o.y === r.y;
      }), a.some((o) => o.x === r.x && o.y === r.y) || a.push(r), l = !0;
    } else
      i = s, l || a.push(s);
  }), a;
}, "cutPathAtIntersect"), pr = /* @__PURE__ */ d(function(e, t, a, i, l, s, r) {
  let n = a.points;
  m.debug("abc88 InsertEdge: edge=", a, "e=", t);
  let o = !1;
  const u = s.node(t.v);
  var h = s.node(t.w);
  h != null && h.intersect && (u != null && u.intersect) && (n = n.slice(1, a.points.length - 1), n.unshift(u.intersect(n[0])), n.push(h.intersect(n[n.length - 1]))), a.toCluster && (m.debug("to cluster abc88", i[a.toCluster]), n = zt(a.points, i[a.toCluster].node), o = !0), a.fromCluster && (m.debug("from cluster abc88", i[a.fromCluster]), n = zt(n.reverse(), i[a.fromCluster].node).reverse(), o = !0);
  const y = n.filter((x) => !Number.isNaN(x.y));
  let b = ye;
  a.curve && (l === "graph" || l === "flowchart") && (b = a.curve);
  const { x: L, y: E } = fe(a), D = xe().x(L).y(E).curve(b);
  let v;
  switch (a.thickness) {
    case "normal":
      v = "edge-thickness-normal";
      break;
    case "thick":
      v = "edge-thickness-thick";
      break;
    case "invisible":
      v = "edge-thickness-thick";
      break;
    default:
      v = "";
  }
  switch (a.pattern) {
    case "solid":
      v += " edge-pattern-solid";
      break;
    case "dotted":
      v += " edge-pattern-dotted";
      break;
    case "dashed":
      v += " edge-pattern-dashed";
      break;
  }
  const T = e.append("path").attr("d", D(y)).attr("id", a.id).attr("class", " " + v + (a.classes ? " " + a.classes : "")).attr("style", a.style);
  let k = "";
  (z().flowchart.arrowMarkerAbsolute || z().state.arrowMarkerAbsolute) && (k = be(!0)), cr(T, a, k, r, l);
  let N = {};
  return o && (N.updatedPath = n), N.originalPath = a.points, N;
}, "insertEdge"), fr = /* @__PURE__ */ d((e) => {
  const t = /* @__PURE__ */ new Set();
  for (const a of e)
    switch (a) {
      case "x":
        t.add("right"), t.add("left");
        break;
      case "y":
        t.add("up"), t.add("down");
        break;
      default:
        t.add(a);
        break;
    }
  return t;
}, "expandAndDeduplicateDirections"), xr = /* @__PURE__ */ d((e, t, a) => {
  const i = fr(e), l = 2, s = t.height + 2 * a.padding, r = s / l, n = t.width + 2 * r + a.padding, o = a.padding / 2;
  return i.has("right") && i.has("left") && i.has("up") && i.has("down") ? [
    // Bottom
    { x: 0, y: 0 },
    { x: r, y: 0 },
    { x: n / 2, y: 2 * o },
    { x: n - r, y: 0 },
    { x: n, y: 0 },
    // Right
    { x: n, y: -s / 3 },
    { x: n + 2 * o, y: -s / 2 },
    { x: n, y: -2 * s / 3 },
    { x: n, y: -s },
    // Top
    { x: n - r, y: -s },
    { x: n / 2, y: -s - 2 * o },
    { x: r, y: -s },
    // Left
    { x: 0, y: -s },
    { x: 0, y: -2 * s / 3 },
    { x: -2 * o, y: -s / 2 },
    { x: 0, y: -s / 3 }
  ] : i.has("right") && i.has("left") && i.has("up") ? [
    { x: r, y: 0 },
    { x: n - r, y: 0 },
    { x: n, y: -s / 2 },
    { x: n - r, y: -s },
    { x: r, y: -s },
    { x: 0, y: -s / 2 }
  ] : i.has("right") && i.has("left") && i.has("down") ? [
    { x: 0, y: 0 },
    { x: r, y: -s },
    { x: n - r, y: -s },
    { x: n, y: 0 }
  ] : i.has("right") && i.has("up") && i.has("down") ? [
    { x: 0, y: 0 },
    { x: n, y: -r },
    { x: n, y: -s + r },
    { x: 0, y: -s }
  ] : i.has("left") && i.has("up") && i.has("down") ? [
    { x: n, y: 0 },
    { x: 0, y: -r },
    { x: 0, y: -s + r },
    { x: n, y: -s }
  ] : i.has("right") && i.has("left") ? [
    { x: r, y: 0 },
    { x: r, y: -o },
    { x: n - r, y: -o },
    { x: n - r, y: 0 },
    { x: n, y: -s / 2 },
    { x: n - r, y: -s },
    { x: n - r, y: -s + o },
    { x: r, y: -s + o },
    { x: r, y: -s },
    { x: 0, y: -s / 2 }
  ] : i.has("up") && i.has("down") ? [
    // Bottom center
    { x: n / 2, y: 0 },
    // Left pont of bottom arrow
    { x: 0, y: -o },
    { x: r, y: -o },
    // Left top over vertical section
    { x: r, y: -s + o },
    { x: 0, y: -s + o },
    // Top of arrow
    { x: n / 2, y: -s },
    { x: n, y: -s + o },
    // Top of right vertical bar
    { x: n - r, y: -s + o },
    { x: n - r, y: -o },
    { x: n, y: -o }
  ] : i.has("right") && i.has("up") ? [
    { x: 0, y: 0 },
    { x: n, y: -r },
    { x: 0, y: -s }
  ] : i.has("right") && i.has("down") ? [
    { x: 0, y: 0 },
    { x: n, y: 0 },
    { x: 0, y: -s }
  ] : i.has("left") && i.has("up") ? [
    { x: n, y: 0 },
    { x: 0, y: -r },
    { x: n, y: -s }
  ] : i.has("left") && i.has("down") ? [
    { x: n, y: 0 },
    { x: 0, y: 0 },
    { x: n, y: -s }
  ] : i.has("right") ? [
    { x: r, y: -o },
    { x: r, y: -o },
    { x: n - r, y: -o },
    { x: n - r, y: 0 },
    { x: n, y: -s / 2 },
    { x: n - r, y: -s },
    { x: n - r, y: -s + o },
    // top left corner of arrow
    { x: r, y: -s + o },
    { x: r, y: -s + o }
  ] : i.has("left") ? [
    { x: r, y: 0 },
    { x: r, y: -o },
    // Two points, the right corners
    { x: n - r, y: -o },
    { x: n - r, y: -s + o },
    { x: r, y: -s + o },
    { x: r, y: -s },
    { x: 0, y: -s / 2 }
  ] : i.has("up") ? [
    // Bottom center
    { x: r, y: -o },
    // Left top over vertical section
    { x: r, y: -s + o },
    { x: 0, y: -s + o },
    // Top of arrow
    { x: n / 2, y: -s },
    { x: n, y: -s + o },
    // Top of right vertical bar
    { x: n - r, y: -s + o },
    { x: n - r, y: -o }
  ] : i.has("down") ? [
    // Bottom center
    { x: n / 2, y: 0 },
    // Left pont of bottom arrow
    { x: 0, y: -o },
    { x: r, y: -o },
    // Left top over vertical section
    { x: r, y: -s + o },
    { x: n - r, y: -s + o },
    { x: n - r, y: -o },
    { x: n, y: -o }
  ] : [{ x: 0, y: 0 }];
}, "getArrowPoints");
function Jt(e, t) {
  return e.intersect(t);
}
d(Jt, "intersectNode");
var yr = Jt;
function Qt(e, t, a, i) {
  var l = e.x, s = e.y, r = l - i.x, n = s - i.y, o = Math.sqrt(t * t * n * n + a * a * r * r), u = Math.abs(t * a * r / o);
  i.x < l && (u = -u);
  var h = Math.abs(t * a * n / o);
  return i.y < s && (h = -h), { x: l + u, y: s + h };
}
d(Qt, "intersectEllipse");
var $t = Qt;
function te(e, t, a) {
  return $t(e, t, t, a);
}
d(te, "intersectCircle");
var br = te;
function ee(e, t, a, i) {
  var l, s, r, n, o, u, h, y, b, L, E, D, v, T, k;
  if (l = t.y - e.y, r = e.x - t.x, o = t.x * e.y - e.x * t.y, b = l * a.x + r * a.y + o, L = l * i.x + r * i.y + o, !(b !== 0 && L !== 0 && vt(b, L)) && (s = i.y - a.y, n = a.x - i.x, u = i.x * a.y - a.x * i.y, h = s * e.x + n * e.y + u, y = s * t.x + n * t.y + u, !(h !== 0 && y !== 0 && vt(h, y)) && (E = l * n - s * r, E !== 0)))
    return D = Math.abs(E / 2), v = r * u - n * o, T = v < 0 ? (v - D) / E : (v + D) / E, v = s * o - l * u, k = v < 0 ? (v - D) / E : (v + D) / E, { x: T, y: k };
}
d(ee, "intersectLine");
function vt(e, t) {
  return e * t > 0;
}
d(vt, "sameSign");
var wr = ee, mr = re;
function re(e, t, a) {
  var i = e.x, l = e.y, s = [], r = Number.POSITIVE_INFINITY, n = Number.POSITIVE_INFINITY;
  typeof t.forEach == "function" ? t.forEach(function(E) {
    r = Math.min(r, E.x), n = Math.min(n, E.y);
  }) : (r = Math.min(r, t.x), n = Math.min(n, t.y));
  for (var o = i - e.width / 2 - r, u = l - e.height / 2 - n, h = 0; h < t.length; h++) {
    var y = t[h], b = t[h < t.length - 1 ? h + 1 : 0], L = wr(
      e,
      a,
      { x: o + y.x, y: u + y.y },
      { x: o + b.x, y: u + b.y }
    );
    L && s.push(L);
  }
  return s.length ? (s.length > 1 && s.sort(function(E, D) {
    var v = E.x - a.x, T = E.y - a.y, k = Math.sqrt(v * v + T * T), N = D.x - a.x, x = D.y - a.y, g = Math.sqrt(N * N + x * x);
    return k < g ? -1 : k === g ? 0 : 1;
  }), s[0]) : e;
}
d(re, "intersectPolygon");
var Lr = /* @__PURE__ */ d((e, t) => {
  var a = e.x, i = e.y, l = t.x - a, s = t.y - i, r = e.width / 2, n = e.height / 2, o, u;
  return Math.abs(s) * r > Math.abs(l) * n ? (s < 0 && (n = -n), o = s === 0 ? 0 : n * l / s, u = n) : (l < 0 && (r = -r), o = r, u = l === 0 ? 0 : r * s / l), { x: a + o, y: i + u };
}, "intersectRect"), Sr = Lr, C = {
  node: yr,
  circle: br,
  ellipse: $t,
  polygon: mr,
  rect: Sr
}, F = /* @__PURE__ */ d(async (e, t, a, i) => {
  const l = z();
  let s;
  const r = t.useHtmlLabels || Z(l.flowchart.htmlLabels);
  a ? s = a : s = "node default";
  const n = e.insert("g").attr("class", s).attr("id", t.domId || t.id), o = n.insert("g").attr("class", "label").attr("style", t.labelStyle);
  let u;
  t.labelText === void 0 ? u = "" : u = typeof t.labelText == "string" ? t.labelText : t.labelText[0];
  const h = o.node();
  let y;
  t.labelType === "markdown" ? y = Ht(
    o,
    bt(yt(u), l),
    {
      useHtmlLabels: r,
      width: t.width || l.flowchart.wrappingWidth,
      classes: "markdown-node-label"
    },
    l
  ) : y = h.appendChild(
    await j(
      bt(yt(u), l),
      t.labelStyle,
      !1,
      i
    )
  );
  let b = y.getBBox();
  const L = t.padding / 2;
  if (Z(l.flowchart.htmlLabels)) {
    const E = y.children[0], D = R(y), v = E.getElementsByTagName("img");
    if (v) {
      const T = u.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...v].map(
          (k) => new Promise((N) => {
            function x() {
              if (k.style.display = "flex", k.style.flexDirection = "column", T) {
                const g = l.fontSize ? l.fontSize : window.getComputedStyle(document.body).fontSize, w = parseInt(g, 10) * 5 + "px";
                k.style.minWidth = w, k.style.maxWidth = w;
              } else
                k.style.width = "100%";
              N(k);
            }
            d(x, "setupImage"), setTimeout(() => {
              k.complete && x();
            }), k.addEventListener("error", x), k.addEventListener("load", x);
          })
        )
      );
    }
    b = E.getBoundingClientRect(), D.attr("width", b.width), D.attr("height", b.height);
  }
  return r ? o.attr("transform", "translate(" + -b.width / 2 + ", " + -b.height / 2 + ")") : o.attr("transform", "translate(0, " + -b.height / 2 + ")"), t.centerLabel && o.attr("transform", "translate(" + -b.width / 2 + ", " + -b.height / 2 + ")"), o.insert("rect", ":first-child"), { shapeSvg: n, bbox: b, halfPadding: L, label: o };
}, "labelHelper"), I = /* @__PURE__ */ d((e, t) => {
  const a = t.node().getBBox();
  e.width = a.width, e.height = a.height;
}, "updateNodeBounds");
function G(e, t, a, i) {
  return e.insert("polygon", ":first-child").attr(
    "points",
    i.map(function(l) {
      return l.x + "," + l.y;
    }).join(" ")
  ).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + a / 2 + ")");
}
d(G, "insertPolygonShape");
var vr = /* @__PURE__ */ d(async (e, t) => {
  t.useHtmlLabels || z().flowchart.htmlLabels || (t.centerLabel = !0);
  const { shapeSvg: i, bbox: l, halfPadding: s } = await F(
    e,
    t,
    "node " + t.classes,
    !0
  );
  m.info("Classes = ", t.classes);
  const r = i.insert("rect", ":first-child");
  return r.attr("rx", t.rx).attr("ry", t.ry).attr("x", -l.width / 2 - s).attr("y", -l.height / 2 - s).attr("width", l.width + t.padding).attr("height", l.height + t.padding), I(t, r), t.intersect = function(n) {
    return C.rect(t, n);
  }, i;
}, "note"), Er = vr, At = /* @__PURE__ */ d((e) => e ? " " + e : "", "formatClass"), K = /* @__PURE__ */ d((e, t) => `${t || "node default"}${At(e.classes)} ${At(
  e.class
)}`, "getClassesFromNode"), Mt = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = l + s, n = [
    { x: r / 2, y: 0 },
    { x: r, y: -r / 2 },
    { x: r / 2, y: -r },
    { x: 0, y: -r / 2 }
  ];
  m.info("Question main (Circle)");
  const o = G(a, r, r, n);
  return o.attr("style", t.style), I(t, o), t.intersect = function(u) {
    return m.warn("Intersect called"), C.polygon(t, n, u);
  }, a;
}, "question"), _r = /* @__PURE__ */ d((e, t) => {
  const a = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), i = 28, l = [
    { x: 0, y: i / 2 },
    { x: i / 2, y: 0 },
    { x: 0, y: -i / 2 },
    { x: -i / 2, y: 0 }
  ];
  return a.insert("polygon", ":first-child").attr(
    "points",
    l.map(function(r) {
      return r.x + "," + r.y;
    }).join(" ")
  ).attr("class", "state-start").attr("r", 7).attr("width", 28).attr("height", 28), t.width = 28, t.height = 28, t.intersect = function(r) {
    return C.circle(t, 14, r);
  }, a;
}, "choice"), kr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = 4, s = i.height + t.padding, r = s / l, n = i.width + 2 * r + t.padding, o = [
    { x: r, y: 0 },
    { x: n - r, y: 0 },
    { x: n, y: -s / 2 },
    { x: n - r, y: -s },
    { x: r, y: -s },
    { x: 0, y: -s / 2 }
  ], u = G(a, n, s, o);
  return u.attr("style", t.style), I(t, u), t.intersect = function(h) {
    return C.polygon(t, o, h);
  }, a;
}, "hexagon"), Dr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(e, t, void 0, !0), l = 2, s = i.height + 2 * t.padding, r = s / l, n = i.width + 2 * r + t.padding, o = xr(t.directions, i, t), u = G(a, n, s, o);
  return u.attr("style", t.style), I(t, u), t.intersect = function(h) {
    return C.polygon(t, o, h);
  }, a;
}, "block_arrow"), Nr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: -s / 2, y: 0 },
    { x: l, y: 0 },
    { x: l, y: -s },
    { x: -s / 2, y: -s },
    { x: 0, y: -s / 2 }
  ];
  return G(a, l, s, r).attr("style", t.style), t.width = l + s, t.height = s, t.intersect = function(o) {
    return C.polygon(t, r, o);
  }, a;
}, "rect_left_inv_arrow"), Tr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(e, t, K(t), !0), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: -2 * s / 6, y: 0 },
    { x: l - s / 6, y: 0 },
    { x: l + 2 * s / 6, y: -s },
    { x: s / 6, y: -s }
  ], n = G(a, l, s, r);
  return n.attr("style", t.style), I(t, n), t.intersect = function(o) {
    return C.polygon(t, r, o);
  }, a;
}, "lean_right"), Cr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: 2 * s / 6, y: 0 },
    { x: l + s / 6, y: 0 },
    { x: l - 2 * s / 6, y: -s },
    { x: -s / 6, y: -s }
  ], n = G(a, l, s, r);
  return n.attr("style", t.style), I(t, n), t.intersect = function(o) {
    return C.polygon(t, r, o);
  }, a;
}, "lean_left"), Ir = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: -2 * s / 6, y: 0 },
    { x: l + 2 * s / 6, y: 0 },
    { x: l - s / 6, y: -s },
    { x: s / 6, y: -s }
  ], n = G(a, l, s, r);
  return n.attr("style", t.style), I(t, n), t.intersect = function(o) {
    return C.polygon(t, r, o);
  }, a;
}, "trapezoid"), Br = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: s / 6, y: 0 },
    { x: l - s / 6, y: 0 },
    { x: l + 2 * s / 6, y: -s },
    { x: -2 * s / 6, y: -s }
  ], n = G(a, l, s, r);
  return n.attr("style", t.style), I(t, n), t.intersect = function(o) {
    return C.polygon(t, r, o);
  }, a;
}, "inv_trapezoid"), Or = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: 0, y: 0 },
    { x: l + s / 2, y: 0 },
    { x: l, y: -s / 2 },
    { x: l + s / 2, y: -s },
    { x: 0, y: -s }
  ], n = G(a, l, s, r);
  return n.attr("style", t.style), I(t, n), t.intersect = function(o) {
    return C.polygon(t, r, o);
  }, a;
}, "rect_right_inv_arrow"), Rr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = i.width + t.padding, s = l / 2, r = s / (2.5 + l / 50), n = i.height + r + t.padding, o = "M 0," + r + " a " + s + "," + r + " 0,0,0 " + l + " 0 a " + s + "," + r + " 0,0,0 " + -l + " 0 l 0," + n + " a " + s + "," + r + " 0,0,0 " + l + " 0 l 0," + -n, u = a.attr("label-offset-y", r).insert("path", ":first-child").attr("style", t.style).attr("d", o).attr("transform", "translate(" + -l / 2 + "," + -(n / 2 + r) + ")");
  return I(t, u), t.intersect = function(h) {
    const y = C.rect(t, h), b = y.x - t.x;
    if (s != 0 && (Math.abs(b) < t.width / 2 || Math.abs(b) == t.width / 2 && Math.abs(y.y - t.y) > t.height / 2 - r)) {
      let L = r * r * (1 - b * b / (s * s));
      L != 0 && (L = Math.sqrt(L)), L = r - L, h.y - t.y > 0 && (L = -L), y.y += L;
    }
    return y;
  }, a;
}, "cylinder"), zr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i, halfPadding: l } = await F(
    e,
    t,
    "node " + t.classes + " " + t.class,
    !0
  ), s = a.insert("rect", ":first-child"), r = t.positioned ? t.width : i.width + t.padding, n = t.positioned ? t.height : i.height + t.padding, o = t.positioned ? -r / 2 : -i.width / 2 - l, u = t.positioned ? -n / 2 : -i.height / 2 - l;
  if (s.attr("class", "basic label-container").attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("x", o).attr("y", u).attr("width", r).attr("height", n), t.props) {
    const h = new Set(Object.keys(t.props));
    t.props.borders && (dt(s, t.props.borders, r, n), h.delete("borders")), h.forEach((y) => {
      m.warn(`Unknown node property ${y}`);
    });
  }
  return I(t, s), t.intersect = function(h) {
    return C.rect(t, h);
  }, a;
}, "rect"), Ar = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i, halfPadding: l } = await F(
    e,
    t,
    "node " + t.classes,
    !0
  ), s = a.insert("rect", ":first-child"), r = t.positioned ? t.width : i.width + t.padding, n = t.positioned ? t.height : i.height + t.padding, o = t.positioned ? -r / 2 : -i.width / 2 - l, u = t.positioned ? -n / 2 : -i.height / 2 - l;
  if (s.attr("class", "basic cluster composite label-container").attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("x", o).attr("y", u).attr("width", r).attr("height", n), t.props) {
    const h = new Set(Object.keys(t.props));
    t.props.borders && (dt(s, t.props.borders, r, n), h.delete("borders")), h.forEach((y) => {
      m.warn(`Unknown node property ${y}`);
    });
  }
  return I(t, s), t.intersect = function(h) {
    return C.rect(t, h);
  }, a;
}, "composite"), Mr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a } = await F(e, t, "label", !0);
  m.trace("Classes = ", t.class);
  const i = a.insert("rect", ":first-child"), l = 0, s = 0;
  if (i.attr("width", l).attr("height", s), a.attr("class", "label edgeLabel"), t.props) {
    const r = new Set(Object.keys(t.props));
    t.props.borders && (dt(i, t.props.borders, l, s), r.delete("borders")), r.forEach((n) => {
      m.warn(`Unknown node property ${n}`);
    });
  }
  return I(t, i), t.intersect = function(r) {
    return C.rect(t, r);
  }, a;
}, "labelRect");
function dt(e, t, a, i) {
  const l = [], s = /* @__PURE__ */ d((n) => {
    l.push(n, 0);
  }, "addBorder"), r = /* @__PURE__ */ d((n) => {
    l.push(0, n);
  }, "skipBorder");
  t.includes("t") ? (m.debug("add top border"), s(a)) : r(a), t.includes("r") ? (m.debug("add right border"), s(i)) : r(i), t.includes("b") ? (m.debug("add bottom border"), s(a)) : r(a), t.includes("l") ? (m.debug("add left border"), s(i)) : r(i), e.attr("stroke-dasharray", l.join(" "));
}
d(dt, "applyNodePropertyBorders");
var Fr = /* @__PURE__ */ d(async (e, t) => {
  let a;
  t.classes ? a = "node " + t.classes : a = "node default";
  const i = e.insert("g").attr("class", a).attr("id", t.domId || t.id), l = i.insert("rect", ":first-child"), s = i.insert("line"), r = i.insert("g").attr("class", "label"), n = t.labelText.flat ? t.labelText.flat() : t.labelText;
  let o = "";
  typeof n == "object" ? o = n[0] : o = n, m.info("Label text abc79", o, n, typeof n == "object");
  const u = r.node().appendChild(await j(o, t.labelStyle, !0, !0));
  let h = { width: 0, height: 0 };
  if (Z(z().flowchart.htmlLabels)) {
    const D = u.children[0], v = R(u);
    h = D.getBoundingClientRect(), v.attr("width", h.width), v.attr("height", h.height);
  }
  m.info("Text 2", n);
  const y = n.slice(1, n.length);
  let b = u.getBBox();
  const L = r.node().appendChild(
    await j(
      y.join ? y.join("<br/>") : y,
      t.labelStyle,
      !0,
      !0
    )
  );
  if (Z(z().flowchart.htmlLabels)) {
    const D = L.children[0], v = R(L);
    h = D.getBoundingClientRect(), v.attr("width", h.width), v.attr("height", h.height);
  }
  const E = t.padding / 2;
  return R(L).attr(
    "transform",
    "translate( " + // (titleBox.width - bbox.width) / 2 +
    (h.width > b.width ? 0 : (b.width - h.width) / 2) + ", " + (b.height + E + 5) + ")"
  ), R(u).attr(
    "transform",
    "translate( " + // (titleBox.width - bbox.width) / 2 +
    (h.width < b.width ? 0 : -(b.width - h.width) / 2) + ", 0)"
  ), h = r.node().getBBox(), r.attr(
    "transform",
    "translate(" + -h.width / 2 + ", " + (-h.height / 2 - E + 3) + ")"
  ), l.attr("class", "outer title-state").attr("x", -h.width / 2 - E).attr("y", -h.height / 2 - E).attr("width", h.width + t.padding).attr("height", h.height + t.padding), s.attr("class", "divider").attr("x1", -h.width / 2 - E).attr("x2", h.width / 2 + E).attr("y1", -h.height / 2 - E + b.height + E).attr("y2", -h.height / 2 - E + b.height + E), I(t, l), t.intersect = function(D) {
    return C.rect(t, D);
  }, i;
}, "rectWithTitle"), Wr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = i.height + t.padding, s = i.width + l / 4 + t.padding, r = a.insert("rect", ":first-child").attr("style", t.style).attr("rx", l / 2).attr("ry", l / 2).attr("x", -s / 2).attr("y", -l / 2).attr("width", s).attr("height", l);
  return I(t, r), t.intersect = function(n) {
    return C.rect(t, n);
  }, a;
}, "stadium"), Pr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i, halfPadding: l } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), s = a.insert("circle", ":first-child");
  return s.attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("r", i.width / 2 + l).attr("width", i.width + t.padding).attr("height", i.height + t.padding), m.info("Circle main"), I(t, s), t.intersect = function(r) {
    return m.info("Circle intersect", t, i.width / 2 + l, r), C.circle(t, i.width / 2 + l, r);
  }, a;
}, "circle"), Yr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i, halfPadding: l } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), s = 5, r = a.insert("g", ":first-child"), n = r.insert("circle"), o = r.insert("circle");
  return r.attr("class", t.class), n.attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("r", i.width / 2 + l + s).attr("width", i.width + t.padding + s * 2).attr("height", i.height + t.padding + s * 2), o.attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("r", i.width / 2 + l).attr("width", i.width + t.padding).attr("height", i.height + t.padding), m.info("DoubleCircle main"), I(t, n), t.intersect = function(u) {
    return m.info("DoubleCircle intersect", t, i.width / 2 + l + s, u), C.circle(t, i.width / 2 + l + s, u);
  }, a;
}, "doublecircle"), Hr = /* @__PURE__ */ d(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await F(
    e,
    t,
    K(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: 0, y: 0 },
    { x: l, y: 0 },
    { x: l, y: -s },
    { x: 0, y: -s },
    { x: 0, y: 0 },
    { x: -8, y: 0 },
    { x: l + 8, y: 0 },
    { x: l + 8, y: -s },
    { x: -8, y: -s },
    { x: -8, y: 0 }
  ], n = G(a, l, s, r);
  return n.attr("style", t.style), I(t, n), t.intersect = function(o) {
    return C.polygon(t, r, o);
  }, a;
}, "subroutine"), Kr = /* @__PURE__ */ d((e, t) => {
  const a = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), i = a.insert("circle", ":first-child");
  return i.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14), I(t, i), t.intersect = function(l) {
    return C.circle(t, 7, l);
  }, a;
}, "start"), Ft = /* @__PURE__ */ d((e, t, a) => {
  const i = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id);
  let l = 70, s = 10;
  a === "LR" && (l = 10, s = 70);
  const r = i.append("rect").attr("x", -1 * l / 2).attr("y", -1 * s / 2).attr("width", l).attr("height", s).attr("class", "fork-join");
  return I(t, r), t.height = t.height + t.padding / 2, t.width = t.width + t.padding / 2, t.intersect = function(n) {
    return C.rect(t, n);
  }, i;
}, "forkJoin"), Xr = /* @__PURE__ */ d((e, t) => {
  const a = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), i = a.insert("circle", ":first-child"), l = a.insert("circle", ":first-child");
  return l.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14), i.attr("class", "state-end").attr("r", 5).attr("width", 10).attr("height", 10), I(t, l), t.intersect = function(s) {
    return C.circle(t, 7, s);
  }, a;
}, "end"), Ur = /* @__PURE__ */ d(async (e, t) => {
  var S;
  const a = t.padding / 2, i = 4, l = 8;
  let s;
  t.classes ? s = "node " + t.classes : s = "node default";
  const r = e.insert("g").attr("class", s).attr("id", t.domId || t.id), n = r.insert("rect", ":first-child"), o = r.insert("line"), u = r.insert("line");
  let h = 0, y = i;
  const b = r.insert("g").attr("class", "label");
  let L = 0;
  const E = (S = t.classData.annotations) == null ? void 0 : S[0], D = t.classData.annotations[0] ? "«" + t.classData.annotations[0] + "»" : "", v = b.node().appendChild(await j(D, t.labelStyle, !0, !0));
  let T = v.getBBox();
  if (Z(z().flowchart.htmlLabels)) {
    const c = v.children[0], _ = R(v);
    T = c.getBoundingClientRect(), _.attr("width", T.width), _.attr("height", T.height);
  }
  t.classData.annotations[0] && (y += T.height + i, h += T.width);
  let k = t.classData.label;
  t.classData.type !== void 0 && t.classData.type !== "" && (z().flowchart.htmlLabels ? k += "&lt;" + t.classData.type + "&gt;" : k += "<" + t.classData.type + ">");
  const N = b.node().appendChild(await j(k, t.labelStyle, !0, !0));
  R(N).attr("class", "classTitle");
  let x = N.getBBox();
  if (Z(z().flowchart.htmlLabels)) {
    const c = N.children[0], _ = R(N);
    x = c.getBoundingClientRect(), _.attr("width", x.width), _.attr("height", x.height);
  }
  y += x.height + i, x.width > h && (h = x.width);
  const g = [];
  t.classData.members.forEach(async (c) => {
    const _ = c.getDisplayDetails();
    let f = _.displayText;
    z().flowchart.htmlLabels && (f = f.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    const A = b.node().appendChild(
      await j(
        f,
        _.cssStyle ? _.cssStyle : t.labelStyle,
        !0,
        !0
      )
    );
    let O = A.getBBox();
    if (Z(z().flowchart.htmlLabels)) {
      const X = A.children[0], P = R(A);
      O = X.getBoundingClientRect(), P.attr("width", O.width), P.attr("height", O.height);
    }
    O.width > h && (h = O.width), y += O.height + i, g.push(A);
  }), y += l;
  const p = [];
  if (t.classData.methods.forEach(async (c) => {
    const _ = c.getDisplayDetails();
    let f = _.displayText;
    z().flowchart.htmlLabels && (f = f.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    const A = b.node().appendChild(
      await j(
        f,
        _.cssStyle ? _.cssStyle : t.labelStyle,
        !0,
        !0
      )
    );
    let O = A.getBBox();
    if (Z(z().flowchart.htmlLabels)) {
      const X = A.children[0], P = R(A);
      O = X.getBoundingClientRect(), P.attr("width", O.width), P.attr("height", O.height);
    }
    O.width > h && (h = O.width), y += O.height + i, p.push(A);
  }), y += l, E) {
    let c = (h - T.width) / 2;
    R(v).attr(
      "transform",
      "translate( " + (-1 * h / 2 + c) + ", " + -1 * y / 2 + ")"
    ), L = T.height + i;
  }
  let w = (h - x.width) / 2;
  return R(N).attr(
    "transform",
    "translate( " + (-1 * h / 2 + w) + ", " + (-1 * y / 2 + L) + ")"
  ), L += x.height + i, o.attr("class", "divider").attr("x1", -h / 2 - a).attr("x2", h / 2 + a).attr("y1", -y / 2 - a + l + L).attr("y2", -y / 2 - a + l + L), L += l, g.forEach((c) => {
    R(c).attr(
      "transform",
      "translate( " + -h / 2 + ", " + (-1 * y / 2 + L + l / 2) + ")"
    );
    const _ = c == null ? void 0 : c.getBBox();
    L += ((_ == null ? void 0 : _.height) ?? 0) + i;
  }), L += l, u.attr("class", "divider").attr("x1", -h / 2 - a).attr("x2", h / 2 + a).attr("y1", -y / 2 - a + l + L).attr("y2", -y / 2 - a + l + L), L += l, p.forEach((c) => {
    R(c).attr(
      "transform",
      "translate( " + -h / 2 + ", " + (-1 * y / 2 + L) + ")"
    );
    const _ = c == null ? void 0 : c.getBBox();
    L += ((_ == null ? void 0 : _.height) ?? 0) + i;
  }), n.attr("style", t.style).attr("class", "outer title-state").attr("x", -h / 2 - a).attr("y", -(y / 2) - a).attr("width", h + t.padding).attr("height", y + t.padding), I(t, n), t.intersect = function(c) {
    return C.rect(t, c);
  }, r;
}, "class_box"), Wt = {
  rhombus: Mt,
  composite: Ar,
  question: Mt,
  rect: zr,
  labelRect: Mr,
  rectWithTitle: Fr,
  choice: _r,
  circle: Pr,
  doublecircle: Yr,
  stadium: Wr,
  hexagon: kr,
  block_arrow: Dr,
  rect_left_inv_arrow: Nr,
  lean_right: Tr,
  lean_left: Cr,
  trapezoid: Ir,
  inv_trapezoid: Br,
  rect_right_inv_arrow: Or,
  cylinder: Rr,
  start: Kr,
  end: Xr,
  note: Er,
  subroutine: Hr,
  fork: Ft,
  join: Ft,
  class_box: Ur
}, ct = {}, ae = /* @__PURE__ */ d(async (e, t, a) => {
  let i, l;
  if (t.link) {
    let s;
    z().securityLevel === "sandbox" ? s = "_top" : t.linkTarget && (s = t.linkTarget || "_blank"), i = e.insert("svg:a").attr("xlink:href", t.link).attr("target", s), l = await Wt[t.shape](i, t, a);
  } else
    l = await Wt[t.shape](e, t, a), i = l;
  return t.tooltip && l.attr("title", t.tooltip), t.class && l.attr("class", "node default " + t.class), ct[t.id] = i, t.haveCallback && ct[t.id].attr("class", ct[t.id].attr("class") + " clickable"), i;
}, "insertNode"), jr = /* @__PURE__ */ d((e) => {
  const t = ct[e.id];
  m.trace(
    "Transforming node",
    e.diff,
    e,
    "translate(" + (e.x - e.width / 2 - 5) + ", " + e.width / 2 + ")"
  );
  const a = 8, i = e.diff || 0;
  return e.clusterNode ? t.attr(
    "transform",
    "translate(" + (e.x + i - e.width / 2) + ", " + (e.y - e.height / 2 - a) + ")"
  ) : t.attr("transform", "translate(" + e.x + ", " + e.y + ")"), i;
}, "positionNode");
function Nt(e, t, a = !1) {
  var b, L, E;
  const i = e;
  let l = "default";
  (((b = i == null ? void 0 : i.classes) == null ? void 0 : b.length) || 0) > 0 && (l = ((i == null ? void 0 : i.classes) ?? []).join(" ")), l = l + " flowchart-label";
  let s = 0, r = "", n;
  switch (i.type) {
    case "round":
      s = 5, r = "rect";
      break;
    case "composite":
      s = 0, r = "composite", n = 0;
      break;
    case "square":
      r = "rect";
      break;
    case "diamond":
      r = "question";
      break;
    case "hexagon":
      r = "hexagon";
      break;
    case "block_arrow":
      r = "block_arrow";
      break;
    case "odd":
      r = "rect_left_inv_arrow";
      break;
    case "lean_right":
      r = "lean_right";
      break;
    case "lean_left":
      r = "lean_left";
      break;
    case "trapezoid":
      r = "trapezoid";
      break;
    case "inv_trapezoid":
      r = "inv_trapezoid";
      break;
    case "rect_left_inv_arrow":
      r = "rect_left_inv_arrow";
      break;
    case "circle":
      r = "circle";
      break;
    case "ellipse":
      r = "ellipse";
      break;
    case "stadium":
      r = "stadium";
      break;
    case "subroutine":
      r = "subroutine";
      break;
    case "cylinder":
      r = "cylinder";
      break;
    case "group":
      r = "rect";
      break;
    case "doublecircle":
      r = "doublecircle";
      break;
    default:
      r = "rect";
  }
  const o = Se((i == null ? void 0 : i.styles) ?? []), u = i.label, h = i.size ?? { width: 0, height: 0, x: 0, y: 0 };
  return {
    labelStyle: o.labelStyle,
    shape: r,
    labelText: u,
    rx: s,
    ry: s,
    class: l,
    style: o.style,
    id: i.id,
    directions: i.directions,
    width: h.width,
    height: h.height,
    x: h.x,
    y: h.y,
    positioned: a,
    intersect: void 0,
    type: i.type,
    padding: n ?? ((E = (L = st()) == null ? void 0 : L.block) == null ? void 0 : E.padding) ?? 0
  };
}
d(Nt, "getNodeFromBlock");
async function se(e, t, a) {
  const i = Nt(t, a, !1);
  if (i.type === "group")
    return;
  const l = st(), s = await ae(e, i, { config: l }), r = s.node().getBBox(), n = a.getBlock(i.id);
  n.size = { width: r.width, height: r.height, x: 0, y: 0, node: s }, a.setBlock(n), s.remove();
}
d(se, "calculateBlockSize");
async function ie(e, t, a) {
  const i = Nt(t, a, !0);
  if (a.getBlock(i.id).type !== "space") {
    const s = st();
    await ae(e, i, { config: s }), t.intersect = i == null ? void 0 : i.intersect, jr(i);
  }
}
d(ie, "insertBlockPositioned");
async function gt(e, t, a, i) {
  for (const l of t)
    await i(e, l, a), l.children && await gt(e, l.children, a, i);
}
d(gt, "performOperations");
async function ne(e, t, a) {
  await gt(e, t, a, se);
}
d(ne, "calculateBlockSizes");
async function le(e, t, a) {
  await gt(e, t, a, ie);
}
d(le, "insertBlocks");
async function ce(e, t, a, i, l) {
  const s = new Ee({
    multigraph: !0,
    compound: !0
  });
  s.setGraph({
    rankdir: "TB",
    nodesep: 10,
    ranksep: 10,
    marginx: 8,
    marginy: 8
  });
  for (const r of a)
    r.size && s.setNode(r.id, {
      width: r.size.width,
      height: r.size.height,
      intersect: r.intersect
    });
  for (const r of t)
    if (r.start && r.end) {
      const n = i.getBlock(r.start), o = i.getBlock(r.end);
      if (n != null && n.size && (o != null && o.size)) {
        const u = n.size, h = o.size, y = [
          { x: u.x, y: u.y },
          { x: u.x + (h.x - u.x) / 2, y: u.y + (h.y - u.y) / 2 },
          { x: h.x, y: h.y }
        ];
        pr(
          e,
          { v: r.start, w: r.end, name: r.id },
          {
            ...r,
            arrowTypeEnd: r.arrowTypeEnd,
            arrowTypeStart: r.arrowTypeStart,
            points: y,
            classes: "edge-thickness-normal edge-pattern-solid flowchart-link LS-a1 LE-b1"
          },
          void 0,
          "block",
          s,
          l
        ), r.label && (await hr(e, {
          ...r,
          label: r.label,
          labelStyle: "stroke: #333; stroke-width: 1.5px;fill:none;",
          arrowTypeEnd: r.arrowTypeEnd,
          arrowTypeStart: r.arrowTypeStart,
          points: y,
          classes: "edge-thickness-normal edge-pattern-solid flowchart-link LS-a1 LE-b1"
        }), dr(
          { ...r, x: y[1].x, y: y[1].y },
          {
            originalPath: y
          }
        ));
      }
    }
}
d(ce, "insertEdges");
var Vr = /* @__PURE__ */ d(function(e, t) {
  return t.db.getClasses();
}, "getClasses"), Gr = /* @__PURE__ */ d(async function(e, t, a, i) {
  const { securityLevel: l, block: s } = st(), r = i.db;
  let n;
  l === "sandbox" && (n = R("#i" + t));
  const o = l === "sandbox" ? R(n.nodes()[0].contentDocument.body) : R("body"), u = l === "sandbox" ? o.select(`[id="${t}"]`) : R(`[id="${t}"]`);
  ir(u, ["point", "circle", "cross"], i.type, t);
  const y = r.getBlocks(), b = r.getBlocksFlat(), L = r.getEdges(), E = u.insert("g").attr("class", "block");
  await ne(E, y, r);
  const D = Zt(r);
  if (await le(E, y, r), await ce(E, L, b, r, t), D) {
    const v = D, T = Math.max(1, Math.round(0.125 * (v.width / v.height))), k = v.height + T + 10, N = v.width + 10, { useMaxWidth: x } = s;
    ge(u, k, N, !!x), m.debug("Here Bounds", D, v), u.attr(
      "viewBox",
      `${v.x - 5} ${v.y - 5} ${v.width + 10} ${v.height + 10}`
    );
  }
}, "draw"), Zr = {
  draw: Gr,
  getClasses: Vr
}, ea = {
  parser: ke,
  db: Ue,
  renderer: Zr,
  styles: Ve
};
export {
  ea as diagram
};
