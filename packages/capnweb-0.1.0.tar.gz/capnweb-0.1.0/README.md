# Cap'n Web

According to it's own [documentation](https://github.com/cloudflare/capnweb):

> Cap'n Web is a spiritual sibling to Cap'n Proto (and is created by the same author), 
> but designed to play nice in the web stack.

**What is this**
Short version: a python implementation of the same RPC system, it's meant to play nice with the modern
Python ecosystem (async/await, Pydantic...) and offer the same features as the typescript-based implementation.

**This implementation is a work in progress and it's not production ready**
