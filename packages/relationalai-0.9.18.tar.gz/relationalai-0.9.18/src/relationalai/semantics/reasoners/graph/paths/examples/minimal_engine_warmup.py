from relationalai.semantics import select

select(1 + 1).inspect()