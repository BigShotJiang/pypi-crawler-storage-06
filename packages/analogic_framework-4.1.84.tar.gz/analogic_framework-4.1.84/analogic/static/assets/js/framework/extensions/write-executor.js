'use strict';

class WriteExecutorExtension {
    getExecutor(context) {
        return false;
    }
}