# Copyright The Cloud Custodian Authors.
# SPDX-License-Identifier: Apache-2.0
import logging

logging.getLogger("azure.storage.common.storageclient").setLevel(logging.WARNING)
