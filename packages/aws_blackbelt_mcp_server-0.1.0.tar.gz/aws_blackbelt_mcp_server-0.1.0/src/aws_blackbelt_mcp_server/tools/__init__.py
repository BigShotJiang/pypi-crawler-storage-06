"""Tools for AWS Black Belt MCP server."""
