"""Test package for PDF Reader MCP server."""
