# -*- coding: utf-8 -*-
class BlockEntityData(object):
    def __getitem__(self, key):
        pass

    def __setitem__(self, key, value):
        pass
