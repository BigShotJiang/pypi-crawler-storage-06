This module adds the possibility of Survey Answers to reviews.
