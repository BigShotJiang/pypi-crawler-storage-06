```python
def myfunc():
    return res
```