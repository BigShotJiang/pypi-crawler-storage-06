# credkit

Credkit is an open toolbox for credit modeling. From single loans to portfolio 
yield calculations, this project provides useful primitives for quickly 
building the types of models that often force teams to reach for Excel.