"""Test suite for MCP ctags functionality."""
