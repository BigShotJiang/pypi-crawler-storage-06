---
sdk: gradio
sdk_version: {GRADIO_VERSION}
app_file: ui/main.py
tags:
 - trackio
---