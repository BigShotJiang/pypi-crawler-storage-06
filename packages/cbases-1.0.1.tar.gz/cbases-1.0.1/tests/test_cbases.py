import cbases

a=EquBase(2)
print(a.b2())