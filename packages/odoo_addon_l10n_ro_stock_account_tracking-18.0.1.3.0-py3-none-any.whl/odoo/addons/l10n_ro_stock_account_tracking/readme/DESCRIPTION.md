Stock accounting tracking stock moves for receptions, deliveries,
consume, usage_giving, inventory and production.

Stock valuation by lots/serial number
