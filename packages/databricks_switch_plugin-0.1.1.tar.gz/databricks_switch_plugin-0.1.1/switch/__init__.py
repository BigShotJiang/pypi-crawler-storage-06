from importlib.metadata import version

__version__ = "0.1.1"
