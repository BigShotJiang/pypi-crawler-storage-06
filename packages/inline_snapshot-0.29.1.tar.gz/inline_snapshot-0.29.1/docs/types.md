

::: inline_snapshot
    options:
      heading_level: 1
      members: [Snapshot,Category]
      show_root_heading: true
      show_bases: false
