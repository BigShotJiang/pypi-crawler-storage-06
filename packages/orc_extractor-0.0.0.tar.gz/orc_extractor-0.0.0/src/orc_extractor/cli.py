#!/usr/bin/env python3
import sys


def main() -> int:
    print("placeholder project")
    return 0


if __name__ == "__main__":
    sys.exit(main())
