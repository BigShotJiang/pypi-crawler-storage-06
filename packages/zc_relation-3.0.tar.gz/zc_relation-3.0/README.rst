Index intransitive and transitive n-ary relationships.

It is used as base implementation for z3c.relationfield.

