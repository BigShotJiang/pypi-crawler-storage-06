"""autogit is a command line tool for updating multiple GitLab or GitHub repositories with a single command."""

__version__ = '0.0.16'
