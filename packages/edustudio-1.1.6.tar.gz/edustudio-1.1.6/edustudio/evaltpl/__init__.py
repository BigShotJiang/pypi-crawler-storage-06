from .base_evaltpl import BaseEvalTPL
from .prediction_evaltpl import PredictionEvalTPL
from .interpretability_evaltpl import InterpretabilityEvalTPL
from .fairness_evaltpl import FairnessEvalTPL
from .identifiability_evaltpl import IdentifiabilityEvalTPL

