from .base_datatpl import BaseDataTPL
from .edu_datatpl import EduDataTPL
from .general_datatpl import GeneralDataTPL
from .proxy_datatpl import BaseProxyDataTPL
