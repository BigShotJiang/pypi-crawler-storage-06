# -*- coding: utf-8 -*-
# @Author : Xiangzhi Chen
# @Github : kervias

from enum import Enum


class ModeState(Enum):
    START = 1
    TRAINING = 2
    END = 3
