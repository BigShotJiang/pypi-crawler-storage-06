global filename 
filename = "error"
DEBUG = False

debug_print = print if DEBUG else lambda *args, **kwargs: None
