# easypip

Ease the import / installation of packages in python and especially in notebooks

Usage
```
from easypip import easyimport

torch = easyimport("torch >= 1.8.0")
```