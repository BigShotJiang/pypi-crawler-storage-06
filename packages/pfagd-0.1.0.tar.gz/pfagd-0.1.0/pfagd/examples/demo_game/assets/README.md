# Demo Game Assets

This directory contains placeholder assets for the PFAGD demo game.

## Files:
- `player.png` - Player character sprite (placeholder)
- `enemy.png` - Enemy sprite (placeholder)  
- `background.png` - Background image (placeholder)
- `jump.wav` - Jump sound effect (placeholder)

## Note:
In a real project, you would replace these placeholder files with actual game assets.

The PFAGD asset manager will automatically optimize these assets for mobile deployment.