"""
PFAGD CLI Module
"""