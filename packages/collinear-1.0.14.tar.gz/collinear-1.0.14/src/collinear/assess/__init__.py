"""Local assessment package (no platform dependencies)."""
