export const peekAppEnvironment = {
  version: "5.1.4",
};
