# Mock objects for testing
