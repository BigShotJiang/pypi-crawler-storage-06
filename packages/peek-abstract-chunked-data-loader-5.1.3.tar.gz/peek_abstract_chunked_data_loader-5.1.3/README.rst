====================
Abstract Data Loader
====================

This plugin loads equipment details from a source server.

The details it loads are simple properties, like ID, Alias, Name and a customised list of
attributes.

The plugin populates two of the standard Peek DB plugins, Search and DocDB
