"""The ncaaf data sportsball module."""

# ruff: noqa: F401
from .combined.ncaaf_combined_league_model import \
    NCAAFCombinedLeagueModel as NCAAFLeagueModel
