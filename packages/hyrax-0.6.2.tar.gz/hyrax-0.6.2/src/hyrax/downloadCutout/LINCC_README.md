# HSC Data download tool.
This tool was downloaded from the [ssp-software/data-access-tools](https://hsc-gitlab.mtk.nao.ac.jp/ssp-software/data-access-tools/) gitlab repository.

This directory was initialized with a copy of the `pdr3/downloadCutout` directory at rev b628d6089acda041eea1041d1011ea154ebefc28 committed Feb 14 2024.