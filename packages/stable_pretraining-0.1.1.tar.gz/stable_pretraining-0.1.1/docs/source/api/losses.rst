stable_pretraining.losses
=================

.. module:: stable_pretraining.losses
.. currentmodule:: stable_pretraining.losses

.. autosummary::
   :toctree: gen_modules/
   :template: myclass_template.rst

   NTXEntLoss
   NegativeCosineSimilarity
   VICRegLoss
   BarlowTwinsLoss
