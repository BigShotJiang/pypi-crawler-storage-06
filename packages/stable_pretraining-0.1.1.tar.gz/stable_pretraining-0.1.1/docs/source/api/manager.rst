stable_pretraining.manager
==================
.. module:: stable_pretraining.manager
.. currentmodule:: stable_pretraining.manager

The manager module provides the main training orchestration class for self-supervised learning experiments.

Training Management
------------------

.. autosummary::
   :toctree: gen_modules/
   :template: myclass_template.rst

   Manager
