﻿set\_embedding\_dim
===================

.. currentmodule:: stable_pretraining.backbone

.. autofunction:: set_embedding_dim

.. minigallery:: stable_pretraining.backbone.set_embedding_dim
    :add-heading: Examples using ``set_embedding_dim``:
