﻿TeacherStudentWrapper
====================

.. currentmodule:: stable_pretraining.backbone

.. autoclass:: TeacherStudentWrapper
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.backbone.TeacherStudentWrapper:

.. minigallery:: stable_pretraining.backbone.TeacherStudentWrapper
    :add-heading: Examples using ``TeacherStudentWrapper``:
