﻿from\_torchvision
=================

.. currentmodule:: stable_pretraining.backbone

.. autofunction:: from_torchvision

.. minigallery:: stable_pretraining.backbone.from_torchvision
    :add-heading: Examples using ``from_torchvision``:
