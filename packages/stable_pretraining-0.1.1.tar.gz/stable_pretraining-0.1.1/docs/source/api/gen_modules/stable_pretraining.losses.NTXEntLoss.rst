﻿NTXEntLoss
==========

.. currentmodule:: stable_pretraining.losses

.. autoclass:: NTXEntLoss
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.losses.NTXEntLoss:

.. minigallery:: stable_pretraining.losses.NTXEntLoss
    :add-heading: Examples using ``NTXEntLoss``:
