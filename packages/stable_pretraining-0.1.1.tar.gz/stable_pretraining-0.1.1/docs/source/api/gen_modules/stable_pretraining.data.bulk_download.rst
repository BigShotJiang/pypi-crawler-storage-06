﻿bulk\_download
==============

.. currentmodule:: stable_pretraining.data

.. autofunction:: bulk_download

.. minigallery:: stable_pretraining.data.bulk_download
    :add-heading: Examples using ``bulk_download``:
