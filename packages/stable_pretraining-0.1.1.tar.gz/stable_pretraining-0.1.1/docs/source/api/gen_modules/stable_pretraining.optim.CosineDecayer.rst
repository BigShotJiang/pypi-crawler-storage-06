﻿CosineDecayer
=============

.. currentmodule:: stable_pretraining.optim

.. autoclass:: CosineDecayer
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.optim.CosineDecayer:

.. minigallery:: stable_pretraining.optim.CosineDecayer
    :add-heading: Examples using ``CosineDecayer``:
