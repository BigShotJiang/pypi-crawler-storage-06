﻿ExponentialNormalNoiseModel
===========================

.. currentmodule:: stable_pretraining.data

.. autoclass:: ExponentialNormalNoiseModel
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.data.ExponentialNormalNoiseModel:

.. minigallery:: stable_pretraining.data.ExponentialNormalNoiseModel
    :add-heading: Examples using ``ExponentialNormalNoiseModel``:
