﻿Resnet9
=======

.. currentmodule:: stable_pretraining.backbone

.. autoclass:: Resnet9
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.backbone.Resnet9:

.. minigallery:: stable_pretraining.backbone.Resnet9
    :add-heading: Examples using ``Resnet9``:
