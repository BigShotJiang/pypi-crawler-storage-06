﻿VICRegLoss
==========

.. currentmodule:: stable_pretraining.losses

.. autoclass:: VICRegLoss
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.losses.VICRegLoss:

.. minigallery:: stable_pretraining.losses.VICRegLoss
    :add-heading: Examples using ``VICRegLoss``:
