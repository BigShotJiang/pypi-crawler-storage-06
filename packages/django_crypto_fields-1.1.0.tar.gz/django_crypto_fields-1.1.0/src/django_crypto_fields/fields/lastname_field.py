from .base_rsa_field import BaseRsaField

__all__ = ["LastnameField"]


class LastnameField(BaseRsaField):
    pass
