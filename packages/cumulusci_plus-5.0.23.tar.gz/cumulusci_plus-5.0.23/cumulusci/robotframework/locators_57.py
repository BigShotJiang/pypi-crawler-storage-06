import copy

from cumulusci.robotframework import locators_56

lex_locators = copy.deepcopy(locators_56.lex_locators)
