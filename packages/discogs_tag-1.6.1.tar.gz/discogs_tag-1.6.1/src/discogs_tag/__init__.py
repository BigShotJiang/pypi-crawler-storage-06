import importlib_metadata

__NAME__ = 'discogs-tag'
__VERSION__ = importlib_metadata.version(__NAME__)
