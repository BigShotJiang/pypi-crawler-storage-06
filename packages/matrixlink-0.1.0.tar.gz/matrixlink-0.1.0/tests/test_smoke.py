from matrixlink import MCPClient, A2AClient, OrchestratorClient

def test_imports():
    assert MCPClient and A2AClient and OrchestratorClient
