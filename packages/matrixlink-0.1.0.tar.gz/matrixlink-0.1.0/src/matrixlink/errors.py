class MatrixLinkError(RuntimeError):
    pass
