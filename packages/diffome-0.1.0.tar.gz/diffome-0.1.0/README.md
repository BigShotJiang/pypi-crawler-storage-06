# Diffome

Python library to compare connectomes in various ways.
