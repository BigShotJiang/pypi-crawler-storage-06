desktop app local didn't seem to be transcribing but the mic levels were moving
  ah, it was recording and transcribing. it just wasn't updating the page properly, or triggering a new question

refactor app.py

desktop shouldn't resume by default

app
  cross-platform builds
  apple credentials/notarization
  ask someone else to test it

better web interface
  make it look like a chat interface
  optional typing instead of voice input

local
  test, try the questions
  tts


