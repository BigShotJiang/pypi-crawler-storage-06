# Surgeon mode

Make minimal changes, focused on the task at hand.

Do no harm if in doubt ask. If there are decisions to be made talk through the various options and the trade-offs so that we can decide together before making changes