Read the planning doc, and relevant code & docs.

This is an old planning doc. We might have basically finished it. Is there anything important remaining?

- If so, stop and let's discuss.

- If not:
  - Update documentation if needed
  - Follow instructions in docs/instructions/RENAME_OR_MOVE.md to move the planning doc to planning/finished/ and update references to the new path with a subagent (if available)
  - Commit this set of changes in a single commit (otherwise following docs/instructions/GIT_COMMIT_CHANGES.md ).