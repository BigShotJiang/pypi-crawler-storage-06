"""Single source of truth for package version."""

__version__ = "0.6.1"
