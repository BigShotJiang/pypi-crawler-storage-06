"""Configuracoes do plugin."""

from mtcli.conf import *
