# request-mcp

A Python package for experimenting with request-mcp ONLY. Do not use.

## Installation

```bash
pip install request-mcp

