"""Basic tests for trendify package."""


def test_import():
    """Test that trendify can be imported."""
    import trendify

    assert trendify is not None
