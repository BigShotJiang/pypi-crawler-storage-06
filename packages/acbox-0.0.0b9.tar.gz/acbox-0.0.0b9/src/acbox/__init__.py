__version__ = "{{ gdata.version }}"
__hash__ = "{{ gdata.rev }}"
