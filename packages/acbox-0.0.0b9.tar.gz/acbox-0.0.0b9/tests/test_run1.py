def test_ls(resolver):
    print(resolver.lookup("simple-script.py"))
