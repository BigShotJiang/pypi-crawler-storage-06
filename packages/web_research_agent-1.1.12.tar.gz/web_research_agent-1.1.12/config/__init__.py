
# Config module initialization
from .config import get_config, init_config