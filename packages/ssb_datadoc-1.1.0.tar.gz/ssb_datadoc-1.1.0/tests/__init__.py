"""Unit tests for Datadoc."""
