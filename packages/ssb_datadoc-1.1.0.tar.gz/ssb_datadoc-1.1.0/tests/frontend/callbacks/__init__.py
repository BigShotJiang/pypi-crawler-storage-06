"""Unit tests for the frontend.callbacks package."""
