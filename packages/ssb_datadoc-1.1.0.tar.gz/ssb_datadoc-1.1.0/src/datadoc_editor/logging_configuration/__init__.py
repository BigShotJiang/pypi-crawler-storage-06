"""Code that is used for setting up the logging for the Datadoc app."""
