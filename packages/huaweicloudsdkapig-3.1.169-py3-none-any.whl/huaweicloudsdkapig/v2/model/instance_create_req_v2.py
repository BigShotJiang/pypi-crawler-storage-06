# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class InstanceCreateReqV2:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'description': 'str',
        'maintain_begin': 'str',
        'maintain_end': 'str',
        'instance_name': 'str',
        'instance_id': 'str',
        'spec_id': 'str',
        'vpc_id': 'str',
        'subnet_id': 'str',
        'security_group_id': 'str',
        'eip_id': 'str',
        'enterprise_project_id': 'str',
        'available_zone_ids': 'list[str]',
        'bandwidth_size': 'int',
        'bandwidth_charging_mode': 'str',
        'ipv6_enable': 'bool',
        'loadbalancer_provider': 'str',
        'tags': 'list[TmsKeyValue]',
        'vpcep_service_name': 'str',
        'ingress_bandwidth_size': 'int',
        'ingress_bandwidth_charging_mode': 'str'
    }

    attribute_map = {
        'description': 'description',
        'maintain_begin': 'maintain_begin',
        'maintain_end': 'maintain_end',
        'instance_name': 'instance_name',
        'instance_id': 'instance_id',
        'spec_id': 'spec_id',
        'vpc_id': 'vpc_id',
        'subnet_id': 'subnet_id',
        'security_group_id': 'security_group_id',
        'eip_id': 'eip_id',
        'enterprise_project_id': 'enterprise_project_id',
        'available_zone_ids': 'available_zone_ids',
        'bandwidth_size': 'bandwidth_size',
        'bandwidth_charging_mode': 'bandwidth_charging_mode',
        'ipv6_enable': 'ipv6_enable',
        'loadbalancer_provider': 'loadbalancer_provider',
        'tags': 'tags',
        'vpcep_service_name': 'vpcep_service_name',
        'ingress_bandwidth_size': 'ingress_bandwidth_size',
        'ingress_bandwidth_charging_mode': 'ingress_bandwidth_charging_mode'
    }

    def __init__(self, description=None, maintain_begin=None, maintain_end=None, instance_name=None, instance_id=None, spec_id=None, vpc_id=None, subnet_id=None, security_group_id=None, eip_id=None, enterprise_project_id=None, available_zone_ids=None, bandwidth_size=None, bandwidth_charging_mode=None, ipv6_enable=None, loadbalancer_provider=None, tags=None, vpcep_service_name=None, ingress_bandwidth_size=None, ingress_bandwidth_charging_mode=None):
        r"""InstanceCreateReqV2

        The model defined in huaweicloud sdk

        :param description: 实例描述。支持除&gt;和&lt;以外的字符，长度为0~255。
        :type description: str
        :param maintain_begin: 维护时间窗开始时间。时间格式为 xx:00:00，xx取值为02,06,10,14,18,22。  在这个时间段内，运维人员可以对该实例的节点进行维护操作。维护期间，业务可以正常使用，可能会发生闪断。维护操作通常几个月一次。
        :type maintain_begin: str
        :param maintain_end: 维护时间窗结束时间。时间格式为 xx:00:00，与维护时间窗开始时间相差4个小时。  在这个时间段内，运维人员可以对该实例的节点进行维护操作。维护期间，业务可以正常使用，可能会发生闪断。维护操作通常几个月一次。
        :type maintain_end: str
        :param instance_name: 实例名称。  中英文字符开头，只能由中英文字符、数字、中划线、下划线组成，长度为3~64。  &gt; 中文字符必须为UTF-8或者unicode编码。
        :type instance_name: str
        :param instance_id: 实例编号，不填写自动生成
        :type instance_id: str
        :param spec_id: 实例规格： - BASIC：基础版实例 - PROFESSIONAL：专业版实例 - ENTERPRISE：企业版实例 - PLATINUM：铂金版实例 - BASIC_IPV6：基础版IPV6实例 - PROFESSIONAL_IPV6：专业版IPV6实例 - ENTERPRISE_IPV6：企业版IPV6实例 - PLATINUM_IPV6：铂金版IPV6实例 - PLATINUM_X2：铂金版 x2实例 - PLATINUM_X3：铂金版 x3实例 - PLATINUM_X4：铂金版 x4实例 - PLATINUM_X5：铂金版 x5实例 - PLATINUM_X6：铂金版 x6实例 - PLATINUM_X7：铂金版 x7实例 - PLATINUM_X8：铂金版 x8实例  当前仅部分region支持铂金版 x2、铂金版 x3、铂金版 x4、铂金版 x5、铂金版 x6、铂金版 x7、铂金版 x8
        :type spec_id: str
        :param vpc_id: 虚拟私有云ID。  获取方法如下：   - 方法1：登录虚拟私有云服务的控制台界面，在虚拟私有云的详情页面查找VPC ID。   - 方法2：通过虚拟私有云服务的API接口查询，具体方法请参见《虚拟私有云服务API参考》的“查询VPC列表”章节。 
        :type vpc_id: str
        :param subnet_id: 子网的网络ID。  获取方法如下： - 方法1：登录虚拟私有云服务的控制台界面，单击VPC下的子网，进入子网详情页面，查找网络ID。 - 方法2：通过虚拟私有云服务的API接口查询，具体方法请参见《虚拟私有云服务API参考》的“查询子网列表”章节。 
        :type subnet_id: str
        :param security_group_id: 指定实例所属的安全组。  获取方法如下： - 方法1：登录虚拟私有云服务的控制台界面，在安全组的详情页面查找安全组ID。 - 方法2：通过虚拟私有云服务的API接口查询，具体方法请参见《虚拟私有云服务API参考》的“查询安全组列表”章节。 
        :type security_group_id: str
        :param eip_id: 弹性公网IP ID。  实例需要开启公网访问，且loadbalancer_provider为lvs时需要填写，绑定后使用者可以通过该入口从公网访问APIG实例中的API等资源  获取方法：登录虚拟私有云服务的控制台界面，在弹性公网IP的详情页面查找弹性公网IP ID。
        :type eip_id: str
        :param enterprise_project_id: 企业项目ID，企业账号必填。  获取方法如下： - 方法1：登录企业项目管理界面，在项目管理详情页面查找项目ID。 - 方法2：通过企业项目管理的API接口查询，具体方法请参见《企业管理API参考》的“查询企业项目列表”章节。
        :type enterprise_project_id: str
        :param available_zone_ids: 可用区列表
        :type available_zone_ids: list[str]
        :param bandwidth_size: 出公网带宽  实例需要开启出公网功能时需要填写，绑定后使用者可以利用该出口访问公网上的互联网资源
        :type bandwidth_size: int
        :param bandwidth_charging_mode: 带宽收费模式： - bandwidth - traffic
        :type bandwidth_charging_mode: str
        :param ipv6_enable: 公网访问是否支持IPv6。  当前仅部分region部分可用区支持IPv6
        :type ipv6_enable: bool
        :param loadbalancer_provider: 负载均衡器类型： - lvs - elb
        :type loadbalancer_provider: str
        :param tags: 标签列表。  一个实例默认最多支持创建20个标签
        :type tags: list[:class:`huaweicloudsdkapig.v2.TmsKeyValue`]
        :param vpcep_service_name: 终端节点服务的名称。  支持英文、数字、中划线、下划线，0~16个字符。  如果您不填写该参数，系统生成的终端节点服务的名称为{region}.apig.{service_id}。 如果您填写该参数，系统生成的终端节点服务的名称为{region}.{vpcep_service_name}.{service_id}。 实例创建完成后，可以在实例管理-&gt;终端节点管理页面修改该名称。 
        :type vpcep_service_name: str
        :param ingress_bandwidth_size: 入口带宽大小
        :type ingress_bandwidth_size: int
        :param ingress_bandwidth_charging_mode: 入口带宽收费模式： - bandwidth - traffic
        :type ingress_bandwidth_charging_mode: str
        """
        
        

        self._description = None
        self._maintain_begin = None
        self._maintain_end = None
        self._instance_name = None
        self._instance_id = None
        self._spec_id = None
        self._vpc_id = None
        self._subnet_id = None
        self._security_group_id = None
        self._eip_id = None
        self._enterprise_project_id = None
        self._available_zone_ids = None
        self._bandwidth_size = None
        self._bandwidth_charging_mode = None
        self._ipv6_enable = None
        self._loadbalancer_provider = None
        self._tags = None
        self._vpcep_service_name = None
        self._ingress_bandwidth_size = None
        self._ingress_bandwidth_charging_mode = None
        self.discriminator = None

        if description is not None:
            self.description = description
        if maintain_begin is not None:
            self.maintain_begin = maintain_begin
        if maintain_end is not None:
            self.maintain_end = maintain_end
        if instance_name is not None:
            self.instance_name = instance_name
        if instance_id is not None:
            self.instance_id = instance_id
        if spec_id is not None:
            self.spec_id = spec_id
        if vpc_id is not None:
            self.vpc_id = vpc_id
        if subnet_id is not None:
            self.subnet_id = subnet_id
        if security_group_id is not None:
            self.security_group_id = security_group_id
        if eip_id is not None:
            self.eip_id = eip_id
        if enterprise_project_id is not None:
            self.enterprise_project_id = enterprise_project_id
        if available_zone_ids is not None:
            self.available_zone_ids = available_zone_ids
        if bandwidth_size is not None:
            self.bandwidth_size = bandwidth_size
        if bandwidth_charging_mode is not None:
            self.bandwidth_charging_mode = bandwidth_charging_mode
        if ipv6_enable is not None:
            self.ipv6_enable = ipv6_enable
        if loadbalancer_provider is not None:
            self.loadbalancer_provider = loadbalancer_provider
        if tags is not None:
            self.tags = tags
        if vpcep_service_name is not None:
            self.vpcep_service_name = vpcep_service_name
        if ingress_bandwidth_size is not None:
            self.ingress_bandwidth_size = ingress_bandwidth_size
        if ingress_bandwidth_charging_mode is not None:
            self.ingress_bandwidth_charging_mode = ingress_bandwidth_charging_mode

    @property
    def description(self):
        r"""Gets the description of this InstanceCreateReqV2.

        实例描述。支持除>和<以外的字符，长度为0~255。

        :return: The description of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this InstanceCreateReqV2.

        实例描述。支持除>和<以外的字符，长度为0~255。

        :param description: The description of this InstanceCreateReqV2.
        :type description: str
        """
        self._description = description

    @property
    def maintain_begin(self):
        r"""Gets the maintain_begin of this InstanceCreateReqV2.

        维护时间窗开始时间。时间格式为 xx:00:00，xx取值为02,06,10,14,18,22。  在这个时间段内，运维人员可以对该实例的节点进行维护操作。维护期间，业务可以正常使用，可能会发生闪断。维护操作通常几个月一次。

        :return: The maintain_begin of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._maintain_begin

    @maintain_begin.setter
    def maintain_begin(self, maintain_begin):
        r"""Sets the maintain_begin of this InstanceCreateReqV2.

        维护时间窗开始时间。时间格式为 xx:00:00，xx取值为02,06,10,14,18,22。  在这个时间段内，运维人员可以对该实例的节点进行维护操作。维护期间，业务可以正常使用，可能会发生闪断。维护操作通常几个月一次。

        :param maintain_begin: The maintain_begin of this InstanceCreateReqV2.
        :type maintain_begin: str
        """
        self._maintain_begin = maintain_begin

    @property
    def maintain_end(self):
        r"""Gets the maintain_end of this InstanceCreateReqV2.

        维护时间窗结束时间。时间格式为 xx:00:00，与维护时间窗开始时间相差4个小时。  在这个时间段内，运维人员可以对该实例的节点进行维护操作。维护期间，业务可以正常使用，可能会发生闪断。维护操作通常几个月一次。

        :return: The maintain_end of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._maintain_end

    @maintain_end.setter
    def maintain_end(self, maintain_end):
        r"""Sets the maintain_end of this InstanceCreateReqV2.

        维护时间窗结束时间。时间格式为 xx:00:00，与维护时间窗开始时间相差4个小时。  在这个时间段内，运维人员可以对该实例的节点进行维护操作。维护期间，业务可以正常使用，可能会发生闪断。维护操作通常几个月一次。

        :param maintain_end: The maintain_end of this InstanceCreateReqV2.
        :type maintain_end: str
        """
        self._maintain_end = maintain_end

    @property
    def instance_name(self):
        r"""Gets the instance_name of this InstanceCreateReqV2.

        实例名称。  中英文字符开头，只能由中英文字符、数字、中划线、下划线组成，长度为3~64。  > 中文字符必须为UTF-8或者unicode编码。

        :return: The instance_name of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._instance_name

    @instance_name.setter
    def instance_name(self, instance_name):
        r"""Sets the instance_name of this InstanceCreateReqV2.

        实例名称。  中英文字符开头，只能由中英文字符、数字、中划线、下划线组成，长度为3~64。  > 中文字符必须为UTF-8或者unicode编码。

        :param instance_name: The instance_name of this InstanceCreateReqV2.
        :type instance_name: str
        """
        self._instance_name = instance_name

    @property
    def instance_id(self):
        r"""Gets the instance_id of this InstanceCreateReqV2.

        实例编号，不填写自动生成

        :return: The instance_id of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this InstanceCreateReqV2.

        实例编号，不填写自动生成

        :param instance_id: The instance_id of this InstanceCreateReqV2.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def spec_id(self):
        r"""Gets the spec_id of this InstanceCreateReqV2.

        实例规格： - BASIC：基础版实例 - PROFESSIONAL：专业版实例 - ENTERPRISE：企业版实例 - PLATINUM：铂金版实例 - BASIC_IPV6：基础版IPV6实例 - PROFESSIONAL_IPV6：专业版IPV6实例 - ENTERPRISE_IPV6：企业版IPV6实例 - PLATINUM_IPV6：铂金版IPV6实例 - PLATINUM_X2：铂金版 x2实例 - PLATINUM_X3：铂金版 x3实例 - PLATINUM_X4：铂金版 x4实例 - PLATINUM_X5：铂金版 x5实例 - PLATINUM_X6：铂金版 x6实例 - PLATINUM_X7：铂金版 x7实例 - PLATINUM_X8：铂金版 x8实例  当前仅部分region支持铂金版 x2、铂金版 x3、铂金版 x4、铂金版 x5、铂金版 x6、铂金版 x7、铂金版 x8

        :return: The spec_id of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._spec_id

    @spec_id.setter
    def spec_id(self, spec_id):
        r"""Sets the spec_id of this InstanceCreateReqV2.

        实例规格： - BASIC：基础版实例 - PROFESSIONAL：专业版实例 - ENTERPRISE：企业版实例 - PLATINUM：铂金版实例 - BASIC_IPV6：基础版IPV6实例 - PROFESSIONAL_IPV6：专业版IPV6实例 - ENTERPRISE_IPV6：企业版IPV6实例 - PLATINUM_IPV6：铂金版IPV6实例 - PLATINUM_X2：铂金版 x2实例 - PLATINUM_X3：铂金版 x3实例 - PLATINUM_X4：铂金版 x4实例 - PLATINUM_X5：铂金版 x5实例 - PLATINUM_X6：铂金版 x6实例 - PLATINUM_X7：铂金版 x7实例 - PLATINUM_X8：铂金版 x8实例  当前仅部分region支持铂金版 x2、铂金版 x3、铂金版 x4、铂金版 x5、铂金版 x6、铂金版 x7、铂金版 x8

        :param spec_id: The spec_id of this InstanceCreateReqV2.
        :type spec_id: str
        """
        self._spec_id = spec_id

    @property
    def vpc_id(self):
        r"""Gets the vpc_id of this InstanceCreateReqV2.

        虚拟私有云ID。  获取方法如下：   - 方法1：登录虚拟私有云服务的控制台界面，在虚拟私有云的详情页面查找VPC ID。   - 方法2：通过虚拟私有云服务的API接口查询，具体方法请参见《虚拟私有云服务API参考》的“查询VPC列表”章节。 

        :return: The vpc_id of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._vpc_id

    @vpc_id.setter
    def vpc_id(self, vpc_id):
        r"""Sets the vpc_id of this InstanceCreateReqV2.

        虚拟私有云ID。  获取方法如下：   - 方法1：登录虚拟私有云服务的控制台界面，在虚拟私有云的详情页面查找VPC ID。   - 方法2：通过虚拟私有云服务的API接口查询，具体方法请参见《虚拟私有云服务API参考》的“查询VPC列表”章节。 

        :param vpc_id: The vpc_id of this InstanceCreateReqV2.
        :type vpc_id: str
        """
        self._vpc_id = vpc_id

    @property
    def subnet_id(self):
        r"""Gets the subnet_id of this InstanceCreateReqV2.

        子网的网络ID。  获取方法如下： - 方法1：登录虚拟私有云服务的控制台界面，单击VPC下的子网，进入子网详情页面，查找网络ID。 - 方法2：通过虚拟私有云服务的API接口查询，具体方法请参见《虚拟私有云服务API参考》的“查询子网列表”章节。 

        :return: The subnet_id of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._subnet_id

    @subnet_id.setter
    def subnet_id(self, subnet_id):
        r"""Sets the subnet_id of this InstanceCreateReqV2.

        子网的网络ID。  获取方法如下： - 方法1：登录虚拟私有云服务的控制台界面，单击VPC下的子网，进入子网详情页面，查找网络ID。 - 方法2：通过虚拟私有云服务的API接口查询，具体方法请参见《虚拟私有云服务API参考》的“查询子网列表”章节。 

        :param subnet_id: The subnet_id of this InstanceCreateReqV2.
        :type subnet_id: str
        """
        self._subnet_id = subnet_id

    @property
    def security_group_id(self):
        r"""Gets the security_group_id of this InstanceCreateReqV2.

        指定实例所属的安全组。  获取方法如下： - 方法1：登录虚拟私有云服务的控制台界面，在安全组的详情页面查找安全组ID。 - 方法2：通过虚拟私有云服务的API接口查询，具体方法请参见《虚拟私有云服务API参考》的“查询安全组列表”章节。 

        :return: The security_group_id of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._security_group_id

    @security_group_id.setter
    def security_group_id(self, security_group_id):
        r"""Sets the security_group_id of this InstanceCreateReqV2.

        指定实例所属的安全组。  获取方法如下： - 方法1：登录虚拟私有云服务的控制台界面，在安全组的详情页面查找安全组ID。 - 方法2：通过虚拟私有云服务的API接口查询，具体方法请参见《虚拟私有云服务API参考》的“查询安全组列表”章节。 

        :param security_group_id: The security_group_id of this InstanceCreateReqV2.
        :type security_group_id: str
        """
        self._security_group_id = security_group_id

    @property
    def eip_id(self):
        r"""Gets the eip_id of this InstanceCreateReqV2.

        弹性公网IP ID。  实例需要开启公网访问，且loadbalancer_provider为lvs时需要填写，绑定后使用者可以通过该入口从公网访问APIG实例中的API等资源  获取方法：登录虚拟私有云服务的控制台界面，在弹性公网IP的详情页面查找弹性公网IP ID。

        :return: The eip_id of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._eip_id

    @eip_id.setter
    def eip_id(self, eip_id):
        r"""Sets the eip_id of this InstanceCreateReqV2.

        弹性公网IP ID。  实例需要开启公网访问，且loadbalancer_provider为lvs时需要填写，绑定后使用者可以通过该入口从公网访问APIG实例中的API等资源  获取方法：登录虚拟私有云服务的控制台界面，在弹性公网IP的详情页面查找弹性公网IP ID。

        :param eip_id: The eip_id of this InstanceCreateReqV2.
        :type eip_id: str
        """
        self._eip_id = eip_id

    @property
    def enterprise_project_id(self):
        r"""Gets the enterprise_project_id of this InstanceCreateReqV2.

        企业项目ID，企业账号必填。  获取方法如下： - 方法1：登录企业项目管理界面，在项目管理详情页面查找项目ID。 - 方法2：通过企业项目管理的API接口查询，具体方法请参见《企业管理API参考》的“查询企业项目列表”章节。

        :return: The enterprise_project_id of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._enterprise_project_id

    @enterprise_project_id.setter
    def enterprise_project_id(self, enterprise_project_id):
        r"""Sets the enterprise_project_id of this InstanceCreateReqV2.

        企业项目ID，企业账号必填。  获取方法如下： - 方法1：登录企业项目管理界面，在项目管理详情页面查找项目ID。 - 方法2：通过企业项目管理的API接口查询，具体方法请参见《企业管理API参考》的“查询企业项目列表”章节。

        :param enterprise_project_id: The enterprise_project_id of this InstanceCreateReqV2.
        :type enterprise_project_id: str
        """
        self._enterprise_project_id = enterprise_project_id

    @property
    def available_zone_ids(self):
        r"""Gets the available_zone_ids of this InstanceCreateReqV2.

        可用区列表

        :return: The available_zone_ids of this InstanceCreateReqV2.
        :rtype: list[str]
        """
        return self._available_zone_ids

    @available_zone_ids.setter
    def available_zone_ids(self, available_zone_ids):
        r"""Sets the available_zone_ids of this InstanceCreateReqV2.

        可用区列表

        :param available_zone_ids: The available_zone_ids of this InstanceCreateReqV2.
        :type available_zone_ids: list[str]
        """
        self._available_zone_ids = available_zone_ids

    @property
    def bandwidth_size(self):
        r"""Gets the bandwidth_size of this InstanceCreateReqV2.

        出公网带宽  实例需要开启出公网功能时需要填写，绑定后使用者可以利用该出口访问公网上的互联网资源

        :return: The bandwidth_size of this InstanceCreateReqV2.
        :rtype: int
        """
        return self._bandwidth_size

    @bandwidth_size.setter
    def bandwidth_size(self, bandwidth_size):
        r"""Sets the bandwidth_size of this InstanceCreateReqV2.

        出公网带宽  实例需要开启出公网功能时需要填写，绑定后使用者可以利用该出口访问公网上的互联网资源

        :param bandwidth_size: The bandwidth_size of this InstanceCreateReqV2.
        :type bandwidth_size: int
        """
        self._bandwidth_size = bandwidth_size

    @property
    def bandwidth_charging_mode(self):
        r"""Gets the bandwidth_charging_mode of this InstanceCreateReqV2.

        带宽收费模式： - bandwidth - traffic

        :return: The bandwidth_charging_mode of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._bandwidth_charging_mode

    @bandwidth_charging_mode.setter
    def bandwidth_charging_mode(self, bandwidth_charging_mode):
        r"""Sets the bandwidth_charging_mode of this InstanceCreateReqV2.

        带宽收费模式： - bandwidth - traffic

        :param bandwidth_charging_mode: The bandwidth_charging_mode of this InstanceCreateReqV2.
        :type bandwidth_charging_mode: str
        """
        self._bandwidth_charging_mode = bandwidth_charging_mode

    @property
    def ipv6_enable(self):
        r"""Gets the ipv6_enable of this InstanceCreateReqV2.

        公网访问是否支持IPv6。  当前仅部分region部分可用区支持IPv6

        :return: The ipv6_enable of this InstanceCreateReqV2.
        :rtype: bool
        """
        return self._ipv6_enable

    @ipv6_enable.setter
    def ipv6_enable(self, ipv6_enable):
        r"""Sets the ipv6_enable of this InstanceCreateReqV2.

        公网访问是否支持IPv6。  当前仅部分region部分可用区支持IPv6

        :param ipv6_enable: The ipv6_enable of this InstanceCreateReqV2.
        :type ipv6_enable: bool
        """
        self._ipv6_enable = ipv6_enable

    @property
    def loadbalancer_provider(self):
        r"""Gets the loadbalancer_provider of this InstanceCreateReqV2.

        负载均衡器类型： - lvs - elb

        :return: The loadbalancer_provider of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._loadbalancer_provider

    @loadbalancer_provider.setter
    def loadbalancer_provider(self, loadbalancer_provider):
        r"""Sets the loadbalancer_provider of this InstanceCreateReqV2.

        负载均衡器类型： - lvs - elb

        :param loadbalancer_provider: The loadbalancer_provider of this InstanceCreateReqV2.
        :type loadbalancer_provider: str
        """
        self._loadbalancer_provider = loadbalancer_provider

    @property
    def tags(self):
        r"""Gets the tags of this InstanceCreateReqV2.

        标签列表。  一个实例默认最多支持创建20个标签

        :return: The tags of this InstanceCreateReqV2.
        :rtype: list[:class:`huaweicloudsdkapig.v2.TmsKeyValue`]
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this InstanceCreateReqV2.

        标签列表。  一个实例默认最多支持创建20个标签

        :param tags: The tags of this InstanceCreateReqV2.
        :type tags: list[:class:`huaweicloudsdkapig.v2.TmsKeyValue`]
        """
        self._tags = tags

    @property
    def vpcep_service_name(self):
        r"""Gets the vpcep_service_name of this InstanceCreateReqV2.

        终端节点服务的名称。  支持英文、数字、中划线、下划线，0~16个字符。  如果您不填写该参数，系统生成的终端节点服务的名称为{region}.apig.{service_id}。 如果您填写该参数，系统生成的终端节点服务的名称为{region}.{vpcep_service_name}.{service_id}。 实例创建完成后，可以在实例管理->终端节点管理页面修改该名称。 

        :return: The vpcep_service_name of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._vpcep_service_name

    @vpcep_service_name.setter
    def vpcep_service_name(self, vpcep_service_name):
        r"""Sets the vpcep_service_name of this InstanceCreateReqV2.

        终端节点服务的名称。  支持英文、数字、中划线、下划线，0~16个字符。  如果您不填写该参数，系统生成的终端节点服务的名称为{region}.apig.{service_id}。 如果您填写该参数，系统生成的终端节点服务的名称为{region}.{vpcep_service_name}.{service_id}。 实例创建完成后，可以在实例管理->终端节点管理页面修改该名称。 

        :param vpcep_service_name: The vpcep_service_name of this InstanceCreateReqV2.
        :type vpcep_service_name: str
        """
        self._vpcep_service_name = vpcep_service_name

    @property
    def ingress_bandwidth_size(self):
        r"""Gets the ingress_bandwidth_size of this InstanceCreateReqV2.

        入口带宽大小

        :return: The ingress_bandwidth_size of this InstanceCreateReqV2.
        :rtype: int
        """
        return self._ingress_bandwidth_size

    @ingress_bandwidth_size.setter
    def ingress_bandwidth_size(self, ingress_bandwidth_size):
        r"""Sets the ingress_bandwidth_size of this InstanceCreateReqV2.

        入口带宽大小

        :param ingress_bandwidth_size: The ingress_bandwidth_size of this InstanceCreateReqV2.
        :type ingress_bandwidth_size: int
        """
        self._ingress_bandwidth_size = ingress_bandwidth_size

    @property
    def ingress_bandwidth_charging_mode(self):
        r"""Gets the ingress_bandwidth_charging_mode of this InstanceCreateReqV2.

        入口带宽收费模式： - bandwidth - traffic

        :return: The ingress_bandwidth_charging_mode of this InstanceCreateReqV2.
        :rtype: str
        """
        return self._ingress_bandwidth_charging_mode

    @ingress_bandwidth_charging_mode.setter
    def ingress_bandwidth_charging_mode(self, ingress_bandwidth_charging_mode):
        r"""Sets the ingress_bandwidth_charging_mode of this InstanceCreateReqV2.

        入口带宽收费模式： - bandwidth - traffic

        :param ingress_bandwidth_charging_mode: The ingress_bandwidth_charging_mode of this InstanceCreateReqV2.
        :type ingress_bandwidth_charging_mode: str
        """
        self._ingress_bandwidth_charging_mode = ingress_bandwidth_charging_mode

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, InstanceCreateReqV2):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
