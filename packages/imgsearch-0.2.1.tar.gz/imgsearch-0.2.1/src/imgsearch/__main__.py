#!/usr/bin/env python3
"""
ImgSearch command line entry point
"""

from .client import main

if __name__ == '__main__':
    main()
