# Script utils

Script utils for speed up developement.
