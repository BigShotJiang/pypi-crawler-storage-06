class ValidationError(Exception):
    pass


class NotFound(Exception):
    pass
