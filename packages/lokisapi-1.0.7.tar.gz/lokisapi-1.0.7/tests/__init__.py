"""
Tests for LokisApi library.
"""
