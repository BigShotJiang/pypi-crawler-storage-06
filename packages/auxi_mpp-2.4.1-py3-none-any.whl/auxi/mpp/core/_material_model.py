from auxi.core.objects import Object


class MaterialModel(Object):
    pass
