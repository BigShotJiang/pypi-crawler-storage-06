"""AIE2E - AI End-to-End Testing Framework"""

__version__ = "0.1.2"
__author__ = "AIE2E Team"
__description__ = "AI-powered end-to-end testing framework"