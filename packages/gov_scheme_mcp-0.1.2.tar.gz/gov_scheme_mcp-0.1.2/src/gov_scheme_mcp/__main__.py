"""Allow running the package as a module: python -m gov_scheme_mcp"""

from .main import main

if __name__ == "__main__":
    main()