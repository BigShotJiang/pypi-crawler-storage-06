# -*- coding: utf-8 -*-
""" Natural Language Inference (NLI) services. """

from orkgnlp.nli.templates import TemplatesRecommender

__all__ = ["TemplatesRecommender"]
