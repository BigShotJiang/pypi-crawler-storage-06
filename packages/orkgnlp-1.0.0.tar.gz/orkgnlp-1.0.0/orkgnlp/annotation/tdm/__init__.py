# -*- coding: utf-8 -*-
""" TDM-Extraction package. """

from orkgnlp.annotation.tdm.extractor import TdmExtractor

__all__ = ["TdmExtractor"]
