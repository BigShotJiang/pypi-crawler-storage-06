# -*- coding: utf-8 -*-
""" Package for the predicates' recommendation service. """
from orkgnlp.clustering.predicates.recommender import PredicatesRecommender

__all__ = ["PredicatesRecommender"]
