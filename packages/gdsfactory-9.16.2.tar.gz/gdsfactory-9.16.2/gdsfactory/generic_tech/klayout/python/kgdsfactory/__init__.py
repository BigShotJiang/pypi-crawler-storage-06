from __future__ import annotations

from kgdsfactory.shortcuts import set_shortcuts  # type: ignore[import-not-found]

__all__ = ("set_shortcuts",)
