# Yuzo

`Yuzo` is an essential helper package for HamzaGSopp projects. It provides a
simple `greet` function and an `init()` helper that sends a test Discord embed.

Quick start:

    pip install -e .
    python -c "from Yuzo import greet; print(greet('World'))"

Run the package init (sends a test embed to configured webhook):

    python main.py
