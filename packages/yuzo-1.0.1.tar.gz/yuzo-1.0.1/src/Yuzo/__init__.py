"""Yuzo

Essential helper package for HamzaGSopp projects.
"""

from .core import init
import logging

__all__ = ["init", "debug"]

# Package-level debug flag. Use `Yuzo.debug(True)` to enable debug prints in runtime.
debug = False


def _set_debug(flag: bool):
	"""Enable or disable package debug logging.

	This sets the module-level `debug` flag and configures the root logger
	to DEBUG level when True, or INFO when False.
	"""
	global debug
	debug = bool(flag)
	if debug:
		logging.basicConfig(level=logging.DEBUG)
		logging.getLogger(__name__).debug("Yuzo debug enabled")
	else:
		logging.getLogger(__name__).debug("Yuzo debug disabled")
		# reset to default INFO level if previously set
		logging.getLogger().setLevel(logging.INFO)


def debug(flag: bool):
	"""Public helper to enable/disable debug logging for the package.

	Example:
		import yuzo as Yuzo
		Yuzo.debug(True)
	"""
	_set_debug(flag)

__author__ = "HamzaGSopp"
__version__ = "1.0.1"
