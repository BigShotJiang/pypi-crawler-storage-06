import importlib


def test_package_exports_init_and_debug():
    # import the package and confirm new API surface
    Yuzo = importlib.import_module("Yuzo")
    assert hasattr(Yuzo, "init")
    assert hasattr(Yuzo, "debug")
    # default debug flag should be falsy
    assert not bool(Yuzo.debug)
