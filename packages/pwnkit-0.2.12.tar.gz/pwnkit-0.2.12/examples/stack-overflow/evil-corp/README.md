Generate a template for this exploit with `pwnkit`:
```
pip install pwnkit
pwnkit xpl.py -f ./evilcorp
```

## Writeup
https://4xura.com/writeups-for-ctfs/htb-writeup-pwn-evil-corp/

# Memos

* Stack overflow
* ret2shellcode
* Unicode injection
* Wide char explosion
