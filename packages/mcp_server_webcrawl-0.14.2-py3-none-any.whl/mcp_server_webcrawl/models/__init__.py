# this is what is acceptable metadata content for crawl results
METADATA_VALUE_TYPE = str | int | float | bool | list[str] | list[int] | list[float] | None
