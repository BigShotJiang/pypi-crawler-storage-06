Agent = str
Link = int
Network = str
