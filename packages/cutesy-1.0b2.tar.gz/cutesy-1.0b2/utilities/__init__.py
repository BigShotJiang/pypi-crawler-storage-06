"""General-purpose utilities for use in this project."""
