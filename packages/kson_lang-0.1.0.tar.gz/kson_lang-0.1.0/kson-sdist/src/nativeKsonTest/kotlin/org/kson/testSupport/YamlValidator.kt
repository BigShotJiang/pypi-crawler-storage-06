package org.kson.testSupport

actual fun validateYaml(yamlString: String) {
    // No-op implementation for Native, we verify our test Yaml in the JVM impl
} 