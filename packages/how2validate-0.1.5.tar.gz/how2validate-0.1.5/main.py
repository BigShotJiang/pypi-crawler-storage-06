from how2validate.validator import main

if __name__ == "__main__":
    main()
