# Ade

Types:

```python
from ade.types import AdeExtractResponse, AdeParseResponse
```

Methods:

- <code title="post /v1/ade/extract">client.ade.<a href="./src/ade/resources/ade.py">extract</a>(\*\*<a href="src/ade/types/ade_extract_params.py">params</a>) -> <a href="./src/ade/types/ade_extract_response.py">AdeExtractResponse</a></code>
- <code title="post /v1/ade/parse">client.ade.<a href="./src/ade/resources/ade.py">parse</a>(\*\*<a href="src/ade/types/ade_parse_params.py">params</a>) -> <a href="./src/ade/types/ade_parse_response.py">AdeParseResponse</a></code>
