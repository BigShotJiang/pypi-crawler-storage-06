The application exposes the `com.facebook.react.devsupport.DevSettingsActivity` activity. The  `DevSettingsActivity` Activity exposes developer settings and should not be exposed in release versions of the application.

