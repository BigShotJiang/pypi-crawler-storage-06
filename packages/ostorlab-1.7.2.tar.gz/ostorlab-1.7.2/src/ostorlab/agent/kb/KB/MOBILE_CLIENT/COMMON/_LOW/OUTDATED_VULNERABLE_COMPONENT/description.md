The application is using an outdated component with publicly known vulnerabilities. Exploitation of this issue varies
from easily accessible off the shelf exploit to requiring custom exploit.