from .hook import AutoDependenciesHook, DiscoveryConfig

__all__ = ["AutoDependenciesHook", "DiscoveryConfig"]
