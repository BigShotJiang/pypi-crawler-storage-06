class ViolatedExpectation(Exception):
    pass
