def main():
    from bugsink.version import version
    print(version)


if __name__ == "__main__":
    main()
