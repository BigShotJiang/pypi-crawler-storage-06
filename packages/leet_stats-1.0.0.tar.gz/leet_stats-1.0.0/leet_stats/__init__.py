"""
LeetCode Stats CLI - A command line tool to view LeetCode statistics and compare with friends.
"""

__version__ = "1.0.0"
__author__ = "Luigi Schmitt"
