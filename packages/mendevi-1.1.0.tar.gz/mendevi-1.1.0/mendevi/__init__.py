#!/usr/bin/env python3

"""Mesures d'Encodage et Décodage Vidéo."""

from .utils import Activity


__all__ = ["Activity"]
__author__ = "Robin RICHARD (robinechuca)"
__version__ = "1.1.0"  # pep 440
