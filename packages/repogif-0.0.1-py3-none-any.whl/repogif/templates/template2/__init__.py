"""
Template 6 for RepoGif - A Square Badge (250x250) showing repository stats
"""