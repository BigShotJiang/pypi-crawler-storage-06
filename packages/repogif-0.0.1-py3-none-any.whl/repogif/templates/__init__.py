"""
Templates package for RepoGif
"""