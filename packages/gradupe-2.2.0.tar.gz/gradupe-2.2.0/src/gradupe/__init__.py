"""Sobel Gradient Image Deduplication"""

__version__ = "2.2.0"
