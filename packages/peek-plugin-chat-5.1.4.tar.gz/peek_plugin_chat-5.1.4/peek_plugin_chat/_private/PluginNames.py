chatPluginName = "peek_plugin_chat"

chatFilt = {"plugin": "peek_plugin_chat"}
chatTuplePrefix = "peek_plugin_chat."
chatObservableName = "peek_plugin_chat"
chatActionProcessorName = "peek_plugin_chat"
