declare module "katex/dist/contrib/auto-render.js";
