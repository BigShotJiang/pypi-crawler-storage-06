var Vc = Object.defineProperty;
var pr = (l) => {
  throw TypeError(l);
};
var jc = (l, e, t) => e in l ? Vc(l, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : l[e] = t;
var te = (l, e, t) => jc(l, typeof e != "symbol" ? e + "" : e, t), Uc = (l, e, t) => e.has(l) || pr("Cannot " + t);
var gr = (l, e, t) => e.has(l) ? pr("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(l) : e.set(l, t);
var Yl = (l, e, t) => (Uc(l, e, "access private method"), t);
const Gc = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], br = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Gc.reduce(
  (l, { color: e, primary: t, secondary: n }) => ({
    ...l,
    [e]: {
      primary: br[e][t],
      secondary: br[e][n]
    }
  }),
  {}
);
class bi extends Error {
  constructor(e) {
    super(e), this.name = "ShareError";
  }
}
async function vr(l, e) {
  var s;
  if (window.__gradio_space__ == null)
    throw new bi("Must be on Spaces to share.");
  let t, n, i;
  {
    let u;
    if (typeof l == "object" && l.url)
      u = l.url;
    else if (typeof l == "string")
      u = l;
    else
      throw new Error("Invalid data format for URL type");
    const c = await fetch(u);
    t = await c.blob(), n = c.headers.get("content-type") || "", i = c.headers.get("content-disposition") || "";
  }
  const a = new File([t], i, { type: n }), r = await fetch("https://huggingface.co/uploads", {
    method: "POST",
    body: a,
    headers: {
      "Content-Type": a.type,
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  if (!r.ok) {
    if ((s = r.headers.get("content-type")) != null && s.includes("application/json")) {
      const u = await r.json();
      throw new bi(`Upload failed: ${u.error}`);
    }
    throw new bi("Upload failed.");
  }
  return await r.text();
}
function Zc(l) {
  l.addEventListener("click", e);
  async function e(t) {
    const n = t.composedPath(), [i] = n.filter(
      (a) => (a == null ? void 0 : a.tagName) === "BUTTON" && a.classList.contains("copy_code_button")
    );
    if (i) {
      let a = function(u) {
        u.style.opacity = "1", setTimeout(() => {
          u.style.opacity = "0";
        }, 2e3);
      };
      t.stopImmediatePropagation();
      const r = i.parentElement.innerText.trim(), o = Array.from(
        i.children
      )[1];
      await Wc(r) && a(o);
    }
  }
  return {
    destroy() {
      l.removeEventListener("click", e);
    }
  };
}
async function Wc(l) {
  let e = !1;
  if ("clipboard" in navigator)
    await navigator.clipboard.writeText(l), e = !0;
  else {
    const t = document.createElement("textarea");
    t.value = l, t.style.position = "absolute", t.style.left = "-999999px", document.body.prepend(t), t.select();
    try {
      document.execCommand("copy"), e = !0;
    } catch (n) {
      console.error(n), e = !1;
    } finally {
      t.remove();
    }
  }
  return e;
}
const I_ = ["user", "terminal", "llm"], Xc = async (l, e = 1800) => {
  let t = [...l], n = await sa(t);
  if (n.length > e && t.length > 2) {
    const i = t[0], a = t[t.length - 1];
    t = [i, a], n = await sa(t);
  }
  return n.length > e && t.length > 0 && (t = t.map((a) => {
    if (a.type === "text") {
      const r = Math.floor(e / t.length) - 20;
      if (a.content.length > r)
        return {
          ...a,
          content: a.content.substring(0, r) + "..."
        };
    }
    return a;
  }), n = await sa(t)), n;
}, sa = async (l) => (await Promise.all(
  l.map(async (t) => {
    var a;
    if (t.role === "system") return "";
    let n = t.role === "user" ? "😃" : "🤖", i = "";
    if (t.type === "text") {
      const r = {
        audio: /<audio.*?src="(\/file=.*?)"/g,
        video: /<video.*?src="(\/file=.*?)"/g,
        image: /<img.*?src="(\/file=.*?)".*?\/>|!\[.*?\]\((\/file=.*?)\)/g
      };
      i = t.content;
      for (let [o, s] of Object.entries(r)) {
        let u;
        for (; (u = s.exec(t.content)) !== null; ) {
          const c = u[1] || u[2], f = await vr(c);
          i = i.replace(c, f);
        }
      }
    } else {
      if (!t.content.value) return "";
      const r = t.content.component === "video" ? (a = t.content.value) == null ? void 0 : a.video.path : t.content.value, o = await vr(r);
      t.content.component === "audio" ? i = `<audio controls src="${o}"></audio>` : t.content.component === "video" ? i = o : t.content.component === "image" && (i = `<img src="${o}" />`);
    }
    return `${n}: ${i}`;
  })
)).filter((t) => t !== "").join(`
`), L_ = (l, e) => l.replace('src="/file', `src="${e}file`);
function Kc(l, e) {
  if (!l) {
    const t = e == null ? void 0 : e.path;
    if (t) {
      const n = t.toLowerCase();
      if (n.endsWith(".glb") || n.endsWith(".gltf") || n.endsWith(".obj") || n.endsWith(".stl") || n.endsWith(".splat") || n.endsWith(".ply"))
        return "model3d";
    }
    return "file";
  }
  return l.includes("audio") ? "audio" : l.includes("video") ? "video" : l.includes("image") ? "image" : l.includes("model") ? "model3d" : "file";
}
function z_(l) {
  const e = Array.isArray(l.file) ? l.file[0] : l.file;
  return {
    component: Kc(e == null ? void 0 : e.mime_type, e),
    value: l.file,
    alt_text: l.alt_text,
    constructor_args: {},
    props: {}
  };
}
function Yc(l, e) {
  if (l === null) return l;
  const t = /* @__PURE__ */ new Map();
  return l.map((n, i) => {
    let a = typeof n.content == "string" ? {
      name: n.name,
      role: n.role,
      metadata: n.metadata,
      content: L_(n.content, e),
      type: "text",
      index: i,
      options: n.options
    } : "file" in n.content ? {
      content: z_(
        n.content
      ),
      metadata: n.metadata,
      name: n.name,
      role: n.role,
      type: "component",
      index: i,
      options: n.options
    } : { type: "component", ...n };
    const { id: r, title: o, parent_id: s } = n.metadata || {};
    if (s) {
      const u = t.get(String(s));
      if (u) {
        const c = { ...a, children: [] };
        return u.children.push(c), r && o && t.set(String(r), c), null;
      }
    }
    if (r && o) {
      const u = { ...a, children: [] };
      return t.set(String(r), u), u;
    }
    return a;
  }).filter((n) => n !== null);
}
function Qc(l, e) {
  return l === null ? l : l.flatMap((n, i) => n.map((a, r) => {
    if (a == null) return null;
    const o = r == 0 ? "user" : "assistant";
    return typeof a == "string" ? {
      role: o,
      type: "text",
      content: L_(a, e),
      metadata: { title: null },
      index: [i, r]
    } : "file" in a ? {
      content: z_(a),
      role: o,
      type: "component",
      index: [i, r]
    } : {
      role: o,
      content: a,
      type: "component",
      index: [i, r]
    };
  })).filter((n) => n != null);
}
function wr(l) {
  return l.type === "component";
}
function Ql(l, e) {
  const t = l[l.length - 1].role === "assistant", n = l[l.length - 1].index;
  return JSON.stringify(n) === JSON.stringify(e[e.length - 1].index) && t;
}
function Jc(l, e, t = !0) {
  const n = [];
  let i = [], a = null;
  for (const r of l)
    if (I_.includes(r.name)) {
      if (!t) {
        n.push([r]);
        continue;
      }
      r.name === a ? i.push(r) : (i.length > 0 && n.push(i), i = [r], a = r.name);
    }
  return i.length > 0 && n.push(i), n;
}
async function xc(l, e, t) {
  let n = [], i = [];
  return l.forEach((o) => {
    if (e[o] || o === "file")
      return;
    const s = o === "dataframe" || o === "model3d" ? "component" : "base", { name: u, component: c } = t(o, s);
    n.push(u), i.push(c);
  }), (await Promise.allSettled(i)).map(
    (o, s) => o.status === "fulfilled" ? [s, o.value] : null
  ).filter((o) => o !== null).forEach(([o, s]) => {
    e[n[o]] = s.default;
  }), e;
}
function ef(l) {
  if (!l) return [];
  let e = /* @__PURE__ */ new Set();
  return l.forEach((t) => {
    t.type === "component" && e.add(t.content.component);
  }), Array.from(e);
}
function bo(l, e = 0) {
  var a, r;
  let t = "";
  const n = "  ".repeat(e);
  (a = l.metadata) != null && a.title && (t += `${n}${e > 0 ? "- " : ""}${l.metadata.title}
`), typeof l.content == "string" && (t += `${n}  ${l.content}
`);
  const i = l;
  return ((r = i.children) == null ? void 0 : r.length) > 0 && (t += i.children.map((o) => bo(o, e + 1)).join("")), t;
}
function tf(l) {
  var e;
  return Array.isArray(l) ? l.map((t) => {
    var n;
    return (n = t.metadata) != null && n.title ? bo(t) : t.content;
  }).join(`
`) : (e = l.metadata) != null && e.title ? bo(l) : l.content;
}
function kr(l) {
  return Array.isArray(l) && l.every((e) => typeof e.content == "string") || !Array.isArray(l) && typeof l.content == "string";
}
const { setContext: qv, getContext: nf } = window.__gradio__svelte__internal, lf = "WORKER_PROXY_CONTEXT_KEY";
function af() {
  return nf(lf);
}
const of = "lite.local";
function rf(l) {
  return l.host === window.location.host || l.host === "localhost:7860" || l.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  l.host === of;
}
function sf(l, e) {
  const t = e.toLowerCase();
  for (const [n, i] of Object.entries(l))
    if (n.toLowerCase() === t)
      return i;
}
function uf(l) {
  const e = typeof window < "u";
  if (l == null || !e)
    return !1;
  const t = new URL(l, window.location.href);
  return !(!rf(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let Jl;
async function _f(l) {
  const e = typeof window < "u";
  if (l == null || !e || !uf(l))
    return l;
  if (Jl == null)
    try {
      Jl = af();
    } catch {
      return l;
    }
  if (Jl == null)
    return l;
  const n = new URL(l, window.location.href).pathname;
  return Jl.httpRequest({
    method: "GET",
    path: n,
    headers: {},
    query_string: ""
  }).then((i) => {
    if (i.status !== 200)
      throw new Error(`Failed to get file ${n} from the Wasm worker.`);
    const a = new Blob([i.body], {
      type: sf(i.headers, "content-type")
    });
    return URL.createObjectURL(a);
  });
}
const {
  SvelteComponent: Tv,
  assign: Iv,
  check_outros: Lv,
  children: zv,
  claim_element: Mv,
  compute_rest_props: Rv,
  create_slot: Nv,
  detach: Ov,
  element: Hv,
  empty: Pv,
  exclude_internal_props: Vv,
  get_all_dirty_from_scope: jv,
  get_slot_changes: Uv,
  get_spread_update: Gv,
  group_outros: Zv,
  init: Wv,
  insert_hydration: Xv,
  listen: Kv,
  prevent_default: Yv,
  safe_not_equal: Qv,
  set_attributes: Jv,
  set_style: xv,
  toggle_class: e2,
  transition_in: t2,
  transition_out: n2,
  update_slot_base: l2
} = window.__gradio__svelte__internal, { createEventDispatcher: i2, onMount: a2 } = window.__gradio__svelte__internal, {
  SvelteComponent: cf,
  assign: vo,
  bubble: ff,
  claim_element: df,
  compute_rest_props: Dr,
  detach: hf,
  element: mf,
  exclude_internal_props: pf,
  get_spread_update: gf,
  init: bf,
  insert_hydration: vf,
  listen: wf,
  noop: yr,
  safe_not_equal: kf,
  set_attributes: Fr,
  src_url_equal: Df,
  toggle_class: Er
} = window.__gradio__svelte__internal;
function yf(l) {
  let e, t, n, i, a = [
    {
      src: t = /*resolved_src*/
      l[0]
    },
    /*$$restProps*/
    l[1]
  ], r = {};
  for (let o = 0; o < a.length; o += 1)
    r = vo(r, a[o]);
  return {
    c() {
      e = mf("img"), this.h();
    },
    l(o) {
      e = df(o, "IMG", { src: !0 }), this.h();
    },
    h() {
      Fr(e, r), Er(e, "svelte-kxeri3", !0);
    },
    m(o, s) {
      vf(o, e, s), n || (i = wf(
        e,
        "load",
        /*load_handler*/
        l[4]
      ), n = !0);
    },
    p(o, [s]) {
      Fr(e, r = gf(a, [
        s & /*resolved_src*/
        1 && !Df(e.src, t = /*resolved_src*/
        o[0]) && { src: t },
        s & /*$$restProps*/
        2 && /*$$restProps*/
        o[1]
      ])), Er(e, "svelte-kxeri3", !0);
    },
    i: yr,
    o: yr,
    d(o) {
      o && hf(e), n = !1, i();
    }
  };
}
function Ff(l, e, t) {
  const n = ["src"];
  let i = Dr(e, n), { src: a = void 0 } = e, r, o;
  function s(u) {
    ff.call(this, l, u);
  }
  return l.$$set = (u) => {
    e = vo(vo({}, e), pf(u)), t(1, i = Dr(e, n)), "src" in u && t(2, a = u.src);
  }, l.$$.update = () => {
    if (l.$$.dirty & /*src, latest_src*/
    12) {
      t(0, r = a), t(3, o = a);
      const u = a;
      _f(u).then((c) => {
        o === u && t(0, r = c);
      });
    }
  }, [r, i, a, o, s];
}
class Hl extends cf {
  constructor(e) {
    super(), bf(this, e, Ff, yf, kf, { src: 2 });
  }
}
const {
  SvelteComponent: Ef,
  append_hydration: wo,
  assign: Cf,
  attr: Le,
  binding_callbacks: Af,
  children: ql,
  claim_element: M_,
  claim_space: R_,
  claim_svg_element: ua,
  create_slot: $f,
  detach: Rt,
  element: N_,
  empty: Cr,
  get_all_dirty_from_scope: Sf,
  get_slot_changes: Bf,
  get_spread_update: qf,
  init: Tf,
  insert_hydration: Ml,
  listen: If,
  noop: Lf,
  safe_not_equal: zf,
  set_dynamic_element_data: Ar,
  set_style: G,
  space: O_,
  svg_element: _a,
  toggle_class: ye,
  transition_in: H_,
  transition_out: P_,
  update_slot_base: Mf
} = window.__gradio__svelte__internal;
function $r(l) {
  let e, t, n, i, a;
  return {
    c() {
      e = _a("svg"), t = _a("line"), n = _a("line"), this.h();
    },
    l(r) {
      e = ua(r, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var o = ql(e);
      t = ua(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), ql(t).forEach(Rt), n = ua(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), ql(n).forEach(Rt), o.forEach(Rt), this.h();
    },
    h() {
      Le(t, "x1", "1"), Le(t, "y1", "9"), Le(t, "x2", "9"), Le(t, "y2", "1"), Le(t, "stroke", "gray"), Le(t, "stroke-width", "0.5"), Le(n, "x1", "5"), Le(n, "y1", "9"), Le(n, "x2", "9"), Le(n, "y2", "5"), Le(n, "stroke", "gray"), Le(n, "stroke-width", "0.5"), Le(e, "class", "resize-handle svelte-239wnu"), Le(e, "xmlns", "http://www.w3.org/2000/svg"), Le(e, "viewBox", "0 0 10 10");
    },
    m(r, o) {
      Ml(r, e, o), wo(e, t), wo(e, n), i || (a = If(
        e,
        "mousedown",
        /*resize*/
        l[27]
      ), i = !0);
    },
    p: Lf,
    d(r) {
      r && Rt(e), i = !1, a();
    }
  };
}
function Rf(l) {
  var f;
  let e, t, n, i, a;
  const r = (
    /*#slots*/
    l[31].default
  ), o = $f(
    r,
    l,
    /*$$scope*/
    l[30],
    null
  );
  let s = (
    /*resizable*/
    l[19] && $r(l)
  ), u = [
    { "data-testid": (
      /*test_id*/
      l[11]
    ) },
    { id: (
      /*elem_id*/
      l[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((f = l[7]) == null ? void 0 : f.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: i = /*rtl*/
      l[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let _ = 0; _ < u.length; _ += 1)
    c = Cf(c, u[_]);
  return {
    c() {
      e = N_(
        /*tag*/
        l[25]
      ), o && o.c(), t = O_(), s && s.c(), this.h();
    },
    l(_) {
      e = M_(
        _,
        /*tag*/
        (l[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var d = ql(e);
      o && o.l(d), t = R_(d), s && s.l(d), d.forEach(Rt), this.h();
    },
    h() {
      Ar(
        /*tag*/
        l[25]
      )(e, c), ye(
        e,
        "hidden",
        /*visible*/
        l[14] === !1
      ), ye(
        e,
        "padded",
        /*padding*/
        l[10]
      ), ye(
        e,
        "flex",
        /*flex*/
        l[1]
      ), ye(
        e,
        "border_focus",
        /*border_mode*/
        l[9] === "focus"
      ), ye(
        e,
        "border_contrast",
        /*border_mode*/
        l[9] === "contrast"
      ), ye(e, "hide-container", !/*explicit_call*/
      l[12] && !/*container*/
      l[13]), ye(
        e,
        "fullscreen",
        /*fullscreen*/
        l[0]
      ), ye(
        e,
        "animating",
        /*fullscreen*/
        l[0] && /*preexpansionBoundingRect*/
        l[24] !== null
      ), ye(
        e,
        "auto-margin",
        /*scale*/
        l[17] === null
      ), G(
        e,
        "height",
        /*fullscreen*/
        l[0] ? void 0 : (
          /*get_dimension*/
          l[26](
            /*height*/
            l[2]
          )
        )
      ), G(
        e,
        "min-height",
        /*fullscreen*/
        l[0] ? void 0 : (
          /*get_dimension*/
          l[26](
            /*min_height*/
            l[3]
          )
        )
      ), G(
        e,
        "max-height",
        /*fullscreen*/
        l[0] ? void 0 : (
          /*get_dimension*/
          l[26](
            /*max_height*/
            l[4]
          )
        )
      ), G(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        l[24] ? `${/*preexpansionBoundingRect*/
        l[24].top}px` : "0px"
      ), G(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        l[24] ? `${/*preexpansionBoundingRect*/
        l[24].left}px` : "0px"
      ), G(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        l[24] ? `${/*preexpansionBoundingRect*/
        l[24].width}px` : "0px"
      ), G(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        l[24] ? `${/*preexpansionBoundingRect*/
        l[24].height}px` : "0px"
      ), G(
        e,
        "width",
        /*fullscreen*/
        l[0] ? void 0 : typeof /*width*/
        l[5] == "number" ? `calc(min(${/*width*/
        l[5]}px, 100%))` : (
          /*get_dimension*/
          l[26](
            /*width*/
            l[5]
          )
        )
      ), G(
        e,
        "border-style",
        /*variant*/
        l[8]
      ), G(
        e,
        "overflow",
        /*allow_overflow*/
        l[15] ? (
          /*overflow_behavior*/
          l[16]
        ) : "hidden"
      ), G(
        e,
        "flex-grow",
        /*scale*/
        l[17]
      ), G(e, "min-width", `calc(min(${/*min_width*/
      l[18]}px, 100%))`), G(e, "border-width", "var(--block-border-width)");
    },
    m(_, d) {
      Ml(_, e, d), o && o.m(e, null), wo(e, t), s && s.m(e, null), l[32](e), a = !0;
    },
    p(_, d) {
      var h;
      o && o.p && (!a || d[0] & /*$$scope*/
      1073741824) && Mf(
        o,
        r,
        _,
        /*$$scope*/
        _[30],
        a ? Bf(
          r,
          /*$$scope*/
          _[30],
          d,
          null
        ) : Sf(
          /*$$scope*/
          _[30]
        ),
        null
      ), /*resizable*/
      _[19] ? s ? s.p(_, d) : (s = $r(_), s.c(), s.m(e, null)) : s && (s.d(1), s = null), Ar(
        /*tag*/
        _[25]
      )(e, c = qf(u, [
        (!a || d[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          _[11]
        ) },
        (!a || d[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          _[6]
        ) },
        (!a || d[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((h = _[7]) == null ? void 0 : h.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!a || d[0] & /*rtl*/
        1048576 && i !== (i = /*rtl*/
        _[20] ? "rtl" : "ltr")) && { dir: i }
      ])), ye(
        e,
        "hidden",
        /*visible*/
        _[14] === !1
      ), ye(
        e,
        "padded",
        /*padding*/
        _[10]
      ), ye(
        e,
        "flex",
        /*flex*/
        _[1]
      ), ye(
        e,
        "border_focus",
        /*border_mode*/
        _[9] === "focus"
      ), ye(
        e,
        "border_contrast",
        /*border_mode*/
        _[9] === "contrast"
      ), ye(e, "hide-container", !/*explicit_call*/
      _[12] && !/*container*/
      _[13]), ye(
        e,
        "fullscreen",
        /*fullscreen*/
        _[0]
      ), ye(
        e,
        "animating",
        /*fullscreen*/
        _[0] && /*preexpansionBoundingRect*/
        _[24] !== null
      ), ye(
        e,
        "auto-margin",
        /*scale*/
        _[17] === null
      ), d[0] & /*fullscreen, height*/
      5 && G(
        e,
        "height",
        /*fullscreen*/
        _[0] ? void 0 : (
          /*get_dimension*/
          _[26](
            /*height*/
            _[2]
          )
        )
      ), d[0] & /*fullscreen, min_height*/
      9 && G(
        e,
        "min-height",
        /*fullscreen*/
        _[0] ? void 0 : (
          /*get_dimension*/
          _[26](
            /*min_height*/
            _[3]
          )
        )
      ), d[0] & /*fullscreen, max_height*/
      17 && G(
        e,
        "max-height",
        /*fullscreen*/
        _[0] ? void 0 : (
          /*get_dimension*/
          _[26](
            /*max_height*/
            _[4]
          )
        )
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        _[24] ? `${/*preexpansionBoundingRect*/
        _[24].top}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        _[24] ? `${/*preexpansionBoundingRect*/
        _[24].left}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        _[24] ? `${/*preexpansionBoundingRect*/
        _[24].width}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && G(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        _[24] ? `${/*preexpansionBoundingRect*/
        _[24].height}px` : "0px"
      ), d[0] & /*fullscreen, width*/
      33 && G(
        e,
        "width",
        /*fullscreen*/
        _[0] ? void 0 : typeof /*width*/
        _[5] == "number" ? `calc(min(${/*width*/
        _[5]}px, 100%))` : (
          /*get_dimension*/
          _[26](
            /*width*/
            _[5]
          )
        )
      ), d[0] & /*variant*/
      256 && G(
        e,
        "border-style",
        /*variant*/
        _[8]
      ), d[0] & /*allow_overflow, overflow_behavior*/
      98304 && G(
        e,
        "overflow",
        /*allow_overflow*/
        _[15] ? (
          /*overflow_behavior*/
          _[16]
        ) : "hidden"
      ), d[0] & /*scale*/
      131072 && G(
        e,
        "flex-grow",
        /*scale*/
        _[17]
      ), d[0] & /*min_width*/
      262144 && G(e, "min-width", `calc(min(${/*min_width*/
      _[18]}px, 100%))`);
    },
    i(_) {
      a || (H_(o, _), a = !0);
    },
    o(_) {
      P_(o, _), a = !1;
    },
    d(_) {
      _ && Rt(e), o && o.d(_), s && s.d(), l[32](null);
    }
  };
}
function Sr(l) {
  let e;
  return {
    c() {
      e = N_("div"), this.h();
    },
    l(t) {
      e = M_(t, "DIV", { class: !0 }), ql(e).forEach(Rt), this.h();
    },
    h() {
      Le(e, "class", "placeholder svelte-239wnu"), G(
        e,
        "height",
        /*placeholder_height*/
        l[22] + "px"
      ), G(
        e,
        "width",
        /*placeholder_width*/
        l[23] + "px"
      );
    },
    m(t, n) {
      Ml(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && G(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && G(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && Rt(e);
    }
  };
}
function Nf(l) {
  let e, t, n, i = (
    /*tag*/
    l[25] && Rf(l)
  ), a = (
    /*fullscreen*/
    l[0] && Sr(l)
  );
  return {
    c() {
      i && i.c(), e = O_(), a && a.c(), t = Cr();
    },
    l(r) {
      i && i.l(r), e = R_(r), a && a.l(r), t = Cr();
    },
    m(r, o) {
      i && i.m(r, o), Ml(r, e, o), a && a.m(r, o), Ml(r, t, o), n = !0;
    },
    p(r, o) {
      /*tag*/
      r[25] && i.p(r, o), /*fullscreen*/
      r[0] ? a ? a.p(r, o) : (a = Sr(r), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    i(r) {
      n || (H_(i, r), n = !0);
    },
    o(r) {
      P_(i, r), n = !1;
    },
    d(r) {
      r && (Rt(e), Rt(t)), i && i.d(r), a && a.d(r);
    }
  };
}
function Of(l, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { height: a = void 0 } = e, { min_height: r = void 0 } = e, { max_height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: f = "solid" } = e, { border_mode: _ = "base" } = e, { padding: d = !0 } = e, { type: h = "normal" } = e, { test_id: p = void 0 } = e, { explicit_call: v = !1 } = e, { container: D = !0 } = e, { visible: w = !0 } = e, { allow_overflow: m = !0 } = e, { overflow_behavior: g = "auto" } = e, { scale: k = null } = e, { min_width: b = 0 } = e, { flex: y = !1 } = e, { resizable: C = !1 } = e, { rtl: F = !1 } = e, { fullscreen: B = !1 } = e, I = B, S, U = h === "fieldset" ? "fieldset" : "div", V = 0, N = 0, T = null;
  function x(q) {
    B && q.key === "Escape" && t(0, B = !1);
  }
  const H = (q) => {
    if (q !== void 0) {
      if (typeof q == "number")
        return q + "px";
      if (typeof q == "string")
        return q;
    }
  }, ee = (q) => {
    let Q = q.clientY;
    const ve = (be) => {
      const _e = be.clientY - Q;
      Q = be.clientY, t(21, S.style.height = `${S.offsetHeight + _e}px`, S);
    }, ue = () => {
      window.removeEventListener("mousemove", ve), window.removeEventListener("mouseup", ue);
    };
    window.addEventListener("mousemove", ve), window.addEventListener("mouseup", ue);
  };
  function he(q) {
    Af[q ? "unshift" : "push"](() => {
      S = q, t(21, S);
    });
  }
  return l.$$set = (q) => {
    "height" in q && t(2, a = q.height), "min_height" in q && t(3, r = q.min_height), "max_height" in q && t(4, o = q.max_height), "width" in q && t(5, s = q.width), "elem_id" in q && t(6, u = q.elem_id), "elem_classes" in q && t(7, c = q.elem_classes), "variant" in q && t(8, f = q.variant), "border_mode" in q && t(9, _ = q.border_mode), "padding" in q && t(10, d = q.padding), "type" in q && t(28, h = q.type), "test_id" in q && t(11, p = q.test_id), "explicit_call" in q && t(12, v = q.explicit_call), "container" in q && t(13, D = q.container), "visible" in q && t(14, w = q.visible), "allow_overflow" in q && t(15, m = q.allow_overflow), "overflow_behavior" in q && t(16, g = q.overflow_behavior), "scale" in q && t(17, k = q.scale), "min_width" in q && t(18, b = q.min_width), "flex" in q && t(1, y = q.flex), "resizable" in q && t(19, C = q.resizable), "rtl" in q && t(20, F = q.rtl), "fullscreen" in q && t(0, B = q.fullscreen), "$$scope" in q && t(30, i = q.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && B !== I && (t(29, I = B), B ? (t(24, T = S.getBoundingClientRect()), t(22, V = S.offsetHeight), t(23, N = S.offsetWidth), window.addEventListener("keydown", x)) : (t(24, T = null), window.removeEventListener("keydown", x))), l.$$.dirty[0] & /*visible*/
    16384 && (w || t(1, y = !1));
  }, [
    B,
    y,
    a,
    r,
    o,
    s,
    u,
    c,
    f,
    _,
    d,
    p,
    v,
    D,
    w,
    m,
    g,
    k,
    b,
    C,
    F,
    S,
    V,
    N,
    T,
    U,
    H,
    ee,
    h,
    I,
    i,
    n,
    he
  ];
}
class Hf extends Ef {
  constructor(e) {
    super(), Tf(
      this,
      e,
      Of,
      Nf,
      zf,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Vo() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let tl = Vo();
function V_(l) {
  tl = l;
}
const j_ = /[&<>"']/, Pf = new RegExp(j_.source, "g"), U_ = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Vf = new RegExp(U_.source, "g"), jf = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Br = (l) => jf[l];
function it(l, e) {
  if (e) {
    if (j_.test(l))
      return l.replace(Pf, Br);
  } else if (U_.test(l))
    return l.replace(Vf, Br);
  return l;
}
const Uf = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Gf(l) {
  return l.replace(Uf, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const Zf = /(^|[^\[])\^/g;
function K(l, e) {
  let t = typeof l == "string" ? l : l.source;
  e = e || "";
  const n = {
    replace: (i, a) => {
      let r = typeof a == "string" ? a : a.source;
      return r = r.replace(Zf, "$1"), t = t.replace(i, r), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function qr(l) {
  try {
    l = encodeURI(l).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return l;
}
const Tl = { exec: () => null };
function Tr(l, e) {
  const t = l.replace(/\|/g, (a, r, o) => {
    let s = !1, u = r;
    for (; --u >= 0 && o[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let i = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; i < n.length; i++)
    n[i] = n[i].trim().replace(/\\\|/g, "|");
  return n;
}
function xl(l, e, t) {
  const n = l.length;
  if (n === 0)
    return "";
  let i = 0;
  for (; i < n && l.charAt(n - i - 1) === e; )
    i++;
  return l.slice(0, n - i);
}
function Wf(l, e) {
  if (l.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < l.length; n++)
    if (l[n] === "\\")
      n++;
    else if (l[n] === e[0])
      t++;
    else if (l[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Ir(l, e, t, n) {
  const i = e.href, a = e.title ? it(e.title) : null, r = l[1].replace(/\\([\[\]])/g, "$1");
  if (l[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: i,
      title: a,
      text: r,
      tokens: n.inlineTokens(r)
    };
    return n.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: i,
    title: a,
    text: it(r)
  };
}
function Xf(l, e) {
  const t = l.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((i) => {
    const a = i.match(/^\s+/);
    if (a === null)
      return i;
    const [r] = a;
    return r.length >= n.length ? i.slice(n.length) : i;
  }).join(`
`);
}
class Ci {
  // set by the lexer
  constructor(e) {
    te(this, "options");
    te(this, "rules");
    // set by the lexer
    te(this, "lexer");
    this.options = e || tl;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : xl(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], i = Xf(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const i = xl(n, "#");
        (this.options.pedantic || !i || / $/.test(i)) && (n = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = xl(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const i = this.lexer.state.top;
      this.lexer.state.top = !0;
      const a = this.lexer.blockTokens(n);
      return this.lexer.state.top = i, {
        type: "blockquote",
        raw: t[0],
        tokens: a,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const i = n.length > 1, a = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = i ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = i ? n : "[*+-]");
      const r = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = r.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let f = t[2].split(`
`, 1)[0].replace(/^\t+/, (D) => " ".repeat(3 * D.length)), _ = e.split(`
`, 1)[0], d = 0;
        this.options.pedantic ? (d = 2, s = f.trimStart()) : (d = t[2].search(/[^ ]/), d = d > 4 ? 1 : d, s = f.slice(d), d += t[1].length);
        let h = !1;
        if (!f && /^ *$/.test(_) && (o += _ + `
`, e = e.substring(_.length + 1), c = !0), !c) {
          const D = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), w = new RegExp(`^ {0,${Math.min(3, d - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), m = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:\`\`\`|~~~)`), g = new RegExp(`^ {0,${Math.min(3, d - 1)}}#`);
          for (; e; ) {
            const k = e.split(`
`, 1)[0];
            if (_ = k, this.options.pedantic && (_ = _.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), m.test(_) || g.test(_) || D.test(_) || w.test(e))
              break;
            if (_.search(/[^ ]/) >= d || !_.trim())
              s += `
` + _.slice(d);
            else {
              if (h || f.search(/[^ ]/) >= 4 || m.test(f) || g.test(f) || w.test(f))
                break;
              s += `
` + _;
            }
            !h && !_.trim() && (h = !0), o += k + `
`, e = e.substring(k.length + 1), f = _.slice(d);
          }
        }
        a.loose || (u ? a.loose = !0 : /\n *\n *$/.test(o) && (u = !0));
        let p = null, v;
        this.options.gfm && (p = /^\[[ xX]\] /.exec(s), p && (v = p[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), a.items.push({
          type: "list_item",
          raw: o,
          task: !!p,
          checked: v,
          loose: !1,
          text: s,
          tokens: []
        }), a.raw += o;
      }
      a.items[a.items.length - 1].raw = o.trimEnd(), a.items[a.items.length - 1].text = s.trimEnd(), a.raw = a.raw.trimEnd();
      for (let c = 0; c < a.items.length; c++)
        if (this.lexer.state.top = !1, a.items[c].tokens = this.lexer.blockTokens(a.items[c].text, []), !a.loose) {
          const f = a.items[c].tokens.filter((d) => d.type === "space"), _ = f.length > 0 && f.some((d) => /\n.*\n/.test(d.raw));
          a.loose = _;
        }
      if (a.loose)
        for (let c = 0; c < a.items.length; c++)
          a.items[c].loose = !0;
      return a;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), i = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: i,
        title: a
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Tr(t[1]), i = t[2].replace(/^\||\| *$/g, "").split("|"), a = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], r = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === i.length) {
      for (const o of i)
        /^ *-+: *$/.test(o) ? r.align.push("right") : /^ *:-+: *$/.test(o) ? r.align.push("center") : /^ *:-+ *$/.test(o) ? r.align.push("left") : r.align.push(null);
      for (const o of n)
        r.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of a)
        r.rows.push(Tr(o, r.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return r;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: it(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const r = xl(n.slice(0, -1), "\\");
        if ((n.length - r.length) % 2 === 0)
          return;
      } else {
        const r = Wf(t[2], "()");
        if (r > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + r;
          t[2] = t[2].substring(0, r), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], a = "";
      if (this.options.pedantic) {
        const r = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(i);
        r && (i = r[1], a = r[3]);
      } else
        a = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), /^</.test(i) && (this.options.pedantic && !/>$/.test(n) ? i = i.slice(1) : i = i.slice(1, -1)), Ir(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: a && a.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const i = (n[2] || n[1]).replace(/\s+/g, " "), a = t[i.toLowerCase()];
      if (!a) {
        const r = n[0].charAt(0);
        return {
          type: "text",
          raw: r,
          text: r
        };
      }
      return Ir(n, a, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(i[1] || i[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const r = [...i[0]].length - 1;
      let o, s, u = r, c = 0;
      const f = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (f.lastIndex = 0, t = t.slice(-1 * e.length + r); (i = f.exec(t)) != null; ) {
        if (o = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !o)
          continue;
        if (s = [...o].length, i[3] || i[4]) {
          u += s;
          continue;
        } else if ((i[5] || i[6]) && r % 3 && !((r + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const _ = [...i[0]][0].length, d = e.slice(0, r + i.index + _ + s);
        if (Math.min(r, s) % 2) {
          const p = d.slice(1, -1);
          return {
            type: "em",
            raw: d,
            text: p,
            tokens: this.lexer.inlineTokens(p)
          };
        }
        const h = d.slice(2, -2);
        return {
          type: "strong",
          raw: d,
          text: h,
          tokens: this.lexer.inlineTokens(h)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const i = /[^ ]/.test(n), a = /^ /.test(n) && / $/.test(n);
      return i && a && (n = n.substring(1, n.length - 1)), n = it(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, i;
      return t[2] === "@" ? (n = it(t[1]), i = "mailto:" + n) : (n = it(t[1]), i = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, a;
      if (t[2] === "@")
        i = it(t[0]), a = "mailto:" + i;
      else {
        let r;
        do
          r = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (r !== t[0]);
        i = it(t[0]), t[1] === "www." ? a = "http://" + t[0] : a = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: a,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = it(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Kf = /^(?: *(?:\n|$))+/, Yf = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Qf = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Pl = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Jf = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, G_ = /(?:[*+-]|\d{1,9}[.)])/, Z_ = K(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, G_).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), jo = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, xf = /^[^\n]+/, Uo = /(?!\s*\])(?:\\.|[^\[\]\\])+/, ed = K(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Uo).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), td = K(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, G_).getRegex(), Zi = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Go = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, nd = K("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Go).replace("tag", Zi).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), W_ = K(jo).replace("hr", Pl).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Zi).getRegex(), ld = K(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", W_).getRegex(), Zo = {
  blockquote: ld,
  code: Yf,
  def: ed,
  fences: Qf,
  heading: Jf,
  hr: Pl,
  html: nd,
  lheading: Z_,
  list: td,
  newline: Kf,
  paragraph: W_,
  table: Tl,
  text: xf
}, Lr = K("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Pl).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Zi).getRegex(), id = {
  ...Zo,
  table: Lr,
  paragraph: K(jo).replace("hr", Pl).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Lr).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Zi).getRegex()
}, ad = {
  ...Zo,
  html: K(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Go).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Tl,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: K(jo).replace("hr", Pl).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Z_).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, X_ = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, od = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, K_ = /^( {2,}|\\)\n(?!\s*$)/, rd = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Vl = "\\p{P}\\p{S}", sd = K(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Vl).getRegex(), ud = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, _d = K(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Vl).getRegex(), cd = K("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Vl).getRegex(), fd = K("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Vl).getRegex(), dd = K(/\\([punct])/, "gu").replace(/punct/g, Vl).getRegex(), hd = K(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), md = K(Go).replace("(?:-->|$)", "-->").getRegex(), pd = K("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", md).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Ai = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, gd = K(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Ai).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Y_ = K(/^!?\[(label)\]\[(ref)\]/).replace("label", Ai).replace("ref", Uo).getRegex(), Q_ = K(/^!?\[(ref)\](?:\[\])?/).replace("ref", Uo).getRegex(), bd = K("reflink|nolink(?!\\()", "g").replace("reflink", Y_).replace("nolink", Q_).getRegex(), Wo = {
  _backpedal: Tl,
  // only used for GFM url
  anyPunctuation: dd,
  autolink: hd,
  blockSkip: ud,
  br: K_,
  code: od,
  del: Tl,
  emStrongLDelim: _d,
  emStrongRDelimAst: cd,
  emStrongRDelimUnd: fd,
  escape: X_,
  link: gd,
  nolink: Q_,
  punctuation: sd,
  reflink: Y_,
  reflinkSearch: bd,
  tag: pd,
  text: rd,
  url: Tl
}, vd = {
  ...Wo,
  link: K(/^!?\[(label)\]\((.*?)\)/).replace("label", Ai).getRegex(),
  reflink: K(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Ai).getRegex()
}, ko = {
  ...Wo,
  escape: K(X_).replace("])", "~|])").getRegex(),
  url: K(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, wd = {
  ...ko,
  br: K(K_).replace("{2,}", "*").getRegex(),
  text: K(ko.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, ei = {
  normal: Zo,
  gfm: id,
  pedantic: ad
}, yl = {
  normal: Wo,
  gfm: ko,
  breaks: wd,
  pedantic: vd
};
class Nt {
  constructor(e) {
    te(this, "tokens");
    te(this, "options");
    te(this, "state");
    te(this, "tokenizer");
    te(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || tl, this.options.tokenizer = this.options.tokenizer || new Ci(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: ei.normal,
      inline: yl.normal
    };
    this.options.pedantic ? (t.block = ei.pedantic, t.inline = yl.pedantic) : this.options.gfm && (t.block = ei.gfm, this.options.breaks ? t.inline = yl.breaks : t.inline = yl.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: ei,
      inline: yl
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Nt(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Nt(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, s, u) => s + "    ".repeat(u.length));
    let n, i, a, r;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (n = o.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && (i.type === "paragraph" || i.type === "text") ? (i.raw += `
` + n.raw, i.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (o = Math.min(o, u));
          }), o < 1 / 0 && o >= 0 && (a = e.substring(0, o + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(a))) {
          i = t[t.length - 1], r && i.type === "paragraph" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n), r = a.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && i.type === "text" ? (i.raw += `
` + n.raw, i.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = i.text) : t.push(n);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, i, a, r = e, o, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(r)) != null; )
          c.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (r = r.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + r.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(r)) != null; )
      r = r.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + r.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(r)) != null; )
      r = r.slice(0, o.index) + "++" + r.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), i = t[t.length - 1], i && n.type === "text" && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, r, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const f = e.slice(1);
          let _;
          this.options.extensions.startInline.forEach((d) => {
            _ = d.call({ lexer: this }, f), typeof _ == "number" && _ >= 0 && (c = Math.min(c, _));
          }), c < 1 / 0 && c >= 0 && (a = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(a)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, i = t[t.length - 1], i && i.type === "text" ? (i.raw += n.raw, i.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class $i {
  constructor(e) {
    te(this, "options");
    this.options = e || tl;
  }
  code(e, t, n) {
    var a;
    const i = (a = (t || "").match(/^\S*/)) == null ? void 0 : a[0];
    return e = e.replace(/\n$/, "") + `
`, i ? '<pre><code class="language-' + it(i) + '">' + (n ? e : it(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : it(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const i = t ? "ol" : "ul", a = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + i + a + `>
` + e + "</" + i + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const i = qr(e);
    if (i === null)
      return n;
    e = i;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + t + '"'), a += ">" + n + "</a>", a;
  }
  image(e, t, n) {
    const i = qr(e);
    if (i === null)
      return n;
    e = i;
    let a = `<img src="${e}" alt="${n}"`;
    return t && (a += ` title="${t}"`), a += ">", a;
  }
  text(e) {
    return e;
  }
}
class Xo {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Ot {
  constructor(e) {
    te(this, "options");
    te(this, "renderer");
    te(this, "textRenderer");
    this.options = e || tl, this.options.renderer = this.options.renderer || new $i(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Xo();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Ot(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Ot(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const r = a, o = this.options.extensions.renderers[r.type].call({ parser: this }, r);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(r.type)) {
          n += o || "";
          continue;
        }
      }
      switch (a.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const r = a;
          n += this.renderer.heading(this.parseInline(r.tokens), r.depth, Gf(this.parseInline(r.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const r = a;
          n += this.renderer.code(r.text, r.lang, !!r.escaped);
          continue;
        }
        case "table": {
          const r = a;
          let o = "", s = "";
          for (let c = 0; c < r.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(r.header[c].tokens), { header: !0, align: r.align[c] });
          o += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < r.rows.length; c++) {
            const f = r.rows[c];
            s = "";
            for (let _ = 0; _ < f.length; _++)
              s += this.renderer.tablecell(this.parseInline(f[_].tokens), { header: !1, align: r.align[_] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(o, u);
          continue;
        }
        case "blockquote": {
          const r = a, o = this.parse(r.tokens);
          n += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const r = a, o = r.ordered, s = r.start, u = r.loose;
          let c = "";
          for (let f = 0; f < r.items.length; f++) {
            const _ = r.items[f], d = _.checked, h = _.task;
            let p = "";
            if (_.task) {
              const v = this.renderer.checkbox(!!d);
              u ? _.tokens.length > 0 && _.tokens[0].type === "paragraph" ? (_.tokens[0].text = v + " " + _.tokens[0].text, _.tokens[0].tokens && _.tokens[0].tokens.length > 0 && _.tokens[0].tokens[0].type === "text" && (_.tokens[0].tokens[0].text = v + " " + _.tokens[0].tokens[0].text)) : _.tokens.unshift({
                type: "text",
                text: v + " "
              }) : p += v + " ";
            }
            p += this.parse(_.tokens, u), c += this.renderer.listitem(p, h, !!d);
          }
          n += this.renderer.list(c, o, s);
          continue;
        }
        case "html": {
          const r = a;
          n += this.renderer.html(r.text, r.block);
          continue;
        }
        case "paragraph": {
          const r = a;
          n += this.renderer.paragraph(this.parseInline(r.tokens));
          continue;
        }
        case "text": {
          let r = a, o = r.tokens ? this.parseInline(r.tokens) : r.text;
          for (; i + 1 < e.length && e[i + 1].type === "text"; )
            r = e[++i], o += `
` + (r.tokens ? this.parseInline(r.tokens) : r.text);
          n += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const r = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(r), "";
          throw new Error(r);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let i = 0; i < e.length; i++) {
      const a = e[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const r = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (r !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          n += r || "";
          continue;
        }
      }
      switch (a.type) {
        case "escape": {
          const r = a;
          n += t.text(r.text);
          break;
        }
        case "html": {
          const r = a;
          n += t.html(r.text);
          break;
        }
        case "link": {
          const r = a;
          n += t.link(r.href, r.title, this.parseInline(r.tokens, t));
          break;
        }
        case "image": {
          const r = a;
          n += t.image(r.href, r.title, r.text);
          break;
        }
        case "strong": {
          const r = a;
          n += t.strong(this.parseInline(r.tokens, t));
          break;
        }
        case "em": {
          const r = a;
          n += t.em(this.parseInline(r.tokens, t));
          break;
        }
        case "codespan": {
          const r = a;
          n += t.codespan(r.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const r = a;
          n += t.del(this.parseInline(r.tokens, t));
          break;
        }
        case "text": {
          const r = a;
          n += t.text(r.text);
          break;
        }
        default: {
          const r = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(r), "";
          throw new Error(r);
        }
      }
    }
    return n;
  }
}
class Il {
  constructor(e) {
    te(this, "options");
    this.options = e || tl;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
te(Il, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var el, Do, x_;
class J_ {
  constructor(...e) {
    gr(this, el);
    te(this, "defaults", Vo());
    te(this, "options", this.setOptions);
    te(this, "parse", Yl(this, el, Do).call(this, Nt.lex, Ot.parse));
    te(this, "parseInline", Yl(this, el, Do).call(this, Nt.lexInline, Ot.parseInline));
    te(this, "Parser", Ot);
    te(this, "Renderer", $i);
    te(this, "TextRenderer", Xo);
    te(this, "Lexer", Nt);
    te(this, "Tokenizer", Ci);
    te(this, "Hooks", Il);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, a;
    let n = [];
    for (const r of e)
      switch (n = n.concat(t.call(this, r)), r.type) {
        case "table": {
          const o = r;
          for (const s of o.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const o = r;
          n = n.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = r;
          (a = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && a[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const u = o[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : o.tokens && (n = n.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const i = { ...n };
      if (i.async = this.defaults.async || i.async || !1, n.extensions && (n.extensions.forEach((a) => {
        if (!a.name)
          throw new Error("extension name required");
        if ("renderer" in a) {
          const r = t.renderers[a.name];
          r ? t.renderers[a.name] = function(...o) {
            let s = a.renderer.apply(this, o);
            return s === !1 && (s = r.apply(this, o)), s;
          } : t.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const r = t[a.level];
          r ? r.unshift(a.tokenizer) : t[a.level] = [a.tokenizer], a.start && (a.level === "block" ? t.startBlock ? t.startBlock.push(a.start) : t.startBlock = [a.start] : a.level === "inline" && (t.startInline ? t.startInline.push(a.start) : t.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (t.childTokens[a.name] = a.childTokens);
      }), i.extensions = t), n.renderer) {
        const a = this.defaults.renderer || new $i(this.defaults);
        for (const r in n.renderer) {
          if (!(r in a))
            throw new Error(`renderer '${r}' does not exist`);
          if (r === "options")
            continue;
          const o = r, s = n.renderer[o], u = a[o];
          a[o] = (...c) => {
            let f = s.apply(a, c);
            return f === !1 && (f = u.apply(a, c)), f || "";
          };
        }
        i.renderer = a;
      }
      if (n.tokenizer) {
        const a = this.defaults.tokenizer || new Ci(this.defaults);
        for (const r in n.tokenizer) {
          if (!(r in a))
            throw new Error(`tokenizer '${r}' does not exist`);
          if (["options", "rules", "lexer"].includes(r))
            continue;
          const o = r, s = n.tokenizer[o], u = a[o];
          a[o] = (...c) => {
            let f = s.apply(a, c);
            return f === !1 && (f = u.apply(a, c)), f;
          };
        }
        i.tokenizer = a;
      }
      if (n.hooks) {
        const a = this.defaults.hooks || new Il();
        for (const r in n.hooks) {
          if (!(r in a))
            throw new Error(`hook '${r}' does not exist`);
          if (r === "options")
            continue;
          const o = r, s = n.hooks[o], u = a[o];
          Il.passThroughHooks.has(r) ? a[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(a, c)).then((_) => u.call(a, _));
            const f = s.call(a, c);
            return u.call(a, f);
          } : a[o] = (...c) => {
            let f = s.apply(a, c);
            return f === !1 && (f = u.apply(a, c)), f;
          };
        }
        i.hooks = a;
      }
      if (n.walkTokens) {
        const a = this.defaults.walkTokens, r = n.walkTokens;
        i.walkTokens = function(o) {
          let s = [];
          return s.push(r.call(this, o)), a && (s = s.concat(a.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Nt.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Ot.parse(e, t ?? this.defaults);
  }
}
el = new WeakSet(), Do = function(e, t) {
  return (n, i) => {
    const a = { ...i }, r = { ...this.defaults, ...a };
    this.defaults.async === !0 && a.async === !1 && (r.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), r.async = !0);
    const o = Yl(this, el, x_).call(this, !!r.silent, !!r.async);
    if (typeof n > "u" || n === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (r.hooks && (r.hooks.options = r), r.async)
      return Promise.resolve(r.hooks ? r.hooks.preprocess(n) : n).then((s) => e(s, r)).then((s) => r.hooks ? r.hooks.processAllTokens(s) : s).then((s) => r.walkTokens ? Promise.all(this.walkTokens(s, r.walkTokens)).then(() => s) : s).then((s) => t(s, r)).then((s) => r.hooks ? r.hooks.postprocess(s) : s).catch(o);
    try {
      r.hooks && (n = r.hooks.preprocess(n));
      let s = e(n, r);
      r.hooks && (s = r.hooks.processAllTokens(s)), r.walkTokens && this.walkTokens(s, r.walkTokens);
      let u = t(s, r);
      return r.hooks && (u = r.hooks.postprocess(u)), u;
    } catch (s) {
      return o(s);
    }
  };
}, x_ = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const i = "<p>An error occurred:</p><pre>" + it(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(i) : i;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Kn = new J_();
function X(l, e) {
  return Kn.parse(l, e);
}
X.options = X.setOptions = function(l) {
  return Kn.setOptions(l), X.defaults = Kn.defaults, V_(X.defaults), X;
};
X.getDefaults = Vo;
X.defaults = tl;
X.use = function(...l) {
  return Kn.use(...l), X.defaults = Kn.defaults, V_(X.defaults), X;
};
X.walkTokens = function(l, e) {
  return Kn.walkTokens(l, e);
};
X.parseInline = Kn.parseInline;
X.Parser = Ot;
X.parser = Ot.parse;
X.Renderer = $i;
X.TextRenderer = Xo;
X.Lexer = Nt;
X.lexer = Nt.lex;
X.Tokenizer = Ci;
X.Hooks = Il;
X.parse = X;
X.options;
X.setOptions;
X.use;
X.walkTokens;
X.parseInline;
Ot.parse;
Nt.lex;
function kd(l) {
  if (typeof l == "function" && (l = {
    highlight: l
  }), !l || typeof l.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof l.langPrefix != "string" && (l.langPrefix = "language-"), typeof l.emptyLangClass != "string" && (l.emptyLangClass = ""), {
    async: !!l.async,
    walkTokens(e) {
      if (e.type !== "code")
        return;
      const t = zr(e.lang);
      if (l.async)
        return Promise.resolve(l.highlight(e.text, t, e.lang || "")).then(Mr(e));
      const n = l.highlight(e.text, t, e.lang || "");
      if (n instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      Mr(e)(n);
    },
    useNewRenderer: !0,
    renderer: {
      code(e, t, n) {
        typeof e == "object" && (n = e.escaped, t = e.lang, e = e.text);
        const i = zr(t), a = i ? l.langPrefix + Nr(i) : l.emptyLangClass, r = a ? ` class="${a}"` : "";
        return e = e.replace(/\n$/, ""), `<pre><code${r}>${n ? e : Nr(e, !0)}
</code></pre>`;
      }
    }
  };
}
function zr(l) {
  return (l || "").match(/\S*/)[0];
}
function Mr(l) {
  return (e) => {
    typeof e == "string" && e !== l.text && (l.escaped = !0, l.text = e);
  };
}
const ec = /[&<>"']/, Dd = new RegExp(ec.source, "g"), tc = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, yd = new RegExp(tc.source, "g"), Fd = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Rr = (l) => Fd[l];
function Nr(l, e) {
  if (e) {
    if (ec.test(l))
      return l.replace(Dd, Rr);
  } else if (tc.test(l))
    return l.replace(yd, Rr);
  return l;
}
const Ed = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Cd = Object.hasOwnProperty;
class Ko {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let i = Ad(e, t === !0);
    const a = i;
    for (; Cd.call(n.occurrences, i); )
      n.occurrences[a]++, i = a + "-" + n.occurrences[a];
    return n.occurrences[i] = 0, i;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Ad(l, e) {
  return typeof l != "string" ? "" : (e || (l = l.toLowerCase()), l.replace(Ed, "").replace(/ /g, "-"));
}
let nc = new Ko(), lc = [];
function $d({ prefix: l = "", globalSlugs: e = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(t) {
        return e || Sd(), t;
      }
    },
    renderer: {
      heading(t, n, i) {
        i = i.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const a = `${l}${nc.slug(i)}`, r = { level: n, text: t, id: a };
        return lc.push(r), `<h${n} id="${a}">${t}</h${n}>
`;
      }
    }
  };
}
function Sd() {
  lc = [], nc = new Ko();
}
var Or = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function o2(l) {
  return l && l.__esModule && Object.prototype.hasOwnProperty.call(l, "default") ? l.default : l;
}
var ic = { exports: {} };
(function(l) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var i = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, a = 0, r = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function w(m) {
          return m instanceof s ? new s(m.type, w(m.content), m.alias) : Array.isArray(m) ? m.map(w) : m.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(w) {
          return Object.prototype.toString.call(w).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(w) {
          return w.__id || Object.defineProperty(w, "__id", { value: ++a }), w.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function w(m, g) {
          g = g || {};
          var k, b;
          switch (o.util.type(m)) {
            case "Object":
              if (b = o.util.objId(m), g[b])
                return g[b];
              k = /** @type {Record<string, any>} */
              {}, g[b] = k;
              for (var y in m)
                m.hasOwnProperty(y) && (k[y] = w(m[y], g));
              return (
                /** @type {any} */
                k
              );
            case "Array":
              return b = o.util.objId(m), g[b] ? g[b] : (k = [], g[b] = k, /** @type {Array} */
              /** @type {any} */
              m.forEach(function(C, F) {
                k[F] = w(C, g);
              }), /** @type {any} */
              k);
            default:
              return m;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(w) {
          for (; w; ) {
            var m = i.exec(w.className);
            if (m)
              return m[1].toLowerCase();
            w = w.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(w, m) {
          w.className = w.className.replace(RegExp(i, "gi"), ""), w.classList.add("language-" + m);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (k) {
            var w = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(k.stack) || [])[1];
            if (w) {
              var m = document.getElementsByTagName("script");
              for (var g in m)
                if (m[g].src == w)
                  return m[g];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(w, m, g) {
          for (var k = "no-" + m; w; ) {
            var b = w.classList;
            if (b.contains(m))
              return !0;
            if (b.contains(k))
              return !1;
            w = w.parentElement;
          }
          return !!g;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: r,
        plaintext: r,
        text: r,
        txt: r,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(w, m) {
          var g = o.util.clone(o.languages[w]);
          for (var k in m)
            g[k] = m[k];
          return g;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(w, m, g, k) {
          k = k || /** @type {any} */
          o.languages;
          var b = k[w], y = {};
          for (var C in b)
            if (b.hasOwnProperty(C)) {
              if (C == m)
                for (var F in g)
                  g.hasOwnProperty(F) && (y[F] = g[F]);
              g.hasOwnProperty(C) || (y[C] = b[C]);
            }
          var B = k[w];
          return k[w] = y, o.languages.DFS(o.languages, function(I, S) {
            S === B && I != w && (this[I] = y);
          }), y;
        },
        // Traverse a language definition with Depth First Search
        DFS: function w(m, g, k, b) {
          b = b || {};
          var y = o.util.objId;
          for (var C in m)
            if (m.hasOwnProperty(C)) {
              g.call(m, C, m[C], k || C);
              var F = m[C], B = o.util.type(F);
              B === "Object" && !b[y(F)] ? (b[y(F)] = !0, w(F, g, null, b)) : B === "Array" && !b[y(F)] && (b[y(F)] = !0, w(F, g, C, b));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(w, m) {
        o.highlightAllUnder(document, w, m);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(w, m, g) {
        var k = {
          callback: g,
          container: w,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", k), k.elements = Array.prototype.slice.apply(k.container.querySelectorAll(k.selector)), o.hooks.run("before-all-elements-highlight", k);
        for (var b = 0, y; y = k.elements[b++]; )
          o.highlightElement(y, m === !0, k.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(w, m, g) {
        var k = o.util.getLanguage(w), b = o.languages[k];
        o.util.setLanguage(w, k);
        var y = w.parentElement;
        y && y.nodeName.toLowerCase() === "pre" && o.util.setLanguage(y, k);
        var C = w.textContent, F = {
          element: w,
          language: k,
          grammar: b,
          code: C
        };
        function B(S) {
          F.highlightedCode = S, o.hooks.run("before-insert", F), F.element.innerHTML = F.highlightedCode, o.hooks.run("after-highlight", F), o.hooks.run("complete", F), g && g.call(F.element);
        }
        if (o.hooks.run("before-sanity-check", F), y = F.element.parentElement, y && y.nodeName.toLowerCase() === "pre" && !y.hasAttribute("tabindex") && y.setAttribute("tabindex", "0"), !F.code) {
          o.hooks.run("complete", F), g && g.call(F.element);
          return;
        }
        if (o.hooks.run("before-highlight", F), !F.grammar) {
          B(o.util.encode(F.code));
          return;
        }
        if (m && n.Worker) {
          var I = new Worker(o.filename);
          I.onmessage = function(S) {
            B(S.data);
          }, I.postMessage(JSON.stringify({
            language: F.language,
            code: F.code,
            immediateClose: !0
          }));
        } else
          B(o.highlight(F.code, F.grammar, F.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(w, m, g) {
        var k = {
          code: w,
          grammar: m,
          language: g
        };
        if (o.hooks.run("before-tokenize", k), !k.grammar)
          throw new Error('The language "' + k.language + '" has no grammar.');
        return k.tokens = o.tokenize(k.code, k.grammar), o.hooks.run("after-tokenize", k), s.stringify(o.util.encode(k.tokens), k.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(w, m) {
        var g = m.rest;
        if (g) {
          for (var k in g)
            m[k] = g[k];
          delete m.rest;
        }
        var b = new f();
        return _(b, b.head, w), c(w, b, m, b.head, 0), h(b);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(w, m) {
          var g = o.hooks.all;
          g[w] = g[w] || [], g[w].push(m);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(w, m) {
          var g = o.hooks.all[w];
          if (!(!g || !g.length))
            for (var k = 0, b; b = g[k++]; )
              b(m);
        }
      },
      Token: s
    };
    n.Prism = o;
    function s(w, m, g, k) {
      this.type = w, this.content = m, this.alias = g, this.length = (k || "").length | 0;
    }
    s.stringify = function w(m, g) {
      if (typeof m == "string")
        return m;
      if (Array.isArray(m)) {
        var k = "";
        return m.forEach(function(B) {
          k += w(B, g);
        }), k;
      }
      var b = {
        type: m.type,
        content: w(m.content, g),
        tag: "span",
        classes: ["token", m.type],
        attributes: {},
        language: g
      }, y = m.alias;
      y && (Array.isArray(y) ? Array.prototype.push.apply(b.classes, y) : b.classes.push(y)), o.hooks.run("wrap", b);
      var C = "";
      for (var F in b.attributes)
        C += " " + F + '="' + (b.attributes[F] || "").replace(/"/g, "&quot;") + '"';
      return "<" + b.tag + ' class="' + b.classes.join(" ") + '"' + C + ">" + b.content + "</" + b.tag + ">";
    };
    function u(w, m, g, k) {
      w.lastIndex = m;
      var b = w.exec(g);
      if (b && k && b[1]) {
        var y = b[1].length;
        b.index += y, b[0] = b[0].slice(y);
      }
      return b;
    }
    function c(w, m, g, k, b, y) {
      for (var C in g)
        if (!(!g.hasOwnProperty(C) || !g[C])) {
          var F = g[C];
          F = Array.isArray(F) ? F : [F];
          for (var B = 0; B < F.length; ++B) {
            if (y && y.cause == C + "," + B)
              return;
            var I = F[B], S = I.inside, U = !!I.lookbehind, V = !!I.greedy, N = I.alias;
            if (V && !I.pattern.global) {
              var T = I.pattern.toString().match(/[imsuy]*$/)[0];
              I.pattern = RegExp(I.pattern.source, T + "g");
            }
            for (var x = I.pattern || I, H = k.next, ee = b; H !== m.tail && !(y && ee >= y.reach); ee += H.value.length, H = H.next) {
              var he = H.value;
              if (m.length > w.length)
                return;
              if (!(he instanceof s)) {
                var q = 1, Q;
                if (V) {
                  if (Q = u(x, ee, w, U), !Q || Q.index >= w.length)
                    break;
                  var _e = Q.index, ve = Q.index + Q[0].length, ue = ee;
                  for (ue += H.value.length; _e >= ue; )
                    H = H.next, ue += H.value.length;
                  if (ue -= H.value.length, ee = ue, H.value instanceof s)
                    continue;
                  for (var be = H; be !== m.tail && (ue < ve || typeof be.value == "string"); be = be.next)
                    q++, ue += be.value.length;
                  q--, he = w.slice(ee, ue), Q.index -= ee;
                } else if (Q = u(x, 0, he, U), !Q)
                  continue;
                var _e = Q.index, Be = Q[0], L = he.slice(0, _e), ut = he.slice(_e + Be.length), Je = ee + he.length;
                y && Je > y.reach && (y.reach = Je);
                var qe = H.prev;
                L && (qe = _(m, qe, L), ee += L.length), d(m, qe, q);
                var ce = new s(C, S ? o.tokenize(Be, S) : Be, N, Be);
                if (H = _(m, qe, ce), ut && _(m, H, ut), q > 1) {
                  var _t = {
                    cause: C + "," + B,
                    reach: Je
                  };
                  c(w, m, g, H.prev, ee, _t), y && _t.reach > y.reach && (y.reach = _t.reach);
                }
              }
            }
          }
        }
    }
    function f() {
      var w = { value: null, prev: null, next: null }, m = { value: null, prev: w, next: null };
      w.next = m, this.head = w, this.tail = m, this.length = 0;
    }
    function _(w, m, g) {
      var k = m.next, b = { value: g, prev: m, next: k };
      return m.next = b, k.prev = b, w.length++, b;
    }
    function d(w, m, g) {
      for (var k = m.next, b = 0; b < g && k !== w.tail; b++)
        k = k.next;
      m.next = k, k.prev = m, w.length -= b;
    }
    function h(w) {
      for (var m = [], g = w.head.next; g !== w.tail; )
        m.push(g.value), g = g.next;
      return m;
    }
    if (!n.document)
      return n.addEventListener && (o.disableWorkerMessageHandler || n.addEventListener("message", function(w) {
        var m = JSON.parse(w.data), g = m.language, k = m.code, b = m.immediateClose;
        n.postMessage(o.highlight(k, o.languages[g], g)), b && n.close();
      }, !1)), o;
    var p = o.util.currentScript();
    p && (o.filename = p.src, p.hasAttribute("data-manual") && (o.manual = !0));
    function v() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var D = document.readyState;
      D === "loading" || D === "interactive" && p && p.defer ? document.addEventListener("DOMContentLoaded", v) : window.requestAnimationFrame ? window.requestAnimationFrame(v) : window.setTimeout(v, 16);
    }
    return o;
  }(e);
  l.exports && (l.exports = t), typeof Or < "u" && (Or.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(i, a) {
      var r = {};
      r["language-" + a] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[a]
      }, r.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: r
        }
      };
      o["language-" + a] = {
        pattern: /[\s\S]+/,
        inside: t.languages[a]
      };
      var s = {};
      s[i] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return i;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, i) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [i, "language-" + i],
                inside: t.languages[i]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var i = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + i.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + i.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + i.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + i.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: i,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var a = n.languages.markup;
    a && (a.tag.addInlined("style", "css"), a.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", i = function(p, v) {
      return "✖ Error " + p + " while fetching file: " + v;
    }, a = "✖ Error: File does not exist or is empty", r = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", s = "loading", u = "loaded", c = "failed", f = "pre[data-src]:not([" + o + '="' + u + '"]):not([' + o + '="' + s + '"])';
    function _(p, v, D) {
      var w = new XMLHttpRequest();
      w.open("GET", p, !0), w.onreadystatechange = function() {
        w.readyState == 4 && (w.status < 400 && w.responseText ? v(w.responseText) : w.status >= 400 ? D(i(w.status, w.statusText)) : D(a));
      }, w.send(null);
    }
    function d(p) {
      var v = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(p || "");
      if (v) {
        var D = Number(v[1]), w = v[2], m = v[3];
        return w ? m ? [D, Number(m)] : [D, void 0] : [D, D];
      }
    }
    t.hooks.add("before-highlightall", function(p) {
      p.selector += ", " + f;
    }), t.hooks.add("before-sanity-check", function(p) {
      var v = (
        /** @type {HTMLPreElement} */
        p.element
      );
      if (v.matches(f)) {
        p.code = "", v.setAttribute(o, s);
        var D = v.appendChild(document.createElement("CODE"));
        D.textContent = n;
        var w = v.getAttribute("data-src"), m = p.language;
        if (m === "none") {
          var g = (/\.(\w+)$/.exec(w) || [, "none"])[1];
          m = r[g] || g;
        }
        t.util.setLanguage(D, m), t.util.setLanguage(v, m);
        var k = t.plugins.autoloader;
        k && k.loadLanguages(m), _(
          w,
          function(b) {
            v.setAttribute(o, u);
            var y = d(v.getAttribute("data-range"));
            if (y) {
              var C = b.split(/\r\n?|\n/g), F = y[0], B = y[1] == null ? C.length : y[1];
              F < 0 && (F += C.length), F = Math.max(0, Math.min(F - 1, C.length)), B < 0 && (B += C.length), B = Math.max(0, Math.min(B, C.length)), b = C.slice(F, B).join(`
`), v.hasAttribute("data-start") || v.setAttribute("data-start", String(F + 1));
            }
            D.textContent = b, t.highlightElement(D);
          },
          function(b) {
            v.setAttribute(o, c), D.textContent = b;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(v) {
        for (var D = (v || document).querySelectorAll(f), w = 0, m; m = D[w++]; )
          t.highlightElement(m);
      }
    };
    var h = !1;
    t.fileHighlight = function() {
      h || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), h = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(ic);
var ca = ic.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(l) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  l.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, l.languages.tex = l.languages.latex, l.languages.context = l.languages.latex;
})(Prism);
(function(l) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  l.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = l.languages.bash;
  for (var i = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], a = n.variable[1].inside, r = 0; r < i.length; r++)
    a[i[r]] = l.languages.bash[i[r]];
  l.languages.sh = l.languages.bash, l.languages.shell = l.languages.bash;
})(Prism);
const Bd = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', qd = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, Td = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, Hr = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${qd}</span>
  <span class="check">${Td}</span>
</button>`, ac = /[&<>"']/, Id = new RegExp(ac.source, "g"), oc = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Ld = new RegExp(oc.source, "g"), zd = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Pr = (l) => zd[l] || "";
function fa(l, e) {
  if (e) {
    if (ac.test(l))
      return l.replace(Id, Pr);
  } else if (oc.test(l))
    return l.replace(Ld, Pr);
  return l;
}
function Md(l) {
  const e = l.map((t) => ({
    start: new RegExp(t.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(t.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(t) {
      for (const n of e) {
        const i = t.match(n.start);
        if (i)
          return i.index;
      }
      return -1;
    },
    tokenizer(t, n) {
      for (const i of e) {
        const a = new RegExp(
          `${i.start.source}([\\s\\S]+?)${i.end.source}`
        ).exec(t);
        if (a)
          return {
            type: "latex",
            raw: a[0],
            text: a[1].trim()
          };
      }
    },
    renderer(t) {
      return `<div class="latex-block">${t.text}</div>`;
    }
  };
}
function Rd() {
  return {
    name: "mermaid",
    level: "block",
    start(l) {
      var e;
      return (e = l.match(/^```mermaid\s*\n/)) == null ? void 0 : e.index;
    },
    tokenizer(l) {
      const e = /^```mermaid\s*\n([\s\S]*?)```\s*(?:\n|$)/.exec(l);
      if (e)
        return {
          type: "mermaid",
          raw: e[0],
          text: e[1].trim()
        };
    },
    renderer(l) {
      return `<div class="mermaid">${l.text}</div>
`;
    }
  };
}
const Nd = {
  code(l, e, t) {
    var i;
    const n = ((i = (e ?? "").match(/\S*/)) == null ? void 0 : i[0]) ?? "";
    return l = l.replace(/\n$/, "") + `
`, !n || n === "mermaid" ? '<div class="code_wrap">' + Hr + "<pre><code>" + (t ? l : fa(l, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + Hr + '<pre><code class="language-' + fa(n) + '">' + (t ? l : fa(l, !0)) + `</code></pre></div>
`;
  }
}, Od = new Ko();
function Hd({
  header_links: l,
  line_breaks: e,
  latex_delimiters: t
}) {
  const n = new J_();
  n.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: e
    },
    kd({
      highlight: (r, o) => {
        var s;
        return (s = ca.languages) != null && s[o] ? ca.highlight(r, ca.languages[o], o) : r;
      }
    }),
    { renderer: Nd }
  ), l && (n.use($d()), n.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(r) {
          const o = r.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), s = "h" + Od.slug(o), u = r.depth, c = this.parser.parseInline(r.tokens);
          return `<h${u} id="${s}"><a class="md-header-anchor" href="#${s}">${Bd}</a>${c}</h${u}>
`;
        }
      }
    ]
  }));
  const i = Rd(), a = Md(t);
  return n.use({
    extensions: [i, a]
  }), n;
}
const yo = (l) => JSON.parse(JSON.stringify(l)), Pd = (l) => l.nodeType === 1, Vd = (l) => uh.has(l.tagName), jd = (l) => "action" in l, Ud = (l) => l.tagName === "IFRAME", Gd = (l) => "formAction" in l, Zd = (l) => "protocol" in l, ti = /* @__PURE__ */ (() => {
  const l = /^(?:\w+script|data):/i;
  return (e) => l.test(e);
})(), Wd = /* @__PURE__ */ (() => {
  const l = /(?:script|data):/i;
  return (e) => l.test(e);
})(), Xd = (l) => {
  const e = {};
  for (let t = 0, n = l.length; t < n; t++) {
    const i = l[t];
    for (const a in i)
      e[a] ? e[a] = e[a].concat(i[a]) : e[a] = i[a];
  }
  return e;
}, rc = (l, e) => {
  let t = l.firstChild;
  for (; t; ) {
    const n = t.nextSibling;
    Pd(t) && (e(t, l), t.parentNode && rc(t, e)), t = n;
  }
}, Kd = (l, e) => {
  const t = document.createNodeIterator(l, NodeFilter.SHOW_ELEMENT);
  let n;
  for (; n = t.nextNode(); ) {
    const i = n.parentNode;
    i && e(n, i);
  }
}, Yd = (l, e) => !!globalThis.document && !!globalThis.document.createNodeIterator ? Kd(l, e) : rc(l, e), sc = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Qd = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], Jd = /* @__PURE__ */ new Set([
  ...sc,
  ...Qd
]), uc = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], xd = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], eh = /* @__PURE__ */ new Set([
  ...uc,
  ...xd
]), _c = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], th = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], nh = /* @__PURE__ */ new Set([
  ..._c,
  ...th
]), lh = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], ih = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], ah = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], $t = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, oh = {
  [$t.HTML]: Jd,
  [$t.SVG]: eh,
  [$t.MATH]: nh
}, rh = {
  [$t.HTML]: "html",
  [$t.SVG]: "svg",
  [$t.MATH]: "math"
}, sh = {
  [$t.HTML]: "",
  [$t.SVG]: "svg:",
  [$t.MATH]: "math:"
}, uh = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), cc = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...sc,
    ...uc.map((l) => `svg:${l}`),
    ..._c.map((l) => `math:${l}`)
  ],
  allowAttributes: Xd([
    Object.fromEntries(lh.map((l) => [l, ["*"]])),
    Object.fromEntries(ih.map((l) => [l, ["svg:*"]])),
    Object.fromEntries(ah.map((l) => [l, ["math:*"]]))
  ])
};
var da = function(l, e, t, n, i) {
  if (n === "m") throw new TypeError("Private method is not writable");
  if (n === "a" && !i) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? l !== e || !i : !e.has(l)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? i.call(l, t) : i ? i.value = t : e.set(l, t), t;
}, qn = function(l, e, t, n) {
  if (t === "a" && !n) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? l !== e || !n : !e.has(l)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? n : t === "a" ? n.call(l) : n ? n.value : e.get(l);
}, cn, vi, wi;
class fc {
  /* CONSTRUCTOR */
  constructor(e = {}) {
    cn.set(this, void 0), vi.set(this, void 0), wi.set(this, void 0), this.getConfiguration = () => yo(qn(this, cn, "f")), this.sanitize = (c) => {
      const f = qn(this, vi, "f"), _ = qn(this, wi, "f");
      return Yd(c, (d, h) => {
        const p = d.namespaceURI || $t.HTML, v = h.namespaceURI || $t.HTML, D = oh[p], w = rh[p], m = sh[p], g = d.tagName.toLowerCase(), k = `${m}${g}`, y = `${m}*`;
        if (!D.has(g) || !f.has(k) || p !== v && g !== w)
          h.removeChild(d);
        else {
          const C = d.getAttributeNames(), F = C.length;
          if (F) {
            for (let B = 0; B < F; B++) {
              const I = C[B], S = _[I];
              (!S || !S.has(y) && !S.has(k)) && d.removeAttribute(I);
            }
            if (Vd(d))
              if (Zd(d)) {
                const B = d.getAttribute("href");
                B && Wd(B) && ti(d.protocol) && d.removeAttribute("href");
              } else jd(d) ? ti(d.action) && d.removeAttribute("action") : Gd(d) ? ti(d.formAction) && d.removeAttribute("formaction") : Ud(d) && (ti(d.src) && d.removeAttribute("formaction"), d.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), c;
    }, this.sanitizeFor = (c, f) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: t, allowCustomElements: n, allowUnknownMarkup: i, blockElements: a, dropElements: r, dropAttributes: o } = e;
    if (t === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (n)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (i)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (a)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (r)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (o)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    da(this, cn, yo(cc), "f");
    const { allowElements: s, allowAttributes: u } = e;
    s && (qn(this, cn, "f").allowElements = e.allowElements), u && (qn(this, cn, "f").allowAttributes = e.allowAttributes), da(this, vi, new Set(qn(this, cn, "f").allowElements), "f"), da(this, wi, Object.fromEntries(Object.entries(qn(this, cn, "f").allowAttributes || {}).map(([c, f]) => [c, new Set(f)])), "f");
  }
}
cn = /* @__PURE__ */ new WeakMap(), vi = /* @__PURE__ */ new WeakMap(), wi = /* @__PURE__ */ new WeakMap();
fc.getDefaultConfiguration = () => yo(cc);
const _h = (l, e = location.href) => {
  try {
    return !!l && new URL(l).origin !== new URL(e).origin;
  } catch {
    return !1;
  }
};
function Vr(l) {
  const e = new fc(), t = new DOMParser().parseFromString(l, "text/html");
  return dc(t.body, "A", (n) => {
    n instanceof HTMLElement && "target" in n && _h(n.getAttribute("href"), location.href) && (n.setAttribute("target", "_blank"), n.setAttribute("rel", "noopener noreferrer"));
  }), e.sanitize(t).body.innerHTML;
}
function dc(l, e, t) {
  l && (l.nodeName === e || typeof e == "function") && t(l);
  const n = (l == null ? void 0 : l.childNodes) || [];
  for (let i = 0; i < n.length; i++)
    dc(n[i], e, t);
}
const jr = [
  "!--",
  "!doctype",
  "a",
  "abbr",
  "acronym",
  "address",
  "applet",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "basefont",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "meta",
  "meter",
  "nav",
  "noframes",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "search",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], ch = [
  // Base structural elements
  "g",
  "defs",
  "use",
  "symbol",
  // Shape elements
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "path",
  "image",
  // Text elements
  "text",
  "tspan",
  "textPath",
  // Gradient and effects
  "linearGradient",
  "radialGradient",
  "stop",
  "pattern",
  "clipPath",
  "mask",
  "filter",
  // Filter effects
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feGaussianBlur",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTurbulence",
  "feMergeNode",
  "feFuncR",
  "feFuncG",
  "feFuncB",
  "feFuncA",
  "feDistantLight",
  "fePointLight",
  "feSpotLight",
  "feFlood",
  "feTile",
  // Animation elements
  "animate",
  "animateTransform",
  "animateMotion",
  "mpath",
  "set",
  // Interactive and other elements
  "view",
  "cursor",
  "foreignObject",
  "desc",
  "title",
  "metadata",
  "switch"
], fh = [
  ...jr,
  ...ch.filter((l) => !jr.includes(l))
], {
  HtmlTagHydration: dh,
  SvelteComponent: hh,
  attr: mh,
  binding_callbacks: ph,
  children: gh,
  claim_element: bh,
  claim_html_tag: vh,
  detach: Ur,
  element: wh,
  init: kh,
  insert_hydration: Dh,
  noop: Gr,
  safe_not_equal: yh,
  toggle_class: ni
} = window.__gradio__svelte__internal, { afterUpdate: Fh, tick: Eh, onMount: r2 } = window.__gradio__svelte__internal;
function Ch(l) {
  let e, t;
  return {
    c() {
      e = wh("span"), t = new dh(!1), this.h();
    },
    l(n) {
      e = bh(n, "SPAN", { class: !0 });
      var i = gh(e);
      t = vh(i, !1), i.forEach(Ur), this.h();
    },
    h() {
      t.a = null, mh(e, "class", "md svelte-1m32c2s"), ni(
        e,
        "chatbot",
        /*chatbot*/
        l[0]
      ), ni(
        e,
        "prose",
        /*render_markdown*/
        l[1]
      );
    },
    m(n, i) {
      Dh(n, e, i), t.m(
        /*html*/
        l[3],
        e
      ), l[11](e);
    },
    p(n, [i]) {
      i & /*html*/
      8 && t.p(
        /*html*/
        n[3]
      ), i & /*chatbot*/
      1 && ni(
        e,
        "chatbot",
        /*chatbot*/
        n[0]
      ), i & /*render_markdown*/
      2 && ni(
        e,
        "prose",
        /*render_markdown*/
        n[1]
      );
    },
    i: Gr,
    o: Gr,
    d(n) {
      n && Ur(e), l[11](null);
    }
  };
}
function Zr(l) {
  return l.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Ah(l, e, t) {
  var n = this && this.__awaiter || function(b, y, C, F) {
    function B(I) {
      return I instanceof C ? I : new C(function(S) {
        S(I);
      });
    }
    return new (C || (C = Promise))(function(I, S) {
      function U(T) {
        try {
          N(F.next(T));
        } catch (x) {
          S(x);
        }
      }
      function V(T) {
        try {
          N(F.throw(T));
        } catch (x) {
          S(x);
        }
      }
      function N(T) {
        T.done ? I(T.value) : B(T.value).then(U, V);
      }
      N((F = F.apply(b, y || [])).next());
    });
  };
  let { chatbot: i = !0 } = e, { message: a } = e, { sanitize_html: r = !0 } = e, { latex_delimiters: o = [] } = e, { render_markdown: s = !0 } = e, { line_breaks: u = !0 } = e, { header_links: c = !1 } = e, { allow_tags: f = !1 } = e, { theme_mode: _ = "system" } = e, d, h, p = !1;
  const v = Hd({
    header_links: c,
    line_breaks: u,
    latex_delimiters: o || []
  });
  function D(b) {
    return !o || o.length === 0 ? !1 : o.some((y) => b.includes(y.left) && b.includes(y.right));
  }
  function w(b, y) {
    if (y === !0) {
      const C = /<\/?([a-zA-Z][a-zA-Z0-9-]*)([\s>])/g;
      return b.replace(C, (F, B, I) => fh.includes(B.toLowerCase()) ? F : F.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    if (Array.isArray(y)) {
      const C = y.map((B) => ({
        open: new RegExp(`<(${B})(\\s+[^>]*)?>`, "gi"),
        close: new RegExp(`</(${B})>`, "gi")
      }));
      let F = b;
      return C.forEach((B) => {
        F = F.replace(B.open, (I) => I.replace(/</g, "&lt;").replace(/>/g, "&gt;")), F = F.replace(B.close, (I) => I.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      }), F;
    }
    return b;
  }
  function m(b) {
    let y = b;
    if (s) {
      const C = [];
      o.forEach((F, B) => {
        const I = Zr(F.left), S = Zr(F.right), U = new RegExp(`${I}([\\s\\S]+?)${S}`, "g");
        y = y.replace(U, (V, N) => (C.push(V), `%%%LATEX_BLOCK_${C.length - 1}%%%`));
      }), y = v.parse(y), y = y.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, (F, B) => C[parseInt(B, 10)]);
    }
    return f && (y = w(y, f)), r && Vr && (y = Vr(y)), y;
  }
  function g(b) {
    return n(this, void 0, void 0, function* () {
      if (o.length > 0 && b && D(b))
        if (!p)
          yield Promise.all([
            Promise.resolve({              }),
            import("./auto-render-BwaQGe8P.js")
          ]).then(([, { default: y }]) => {
            p = !0, y(d, {
              delimiters: o,
              throwOnError: !1
            });
          });
        else {
          const { default: y } = yield import("./auto-render-BwaQGe8P.js");
          y(d, {
            delimiters: o,
            throwOnError: !1
          });
        }
      if (d) {
        const y = d.querySelectorAll(".mermaid");
        if (y.length > 0) {
          yield Eh();
          const { default: C } = yield import("./mermaid.core-B_TMhUWp.js").then((F) => F.bC);
          C.initialize({
            startOnLoad: !1,
            theme: _ === "dark" ? "dark" : "default",
            securityLevel: "antiscript"
          }), yield C.run({
            nodes: Array.from(y).map((F) => F)
          });
        }
      }
    });
  }
  Fh(() => n(void 0, void 0, void 0, function* () {
    d && document.body.contains(d) ? yield g(a) : console.error("Element is not in the DOM");
  }));
  function k(b) {
    ph[b ? "unshift" : "push"](() => {
      d = b, t(2, d);
    });
  }
  return l.$$set = (b) => {
    "chatbot" in b && t(0, i = b.chatbot), "message" in b && t(4, a = b.message), "sanitize_html" in b && t(5, r = b.sanitize_html), "latex_delimiters" in b && t(6, o = b.latex_delimiters), "render_markdown" in b && t(1, s = b.render_markdown), "line_breaks" in b && t(7, u = b.line_breaks), "header_links" in b && t(8, c = b.header_links), "allow_tags" in b && t(9, f = b.allow_tags), "theme_mode" in b && t(10, _ = b.theme_mode);
  }, l.$$.update = () => {
    l.$$.dirty & /*message*/
    16 && (a && a.trim() ? t(3, h = m(a)) : t(3, h = ""));
  }, [
    i,
    s,
    d,
    h,
    a,
    r,
    o,
    u,
    c,
    f,
    _,
    k
  ];
}
class Yo extends hh {
  constructor(e) {
    super(), kh(this, e, Ah, Ch, yh, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      allow_tags: 9,
      theme_mode: 10
    });
  }
}
const {
  SvelteComponent: s2,
  attr: u2,
  children: _2,
  claim_component: c2,
  claim_element: f2,
  create_component: d2,
  destroy_component: h2,
  detach: m2,
  element: p2,
  init: g2,
  insert_hydration: b2,
  mount_component: v2,
  safe_not_equal: w2,
  transition_in: k2,
  transition_out: D2
} = window.__gradio__svelte__internal, {
  SvelteComponent: y2,
  attr: F2,
  check_outros: E2,
  children: C2,
  claim_component: A2,
  claim_element: $2,
  claim_space: S2,
  create_component: B2,
  create_slot: q2,
  destroy_component: T2,
  detach: I2,
  element: L2,
  empty: z2,
  get_all_dirty_from_scope: M2,
  get_slot_changes: R2,
  group_outros: N2,
  init: O2,
  insert_hydration: H2,
  mount_component: P2,
  safe_not_equal: V2,
  space: j2,
  toggle_class: U2,
  transition_in: G2,
  transition_out: Z2,
  update_slot_base: W2
} = window.__gradio__svelte__internal, {
  SvelteComponent: $h,
  append_hydration: ha,
  attr: ll,
  children: Wr,
  claim_component: Sh,
  claim_element: Xr,
  claim_space: Bh,
  claim_text: qh,
  create_component: Th,
  destroy_component: Ih,
  detach: ma,
  element: Kr,
  init: Lh,
  insert_hydration: zh,
  mount_component: Mh,
  safe_not_equal: Rh,
  set_data: Nh,
  space: Oh,
  text: Hh,
  toggle_class: an,
  transition_in: Ph,
  transition_out: Vh
} = window.__gradio__svelte__internal;
function jh(l) {
  let e, t, n, i, a, r, o;
  return n = new /*Icon*/
  l[1]({}), {
    c() {
      e = Kr("label"), t = Kr("span"), Th(n.$$.fragment), i = Oh(), a = Hh(
        /*label*/
        l[0]
      ), this.h();
    },
    l(s) {
      e = Xr(s, "LABEL", {
        for: !0,
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var u = Wr(e);
      t = Xr(u, "SPAN", { class: !0 });
      var c = Wr(t);
      Sh(n.$$.fragment, c), c.forEach(ma), i = Bh(u), a = qh(
        u,
        /*label*/
        l[0]
      ), u.forEach(ma), this.h();
    },
    h() {
      ll(t, "class", "svelte-13ao5pu"), ll(e, "for", ""), ll(e, "data-testid", "block-label"), ll(e, "dir", r = /*rtl*/
      l[5] ? "rtl" : "ltr"), ll(e, "class", "svelte-13ao5pu"), an(e, "hide", !/*show_label*/
      l[2]), an(e, "sr-only", !/*show_label*/
      l[2]), an(
        e,
        "float",
        /*float*/
        l[4]
      ), an(
        e,
        "hide-label",
        /*disable*/
        l[3]
      );
    },
    m(s, u) {
      zh(s, e, u), ha(e, t), Mh(n, t, null), ha(e, i), ha(e, a), o = !0;
    },
    p(s, [u]) {
      (!o || u & /*label*/
      1) && Nh(
        a,
        /*label*/
        s[0]
      ), (!o || u & /*rtl*/
      32 && r !== (r = /*rtl*/
      s[5] ? "rtl" : "ltr")) && ll(e, "dir", r), (!o || u & /*show_label*/
      4) && an(e, "hide", !/*show_label*/
      s[2]), (!o || u & /*show_label*/
      4) && an(e, "sr-only", !/*show_label*/
      s[2]), (!o || u & /*float*/
      16) && an(
        e,
        "float",
        /*float*/
        s[4]
      ), (!o || u & /*disable*/
      8) && an(
        e,
        "hide-label",
        /*disable*/
        s[3]
      );
    },
    i(s) {
      o || (Ph(n.$$.fragment, s), o = !0);
    },
    o(s) {
      Vh(n.$$.fragment, s), o = !1;
    },
    d(s) {
      s && ma(e), Ih(n);
    }
  };
}
function Uh(l, e, t) {
  let { label: n = null } = e, { Icon: i } = e, { show_label: a = !0 } = e, { disable: r = !1 } = e, { float: o = !0 } = e, { rtl: s = !1 } = e;
  return l.$$set = (u) => {
    "label" in u && t(0, n = u.label), "Icon" in u && t(1, i = u.Icon), "show_label" in u && t(2, a = u.show_label), "disable" in u && t(3, r = u.disable), "float" in u && t(4, o = u.float), "rtl" in u && t(5, s = u.rtl);
  }, [n, i, a, r, o, s];
}
class Gh extends $h {
  constructor(e) {
    super(), Lh(this, e, Uh, jh, Rh, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4,
      rtl: 5
    });
  }
}
const {
  SvelteComponent: Zh,
  append_hydration: ki,
  attr: Ut,
  bubble: Wh,
  check_outros: Xh,
  children: Fo,
  claim_component: Kh,
  claim_element: Eo,
  claim_space: Yr,
  claim_text: Yh,
  construct_svelte_component: Qr,
  create_component: Jr,
  create_slot: Qh,
  destroy_component: xr,
  detach: Ll,
  element: Co,
  get_all_dirty_from_scope: Jh,
  get_slot_changes: xh,
  group_outros: em,
  init: tm,
  insert_hydration: hc,
  listen: nm,
  mount_component: es,
  safe_not_equal: lm,
  set_data: im,
  set_style: il,
  space: ts,
  text: am,
  toggle_class: Ie,
  transition_in: pa,
  transition_out: ga,
  update_slot_base: om
} = window.__gradio__svelte__internal;
function ns(l) {
  let e, t;
  return {
    c() {
      e = Co("span"), t = am(
        /*label*/
        l[1]
      ), this.h();
    },
    l(n) {
      e = Eo(n, "SPAN", { class: !0 });
      var i = Fo(e);
      t = Yh(
        i,
        /*label*/
        l[1]
      ), i.forEach(Ll), this.h();
    },
    h() {
      Ut(e, "class", "svelte-y0enk4");
    },
    m(n, i) {
      hc(n, e, i), ki(e, t);
    },
    p(n, i) {
      i & /*label*/
      2 && im(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Ll(e);
    }
  };
}
function rm(l) {
  let e, t, n, i, a, r, o, s, u = (
    /*show_label*/
    l[2] && ns(l)
  );
  var c = (
    /*Icon*/
    l[0]
  );
  function f(h, p) {
    return {};
  }
  c && (i = Qr(c, f()));
  const _ = (
    /*#slots*/
    l[15].default
  ), d = Qh(
    _,
    l,
    /*$$scope*/
    l[14],
    null
  );
  return {
    c() {
      e = Co("button"), u && u.c(), t = ts(), n = Co("div"), i && Jr(i.$$.fragment), a = ts(), d && d.c(), this.h();
    },
    l(h) {
      e = Eo(h, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var p = Fo(e);
      u && u.l(p), t = Yr(p), n = Eo(p, "DIV", { class: !0 });
      var v = Fo(n);
      i && Kh(i.$$.fragment, v), a = Yr(v), d && d.l(v), v.forEach(Ll), p.forEach(Ll), this.h();
    },
    h() {
      Ut(n, "class", "svelte-y0enk4"), Ie(
        n,
        "x-small",
        /*size*/
        l[4] === "x-small"
      ), Ie(
        n,
        "small",
        /*size*/
        l[4] === "small"
      ), Ie(
        n,
        "large",
        /*size*/
        l[4] === "large"
      ), Ie(
        n,
        "medium",
        /*size*/
        l[4] === "medium"
      ), e.disabled = /*disabled*/
      l[7], Ut(
        e,
        "aria-label",
        /*label*/
        l[1]
      ), Ut(
        e,
        "aria-haspopup",
        /*hasPopup*/
        l[8]
      ), Ut(
        e,
        "title",
        /*label*/
        l[1]
      ), Ut(e, "class", "svelte-y0enk4"), Ie(
        e,
        "pending",
        /*pending*/
        l[3]
      ), Ie(
        e,
        "padded",
        /*padded*/
        l[5]
      ), Ie(
        e,
        "highlight",
        /*highlight*/
        l[6]
      ), Ie(
        e,
        "transparent",
        /*transparent*/
        l[9]
      ), il(
        e,
        "--border-color",
        /*border*/
        l[11]
      ), il(e, "color", !/*disabled*/
      l[7] && /*_color*/
      l[12] ? (
        /*_color*/
        l[12]
      ) : "var(--block-label-text-color)"), il(e, "--bg-color", /*disabled*/
      l[7] ? "auto" : (
        /*background*/
        l[10]
      ));
    },
    m(h, p) {
      hc(h, e, p), u && u.m(e, null), ki(e, t), ki(e, n), i && es(i, n, null), ki(n, a), d && d.m(n, null), r = !0, o || (s = nm(
        e,
        "click",
        /*click_handler*/
        l[16]
      ), o = !0);
    },
    p(h, [p]) {
      if (/*show_label*/
      h[2] ? u ? u.p(h, p) : (u = ns(h), u.c(), u.m(e, t)) : u && (u.d(1), u = null), p & /*Icon*/
      1 && c !== (c = /*Icon*/
      h[0])) {
        if (i) {
          em();
          const v = i;
          ga(v.$$.fragment, 1, 0, () => {
            xr(v, 1);
          }), Xh();
        }
        c ? (i = Qr(c, f()), Jr(i.$$.fragment), pa(i.$$.fragment, 1), es(i, n, a)) : i = null;
      }
      d && d.p && (!r || p & /*$$scope*/
      16384) && om(
        d,
        _,
        h,
        /*$$scope*/
        h[14],
        r ? xh(
          _,
          /*$$scope*/
          h[14],
          p,
          null
        ) : Jh(
          /*$$scope*/
          h[14]
        ),
        null
      ), (!r || p & /*size*/
      16) && Ie(
        n,
        "x-small",
        /*size*/
        h[4] === "x-small"
      ), (!r || p & /*size*/
      16) && Ie(
        n,
        "small",
        /*size*/
        h[4] === "small"
      ), (!r || p & /*size*/
      16) && Ie(
        n,
        "large",
        /*size*/
        h[4] === "large"
      ), (!r || p & /*size*/
      16) && Ie(
        n,
        "medium",
        /*size*/
        h[4] === "medium"
      ), (!r || p & /*disabled*/
      128) && (e.disabled = /*disabled*/
      h[7]), (!r || p & /*label*/
      2) && Ut(
        e,
        "aria-label",
        /*label*/
        h[1]
      ), (!r || p & /*hasPopup*/
      256) && Ut(
        e,
        "aria-haspopup",
        /*hasPopup*/
        h[8]
      ), (!r || p & /*label*/
      2) && Ut(
        e,
        "title",
        /*label*/
        h[1]
      ), (!r || p & /*pending*/
      8) && Ie(
        e,
        "pending",
        /*pending*/
        h[3]
      ), (!r || p & /*padded*/
      32) && Ie(
        e,
        "padded",
        /*padded*/
        h[5]
      ), (!r || p & /*highlight*/
      64) && Ie(
        e,
        "highlight",
        /*highlight*/
        h[6]
      ), (!r || p & /*transparent*/
      512) && Ie(
        e,
        "transparent",
        /*transparent*/
        h[9]
      ), p & /*border*/
      2048 && il(
        e,
        "--border-color",
        /*border*/
        h[11]
      ), p & /*disabled, _color*/
      4224 && il(e, "color", !/*disabled*/
      h[7] && /*_color*/
      h[12] ? (
        /*_color*/
        h[12]
      ) : "var(--block-label-text-color)"), p & /*disabled, background*/
      1152 && il(e, "--bg-color", /*disabled*/
      h[7] ? "auto" : (
        /*background*/
        h[10]
      ));
    },
    i(h) {
      r || (i && pa(i.$$.fragment, h), pa(d, h), r = !0);
    },
    o(h) {
      i && ga(i.$$.fragment, h), ga(d, h), r = !1;
    },
    d(h) {
      h && Ll(e), u && u.d(), i && xr(i), d && d.d(h), o = !1, s();
    }
  };
}
function sm(l, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e, { Icon: r } = e, { label: o = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: f = !0 } = e, { highlight: _ = !1 } = e, { disabled: d = !1 } = e, { hasPopup: h = !1 } = e, { color: p = "var(--block-label-text-color)" } = e, { transparent: v = !1 } = e, { background: D = "var(--block-background-fill)" } = e, { border: w = "transparent" } = e;
  function m(g) {
    Wh.call(this, l, g);
  }
  return l.$$set = (g) => {
    "Icon" in g && t(0, r = g.Icon), "label" in g && t(1, o = g.label), "show_label" in g && t(2, s = g.show_label), "pending" in g && t(3, u = g.pending), "size" in g && t(4, c = g.size), "padded" in g && t(5, f = g.padded), "highlight" in g && t(6, _ = g.highlight), "disabled" in g && t(7, d = g.disabled), "hasPopup" in g && t(8, h = g.hasPopup), "color" in g && t(13, p = g.color), "transparent" in g && t(9, v = g.transparent), "background" in g && t(10, D = g.background), "border" in g && t(11, w = g.border), "$$scope" in g && t(14, a = g.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty & /*highlight, color*/
    8256 && t(12, n = _ ? "var(--color-accent)" : p);
  }, [
    r,
    o,
    s,
    u,
    c,
    f,
    _,
    d,
    h,
    v,
    D,
    w,
    n,
    p,
    a,
    i,
    m
  ];
}
class Re extends Zh {
  constructor(e) {
    super(), tm(this, e, sm, rm, lm, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      border: 11
    });
  }
}
const {
  SvelteComponent: X2,
  append_hydration: K2,
  attr: Y2,
  binding_callbacks: Q2,
  children: J2,
  claim_element: x2,
  create_slot: ew,
  detach: tw,
  element: nw,
  get_all_dirty_from_scope: lw,
  get_slot_changes: iw,
  init: aw,
  insert_hydration: ow,
  safe_not_equal: rw,
  toggle_class: sw,
  transition_in: uw,
  transition_out: _w,
  update_slot_base: cw
} = window.__gradio__svelte__internal, {
  SvelteComponent: fw,
  append_hydration: dw,
  attr: hw,
  children: mw,
  claim_svg_element: pw,
  detach: gw,
  init: bw,
  insert_hydration: vw,
  noop: ww,
  safe_not_equal: kw,
  svg_element: Dw
} = window.__gradio__svelte__internal, {
  SvelteComponent: yw,
  append_hydration: Fw,
  attr: Ew,
  children: Cw,
  claim_svg_element: Aw,
  detach: $w,
  init: Sw,
  insert_hydration: Bw,
  noop: qw,
  safe_not_equal: Tw,
  svg_element: Iw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lw,
  append_hydration: zw,
  attr: Mw,
  children: Rw,
  claim_svg_element: Nw,
  detach: Ow,
  init: Hw,
  insert_hydration: Pw,
  noop: Vw,
  safe_not_equal: jw,
  svg_element: Uw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gw,
  append_hydration: Zw,
  attr: Ww,
  children: Xw,
  claim_svg_element: Kw,
  detach: Yw,
  init: Qw,
  insert_hydration: Jw,
  noop: xw,
  safe_not_equal: ek,
  svg_element: tk
} = window.__gradio__svelte__internal, {
  SvelteComponent: nk,
  append_hydration: lk,
  attr: ik,
  children: ak,
  claim_svg_element: ok,
  detach: rk,
  init: sk,
  insert_hydration: uk,
  noop: _k,
  safe_not_equal: ck,
  svg_element: fk
} = window.__gradio__svelte__internal, {
  SvelteComponent: dk,
  append_hydration: hk,
  attr: mk,
  children: pk,
  claim_svg_element: gk,
  detach: bk,
  init: vk,
  insert_hydration: wk,
  noop: kk,
  safe_not_equal: Dk,
  svg_element: yk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fk,
  append_hydration: Ek,
  attr: Ck,
  children: Ak,
  claim_svg_element: $k,
  detach: Sk,
  init: Bk,
  insert_hydration: qk,
  noop: Tk,
  safe_not_equal: Ik,
  svg_element: Lk
} = window.__gradio__svelte__internal, {
  SvelteComponent: zk,
  append_hydration: Mk,
  attr: Rk,
  children: Nk,
  claim_svg_element: Ok,
  detach: Hk,
  init: Pk,
  insert_hydration: Vk,
  noop: jk,
  safe_not_equal: Uk,
  svg_element: Gk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zk,
  append_hydration: Wk,
  attr: Xk,
  children: Kk,
  claim_svg_element: Yk,
  detach: Qk,
  init: Jk,
  insert_hydration: xk,
  noop: e3,
  safe_not_equal: t3,
  svg_element: n3
} = window.__gradio__svelte__internal, {
  SvelteComponent: um,
  append_hydration: ls,
  attr: et,
  children: ba,
  claim_svg_element: va,
  detach: li,
  init: _m,
  insert_hydration: cm,
  noop: wa,
  safe_not_equal: fm,
  svg_element: ka
} = window.__gradio__svelte__internal;
function dm(l) {
  let e, t, n;
  return {
    c() {
      e = ka("svg"), t = ka("path"), n = ka("path"), this.h();
    },
    l(i) {
      e = va(i, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        "aria-hidden": !0,
        role: !0,
        class: !0,
        width: !0,
        height: !0,
        preserveAspectRatio: !0,
        viewBox: !0
      });
      var a = ba(e);
      t = va(a, "path", { fill: !0, d: !0 }), ba(t).forEach(li), n = va(a, "path", { fill: !0, d: !0 }), ba(n).forEach(li), a.forEach(li), this.h();
    },
    h() {
      et(t, "fill", "currentColor"), et(t, "d", "M17.74 30L16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84Z"), et(n, "fill", "currentColor"), et(n, "d", "M8 10h16v2H8zm0 6h10v2H8z"), et(e, "xmlns", "http://www.w3.org/2000/svg"), et(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), et(e, "aria-hidden", "true"), et(e, "role", "img"), et(e, "class", "iconify iconify--carbon"), et(e, "width", "100%"), et(e, "height", "100%"), et(e, "preserveAspectRatio", "xMidYMid meet"), et(e, "viewBox", "0 0 32 32");
    },
    m(i, a) {
      cm(i, e, a), ls(e, t), ls(e, n);
    },
    p: wa,
    i: wa,
    o: wa,
    d(i) {
      i && li(e);
    }
  };
}
class hm extends um {
  constructor(e) {
    super(), _m(this, e, null, dm, fm, {});
  }
}
const {
  SvelteComponent: mm,
  append_hydration: pm,
  attr: ct,
  children: is,
  claim_svg_element: as,
  detach: Da,
  init: gm,
  insert_hydration: bm,
  noop: ya,
  safe_not_equal: vm,
  svg_element: os
} = window.__gradio__svelte__internal;
function wm(l) {
  let e, t;
  return {
    c() {
      e = os("svg"), t = os("path"), this.h();
    },
    l(n) {
      e = as(n, "svg", {
        width: !0,
        height: !0,
        "stroke-width": !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        color: !0
      });
      var i = is(e);
      t = as(i, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), is(t).forEach(Da), i.forEach(Da), this.h();
    },
    h() {
      ct(t, "d", "M5 13L9 17L19 7"), ct(t, "stroke", "currentColor"), ct(t, "stroke-width", "1.5"), ct(t, "stroke-linecap", "round"), ct(t, "stroke-linejoin", "round"), ct(e, "width", "100%"), ct(e, "height", "100%"), ct(e, "stroke-width", "1.5"), ct(e, "viewBox", "0 0 24 24"), ct(e, "fill", "none"), ct(e, "xmlns", "http://www.w3.org/2000/svg"), ct(e, "color", "currentColor");
    },
    m(n, i) {
      bm(n, e, i), pm(e, t);
    },
    p: ya,
    i: ya,
    o: ya,
    d(n) {
      n && Da(e);
    }
  };
}
class Rl extends mm {
  constructor(e) {
    super(), gm(this, e, null, wm, vm, {});
  }
}
const {
  SvelteComponent: l3,
  append_hydration: i3,
  attr: a3,
  children: o3,
  claim_svg_element: r3,
  detach: s3,
  init: u3,
  insert_hydration: _3,
  noop: c3,
  safe_not_equal: f3,
  svg_element: d3
} = window.__gradio__svelte__internal, {
  SvelteComponent: km,
  append_hydration: Fa,
  attr: wt,
  children: ii,
  claim_svg_element: ai,
  detach: Fl,
  init: Dm,
  insert_hydration: ym,
  noop: Ea,
  safe_not_equal: Fm,
  set_style: Bt,
  svg_element: oi
} = window.__gradio__svelte__internal;
function Em(l) {
  let e, t, n, i;
  return {
    c() {
      e = oi("svg"), t = oi("g"), n = oi("path"), i = oi("path"), this.h();
    },
    l(a) {
      e = ai(a, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var r = ii(e);
      t = ai(r, "g", { transform: !0 });
      var o = ii(t);
      n = ai(o, "path", { d: !0, style: !0 }), ii(n).forEach(Fl), o.forEach(Fl), i = ai(r, "path", { d: !0, style: !0 }), ii(i).forEach(Fl), r.forEach(Fl), this.h();
    },
    h() {
      wt(n, "d", "M18,6L6.087,17.913"), Bt(n, "fill", "none"), Bt(n, "fill-rule", "nonzero"), Bt(n, "stroke-width", "2px"), wt(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), wt(i, "d", "M4.364,4.364L19.636,19.636"), Bt(i, "fill", "none"), Bt(i, "fill-rule", "nonzero"), Bt(i, "stroke-width", "2px"), wt(e, "width", "100%"), wt(e, "height", "100%"), wt(e, "viewBox", "0 0 24 24"), wt(e, "version", "1.1"), wt(e, "xmlns", "http://www.w3.org/2000/svg"), wt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), wt(e, "xml:space", "preserve"), wt(e, "stroke", "currentColor"), Bt(e, "fill-rule", "evenodd"), Bt(e, "clip-rule", "evenodd"), Bt(e, "stroke-linecap", "round"), Bt(e, "stroke-linejoin", "round");
    },
    m(a, r) {
      ym(a, e, r), Fa(e, t), Fa(t, n), Fa(e, i);
    },
    p: Ea,
    i: Ea,
    o: Ea,
    d(a) {
      a && Fl(e);
    }
  };
}
class Qo extends km {
  constructor(e) {
    super(), Dm(this, e, null, Em, Fm, {});
  }
}
const {
  SvelteComponent: h3,
  append_hydration: m3,
  attr: p3,
  children: g3,
  claim_svg_element: b3,
  claim_text: v3,
  detach: w3,
  init: k3,
  insert_hydration: D3,
  noop: y3,
  safe_not_equal: F3,
  svg_element: E3,
  text: C3
} = window.__gradio__svelte__internal, {
  SvelteComponent: A3,
  append_hydration: $3,
  attr: S3,
  children: B3,
  claim_svg_element: q3,
  detach: T3,
  init: I3,
  insert_hydration: L3,
  noop: z3,
  safe_not_equal: M3,
  svg_element: R3
} = window.__gradio__svelte__internal, {
  SvelteComponent: N3,
  append_hydration: O3,
  attr: H3,
  children: P3,
  claim_svg_element: V3,
  detach: j3,
  init: U3,
  insert_hydration: G3,
  noop: Z3,
  safe_not_equal: W3,
  svg_element: X3
} = window.__gradio__svelte__internal, {
  SvelteComponent: K3,
  append_hydration: Y3,
  attr: Q3,
  children: J3,
  claim_svg_element: x3,
  detach: e5,
  init: t5,
  insert_hydration: n5,
  noop: l5,
  safe_not_equal: i5,
  svg_element: a5
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cm,
  append_hydration: Am,
  attr: Tn,
  children: rs,
  claim_svg_element: ss,
  detach: Ca,
  init: $m,
  insert_hydration: Sm,
  noop: Aa,
  safe_not_equal: Bm,
  svg_element: us
} = window.__gradio__svelte__internal;
function qm(l) {
  let e, t;
  return {
    c() {
      e = us("svg"), t = us("path"), this.h();
    },
    l(n) {
      e = ss(n, "svg", {
        id: !0,
        xmlns: !0,
        viewBox: !0,
        width: !0,
        height: !0
      });
      var i = rs(e);
      t = ss(i, "path", { d: !0, fill: !0 }), rs(t).forEach(Ca), i.forEach(Ca), this.h();
    },
    h() {
      Tn(t, "d", "M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z"), Tn(t, "fill", "currentColor"), Tn(e, "id", "icon"), Tn(e, "xmlns", "http://www.w3.org/2000/svg"), Tn(e, "viewBox", "0 0 32 32"), Tn(e, "width", "100%"), Tn(e, "height", "100%");
    },
    m(n, i) {
      Sm(n, e, i), Am(e, t);
    },
    p: Aa,
    i: Aa,
    o: Aa,
    d(n) {
      n && Ca(e);
    }
  };
}
class Tm extends Cm {
  constructor(e) {
    super(), $m(this, e, null, qm, Bm, {});
  }
}
const {
  SvelteComponent: Im,
  append_hydration: _s,
  attr: qt,
  children: $a,
  claim_svg_element: Sa,
  detach: ri,
  init: Lm,
  insert_hydration: zm,
  noop: Ba,
  safe_not_equal: Mm,
  svg_element: qa
} = window.__gradio__svelte__internal;
function Rm(l) {
  let e, t, n;
  return {
    c() {
      e = qa("svg"), t = qa("path"), n = qa("path"), this.h();
    },
    l(i) {
      e = Sa(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        color: !0,
        "aria-hidden": !0,
        width: !0,
        height: !0
      });
      var a = $a(e);
      t = Sa(a, "path", { fill: !0, d: !0 }), $a(t).forEach(ri), n = Sa(a, "path", { fill: !0, d: !0 }), $a(n).forEach(ri), a.forEach(ri), this.h();
    },
    h() {
      qt(t, "fill", "currentColor"), qt(t, "d", "M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"), qt(n, "fill", "currentColor"), qt(n, "d", "M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"), qt(e, "xmlns", "http://www.w3.org/2000/svg"), qt(e, "viewBox", "0 0 33 33"), qt(e, "color", "currentColor"), qt(e, "aria-hidden", "true"), qt(e, "width", "100%"), qt(e, "height", "100%");
    },
    m(i, a) {
      zm(i, e, a), _s(e, t), _s(e, n);
    },
    p: Ba,
    i: Ba,
    o: Ba,
    d(i) {
      i && ri(e);
    }
  };
}
class Si extends Im {
  constructor(e) {
    super(), Lm(this, e, null, Rm, Mm, {});
  }
}
const {
  SvelteComponent: o5,
  append_hydration: r5,
  attr: s5,
  children: u5,
  claim_svg_element: _5,
  detach: c5,
  init: f5,
  insert_hydration: d5,
  noop: h5,
  safe_not_equal: m5,
  svg_element: p5
} = window.__gradio__svelte__internal, {
  SvelteComponent: g5,
  append_hydration: b5,
  attr: v5,
  children: w5,
  claim_svg_element: k5,
  detach: D5,
  init: y5,
  insert_hydration: F5,
  noop: E5,
  safe_not_equal: C5,
  svg_element: A5
} = window.__gradio__svelte__internal, {
  SvelteComponent: $5,
  append_hydration: S5,
  attr: B5,
  children: q5,
  claim_svg_element: T5,
  detach: I5,
  init: L5,
  insert_hydration: z5,
  noop: M5,
  safe_not_equal: R5,
  svg_element: N5
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nm,
  append_hydration: cs,
  attr: Tt,
  children: Ta,
  claim_svg_element: Ia,
  detach: si,
  init: Om,
  insert_hydration: Hm,
  noop: La,
  safe_not_equal: Pm,
  svg_element: za
} = window.__gradio__svelte__internal;
function Vm(l) {
  let e, t, n;
  return {
    c() {
      e = za("svg"), t = za("circle"), n = za("path"), this.h();
    },
    l(i) {
      e = Ia(i, "svg", {
        class: !0,
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var a = Ta(e);
      t = Ia(a, "circle", { cx: !0, cy: !0, r: !0, class: !0 }), Ta(t).forEach(si), n = Ia(a, "path", { d: !0 }), Ta(n).forEach(si), a.forEach(si), this.h();
    },
    h() {
      Tt(t, "cx", "9"), Tt(t, "cy", "9"), Tt(t, "r", "8"), Tt(t, "class", "circle svelte-ihhdbf"), Tt(n, "d", "M5 8l4 4 4-4z"), Tt(e, "class", "dropdown-arrow svelte-ihhdbf"), Tt(e, "xmlns", "http://www.w3.org/2000/svg"), Tt(e, "width", "100%"), Tt(e, "height", "100%"), Tt(e, "viewBox", "0 0 18 18");
    },
    m(i, a) {
      Hm(i, e, a), cs(e, t), cs(e, n);
    },
    p: La,
    i: La,
    o: La,
    d(i) {
      i && si(e);
    }
  };
}
class jm extends Nm {
  constructor(e) {
    super(), Om(this, e, null, Vm, Pm, {});
  }
}
const {
  SvelteComponent: Um,
  append_hydration: Gm,
  attr: kt,
  children: fs,
  claim_svg_element: ds,
  detach: Ma,
  init: Zm,
  insert_hydration: Wm,
  noop: Ra,
  safe_not_equal: Xm,
  svg_element: hs
} = window.__gradio__svelte__internal;
function Km(l) {
  let e, t;
  return {
    c() {
      e = hs("svg"), t = hs("path"), this.h();
    },
    l(n) {
      e = ds(n, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var i = fs(e);
      t = ds(i, "path", { d: !0 }), fs(t).forEach(Ma), i.forEach(Ma), this.h();
    },
    h() {
      kt(t, "d", "M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"), kt(e, "xmlns", "http://www.w3.org/2000/svg"), kt(e, "width", "100%"), kt(e, "height", "100%"), kt(e, "viewBox", "0 0 24 24"), kt(e, "fill", "none"), kt(e, "stroke", "currentColor"), kt(e, "stroke-width", "1.5"), kt(e, "stroke-linecap", "round"), kt(e, "stroke-linejoin", "round"), kt(e, "class", "feather feather-edit-2");
    },
    m(n, i) {
      Wm(n, e, i), Gm(e, t);
    },
    p: Ra,
    i: Ra,
    o: Ra,
    d(n) {
      n && Ma(e);
    }
  };
}
class Ym extends Um {
  constructor(e) {
    super(), Zm(this, e, null, Km, Xm, {});
  }
}
const {
  SvelteComponent: O5,
  append_hydration: H5,
  attr: P5,
  children: V5,
  claim_svg_element: j5,
  detach: U5,
  init: G5,
  insert_hydration: Z5,
  noop: W5,
  safe_not_equal: X5,
  svg_element: K5
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y5,
  append_hydration: Q5,
  attr: J5,
  children: x5,
  claim_svg_element: e4,
  detach: t4,
  init: n4,
  insert_hydration: l4,
  noop: i4,
  safe_not_equal: a4,
  svg_element: o4
} = window.__gradio__svelte__internal, {
  SvelteComponent: r4,
  append_hydration: s4,
  attr: u4,
  children: _4,
  claim_svg_element: c4,
  detach: f4,
  init: d4,
  insert_hydration: h4,
  noop: m4,
  safe_not_equal: p4,
  svg_element: g4
} = window.__gradio__svelte__internal, {
  SvelteComponent: b4,
  append_hydration: v4,
  attr: w4,
  children: k4,
  claim_svg_element: D4,
  detach: y4,
  init: F4,
  insert_hydration: E4,
  noop: C4,
  safe_not_equal: A4,
  svg_element: $4
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qm,
  append_hydration: ms,
  attr: ft,
  children: Na,
  claim_svg_element: Oa,
  detach: ui,
  init: Jm,
  insert_hydration: xm,
  noop: Ha,
  safe_not_equal: e1,
  svg_element: Pa
} = window.__gradio__svelte__internal;
function t1(l) {
  let e, t, n;
  return {
    c() {
      e = Pa("svg"), t = Pa("path"), n = Pa("polyline"), this.h();
    },
    l(i) {
      e = Oa(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var a = Na(e);
      t = Oa(a, "path", { d: !0 }), Na(t).forEach(ui), n = Oa(a, "polyline", { points: !0 }), Na(n).forEach(ui), a.forEach(ui), this.h();
    },
    h() {
      ft(t, "d", "M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"), ft(n, "points", "13 2 13 9 20 9"), ft(e, "xmlns", "http://www.w3.org/2000/svg"), ft(e, "width", "100%"), ft(e, "height", "100%"), ft(e, "viewBox", "0 0 24 24"), ft(e, "fill", "none"), ft(e, "stroke", "currentColor"), ft(e, "stroke-width", "1.5"), ft(e, "stroke-linecap", "round"), ft(e, "stroke-linejoin", "round"), ft(e, "class", "feather feather-file");
    },
    m(i, a) {
      xm(i, e, a), ms(e, t), ms(e, n);
    },
    p: Ha,
    i: Ha,
    o: Ha,
    d(i) {
      i && ui(e);
    }
  };
}
let Jo = class extends Qm {
  constructor(e) {
    super(), Jm(this, e, null, t1, e1, {});
  }
};
const {
  SvelteComponent: B4,
  append_hydration: q4,
  attr: T4,
  children: I4,
  claim_svg_element: L4,
  detach: z4,
  init: M4,
  insert_hydration: R4,
  noop: N4,
  safe_not_equal: O4,
  svg_element: H4
} = window.__gradio__svelte__internal, {
  SvelteComponent: P4,
  append_hydration: V4,
  attr: j4,
  children: U4,
  claim_svg_element: G4,
  detach: Z4,
  init: W4,
  insert_hydration: X4,
  noop: K4,
  safe_not_equal: Y4,
  svg_element: Q4
} = window.__gradio__svelte__internal, {
  SvelteComponent: J4,
  append_hydration: x4,
  attr: e6,
  children: t6,
  claim_svg_element: n6,
  detach: l6,
  init: i6,
  insert_hydration: a6,
  noop: o6,
  safe_not_equal: r6,
  svg_element: s6
} = window.__gradio__svelte__internal, {
  SvelteComponent: u6,
  append_hydration: _6,
  attr: c6,
  children: f6,
  claim_svg_element: d6,
  detach: h6,
  init: m6,
  insert_hydration: p6,
  noop: g6,
  safe_not_equal: b6,
  svg_element: v6
} = window.__gradio__svelte__internal, {
  SvelteComponent: w6,
  append_hydration: k6,
  attr: D6,
  children: y6,
  claim_svg_element: F6,
  detach: E6,
  init: C6,
  insert_hydration: A6,
  noop: $6,
  safe_not_equal: S6,
  svg_element: B6
} = window.__gradio__svelte__internal, {
  SvelteComponent: q6,
  append_hydration: T6,
  attr: I6,
  children: L6,
  claim_svg_element: z6,
  detach: M6,
  init: R6,
  insert_hydration: N6,
  noop: O6,
  safe_not_equal: H6,
  svg_element: P6
} = window.__gradio__svelte__internal, {
  SvelteComponent: V6,
  append_hydration: j6,
  attr: U6,
  children: G6,
  claim_svg_element: Z6,
  detach: W6,
  init: X6,
  insert_hydration: K6,
  noop: Y6,
  safe_not_equal: Q6,
  svg_element: J6
} = window.__gradio__svelte__internal, {
  SvelteComponent: x6,
  append_hydration: eD,
  attr: tD,
  children: nD,
  claim_svg_element: lD,
  detach: iD,
  init: aD,
  insert_hydration: oD,
  noop: rD,
  safe_not_equal: sD,
  svg_element: uD
} = window.__gradio__svelte__internal, {
  SvelteComponent: _D,
  append_hydration: cD,
  attr: fD,
  children: dD,
  claim_svg_element: hD,
  detach: mD,
  init: pD,
  insert_hydration: gD,
  noop: bD,
  safe_not_equal: vD,
  svg_element: wD
} = window.__gradio__svelte__internal, {
  SvelteComponent: kD,
  append_hydration: DD,
  attr: yD,
  children: FD,
  claim_svg_element: ED,
  detach: CD,
  init: AD,
  insert_hydration: $D,
  noop: SD,
  safe_not_equal: BD,
  svg_element: qD
} = window.__gradio__svelte__internal, {
  SvelteComponent: n1,
  append_hydration: Va,
  attr: $e,
  children: _i,
  claim_svg_element: ci,
  detach: El,
  init: l1,
  insert_hydration: i1,
  noop: ja,
  safe_not_equal: a1,
  svg_element: fi
} = window.__gradio__svelte__internal;
function o1(l) {
  let e, t, n, i;
  return {
    c() {
      e = fi("svg"), t = fi("path"), n = fi("circle"), i = fi("circle"), this.h();
    },
    l(a) {
      e = ci(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var r = _i(e);
      t = ci(r, "path", { d: !0 }), _i(t).forEach(El), n = ci(r, "circle", { cx: !0, cy: !0, r: !0 }), _i(n).forEach(El), i = ci(r, "circle", { cx: !0, cy: !0, r: !0 }), _i(i).forEach(El), r.forEach(El), this.h();
    },
    h() {
      $e(t, "d", "M9 18V5l12-2v13"), $e(n, "cx", "6"), $e(n, "cy", "18"), $e(n, "r", "3"), $e(i, "cx", "18"), $e(i, "cy", "16"), $e(i, "r", "3"), $e(e, "xmlns", "http://www.w3.org/2000/svg"), $e(e, "width", "100%"), $e(e, "height", "100%"), $e(e, "viewBox", "0 0 24 24"), $e(e, "fill", "none"), $e(e, "stroke", "currentColor"), $e(e, "stroke-width", "1.5"), $e(e, "stroke-linecap", "round"), $e(e, "stroke-linejoin", "round"), $e(e, "class", "feather feather-music");
    },
    m(a, r) {
      i1(a, e, r), Va(e, t), Va(e, n), Va(e, i);
    },
    p: ja,
    i: ja,
    o: ja,
    d(a) {
      a && El(e);
    }
  };
}
class mc extends n1 {
  constructor(e) {
    super(), l1(this, e, null, o1, a1, {});
  }
}
const {
  SvelteComponent: TD,
  append_hydration: ID,
  attr: LD,
  children: zD,
  claim_svg_element: MD,
  detach: RD,
  init: ND,
  insert_hydration: OD,
  noop: HD,
  safe_not_equal: PD,
  svg_element: VD
} = window.__gradio__svelte__internal, {
  SvelteComponent: jD,
  append_hydration: UD,
  attr: GD,
  children: ZD,
  claim_svg_element: WD,
  detach: XD,
  init: KD,
  insert_hydration: YD,
  noop: QD,
  safe_not_equal: JD,
  svg_element: xD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ey,
  append_hydration: ty,
  attr: ny,
  children: ly,
  claim_svg_element: iy,
  detach: ay,
  init: oy,
  insert_hydration: ry,
  noop: sy,
  safe_not_equal: uy,
  svg_element: _y
} = window.__gradio__svelte__internal, {
  SvelteComponent: cy,
  append_hydration: fy,
  attr: dy,
  children: hy,
  claim_svg_element: my,
  detach: py,
  init: gy,
  insert_hydration: by,
  noop: vy,
  safe_not_equal: wy,
  svg_element: ky
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dy,
  append_hydration: yy,
  attr: Fy,
  children: Ey,
  claim_svg_element: Cy,
  detach: Ay,
  init: $y,
  insert_hydration: Sy,
  noop: By,
  safe_not_equal: qy,
  svg_element: Ty
} = window.__gradio__svelte__internal, {
  SvelteComponent: Iy,
  append_hydration: Ly,
  attr: zy,
  children: My,
  claim_svg_element: Ry,
  detach: Ny,
  init: Oy,
  insert_hydration: Hy,
  noop: Py,
  safe_not_equal: Vy,
  svg_element: jy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uy,
  append_hydration: Gy,
  attr: Zy,
  children: Wy,
  claim_svg_element: Xy,
  detach: Ky,
  init: Yy,
  insert_hydration: Qy,
  noop: Jy,
  safe_not_equal: xy,
  svg_element: e8
} = window.__gradio__svelte__internal, {
  SvelteComponent: t8,
  append_hydration: n8,
  attr: l8,
  children: i8,
  claim_svg_element: a8,
  detach: o8,
  init: r8,
  insert_hydration: s8,
  noop: u8,
  safe_not_equal: _8,
  set_style: c8,
  svg_element: f8
} = window.__gradio__svelte__internal, {
  SvelteComponent: d8,
  append_hydration: h8,
  attr: m8,
  children: p8,
  claim_svg_element: g8,
  detach: b8,
  init: v8,
  insert_hydration: w8,
  noop: k8,
  safe_not_equal: D8,
  svg_element: y8
} = window.__gradio__svelte__internal, {
  SvelteComponent: F8,
  append_hydration: E8,
  attr: C8,
  children: A8,
  claim_svg_element: $8,
  detach: S8,
  init: B8,
  insert_hydration: q8,
  noop: T8,
  safe_not_equal: I8,
  svg_element: L8
} = window.__gradio__svelte__internal, {
  SvelteComponent: z8,
  append_hydration: M8,
  attr: R8,
  children: N8,
  claim_svg_element: O8,
  detach: H8,
  init: P8,
  insert_hydration: V8,
  noop: j8,
  safe_not_equal: U8,
  svg_element: G8
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z8,
  append_hydration: W8,
  attr: X8,
  children: K8,
  claim_svg_element: Y8,
  detach: Q8,
  init: J8,
  insert_hydration: x8,
  noop: e9,
  safe_not_equal: t9,
  svg_element: n9
} = window.__gradio__svelte__internal, {
  SvelteComponent: l9,
  append_hydration: i9,
  attr: a9,
  children: o9,
  claim_svg_element: r9,
  detach: s9,
  init: u9,
  insert_hydration: _9,
  noop: c9,
  safe_not_equal: f9,
  svg_element: d9
} = window.__gradio__svelte__internal, {
  SvelteComponent: h9,
  append_hydration: m9,
  attr: p9,
  children: g9,
  claim_svg_element: b9,
  detach: v9,
  init: w9,
  insert_hydration: k9,
  noop: D9,
  safe_not_equal: y9,
  svg_element: F9
} = window.__gradio__svelte__internal, {
  SvelteComponent: E9,
  append_hydration: C9,
  attr: A9,
  children: $9,
  claim_svg_element: S9,
  detach: B9,
  init: q9,
  insert_hydration: T9,
  noop: I9,
  safe_not_equal: L9,
  svg_element: z9
} = window.__gradio__svelte__internal, {
  SvelteComponent: M9,
  append_hydration: R9,
  attr: N9,
  children: O9,
  claim_svg_element: H9,
  detach: P9,
  init: V9,
  insert_hydration: j9,
  noop: U9,
  safe_not_equal: G9,
  svg_element: Z9
} = window.__gradio__svelte__internal, {
  SvelteComponent: r1,
  append_hydration: on,
  attr: le,
  children: rn,
  claim_svg_element: sn,
  claim_text: s1,
  detach: Vt,
  init: u1,
  insert_hydration: _1,
  noop: Ua,
  safe_not_equal: c1,
  svg_element: un,
  text: f1
} = window.__gradio__svelte__internal;
function d1(l) {
  let e, t, n, i, a, r, o, s, u;
  return {
    c() {
      e = un("svg"), t = un("defs"), n = un("style"), i = f1(`.cls-1 {
				fill: none;
			}
		`), a = un("rect"), r = un("rect"), o = un("path"), s = un("rect"), u = un("rect"), this.h();
    },
    l(c) {
      e = sn(c, "svg", {
        id: !0,
        xmlns: !0,
        viewBox: !0,
        fill: !0,
        width: !0,
        height: !0
      });
      var f = rn(e);
      t = sn(f, "defs", {});
      var _ = rn(t);
      n = sn(_, "style", {});
      var d = rn(n);
      i = s1(d, `.cls-1 {
				fill: none;
			}
		`), d.forEach(Vt), _.forEach(Vt), a = sn(f, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0
      }), rn(a).forEach(Vt), r = sn(f, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0
      }), rn(r).forEach(Vt), o = sn(f, "path", { d: !0 }), rn(o).forEach(Vt), s = sn(f, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0
      }), rn(s).forEach(Vt), u = sn(f, "rect", {
        id: !0,
        "data-name": !0,
        class: !0,
        width: !0,
        height: !0
      }), rn(u).forEach(Vt), f.forEach(Vt), this.h();
    },
    h() {
      le(a, "x", "12"), le(a, "y", "12"), le(a, "width", "2"), le(a, "height", "12"), le(r, "x", "18"), le(r, "y", "12"), le(r, "width", "2"), le(r, "height", "12"), le(o, "d", "M4,6V8H6V28a2,2,0,0,0,2,2H24a2,2,0,0,0,2-2V8h2V6ZM8,28V8H24V28Z"), le(s, "x", "12"), le(s, "y", "2"), le(s, "width", "8"), le(s, "height", "2"), le(u, "id", "_Transparent_Rectangle_"), le(u, "data-name", "<Transparent Rectangle>"), le(u, "class", "cls-1"), le(u, "width", "32"), le(u, "height", "32"), le(e, "id", "icon"), le(e, "xmlns", "http://www.w3.org/2000/svg"), le(e, "viewBox", "0 0 32 32"), le(e, "fill", "currentColor"), le(e, "width", "100%"), le(e, "height", "100%");
    },
    m(c, f) {
      _1(c, e, f), on(e, t), on(t, n), on(n, i), on(e, a), on(e, r), on(e, o), on(e, s), on(e, u);
    },
    p: Ua,
    i: Ua,
    o: Ua,
    d(c) {
      c && Vt(e);
    }
  };
}
class h1 extends r1 {
  constructor(e) {
    super(), u1(this, e, null, d1, c1, {});
  }
}
const {
  SvelteComponent: W9,
  append_hydration: X9,
  attr: K9,
  children: Y9,
  claim_svg_element: Q9,
  detach: J9,
  init: x9,
  insert_hydration: e7,
  noop: t7,
  safe_not_equal: n7,
  svg_element: l7
} = window.__gradio__svelte__internal, {
  SvelteComponent: i7,
  append_hydration: a7,
  attr: o7,
  children: r7,
  claim_svg_element: s7,
  detach: u7,
  init: _7,
  insert_hydration: c7,
  noop: f7,
  safe_not_equal: d7,
  svg_element: h7
} = window.__gradio__svelte__internal, {
  SvelteComponent: m1,
  append_hydration: ps,
  attr: tt,
  children: Ga,
  claim_svg_element: Za,
  detach: di,
  init: p1,
  insert_hydration: g1,
  noop: Wa,
  safe_not_equal: b1,
  svg_element: Xa
} = window.__gradio__svelte__internal;
function v1(l) {
  let e, t, n;
  return {
    c() {
      e = Xa("svg"), t = Xa("polyline"), n = Xa("path"), this.h();
    },
    l(i) {
      e = Za(i, "svg", {
        "aria-label": !0,
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var a = Ga(e);
      t = Za(a, "polyline", { points: !0 }), Ga(t).forEach(di), n = Za(a, "path", { d: !0 }), Ga(n).forEach(di), a.forEach(di), this.h();
    },
    h() {
      tt(t, "points", "1 4 1 10 7 10"), tt(n, "d", "M3.51 15a9 9 0 1 0 2.13-9.36L1 10"), tt(e, "aria-label", "undo"), tt(e, "xmlns", "http://www.w3.org/2000/svg"), tt(e, "width", "100%"), tt(e, "height", "100%"), tt(e, "viewBox", "0 0 24 24"), tt(e, "fill", "none"), tt(e, "stroke", "currentColor"), tt(e, "stroke-width", "1.5"), tt(e, "stroke-linecap", "round"), tt(e, "stroke-linejoin", "round"), tt(e, "class", "feather feather-rotate-ccw");
    },
    m(i, a) {
      g1(i, e, a), ps(e, t), ps(e, n);
    },
    p: Wa,
    i: Wa,
    o: Wa,
    d(i) {
      i && di(e);
    }
  };
}
class w1 extends m1 {
  constructor(e) {
    super(), p1(this, e, null, v1, b1, {});
  }
}
const {
  SvelteComponent: m7,
  append_hydration: p7,
  attr: g7,
  children: b7,
  claim_svg_element: v7,
  detach: w7,
  init: k7,
  insert_hydration: D7,
  noop: y7,
  safe_not_equal: F7,
  svg_element: E7
} = window.__gradio__svelte__internal, {
  SvelteComponent: C7,
  append_hydration: A7,
  attr: $7,
  children: S7,
  claim_svg_element: B7,
  detach: q7,
  init: T7,
  insert_hydration: I7,
  noop: L7,
  safe_not_equal: z7,
  svg_element: M7
} = window.__gradio__svelte__internal, {
  SvelteComponent: R7,
  append_hydration: N7,
  attr: O7,
  children: H7,
  claim_svg_element: P7,
  detach: V7,
  init: j7,
  insert_hydration: U7,
  noop: G7,
  safe_not_equal: Z7,
  svg_element: W7
} = window.__gradio__svelte__internal, {
  SvelteComponent: X7,
  append_hydration: K7,
  attr: Y7,
  children: Q7,
  claim_svg_element: J7,
  detach: x7,
  init: eF,
  insert_hydration: tF,
  noop: nF,
  safe_not_equal: lF,
  svg_element: iF
} = window.__gradio__svelte__internal, {
  SvelteComponent: aF,
  append_hydration: oF,
  attr: rF,
  children: sF,
  claim_svg_element: uF,
  claim_text: _F,
  detach: cF,
  init: fF,
  insert_hydration: dF,
  noop: hF,
  safe_not_equal: mF,
  svg_element: pF,
  text: gF
} = window.__gradio__svelte__internal, {
  SvelteComponent: bF,
  append_hydration: vF,
  attr: wF,
  children: kF,
  claim_svg_element: DF,
  claim_text: yF,
  detach: FF,
  init: EF,
  insert_hydration: CF,
  noop: AF,
  safe_not_equal: $F,
  svg_element: SF,
  text: BF
} = window.__gradio__svelte__internal, {
  SvelteComponent: qF,
  append_hydration: TF,
  attr: IF,
  children: LF,
  claim_svg_element: zF,
  claim_text: MF,
  detach: RF,
  init: NF,
  insert_hydration: OF,
  noop: HF,
  safe_not_equal: PF,
  svg_element: VF,
  text: jF
} = window.__gradio__svelte__internal, {
  SvelteComponent: UF,
  append_hydration: GF,
  attr: ZF,
  children: WF,
  claim_svg_element: XF,
  detach: KF,
  init: YF,
  insert_hydration: QF,
  noop: JF,
  safe_not_equal: xF,
  svg_element: eE
} = window.__gradio__svelte__internal, {
  SvelteComponent: tE,
  append_hydration: nE,
  attr: lE,
  children: iE,
  claim_svg_element: aE,
  detach: oE,
  init: rE,
  insert_hydration: sE,
  noop: uE,
  safe_not_equal: _E,
  svg_element: cE
} = window.__gradio__svelte__internal, {
  SvelteComponent: fE,
  append_hydration: dE,
  attr: hE,
  children: mE,
  claim_svg_element: pE,
  detach: gE,
  init: bE,
  insert_hydration: vE,
  noop: wE,
  safe_not_equal: kE,
  svg_element: DE
} = window.__gradio__svelte__internal, {
  SvelteComponent: yE,
  append_hydration: FE,
  attr: EE,
  children: CE,
  claim_svg_element: AE,
  detach: $E,
  init: SE,
  insert_hydration: BE,
  noop: qE,
  safe_not_equal: TE,
  svg_element: IE
} = window.__gradio__svelte__internal, {
  SvelteComponent: k1,
  append_hydration: hi,
  attr: Y,
  children: Cl,
  claim_svg_element: Al,
  detach: al,
  init: D1,
  insert_hydration: y1,
  noop: Ka,
  safe_not_equal: F1,
  svg_element: $l
} = window.__gradio__svelte__internal;
function E1(l) {
  let e, t, n, i, a;
  return {
    c() {
      e = $l("svg"), t = $l("path"), n = $l("path"), i = $l("path"), a = $l("path"), this.h();
    },
    l(r) {
      e = Al(r, "svg", {
        width: !0,
        height: !0,
        "stroke-width": !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        color: !0
      });
      var o = Cl(e);
      t = Al(o, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Cl(t).forEach(al), n = Al(o, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Cl(n).forEach(al), i = Al(o, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Cl(i).forEach(al), a = Al(o, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Cl(a).forEach(al), o.forEach(al), this.h();
    },
    h() {
      Y(t, "d", "M19.1679 9C18.0247 6.46819 15.3006 4.5 11.9999 4.5C8.31459 4.5 5.05104 7.44668 4.54932 11"), Y(t, "stroke", "currentColor"), Y(t, "stroke-width", "1.5"), Y(t, "stroke-linecap", "round"), Y(t, "stroke-linejoin", "round"), Y(n, "d", "M16 9H19.4C19.7314 9 20 8.73137 20 8.4V5"), Y(n, "stroke", "currentColor"), Y(n, "stroke-width", "1.5"), Y(n, "stroke-linecap", "round"), Y(n, "stroke-linejoin", "round"), Y(i, "d", "M4.88146 15C5.92458 17.5318 8.64874 19.5 12.0494 19.5C15.7347 19.5 18.9983 16.5533 19.5 13"), Y(i, "stroke", "currentColor"), Y(i, "stroke-width", "1.5"), Y(i, "stroke-linecap", "round"), Y(i, "stroke-linejoin", "round"), Y(a, "d", "M8.04932 15H4.64932C4.31795 15 4.04932 15.2686 4.04932 15.6V19"), Y(a, "stroke", "currentColor"), Y(a, "stroke-width", "1.5"), Y(a, "stroke-linecap", "round"), Y(a, "stroke-linejoin", "round"), Y(e, "width", "100%"), Y(e, "height", "100%"), Y(e, "stroke-width", "1.5"), Y(e, "viewBox", "0 0 24 24"), Y(e, "fill", "none"), Y(e, "xmlns", "http://www.w3.org/2000/svg"), Y(e, "color", "currentColor");
    },
    m(r, o) {
      y1(r, e, o), hi(e, t), hi(e, n), hi(e, i), hi(e, a);
    },
    p: Ka,
    i: Ka,
    o: Ka,
    d(r) {
      r && al(e);
    }
  };
}
class C1 extends k1 {
  constructor(e) {
    super(), D1(this, e, null, E1, F1, {});
  }
}
const {
  SvelteComponent: A1,
  append_hydration: $1,
  attr: It,
  children: gs,
  claim_svg_element: bs,
  detach: Ya,
  init: S1,
  insert_hydration: B1,
  noop: Qa,
  safe_not_equal: q1,
  svg_element: vs
} = window.__gradio__svelte__internal;
function T1(l) {
  let e, t;
  return {
    c() {
      e = vs("svg"), t = vs("path"), this.h();
    },
    l(n) {
      e = bs(n, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0
      });
      var i = gs(e);
      t = bs(i, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), gs(t).forEach(Ya), i.forEach(Ya), this.h();
    },
    h() {
      It(t, "d", "M12 20L12 4M12 20L7 15M12 20L17 15"), It(t, "stroke", "currentColor"), It(t, "stroke-width", "2"), It(t, "stroke-linecap", "round"), It(t, "stroke-linejoin", "round"), It(e, "width", "100%"), It(e, "height", "100%"), It(e, "viewBox", "0 0 24 24"), It(e, "fill", "none"), It(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(n, i) {
      B1(n, e, i), $1(e, t);
    },
    p: Qa,
    i: Qa,
    o: Qa,
    d(n) {
      n && Ya(e);
    }
  };
}
class I1 extends A1 {
  constructor(e) {
    super(), S1(this, e, null, T1, q1, {});
  }
}
const {
  SvelteComponent: LE,
  append_hydration: zE,
  attr: ME,
  children: RE,
  claim_svg_element: NE,
  detach: OE,
  init: HE,
  insert_hydration: PE,
  noop: VE,
  safe_not_equal: jE,
  svg_element: UE
} = window.__gradio__svelte__internal, {
  SvelteComponent: GE,
  append_hydration: ZE,
  attr: WE,
  children: XE,
  claim_svg_element: KE,
  detach: YE,
  init: QE,
  insert_hydration: JE,
  noop: xE,
  safe_not_equal: eC,
  svg_element: tC
} = window.__gradio__svelte__internal, {
  SvelteComponent: nC,
  append_hydration: lC,
  attr: iC,
  children: aC,
  claim_svg_element: oC,
  detach: rC,
  init: sC,
  insert_hydration: uC,
  noop: _C,
  safe_not_equal: cC,
  svg_element: fC
} = window.__gradio__svelte__internal, {
  SvelteComponent: dC,
  append_hydration: hC,
  attr: mC,
  children: pC,
  claim_svg_element: gC,
  detach: bC,
  init: vC,
  insert_hydration: wC,
  noop: kC,
  safe_not_equal: DC,
  svg_element: yC
} = window.__gradio__svelte__internal, {
  SvelteComponent: FC,
  append_hydration: EC,
  attr: CC,
  children: AC,
  claim_svg_element: $C,
  detach: SC,
  init: BC,
  insert_hydration: qC,
  noop: TC,
  safe_not_equal: IC,
  svg_element: LC
} = window.__gradio__svelte__internal, {
  SvelteComponent: zC,
  claim_component: MC,
  create_component: RC,
  destroy_component: NC,
  init: OC,
  mount_component: HC,
  safe_not_equal: PC,
  transition_in: VC,
  transition_out: jC
} = window.__gradio__svelte__internal, { createEventDispatcher: UC } = window.__gradio__svelte__internal, {
  SvelteComponent: GC,
  append_hydration: ZC,
  attr: WC,
  check_outros: XC,
  children: KC,
  claim_component: YC,
  claim_element: QC,
  claim_space: JC,
  claim_text: xC,
  create_component: eA,
  destroy_component: tA,
  detach: nA,
  element: lA,
  empty: iA,
  group_outros: aA,
  init: oA,
  insert_hydration: rA,
  mount_component: sA,
  safe_not_equal: uA,
  set_data: _A,
  space: cA,
  text: fA,
  toggle_class: dA,
  transition_in: hA,
  transition_out: mA
} = window.__gradio__svelte__internal, {
  SvelteComponent: pA,
  attr: gA,
  children: bA,
  claim_element: vA,
  create_slot: wA,
  detach: kA,
  element: DA,
  get_all_dirty_from_scope: yA,
  get_slot_changes: FA,
  init: EA,
  insert_hydration: CA,
  safe_not_equal: AA,
  toggle_class: $A,
  transition_in: SA,
  transition_out: BA,
  update_slot_base: qA
} = window.__gradio__svelte__internal, {
  SvelteComponent: TA,
  append_hydration: IA,
  attr: LA,
  check_outros: zA,
  children: MA,
  claim_component: RA,
  claim_element: NA,
  claim_space: OA,
  create_component: HA,
  destroy_component: PA,
  detach: VA,
  element: jA,
  empty: UA,
  group_outros: GA,
  init: ZA,
  insert_hydration: WA,
  listen: XA,
  mount_component: KA,
  safe_not_equal: YA,
  space: QA,
  toggle_class: JA,
  transition_in: xA,
  transition_out: e$
} = window.__gradio__svelte__internal, {
  SvelteComponent: L1,
  attr: ws,
  children: z1,
  claim_element: M1,
  create_slot: R1,
  detach: ks,
  element: N1,
  get_all_dirty_from_scope: O1,
  get_slot_changes: H1,
  init: P1,
  insert_hydration: V1,
  null_to_empty: Ds,
  safe_not_equal: j1,
  transition_in: U1,
  transition_out: G1,
  update_slot_base: Z1
} = window.__gradio__svelte__internal;
function W1(l) {
  let e, t, n;
  const i = (
    /*#slots*/
    l[3].default
  ), a = R1(
    i,
    l,
    /*$$scope*/
    l[2],
    null
  );
  return {
    c() {
      e = N1("div"), a && a.c(), this.h();
    },
    l(r) {
      e = M1(r, "DIV", { class: !0 });
      var o = z1(e);
      a && a.l(o), o.forEach(ks), this.h();
    },
    h() {
      ws(e, "class", t = Ds(`icon-button-wrapper ${/*top_panel*/
      l[0] ? "top-panel" : ""} ${/*display_top_corner*/
      l[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-1h0hs6p");
    },
    m(r, o) {
      V1(r, e, o), a && a.m(e, null), n = !0;
    },
    p(r, [o]) {
      a && a.p && (!n || o & /*$$scope*/
      4) && Z1(
        a,
        i,
        r,
        /*$$scope*/
        r[2],
        n ? H1(
          i,
          /*$$scope*/
          r[2],
          o,
          null
        ) : O1(
          /*$$scope*/
          r[2]
        ),
        null
      ), (!n || o & /*top_panel, display_top_corner*/
      3 && t !== (t = Ds(`icon-button-wrapper ${/*top_panel*/
      r[0] ? "top-panel" : ""} ${/*display_top_corner*/
      r[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-1h0hs6p")) && ws(e, "class", t);
    },
    i(r) {
      n || (U1(a, r), n = !0);
    },
    o(r) {
      G1(a, r), n = !1;
    },
    d(r) {
      r && ks(e), a && a.d(r);
    }
  };
}
function X1(l, e, t) {
  let { $$slots: n = {}, $$scope: i } = e, { top_panel: a = !0 } = e, { display_top_corner: r = !1 } = e;
  return l.$$set = (o) => {
    "top_panel" in o && t(0, a = o.top_panel), "display_top_corner" in o && t(1, r = o.display_top_corner), "$$scope" in o && t(2, i = o.$$scope);
  }, [a, r, i, n];
}
class pc extends L1 {
  constructor(e) {
    super(), P1(this, e, X1, W1, j1, { top_panel: 0, display_top_corner: 1 });
  }
}
const {
  SvelteComponent: t$,
  check_outros: n$,
  claim_component: l$,
  create_component: i$,
  destroy_component: a$,
  detach: o$,
  empty: r$,
  group_outros: s$,
  init: u$,
  insert_hydration: _$,
  mount_component: c$,
  noop: f$,
  safe_not_equal: d$,
  transition_in: h$,
  transition_out: m$
} = window.__gradio__svelte__internal, { createEventDispatcher: p$ } = window.__gradio__svelte__internal, {
  SvelteComponent: g$,
  append_hydration: b$,
  attr: v$,
  binding_callbacks: w$,
  bubble: k$,
  check_outros: D$,
  children: y$,
  claim_component: F$,
  claim_element: E$,
  claim_space: C$,
  create_component: A$,
  destroy_component: $$,
  detach: S$,
  element: B$,
  empty: q$,
  group_outros: T$,
  init: I$,
  insert_hydration: L$,
  listen: z$,
  mount_component: M$,
  safe_not_equal: R$,
  space: N$,
  toggle_class: O$,
  transition_in: H$,
  transition_out: P$
} = window.__gradio__svelte__internal, { createEventDispatcher: V$, onMount: j$ } = window.__gradio__svelte__internal, {
  SvelteComponent: K1,
  append_hydration: Y1,
  attr: In,
  children: ys,
  claim_svg_element: Fs,
  detach: Ja,
  init: Q1,
  insert_hydration: J1,
  noop: xa,
  safe_not_equal: x1,
  svg_element: Es
} = window.__gradio__svelte__internal;
function ep(l) {
  let e, t;
  return {
    c() {
      e = Es("svg"), t = Es("path"), this.h();
    },
    l(n) {
      e = Fs(n, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0
      });
      var i = ys(e);
      t = Fs(i, "path", { d: !0, fill: !0 }), ys(t).forEach(Ja), i.forEach(Ja), this.h();
    },
    h() {
      In(t, "d", "M11.25 6.61523H9.375V1.36523H11.25V6.61523ZM3.375 1.36523H8.625V6.91636L7.48425 8.62748L7.16737 10.8464C7.14108 11.0248 7.05166 11.1879 6.91535 11.3061C6.77904 11.4242 6.60488 11.4896 6.4245 11.4902H6.375C6.07672 11.4899 5.79075 11.3713 5.57983 11.1604C5.36892 10.9495 5.2503 10.6635 5.25 10.3652V8.11523H2.25C1.85233 8.11474 1.47109 7.95654 1.18989 7.67535C0.908691 7.39415 0.750496 7.01291 0.75 6.61523V3.99023C0.750992 3.29435 1.02787 2.62724 1.51994 2.13517C2.01201 1.64311 2.67911 1.36623 3.375 1.36523Z"), In(t, "fill", "currentColor"), In(e, "width", "100%"), In(e, "height", "100%"), In(e, "viewBox", "0 0 12 12"), In(e, "fill", "none"), In(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(n, i) {
      J1(n, e, i), Y1(e, t);
    },
    p: xa,
    i: xa,
    o: xa,
    d(n) {
      n && Ja(e);
    }
  };
}
class Cs extends K1 {
  constructor(e) {
    super(), Q1(this, e, null, ep, x1, {});
  }
}
const {
  SvelteComponent: tp,
  append_hydration: np,
  attr: Ln,
  children: As,
  claim_svg_element: $s,
  detach: eo,
  init: lp,
  insert_hydration: ip,
  noop: to,
  safe_not_equal: ap,
  svg_element: Ss
} = window.__gradio__svelte__internal;
function op(l) {
  let e, t;
  return {
    c() {
      e = Ss("svg"), t = Ss("path"), this.h();
    },
    l(n) {
      e = $s(n, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0
      });
      var i = As(e);
      t = $s(i, "path", { d: !0, fill: !0 }), As(t).forEach(eo), i.forEach(eo), this.h();
    },
    h() {
      Ln(t, "d", "M2.25 8.11523H4.5V10.3652C4.5003 10.6635 4.61892 10.9495 4.82983 11.1604C5.04075 11.3713 5.32672 11.4899 5.625 11.4902H6.42488C6.60519 11.4895 6.77926 11.4241 6.91549 11.3059C7.05172 11.1878 7.14109 11.0248 7.16737 10.8464L7.48425 8.62748L8.82562 6.61523H11.25V1.36523H3.375C2.67911 1.36623 2.01201 1.64311 1.51994 2.13517C1.02787 2.62724 0.750992 3.29435 0.75 3.99023V6.61523C0.750496 7.01291 0.908691 7.39415 1.18989 7.67535C1.47109 7.95654 1.85233 8.11474 2.25 8.11523ZM9 2.11523H10.5V5.86523H9V2.11523ZM1.5 3.99023C1.5006 3.49314 1.69833 3.01657 2.04983 2.66507C2.40133 2.31356 2.8779 2.11583 3.375 2.11523H8.25V6.12661L6.76575 8.35298L6.4245 10.7402H5.625C5.52554 10.7402 5.43016 10.7007 5.35983 10.6304C5.28951 10.5601 5.25 10.4647 5.25 10.3652V7.36523H2.25C2.05118 7.36494 1.86059 7.28582 1.72 7.14524C1.57941 7.00465 1.5003 6.81406 1.5 6.61523V3.99023Z"), Ln(t, "fill", "currentColor"), Ln(e, "width", "100%"), Ln(e, "height", "100%"), Ln(e, "viewBox", "0 0 12 12"), Ln(e, "fill", "none"), Ln(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(n, i) {
      ip(n, e, i), np(e, t);
    },
    p: to,
    i: to,
    o: to,
    d(n) {
      n && eo(e);
    }
  };
}
class Bs extends tp {
  constructor(e) {
    super(), lp(this, e, null, op, ap, {});
  }
}
const {
  SvelteComponent: rp,
  append_hydration: sp,
  attr: zn,
  children: qs,
  claim_svg_element: Ts,
  detach: no,
  init: up,
  insert_hydration: _p,
  noop: lo,
  safe_not_equal: cp,
  svg_element: Is
} = window.__gradio__svelte__internal;
function fp(l) {
  let e, t;
  return {
    c() {
      e = Is("svg"), t = Is("path"), this.h();
    },
    l(n) {
      e = Ts(n, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0
      });
      var i = qs(e);
      t = Ts(i, "path", { d: !0, fill: !0 }), qs(t).forEach(no), i.forEach(no), this.h();
    },
    h() {
      zn(t, "d", "M0.75 6.24023H2.625V11.4902H0.75V6.24023ZM8.625 11.4902H3.375V5.93911L4.51575 4.22798L4.83263 2.00911C4.85892 1.83065 4.94834 1.66754 5.08465 1.5494C5.22096 1.43125 5.39512 1.36591 5.5755 1.36523H5.625C5.92328 1.36553 6.20925 1.48415 6.42017 1.69507C6.63108 1.90598 6.7497 2.19196 6.75 2.49023V4.74023H9.75C10.1477 4.74073 10.5289 4.89893 10.8101 5.18012C11.0913 5.46132 11.2495 5.84256 11.25 6.24023V8.86523C11.249 9.56112 10.9721 10.2282 10.4801 10.7203C9.98799 11.2124 9.32089 11.4892 8.625 11.4902Z"), zn(t, "fill", "currentColor"), zn(e, "width", "100%"), zn(e, "height", "100%"), zn(e, "viewBox", "0 0 12 12"), zn(e, "fill", "none"), zn(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(n, i) {
      _p(n, e, i), sp(e, t);
    },
    p: lo,
    i: lo,
    o: lo,
    d(n) {
      n && no(e);
    }
  };
}
class Ls extends rp {
  constructor(e) {
    super(), up(this, e, null, fp, cp, {});
  }
}
const {
  SvelteComponent: dp,
  append_hydration: hp,
  attr: Mn,
  children: zs,
  claim_svg_element: Ms,
  detach: io,
  init: mp,
  insert_hydration: pp,
  noop: ao,
  safe_not_equal: gp,
  svg_element: Rs
} = window.__gradio__svelte__internal;
function bp(l) {
  let e, t;
  return {
    c() {
      e = Rs("svg"), t = Rs("path"), this.h();
    },
    l(n) {
      e = Ms(n, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0
      });
      var i = zs(e);
      t = Ms(i, "path", { d: !0, fill: !0 }), zs(t).forEach(io), i.forEach(io), this.h();
    },
    h() {
      Mn(t, "d", "M9.75 4.74023H7.5V2.49023C7.4997 2.19196 7.38108 1.90598 7.17017 1.69507C6.95925 1.48415 6.67328 1.36553 6.375 1.36523H5.57512C5.39481 1.366 5.22074 1.43138 5.08451 1.54952C4.94828 1.66766 4.85891 1.83072 4.83262 2.00911L4.51575 4.22798L3.17438 6.24023H0.75V11.4902H8.625C9.32089 11.4892 9.98799 11.2124 10.4801 10.7203C10.9721 10.2282 11.249 9.56112 11.25 8.86523V6.24023C11.2495 5.84256 11.0913 5.46132 10.8101 5.18012C10.5289 4.89893 10.1477 4.74073 9.75 4.74023ZM3 10.7402H1.5V6.99023H3V10.7402ZM10.5 8.86523C10.4994 9.36233 10.3017 9.8389 9.95017 10.1904C9.59867 10.5419 9.1221 10.7396 8.625 10.7402H3.75V6.72886L5.23425 4.50248L5.5755 2.11523H6.375C6.47446 2.11523 6.56984 2.15474 6.64017 2.22507C6.71049 2.2954 6.75 2.39078 6.75 2.49023V5.49023H9.75C9.94882 5.49053 10.1394 5.56965 10.28 5.71023C10.4206 5.85082 10.4997 6.04141 10.5 6.24023V8.86523Z"), Mn(t, "fill", "currentColor"), Mn(e, "width", "100%"), Mn(e, "height", "100%"), Mn(e, "viewBox", "0 0 12 12"), Mn(e, "fill", "none"), Mn(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(n, i) {
      pp(n, e, i), hp(e, t);
    },
    p: ao,
    i: ao,
    o: ao,
    d(n) {
      n && io(e);
    }
  };
}
class Ns extends dp {
  constructor(e) {
    super(), mp(this, e, null, bp, gp, {});
  }
}
const {
  SvelteComponent: vp,
  append_hydration: wp,
  attr: ol,
  children: Os,
  claim_svg_element: Hs,
  detach: oo,
  init: kp,
  insert_hydration: Dp,
  noop: ro,
  safe_not_equal: yp,
  svg_element: Ps
} = window.__gradio__svelte__internal;
function Fp(l) {
  let e, t;
  return {
    c() {
      e = Ps("svg"), t = Ps("path"), this.h();
    },
    l(n) {
      e = Hs(n, "svg", {
        id: !0,
        xmlns: !0,
        viewBox: !0,
        fill: !0
      });
      var i = Os(e);
      t = Hs(i, "path", { fill: !0, d: !0 }), Os(t).forEach(oo), i.forEach(oo), this.h();
    },
    h() {
      ol(t, "fill", "currentColor"), ol(t, "d", "M6,30H4V2H28l-5.8,9L28,20H6ZM6,18H24.33L19.8,11l4.53-7H6Z"), ol(e, "id", "icon"), ol(e, "xmlns", "http://www.w3.org/2000/svg"), ol(e, "viewBox", "0 0 32 32"), ol(e, "fill", "none");
    },
    m(n, i) {
      Dp(n, e, i), wp(e, t);
    },
    p: ro,
    i: ro,
    o: ro,
    d(n) {
      n && oo(e);
    }
  };
}
class Vs extends vp {
  constructor(e) {
    super(), kp(this, e, null, Fp, yp, {});
  }
}
const {
  SvelteComponent: Ep,
  append_hydration: Cp,
  attr: rl,
  children: js,
  claim_svg_element: Us,
  detach: so,
  init: Ap,
  insert_hydration: $p,
  noop: uo,
  safe_not_equal: Sp,
  svg_element: Gs
} = window.__gradio__svelte__internal;
function Bp(l) {
  let e, t;
  return {
    c() {
      e = Gs("svg"), t = Gs("path"), this.h();
    },
    l(n) {
      e = Us(n, "svg", {
        id: !0,
        xmlns: !0,
        viewBox: !0,
        fill: !0
      });
      var i = js(e);
      t = Us(i, "path", { fill: !0, d: !0 }), js(t).forEach(so), i.forEach(so), this.h();
    },
    h() {
      rl(t, "fill", "currentColor"), rl(t, "d", "M4,2H28l-5.8,9L28,20H6v10H4V2z"), rl(e, "id", "icon"), rl(e, "xmlns", "http://www.w3.org/2000/svg"), rl(e, "viewBox", "0 0 32 32"), rl(e, "fill", "none");
    },
    m(n, i) {
      $p(n, e, i), Cp(e, t);
    },
    p: uo,
    i: uo,
    o: uo,
    d(n) {
      n && so(e);
    }
  };
}
class Zs extends Ep {
  constructor(e) {
    super(), Ap(this, e, null, Bp, Sp, {});
  }
}
const {
  SvelteComponent: qp,
  append_hydration: Ao,
  attr: $o,
  check_outros: Bi,
  children: So,
  claim_component: xo,
  claim_element: Bo,
  claim_space: er,
  claim_text: Tp,
  create_component: tr,
  destroy_component: nr,
  destroy_each: Ip,
  detach: Xt,
  element: qo,
  empty: qi,
  ensure_array_like: Ws,
  group_outros: Ti,
  init: Lp,
  insert_hydration: pl,
  listen: zp,
  mount_component: lr,
  safe_not_equal: Mp,
  set_data: Rp,
  set_style: Xs,
  space: ir,
  text: Np,
  transition_in: Ge,
  transition_out: Ct
} = window.__gradio__svelte__internal;
function Ks(l, e, t) {
  const n = l.slice();
  return n[9] = e[t], n;
}
function Ys(l) {
  let e = (
    /*feedback_options*/
    l[3].includes("Dislike")
  ), t, n = (
    /*feedback_options*/
    l[3].includes("Like")
  ), i, a, r = e && Qs(l), o = n && Js(l);
  return {
    c() {
      r && r.c(), t = ir(), o && o.c(), i = qi();
    },
    l(s) {
      r && r.l(s), t = er(s), o && o.l(s), i = qi();
    },
    m(s, u) {
      r && r.m(s, u), pl(s, t, u), o && o.m(s, u), pl(s, i, u), a = !0;
    },
    p(s, u) {
      u & /*feedback_options*/
      8 && (e = /*feedback_options*/
      s[3].includes("Dislike")), e ? r ? (r.p(s, u), u & /*feedback_options*/
      8 && Ge(r, 1)) : (r = Qs(s), r.c(), Ge(r, 1), r.m(t.parentNode, t)) : r && (Ti(), Ct(r, 1, 1, () => {
        r = null;
      }), Bi()), u & /*feedback_options*/
      8 && (n = /*feedback_options*/
      s[3].includes("Like")), n ? o ? (o.p(s, u), u & /*feedback_options*/
      8 && Ge(o, 1)) : (o = Js(s), o.c(), Ge(o, 1), o.m(i.parentNode, i)) : o && (Ti(), Ct(o, 1, 1, () => {
        o = null;
      }), Bi());
    },
    i(s) {
      a || (Ge(r), Ge(o), a = !0);
    },
    o(s) {
      Ct(r), Ct(o), a = !1;
    },
    d(s) {
      s && (Xt(t), Xt(i)), r && r.d(s), o && o.d(s);
    }
  };
}
function Qs(l) {
  let e, t;
  return e = new Re({
    props: {
      Icon: (
        /*selected*/
        l[0] === "Dislike" ? Cs : Bs
      ),
      label: (
        /*selected*/
        l[0] === "Dislike" ? "clicked dislike" : (
          /*i18n*/
          l[1]("chatbot.dislike")
        )
      ),
      color: (
        /*selected*/
        l[0] === "Dislike" ? "var(--color-accent)" : "var(--block-label-text-color)"
      )
    }
  }), e.$on(
    "click",
    /*click_handler*/
    l[6]
  ), {
    c() {
      tr(e.$$.fragment);
    },
    l(n) {
      xo(e.$$.fragment, n);
    },
    m(n, i) {
      lr(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*selected*/
      1 && (a.Icon = /*selected*/
      n[0] === "Dislike" ? Cs : Bs), i & /*selected, i18n*/
      3 && (a.label = /*selected*/
      n[0] === "Dislike" ? "clicked dislike" : (
        /*i18n*/
        n[1]("chatbot.dislike")
      )), i & /*selected*/
      1 && (a.color = /*selected*/
      n[0] === "Dislike" ? "var(--color-accent)" : "var(--block-label-text-color)"), e.$set(a);
    },
    i(n) {
      t || (Ge(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ct(e.$$.fragment, n), t = !1;
    },
    d(n) {
      nr(e, n);
    }
  };
}
function Js(l) {
  let e, t;
  return e = new Re({
    props: {
      Icon: (
        /*selected*/
        l[0] === "Like" ? Ls : Ns
      ),
      label: (
        /*selected*/
        l[0] === "Like" ? "clicked like" : (
          /*i18n*/
          l[1]("chatbot.like")
        )
      ),
      color: (
        /*selected*/
        l[0] === "Like" ? "var(--color-accent)" : "var(--block-label-text-color)"
      )
    }
  }), e.$on(
    "click",
    /*click_handler_1*/
    l[7]
  ), {
    c() {
      tr(e.$$.fragment);
    },
    l(n) {
      xo(e.$$.fragment, n);
    },
    m(n, i) {
      lr(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*selected*/
      1 && (a.Icon = /*selected*/
      n[0] === "Like" ? Ls : Ns), i & /*selected, i18n*/
      3 && (a.label = /*selected*/
      n[0] === "Like" ? "clicked like" : (
        /*i18n*/
        n[1]("chatbot.like")
      )), i & /*selected*/
      1 && (a.color = /*selected*/
      n[0] === "Like" ? "var(--color-accent)" : "var(--block-label-text-color)"), e.$set(a);
    },
    i(n) {
      t || (Ge(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ct(e.$$.fragment, n), t = !1;
    },
    d(n) {
      nr(e, n);
    }
  };
}
function xs(l) {
  let e, t, n, i, a;
  t = new Re({
    props: {
      Icon: (
        /*selected*/
        l[0] && /*extra_feedback*/
        l[4].includes(
          /*selected*/
          l[0]
        ) ? Zs : Vs
      ),
      label: "Feedback",
      color: (
        /*selected*/
        l[0] && /*extra_feedback*/
        l[4].includes(
          /*selected*/
          l[0]
        ) ? "var(--color-accent)" : "var(--block-label-text-color)"
      )
    }
  });
  let r = Ws(
    /*extra_feedback*/
    l[4]
  ), o = [];
  for (let s = 0; s < r.length; s += 1)
    o[s] = eu(Ks(l, r, s));
  return {
    c() {
      e = qo("div"), tr(t.$$.fragment), n = ir(), i = qo("div");
      for (let s = 0; s < o.length; s += 1)
        o[s].c();
      this.h();
    },
    l(s) {
      e = Bo(s, "DIV", { class: !0 });
      var u = So(e);
      xo(t.$$.fragment, u), n = er(u), i = Bo(u, "DIV", { class: !0 });
      var c = So(i);
      for (let f = 0; f < o.length; f += 1)
        o[f].l(c);
      c.forEach(Xt), u.forEach(Xt), this.h();
    },
    h() {
      $o(i, "class", "extra-feedback-options svelte-w8k080"), $o(e, "class", "extra-feedback no-border svelte-w8k080");
    },
    m(s, u) {
      pl(s, e, u), lr(t, e, null), Ao(e, n), Ao(e, i);
      for (let c = 0; c < o.length; c += 1)
        o[c] && o[c].m(i, null);
      a = !0;
    },
    p(s, u) {
      const c = {};
      if (u & /*selected, extra_feedback*/
      17 && (c.Icon = /*selected*/
      s[0] && /*extra_feedback*/
      s[4].includes(
        /*selected*/
        s[0]
      ) ? Zs : Vs), u & /*selected, extra_feedback*/
      17 && (c.color = /*selected*/
      s[0] && /*extra_feedback*/
      s[4].includes(
        /*selected*/
        s[0]
      ) ? "var(--color-accent)" : "var(--block-label-text-color)"), t.$set(c), u & /*selected, extra_feedback, toggleSelection, handle_action*/
      53) {
        r = Ws(
          /*extra_feedback*/
          s[4]
        );
        let f;
        for (f = 0; f < r.length; f += 1) {
          const _ = Ks(s, r, f);
          o[f] ? o[f].p(_, u) : (o[f] = eu(_), o[f].c(), o[f].m(i, null));
        }
        for (; f < o.length; f += 1)
          o[f].d(1);
        o.length = r.length;
      }
    },
    i(s) {
      a || (Ge(t.$$.fragment, s), a = !0);
    },
    o(s) {
      Ct(t.$$.fragment, s), a = !1;
    },
    d(s) {
      s && Xt(e), nr(t), Ip(o, s);
    }
  };
}
function eu(l) {
  let e, t = (
    /*option*/
    l[9] + ""
  ), n, i, a;
  function r() {
    return (
      /*click_handler_2*/
      l[8](
        /*option*/
        l[9]
      )
    );
  }
  return {
    c() {
      e = qo("button"), n = Np(t), this.h();
    },
    l(o) {
      e = Bo(o, "BUTTON", { class: !0 });
      var s = So(e);
      n = Tp(s, t), s.forEach(Xt), this.h();
    },
    h() {
      $o(e, "class", "extra-feedback-option svelte-w8k080"), Xs(
        e,
        "font-weight",
        /*selected*/
        l[0] === /*option*/
        l[9] ? "bold" : "normal"
      );
    },
    m(o, s) {
      pl(o, e, s), Ao(e, n), i || (a = zp(e, "click", r), i = !0);
    },
    p(o, s) {
      l = o, s & /*extra_feedback*/
      16 && t !== (t = /*option*/
      l[9] + "") && Rp(n, t), s & /*selected, extra_feedback*/
      17 && Xs(
        e,
        "font-weight",
        /*selected*/
        l[0] === /*option*/
        l[9] ? "bold" : "normal"
      );
    },
    d(o) {
      o && Xt(e), i = !1, a();
    }
  };
}
function Op(l) {
  let e = (
    /*feedback_options*/
    l[3].includes("Like") || /*feedback_options*/
    l[3].includes("Dislike")
  ), t, n, i, a = e && Ys(l), r = (
    /*extra_feedback*/
    l[4].length > 0 && xs(l)
  );
  return {
    c() {
      a && a.c(), t = ir(), r && r.c(), n = qi();
    },
    l(o) {
      a && a.l(o), t = er(o), r && r.l(o), n = qi();
    },
    m(o, s) {
      a && a.m(o, s), pl(o, t, s), r && r.m(o, s), pl(o, n, s), i = !0;
    },
    p(o, [s]) {
      s & /*feedback_options*/
      8 && (e = /*feedback_options*/
      o[3].includes("Like") || /*feedback_options*/
      o[3].includes("Dislike")), e ? a ? (a.p(o, s), s & /*feedback_options*/
      8 && Ge(a, 1)) : (a = Ys(o), a.c(), Ge(a, 1), a.m(t.parentNode, t)) : a && (Ti(), Ct(a, 1, 1, () => {
        a = null;
      }), Bi()), /*extra_feedback*/
      o[4].length > 0 ? r ? (r.p(o, s), s & /*extra_feedback*/
      16 && Ge(r, 1)) : (r = xs(o), r.c(), Ge(r, 1), r.m(n.parentNode, n)) : r && (Ti(), Ct(r, 1, 1, () => {
        r = null;
      }), Bi());
    },
    i(o) {
      i || (Ge(a), Ge(r), i = !0);
    },
    o(o) {
      Ct(a), Ct(r), i = !1;
    },
    d(o) {
      o && (Xt(t), Xt(n)), a && a.d(o), r && r.d(o);
    }
  };
}
function Hp(l, e, t) {
  let n, { i18n: i } = e, { handle_action: a } = e, { feedback_options: r } = e, { selected: o = null } = e;
  function s(_) {
    t(0, o = o === _ ? null : _), a(o);
  }
  const u = () => s("Dislike"), c = () => s("Like"), f = (_) => {
    s(_), a(o || null);
  };
  return l.$$set = (_) => {
    "i18n" in _ && t(1, i = _.i18n), "handle_action" in _ && t(2, a = _.handle_action), "feedback_options" in _ && t(3, r = _.feedback_options), "selected" in _ && t(0, o = _.selected);
  }, l.$$.update = () => {
    l.$$.dirty & /*feedback_options*/
    8 && t(4, n = r.filter((_) => _ !== "Like" && _ !== "Dislike"));
  }, [
    o,
    i,
    a,
    r,
    n,
    s,
    u,
    c,
    f
  ];
}
class Pp extends qp {
  constructor(e) {
    super(), Lp(this, e, Hp, Op, Mp, {
      i18n: 1,
      handle_action: 2,
      feedback_options: 3,
      selected: 0
    });
  }
}
const {
  SvelteComponent: Vp,
  claim_component: jp,
  create_component: Up,
  destroy_component: Gp,
  init: Zp,
  mount_component: Wp,
  safe_not_equal: Xp,
  transition_in: Kp,
  transition_out: Yp
} = window.__gradio__svelte__internal, { createEventDispatcher: Qp } = window.__gradio__svelte__internal, { onDestroy: Jp } = window.__gradio__svelte__internal;
function xp(l) {
  let e, t;
  return e = new Re({
    props: {
      label: (
        /*copied*/
        l[0] ? "Copied message" : "Copy message"
      ),
      Icon: (
        /*copied*/
        l[0] ? Rl : Si
      )
    }
  }), e.$on(
    "click",
    /*handle_copy*/
    l[1]
  ), {
    c() {
      Up(e.$$.fragment);
    },
    l(n) {
      jp(e.$$.fragment, n);
    },
    m(n, i) {
      Wp(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*copied*/
      1 && (a.label = /*copied*/
      n[0] ? "Copied message" : "Copy message"), i & /*copied*/
      1 && (a.Icon = /*copied*/
      n[0] ? Rl : Si), e.$set(a);
    },
    i(n) {
      t || (Kp(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Yp(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Gp(e, n);
    }
  };
}
function e0(l, e, t) {
  var n = this && this.__awaiter || function(f, _, d, h) {
    function p(v) {
      return v instanceof d ? v : new d(function(D) {
        D(v);
      });
    }
    return new (d || (d = Promise))(function(v, D) {
      function w(k) {
        try {
          g(h.next(k));
        } catch (b) {
          D(b);
        }
      }
      function m(k) {
        try {
          g(h.throw(k));
        } catch (b) {
          D(b);
        }
      }
      function g(k) {
        k.done ? v(k.value) : p(k.value).then(w, m);
      }
      g((h = h.apply(f, _ || [])).next());
    });
  };
  const i = Qp();
  let a = !1, { value: r } = e, { watermark: o = null } = e, s;
  function u() {
    t(0, a = !0), s && clearTimeout(s), s = setTimeout(
      () => {
        t(0, a = !1);
      },
      2e3
    );
  }
  function c() {
    return n(this, void 0, void 0, function* () {
      if ("clipboard" in navigator) {
        i("copy", { value: r });
        const f = o ? `${r}

${o}` : r;
        yield navigator.clipboard.writeText(f), u();
      } else {
        const f = document.createElement("textarea"), _ = o ? `${r}

${o}` : r;
        f.value = _, f.style.position = "absolute", f.style.left = "-999999px", document.body.prepend(f), f.select();
        try {
          document.execCommand("copy"), u();
        } catch (d) {
          console.error(d);
        } finally {
          f.remove();
        }
      }
    });
  }
  return Jp(() => {
    s && clearTimeout(s);
  }), l.$$set = (f) => {
    "value" in f && t(2, r = f.value), "watermark" in f && t(3, o = f.watermark);
  }, [a, c, r, o];
}
class t0 extends Vp {
  constructor(e) {
    super(), Zp(this, e, e0, xp, Xp, { value: 2, watermark: 3 });
  }
}
const {
  SvelteComponent: n0,
  attr: tu,
  check_outros: Hn,
  children: l0,
  claim_component: bn,
  claim_element: i0,
  claim_space: Sl,
  create_component: vn,
  destroy_component: wn,
  detach: Mt,
  element: a0,
  empty: gl,
  group_outros: Pn,
  init: o0,
  insert_hydration: Gt,
  mount_component: kn,
  safe_not_equal: r0,
  space: Bl,
  transition_in: Z,
  transition_out: fe
} = window.__gradio__svelte__internal;
function nu(l) {
  let e, t, n, i;
  return t = new pc({
    props: {
      top_panel: !1,
      $$slots: { default: [_0] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      e = a0("div"), vn(t.$$.fragment), this.h();
    },
    l(a) {
      e = i0(a, "DIV", { class: !0 });
      var r = l0(e);
      bn(t.$$.fragment, r), r.forEach(Mt), this.h();
    },
    h() {
      tu(e, "class", n = "message-buttons-" + /*position*/
      l[8] + " " + /*layout*/
      l[13] + " message-buttons " + /*avatar*/
      (l[9] !== null && "with-avatar") + " svelte-pa8ton");
    },
    m(a, r) {
      Gt(a, e, r), kn(t, e, null), i = !0;
    },
    p(a, r) {
      const o = {};
      r & /*$$scope, i18n, generating, handle_action, in_edit_mode, feedback_options, current_feedback, likeable, show_edit, show_undo, show_retry, message_text, watermark, dispatch, show_copy*/
      33676543 && (o.$$scope = { dirty: r, ctx: a }), t.$set(o), (!i || r & /*position, layout, avatar*/
      8960 && n !== (n = "message-buttons-" + /*position*/
      a[8] + " " + /*layout*/
      a[13] + " message-buttons " + /*avatar*/
      (a[9] !== null && "with-avatar") + " svelte-pa8ton")) && tu(e, "class", n);
    },
    i(a) {
      i || (Z(t.$$.fragment, a), i = !0);
    },
    o(a) {
      fe(t.$$.fragment, a), i = !1;
    },
    d(a) {
      a && Mt(e), wn(t);
    }
  };
}
function s0(l) {
  let e, t, n, i, a, r, o = (
    /*show_copy*/
    l[15] && lu(l)
  ), s = (
    /*show_retry*/
    l[3] && iu(l)
  ), u = (
    /*show_undo*/
    l[4] && au(l)
  ), c = (
    /*show_edit*/
    l[5] && ou(l)
  ), f = (
    /*likeable*/
    l[1] && ru(l)
  );
  return {
    c() {
      o && o.c(), e = Bl(), s && s.c(), t = Bl(), u && u.c(), n = Bl(), c && c.c(), i = Bl(), f && f.c(), a = gl();
    },
    l(_) {
      o && o.l(_), e = Sl(_), s && s.l(_), t = Sl(_), u && u.l(_), n = Sl(_), c && c.l(_), i = Sl(_), f && f.l(_), a = gl();
    },
    m(_, d) {
      o && o.m(_, d), Gt(_, e, d), s && s.m(_, d), Gt(_, t, d), u && u.m(_, d), Gt(_, n, d), c && c.m(_, d), Gt(_, i, d), f && f.m(_, d), Gt(_, a, d), r = !0;
    },
    p(_, d) {
      /*show_copy*/
      _[15] ? o ? (o.p(_, d), d & /*show_copy*/
      32768 && Z(o, 1)) : (o = lu(_), o.c(), Z(o, 1), o.m(e.parentNode, e)) : o && (Pn(), fe(o, 1, 1, () => {
        o = null;
      }), Hn()), /*show_retry*/
      _[3] ? s ? (s.p(_, d), d & /*show_retry*/
      8 && Z(s, 1)) : (s = iu(_), s.c(), Z(s, 1), s.m(t.parentNode, t)) : s && (Pn(), fe(s, 1, 1, () => {
        s = null;
      }), Hn()), /*show_undo*/
      _[4] ? u ? (u.p(_, d), d & /*show_undo*/
      16 && Z(u, 1)) : (u = au(_), u.c(), Z(u, 1), u.m(n.parentNode, n)) : u && (Pn(), fe(u, 1, 1, () => {
        u = null;
      }), Hn()), /*show_edit*/
      _[5] ? c ? (c.p(_, d), d & /*show_edit*/
      32 && Z(c, 1)) : (c = ou(_), c.c(), Z(c, 1), c.m(i.parentNode, i)) : c && (Pn(), fe(c, 1, 1, () => {
        c = null;
      }), Hn()), /*likeable*/
      _[1] ? f ? (f.p(_, d), d & /*likeable*/
      2 && Z(f, 1)) : (f = ru(_), f.c(), Z(f, 1), f.m(a.parentNode, a)) : f && (Pn(), fe(f, 1, 1, () => {
        f = null;
      }), Hn());
    },
    i(_) {
      r || (Z(o), Z(s), Z(u), Z(c), Z(f), r = !0);
    },
    o(_) {
      fe(o), fe(s), fe(u), fe(c), fe(f), r = !1;
    },
    d(_) {
      _ && (Mt(e), Mt(t), Mt(n), Mt(i), Mt(a)), o && o.d(_), s && s.d(_), u && u.d(_), c && c.d(_), f && f.d(_);
    }
  };
}
function u0(l) {
  let e, t, n, i;
  return e = new Re({
    props: {
      label: (
        /*i18n*/
        l[0]("chatbot.submit")
      ),
      Icon: Rl,
      disabled: (
        /*generating*/
        l[10]
      )
    }
  }), e.$on(
    "click",
    /*click_handler*/
    l[19]
  ), n = new Re({
    props: {
      label: (
        /*i18n*/
        l[0]("chatbot.cancel")
      ),
      Icon: Qo,
      disabled: (
        /*generating*/
        l[10]
      )
    }
  }), n.$on(
    "click",
    /*click_handler_1*/
    l[20]
  ), {
    c() {
      vn(e.$$.fragment), t = Bl(), vn(n.$$.fragment);
    },
    l(a) {
      bn(e.$$.fragment, a), t = Sl(a), bn(n.$$.fragment, a);
    },
    m(a, r) {
      kn(e, a, r), Gt(a, t, r), kn(n, a, r), i = !0;
    },
    p(a, r) {
      const o = {};
      r & /*i18n*/
      1 && (o.label = /*i18n*/
      a[0]("chatbot.submit")), r & /*generating*/
      1024 && (o.disabled = /*generating*/
      a[10]), e.$set(o);
      const s = {};
      r & /*i18n*/
      1 && (s.label = /*i18n*/
      a[0]("chatbot.cancel")), r & /*generating*/
      1024 && (s.disabled = /*generating*/
      a[10]), n.$set(s);
    },
    i(a) {
      i || (Z(e.$$.fragment, a), Z(n.$$.fragment, a), i = !0);
    },
    o(a) {
      fe(e.$$.fragment, a), fe(n.$$.fragment, a), i = !1;
    },
    d(a) {
      a && Mt(t), wn(e, a), wn(n, a);
    }
  };
}
function lu(l) {
  let e, t;
  return e = new t0({
    props: {
      value: (
        /*message_text*/
        l[16]
      ),
      watermark: (
        /*watermark*/
        l[7]
      )
    }
  }), e.$on(
    "copy",
    /*copy_handler*/
    l[21]
  ), {
    c() {
      vn(e.$$.fragment);
    },
    l(n) {
      bn(e.$$.fragment, n);
    },
    m(n, i) {
      kn(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*message_text*/
      65536 && (a.value = /*message_text*/
      n[16]), i & /*watermark*/
      128 && (a.watermark = /*watermark*/
      n[7]), e.$set(a);
    },
    i(n) {
      t || (Z(e.$$.fragment, n), t = !0);
    },
    o(n) {
      fe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      wn(e, n);
    }
  };
}
function iu(l) {
  let e, t;
  return e = new Re({
    props: {
      Icon: C1,
      label: (
        /*i18n*/
        l[0]("chatbot.retry")
      ),
      disabled: (
        /*generating*/
        l[10]
      )
    }
  }), e.$on(
    "click",
    /*click_handler_2*/
    l[22]
  ), {
    c() {
      vn(e.$$.fragment);
    },
    l(n) {
      bn(e.$$.fragment, n);
    },
    m(n, i) {
      kn(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*i18n*/
      1 && (a.label = /*i18n*/
      n[0]("chatbot.retry")), i & /*generating*/
      1024 && (a.disabled = /*generating*/
      n[10]), e.$set(a);
    },
    i(n) {
      t || (Z(e.$$.fragment, n), t = !0);
    },
    o(n) {
      fe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      wn(e, n);
    }
  };
}
function au(l) {
  let e, t;
  return e = new Re({
    props: {
      label: (
        /*i18n*/
        l[0]("chatbot.undo")
      ),
      Icon: w1,
      disabled: (
        /*generating*/
        l[10]
      )
    }
  }), e.$on(
    "click",
    /*click_handler_3*/
    l[23]
  ), {
    c() {
      vn(e.$$.fragment);
    },
    l(n) {
      bn(e.$$.fragment, n);
    },
    m(n, i) {
      kn(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*i18n*/
      1 && (a.label = /*i18n*/
      n[0]("chatbot.undo")), i & /*generating*/
      1024 && (a.disabled = /*generating*/
      n[10]), e.$set(a);
    },
    i(n) {
      t || (Z(e.$$.fragment, n), t = !0);
    },
    o(n) {
      fe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      wn(e, n);
    }
  };
}
function ou(l) {
  let e, t;
  return e = new Re({
    props: {
      label: (
        /*i18n*/
        l[0]("chatbot.edit")
      ),
      Icon: Ym,
      disabled: (
        /*generating*/
        l[10]
      )
    }
  }), e.$on(
    "click",
    /*click_handler_4*/
    l[24]
  ), {
    c() {
      vn(e.$$.fragment);
    },
    l(n) {
      bn(e.$$.fragment, n);
    },
    m(n, i) {
      kn(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*i18n*/
      1 && (a.label = /*i18n*/
      n[0]("chatbot.edit")), i & /*generating*/
      1024 && (a.disabled = /*generating*/
      n[10]), e.$set(a);
    },
    i(n) {
      t || (Z(e.$$.fragment, n), t = !0);
    },
    o(n) {
      fe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      wn(e, n);
    }
  };
}
function ru(l) {
  let e, t;
  return e = new Pp({
    props: {
      handle_action: (
        /*handle_action*/
        l[12]
      ),
      feedback_options: (
        /*feedback_options*/
        l[2]
      ),
      selected: (
        /*current_feedback*/
        l[11]
      ),
      i18n: (
        /*i18n*/
        l[0]
      )
    }
  }), {
    c() {
      vn(e.$$.fragment);
    },
    l(n) {
      bn(e.$$.fragment, n);
    },
    m(n, i) {
      kn(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*handle_action*/
      4096 && (a.handle_action = /*handle_action*/
      n[12]), i & /*feedback_options*/
      4 && (a.feedback_options = /*feedback_options*/
      n[2]), i & /*current_feedback*/
      2048 && (a.selected = /*current_feedback*/
      n[11]), i & /*i18n*/
      1 && (a.i18n = /*i18n*/
      n[0]), e.$set(a);
    },
    i(n) {
      t || (Z(e.$$.fragment, n), t = !0);
    },
    o(n) {
      fe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      wn(e, n);
    }
  };
}
function _0(l) {
  let e, t, n, i;
  const a = [u0, s0], r = [];
  function o(s, u) {
    return (
      /*in_edit_mode*/
      s[6] ? 0 : 1
    );
  }
  return e = o(l), t = r[e] = a[e](l), {
    c() {
      t.c(), n = gl();
    },
    l(s) {
      t.l(s), n = gl();
    },
    m(s, u) {
      r[e].m(s, u), Gt(s, n, u), i = !0;
    },
    p(s, u) {
      let c = e;
      e = o(s), e === c ? r[e].p(s, u) : (Pn(), fe(r[c], 1, 1, () => {
        r[c] = null;
      }), Hn(), t = r[e], t ? t.p(s, u) : (t = r[e] = a[e](s), t.c()), Z(t, 1), t.m(n.parentNode, n));
    },
    i(s) {
      i || (Z(t), i = !0);
    },
    o(s) {
      fe(t), i = !1;
    },
    d(s) {
      s && Mt(n), r[e].d(s);
    }
  };
}
function c0(l) {
  let e, t, n = (
    /*show_copy*/
    (l[15] || /*show_retry*/
    l[3] || /*show_undo*/
    l[4] || /*show_edit*/
    l[5] || /*likeable*/
    l[1]) && nu(l)
  );
  return {
    c() {
      n && n.c(), e = gl();
    },
    l(i) {
      n && n.l(i), e = gl();
    },
    m(i, a) {
      n && n.m(i, a), Gt(i, e, a), t = !0;
    },
    p(i, [a]) {
      /*show_copy*/
      i[15] || /*show_retry*/
      i[3] || /*show_undo*/
      i[4] || /*show_edit*/
      i[5] || /*likeable*/
      i[1] ? n ? (n.p(i, a), a & /*show_copy, show_retry, show_undo, show_edit, likeable*/
      32826 && Z(n, 1)) : (n = nu(i), n.c(), Z(n, 1), n.m(e.parentNode, e)) : n && (Pn(), fe(n, 1, 1, () => {
        n = null;
      }), Hn());
    },
    i(i) {
      t || (Z(n), t = !0);
    },
    o(i) {
      fe(n), t = !1;
    },
    d(i) {
      i && Mt(e), n && n.d(i);
    }
  };
}
function f0(l, e, t) {
  let n, i, { i18n: a } = e, { likeable: r } = e, { feedback_options: o } = e, { show_retry: s } = e, { show_undo: u } = e, { show_edit: c } = e, { in_edit_mode: f } = e, { show_copy_button: _ } = e, { watermark: d = null } = e, { message: h } = e, { position: p } = e, { avatar: v } = e, { generating: D } = e, { current_feedback: w } = e, { handle_action: m } = e, { layout: g } = e, { dispatch: k } = e;
  const b = () => m("edit_submit"), y = () => m("edit_cancel"), C = (S) => k("copy", S.detail), F = () => m("retry"), B = () => m("undo"), I = () => m("edit");
  return l.$$set = (S) => {
    "i18n" in S && t(0, a = S.i18n), "likeable" in S && t(1, r = S.likeable), "feedback_options" in S && t(2, o = S.feedback_options), "show_retry" in S && t(3, s = S.show_retry), "show_undo" in S && t(4, u = S.show_undo), "show_edit" in S && t(5, c = S.show_edit), "in_edit_mode" in S && t(6, f = S.in_edit_mode), "show_copy_button" in S && t(17, _ = S.show_copy_button), "watermark" in S && t(7, d = S.watermark), "message" in S && t(18, h = S.message), "position" in S && t(8, p = S.position), "avatar" in S && t(9, v = S.avatar), "generating" in S && t(10, D = S.generating), "current_feedback" in S && t(11, w = S.current_feedback), "handle_action" in S && t(12, m = S.handle_action), "layout" in S && t(13, g = S.layout), "dispatch" in S && t(14, k = S.dispatch);
  }, l.$$.update = () => {
    l.$$.dirty & /*message*/
    262144 && t(16, n = kr(h) ? tf(h) : ""), l.$$.dirty & /*show_copy_button, message*/
    393216 && t(15, i = _ && h && kr(h));
  }, [
    a,
    r,
    o,
    s,
    u,
    c,
    f,
    d,
    p,
    v,
    D,
    w,
    m,
    g,
    k,
    i,
    n,
    _,
    h,
    b,
    y,
    C,
    F,
    B,
    I
  ];
}
class gc extends n0 {
  constructor(e) {
    super(), o0(this, e, f0, c0, r0, {
      i18n: 0,
      likeable: 1,
      feedback_options: 2,
      show_retry: 3,
      show_undo: 4,
      show_edit: 5,
      in_edit_mode: 6,
      show_copy_button: 17,
      watermark: 7,
      message: 18,
      position: 8,
      avatar: 9,
      generating: 10,
      current_feedback: 11,
      handle_action: 12,
      layout: 13,
      dispatch: 14
    });
  }
}
const {
  SvelteComponent: d0,
  assign: Ne,
  attr: h0,
  bubble: _n,
  check_outros: Jt,
  children: m0,
  claim_component: Fn,
  claim_element: bc,
  construct_svelte_component: Oe,
  create_component: He,
  destroy_component: Pe,
  detach: St,
  element: vc,
  empty: Ve,
  get_spread_object: Ee,
  get_spread_update: je,
  group_outros: xt,
  init: p0,
  insert_hydration: Pt,
  mount_component: Ue,
  noop: g0,
  safe_not_equal: b0,
  set_style: v0,
  transition_in: Ce,
  transition_out: Ae
} = window.__gradio__svelte__internal;
function w0(l) {
  let e, t, n;
  const i = [
    /*props*/
    l[5],
    { value: (
      /*value*/
      l[2]
    ) },
    {
      clear_color: (
        /*props*/
        l[5].clear_color
      )
    },
    {
      display_mode: (
        /*props*/
        l[5].display_mode
      )
    },
    { zoom_speed: (
      /*props*/
      l[5].zoom_speed
    ) },
    { pan_speed: (
      /*props*/
      l[5].pan_speed
    ) },
    /*props*/
    l[5].camera_position !== void 0 && {
      camera_position: (
        /*props*/
        l[5].camera_position
      )
    },
    { has_change_history: !0 },
    {
      show_label: (
        /*props*/
        !!l[5].label
      )
    },
    { root: "" },
    { interactive: !1 },
    { show_share_button: !0 },
    {
      gradio: { dispatch: co, i18n: (
        /*i18n*/
        l[6]
      ) }
    }
  ];
  var a = (
    /*components*/
    l[1][
      /*type*/
      l[0]
    ]
  );
  function r(o, s) {
    let u = {};
    for (let c = 0; c < i.length; c += 1)
      u = Ne(u, i[c]);
    return s !== void 0 && s & /*props, value, undefined, i18n*/
    100 && (u = Ne(u, je(i, [
      s & /*props*/
      32 && Ee(
        /*props*/
        o[5]
      ),
      s & /*value*/
      4 && { value: (
        /*value*/
        o[2]
      ) },
      s & /*props*/
      32 && {
        clear_color: (
          /*props*/
          o[5].clear_color
        )
      },
      s & /*props*/
      32 && {
        display_mode: (
          /*props*/
          o[5].display_mode
        )
      },
      s & /*props*/
      32 && { zoom_speed: (
        /*props*/
        o[5].zoom_speed
      ) },
      s & /*props*/
      32 && { pan_speed: (
        /*props*/
        o[5].pan_speed
      ) },
      s & /*props, undefined*/
      32 && Ee(
        /*props*/
        o[5].camera_position !== void 0 && {
          camera_position: (
            /*props*/
            o[5].camera_position
          )
        }
      ),
      i[7],
      s & /*props*/
      32 && {
        show_label: (
          /*props*/
          !!o[5].label
        )
      },
      i[9],
      i[10],
      i[11],
      s & /*i18n*/
      64 && {
        gradio: { dispatch: co, i18n: (
          /*i18n*/
          o[6]
        ) }
      }
    ]))), { props: u };
  }
  return a && (e = Oe(a, r(l)), e.$on(
    "load",
    /*load_handler_7*/
    l[18]
  )), {
    c() {
      e && He(e.$$.fragment), t = Ve();
    },
    l(o) {
      e && Fn(e.$$.fragment, o), t = Ve();
    },
    m(o, s) {
      e && Ue(e, o, s), Pt(o, t, s), n = !0;
    },
    p(o, s) {
      if (s & /*components, type*/
      3 && a !== (a = /*components*/
      o[1][
        /*type*/
        o[0]
      ])) {
        if (e) {
          xt();
          const u = e;
          Ae(u.$$.fragment, 1, 0, () => {
            Pe(u, 1);
          }), Jt();
        }
        a ? (e = Oe(a, r(o, s)), e.$on(
          "load",
          /*load_handler_7*/
          o[18]
        ), He(e.$$.fragment), Ce(e.$$.fragment, 1), Ue(e, t.parentNode, t)) : e = null;
      } else if (a) {
        const u = s & /*props, value, undefined, i18n*/
        100 ? je(i, [
          s & /*props*/
          32 && Ee(
            /*props*/
            o[5]
          ),
          s & /*value*/
          4 && { value: (
            /*value*/
            o[2]
          ) },
          s & /*props*/
          32 && {
            clear_color: (
              /*props*/
              o[5].clear_color
            )
          },
          s & /*props*/
          32 && {
            display_mode: (
              /*props*/
              o[5].display_mode
            )
          },
          s & /*props*/
          32 && { zoom_speed: (
            /*props*/
            o[5].zoom_speed
          ) },
          s & /*props*/
          32 && { pan_speed: (
            /*props*/
            o[5].pan_speed
          ) },
          s & /*props, undefined*/
          32 && Ee(
            /*props*/
            o[5].camera_position !== void 0 && {
              camera_position: (
                /*props*/
                o[5].camera_position
              )
            }
          ),
          i[7],
          s & /*props*/
          32 && {
            show_label: (
              /*props*/
              !!o[5].label
            )
          },
          i[9],
          i[10],
          i[11],
          s & /*i18n*/
          64 && {
            gradio: { dispatch: co, i18n: (
              /*i18n*/
              o[6]
            ) }
          }
        ]) : {};
        e.$set(u);
      }
    },
    i(o) {
      n || (e && Ce(e.$$.fragment, o), n = !0);
    },
    o(o) {
      e && Ae(e.$$.fragment, o), n = !1;
    },
    d(o) {
      o && St(t), e && Pe(e, o);
    }
  };
}
function k0(l) {
  let e, t, n;
  const i = [
    /*props*/
    l[5],
    { value: (
      /*value*/
      l[2]
    ) },
    { show_label: !1 },
    { show_share_button: !0 },
    { i18n: (
      /*i18n*/
      l[6]
    ) },
    { gradio: { dispatch: B0 } }
  ];
  var a = (
    /*components*/
    l[1][
      /*type*/
      l[0]
    ]
  );
  function r(o, s) {
    let u = {};
    for (let c = 0; c < i.length; c += 1)
      u = Ne(u, i[c]);
    return s !== void 0 && s & /*props, value, i18n*/
    100 && (u = Ne(u, je(i, [
      s & /*props*/
      32 && Ee(
        /*props*/
        o[5]
      ),
      s & /*value*/
      4 && { value: (
        /*value*/
        o[2]
      ) },
      i[2],
      i[3],
      s & /*i18n*/
      64 && { i18n: (
        /*i18n*/
        o[6]
      ) },
      i[5]
    ]))), { props: u };
  }
  return a && (e = Oe(a, r(l)), e.$on(
    "load",
    /*load_handler_6*/
    l[17]
  )), {
    c() {
      e && He(e.$$.fragment), t = Ve();
    },
    l(o) {
      e && Fn(e.$$.fragment, o), t = Ve();
    },
    m(o, s) {
      e && Ue(e, o, s), Pt(o, t, s), n = !0;
    },
    p(o, s) {
      if (s & /*components, type*/
      3 && a !== (a = /*components*/
      o[1][
        /*type*/
        o[0]
      ])) {
        if (e) {
          xt();
          const u = e;
          Ae(u.$$.fragment, 1, 0, () => {
            Pe(u, 1);
          }), Jt();
        }
        a ? (e = Oe(a, r(o, s)), e.$on(
          "load",
          /*load_handler_6*/
          o[17]
        ), He(e.$$.fragment), Ce(e.$$.fragment, 1), Ue(e, t.parentNode, t)) : e = null;
      } else if (a) {
        const u = s & /*props, value, i18n*/
        100 ? je(i, [
          s & /*props*/
          32 && Ee(
            /*props*/
            o[5]
          ),
          s & /*value*/
          4 && { value: (
            /*value*/
            o[2]
          ) },
          i[2],
          i[3],
          s & /*i18n*/
          64 && { i18n: (
            /*i18n*/
            o[6]
          ) },
          i[5]
        ]) : {};
        e.$set(u);
      }
    },
    i(o) {
      n || (e && Ce(e.$$.fragment, o), n = !0);
    },
    o(o) {
      e && Ae(e.$$.fragment, o), n = !1;
    },
    d(o) {
      o && St(t), e && Pe(e, o);
    }
  };
}
function D0(l) {
  let e, t, n;
  const i = [
    /*props*/
    l[5],
    { value: (
      /*value*/
      l[2]
    ) },
    {
      show_label: (
        /*props*/
        !!l[5].label
      )
    },
    {
      show_download_button: (
        /*allow_file_downloads*/
        l[9]
      )
    },
    {
      display_icon_button_wrapper_top_corner: (
        /*display_icon_button_wrapper_top_corner*/
        l[10]
      )
    },
    { i18n: (
      /*i18n*/
      l[6]
    ) }
  ];
  var a = (
    /*components*/
    l[1][
      /*type*/
      l[0]
    ]
  );
  function r(o, s) {
    let u = {};
    for (let c = 0; c < i.length; c += 1)
      u = Ne(u, i[c]);
    return s !== void 0 && s & /*props, value, allow_file_downloads, display_icon_button_wrapper_top_corner, i18n*/
    1636 && (u = Ne(u, je(i, [
      s & /*props*/
      32 && Ee(
        /*props*/
        o[5]
      ),
      s & /*value*/
      4 && { value: (
        /*value*/
        o[2]
      ) },
      s & /*props*/
      32 && {
        show_label: (
          /*props*/
          !!o[5].label
        )
      },
      s & /*allow_file_downloads*/
      512 && {
        show_download_button: (
          /*allow_file_downloads*/
          o[9]
        )
      },
      s & /*display_icon_button_wrapper_top_corner*/
      1024 && {
        display_icon_button_wrapper_top_corner: (
          /*display_icon_button_wrapper_top_corner*/
          o[10]
        )
      },
      s & /*i18n*/
      64 && { i18n: (
        /*i18n*/
        o[6]
      ) }
    ]))), { props: u };
  }
  return a && (e = Oe(a, r(l)), e.$on(
    "load",
    /*load_handler_5*/
    l[16]
  )), {
    c() {
      e && He(e.$$.fragment), t = Ve();
    },
    l(o) {
      e && Fn(e.$$.fragment, o), t = Ve();
    },
    m(o, s) {
      e && Ue(e, o, s), Pt(o, t, s), n = !0;
    },
    p(o, s) {
      if (s & /*components, type*/
      3 && a !== (a = /*components*/
      o[1][
        /*type*/
        o[0]
      ])) {
        if (e) {
          xt();
          const u = e;
          Ae(u.$$.fragment, 1, 0, () => {
            Pe(u, 1);
          }), Jt();
        }
        a ? (e = Oe(a, r(o, s)), e.$on(
          "load",
          /*load_handler_5*/
          o[16]
        ), He(e.$$.fragment), Ce(e.$$.fragment, 1), Ue(e, t.parentNode, t)) : e = null;
      } else if (a) {
        const u = s & /*props, value, allow_file_downloads, display_icon_button_wrapper_top_corner, i18n*/
        1636 ? je(i, [
          s & /*props*/
          32 && Ee(
            /*props*/
            o[5]
          ),
          s & /*value*/
          4 && { value: (
            /*value*/
            o[2]
          ) },
          s & /*props*/
          32 && {
            show_label: (
              /*props*/
              !!o[5].label
            )
          },
          s & /*allow_file_downloads*/
          512 && {
            show_download_button: (
              /*allow_file_downloads*/
              o[9]
            )
          },
          s & /*display_icon_button_wrapper_top_corner*/
          1024 && {
            display_icon_button_wrapper_top_corner: (
              /*display_icon_button_wrapper_top_corner*/
              o[10]
            )
          },
          s & /*i18n*/
          64 && { i18n: (
            /*i18n*/
            o[6]
          ) }
        ]) : {};
        e.$set(u);
      }
    },
    i(o) {
      n || (e && Ce(e.$$.fragment, o), n = !0);
    },
    o(o) {
      e && Ae(e.$$.fragment, o), n = !1;
    },
    d(o) {
      o && St(t), e && Pe(e, o);
    }
  };
}
function y0(l) {
  let e, t, n;
  const i = [
    /*props*/
    l[5],
    { autoplay: (
      /*props*/
      l[5].autoplay
    ) },
    {
      value: (
        /*value*/
        l[2].video || /*value*/
        l[2]
      )
    },
    {
      show_label: (
        /*props*/
        !!l[5].label
      )
    },
    { show_share_button: !0 },
    { i18n: (
      /*i18n*/
      l[6]
    ) },
    { upload: (
      /*upload*/
      l[7]
    ) },
    {
      display_icon_button_wrapper_top_corner: (
        /*display_icon_button_wrapper_top_corner*/
        l[10]
      )
    },
    {
      show_download_button: (
        /*allow_file_downloads*/
        l[9]
      )
    }
  ];
  var a = (
    /*components*/
    l[1][
      /*type*/
      l[0]
    ]
  );
  function r(o, s) {
    let u = {
      $$slots: { default: [$0] },
      $$scope: { ctx: o }
    };
    for (let c = 0; c < i.length; c += 1)
      u = Ne(u, i[c]);
    return s !== void 0 && s & /*props, value, i18n, upload, display_icon_button_wrapper_top_corner, allow_file_downloads*/
    1764 && (u = Ne(u, je(i, [
      s & /*props*/
      32 && Ee(
        /*props*/
        o[5]
      ),
      s & /*props*/
      32 && { autoplay: (
        /*props*/
        o[5].autoplay
      ) },
      s & /*value*/
      4 && {
        value: (
          /*value*/
          o[2].video || /*value*/
          o[2]
        )
      },
      s & /*props*/
      32 && {
        show_label: (
          /*props*/
          !!o[5].label
        )
      },
      i[4],
      s & /*i18n*/
      64 && { i18n: (
        /*i18n*/
        o[6]
      ) },
      s & /*upload*/
      128 && { upload: (
        /*upload*/
        o[7]
      ) },
      s & /*display_icon_button_wrapper_top_corner*/
      1024 && {
        display_icon_button_wrapper_top_corner: (
          /*display_icon_button_wrapper_top_corner*/
          o[10]
        )
      },
      s & /*allow_file_downloads*/
      512 && {
        show_download_button: (
          /*allow_file_downloads*/
          o[9]
        )
      }
    ]))), { props: u };
  }
  return a && (e = Oe(a, r(l)), e.$on(
    "load",
    /*load_handler_4*/
    l[15]
  )), {
    c() {
      e && He(e.$$.fragment), t = Ve();
    },
    l(o) {
      e && Fn(e.$$.fragment, o), t = Ve();
    },
    m(o, s) {
      e && Ue(e, o, s), Pt(o, t, s), n = !0;
    },
    p(o, s) {
      if (s & /*components, type*/
      3 && a !== (a = /*components*/
      o[1][
        /*type*/
        o[0]
      ])) {
        if (e) {
          xt();
          const u = e;
          Ae(u.$$.fragment, 1, 0, () => {
            Pe(u, 1);
          }), Jt();
        }
        a ? (e = Oe(a, r(o, s)), e.$on(
          "load",
          /*load_handler_4*/
          o[15]
        ), He(e.$$.fragment), Ce(e.$$.fragment, 1), Ue(e, t.parentNode, t)) : e = null;
      } else if (a) {
        const u = s & /*props, value, i18n, upload, display_icon_button_wrapper_top_corner, allow_file_downloads*/
        1764 ? je(i, [
          s & /*props*/
          32 && Ee(
            /*props*/
            o[5]
          ),
          s & /*props*/
          32 && { autoplay: (
            /*props*/
            o[5].autoplay
          ) },
          s & /*value*/
          4 && {
            value: (
              /*value*/
              o[2].video || /*value*/
              o[2]
            )
          },
          s & /*props*/
          32 && {
            show_label: (
              /*props*/
              !!o[5].label
            )
          },
          i[4],
          s & /*i18n*/
          64 && { i18n: (
            /*i18n*/
            o[6]
          ) },
          s & /*upload*/
          128 && { upload: (
            /*upload*/
            o[7]
          ) },
          s & /*display_icon_button_wrapper_top_corner*/
          1024 && {
            display_icon_button_wrapper_top_corner: (
              /*display_icon_button_wrapper_top_corner*/
              o[10]
            )
          },
          s & /*allow_file_downloads*/
          512 && {
            show_download_button: (
              /*allow_file_downloads*/
              o[9]
            )
          }
        ]) : {};
        s & /*$$scope*/
        524288 && (u.$$scope = { dirty: s, ctx: o }), e.$set(u);
      }
    },
    i(o) {
      n || (e && Ce(e.$$.fragment, o), n = !0);
    },
    o(o) {
      e && Ae(e.$$.fragment, o), n = !1;
    },
    d(o) {
      o && St(t), e && Pe(e, o);
    }
  };
}
function F0(l) {
  let e, t, n;
  const i = [
    /*props*/
    l[5],
    { value: (
      /*value*/
      l[2]
    ) },
    {
      show_label: (
        /*props*/
        !!l[5].label
      )
    },
    { show_share_button: !0 },
    { i18n: (
      /*i18n*/
      l[6]
    ) },
    {
      waveform_settings: {
        .../*props*/
        l[5].waveform_settings,
        autoplay: (
          /*props*/
          l[5].autoplay
        )
      }
    },
    {
      show_download_button: (
        /*allow_file_downloads*/
        l[9]
      )
    },
    {
      display_icon_button_wrapper_top_corner: (
        /*display_icon_button_wrapper_top_corner*/
        l[10]
      )
    }
  ];
  var a = (
    /*components*/
    l[1][
      /*type*/
      l[0]
    ]
  );
  function r(o, s) {
    let u = {};
    for (let c = 0; c < i.length; c += 1)
      u = Ne(u, i[c]);
    return s !== void 0 && s & /*props, value, i18n, allow_file_downloads, display_icon_button_wrapper_top_corner*/
    1636 && (u = Ne(u, je(i, [
      s & /*props*/
      32 && Ee(
        /*props*/
        o[5]
      ),
      s & /*value*/
      4 && { value: (
        /*value*/
        o[2]
      ) },
      s & /*props*/
      32 && {
        show_label: (
          /*props*/
          !!o[5].label
        )
      },
      i[3],
      s & /*i18n*/
      64 && { i18n: (
        /*i18n*/
        o[6]
      ) },
      s & /*props*/
      32 && {
        waveform_settings: {
          .../*props*/
          o[5].waveform_settings,
          autoplay: (
            /*props*/
            o[5].autoplay
          )
        }
      },
      s & /*allow_file_downloads*/
      512 && {
        show_download_button: (
          /*allow_file_downloads*/
          o[9]
        )
      },
      s & /*display_icon_button_wrapper_top_corner*/
      1024 && {
        display_icon_button_wrapper_top_corner: (
          /*display_icon_button_wrapper_top_corner*/
          o[10]
        )
      }
    ]))), { props: u };
  }
  return a && (t = Oe(a, r(l)), t.$on(
    "load",
    /*load_handler_3*/
    l[14]
  )), {
    c() {
      e = vc("div"), t && He(t.$$.fragment), this.h();
    },
    l(o) {
      e = bc(o, "DIV", { style: !0 });
      var s = m0(e);
      t && Fn(t.$$.fragment, s), s.forEach(St), this.h();
    },
    h() {
      v0(e, "position", "relative");
    },
    m(o, s) {
      Pt(o, e, s), t && Ue(t, e, null), n = !0;
    },
    p(o, s) {
      if (s & /*components, type*/
      3 && a !== (a = /*components*/
      o[1][
        /*type*/
        o[0]
      ])) {
        if (t) {
          xt();
          const u = t;
          Ae(u.$$.fragment, 1, 0, () => {
            Pe(u, 1);
          }), Jt();
        }
        a ? (t = Oe(a, r(o, s)), t.$on(
          "load",
          /*load_handler_3*/
          o[14]
        ), He(t.$$.fragment), Ce(t.$$.fragment, 1), Ue(t, e, null)) : t = null;
      } else if (a) {
        const u = s & /*props, value, i18n, allow_file_downloads, display_icon_button_wrapper_top_corner*/
        1636 ? je(i, [
          s & /*props*/
          32 && Ee(
            /*props*/
            o[5]
          ),
          s & /*value*/
          4 && { value: (
            /*value*/
            o[2]
          ) },
          s & /*props*/
          32 && {
            show_label: (
              /*props*/
              !!o[5].label
            )
          },
          i[3],
          s & /*i18n*/
          64 && { i18n: (
            /*i18n*/
            o[6]
          ) },
          s & /*props*/
          32 && {
            waveform_settings: {
              .../*props*/
              o[5].waveform_settings,
              autoplay: (
                /*props*/
                o[5].autoplay
              )
            }
          },
          s & /*allow_file_downloads*/
          512 && {
            show_download_button: (
              /*allow_file_downloads*/
              o[9]
            )
          },
          s & /*display_icon_button_wrapper_top_corner*/
          1024 && {
            display_icon_button_wrapper_top_corner: (
              /*display_icon_button_wrapper_top_corner*/
              o[10]
            )
          }
        ]) : {};
        t.$set(u);
      }
    },
    i(o) {
      n || (t && Ce(t.$$.fragment, o), n = !0);
    },
    o(o) {
      t && Ae(t.$$.fragment, o), n = !1;
    },
    d(o) {
      o && St(e), t && Pe(t);
    }
  };
}
function E0(l) {
  let e, t, n;
  const i = [
    /*props*/
    l[5],
    { value: (
      /*value*/
      l[2]
    ) },
    { target: (
      /*target*/
      l[3]
    ) },
    { theme_mode: (
      /*theme_mode*/
      l[4]
    ) },
    {
      bokeh_version: (
        /*props*/
        l[5].bokeh_version
      )
    },
    { caption: (
      /*props*/
      l[5].caption || ""
    ) },
    { show_actions_button: !0 }
  ];
  var a = (
    /*components*/
    l[1][
      /*type*/
      l[0]
    ]
  );
  function r(o, s) {
    let u = {};
    for (let c = 0; c < i.length; c += 1)
      u = Ne(u, i[c]);
    return s !== void 0 && s & /*props, value, target, theme_mode*/
    60 && (u = Ne(u, je(i, [
      s & /*props*/
      32 && Ee(
        /*props*/
        o[5]
      ),
      s & /*value*/
      4 && { value: (
        /*value*/
        o[2]
      ) },
      s & /*target*/
      8 && { target: (
        /*target*/
        o[3]
      ) },
      s & /*theme_mode*/
      16 && { theme_mode: (
        /*theme_mode*/
        o[4]
      ) },
      s & /*props*/
      32 && {
        bokeh_version: (
          /*props*/
          o[5].bokeh_version
        )
      },
      s & /*props*/
      32 && { caption: (
        /*props*/
        o[5].caption || ""
      ) },
      i[6]
    ]))), { props: u };
  }
  return a && (e = Oe(a, r(l)), e.$on(
    "load",
    /*load_handler_2*/
    l[13]
  )), {
    c() {
      e && He(e.$$.fragment), t = Ve();
    },
    l(o) {
      e && Fn(e.$$.fragment, o), t = Ve();
    },
    m(o, s) {
      e && Ue(e, o, s), Pt(o, t, s), n = !0;
    },
    p(o, s) {
      if (s & /*components, type*/
      3 && a !== (a = /*components*/
      o[1][
        /*type*/
        o[0]
      ])) {
        if (e) {
          xt();
          const u = e;
          Ae(u.$$.fragment, 1, 0, () => {
            Pe(u, 1);
          }), Jt();
        }
        a ? (e = Oe(a, r(o, s)), e.$on(
          "load",
          /*load_handler_2*/
          o[13]
        ), He(e.$$.fragment), Ce(e.$$.fragment, 1), Ue(e, t.parentNode, t)) : e = null;
      } else if (a) {
        const u = s & /*props, value, target, theme_mode*/
        60 ? je(i, [
          s & /*props*/
          32 && Ee(
            /*props*/
            o[5]
          ),
          s & /*value*/
          4 && { value: (
            /*value*/
            o[2]
          ) },
          s & /*target*/
          8 && { target: (
            /*target*/
            o[3]
          ) },
          s & /*theme_mode*/
          16 && { theme_mode: (
            /*theme_mode*/
            o[4]
          ) },
          s & /*props*/
          32 && {
            bokeh_version: (
              /*props*/
              o[5].bokeh_version
            )
          },
          s & /*props*/
          32 && { caption: (
            /*props*/
            o[5].caption || ""
          ) },
          i[6]
        ]) : {};
        e.$set(u);
      }
    },
    i(o) {
      n || (e && Ce(e.$$.fragment, o), n = !0);
    },
    o(o) {
      e && Ae(e.$$.fragment, o), n = !1;
    },
    d(o) {
      o && St(t), e && Pe(e, o);
    }
  };
}
function C0(l) {
  let e, t, n;
  const i = [
    /*props*/
    l[5],
    { value: (
      /*value*/
      l[2]
    ) },
    {
      show_label: (
        /*props*/
        !!l[5].label
      )
    },
    { i18n: (
      /*i18n*/
      l[6]
    ) },
    { interactive: !1 },
    {
      line_breaks: (
        /*props*/
        l[5].line_breaks
      )
    },
    { wrap: !0 },
    { root: "" },
    {
      gradio: { dispatch: _o, i18n: (
        /*i18n*/
        l[6]
      ) }
    },
    { datatype: (
      /*props*/
      l[5].datatype
    ) },
    {
      latex_delimiters: (
        /*props*/
        l[5].latex_delimiters
      )
    },
    { col_count: (
      /*props*/
      l[5].col_count
    ) },
    { row_count: (
      /*props*/
      l[5].row_count
    ) }
  ];
  var a = (
    /*components*/
    l[1][
      /*type*/
      l[0]
    ]
  );
  function r(o, s) {
    let u = {};
    for (let c = 0; c < i.length; c += 1)
      u = Ne(u, i[c]);
    return s !== void 0 && s & /*props, value, i18n*/
    100 && (u = Ne(u, je(i, [
      s & /*props*/
      32 && Ee(
        /*props*/
        o[5]
      ),
      s & /*value*/
      4 && { value: (
        /*value*/
        o[2]
      ) },
      s & /*props*/
      32 && {
        show_label: (
          /*props*/
          !!o[5].label
        )
      },
      s & /*i18n*/
      64 && { i18n: (
        /*i18n*/
        o[6]
      ) },
      i[4],
      s & /*props*/
      32 && {
        line_breaks: (
          /*props*/
          o[5].line_breaks
        )
      },
      i[6],
      i[7],
      s & /*i18n*/
      64 && {
        gradio: { dispatch: _o, i18n: (
          /*i18n*/
          o[6]
        ) }
      },
      s & /*props*/
      32 && { datatype: (
        /*props*/
        o[5].datatype
      ) },
      s & /*props*/
      32 && {
        latex_delimiters: (
          /*props*/
          o[5].latex_delimiters
        )
      },
      s & /*props*/
      32 && { col_count: (
        /*props*/
        o[5].col_count
      ) },
      s & /*props*/
      32 && { row_count: (
        /*props*/
        o[5].row_count
      ) }
    ]))), { props: u };
  }
  return a && (e = Oe(a, r(l)), e.$on(
    "load",
    /*load_handler_1*/
    l[12]
  )), {
    c() {
      e && He(e.$$.fragment), t = Ve();
    },
    l(o) {
      e && Fn(e.$$.fragment, o), t = Ve();
    },
    m(o, s) {
      e && Ue(e, o, s), Pt(o, t, s), n = !0;
    },
    p(o, s) {
      if (s & /*components, type*/
      3 && a !== (a = /*components*/
      o[1][
        /*type*/
        o[0]
      ])) {
        if (e) {
          xt();
          const u = e;
          Ae(u.$$.fragment, 1, 0, () => {
            Pe(u, 1);
          }), Jt();
        }
        a ? (e = Oe(a, r(o, s)), e.$on(
          "load",
          /*load_handler_1*/
          o[12]
        ), He(e.$$.fragment), Ce(e.$$.fragment, 1), Ue(e, t.parentNode, t)) : e = null;
      } else if (a) {
        const u = s & /*props, value, i18n*/
        100 ? je(i, [
          s & /*props*/
          32 && Ee(
            /*props*/
            o[5]
          ),
          s & /*value*/
          4 && { value: (
            /*value*/
            o[2]
          ) },
          s & /*props*/
          32 && {
            show_label: (
              /*props*/
              !!o[5].label
            )
          },
          s & /*i18n*/
          64 && { i18n: (
            /*i18n*/
            o[6]
          ) },
          i[4],
          s & /*props*/
          32 && {
            line_breaks: (
              /*props*/
              o[5].line_breaks
            )
          },
          i[6],
          i[7],
          s & /*i18n*/
          64 && {
            gradio: { dispatch: _o, i18n: (
              /*i18n*/
              o[6]
            ) }
          },
          s & /*props*/
          32 && { datatype: (
            /*props*/
            o[5].datatype
          ) },
          s & /*props*/
          32 && {
            latex_delimiters: (
              /*props*/
              o[5].latex_delimiters
            )
          },
          s & /*props*/
          32 && { col_count: (
            /*props*/
            o[5].col_count
          ) },
          s & /*props*/
          32 && { row_count: (
            /*props*/
            o[5].row_count
          ) }
        ]) : {};
        e.$set(u);
      }
    },
    i(o) {
      n || (e && Ce(e.$$.fragment, o), n = !0);
    },
    o(o) {
      e && Ae(e.$$.fragment, o), n = !1;
    },
    d(o) {
      o && St(t), e && Pe(e, o);
    }
  };
}
function A0(l) {
  let e, t, n;
  const i = [
    /*props*/
    l[5],
    { value: (
      /*value*/
      l[2]
    ) },
    {
      display_icon_button_wrapper_top_corner: (
        /*display_icon_button_wrapper_top_corner*/
        l[10]
      )
    },
    {
      show_label: (
        /*props*/
        !!l[5].label
      )
    },
    { i18n: (
      /*i18n*/
      l[6]
    ) },
    { _fetch: (
      /*_fetch*/
      l[8]
    ) },
    { allow_preview: !1 },
    { interactive: !1 },
    { mode: "minimal" },
    { fixed_height: 1 }
  ];
  var a = (
    /*components*/
    l[1][
      /*type*/
      l[0]
    ]
  );
  function r(o, s) {
    let u = {};
    for (let c = 0; c < i.length; c += 1)
      u = Ne(u, i[c]);
    return s !== void 0 && s & /*props, value, display_icon_button_wrapper_top_corner, i18n, _fetch*/
    1380 && (u = Ne(u, je(i, [
      s & /*props*/
      32 && Ee(
        /*props*/
        o[5]
      ),
      s & /*value*/
      4 && { value: (
        /*value*/
        o[2]
      ) },
      s & /*display_icon_button_wrapper_top_corner*/
      1024 && {
        display_icon_button_wrapper_top_corner: (
          /*display_icon_button_wrapper_top_corner*/
          o[10]
        )
      },
      s & /*props*/
      32 && {
        show_label: (
          /*props*/
          !!o[5].label
        )
      },
      s & /*i18n*/
      64 && { i18n: (
        /*i18n*/
        o[6]
      ) },
      s & /*_fetch*/
      256 && { _fetch: (
        /*_fetch*/
        o[8]
      ) },
      i[6],
      i[7],
      i[8],
      i[9]
    ]))), { props: u };
  }
  return a && (e = Oe(a, r(l)), e.$on(
    "load",
    /*load_handler*/
    l[11]
  )), {
    c() {
      e && He(e.$$.fragment), t = Ve();
    },
    l(o) {
      e && Fn(e.$$.fragment, o), t = Ve();
    },
    m(o, s) {
      e && Ue(e, o, s), Pt(o, t, s), n = !0;
    },
    p(o, s) {
      if (s & /*components, type*/
      3 && a !== (a = /*components*/
      o[1][
        /*type*/
        o[0]
      ])) {
        if (e) {
          xt();
          const u = e;
          Ae(u.$$.fragment, 1, 0, () => {
            Pe(u, 1);
          }), Jt();
        }
        a ? (e = Oe(a, r(o, s)), e.$on(
          "load",
          /*load_handler*/
          o[11]
        ), He(e.$$.fragment), Ce(e.$$.fragment, 1), Ue(e, t.parentNode, t)) : e = null;
      } else if (a) {
        const u = s & /*props, value, display_icon_button_wrapper_top_corner, i18n, _fetch*/
        1380 ? je(i, [
          s & /*props*/
          32 && Ee(
            /*props*/
            o[5]
          ),
          s & /*value*/
          4 && { value: (
            /*value*/
            o[2]
          ) },
          s & /*display_icon_button_wrapper_top_corner*/
          1024 && {
            display_icon_button_wrapper_top_corner: (
              /*display_icon_button_wrapper_top_corner*/
              o[10]
            )
          },
          s & /*props*/
          32 && {
            show_label: (
              /*props*/
              !!o[5].label
            )
          },
          s & /*i18n*/
          64 && { i18n: (
            /*i18n*/
            o[6]
          ) },
          s & /*_fetch*/
          256 && { _fetch: (
            /*_fetch*/
            o[8]
          ) },
          i[6],
          i[7],
          i[8],
          i[9]
        ]) : {};
        e.$set(u);
      }
    },
    i(o) {
      n || (e && Ce(e.$$.fragment, o), n = !0);
    },
    o(o) {
      e && Ae(e.$$.fragment, o), n = !1;
    },
    d(o) {
      o && St(t), e && Pe(e, o);
    }
  };
}
function $0(l) {
  let e;
  return {
    c() {
      e = vc("track"), this.h();
    },
    l(t) {
      e = bc(t, "TRACK", { kind: !0 }), this.h();
    },
    h() {
      h0(e, "kind", "captions");
    },
    m(t, n) {
      Pt(t, e, n);
    },
    p: g0,
    d(t) {
      t && St(e);
    }
  };
}
function S0(l) {
  let e, t, n, i;
  const a = [
    A0,
    C0,
    E0,
    F0,
    y0,
    D0,
    k0,
    w0
  ], r = [];
  function o(s, u) {
    return (
      /*type*/
      s[0] === "gallery" ? 0 : (
        /*type*/
        s[0] === "dataframe" ? 1 : (
          /*type*/
          s[0] === "plot" ? 2 : (
            /*type*/
            s[0] === "audio" ? 3 : (
              /*type*/
              s[0] === "video" ? 4 : (
                /*type*/
                s[0] === "image" ? 5 : (
                  /*type*/
                  s[0] === "html" ? 6 : (
                    /*type*/
                    s[0] === "model3d" ? 7 : -1
                  )
                )
              )
            )
          )
        )
      )
    );
  }
  return ~(e = o(l)) && (t = r[e] = a[e](l)), {
    c() {
      t && t.c(), n = Ve();
    },
    l(s) {
      t && t.l(s), n = Ve();
    },
    m(s, u) {
      ~e && r[e].m(s, u), Pt(s, n, u), i = !0;
    },
    p(s, [u]) {
      let c = e;
      e = o(s), e === c ? ~e && r[e].p(s, u) : (t && (xt(), Ae(r[c], 1, 1, () => {
        r[c] = null;
      }), Jt()), ~e ? (t = r[e], t ? t.p(s, u) : (t = r[e] = a[e](s), t.c()), Ce(t, 1), t.m(n.parentNode, n)) : t = null);
    },
    i(s) {
      i || (Ce(t), i = !0);
    },
    o(s) {
      Ae(t), i = !1;
    },
    d(s) {
      s && St(n), ~e && r[e].d(s);
    }
  };
}
const _o = () => {
}, B0 = () => {
}, co = () => {
};
function q0(l, e, t) {
  let { type: n } = e, { components: i } = e, { value: a } = e, { target: r } = e, { theme_mode: o } = e, { props: s } = e, { i18n: u } = e, { upload: c } = e, { _fetch: f } = e, { allow_file_downloads: _ } = e, { display_icon_button_wrapper_top_corner: d = !1 } = e;
  function h(b) {
    _n.call(this, l, b);
  }
  function p(b) {
    _n.call(this, l, b);
  }
  function v(b) {
    _n.call(this, l, b);
  }
  function D(b) {
    _n.call(this, l, b);
  }
  function w(b) {
    _n.call(this, l, b);
  }
  function m(b) {
    _n.call(this, l, b);
  }
  function g(b) {
    _n.call(this, l, b);
  }
  function k(b) {
    _n.call(this, l, b);
  }
  return l.$$set = (b) => {
    "type" in b && t(0, n = b.type), "components" in b && t(1, i = b.components), "value" in b && t(2, a = b.value), "target" in b && t(3, r = b.target), "theme_mode" in b && t(4, o = b.theme_mode), "props" in b && t(5, s = b.props), "i18n" in b && t(6, u = b.i18n), "upload" in b && t(7, c = b.upload), "_fetch" in b && t(8, f = b._fetch), "allow_file_downloads" in b && t(9, _ = b.allow_file_downloads), "display_icon_button_wrapper_top_corner" in b && t(10, d = b.display_icon_button_wrapper_top_corner);
  }, l.$$.update = () => {
    l.$$.dirty & /*props*/
    32 && console.log("props.label", s.label);
  }, [
    n,
    i,
    a,
    r,
    o,
    s,
    u,
    c,
    f,
    _,
    d,
    h,
    p,
    v,
    D,
    w,
    m,
    g,
    k
  ];
}
class T0 extends d0 {
  constructor(e) {
    super(), p0(this, e, q0, S0, b0, {
      type: 0,
      components: 1,
      value: 2,
      target: 3,
      theme_mode: 4,
      props: 5,
      i18n: 6,
      upload: 7,
      _fetch: 8,
      allow_file_downloads: 9,
      display_icon_button_wrapper_top_corner: 10
    });
  }
}
const {
  SvelteComponent: I0,
  append_hydration: jt,
  attr: lt,
  check_outros: L0,
  children: Rn,
  claim_component: ar,
  claim_element: Nn,
  claim_space: su,
  claim_text: uu,
  create_component: or,
  destroy_component: rr,
  detach: Lt,
  element: On,
  empty: _u,
  group_outros: z0,
  init: M0,
  insert_hydration: sr,
  is_function: R0,
  mount_component: ur,
  safe_not_equal: N0,
  set_data: cu,
  space: fu,
  text: du,
  transition_in: Nl,
  transition_out: Ol
} = window.__gradio__svelte__internal;
function O0(l) {
  var D, w, m, g;
  let e, t, n, i, a, r, o, s = (
    /*message*/
    (((D = l[15].content.value) == null ? void 0 : D.orig_name) || /*message*/
    ((w = l[15].content.value) == null ? void 0 : w.path.split("/").pop()) || "file") + ""
  ), u, c, f, _, d, h = (
    /*message*/
    (((m = l[15].content.value) == null ? void 0 : m.orig_name) || /*message*/
    ((g = l[15].content.value) == null ? void 0 : g.path) || "").split(".").pop().toUpperCase() + ""
  ), p, v;
  return n = new Jo({}), {
    c() {
      e = On("div"), t = On("div"), or(n.$$.fragment), i = fu(), a = On("div"), r = On("a"), o = On("span"), u = du(s), _ = fu(), d = On("span"), p = du(h), this.h();
    },
    l(k) {
      e = Nn(k, "DIV", { class: !0 });
      var b = Rn(e);
      t = Nn(b, "DIV", { class: !0 });
      var y = Rn(t);
      ar(n.$$.fragment, y), y.forEach(Lt), i = su(b), a = Nn(b, "DIV", { class: !0 });
      var C = Rn(a);
      r = Nn(C, "A", {
        "data-testid": !0,
        class: !0,
        href: !0,
        target: !0,
        download: !0
      });
      var F = Rn(r);
      o = Nn(F, "SPAN", { class: !0 });
      var B = Rn(o);
      u = uu(B, s), B.forEach(Lt), F.forEach(Lt), _ = su(C), d = Nn(C, "SPAN", { class: !0 });
      var I = Rn(d);
      p = uu(I, h), I.forEach(Lt), C.forEach(Lt), b.forEach(Lt), this.h();
    },
    h() {
      var k, b;
      lt(t, "class", "file-icon svelte-5dyec9"), lt(o, "class", "file-name svelte-5dyec9"), lt(r, "data-testid", "chatbot-file"), lt(r, "class", "file-link svelte-5dyec9"), lt(r, "href", c = /*message*/
      l[15].content.value.url), lt(r, "target", "_blank"), lt(r, "download", f = window.__is_colab__ ? null : (
        /*message*/
        ((k = l[15].content.value) == null ? void 0 : k.orig_name) || /*message*/
        ((b = l[15].content.value) == null ? void 0 : b.path.split("/").pop()) || "file"
      )), lt(d, "class", "file-type svelte-5dyec9"), lt(a, "class", "file-info svelte-5dyec9"), lt(e, "class", "file-container svelte-5dyec9");
    },
    m(k, b) {
      sr(k, e, b), jt(e, t), ur(n, t, null), jt(e, i), jt(e, a), jt(a, r), jt(r, o), jt(o, u), jt(a, _), jt(a, d), jt(d, p), v = !0;
    },
    p(k, b) {
      var y, C, F, B, I, S;
      (!v || b & /*message*/
      32768) && s !== (s = /*message*/
      (((y = k[15].content.value) == null ? void 0 : y.orig_name) || /*message*/
      ((C = k[15].content.value) == null ? void 0 : C.path.split("/").pop()) || "file") + "") && cu(u, s), (!v || b & /*message*/
      32768 && c !== (c = /*message*/
      k[15].content.value.url)) && lt(r, "href", c), (!v || b & /*message*/
      32768 && f !== (f = window.__is_colab__ ? null : (
        /*message*/
        ((F = k[15].content.value) == null ? void 0 : F.orig_name) || /*message*/
        ((B = k[15].content.value) == null ? void 0 : B.path.split("/").pop()) || "file"
      ))) && lt(r, "download", f), (!v || b & /*message*/
      32768) && h !== (h = /*message*/
      (((I = k[15].content.value) == null ? void 0 : I.orig_name) || /*message*/
      ((S = k[15].content.value) == null ? void 0 : S.path) || "").split(".").pop().toUpperCase() + "") && cu(p, h);
    },
    i(k) {
      v || (Nl(n.$$.fragment, k), v = !0);
    },
    o(k) {
      Ol(n.$$.fragment, k), v = !1;
    },
    d(k) {
      k && Lt(e), rr(n);
    }
  };
}
function H0(l) {
  let e, t;
  return e = new T0({
    props: {
      target: (
        /*target*/
        l[6]
      ),
      theme_mode: (
        /*theme_mode*/
        l[7]
      ),
      props: (
        /*message*/
        l[15].content.props
      ),
      type: (
        /*message*/
        l[15].content.component
      ),
      components: (
        /*_components*/
        l[8]
      ),
      value: (
        /*message*/
        l[15].content.value
      ),
      display_icon_button_wrapper_top_corner: (
        /*thought_index*/
        l[13] > 0 && /*display_consecutive_in_same_bubble*/
        l[12]
      ),
      i18n: (
        /*i18n*/
        l[3]
      ),
      upload: (
        /*upload*/
        l[5]
      ),
      _fetch: (
        /*_fetch*/
        l[2]
      ),
      allow_file_downloads: (
        /*allow_file_downloads*/
        l[11]
      )
    }
  }), e.$on(
    "load",
    /*load_handler*/
    l[16]
  ), {
    c() {
      or(e.$$.fragment);
    },
    l(n) {
      ar(e.$$.fragment, n);
    },
    m(n, i) {
      ur(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i & /*target*/
      64 && (a.target = /*target*/
      n[6]), i & /*theme_mode*/
      128 && (a.theme_mode = /*theme_mode*/
      n[7]), i & /*message*/
      32768 && (a.props = /*message*/
      n[15].content.props), i & /*message*/
      32768 && (a.type = /*message*/
      n[15].content.component), i & /*_components*/
      256 && (a.components = /*_components*/
      n[8]), i & /*message*/
      32768 && (a.value = /*message*/
      n[15].content.value), i & /*thought_index, display_consecutive_in_same_bubble*/
      12288 && (a.display_icon_button_wrapper_top_corner = /*thought_index*/
      n[13] > 0 && /*display_consecutive_in_same_bubble*/
      n[12]), i & /*i18n*/
      8 && (a.i18n = /*i18n*/
      n[3]), i & /*upload*/
      32 && (a.upload = /*upload*/
      n[5]), i & /*_fetch*/
      4 && (a._fetch = /*_fetch*/
      n[2]), i & /*allow_file_downloads*/
      2048 && (a.allow_file_downloads = /*allow_file_downloads*/
      n[11]), e.$set(a);
    },
    i(n) {
      t || (Nl(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ol(e.$$.fragment, n), t = !1;
    },
    d(n) {
      rr(e, n);
    }
  };
}
function P0(l) {
  let e, t, n;
  return t = new Yo({
    props: {
      message: (
        /*message*/
        l[15].content
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        l[0]
      ),
      sanitize_html: (
        /*sanitize_html*/
        l[1]
      ),
      render_markdown: (
        /*render_markdown*/
        l[9]
      ),
      line_breaks: (
        /*line_breaks*/
        l[4]
      ),
      allow_tags: (
        /*allow_tags*/
        l[14]
      ),
      theme_mode: (
        /*theme_mode*/
        l[7]
      )
    }
  }), t.$on("load", function() {
    R0(
      /*scroll*/
      l[10]
    ) && l[10].apply(this, arguments);
  }), {
    c() {
      e = On("div"), or(t.$$.fragment), this.h();
    },
    l(i) {
      e = Nn(i, "DIV", { class: !0 });
      var a = Rn(e);
      ar(t.$$.fragment, a), a.forEach(Lt), this.h();
    },
    h() {
      lt(e, "class", "message-content");
    },
    m(i, a) {
      sr(i, e, a), ur(t, e, null), n = !0;
    },
    p(i, a) {
      l = i;
      const r = {};
      a & /*message*/
      32768 && (r.message = /*message*/
      l[15].content), a & /*latex_delimiters*/
      1 && (r.latex_delimiters = /*latex_delimiters*/
      l[0]), a & /*sanitize_html*/
      2 && (r.sanitize_html = /*sanitize_html*/
      l[1]), a & /*render_markdown*/
      512 && (r.render_markdown = /*render_markdown*/
      l[9]), a & /*line_breaks*/
      16 && (r.line_breaks = /*line_breaks*/
      l[4]), a & /*allow_tags*/
      16384 && (r.allow_tags = /*allow_tags*/
      l[14]), a & /*theme_mode*/
      128 && (r.theme_mode = /*theme_mode*/
      l[7]), t.$set(r);
    },
    i(i) {
      n || (Nl(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Ol(t.$$.fragment, i), n = !1;
    },
    d(i) {
      i && Lt(e), rr(t);
    }
  };
}
function V0(l) {
  let e, t, n, i;
  const a = [P0, H0, O0], r = [];
  function o(s, u) {
    return (
      /*message*/
      s[15].type === "text" ? 0 : (
        /*message*/
        s[15].type === "component" && /*message*/
        s[15].content.component in /*_components*/
        s[8] ? 1 : (
          /*message*/
          s[15].type === "component" && /*message*/
          s[15].content.component === "file" ? 2 : -1
        )
      )
    );
  }
  return ~(e = o(l)) && (t = r[e] = a[e](l)), {
    c() {
      t && t.c(), n = _u();
    },
    l(s) {
      t && t.l(s), n = _u();
    },
    m(s, u) {
      ~e && r[e].m(s, u), sr(s, n, u), i = !0;
    },
    p(s, [u]) {
      let c = e;
      e = o(s), e === c ? ~e && r[e].p(s, u) : (t && (z0(), Ol(r[c], 1, 1, () => {
        r[c] = null;
      }), L0()), ~e ? (t = r[e], t ? t.p(s, u) : (t = r[e] = a[e](s), t.c()), Nl(t, 1), t.m(n.parentNode, n)) : t = null);
    },
    i(s) {
      i || (Nl(t), i = !0);
    },
    o(s) {
      Ol(t), i = !1;
    },
    d(s) {
      s && Lt(n), ~e && r[e].d(s);
    }
  };
}
function j0(l, e, t) {
  let { latex_delimiters: n } = e, { sanitize_html: i } = e, { _fetch: a } = e, { i18n: r } = e, { line_breaks: o } = e, { upload: s } = e, { target: u } = e, { theme_mode: c } = e, { _components: f } = e, { render_markdown: _ } = e, { scroll: d } = e, { allow_file_downloads: h } = e, { display_consecutive_in_same_bubble: p } = e, { thought_index: v } = e, { allow_tags: D = !1 } = e, { message: w } = e;
  const m = () => d();
  return l.$$set = (g) => {
    "latex_delimiters" in g && t(0, n = g.latex_delimiters), "sanitize_html" in g && t(1, i = g.sanitize_html), "_fetch" in g && t(2, a = g._fetch), "i18n" in g && t(3, r = g.i18n), "line_breaks" in g && t(4, o = g.line_breaks), "upload" in g && t(5, s = g.upload), "target" in g && t(6, u = g.target), "theme_mode" in g && t(7, c = g.theme_mode), "_components" in g && t(8, f = g._components), "render_markdown" in g && t(9, _ = g.render_markdown), "scroll" in g && t(10, d = g.scroll), "allow_file_downloads" in g && t(11, h = g.allow_file_downloads), "display_consecutive_in_same_bubble" in g && t(12, p = g.display_consecutive_in_same_bubble), "thought_index" in g && t(13, v = g.thought_index), "allow_tags" in g && t(14, D = g.allow_tags), "message" in g && t(15, w = g.message);
  }, [
    n,
    i,
    a,
    r,
    o,
    s,
    u,
    c,
    f,
    _,
    d,
    h,
    p,
    v,
    D,
    w,
    m
  ];
}
class wc extends I0 {
  constructor(e) {
    super(), M0(this, e, j0, V0, N0, {
      latex_delimiters: 0,
      sanitize_html: 1,
      _fetch: 2,
      i18n: 3,
      line_breaks: 4,
      upload: 5,
      target: 6,
      theme_mode: 7,
      _components: 8,
      render_markdown: 9,
      scroll: 10,
      allow_file_downloads: 11,
      display_consecutive_in_same_bubble: 12,
      thought_index: 13,
      allow_tags: 14,
      message: 15
    });
  }
}
function Di() {
}
const kc = typeof window < "u";
let hu = kc ? () => window.performance.now() : () => Date.now(), Dc = kc ? (l) => requestAnimationFrame(l) : Di;
const dl = /* @__PURE__ */ new Set();
function yc(l) {
  dl.forEach((e) => {
    e.c(l) || (dl.delete(e), e.f());
  }), dl.size !== 0 && Dc(yc);
}
function U0(l) {
  let e;
  return dl.size === 0 && Dc(yc), { promise: new Promise((t) => {
    dl.add(e = { c: l, f: t });
  }), abort() {
    dl.delete(e);
  } };
}
function G0(l) {
  const e = l - 1;
  return e * e * e + 1;
}
function mu(l, { delay: e = 0, duration: t = 400, easing: n = G0, axis: i = "y" } = {}) {
  const a = getComputedStyle(l), r = +a.opacity, o = i === "y" ? "height" : "width", s = parseFloat(a[o]), u = i === "y" ? ["top", "bottom"] : ["left", "right"], c = u.map((D) => `${D[0].toUpperCase()}${D.slice(1)}`), f = parseFloat(a[`padding${c[0]}`]), _ = parseFloat(a[`padding${c[1]}`]), d = parseFloat(a[`margin${c[0]}`]), h = parseFloat(a[`margin${c[1]}`]), p = parseFloat(a[`border${c[0]}Width`]), v = parseFloat(a[`border${c[1]}Width`]);
  return { delay: e, duration: t, easing: n, css: (D) => `overflow: hidden;opacity: ${Math.min(20 * D, 1) * r};${o}: ${D * s}px;padding-${u[0]}: ${D * f}px;padding-${u[1]}: ${D * _}px;margin-${u[0]}: ${D * d}px;margin-${u[1]}: ${D * h}px;border-${u[0]}-width: ${D * p}px;border-${u[1]}-width: ${D * v}px;` };
}
const sl = [];
function Z0(l, e = Di) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function i(r) {
    if (s = r, ((o = l) != o ? s == s : o !== s || o && typeof o == "object" || typeof o == "function") && (l = r, t)) {
      const u = !sl.length;
      for (const c of n) c[1](), sl.push(c, l);
      if (u) {
        for (let c = 0; c < sl.length; c += 2) sl[c][0](sl[c + 1]);
        sl.length = 0;
      }
    }
    var o, s;
  }
  function a(r) {
    i(r(l));
  }
  return { set: i, update: a, subscribe: function(r, o = Di) {
    const s = [r, o];
    return n.add(s), n.size === 1 && (t = e(i, a) || Di), r(l), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function pu(l) {
  return Object.prototype.toString.call(l) === "[object Date]";
}
function To(l, e, t, n) {
  if (typeof t == "number" || pu(t)) {
    const i = n - t, a = (t - e) / (l.dt || 1 / 60), r = (a + (l.opts.stiffness * i - l.opts.damping * a) * l.inv_mass) * l.dt;
    return Math.abs(r) < l.opts.precision && Math.abs(i) < l.opts.precision ? n : (l.settled = !1, pu(t) ? new Date(t.getTime() + r) : t + r);
  }
  if (Array.isArray(t)) return t.map((i, a) => To(l, e[a], t[a], n[a]));
  if (typeof t == "object") {
    const i = {};
    for (const a in t) i[a] = To(l, e[a], t[a], n[a]);
    return i;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function gu(l, e = {}) {
  const t = Z0(l), { stiffness: n = 0.15, damping: i = 0.8, precision: a = 0.01 } = e;
  let r, o, s, u = l, c = l, f = 1, _ = 0, d = !1;
  function h(v, D = {}) {
    c = v;
    const w = s = {};
    return l == null || D.hard || p.stiffness >= 1 && p.damping >= 1 ? (d = !0, r = hu(), u = v, t.set(l = c), Promise.resolve()) : (D.soft && (_ = 1 / (60 * (D.soft === !0 ? 0.5 : +D.soft)), f = 0), o || (r = hu(), d = !1, o = U0((m) => {
      if (d) return d = !1, o = null, !1;
      f = Math.min(f + _, 1);
      const g = { inv_mass: f, opts: p, settled: !0, dt: 60 * (m - r) / 1e3 }, k = To(g, u, l, c);
      return r = m, u = l, t.set(l = k), g.settled && (o = null), !g.settled;
    })), new Promise((m) => {
      o.promise.then(() => {
        w === s && m();
      });
    }));
  }
  const p = { set: h, update: (v, D) => h(v(c, l), D), subscribe: t.subscribe, stiffness: n, damping: i, precision: a };
  return p;
}
const {
  SvelteComponent: W0,
  add_render_callback: X0,
  append_hydration: dn,
  attr: Et,
  binding_callbacks: K0,
  check_outros: _r,
  children: Vn,
  claim_component: Ii,
  claim_element: jn,
  claim_space: ul,
  claim_text: Yt,
  create_bidirectional_transition: bu,
  create_component: Li,
  destroy_component: zi,
  destroy_each: Y0,
  detach: ge,
  element: Un,
  ensure_array_like: vu,
  group_outros: cr,
  init: Q0,
  insert_hydration: Qe,
  listen: Io,
  mount_component: Mi,
  run_all: J0,
  safe_not_equal: x0,
  set_data: Wi,
  set_style: wu,
  space: _l,
  stop_propagation: eg,
  text: Qt,
  toggle_class: cl,
  transition_in: at,
  transition_out: Ht
} = window.__gradio__svelte__internal;
function ku(l, e, t) {
  const n = l.slice();
  return n[29] = e[t], n[31] = t, n;
}
function Du(l) {
  let e;
  return {
    c() {
      e = Un("span"), this.h();
    },
    l(t) {
      e = jn(t, "SPAN", { class: !0 }), Vn(e).forEach(ge), this.h();
    },
    h() {
      Et(e, "class", "loading-spinner svelte-1812gcz");
    },
    m(t, n) {
      Qe(t, e, n);
    },
    d(t) {
      t && ge(e);
    }
  };
}
function yu(l) {
  let e, t, n = (
    /*thought_node*/
    l[16].metadata.log && Fu(l)
  ), i = (
    /*thought_node*/
    l[16].metadata.duration !== void 0 && Eu(l)
  );
  return {
    c() {
      e = Un("span"), n && n.c(), t = _l(), i && i.c(), this.h();
    },
    l(a) {
      e = jn(a, "SPAN", { class: !0 });
      var r = Vn(e);
      n && n.l(r), t = ul(r), i && i.l(r), r.forEach(ge), this.h();
    },
    h() {
      Et(e, "class", "duration svelte-1812gcz");
    },
    m(a, r) {
      Qe(a, e, r), n && n.m(e, null), dn(e, t), i && i.m(e, null);
    },
    p(a, r) {
      /*thought_node*/
      a[16].metadata.log ? n ? n.p(a, r) : (n = Fu(a), n.c(), n.m(e, t)) : n && (n.d(1), n = null), /*thought_node*/
      a[16].metadata.duration !== void 0 ? i ? i.p(a, r) : (i = Eu(a), i.c(), i.m(e, null)) : i && (i.d(1), i = null);
    },
    d(a) {
      a && ge(e), n && n.d(), i && i.d();
    }
  };
}
function Fu(l) {
  let e = (
    /*thought_node*/
    l[16].metadata.log + ""
  ), t;
  return {
    c() {
      t = Qt(e);
    },
    l(n) {
      t = Yt(n, e);
    },
    m(n, i) {
      Qe(n, t, i);
    },
    p(n, i) {
      i[0] & /*thought_node*/
      65536 && e !== (e = /*thought_node*/
      n[16].metadata.log + "") && Wi(t, e);
    },
    d(n) {
      n && ge(t);
    }
  };
}
function Eu(l) {
  let e, t, n;
  function i(o, s) {
    return s[0] & /*thought_node*/
    65536 && (t = null), t == null && (t = !!Number.isInteger(
      /*thought_node*/
      o[16].metadata.duration
    )), t ? lg : (
      /*thought_node*/
      o[16].metadata.duration >= 0.1 ? ng : tg
    );
  }
  let a = i(l, [-1, -1]), r = a(l);
  return {
    c() {
      e = Qt("("), r.c(), n = Qt(")");
    },
    l(o) {
      e = Yt(o, "("), r.l(o), n = Yt(o, ")");
    },
    m(o, s) {
      Qe(o, e, s), r.m(o, s), Qe(o, n, s);
    },
    p(o, s) {
      a === (a = i(o, s)) && r ? r.p(o, s) : (r.d(1), r = a(o), r && (r.c(), r.m(n.parentNode, n)));
    },
    d(o) {
      o && (ge(e), ge(n)), r.d(o);
    }
  };
}
function tg(l) {
  let e = (
    /*thought_node*/
    (l[16].metadata.duration * 1e3).toFixed(1) + ""
  ), t, n;
  return {
    c() {
      t = Qt(e), n = Qt("ms");
    },
    l(i) {
      t = Yt(i, e), n = Yt(i, "ms");
    },
    m(i, a) {
      Qe(i, t, a), Qe(i, n, a);
    },
    p(i, a) {
      a[0] & /*thought_node*/
      65536 && e !== (e = /*thought_node*/
      (i[16].metadata.duration * 1e3).toFixed(1) + "") && Wi(t, e);
    },
    d(i) {
      i && (ge(t), ge(n));
    }
  };
}
function ng(l) {
  let e = (
    /*thought_node*/
    l[16].metadata.duration.toFixed(1) + ""
  ), t, n;
  return {
    c() {
      t = Qt(e), n = Qt("s");
    },
    l(i) {
      t = Yt(i, e), n = Yt(i, "s");
    },
    m(i, a) {
      Qe(i, t, a), Qe(i, n, a);
    },
    p(i, a) {
      a[0] & /*thought_node*/
      65536 && e !== (e = /*thought_node*/
      i[16].metadata.duration.toFixed(1) + "") && Wi(t, e);
    },
    d(i) {
      i && (ge(t), ge(n));
    }
  };
}
function lg(l) {
  let e = (
    /*thought_node*/
    l[16].metadata.duration + ""
  ), t, n;
  return {
    c() {
      t = Qt(e), n = Qt("s");
    },
    l(i) {
      t = Yt(i, e), n = Yt(i, "s");
    },
    m(i, a) {
      Qe(i, t, a), Qe(i, n, a);
    },
    p(i, a) {
      a[0] & /*thought_node*/
      65536 && e !== (e = /*thought_node*/
      i[16].metadata.duration + "") && Wi(t, e);
    },
    d(i) {
      i && (ge(t), ge(n));
    }
  };
}
function Cu(l) {
  var u;
  let e, t, n, i, a, r, o;
  t = new wc({
    props: {
      message: (
        /*thought_node*/
        l[16]
      ),
      sanitize_html: (
        /*sanitize_html*/
        l[1]
      ),
      allow_tags: (
        /*allow_tags*/
        l[15]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        l[2]
      ),
      render_markdown: (
        /*render_markdown*/
        l[3]
      ),
      _components: (
        /*_components*/
        l[4]
      ),
      upload: (
        /*upload*/
        l[5]
      ),
      thought_index: (
        /*thought_index*/
        l[6]
      ),
      target: (
        /*target*/
        l[7]
      ),
      theme_mode: (
        /*theme_mode*/
        l[8]
      ),
      _fetch: (
        /*_fetch*/
        l[9]
      ),
      scroll: (
        /*scroll*/
        l[10]
      ),
      allow_file_downloads: (
        /*allow_file_downloads*/
        l[11]
      ),
      display_consecutive_in_same_bubble: (
        /*display_consecutive_in_same_bubble*/
        l[12]
      ),
      i18n: (
        /*i18n*/
        l[13]
      ),
      line_breaks: (
        /*line_breaks*/
        l[14]
      )
    }
  });
  let s = (
    /*thought_node*/
    ((u = l[16].children) == null ? void 0 : u.length) > 0 && Au(l)
  );
  return {
    c() {
      e = Un("div"), Li(t.$$.fragment), n = _l(), s && s.c(), this.h();
    },
    l(c) {
      e = jn(c, "DIV", { class: !0 });
      var f = Vn(e);
      Ii(t.$$.fragment, f), n = ul(f), s && s.l(f), f.forEach(ge), this.h();
    },
    h() {
      var c;
      Et(e, "class", "svelte-1812gcz"), cl(
        e,
        "content",
        /*expanded*/
        l[18]
      ), cl(e, "content-preview", !/*expanded*/
      l[18] && /*thought_node*/
      ((c = l[16].metadata) == null ? void 0 : c.status) !== "done");
    },
    m(c, f) {
      Qe(c, e, f), Mi(t, e, null), dn(e, n), s && s.m(e, null), l[26](e), a = !0, r || (o = Io(
        e,
        "scroll",
        /*handleScroll*/
        l[20]
      ), r = !0);
    },
    p(c, f) {
      var d, h;
      const _ = {};
      f[0] & /*thought_node*/
      65536 && (_.message = /*thought_node*/
      c[16]), f[0] & /*sanitize_html*/
      2 && (_.sanitize_html = /*sanitize_html*/
      c[1]), f[0] & /*allow_tags*/
      32768 && (_.allow_tags = /*allow_tags*/
      c[15]), f[0] & /*latex_delimiters*/
      4 && (_.latex_delimiters = /*latex_delimiters*/
      c[2]), f[0] & /*render_markdown*/
      8 && (_.render_markdown = /*render_markdown*/
      c[3]), f[0] & /*_components*/
      16 && (_._components = /*_components*/
      c[4]), f[0] & /*upload*/
      32 && (_.upload = /*upload*/
      c[5]), f[0] & /*thought_index*/
      64 && (_.thought_index = /*thought_index*/
      c[6]), f[0] & /*target*/
      128 && (_.target = /*target*/
      c[7]), f[0] & /*theme_mode*/
      256 && (_.theme_mode = /*theme_mode*/
      c[8]), f[0] & /*_fetch*/
      512 && (_._fetch = /*_fetch*/
      c[9]), f[0] & /*scroll*/
      1024 && (_.scroll = /*scroll*/
      c[10]), f[0] & /*allow_file_downloads*/
      2048 && (_.allow_file_downloads = /*allow_file_downloads*/
      c[11]), f[0] & /*display_consecutive_in_same_bubble*/
      4096 && (_.display_consecutive_in_same_bubble = /*display_consecutive_in_same_bubble*/
      c[12]), f[0] & /*i18n*/
      8192 && (_.i18n = /*i18n*/
      c[13]), f[0] & /*line_breaks*/
      16384 && (_.line_breaks = /*line_breaks*/
      c[14]), t.$set(_), /*thought_node*/
      ((d = c[16].children) == null ? void 0 : d.length) > 0 ? s ? (s.p(c, f), f[0] & /*thought_node*/
      65536 && at(s, 1)) : (s = Au(c), s.c(), at(s, 1), s.m(e, null)) : s && (cr(), Ht(s, 1, 1, () => {
        s = null;
      }), _r()), (!a || f[0] & /*expanded*/
      262144) && cl(
        e,
        "content",
        /*expanded*/
        c[18]
      ), (!a || f[0] & /*expanded, thought_node*/
      327680) && cl(e, "content-preview", !/*expanded*/
      c[18] && /*thought_node*/
      ((h = c[16].metadata) == null ? void 0 : h.status) !== "done");
    },
    i(c) {
      a || (at(t.$$.fragment, c), at(s), c && X0(() => {
        a && (i || (i = bu(e, mu, {}, !0)), i.run(1));
      }), a = !0);
    },
    o(c) {
      Ht(t.$$.fragment, c), Ht(s), c && (i || (i = bu(e, mu, {}, !1)), i.run(0)), a = !1;
    },
    d(c) {
      c && ge(e), zi(t), s && s.d(), l[26](null), c && i && i.end(), r = !1, o();
    }
  };
}
function Au(l) {
  let e, t, n = vu(
    /*thought_node*/
    l[16].children
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = $u(ku(l, n, r));
  const a = (r) => Ht(i[r], 1, 1, () => {
    i[r] = null;
  });
  return {
    c() {
      e = Un("div");
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      this.h();
    },
    l(r) {
      e = jn(r, "DIV", { class: !0 });
      var o = Vn(e);
      for (let s = 0; s < i.length; s += 1)
        i[s].l(o);
      o.forEach(ge), this.h();
    },
    h() {
      Et(e, "class", "children svelte-1812gcz");
    },
    m(r, o) {
      Qe(r, e, o);
      for (let s = 0; s < i.length; s += 1)
        i[s] && i[s].m(e, null);
      t = !0;
    },
    p(r, o) {
      if (o[0] & /*thought_node, rtl, sanitize_html, latex_delimiters, render_markdown, _components, upload, thought_index, target, theme_mode, _fetch, scroll, allow_file_downloads, display_consecutive_in_same_bubble, i18n, line_breaks*/
      98303) {
        n = vu(
          /*thought_node*/
          r[16].children
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const u = ku(r, n, s);
          i[s] ? (i[s].p(u, o), at(i[s], 1)) : (i[s] = $u(u), i[s].c(), at(i[s], 1), i[s].m(e, null));
        }
        for (cr(), s = n.length; s < i.length; s += 1)
          a(s);
        _r();
      }
    },
    i(r) {
      if (!t) {
        for (let o = 0; o < n.length; o += 1)
          at(i[o]);
        t = !0;
      }
    },
    o(r) {
      i = i.filter(Boolean);
      for (let o = 0; o < i.length; o += 1)
        Ht(i[o]);
      t = !1;
    },
    d(r) {
      r && ge(e), Y0(i, r);
    }
  };
}
function $u(l) {
  let e, t;
  return e = new Fc({
    props: {
      thought: (
        /*child*/
        l[29]
      ),
      rtl: (
        /*rtl*/
        l[0]
      ),
      sanitize_html: (
        /*sanitize_html*/
        l[1]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        l[2]
      ),
      render_markdown: (
        /*render_markdown*/
        l[3]
      ),
      _components: (
        /*_components*/
        l[4]
      ),
      upload: (
        /*upload*/
        l[5]
      ),
      thought_index: (
        /*thought_index*/
        l[6] + 1
      ),
      target: (
        /*target*/
        l[7]
      ),
      theme_mode: (
        /*theme_mode*/
        l[8]
      ),
      _fetch: (
        /*_fetch*/
        l[9]
      ),
      scroll: (
        /*scroll*/
        l[10]
      ),
      allow_file_downloads: (
        /*allow_file_downloads*/
        l[11]
      ),
      display_consecutive_in_same_bubble: (
        /*display_consecutive_in_same_bubble*/
        l[12]
      ),
      i18n: (
        /*i18n*/
        l[13]
      ),
      line_breaks: (
        /*line_breaks*/
        l[14]
      )
    }
  }), {
    c() {
      Li(e.$$.fragment);
    },
    l(n) {
      Ii(e.$$.fragment, n);
    },
    m(n, i) {
      Mi(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*thought_node*/
      65536 && (a.thought = /*child*/
      n[29]), i[0] & /*rtl*/
      1 && (a.rtl = /*rtl*/
      n[0]), i[0] & /*sanitize_html*/
      2 && (a.sanitize_html = /*sanitize_html*/
      n[1]), i[0] & /*latex_delimiters*/
      4 && (a.latex_delimiters = /*latex_delimiters*/
      n[2]), i[0] & /*render_markdown*/
      8 && (a.render_markdown = /*render_markdown*/
      n[3]), i[0] & /*_components*/
      16 && (a._components = /*_components*/
      n[4]), i[0] & /*upload*/
      32 && (a.upload = /*upload*/
      n[5]), i[0] & /*thought_index*/
      64 && (a.thought_index = /*thought_index*/
      n[6] + 1), i[0] & /*target*/
      128 && (a.target = /*target*/
      n[7]), i[0] & /*theme_mode*/
      256 && (a.theme_mode = /*theme_mode*/
      n[8]), i[0] & /*_fetch*/
      512 && (a._fetch = /*_fetch*/
      n[9]), i[0] & /*scroll*/
      1024 && (a.scroll = /*scroll*/
      n[10]), i[0] & /*allow_file_downloads*/
      2048 && (a.allow_file_downloads = /*allow_file_downloads*/
      n[11]), i[0] & /*display_consecutive_in_same_bubble*/
      4096 && (a.display_consecutive_in_same_bubble = /*display_consecutive_in_same_bubble*/
      n[12]), i[0] & /*i18n*/
      8192 && (a.i18n = /*i18n*/
      n[13]), i[0] & /*line_breaks*/
      16384 && (a.line_breaks = /*line_breaks*/
      n[14]), e.$set(a);
    },
    i(n) {
      t || (at(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ht(e.$$.fragment, n), t = !1;
    },
    d(n) {
      zi(e, n);
    }
  };
}
function ig(l) {
  var D, w, m, g, k, b;
  let e, t, n, i, a, r, o, s, u, c, f, _, d;
  i = new Re({ props: { Icon: jm } }), r = new Yo({
    props: {
      message: (
        /*thought_node*/
        ((D = l[16].metadata) == null ? void 0 : D.title) || ""
      ),
      render_markdown: (
        /*render_markdown*/
        l[3]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        l[2]
      ),
      sanitize_html: (
        /*sanitize_html*/
        l[1]
      ),
      allow_tags: (
        /*allow_tags*/
        l[15]
      )
    }
  });
  let h = (
    /*thought_node*/
    ((w = l[16].metadata) == null ? void 0 : w.status) === "pending" && Du()
  ), p = (
    /*thought_node*/
    (((g = (m = l[16]) == null ? void 0 : m.metadata) == null ? void 0 : g.log) || /*thought_node*/
    ((b = (k = l[16]) == null ? void 0 : k.metadata) == null ? void 0 : b.duration)) && yu(l)
  ), v = (
    /*expanded*/
    l[18] && Cu(l)
  );
  return {
    c() {
      e = Un("div"), t = Un("div"), n = Un("span"), Li(i.$$.fragment), a = _l(), Li(r.$$.fragment), o = _l(), h && h.c(), s = _l(), p && p.c(), c = _l(), v && v.c(), this.h();
    },
    l(y) {
      e = jn(y, "DIV", { class: !0 });
      var C = Vn(e);
      t = jn(C, "DIV", {
        class: !0,
        "aria-busy": !0,
        role: !0,
        tabindex: !0
      });
      var F = Vn(t);
      n = jn(F, "SPAN", { class: !0 });
      var B = Vn(n);
      Ii(i.$$.fragment, B), B.forEach(ge), a = ul(F), Ii(r.$$.fragment, F), o = ul(F), h && h.l(F), s = ul(F), p && p.l(F), F.forEach(ge), c = ul(C), v && v.l(C), C.forEach(ge), this.h();
    },
    h() {
      Et(n, "class", "arrow svelte-1812gcz"), wu(
        n,
        "transform",
        /*expanded*/
        l[18] ? "rotate(180deg)" : "rotate(0deg)"
      ), Et(t, "class", "title svelte-1812gcz"), Et(t, "aria-busy", u = /*thought_node*/
      l[16].content === "" || /*thought_node*/
      l[16].content === null), Et(t, "role", "button"), Et(t, "tabindex", "0"), cl(
        t,
        "expanded",
        /*expanded*/
        l[18]
      ), Et(e, "class", "thought-group svelte-1812gcz");
    },
    m(y, C) {
      Qe(y, e, C), dn(e, t), dn(t, n), Mi(i, n, null), dn(t, a), Mi(r, t, null), dn(t, o), h && h.m(t, null), dn(t, s), p && p.m(t, null), dn(e, c), v && v.m(e, null), f = !0, _ || (d = [
        Io(t, "click", eg(
          /*toggleExpanded*/
          l[19]
        )),
        Io(
          t,
          "keydown",
          /*keydown_handler*/
          l[25]
        )
      ], _ = !0);
    },
    p(y, C) {
      var B, I, S, U, V, N;
      C[0] & /*expanded*/
      262144 && wu(
        n,
        "transform",
        /*expanded*/
        y[18] ? "rotate(180deg)" : "rotate(0deg)"
      );
      const F = {};
      C[0] & /*thought_node*/
      65536 && (F.message = /*thought_node*/
      ((B = y[16].metadata) == null ? void 0 : B.title) || ""), C[0] & /*render_markdown*/
      8 && (F.render_markdown = /*render_markdown*/
      y[3]), C[0] & /*latex_delimiters*/
      4 && (F.latex_delimiters = /*latex_delimiters*/
      y[2]), C[0] & /*sanitize_html*/
      2 && (F.sanitize_html = /*sanitize_html*/
      y[1]), C[0] & /*allow_tags*/
      32768 && (F.allow_tags = /*allow_tags*/
      y[15]), r.$set(F), /*thought_node*/
      ((I = y[16].metadata) == null ? void 0 : I.status) === "pending" ? h || (h = Du(), h.c(), h.m(t, s)) : h && (h.d(1), h = null), /*thought_node*/
      (U = (S = y[16]) == null ? void 0 : S.metadata) != null && U.log || /*thought_node*/
      (N = (V = y[16]) == null ? void 0 : V.metadata) != null && N.duration ? p ? p.p(y, C) : (p = yu(y), p.c(), p.m(t, null)) : p && (p.d(1), p = null), (!f || C[0] & /*thought_node*/
      65536 && u !== (u = /*thought_node*/
      y[16].content === "" || /*thought_node*/
      y[16].content === null)) && Et(t, "aria-busy", u), (!f || C[0] & /*expanded*/
      262144) && cl(
        t,
        "expanded",
        /*expanded*/
        y[18]
      ), /*expanded*/
      y[18] ? v ? (v.p(y, C), C[0] & /*expanded*/
      262144 && at(v, 1)) : (v = Cu(y), v.c(), at(v, 1), v.m(e, null)) : v && (cr(), Ht(v, 1, 1, () => {
        v = null;
      }), _r());
    },
    i(y) {
      f || (at(i.$$.fragment, y), at(r.$$.fragment, y), at(v), f = !0);
    },
    o(y) {
      Ht(i.$$.fragment, y), Ht(r.$$.fragment, y), Ht(v), f = !1;
    },
    d(y) {
      y && ge(e), zi(i), zi(r), h && h.d(), p && p.d(), v && v.d(), _ = !1, J0(d);
    }
  };
}
function ag(l) {
  return "children" in l;
}
function og(l, e, t) {
  var n, i;
  let { thought: a } = e, { rtl: r = !1 } = e, { sanitize_html: o } = e, { latex_delimiters: s } = e, { render_markdown: u } = e, { _components: c } = e, { upload: f } = e, { thought_index: _ } = e, { target: d } = e, { theme_mode: h } = e, { _fetch: p } = e, { scroll: v } = e, { allow_file_downloads: D } = e, { display_consecutive_in_same_bubble: w } = e, { i18n: m } = e, { line_breaks: g } = e, { allow_tags: k = !1 } = e, b, y = !1, C = !1, F, B = !1;
  function I() {
    t(18, y = !y), t(24, C = !0);
  }
  function S() {
    F && !B && t(17, F.scrollTop = F.scrollHeight, F);
  }
  function U() {
    F && (F.scrollHeight - F.scrollTop <= F.clientHeight + 10 || (B = !0));
  }
  const V = (T) => T.key === "Enter" && I();
  function N(T) {
    K0[T ? "unshift" : "push"](() => {
      F = T, t(17, F);
    });
  }
  return l.$$set = (T) => {
    "thought" in T && t(21, a = T.thought), "rtl" in T && t(0, r = T.rtl), "sanitize_html" in T && t(1, o = T.sanitize_html), "latex_delimiters" in T && t(2, s = T.latex_delimiters), "render_markdown" in T && t(3, u = T.render_markdown), "_components" in T && t(4, c = T._components), "upload" in T && t(5, f = T.upload), "thought_index" in T && t(6, _ = T.thought_index), "target" in T && t(7, d = T.target), "theme_mode" in T && t(8, h = T.theme_mode), "_fetch" in T && t(9, p = T._fetch), "scroll" in T && t(10, v = T.scroll), "allow_file_downloads" in T && t(11, D = T.allow_file_downloads), "display_consecutive_in_same_bubble" in T && t(12, w = T.display_consecutive_in_same_bubble), "i18n" in T && t(13, m = T.i18n), "line_breaks" in T && t(14, g = T.line_breaks), "allow_tags" in T && t(15, k = T.allow_tags);
  }, l.$$.update = () => {
    l.$$.dirty[0] & /*thought*/
    2097152 && t(16, b = Object.assign(Object.assign({}, a), {
      children: ag(a) ? a.children : []
    })), l.$$.dirty[0] & /*user_expanded_toggled, thought_node, _a*/
    21037056 && (C || t(18, y = (t(22, n = b == null ? void 0 : b.metadata) === null || n === void 0 ? void 0 : n.status) !== "done")), l.$$.dirty[0] & /*thought_node, content_preview_element, _b*/
    8585216 && b.content && F && (t(23, i = b.metadata) === null || i === void 0 ? void 0 : i.status) !== "done" && setTimeout(S, 0);
  }, [
    r,
    o,
    s,
    u,
    c,
    f,
    _,
    d,
    h,
    p,
    v,
    D,
    w,
    m,
    g,
    k,
    b,
    F,
    y,
    I,
    U,
    a,
    n,
    i,
    C,
    V,
    N
  ];
}
class Fc extends W0 {
  constructor(e) {
    super(), Q0(
      this,
      e,
      og,
      ig,
      x0,
      {
        thought: 21,
        rtl: 0,
        sanitize_html: 1,
        latex_delimiters: 2,
        render_markdown: 3,
        _components: 4,
        upload: 5,
        thought_index: 6,
        target: 7,
        theme_mode: 8,
        _fetch: 9,
        scroll: 10,
        allow_file_downloads: 11,
        display_consecutive_in_same_bubble: 12,
        i18n: 13,
        line_breaks: 14,
        allow_tags: 15
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: rg,
  append_hydration: fo,
  assign: Ec,
  attr: ze,
  binding_callbacks: sg,
  check_outros: hl,
  children: Gn,
  claim_component: jl,
  claim_element: Zn,
  claim_space: Lo,
  create_component: Ul,
  destroy_component: Gl,
  destroy_each: ug,
  detach: Me,
  element: Wn,
  empty: Ri,
  ensure_array_like: Su,
  get_spread_object: Cc,
  get_spread_update: Ac,
  group_outros: ml,
  init: _g,
  insert_hydration: Kt,
  listen: zo,
  mount_component: Zl,
  noop: Bu,
  null_to_empty: qu,
  run_all: cg,
  safe_not_equal: fg,
  set_input_value: Tu,
  set_style: Zt,
  space: Mo,
  toggle_class: J,
  transition_in: pe,
  transition_out: Se
} = window.__gradio__svelte__internal;
function Iu(l, e, t) {
  const n = l.slice();
  return n[49] = e[t], n[50] = e, n[51] = t, n;
}
function Lu(l) {
  var i;
  let e, t, n;
  return t = new Hl({
    props: {
      class: "avatar-image",
      src: (
        /*avatar_img*/
        (i = l[2]) == null ? void 0 : i.url
      ),
      alt: (
        /*role*/
        l[4] + " avatar"
      )
    }
  }), {
    c() {
      e = Wn("div"), Ul(t.$$.fragment), this.h();
    },
    l(a) {
      e = Zn(a, "DIV", { class: !0 });
      var r = Gn(e);
      jl(t.$$.fragment, r), r.forEach(Me), this.h();
    },
    h() {
      ze(e, "class", "avatar-container svelte-c133vk");
    },
    m(a, r) {
      Kt(a, e, r), Zl(t, e, null), n = !0;
    },
    p(a, r) {
      var s;
      const o = {};
      r[0] & /*avatar_img*/
      4 && (o.src = /*avatar_img*/
      (s = a[2]) == null ? void 0 : s.url), r[0] & /*role*/
      16 && (o.alt = /*role*/
      a[4] + " avatar"), t.$set(o);
    },
    i(a) {
      n || (pe(t.$$.fragment, a), n = !0);
    },
    o(a) {
      Se(t.$$.fragment, a), n = !1;
    },
    d(a) {
      a && Me(e), Gl(t);
    }
  };
}
function dg(l) {
  let e, t, n, i, a, r = (
    /*thought_index*/
    l[51]
  ), o, s, u;
  const c = [pg, mg], f = [];
  function _(D, w) {
    var m, g;
    return (
      /*message*/
      (g = (m = D[49]) == null ? void 0 : m.metadata) != null && g.title ? 0 : 1
    );
  }
  t = _(l), n = f[t] = c[t](l);
  const d = () => (
    /*div_binding*/
    l[45](e, r)
  ), h = () => (
    /*div_binding*/
    l[45](null, r)
  );
  function p() {
    return (
      /*click_handler*/
      l[46](
        /*message*/
        l[49]
      )
    );
  }
  function v(...D) {
    return (
      /*keydown_handler*/
      l[47](
        /*message*/
        l[49],
        ...D
      )
    );
  }
  return {
    c() {
      e = Wn("div"), n.c(), this.h();
    },
    l(D) {
      e = Zn(D, "DIV", {
        "data-testid": !0,
        dir: !0,
        "aria-label": !0,
        class: !0
      });
      var w = Gn(e);
      n.l(w), w.forEach(Me), this.h();
    },
    h() {
      ze(
        e,
        "data-testid",
        /*role*/
        l[4]
      ), ze(e, "dir", i = /*rtl*/
      l[12] ? "rtl" : "ltr"), ze(e, "aria-label", a = /*role*/
      l[4] + "'s message: " + Nu(
        /*message*/
        l[49]
      )), ze(e, "class", "svelte-c133vk"), J(
        e,
        "latest",
        /*i*/
        l[20] === /*value*/
        l[1].length - 1
      ), J(e, "message-markdown-disabled", !/*render_markdown*/
      l[7]), J(
        e,
        "selectable",
        /*selectable*/
        l[10]
      ), Zt(e, "user-select", "text"), Zt(
        e,
        "cursor",
        /*selectable*/
        l[10] ? "pointer" : "auto"
      ), Zt(
        e,
        "text-align",
        /*rtl*/
        l[12] ? "right" : "left"
      );
    },
    m(D, w) {
      Kt(D, e, w), f[t].m(e, null), d(), o = !0, s || (u = [
        zo(e, "click", p),
        zo(e, "keydown", v)
      ], s = !0);
    },
    p(D, w) {
      l = D;
      let m = t;
      t = _(l), t === m ? f[t].p(l, w) : (ml(), Se(f[m], 1, 1, () => {
        f[m] = null;
      }), hl(), n = f[t], n ? n.p(l, w) : (n = f[t] = c[t](l), n.c()), pe(n, 1), n.m(e, null)), (!o || w[0] & /*role*/
      16) && ze(
        e,
        "data-testid",
        /*role*/
        l[4]
      ), (!o || w[0] & /*rtl*/
      4096 && i !== (i = /*rtl*/
      l[12] ? "rtl" : "ltr")) && ze(e, "dir", i), (!o || w[0] & /*role, messages*/
      48 && a !== (a = /*role*/
      l[4] + "'s message: " + Nu(
        /*message*/
        l[49]
      ))) && ze(e, "aria-label", a), r !== /*thought_index*/
      l[51] && (h(), r = /*thought_index*/
      l[51], d()), (!o || w[0] & /*i, value*/
      1048578) && J(
        e,
        "latest",
        /*i*/
        l[20] === /*value*/
        l[1].length - 1
      ), (!o || w[0] & /*render_markdown*/
      128) && J(e, "message-markdown-disabled", !/*render_markdown*/
      l[7]), (!o || w[0] & /*selectable*/
      1024) && J(
        e,
        "selectable",
        /*selectable*/
        l[10]
      ), w[0] & /*selectable*/
      1024 && Zt(
        e,
        "cursor",
        /*selectable*/
        l[10] ? "pointer" : "auto"
      ), w[0] & /*rtl*/
      4096 && Zt(
        e,
        "text-align",
        /*rtl*/
        l[12] ? "right" : "left"
      );
    },
    i(D) {
      o || (pe(n), o = !0);
    },
    o(D) {
      Se(n), o = !1;
    },
    d(D) {
      D && Me(e), f[t].d(), h(), s = !1, cg(u);
    }
  };
}
function hg(l) {
  let e, t, n;
  function i() {
    l[44].call(
      e,
      /*thought_index*/
      l[51]
    );
  }
  return {
    c() {
      e = Wn("textarea"), this.h();
    },
    l(a) {
      e = Zn(a, "TEXTAREA", { class: !0 }), Gn(e).forEach(Me), this.h();
    },
    h() {
      ze(e, "class", "edit-textarea svelte-c133vk"), e.autofocus = !0, Zt(e, "width", `max(${/*message_widths*/
      l[29][
        /*thought_index*/
        l[51]
      ]}px, 160px)`), Zt(e, "min-height", `${/*message_heights*/
      l[30][
        /*thought_index*/
        l[51]
      ]}px`);
    },
    m(a, r) {
      Kt(a, e, r), Tu(
        e,
        /*edit_messages*/
        l[0][
          /*thought_index*/
          l[51]
        ]
      ), e.focus(), t || (n = zo(e, "input", i), t = !0);
    },
    p(a, r) {
      l = a, r[0] & /*edit_messages*/
      1 && Tu(
        e,
        /*edit_messages*/
        l[0][
          /*thought_index*/
          l[51]
        ]
      ), r[0] & /*message_widths*/
      536870912 && Zt(e, "width", `max(${/*message_widths*/
      l[29][
        /*thought_index*/
        l[51]
      ]}px, 160px)`), r[0] & /*message_heights*/
      1073741824 && Zt(e, "min-height", `${/*message_heights*/
      l[30][
        /*thought_index*/
        l[51]
      ]}px`);
    },
    i: Bu,
    o: Bu,
    d(a) {
      a && Me(e), t = !1, n();
    }
  };
}
function mg(l) {
  let e, t;
  return e = new wc({
    props: {
      message: (
        /*message*/
        l[49]
      ),
      sanitize_html: (
        /*sanitize_html*/
        l[9]
      ),
      allow_tags: (
        /*allow_tags*/
        l[26]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        l[8]
      ),
      render_markdown: (
        /*render_markdown*/
        l[7]
      ),
      _components: (
        /*_components*/
        l[19]
      ),
      upload: (
        /*upload*/
        l[16]
      ),
      thought_index: (
        /*thought_index*/
        l[51]
      ),
      target: (
        /*target*/
        l[17]
      ),
      theme_mode: (
        /*theme_mode*/
        l[18]
      ),
      _fetch: (
        /*_fetch*/
        l[11]
      ),
      scroll: (
        /*scroll*/
        l[21]
      ),
      allow_file_downloads: (
        /*allow_file_downloads*/
        l[22]
      ),
      display_consecutive_in_same_bubble: (
        /*display_consecutive_in_same_bubble*/
        l[24]
      ),
      i18n: (
        /*i18n*/
        l[14]
      ),
      line_breaks: (
        /*line_breaks*/
        l[15]
      )
    }
  }), {
    c() {
      Ul(e.$$.fragment);
    },
    l(n) {
      jl(e.$$.fragment, n);
    },
    m(n, i) {
      Zl(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*messages*/
      32 && (a.message = /*message*/
      n[49]), i[0] & /*sanitize_html*/
      512 && (a.sanitize_html = /*sanitize_html*/
      n[9]), i[0] & /*allow_tags*/
      67108864 && (a.allow_tags = /*allow_tags*/
      n[26]), i[0] & /*latex_delimiters*/
      256 && (a.latex_delimiters = /*latex_delimiters*/
      n[8]), i[0] & /*render_markdown*/
      128 && (a.render_markdown = /*render_markdown*/
      n[7]), i[0] & /*_components*/
      524288 && (a._components = /*_components*/
      n[19]), i[0] & /*upload*/
      65536 && (a.upload = /*upload*/
      n[16]), i[0] & /*target*/
      131072 && (a.target = /*target*/
      n[17]), i[0] & /*theme_mode*/
      262144 && (a.theme_mode = /*theme_mode*/
      n[18]), i[0] & /*_fetch*/
      2048 && (a._fetch = /*_fetch*/
      n[11]), i[0] & /*scroll*/
      2097152 && (a.scroll = /*scroll*/
      n[21]), i[0] & /*allow_file_downloads*/
      4194304 && (a.allow_file_downloads = /*allow_file_downloads*/
      n[22]), i[0] & /*display_consecutive_in_same_bubble*/
      16777216 && (a.display_consecutive_in_same_bubble = /*display_consecutive_in_same_bubble*/
      n[24]), i[0] & /*i18n*/
      16384 && (a.i18n = /*i18n*/
      n[14]), i[0] & /*line_breaks*/
      32768 && (a.line_breaks = /*line_breaks*/
      n[15]), e.$set(a);
    },
    i(n) {
      t || (pe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Se(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Gl(e, n);
    }
  };
}
function pg(l) {
  let e, t;
  return e = new Fc({
    props: {
      thought: (
        /*message*/
        l[49]
      ),
      rtl: (
        /*rtl*/
        l[12]
      ),
      sanitize_html: (
        /*sanitize_html*/
        l[9]
      ),
      allow_tags: (
        /*allow_tags*/
        l[26]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        l[8]
      ),
      render_markdown: (
        /*render_markdown*/
        l[7]
      ),
      _components: (
        /*_components*/
        l[19]
      ),
      upload: (
        /*upload*/
        l[16]
      ),
      thought_index: (
        /*thought_index*/
        l[51]
      ),
      target: (
        /*target*/
        l[17]
      ),
      theme_mode: (
        /*theme_mode*/
        l[18]
      ),
      _fetch: (
        /*_fetch*/
        l[11]
      ),
      scroll: (
        /*scroll*/
        l[21]
      ),
      allow_file_downloads: (
        /*allow_file_downloads*/
        l[22]
      ),
      display_consecutive_in_same_bubble: (
        /*display_consecutive_in_same_bubble*/
        l[24]
      ),
      i18n: (
        /*i18n*/
        l[14]
      ),
      line_breaks: (
        /*line_breaks*/
        l[15]
      )
    }
  }), {
    c() {
      Ul(e.$$.fragment);
    },
    l(n) {
      jl(e.$$.fragment, n);
    },
    m(n, i) {
      Zl(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*messages*/
      32 && (a.thought = /*message*/
      n[49]), i[0] & /*rtl*/
      4096 && (a.rtl = /*rtl*/
      n[12]), i[0] & /*sanitize_html*/
      512 && (a.sanitize_html = /*sanitize_html*/
      n[9]), i[0] & /*allow_tags*/
      67108864 && (a.allow_tags = /*allow_tags*/
      n[26]), i[0] & /*latex_delimiters*/
      256 && (a.latex_delimiters = /*latex_delimiters*/
      n[8]), i[0] & /*render_markdown*/
      128 && (a.render_markdown = /*render_markdown*/
      n[7]), i[0] & /*_components*/
      524288 && (a._components = /*_components*/
      n[19]), i[0] & /*upload*/
      65536 && (a.upload = /*upload*/
      n[16]), i[0] & /*target*/
      131072 && (a.target = /*target*/
      n[17]), i[0] & /*theme_mode*/
      262144 && (a.theme_mode = /*theme_mode*/
      n[18]), i[0] & /*_fetch*/
      2048 && (a._fetch = /*_fetch*/
      n[11]), i[0] & /*scroll*/
      2097152 && (a.scroll = /*scroll*/
      n[21]), i[0] & /*allow_file_downloads*/
      4194304 && (a.allow_file_downloads = /*allow_file_downloads*/
      n[22]), i[0] & /*display_consecutive_in_same_bubble*/
      16777216 && (a.display_consecutive_in_same_bubble = /*display_consecutive_in_same_bubble*/
      n[24]), i[0] & /*i18n*/
      16384 && (a.i18n = /*i18n*/
      n[14]), i[0] & /*line_breaks*/
      32768 && (a.line_breaks = /*line_breaks*/
      n[15]), e.$set(a);
    },
    i(n) {
      t || (pe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Se(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Gl(e, n);
    }
  };
}
function zu(l) {
  let e, t;
  const n = [
    /*button_panel_props*/
    l[31],
    {
      current_feedback: (
        /*current_feedback*/
        l[25]
      )
    },
    { watermark: (
      /*watermark*/
      l[27]
    ) },
    { i18n: (
      /*i18n*/
      l[14]
    ) }
  ];
  let i = {};
  for (let a = 0; a < n.length; a += 1)
    i = Ec(i, n[a]);
  return e = new gc({ props: i }), e.$on(
    "copy",
    /*copy_handler*/
    l[48]
  ), {
    c() {
      Ul(e.$$.fragment);
    },
    l(a) {
      jl(e.$$.fragment, a);
    },
    m(a, r) {
      Zl(e, a, r), t = !0;
    },
    p(a, r) {
      const o = r[0] & /*current_feedback, watermark, i18n*/
      167788544 | r[1] & /*button_panel_props*/
      1 ? Ac(n, [
        r[1] & /*button_panel_props*/
        1 && Cc(
          /*button_panel_props*/
          a[31]
        ),
        r[0] & /*current_feedback*/
        33554432 && {
          current_feedback: (
            /*current_feedback*/
            a[25]
          )
        },
        r[0] & /*watermark*/
        134217728 && { watermark: (
          /*watermark*/
          a[27]
        ) },
        r[0] & /*i18n*/
        16384 && { i18n: (
          /*i18n*/
          a[14]
        ) }
      ]) : {};
      e.$set(o);
    },
    i(a) {
      t || (pe(e.$$.fragment, a), t = !0);
    },
    o(a) {
      Se(e.$$.fragment, a), t = !1;
    },
    d(a) {
      Gl(e, a);
    }
  };
}
function Mu(l) {
  let e, t, n, i, a, r, o;
  const s = [hg, dg], u = [];
  function c(_, d) {
    return (
      /*in_edit_mode*/
      _[23] && /*message*/
      _[49].type === "text" ? 0 : 1
    );
  }
  t = c(l), n = u[t] = s[t](l);
  let f = (
    /*layout*/
    l[6] === "panel" && zu(l)
  );
  return {
    c() {
      e = Wn("div"), n.c(), a = Mo(), f && f.c(), r = Ri(), this.h();
    },
    l(_) {
      e = Zn(_, "DIV", { class: !0 });
      var d = Gn(e);
      n.l(d), d.forEach(Me), a = Lo(_), f && f.l(_), r = Ri(), this.h();
    },
    h() {
      ze(e, "class", i = "message " + (/*display_consecutive_in_same_bubble*/
      l[24] ? "" : (
        /*role*/
        l[4]
      )) + " svelte-c133vk"), J(e, "panel-full-width", !0), J(e, "message-markdown-disabled", !/*render_markdown*/
      l[7]), J(
        e,
        "component",
        /*message*/
        l[49].type === "component"
      ), J(e, "html", wr(
        /*message*/
        l[49]
      ) && /*message*/
      l[49].content.component === "html"), J(
        e,
        "thought",
        /*thought_index*/
        l[51] > 0
      );
    },
    m(_, d) {
      Kt(_, e, d), u[t].m(e, null), Kt(_, a, d), f && f.m(_, d), Kt(_, r, d), o = !0;
    },
    p(_, d) {
      let h = t;
      t = c(_), t === h ? u[t].p(_, d) : (ml(), Se(u[h], 1, 1, () => {
        u[h] = null;
      }), hl(), n = u[t], n ? n.p(_, d) : (n = u[t] = s[t](_), n.c()), pe(n, 1), n.m(e, null)), (!o || d[0] & /*display_consecutive_in_same_bubble, role*/
      16777232 && i !== (i = "message " + (/*display_consecutive_in_same_bubble*/
      _[24] ? "" : (
        /*role*/
        _[4]
      )) + " svelte-c133vk")) && ze(e, "class", i), (!o || d[0] & /*display_consecutive_in_same_bubble, role*/
      16777232) && J(e, "panel-full-width", !0), (!o || d[0] & /*display_consecutive_in_same_bubble, role, render_markdown*/
      16777360) && J(e, "message-markdown-disabled", !/*render_markdown*/
      _[7]), (!o || d[0] & /*display_consecutive_in_same_bubble, role, messages*/
      16777264) && J(
        e,
        "component",
        /*message*/
        _[49].type === "component"
      ), (!o || d[0] & /*display_consecutive_in_same_bubble, role, messages*/
      16777264) && J(e, "html", wr(
        /*message*/
        _[49]
      ) && /*message*/
      _[49].content.component === "html"), (!o || d[0] & /*display_consecutive_in_same_bubble, role*/
      16777232) && J(
        e,
        "thought",
        /*thought_index*/
        _[51] > 0
      ), /*layout*/
      _[6] === "panel" ? f ? (f.p(_, d), d[0] & /*layout*/
      64 && pe(f, 1)) : (f = zu(_), f.c(), pe(f, 1), f.m(r.parentNode, r)) : f && (ml(), Se(f, 1, 1, () => {
        f = null;
      }), hl());
    },
    i(_) {
      o || (pe(n), pe(f), o = !0);
    },
    o(_) {
      Se(n), Se(f), o = !1;
    },
    d(_) {
      _ && (Me(e), Me(a), Me(r)), u[t].d(), f && f.d(_);
    }
  };
}
function Ru(l) {
  let e, t;
  const n = [
    /*button_panel_props*/
    l[31],
    { i18n: (
      /*i18n*/
      l[14]
    ) }
  ];
  let i = {};
  for (let a = 0; a < n.length; a += 1)
    i = Ec(i, n[a]);
  return e = new gc({ props: i }), {
    c() {
      Ul(e.$$.fragment);
    },
    l(a) {
      jl(e.$$.fragment, a);
    },
    m(a, r) {
      Zl(e, a, r), t = !0;
    },
    p(a, r) {
      const o = r[0] & /*i18n*/
      16384 | r[1] & /*button_panel_props*/
      1 ? Ac(n, [
        r[1] & /*button_panel_props*/
        1 && Cc(
          /*button_panel_props*/
          a[31]
        ),
        r[0] & /*i18n*/
        16384 && { i18n: (
          /*i18n*/
          a[14]
        ) }
      ]) : {};
      e.$set(o);
    },
    i(a) {
      t || (pe(e.$$.fragment, a), t = !0);
    },
    o(a) {
      Se(e.$$.fragment, a), t = !1;
    },
    d(a) {
      Gl(e, a);
    }
  };
}
function gg(l) {
  let e, t, n, i, a, r, o, s, u, c = (
    /*avatar_img*/
    l[2] !== null && Lu(l)
  ), f = Su(
    /*messages*/
    l[5]
  ), _ = [];
  for (let p = 0; p < f.length; p += 1)
    _[p] = Mu(Iu(l, f, p));
  const d = (p) => Se(_[p], 1, 1, () => {
    _[p] = null;
  });
  let h = (
    /*layout*/
    l[6] === "bubble" && Ru(l)
  );
  return {
    c() {
      e = Wn("div"), c && c.c(), t = Mo(), n = Wn("div"), i = Wn("div");
      for (let p = 0; p < _.length; p += 1)
        _[p].c();
      o = Mo(), h && h.c(), s = Ri(), this.h();
    },
    l(p) {
      e = Zn(p, "DIV", { class: !0 });
      var v = Gn(e);
      c && c.l(v), t = Lo(v), n = Zn(v, "DIV", { class: !0 });
      var D = Gn(n);
      i = Zn(D, "DIV", { class: !0 });
      var w = Gn(i);
      for (let m = 0; m < _.length; m += 1)
        _[m].l(w);
      w.forEach(Me), D.forEach(Me), v.forEach(Me), o = Lo(p), h && h.l(p), s = Ri(), this.h();
    },
    h() {
      ze(i, "class", a = qu(
        /*display_consecutive_in_same_bubble*/
        l[24] ? (
          /*role*/
          l[4]
        ) : ""
      ) + " svelte-c133vk"), J(
        i,
        "message",
        /*display_consecutive_in_same_bubble*/
        l[24]
      ), ze(n, "class", "flex-wrap svelte-c133vk"), J(
        n,
        "role",
        /*role*/
        l[4]
      ), J(
        n,
        "component-wrap",
        /*messages*/
        l[5][0].type === "component"
      ), ze(e, "class", r = "message-row " + /*layout*/
      l[6] + " " + /*role*/
      l[4] + "-row svelte-c133vk"), J(
        e,
        "with_avatar",
        /*avatar_img*/
        l[2] !== null
      ), J(
        e,
        "with_opposite_avatar",
        /*opposite_avatar_img*/
        l[3] !== null
      );
    },
    m(p, v) {
      Kt(p, e, v), c && c.m(e, null), fo(e, t), fo(e, n), fo(n, i);
      for (let D = 0; D < _.length; D += 1)
        _[D] && _[D].m(i, null);
      Kt(p, o, v), h && h.m(p, v), Kt(p, s, v), u = !0;
    },
    p(p, v) {
      if (/*avatar_img*/
      p[2] !== null ? c ? (c.p(p, v), v[0] & /*avatar_img*/
      4 && pe(c, 1)) : (c = Lu(p), c.c(), pe(c, 1), c.m(e, t)) : c && (ml(), Se(c, 1, 1, () => {
        c = null;
      }), hl()), v[0] & /*current_feedback, watermark, i18n, dispatch, layout, display_consecutive_in_same_bubble, role, render_markdown, messages, edit_messages, message_widths, message_heights, in_edit_mode, rtl, messageElements, i, value, selectable, sanitize_html, allow_tags, latex_delimiters, _components, upload, target, theme_mode, _fetch, scroll, allow_file_downloads, line_breaks*/
      2147483635 | v[1] & /*button_panel_props, handle_select*/
      3) {
        f = Su(
          /*messages*/
          p[5]
        );
        let D;
        for (D = 0; D < f.length; D += 1) {
          const w = Iu(p, f, D);
          _[D] ? (_[D].p(w, v), pe(_[D], 1)) : (_[D] = Mu(w), _[D].c(), pe(_[D], 1), _[D].m(i, null));
        }
        for (ml(), D = f.length; D < _.length; D += 1)
          d(D);
        hl();
      }
      (!u || v[0] & /*display_consecutive_in_same_bubble, role*/
      16777232 && a !== (a = qu(
        /*display_consecutive_in_same_bubble*/
        p[24] ? (
          /*role*/
          p[4]
        ) : ""
      ) + " svelte-c133vk")) && ze(i, "class", a), (!u || v[0] & /*display_consecutive_in_same_bubble, role, display_consecutive_in_same_bubble*/
      16777232) && J(
        i,
        "message",
        /*display_consecutive_in_same_bubble*/
        p[24]
      ), (!u || v[0] & /*role*/
      16) && J(
        n,
        "role",
        /*role*/
        p[4]
      ), (!u || v[0] & /*messages*/
      32) && J(
        n,
        "component-wrap",
        /*messages*/
        p[5][0].type === "component"
      ), (!u || v[0] & /*layout, role*/
      80 && r !== (r = "message-row " + /*layout*/
      p[6] + " " + /*role*/
      p[4] + "-row svelte-c133vk")) && ze(e, "class", r), (!u || v[0] & /*layout, role, avatar_img*/
      84) && J(
        e,
        "with_avatar",
        /*avatar_img*/
        p[2] !== null
      ), (!u || v[0] & /*layout, role, opposite_avatar_img*/
      88) && J(
        e,
        "with_opposite_avatar",
        /*opposite_avatar_img*/
        p[3] !== null
      ), /*layout*/
      p[6] === "bubble" ? h ? (h.p(p, v), v[0] & /*layout*/
      64 && pe(h, 1)) : (h = Ru(p), h.c(), pe(h, 1), h.m(s.parentNode, s)) : h && (ml(), Se(h, 1, 1, () => {
        h = null;
      }), hl());
    },
    i(p) {
      if (!u) {
        pe(c);
        for (let v = 0; v < f.length; v += 1)
          pe(_[v]);
        pe(h), u = !0;
      }
    },
    o(p) {
      Se(c), _ = _.filter(Boolean);
      for (let v = 0; v < _.length; v += 1)
        Se(_[v]);
      Se(h), u = !1;
    },
    d(p) {
      p && (Me(e), Me(o), Me(s)), c && c.d(), ug(_, p), h && h.d(p);
    }
  };
}
function Nu(l) {
  var e, t, n, i, a, r;
  return l.type === "text" ? l.content : l.type === "component" && l.content.component === "file" ? Array.isArray(l.content.value) ? `file of extension type: ${(e = l.content.value[0].orig_name) === null || e === void 0 ? void 0 : e.split(".").pop()}` : `file of extension type: ${(n = (t = l.content.value) === null || t === void 0 ? void 0 : t.orig_name) === null || n === void 0 ? void 0 : n.split(".").pop()}` + ((a = (i = l.content.value) === null || i === void 0 ? void 0 : i.orig_name) !== null && a !== void 0 ? a : "") : `a component of type ${(r = l.content.component) !== null && r !== void 0 ? r : "unknown"}`;
}
function bg(l, e, t) {
  var n, i;
  let { value: a } = e, { avatar_img: r } = e, { opposite_avatar_img: o = null } = e, { role: s = "user" } = e, { messages: u = [] } = e, { layout: c } = e, { render_markdown: f } = e, { latex_delimiters: _ } = e, { sanitize_html: d } = e, { selectable: h } = e, { _fetch: p } = e, { rtl: v } = e, { dispatch: D } = e, { i18n: w } = e, { line_breaks: m } = e, { upload: g } = e, { target: k } = e, { theme_mode: b } = e, { _components: y } = e, { i: C } = e, { show_copy_button: F } = e, { generating: B } = e, { feedback_options: I } = e, { show_like: S } = e, { show_edit: U } = e, { show_retry: V } = e, { show_undo: N } = e, { msg_format: T } = e, { handle_action: x } = e, { scroll: H } = e, { allow_file_downloads: ee } = e, { in_edit_mode: he } = e, { edit_messages: q } = e, { display_consecutive_in_same_bubble: Q } = e, { current_feedback: ve = null } = e, { allow_tags: ue = !1 } = e, { watermark: be = null } = e, _e = [], Be = Array(u.length).fill(160), L = Array(u.length).fill(0);
  function ut($, we) {
    D("select", {
      index: we.index,
      value: we.content
    });
  }
  let Je;
  function qe($) {
    q[$] = this.value, t(0, q);
  }
  function ce($, we) {
    sg[$ ? "unshift" : "push"](() => {
      _e[we] = $, t(28, _e);
    });
  }
  const _t = ($) => ut(C, $), Te = ($, we) => {
    we.key === "Enter" && ut(C, $);
  }, nl = ($) => D("copy", $.detail);
  return l.$$set = ($) => {
    "value" in $ && t(1, a = $.value), "avatar_img" in $ && t(2, r = $.avatar_img), "opposite_avatar_img" in $ && t(3, o = $.opposite_avatar_img), "role" in $ && t(4, s = $.role), "messages" in $ && t(5, u = $.messages), "layout" in $ && t(6, c = $.layout), "render_markdown" in $ && t(7, f = $.render_markdown), "latex_delimiters" in $ && t(8, _ = $.latex_delimiters), "sanitize_html" in $ && t(9, d = $.sanitize_html), "selectable" in $ && t(10, h = $.selectable), "_fetch" in $ && t(11, p = $._fetch), "rtl" in $ && t(12, v = $.rtl), "dispatch" in $ && t(13, D = $.dispatch), "i18n" in $ && t(14, w = $.i18n), "line_breaks" in $ && t(15, m = $.line_breaks), "upload" in $ && t(16, g = $.upload), "target" in $ && t(17, k = $.target), "theme_mode" in $ && t(18, b = $.theme_mode), "_components" in $ && t(19, y = $._components), "i" in $ && t(20, C = $.i), "show_copy_button" in $ && t(33, F = $.show_copy_button), "generating" in $ && t(34, B = $.generating), "feedback_options" in $ && t(35, I = $.feedback_options), "show_like" in $ && t(36, S = $.show_like), "show_edit" in $ && t(37, U = $.show_edit), "show_retry" in $ && t(38, V = $.show_retry), "show_undo" in $ && t(39, N = $.show_undo), "msg_format" in $ && t(40, T = $.msg_format), "handle_action" in $ && t(41, x = $.handle_action), "scroll" in $ && t(21, H = $.scroll), "allow_file_downloads" in $ && t(22, ee = $.allow_file_downloads), "in_edit_mode" in $ && t(23, he = $.in_edit_mode), "edit_messages" in $ && t(0, q = $.edit_messages), "display_consecutive_in_same_bubble" in $ && t(24, Q = $.display_consecutive_in_same_bubble), "current_feedback" in $ && t(25, ve = $.current_feedback), "allow_tags" in $ && t(26, ue = $.allow_tags), "watermark" in $ && t(27, be = $.watermark);
  }, l.$$.update = () => {
    if (l.$$.dirty[0] & /*in_edit_mode, messageElements, messages*/
    276824096 | l.$$.dirty[1] & /*_a, _b*/
    6144 && he) {
      const $ = _e.length - u.length;
      for (let we = $; we < _e.length; we++)
        we >= 0 && (t(
          29,
          Be[we - $] = t(42, n = _e[we]) === null || n === void 0 ? void 0 : n.clientWidth,
          Be
        ), t(
          30,
          L[we - $] = t(43, i = _e[we]) === null || i === void 0 ? void 0 : i.clientHeight,
          L
        ));
    }
    l.$$.dirty[0] & /*in_edit_mode, messages, role, avatar_img, layout, dispatch, current_feedback, watermark*/
    176169076 | l.$$.dirty[1] & /*handle_action, show_like, feedback_options, show_retry, show_undo, show_edit, generating, show_copy_button, msg_format*/
    2044 && t(31, Je = {
      handle_action: x,
      likeable: S,
      feedback_options: I,
      show_retry: V,
      show_undo: N,
      show_edit: U,
      in_edit_mode: he,
      generating: B,
      show_copy_button: F,
      message: T === "tuples" ? u[0] : u,
      position: s === "user" ? "right" : "left",
      avatar: r,
      layout: c,
      dispatch: D,
      current_feedback: ve,
      watermark: be
    });
  }, [
    q,
    a,
    r,
    o,
    s,
    u,
    c,
    f,
    _,
    d,
    h,
    p,
    v,
    D,
    w,
    m,
    g,
    k,
    b,
    y,
    C,
    H,
    ee,
    he,
    Q,
    ve,
    ue,
    be,
    _e,
    Be,
    L,
    Je,
    ut,
    F,
    B,
    I,
    S,
    U,
    V,
    N,
    T,
    x,
    n,
    i,
    qe,
    ce,
    _t,
    Te,
    nl
  ];
}
class vg extends rg {
  constructor(e) {
    super(), _g(
      this,
      e,
      bg,
      gg,
      fg,
      {
        value: 1,
        avatar_img: 2,
        opposite_avatar_img: 3,
        role: 4,
        messages: 5,
        layout: 6,
        render_markdown: 7,
        latex_delimiters: 8,
        sanitize_html: 9,
        selectable: 10,
        _fetch: 11,
        rtl: 12,
        dispatch: 13,
        i18n: 14,
        line_breaks: 15,
        upload: 16,
        target: 17,
        theme_mode: 18,
        _components: 19,
        i: 20,
        show_copy_button: 33,
        generating: 34,
        feedback_options: 35,
        show_like: 36,
        show_edit: 37,
        show_retry: 38,
        show_undo: 39,
        msg_format: 40,
        handle_action: 41,
        scroll: 21,
        allow_file_downloads: 22,
        in_edit_mode: 23,
        edit_messages: 0,
        display_consecutive_in_same_bubble: 24,
        current_feedback: 25,
        allow_tags: 26,
        watermark: 27
      },
      null,
      [-1, -1]
    );
  }
}
var Ou = Object.prototype.hasOwnProperty;
function Ro(l, e) {
  var t, n;
  if (l === e) return !0;
  if (l && e && (t = l.constructor) === e.constructor) {
    if (t === Date) return l.getTime() === e.getTime();
    if (t === RegExp) return l.toString() === e.toString();
    if (t === Array) {
      if ((n = l.length) === e.length)
        for (; n-- && Ro(l[n], e[n]); ) ;
      return n === -1;
    }
    if (!t || typeof l == "object") {
      n = 0;
      for (t in l)
        if (Ou.call(l, t) && ++n && !Ou.call(e, t) || !(t in e) || !Ro(l[t], e[t])) return !1;
      return Object.keys(e).length === n;
    }
  }
  return l !== l && e !== e;
}
const {
  SvelteComponent: wg,
  append_hydration: ho,
  attr: fn,
  check_outros: kg,
  children: No,
  claim_component: Dg,
  claim_element: yi,
  claim_space: yg,
  create_component: Fg,
  destroy_component: Eg,
  detach: zl,
  element: Fi,
  get_svelte_dataset: Cg,
  group_outros: Ag,
  init: $g,
  insert_hydration: $c,
  mount_component: Sg,
  safe_not_equal: Bg,
  space: qg,
  toggle_class: mi,
  transition_in: Ei,
  transition_out: Oo
} = window.__gradio__svelte__internal;
function Hu(l) {
  let e, t, n;
  return t = new Hl({
    props: {
      class: "avatar-image",
      src: (
        /*avatar_images*/
        l[1][1].url
      ),
      alt: "bot avatar"
    }
  }), {
    c() {
      e = Fi("div"), Fg(t.$$.fragment), this.h();
    },
    l(i) {
      e = yi(i, "DIV", { class: !0 });
      var a = No(e);
      Dg(t.$$.fragment, a), a.forEach(zl), this.h();
    },
    h() {
      fn(e, "class", "avatar-container svelte-1u8ierl");
    },
    m(i, a) {
      $c(i, e, a), Sg(t, e, null), n = !0;
    },
    p(i, a) {
      const r = {};
      a & /*avatar_images*/
      2 && (r.src = /*avatar_images*/
      i[1][1].url), t.$set(r);
    },
    i(i) {
      n || (Ei(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Oo(t.$$.fragment, i), n = !1;
    },
    d(i) {
      i && zl(e), Eg(t);
    }
  };
}
function Tg(l) {
  let e, t, n, i, a = '<span class="sr-only">Loading content</span> <div class="dots svelte-1u8ierl"><div class="dot svelte-1u8ierl"></div> <div class="dot svelte-1u8ierl"></div> <div class="dot svelte-1u8ierl"></div></div>', r, o, s = (
    /*avatar_images*/
    l[1][1] !== null && Hu(l)
  );
  return {
    c() {
      e = Fi("div"), s && s.c(), t = qg(), n = Fi("div"), i = Fi("div"), i.innerHTML = a, this.h();
    },
    l(u) {
      e = yi(u, "DIV", { class: !0 });
      var c = No(e);
      s && s.l(c), t = yg(c), n = yi(c, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0,
        "aria-live": !0
      });
      var f = No(n);
      i = yi(f, "DIV", { class: !0, "data-svelte-h": !0 }), Cg(i) !== "svelte-1vfby8" && (i.innerHTML = a), f.forEach(zl), c.forEach(zl), this.h();
    },
    h() {
      fn(i, "class", "message-content svelte-1u8ierl"), fn(n, "class", r = "message bot pending " + /*layout*/
      l[0] + " svelte-1u8ierl"), fn(n, "role", "status"), fn(n, "aria-label", "Loading response"), fn(n, "aria-live", "polite"), mi(
        n,
        "with_avatar",
        /*avatar_images*/
        l[1][1] !== null
      ), mi(
        n,
        "with_opposite_avatar",
        /*avatar_images*/
        l[1][0] !== null
      ), fn(e, "class", "container svelte-1u8ierl");
    },
    m(u, c) {
      $c(u, e, c), s && s.m(e, null), ho(e, t), ho(e, n), ho(n, i), o = !0;
    },
    p(u, [c]) {
      /*avatar_images*/
      u[1][1] !== null ? s ? (s.p(u, c), c & /*avatar_images*/
      2 && Ei(s, 1)) : (s = Hu(u), s.c(), Ei(s, 1), s.m(e, t)) : s && (Ag(), Oo(s, 1, 1, () => {
        s = null;
      }), kg()), (!o || c & /*layout*/
      1 && r !== (r = "message bot pending " + /*layout*/
      u[0] + " svelte-1u8ierl")) && fn(n, "class", r), (!o || c & /*layout, avatar_images*/
      3) && mi(
        n,
        "with_avatar",
        /*avatar_images*/
        u[1][1] !== null
      ), (!o || c & /*layout, avatar_images*/
      3) && mi(
        n,
        "with_opposite_avatar",
        /*avatar_images*/
        u[1][0] !== null
      );
    },
    i(u) {
      o || (Ei(s), o = !0);
    },
    o(u) {
      Oo(s), o = !1;
    },
    d(u) {
      u && zl(e), s && s.d();
    }
  };
}
function Ig(l, e, t) {
  let { layout: n = "bubble" } = e, { avatar_images: i = [null, null] } = e;
  return l.$$set = (a) => {
    "layout" in a && t(0, n = a.layout), "avatar_images" in a && t(1, i = a.avatar_images);
  }, [n, i];
}
class Sc extends wg {
  constructor(e) {
    super(), $g(this, e, Ig, Tg, Bg, { layout: 0, avatar_images: 1 });
  }
}
const {
  SvelteComponent: Lg,
  append_hydration: ke,
  attr: M,
  check_outros: Dn,
  children: de,
  claim_component: En,
  claim_element: re,
  claim_space: bl,
  claim_text: Yn,
  create_component: Cn,
  destroy_component: An,
  destroy_each: Bc,
  detach: O,
  element: se,
  empty: Ni,
  ensure_array_like: Oi,
  get_svelte_dataset: zg,
  group_outros: yn,
  init: Mg,
  insert_hydration: De,
  listen: Rg,
  mount_component: $n,
  noop: Xn,
  safe_not_equal: Ng,
  set_data: Xi,
  space: vl,
  src_url_equal: Hi,
  text: Qn,
  transition_in: W,
  transition_out: oe
} = window.__gradio__svelte__internal, { createEventDispatcher: Og } = window.__gradio__svelte__internal;
function Pu(l, e, t) {
  const n = l.slice();
  return n[6] = e[t], n[8] = t, n;
}
function Vu(l, e, t) {
  const n = l.slice();
  return n[9] = e[t], n[8] = t, n;
}
function ju(l) {
  let e, t, n;
  return t = new Yo({
    props: {
      message: (
        /*placeholder*/
        l[1]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        l[2]
      )
    }
  }), {
    c() {
      e = se("div"), Cn(t.$$.fragment), this.h();
    },
    l(i) {
      e = re(i, "DIV", { class: !0 });
      var a = de(e);
      En(t.$$.fragment, a), a.forEach(O), this.h();
    },
    h() {
      M(e, "class", "placeholder svelte-9nrvad");
    },
    m(i, a) {
      De(i, e, a), $n(t, e, null), n = !0;
    },
    p(i, a) {
      const r = {};
      a & /*placeholder*/
      2 && (r.message = /*placeholder*/
      i[1]), a & /*latex_delimiters*/
      4 && (r.latex_delimiters = /*latex_delimiters*/
      i[2]), t.$set(r);
    },
    i(i) {
      n || (W(t.$$.fragment, i), n = !0);
    },
    o(i) {
      oe(t.$$.fragment, i), n = !1;
    },
    d(i) {
      i && O(e), An(t);
    }
  };
}
function Uu(l) {
  let e, t, n = Oi(
    /*examples*/
    l[0]
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = Ku(Pu(l, n, r));
  const a = (r) => oe(i[r], 1, 1, () => {
    i[r] = null;
  });
  return {
    c() {
      e = se("div");
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      this.h();
    },
    l(r) {
      e = re(r, "DIV", { class: !0, role: !0 });
      var o = de(e);
      for (let s = 0; s < i.length; s += 1)
        i[s].l(o);
      o.forEach(O), this.h();
    },
    h() {
      M(e, "class", "examples svelte-9nrvad"), M(e, "role", "list");
    },
    m(r, o) {
      De(r, e, o);
      for (let s = 0; s < i.length; s += 1)
        i[s] && i[s].m(e, null);
      t = !0;
    },
    p(r, o) {
      if (o & /*examples, handle_example_select, undefined*/
      9) {
        n = Oi(
          /*examples*/
          r[0]
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const u = Pu(r, n, s);
          i[s] ? (i[s].p(u, o), W(i[s], 1)) : (i[s] = Ku(u), i[s].c(), W(i[s], 1), i[s].m(e, null));
        }
        for (yn(), s = n.length; s < i.length; s += 1)
          a(s);
        Dn();
      }
    },
    i(r) {
      if (!t) {
        for (let o = 0; o < n.length; o += 1)
          W(i[o]);
        t = !0;
      }
    },
    o(r) {
      i = i.filter(Boolean);
      for (let o = 0; o < i.length; o += 1)
        oe(i[o]);
      t = !1;
    },
    d(r) {
      r && O(e), Bc(i, r);
    }
  };
}
function Hg(l) {
  let e, t, n, i, a, r, o;
  const s = [
    Wg,
    Zg,
    Gg,
    Ug,
    jg
  ], u = [];
  function c(f, _) {
    var d, h, p;
    return _ & /*examples*/
    1 && (e = null), _ & /*examples*/
    1 && (t = null), _ & /*examples*/
    1 && (n = null), /*example*/
    f[6].files.length > 1 ? 0 : (e == null && (e = !!/*example*/
    ((d = f[6].files[0].mime_type) != null && d.includes("image"))), e ? 1 : (t == null && (t = !!/*example*/
    ((h = f[6].files[0].mime_type) != null && h.includes("video"))), t ? 2 : (n == null && (n = !!/*example*/
    ((p = f[6].files[0].mime_type) != null && p.includes("audio"))), n ? 3 : 4)));
  }
  return i = c(l, -1), a = u[i] = s[i](l), {
    c() {
      a.c(), r = Ni();
    },
    l(f) {
      a.l(f), r = Ni();
    },
    m(f, _) {
      u[i].m(f, _), De(f, r, _), o = !0;
    },
    p(f, _) {
      let d = i;
      i = c(f, _), i === d ? u[i].p(f, _) : (yn(), oe(u[d], 1, 1, () => {
        u[d] = null;
      }), Dn(), a = u[i], a ? a.p(f, _) : (a = u[i] = s[i](f), a.c()), W(a, 1), a.m(r.parentNode, r));
    },
    i(f) {
      o || (W(a), o = !0);
    },
    o(f) {
      oe(a), o = !1;
    },
    d(f) {
      f && O(r), u[i].d(f);
    }
  };
}
function Pg(l) {
  let e, t = '<span class="text-icon-aa svelte-9nrvad">Aa</span>';
  return {
    c() {
      e = se("div"), e.innerHTML = t, this.h();
    },
    l(n) {
      e = re(n, "DIV", {
        class: !0,
        "aria-hidden": !0,
        "data-svelte-h": !0
      }), zg(e) !== "svelte-15cq9iz" && (e.innerHTML = t), this.h();
    },
    h() {
      M(e, "class", "example-icon svelte-9nrvad"), M(e, "aria-hidden", "true");
    },
    m(n, i) {
      De(n, e, i);
    },
    p: Xn,
    i: Xn,
    o: Xn,
    d(n) {
      n && O(e);
    }
  };
}
function Vg(l) {
  let e, t, n;
  return t = new Hl({
    props: {
      class: "example-image",
      src: (
        /*example*/
        l[6].icon.url
      ),
      alt: "Example icon"
    }
  }), {
    c() {
      e = se("div"), Cn(t.$$.fragment), this.h();
    },
    l(i) {
      e = re(i, "DIV", { class: !0 });
      var a = de(e);
      En(t.$$.fragment, a), a.forEach(O), this.h();
    },
    h() {
      M(e, "class", "example-image-container svelte-9nrvad");
    },
    m(i, a) {
      De(i, e, a), $n(t, e, null), n = !0;
    },
    p(i, a) {
      const r = {};
      a & /*examples*/
      1 && (r.src = /*example*/
      i[6].icon.url), t.$set(r);
    },
    i(i) {
      n || (W(t.$$.fragment, i), n = !0);
    },
    o(i) {
      oe(t.$$.fragment, i), n = !1;
    },
    d(i) {
      i && O(e), An(t);
    }
  };
}
function jg(l) {
  let e, t, n, i;
  return t = new Jo({}), {
    c() {
      e = se("div"), Cn(t.$$.fragment), this.h();
    },
    l(a) {
      e = re(a, "DIV", { class: !0, "aria-label": !0 });
      var r = de(e);
      En(t.$$.fragment, r), r.forEach(O), this.h();
    },
    h() {
      M(e, "class", "example-icon svelte-9nrvad"), M(e, "aria-label", n = `File: ${/*example*/
      l[6].files[0].orig_name}`);
    },
    m(a, r) {
      De(a, e, r), $n(t, e, null), i = !0;
    },
    p(a, r) {
      (!i || r & /*examples*/
      1 && n !== (n = `File: ${/*example*/
      a[6].files[0].orig_name}`)) && M(e, "aria-label", n);
    },
    i(a) {
      i || (W(t.$$.fragment, a), i = !0);
    },
    o(a) {
      oe(t.$$.fragment, a), i = !1;
    },
    d(a) {
      a && O(e), An(t);
    }
  };
}
function Ug(l) {
  let e, t, n, i;
  return t = new mc({}), {
    c() {
      e = se("div"), Cn(t.$$.fragment), this.h();
    },
    l(a) {
      e = re(a, "DIV", { class: !0, "aria-label": !0 });
      var r = de(e);
      En(t.$$.fragment, r), r.forEach(O), this.h();
    },
    h() {
      M(e, "class", "example-icon svelte-9nrvad"), M(e, "aria-label", n = `File: ${/*example*/
      l[6].files[0].orig_name}`);
    },
    m(a, r) {
      De(a, e, r), $n(t, e, null), i = !0;
    },
    p(a, r) {
      (!i || r & /*examples*/
      1 && n !== (n = `File: ${/*example*/
      a[6].files[0].orig_name}`)) && M(e, "aria-label", n);
    },
    i(a) {
      i || (W(t.$$.fragment, a), i = !0);
    },
    o(a) {
      oe(t.$$.fragment, a), i = !1;
    },
    d(a) {
      a && O(e), An(t);
    }
  };
}
function Gg(l) {
  let e, t, n;
  return {
    c() {
      e = se("div"), t = se("video"), this.h();
    },
    l(i) {
      e = re(i, "DIV", { class: !0 });
      var a = de(e);
      t = re(a, "VIDEO", {
        class: !0,
        src: !0,
        "aria-hidden": !0
      }), de(t).forEach(O), a.forEach(O), this.h();
    },
    h() {
      M(t, "class", "example-image"), Hi(t.src, n = /*example*/
      l[6].files[0].url) || M(t, "src", n), M(t, "aria-hidden", "true"), M(e, "class", "example-image-container svelte-9nrvad");
    },
    m(i, a) {
      De(i, e, a), ke(e, t);
    },
    p(i, a) {
      a & /*examples*/
      1 && !Hi(t.src, n = /*example*/
      i[6].files[0].url) && M(t, "src", n);
    },
    i: Xn,
    o: Xn,
    d(i) {
      i && O(e);
    }
  };
}
function Zg(l) {
  let e, t, n;
  return t = new Hl({
    props: {
      class: "example-image",
      src: (
        /*example*/
        l[6].files[0].url
      ),
      alt: (
        /*example*/
        l[6].files[0].orig_name || "Example image"
      )
    }
  }), {
    c() {
      e = se("div"), Cn(t.$$.fragment), this.h();
    },
    l(i) {
      e = re(i, "DIV", { class: !0 });
      var a = de(e);
      En(t.$$.fragment, a), a.forEach(O), this.h();
    },
    h() {
      M(e, "class", "example-image-container svelte-9nrvad");
    },
    m(i, a) {
      De(i, e, a), $n(t, e, null), n = !0;
    },
    p(i, a) {
      const r = {};
      a & /*examples*/
      1 && (r.src = /*example*/
      i[6].files[0].url), a & /*examples*/
      1 && (r.alt = /*example*/
      i[6].files[0].orig_name || "Example image"), t.$set(r);
    },
    i(i) {
      n || (W(t.$$.fragment, i), n = !0);
    },
    o(i) {
      oe(t.$$.fragment, i), n = !1;
    },
    d(i) {
      i && O(e), An(t);
    }
  };
}
function Wg(l) {
  let e, t, n, i = Oi(
    /*example*/
    l[6].files.slice(0, 4)
  ), a = [];
  for (let s = 0; s < i.length; s += 1)
    a[s] = Wu(Vu(l, i, s));
  const r = (s) => oe(a[s], 1, 1, () => {
    a[s] = null;
  });
  let o = (
    /*example*/
    l[6].files.length > 4 && Xu(l)
  );
  return {
    c() {
      e = se("div");
      for (let s = 0; s < a.length; s += 1)
        a[s].c();
      t = vl(), o && o.c(), this.h();
    },
    l(s) {
      e = re(s, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0
      });
      var u = de(e);
      for (let c = 0; c < a.length; c += 1)
        a[c].l(u);
      t = bl(u), o && o.l(u), u.forEach(O), this.h();
    },
    h() {
      M(e, "class", "example-icons-grid svelte-9nrvad"), M(e, "role", "group"), M(e, "aria-label", "Example attachments");
    },
    m(s, u) {
      De(s, e, u);
      for (let c = 0; c < a.length; c += 1)
        a[c] && a[c].m(e, null);
      ke(e, t), o && o.m(e, null), n = !0;
    },
    p(s, u) {
      if (u & /*examples*/
      1) {
        i = Oi(
          /*example*/
          s[6].files.slice(0, 4)
        );
        let c;
        for (c = 0; c < i.length; c += 1) {
          const f = Vu(s, i, c);
          a[c] ? (a[c].p(f, u), W(a[c], 1)) : (a[c] = Wu(f), a[c].c(), W(a[c], 1), a[c].m(e, t));
        }
        for (yn(), c = i.length; c < a.length; c += 1)
          r(c);
        Dn();
      }
      /*example*/
      s[6].files.length > 4 ? o ? o.p(s, u) : (o = Xu(s), o.c(), o.m(e, null)) : o && (o.d(1), o = null);
    },
    i(s) {
      if (!n) {
        for (let u = 0; u < i.length; u += 1)
          W(a[u]);
        n = !0;
      }
    },
    o(s) {
      a = a.filter(Boolean);
      for (let u = 0; u < a.length; u += 1)
        oe(a[u]);
      n = !1;
    },
    d(s) {
      s && O(e), Bc(a, s), o && o.d();
    }
  };
}
function Xg(l) {
  let e, t, n, i, a, r;
  const o = [Jg, Qg], s = [];
  function u(c, f) {
    var _;
    return f & /*examples*/
    1 && (t = null), t == null && (t = !!/*file*/
    ((_ = c[9].mime_type) != null && _.includes("audio"))), t ? 0 : 1;
  }
  return n = u(l, -1), i = s[n] = o[n](l), {
    c() {
      e = se("div"), i.c(), this.h();
    },
    l(c) {
      e = re(c, "DIV", { class: !0, "aria-label": !0 });
      var f = de(e);
      i.l(f), f.forEach(O), this.h();
    },
    h() {
      M(e, "class", "example-icon svelte-9nrvad"), M(e, "aria-label", a = `File: ${/*file*/
      l[9].orig_name}`);
    },
    m(c, f) {
      De(c, e, f), s[n].m(e, null), r = !0;
    },
    p(c, f) {
      let _ = n;
      n = u(c, f), n !== _ && (yn(), oe(s[_], 1, 1, () => {
        s[_] = null;
      }), Dn(), i = s[n], i || (i = s[n] = o[n](c), i.c()), W(i, 1), i.m(e, null)), (!r || f & /*examples*/
      1 && a !== (a = `File: ${/*file*/
      c[9].orig_name}`)) && M(e, "aria-label", a);
    },
    i(c) {
      r || (W(i), r = !0);
    },
    o(c) {
      oe(i), r = !1;
    },
    d(c) {
      c && O(e), s[n].d();
    }
  };
}
function Kg(l) {
  let e, t, n, i, a = (
    /*i*/
    l[8] === 3 && /*example*/
    l[6].files.length > 4 && Gu(l)
  );
  return {
    c() {
      e = se("div"), t = se("video"), i = vl(), a && a.c(), this.h();
    },
    l(r) {
      e = re(r, "DIV", { class: !0 });
      var o = de(e);
      t = re(o, "VIDEO", {
        class: !0,
        src: !0,
        "aria-hidden": !0
      }), de(t).forEach(O), i = bl(o), a && a.l(o), o.forEach(O), this.h();
    },
    h() {
      M(t, "class", "example-image"), Hi(t.src, n = /*file*/
      l[9].url) || M(t, "src", n), M(t, "aria-hidden", "true"), M(e, "class", "example-image-container svelte-9nrvad");
    },
    m(r, o) {
      De(r, e, o), ke(e, t), ke(e, i), a && a.m(e, null);
    },
    p(r, o) {
      o & /*examples*/
      1 && !Hi(t.src, n = /*file*/
      r[9].url) && M(t, "src", n), /*i*/
      r[8] === 3 && /*example*/
      r[6].files.length > 4 ? a ? a.p(r, o) : (a = Gu(r), a.c(), a.m(e, null)) : a && (a.d(1), a = null);
    },
    i: Xn,
    o: Xn,
    d(r) {
      r && O(e), a && a.d();
    }
  };
}
function Yg(l) {
  let e, t, n, i;
  t = new Hl({
    props: {
      class: "example-image",
      src: (
        /*file*/
        l[9].url
      ),
      alt: (
        /*file*/
        l[9].orig_name || `Example image ${/*i*/
        l[8] + 1}`
      )
    }
  });
  let a = (
    /*i*/
    l[8] === 3 && /*example*/
    l[6].files.length > 4 && Zu(l)
  );
  return {
    c() {
      e = se("div"), Cn(t.$$.fragment), n = vl(), a && a.c(), this.h();
    },
    l(r) {
      e = re(r, "DIV", { class: !0 });
      var o = de(e);
      En(t.$$.fragment, o), n = bl(o), a && a.l(o), o.forEach(O), this.h();
    },
    h() {
      M(e, "class", "example-image-container svelte-9nrvad");
    },
    m(r, o) {
      De(r, e, o), $n(t, e, null), ke(e, n), a && a.m(e, null), i = !0;
    },
    p(r, o) {
      const s = {};
      o & /*examples*/
      1 && (s.src = /*file*/
      r[9].url), o & /*examples*/
      1 && (s.alt = /*file*/
      r[9].orig_name || `Example image ${/*i*/
      r[8] + 1}`), t.$set(s), /*i*/
      r[8] === 3 && /*example*/
      r[6].files.length > 4 ? a ? a.p(r, o) : (a = Zu(r), a.c(), a.m(e, null)) : a && (a.d(1), a = null);
    },
    i(r) {
      i || (W(t.$$.fragment, r), i = !0);
    },
    o(r) {
      oe(t.$$.fragment, r), i = !1;
    },
    d(r) {
      r && O(e), An(t), a && a.d();
    }
  };
}
function Qg(l) {
  let e, t;
  return e = new Jo({}), {
    c() {
      Cn(e.$$.fragment);
    },
    l(n) {
      En(e.$$.fragment, n);
    },
    m(n, i) {
      $n(e, n, i), t = !0;
    },
    i(n) {
      t || (W(e.$$.fragment, n), t = !0);
    },
    o(n) {
      oe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      An(e, n);
    }
  };
}
function Jg(l) {
  let e, t;
  return e = new mc({}), {
    c() {
      Cn(e.$$.fragment);
    },
    l(n) {
      En(e.$$.fragment, n);
    },
    m(n, i) {
      $n(e, n, i), t = !0;
    },
    i(n) {
      t || (W(e.$$.fragment, n), t = !0);
    },
    o(n) {
      oe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      An(e, n);
    }
  };
}
function Gu(l) {
  let e, t, n = (
    /*example*/
    l[6].files.length - 4 + ""
  ), i, a;
  return {
    c() {
      e = se("div"), t = Qn("+"), i = Qn(n), this.h();
    },
    l(r) {
      e = re(r, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0
      });
      var o = de(e);
      t = Yn(o, "+"), i = Yn(o, n), o.forEach(O), this.h();
    },
    h() {
      M(e, "class", "image-overlay svelte-9nrvad"), M(e, "role", "status"), M(e, "aria-label", a = `${/*example*/
      l[6].files.length - 4} more files`);
    },
    m(r, o) {
      De(r, e, o), ke(e, t), ke(e, i);
    },
    p(r, o) {
      o & /*examples*/
      1 && n !== (n = /*example*/
      r[6].files.length - 4 + "") && Xi(i, n), o & /*examples*/
      1 && a !== (a = `${/*example*/
      r[6].files.length - 4} more files`) && M(e, "aria-label", a);
    },
    d(r) {
      r && O(e);
    }
  };
}
function Zu(l) {
  let e, t, n = (
    /*example*/
    l[6].files.length - 4 + ""
  ), i, a;
  return {
    c() {
      e = se("div"), t = Qn("+"), i = Qn(n), this.h();
    },
    l(r) {
      e = re(r, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0
      });
      var o = de(e);
      t = Yn(o, "+"), i = Yn(o, n), o.forEach(O), this.h();
    },
    h() {
      M(e, "class", "image-overlay svelte-9nrvad"), M(e, "role", "status"), M(e, "aria-label", a = `${/*example*/
      l[6].files.length - 4} more files`);
    },
    m(r, o) {
      De(r, e, o), ke(e, t), ke(e, i);
    },
    p(r, o) {
      o & /*examples*/
      1 && n !== (n = /*example*/
      r[6].files.length - 4 + "") && Xi(i, n), o & /*examples*/
      1 && a !== (a = `${/*example*/
      r[6].files.length - 4} more files`) && M(e, "aria-label", a);
    },
    d(r) {
      r && O(e);
    }
  };
}
function Wu(l) {
  let e, t, n, i, a, r;
  const o = [Yg, Kg, Xg], s = [];
  function u(c, f) {
    var _, d;
    return f & /*examples*/
    1 && (e = null), f & /*examples*/
    1 && (t = null), e == null && (e = !!/*file*/
    ((_ = c[9].mime_type) != null && _.includes("image"))), e ? 0 : (t == null && (t = !!/*file*/
    ((d = c[9].mime_type) != null && d.includes("video"))), t ? 1 : 2);
  }
  return n = u(l, -1), i = s[n] = o[n](l), {
    c() {
      i.c(), a = Ni();
    },
    l(c) {
      i.l(c), a = Ni();
    },
    m(c, f) {
      s[n].m(c, f), De(c, a, f), r = !0;
    },
    p(c, f) {
      let _ = n;
      n = u(c, f), n === _ ? s[n].p(c, f) : (yn(), oe(s[_], 1, 1, () => {
        s[_] = null;
      }), Dn(), i = s[n], i ? i.p(c, f) : (i = s[n] = o[n](c), i.c()), W(i, 1), i.m(a.parentNode, a));
    },
    i(c) {
      r || (W(i), r = !0);
    },
    o(c) {
      oe(i), r = !1;
    },
    d(c) {
      c && O(a), s[n].d(c);
    }
  };
}
function Xu(l) {
  let e, t, n, i = (
    /*example*/
    l[6].files.length - 4 + ""
  ), a, r;
  return {
    c() {
      e = se("div"), t = se("div"), n = Qn("+"), a = Qn(i), this.h();
    },
    l(o) {
      e = re(o, "DIV", { class: !0 });
      var s = de(e);
      t = re(s, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0
      });
      var u = de(t);
      n = Yn(u, "+"), a = Yn(u, i), u.forEach(O), s.forEach(O), this.h();
    },
    h() {
      M(t, "class", "file-overlay svelte-9nrvad"), M(t, "role", "status"), M(t, "aria-label", r = `${/*example*/
      l[6].files.length - 4} more files`), M(e, "class", "example-icon svelte-9nrvad");
    },
    m(o, s) {
      De(o, e, s), ke(e, t), ke(t, n), ke(t, a);
    },
    p(o, s) {
      s & /*examples*/
      1 && i !== (i = /*example*/
      o[6].files.length - 4 + "") && Xi(a, i), s & /*examples*/
      1 && r !== (r = `${/*example*/
      o[6].files.length - 4} more files`) && M(t, "aria-label", r);
    },
    d(o) {
      o && O(e);
    }
  };
}
function Ku(l) {
  let e, t, n, i, a, r, o, s = (
    /*example*/
    (l[6].display_text || /*example*/
    l[6].text) + ""
  ), u, c, f, _, d, h;
  const p = [Vg, Pg, Hg], v = [];
  function D(m, g) {
    var k, b, y, C;
    return (
      /*example*/
      (b = (k = m[6]) == null ? void 0 : k.icon) != null && b.url ? 0 : (
        /*example*/
        ((C = (y = m[6]) == null ? void 0 : y.icon) == null ? void 0 : C.mime_type) === "text" ? 1 : (
          /*example*/
          m[6].files !== void 0 && /*example*/
          m[6].files.length > 0 ? 2 : -1
        )
      )
    );
  }
  ~(n = D(l)) && (i = v[n] = p[n](l));
  function w() {
    return (
      /*click_handler*/
      l[4](
        /*i*/
        l[8],
        /*example*/
        l[6]
      )
    );
  }
  return {
    c() {
      e = se("button"), t = se("div"), i && i.c(), a = vl(), r = se("div"), o = se("span"), u = Qn(s), c = vl(), this.h();
    },
    l(m) {
      e = re(m, "BUTTON", { class: !0, "aria-label": !0 });
      var g = de(e);
      t = re(g, "DIV", { class: !0 });
      var k = de(t);
      i && i.l(k), a = bl(k), r = re(k, "DIV", { class: !0 });
      var b = de(r);
      o = re(b, "SPAN", { class: !0 });
      var y = de(o);
      u = Yn(y, s), y.forEach(O), b.forEach(O), k.forEach(O), c = bl(g), g.forEach(O), this.h();
    },
    h() {
      M(o, "class", "example-text svelte-9nrvad"), M(r, "class", "example-text-content svelte-9nrvad"), M(t, "class", "example-content svelte-9nrvad"), M(e, "class", "example svelte-9nrvad"), M(e, "aria-label", f = `Select example ${/*i*/
      l[8] + 1}: ${/*example*/
      l[6].display_text || /*example*/
      l[6].text}`);
    },
    m(m, g) {
      De(m, e, g), ke(e, t), ~n && v[n].m(t, null), ke(t, a), ke(t, r), ke(r, o), ke(o, u), ke(e, c), _ = !0, d || (h = Rg(e, "click", w), d = !0);
    },
    p(m, g) {
      l = m;
      let k = n;
      n = D(l), n === k ? ~n && v[n].p(l, g) : (i && (yn(), oe(v[k], 1, 1, () => {
        v[k] = null;
      }), Dn()), ~n ? (i = v[n], i ? i.p(l, g) : (i = v[n] = p[n](l), i.c()), W(i, 1), i.m(t, a)) : i = null), (!_ || g & /*examples*/
      1) && s !== (s = /*example*/
      (l[6].display_text || /*example*/
      l[6].text) + "") && Xi(u, s), (!_ || g & /*examples*/
      1 && f !== (f = `Select example ${/*i*/
      l[8] + 1}: ${/*example*/
      l[6].display_text || /*example*/
      l[6].text}`)) && M(e, "aria-label", f);
    },
    i(m) {
      _ || (W(i), _ = !0);
    },
    o(m) {
      oe(i), _ = !1;
    },
    d(m) {
      m && O(e), ~n && v[n].d(), d = !1, h();
    }
  };
}
function xg(l) {
  let e, t, n, i = (
    /*placeholder*/
    l[1] !== null && ju(l)
  ), a = (
    /*examples*/
    l[0] !== null && Uu(l)
  );
  return {
    c() {
      e = se("div"), i && i.c(), t = vl(), a && a.c(), this.h();
    },
    l(r) {
      e = re(r, "DIV", { class: !0, role: !0 });
      var o = de(e);
      i && i.l(o), t = bl(o), a && a.l(o), o.forEach(O), this.h();
    },
    h() {
      M(e, "class", "placeholder-content svelte-9nrvad"), M(e, "role", "complementary");
    },
    m(r, o) {
      De(r, e, o), i && i.m(e, null), ke(e, t), a && a.m(e, null), n = !0;
    },
    p(r, [o]) {
      /*placeholder*/
      r[1] !== null ? i ? (i.p(r, o), o & /*placeholder*/
      2 && W(i, 1)) : (i = ju(r), i.c(), W(i, 1), i.m(e, t)) : i && (yn(), oe(i, 1, 1, () => {
        i = null;
      }), Dn()), /*examples*/
      r[0] !== null ? a ? (a.p(r, o), o & /*examples*/
      1 && W(a, 1)) : (a = Uu(r), a.c(), W(a, 1), a.m(e, null)) : a && (yn(), oe(a, 1, 1, () => {
        a = null;
      }), Dn());
    },
    i(r) {
      n || (W(i), W(a), n = !0);
    },
    o(r) {
      oe(i), oe(a), n = !1;
    },
    d(r) {
      r && O(e), i && i.d(), a && a.d();
    }
  };
}
function eb(l, e, t) {
  let { examples: n = null } = e, { placeholder: i = null } = e, { latex_delimiters: a } = e;
  const r = Og();
  function o(u, c) {
    const f = typeof c == "string" ? { text: c } : c;
    r("example_select", {
      index: u,
      value: {
        text: f.text,
        files: f.files
      }
    });
  }
  const s = (u, c) => o(u, typeof c == "string" ? { text: c } : c);
  return l.$$set = (u) => {
    "examples" in u && t(0, n = u.examples), "placeholder" in u && t(1, i = u.placeholder), "latex_delimiters" in u && t(2, a = u.latex_delimiters);
  }, [n, i, a, o, s];
}
class tb extends Lg {
  constructor(e) {
    super(), Mg(this, e, eb, xg, Ng, {
      examples: 0,
      placeholder: 1,
      latex_delimiters: 2
    });
  }
}
const {
  SvelteComponent: nb,
  claim_component: lb,
  create_component: ib,
  destroy_component: ab,
  init: ob,
  mount_component: rb,
  safe_not_equal: sb,
  transition_in: ub,
  transition_out: _b
} = window.__gradio__svelte__internal, { onDestroy: cb } = window.__gradio__svelte__internal;
function fb(l) {
  let e, t;
  return e = new Re({
    props: {
      Icon: (
        /*copied*/
        l[0] ? Rl : Si
      ),
      label: (
        /*copied*/
        l[0] ? "Copied conversation" : "Copy conversation"
      )
    }
  }), e.$on(
    "click",
    /*handle_copy*/
    l[1]
  ), {
    c() {
      ib(e.$$.fragment);
    },
    l(n) {
      lb(e.$$.fragment, n);
    },
    m(n, i) {
      rb(e, n, i), t = !0;
    },
    p(n, [i]) {
      const a = {};
      i & /*copied*/
      1 && (a.Icon = /*copied*/
      n[0] ? Rl : Si), i & /*copied*/
      1 && (a.label = /*copied*/
      n[0] ? "Copied conversation" : "Copy conversation"), e.$set(a);
    },
    i(n) {
      t || (ub(e.$$.fragment, n), t = !0);
    },
    o(n) {
      _b(e.$$.fragment, n), t = !1;
    },
    d(n) {
      ab(e, n);
    }
  };
}
function db(l, e, t) {
  var n = this && this.__awaiter || function(f, _, d, h) {
    function p(v) {
      return v instanceof d ? v : new d(function(D) {
        D(v);
      });
    }
    return new (d || (d = Promise))(function(v, D) {
      function w(k) {
        try {
          g(h.next(k));
        } catch (b) {
          D(b);
        }
      }
      function m(k) {
        try {
          g(h.throw(k));
        } catch (b) {
          D(b);
        }
      }
      function g(k) {
        k.done ? v(k.value) : p(k.value).then(w, m);
      }
      g((h = h.apply(f, _ || [])).next());
    });
  };
  let i = !1, { value: a } = e, { watermark: r = null } = e, o;
  function s() {
    t(0, i = !0), o && clearTimeout(o), o = setTimeout(
      () => {
        t(0, i = !1);
      },
      1e3
    );
  }
  const u = () => {
    if (a) {
      const f = a.map((d) => d.type === "text" ? `${d.role}: ${d.content}` : `${d.role}: ${d.content.value.url}`).join(`

`), _ = r ? `${f}

${r}` : f;
      navigator.clipboard.writeText(_).catch((d) => {
        console.error("Failed to copy conversation: ", d);
      });
    }
  };
  function c() {
    return n(this, void 0, void 0, function* () {
      "clipboard" in navigator && (u(), s());
    });
  }
  return cb(() => {
    o && clearTimeout(o);
  }), l.$$set = (f) => {
    "value" in f && t(2, a = f.value), "watermark" in f && t(3, r = f.watermark);
  }, [i, c, a, r];
}
class hb extends nb {
  constructor(e) {
    super(), ob(this, e, db, fb, sb, { value: 2, watermark: 3 });
  }
}
const {
  SvelteComponent: mb,
  action_destroyer: pb,
  add_flush_callback: gb,
  append_hydration: Ho,
  attr: Wt,
  bind: bb,
  binding_callbacks: qc,
  check_outros: pn,
  children: Wl,
  claim_component: en,
  claim_element: Xl,
  claim_space: Jn,
  claim_text: vb,
  create_component: tn,
  destroy_component: nn,
  destroy_each: Tc,
  detach: Fe,
  element: Kl,
  empty: wl,
  ensure_array_like: Pi,
  group_outros: gn,
  init: wb,
  insert_hydration: ot,
  listen: kb,
  mount_component: ln,
  noop: Vi,
  null_to_empty: Yu,
  safe_not_equal: Db,
  set_data: yb,
  space: xn,
  text: Fb,
  transition_in: j,
  transition_out: ne
} = window.__gradio__svelte__internal, { createEventDispatcher: Eb, tick: Cb, onMount: mo } = window.__gradio__svelte__internal;
function Qu(l, e, t) {
  const n = l.slice();
  return n[62] = e[t], n[64] = t, n;
}
function Ju(l, e, t) {
  const n = l.slice();
  n[65] = e[t], n[73] = t;
  const i = (
    /*messages*/
    n[65][0].name
  );
  n[66] = i;
  const a = (
    /*messages*/
    n[65][0].role === "user" ? "user" : "bot"
  );
  n[67] = a;
  const r = (
    /*avatar_images*/
    n[16][I_.indexOf(
      /*messages*/
      n[65][0].name
    )]
  );
  n[68] = r;
  const o = (
    /*avatar_images*/
    n[16][
      /*role*/
      n[67] === "user" ? 0 : 1
    ]
  );
  n[69] = o;
  const s = (
    /*groupedMessages*/
    n[39].slice(
      0,
      /*i*/
      n[73]
    ).filter((c) => c[0].role === "assistant").length
  );
  n[70] = s;
  const u = (
    /*role*/
    n[67] === "bot" && /*feedback_value*/
    n[10] && /*feedback_value*/
    n[10][
      /*feedback_index*/
      n[70]
    ] ? (
      /*feedback_value*/
      n[10][
        /*feedback_index*/
        n[70]
      ]
    ) : null
  );
  return n[71] = u, n;
}
function xu(l) {
  let e, t;
  return e = new pc({
    props: {
      $$slots: { default: [Ab] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      tn(e.$$.fragment);
    },
    l(n) {
      en(e.$$.fragment, n);
    },
    m(n, i) {
      ln(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*value, show_copy_all_button, i18n, show_share_button*/
      2109441 | i[1] & /*watermark*/
      1 | i[2] & /*$$scope*/
      4096 && (a.$$scope = { dirty: i, ctx: n }), e.$set(a);
    },
    i(n) {
      t || (j(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ne(e.$$.fragment, n), t = !1;
    },
    d(n) {
      nn(e, n);
    }
  };
}
function e_(l) {
  let e, t;
  return e = new Re({ props: { Icon: Tm } }), e.$on(
    "click",
    /*click_handler*/
    l[48]
  ), {
    c() {
      tn(e.$$.fragment);
    },
    l(n) {
      en(e.$$.fragment, n);
    },
    m(n, i) {
      ln(e, n, i), t = !0;
    },
    p: Vi,
    i(n) {
      t || (j(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ne(e.$$.fragment, n), t = !1;
    },
    d(n) {
      nn(e, n);
    }
  };
}
function t_(l) {
  let e, t;
  return e = new hb({
    props: {
      value: (
        /*value*/
        l[0]
      ),
      watermark: (
        /*watermark*/
        l[31]
      )
    }
  }), {
    c() {
      tn(e.$$.fragment);
    },
    l(n) {
      en(e.$$.fragment, n);
    },
    m(n, i) {
      ln(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*value*/
      1 && (a.value = /*value*/
      n[0]), i[1] & /*watermark*/
      1 && (a.watermark = /*watermark*/
      n[31]), e.$set(a);
    },
    i(n) {
      t || (j(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ne(e.$$.fragment, n), t = !1;
    },
    d(n) {
      nn(e, n);
    }
  };
}
function Ab(l) {
  let e, t, n, i, a, r = (
    /*show_share_button*/
    l[12] && e_(l)
  );
  t = new Re({
    props: {
      Icon: h1,
      label: (
        /*i18n*/
        l[21]("chatbot.clear")
      )
    }
  }), t.$on(
    "click",
    /*click_handler_1*/
    l[49]
  );
  let o = (
    /*show_copy_all_button*/
    l[13] && t_(l)
  );
  return {
    c() {
      r && r.c(), e = xn(), tn(t.$$.fragment), n = xn(), o && o.c(), i = wl();
    },
    l(s) {
      r && r.l(s), e = Jn(s), en(t.$$.fragment, s), n = Jn(s), o && o.l(s), i = wl();
    },
    m(s, u) {
      r && r.m(s, u), ot(s, e, u), ln(t, s, u), ot(s, n, u), o && o.m(s, u), ot(s, i, u), a = !0;
    },
    p(s, u) {
      /*show_share_button*/
      s[12] ? r ? (r.p(s, u), u[0] & /*show_share_button*/
      4096 && j(r, 1)) : (r = e_(s), r.c(), j(r, 1), r.m(e.parentNode, e)) : r && (gn(), ne(r, 1, 1, () => {
        r = null;
      }), pn());
      const c = {};
      u[0] & /*i18n*/
      2097152 && (c.label = /*i18n*/
      s[21]("chatbot.clear")), t.$set(c), /*show_copy_all_button*/
      s[13] ? o ? (o.p(s, u), u[0] & /*show_copy_all_button*/
      8192 && j(o, 1)) : (o = t_(s), o.c(), j(o, 1), o.m(i.parentNode, i)) : o && (gn(), ne(o, 1, 1, () => {
        o = null;
      }), pn());
    },
    i(s) {
      a || (j(r), j(t.$$.fragment, s), j(o), a = !0);
    },
    o(s) {
      ne(r), ne(t.$$.fragment, s), ne(o), a = !1;
    },
    d(s) {
      s && (Fe(e), Fe(n), Fe(i)), r && r.d(s), nn(t, s), o && o.d(s);
    }
  };
}
function $b(l) {
  let e, t;
  return e = new tb({
    props: {
      examples: (
        /*examples*/
        l[26]
      ),
      placeholder: (
        /*placeholder*/
        l[23]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        l[4]
      )
    }
  }), e.$on(
    "example_select",
    /*example_select_handler*/
    l[54]
  ), {
    c() {
      tn(e.$$.fragment);
    },
    l(n) {
      en(e.$$.fragment, n);
    },
    m(n, i) {
      ln(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*examples*/
      67108864 && (a.examples = /*examples*/
      n[26]), i[0] & /*placeholder*/
      8388608 && (a.placeholder = /*placeholder*/
      n[23]), i[0] & /*latex_delimiters*/
      16 && (a.latex_delimiters = /*latex_delimiters*/
      n[4]), e.$set(a);
    },
    i(n) {
      t || (j(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ne(e.$$.fragment, n), t = !1;
    },
    d(n) {
      nn(e, n);
    }
  };
}
function Sb(l) {
  let e, t, n, i, a, r, o, s = Pi(
    /*groupedMessages*/
    l[39]
  ), u = [];
  for (let h = 0; h < s.length; h += 1)
    u[h] = l_(Ju(l, s, h));
  const c = (h) => ne(u[h], 1, 1, () => {
    u[h] = null;
  }), f = [qb, Bb], _ = [];
  function d(h, p) {
    return (
      /*show_progress*/
      h[32] !== "hidden" && /*pending_message*/
      h[5] ? 0 : (
        /*options*/
        h[40] ? 1 : -1
      )
    );
  }
  return ~(n = d(l)) && (i = _[n] = f[n](l)), {
    c() {
      e = Kl("div");
      for (let h = 0; h < u.length; h += 1)
        u[h].c();
      t = xn(), i && i.c(), this.h();
    },
    l(h) {
      e = Xl(h, "DIV", { class: !0 });
      var p = Wl(e);
      for (let v = 0; v < u.length; v += 1)
        u[v].l(p);
      t = Jn(p), i && i.l(p), p.forEach(Fe), this.h();
    },
    h() {
      Wt(e, "class", "message-wrap svelte-6d3nkq");
    },
    m(h, p) {
      ot(h, e, p);
      for (let v = 0; v < u.length; v += 1)
        u[v] && u[v].m(e, null);
      Ho(e, t), ~n && _[n].m(e, null), a = !0, r || (o = pb(Zc.call(null, e)), r = !0);
    },
    p(h, p) {
      if (p[0] & /*layout, avatar_images, generating, display_consecutive_in_same_bubble, i18n, _fetch, line_breaks, theme_mode, upload, selectable, sanitize_html, render_markdown, rtl, value, latex_delimiters, msg_format, feedback_options, feedback_value, allow_tags, likeable, like_user_message, _retryable, _undoable, editable, show_copy_button, allow_file_downloads*/
      2071973855 | p[1] & /*show_progress, groupedMessages, dispatch, target, _components, watermark, edit_index, edit_messages, handle_action, is_browser*/
      11583) {
        s = Pi(
          /*groupedMessages*/
          h[39]
        );
        let D;
        for (D = 0; D < s.length; D += 1) {
          const w = Ju(h, s, D);
          u[D] ? (u[D].p(w, p), j(u[D], 1)) : (u[D] = l_(w), u[D].c(), j(u[D], 1), u[D].m(e, t));
        }
        for (gn(), D = s.length; D < u.length; D += 1)
          c(D);
        pn();
      }
      let v = n;
      n = d(h), n === v ? ~n && _[n].p(h, p) : (i && (gn(), ne(_[v], 1, 1, () => {
        _[v] = null;
      }), pn()), ~n ? (i = _[n], i ? i.p(h, p) : (i = _[n] = f[n](h), i.c()), j(i, 1), i.m(e, null)) : i = null);
    },
    i(h) {
      if (!a) {
        for (let p = 0; p < s.length; p += 1)
          j(u[p]);
        j(i), a = !0;
      }
    },
    o(h) {
      u = u.filter(Boolean);
      for (let p = 0; p < u.length; p += 1)
        ne(u[p]);
      ne(i), a = !1;
    },
    d(h) {
      h && Fe(e), Tc(u, h), ~n && _[n].d(), r = !1, o();
    }
  };
}
function n_(l) {
  let e, t;
  return e = new Sc({
    props: {
      layout: (
        /*layout*/
        l[22]
      ),
      avatar_images: (
        /*avatar_images*/
        l[16]
      )
    }
  }), {
    c() {
      tn(e.$$.fragment);
    },
    l(n) {
      en(e.$$.fragment, n);
    },
    m(n, i) {
      ln(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*layout*/
      4194304 && (a.layout = /*layout*/
      n[22]), i[0] & /*avatar_images*/
      65536 && (a.avatar_images = /*avatar_images*/
      n[16]), e.$set(a);
    },
    i(n) {
      t || (j(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ne(e.$$.fragment, n), t = !1;
    },
    d(n) {
      nn(e, n);
    }
  };
}
function l_(l) {
  var c;
  let e, t, n, i, a;
  function r(...f) {
    return (
      /*func*/
      l[50](
        /*messages*/
        l[65],
        /*i*/
        l[73],
        ...f
      )
    );
  }
  function o(f) {
    l[51](f);
  }
  let s = {
    messages: (
      /*messages*/
      l[65]
    ),
    display_consecutive_in_same_bubble: (
      /*display_consecutive_in_same_bubble*/
      l[3]
    ),
    opposite_avatar_img: (
      /*opposite_avatar_img*/
      l[69]
    ),
    avatar_img: (
      /*avatar_img*/
      l[68]
    ),
    name: (
      /*name*/
      l[66]
    ),
    role: (
      /*role*/
      l[67]
    ),
    layout: (
      /*layout*/
      l[22]
    ),
    dispatch: (
      /*dispatch*/
      l[42]
    ),
    i18n: (
      /*i18n*/
      l[21]
    ),
    _fetch: (
      /*_fetch*/
      l[1]
    ),
    line_breaks: (
      /*line_breaks*/
      l[19]
    ),
    theme_mode: (
      /*theme_mode*/
      l[20]
    ),
    target: (
      /*target*/
      l[34]
    ),
    upload: (
      /*upload*/
      l[24]
    ),
    selectable: (
      /*selectable*/
      l[7]
    ),
    sanitize_html: (
      /*sanitize_html*/
      l[17]
    ),
    render_markdown: (
      /*render_markdown*/
      l[18]
    ),
    rtl: (
      /*rtl*/
      l[14]
    ),
    i: (
      /*i*/
      l[73]
    ),
    value: (
      /*value*/
      l[0]
    ),
    latex_delimiters: (
      /*latex_delimiters*/
      l[4]
    ),
    _components: (
      /*_components*/
      l[33]
    ),
    generating: (
      /*generating*/
      l[6]
    ),
    msg_format: (
      /*msg_format*/
      l[25]
    ),
    feedback_options: (
      /*feedback_options*/
      l[9]
    ),
    current_feedback: (
      /*current_feedback*/
      l[71]
    ),
    allow_tags: (
      /*allow_tags*/
      l[30]
    ),
    watermark: (
      /*watermark*/
      l[31]
    ),
    show_like: (
      /*role*/
      l[67] === "user" ? (
        /*likeable*/
        l[8] && /*like_user_message*/
        l[29]
      ) : (
        /*likeable*/
        l[8]
      )
    ),
    show_retry: (
      /*_retryable*/
      l[27] && Ql(
        /*messages*/
        l[65],
        /*value*/
        l[0]
      )
    ),
    show_undo: (
      /*_undoable*/
      l[28] && Ql(
        /*messages*/
        l[65],
        /*value*/
        l[0]
      )
    ),
    show_edit: (
      /*editable*/
      l[11] === "llm" && /*name*/
      l[66] === "llm" && /*messages*/
      l[65].length > 0 && /*messages*/
      l[65][
        /*messages*/
        l[65].length - 1
      ].type == "text"
    ),
    in_edit_mode: (
      /*edit_index*/
      l[35] === /*i*/
      l[73]
    ),
    show_copy_button: (
      /*show_copy_button*/
      l[15]
    ),
    handle_action: r,
    scroll: (
      /*is_browser*/
      l[41] ? scroll : Ib
    ),
    allow_file_downloads: (
      /*allow_file_downloads*/
      l[2]
    )
  };
  /*edit_messages*/
  l[36] !== void 0 && (s.edit_messages = /*edit_messages*/
  l[36]), e = new vg({ props: s }), qc.push(() => bb(e, "edit_messages", o)), e.$on(
    "copy",
    /*copy_handler*/
    l[52]
  );
  let u = (
    /*show_progress*/
    l[32] !== "hidden" && /*generating*/
    l[6] && /*messages*/
    l[65][
      /*messages*/
      l[65].length - 1
    ].role === "assistant" && /*messages*/
    ((c = l[65][
      /*messages*/
      l[65].length - 1
    ].metadata) == null ? void 0 : c.status) === "done" && n_(l)
  );
  return {
    c() {
      tn(e.$$.fragment), n = xn(), u && u.c(), i = wl();
    },
    l(f) {
      en(e.$$.fragment, f), n = Jn(f), u && u.l(f), i = wl();
    },
    m(f, _) {
      ln(e, f, _), ot(f, n, _), u && u.m(f, _), ot(f, i, _), a = !0;
    },
    p(f, _) {
      var h;
      l = f;
      const d = {};
      _[1] & /*groupedMessages*/
      256 && (d.messages = /*messages*/
      l[65]), _[0] & /*display_consecutive_in_same_bubble*/
      8 && (d.display_consecutive_in_same_bubble = /*display_consecutive_in_same_bubble*/
      l[3]), _[0] & /*avatar_images*/
      65536 | _[1] & /*groupedMessages*/
      256 && (d.opposite_avatar_img = /*opposite_avatar_img*/
      l[69]), _[0] & /*avatar_images*/
      65536 | _[1] & /*groupedMessages*/
      256 && (d.avatar_img = /*avatar_img*/
      l[68]), _[1] & /*groupedMessages*/
      256 && (d.name = /*name*/
      l[66]), _[1] & /*groupedMessages*/
      256 && (d.role = /*role*/
      l[67]), _[0] & /*layout*/
      4194304 && (d.layout = /*layout*/
      l[22]), _[0] & /*i18n*/
      2097152 && (d.i18n = /*i18n*/
      l[21]), _[0] & /*_fetch*/
      2 && (d._fetch = /*_fetch*/
      l[1]), _[0] & /*line_breaks*/
      524288 && (d.line_breaks = /*line_breaks*/
      l[19]), _[0] & /*theme_mode*/
      1048576 && (d.theme_mode = /*theme_mode*/
      l[20]), _[1] & /*target*/
      8 && (d.target = /*target*/
      l[34]), _[0] & /*upload*/
      16777216 && (d.upload = /*upload*/
      l[24]), _[0] & /*selectable*/
      128 && (d.selectable = /*selectable*/
      l[7]), _[0] & /*sanitize_html*/
      131072 && (d.sanitize_html = /*sanitize_html*/
      l[17]), _[0] & /*render_markdown*/
      262144 && (d.render_markdown = /*render_markdown*/
      l[18]), _[0] & /*rtl*/
      16384 && (d.rtl = /*rtl*/
      l[14]), _[0] & /*value*/
      1 && (d.value = /*value*/
      l[0]), _[0] & /*latex_delimiters*/
      16 && (d.latex_delimiters = /*latex_delimiters*/
      l[4]), _[1] & /*_components*/
      4 && (d._components = /*_components*/
      l[33]), _[0] & /*generating*/
      64 && (d.generating = /*generating*/
      l[6]), _[0] & /*msg_format*/
      33554432 && (d.msg_format = /*msg_format*/
      l[25]), _[0] & /*feedback_options*/
      512 && (d.feedback_options = /*feedback_options*/
      l[9]), _[0] & /*feedback_value*/
      1024 | _[1] & /*groupedMessages*/
      256 && (d.current_feedback = /*current_feedback*/
      l[71]), _[0] & /*allow_tags*/
      1073741824 && (d.allow_tags = /*allow_tags*/
      l[30]), _[1] & /*watermark*/
      1 && (d.watermark = /*watermark*/
      l[31]), _[0] & /*likeable, like_user_message*/
      536871168 | _[1] & /*groupedMessages*/
      256 && (d.show_like = /*role*/
      l[67] === "user" ? (
        /*likeable*/
        l[8] && /*like_user_message*/
        l[29]
      ) : (
        /*likeable*/
        l[8]
      )), _[0] & /*_retryable, value*/
      134217729 | _[1] & /*groupedMessages*/
      256 && (d.show_retry = /*_retryable*/
      l[27] && Ql(
        /*messages*/
        l[65],
        /*value*/
        l[0]
      )), _[0] & /*_undoable, value*/
      268435457 | _[1] & /*groupedMessages*/
      256 && (d.show_undo = /*_undoable*/
      l[28] && Ql(
        /*messages*/
        l[65],
        /*value*/
        l[0]
      )), _[0] & /*editable*/
      2048 | _[1] & /*groupedMessages*/
      256 && (d.show_edit = /*editable*/
      l[11] === "llm" && /*name*/
      l[66] === "llm" && /*messages*/
      l[65].length > 0 && /*messages*/
      l[65][
        /*messages*/
        l[65].length - 1
      ].type == "text"), _[1] & /*edit_index*/
      16 && (d.in_edit_mode = /*edit_index*/
      l[35] === /*i*/
      l[73]), _[0] & /*show_copy_button*/
      32768 && (d.show_copy_button = /*show_copy_button*/
      l[15]), _[1] & /*edit_messages, groupedMessages*/
      288 && (d.handle_action = r), _[0] & /*allow_file_downloads*/
      4 && (d.allow_file_downloads = /*allow_file_downloads*/
      l[2]), !t && _[1] & /*edit_messages*/
      32 && (t = !0, d.edit_messages = /*edit_messages*/
      l[36], gb(() => t = !1)), e.$set(d), /*show_progress*/
      l[32] !== "hidden" && /*generating*/
      l[6] && /*messages*/
      l[65][
        /*messages*/
        l[65].length - 1
      ].role === "assistant" && /*messages*/
      ((h = l[65][
        /*messages*/
        l[65].length - 1
      ].metadata) == null ? void 0 : h.status) === "done" ? u ? (u.p(l, _), _[0] & /*generating*/
      64 | _[1] & /*show_progress, groupedMessages*/
      258 && j(u, 1)) : (u = n_(l), u.c(), j(u, 1), u.m(i.parentNode, i)) : u && (gn(), ne(u, 1, 1, () => {
        u = null;
      }), pn());
    },
    i(f) {
      a || (j(e.$$.fragment, f), j(u), a = !0);
    },
    o(f) {
      ne(e.$$.fragment, f), ne(u), a = !1;
    },
    d(f) {
      f && (Fe(n), Fe(i)), nn(e, f), u && u.d(f);
    }
  };
}
function Bb(l) {
  let e, t = Pi(
    /*options*/
    l[40]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = i_(Qu(l, t, i));
  return {
    c() {
      e = Kl("div");
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      this.h();
    },
    l(i) {
      e = Xl(i, "DIV", { class: !0 });
      var a = Wl(e);
      for (let r = 0; r < n.length; r += 1)
        n[r].l(a);
      a.forEach(Fe), this.h();
    },
    h() {
      Wt(e, "class", "options svelte-6d3nkq");
    },
    m(i, a) {
      ot(i, e, a);
      for (let r = 0; r < n.length; r += 1)
        n[r] && n[r].m(e, null);
    },
    p(i, a) {
      if (a[1] & /*dispatch, options*/
      2560) {
        t = Pi(
          /*options*/
          i[40]
        );
        let r;
        for (r = 0; r < t.length; r += 1) {
          const o = Qu(i, t, r);
          n[r] ? n[r].p(o, a) : (n[r] = i_(o), n[r].c(), n[r].m(e, null));
        }
        for (; r < n.length; r += 1)
          n[r].d(1);
        n.length = t.length;
      }
    },
    i: Vi,
    o: Vi,
    d(i) {
      i && Fe(e), Tc(n, i);
    }
  };
}
function qb(l) {
  let e, t;
  return e = new Sc({
    props: {
      layout: (
        /*layout*/
        l[22]
      ),
      avatar_images: (
        /*avatar_images*/
        l[16]
      )
    }
  }), {
    c() {
      tn(e.$$.fragment);
    },
    l(n) {
      en(e.$$.fragment, n);
    },
    m(n, i) {
      ln(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*layout*/
      4194304 && (a.layout = /*layout*/
      n[22]), i[0] & /*avatar_images*/
      65536 && (a.avatar_images = /*avatar_images*/
      n[16]), e.$set(a);
    },
    i(n) {
      t || (j(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ne(e.$$.fragment, n), t = !1;
    },
    d(n) {
      nn(e, n);
    }
  };
}
function i_(l) {
  let e, t = (
    /*option*/
    (l[62].label || /*option*/
    l[62].value) + ""
  ), n, i, a, r;
  function o() {
    return (
      /*click_handler_2*/
      l[53](
        /*index*/
        l[64],
        /*option*/
        l[62]
      )
    );
  }
  return {
    c() {
      e = Kl("button"), n = Fb(t), i = xn(), this.h();
    },
    l(s) {
      e = Xl(s, "BUTTON", { class: !0 });
      var u = Wl(e);
      n = vb(u, t), i = Jn(u), u.forEach(Fe), this.h();
    },
    h() {
      Wt(e, "class", "option svelte-6d3nkq");
    },
    m(s, u) {
      ot(s, e, u), Ho(e, n), Ho(e, i), a || (r = kb(e, "click", o), a = !0);
    },
    p(s, u) {
      l = s, u[1] & /*options*/
      512 && t !== (t = /*option*/
      (l[62].label || /*option*/
      l[62].value) + "") && yb(n, t);
    },
    d(s) {
      s && Fe(e), a = !1, r();
    }
  };
}
function a_(l) {
  let e, t, n;
  return t = new Re({
    props: {
      Icon: I1,
      label: "Scroll down",
      size: "large"
    }
  }), t.$on(
    "click",
    /*scroll_to_bottom*/
    l[43]
  ), {
    c() {
      e = Kl("div"), tn(t.$$.fragment), this.h();
    },
    l(i) {
      e = Xl(i, "DIV", { class: !0 });
      var a = Wl(e);
      en(t.$$.fragment, a), a.forEach(Fe), this.h();
    },
    h() {
      Wt(e, "class", "scroll-down-button-container svelte-6d3nkq");
    },
    m(i, a) {
      ot(i, e, a), ln(t, e, null), n = !0;
    },
    p: Vi,
    i(i) {
      n || (j(t.$$.fragment, i), n = !0);
    },
    o(i) {
      ne(t.$$.fragment, i), n = !1;
    },
    d(i) {
      i && Fe(e), nn(t);
    }
  };
}
function Tb(l) {
  let e, t, n, i, a, r, o, s, u = (
    /*value*/
    l[0] !== null && /*value*/
    l[0].length > 0 && xu(l)
  );
  const c = [Sb, $b], f = [];
  function _(h, p) {
    return (
      /*value*/
      h[0] !== null && /*value*/
      h[0].length > 0 && /*groupedMessages*/
      h[39] !== null ? 0 : 1
    );
  }
  n = _(l), i = f[n] = c[n](l);
  let d = (
    /*show_scroll_button*/
    l[38] && a_(l)
  );
  return {
    c() {
      u && u.c(), e = xn(), t = Kl("div"), i.c(), r = xn(), d && d.c(), o = wl(), this.h();
    },
    l(h) {
      u && u.l(h), e = Jn(h), t = Xl(h, "DIV", {
        class: !0,
        role: !0,
        "aria-label": !0,
        "aria-live": !0
      });
      var p = Wl(t);
      i.l(p), p.forEach(Fe), r = Jn(h), d && d.l(h), o = wl(), this.h();
    },
    h() {
      Wt(t, "class", a = Yu(
        /*layout*/
        l[22] === "bubble" ? "bubble-wrap" : "panel-wrap"
      ) + " svelte-6d3nkq"), Wt(t, "role", "log"), Wt(t, "aria-label", "chatbot conversation"), Wt(t, "aria-live", "polite");
    },
    m(h, p) {
      u && u.m(h, p), ot(h, e, p), ot(h, t, p), f[n].m(t, null), l[55](t), ot(h, r, p), d && d.m(h, p), ot(h, o, p), s = !0;
    },
    p(h, p) {
      /*value*/
      h[0] !== null && /*value*/
      h[0].length > 0 ? u ? (u.p(h, p), p[0] & /*value*/
      1 && j(u, 1)) : (u = xu(h), u.c(), j(u, 1), u.m(e.parentNode, e)) : u && (gn(), ne(u, 1, 1, () => {
        u = null;
      }), pn());
      let v = n;
      n = _(h), n === v ? f[n].p(h, p) : (gn(), ne(f[v], 1, 1, () => {
        f[v] = null;
      }), pn(), i = f[n], i ? i.p(h, p) : (i = f[n] = c[n](h), i.c()), j(i, 1), i.m(t, null)), (!s || p[0] & /*layout*/
      4194304 && a !== (a = Yu(
        /*layout*/
        h[22] === "bubble" ? "bubble-wrap" : "panel-wrap"
      ) + " svelte-6d3nkq")) && Wt(t, "class", a), /*show_scroll_button*/
      h[38] ? d ? (d.p(h, p), p[1] & /*show_scroll_button*/
      128 && j(d, 1)) : (d = a_(h), d.c(), j(d, 1), d.m(o.parentNode, o)) : d && (gn(), ne(d, 1, 1, () => {
        d = null;
      }), pn());
    },
    i(h) {
      s || (j(u), j(i), j(d), s = !0);
    },
    o(h) {
      ne(u), ne(i), ne(d), s = !1;
    },
    d(h) {
      h && (Fe(e), Fe(t), Fe(r), Fe(o)), u && u.d(h), f[n].d(), l[55](null), d && d.d(h);
    }
  };
}
const Ib = () => {
};
function Lb(l, e, t) {
  let n, i;
  var a = this && this.__awaiter || function(A, We, me, Xe) {
    function xe(Sn) {
      return Sn instanceof me ? Sn : new me(function(Dl) {
        Dl(Sn);
      });
    }
    return new (me || (me = Promise))(function(Sn, Dl) {
      function aa(Bn) {
        try {
          oa(Xe.next(Bn));
        } catch (ra) {
          Dl(ra);
        }
      }
      function Pc(Bn) {
        try {
          oa(Xe.throw(Bn));
        } catch (ra) {
          Dl(ra);
        }
      }
      function oa(Bn) {
        Bn.done ? Sn(Bn.value) : xe(Bn.value).then(aa, Pc);
      }
      oa((Xe = Xe.apply(A, We || [])).next());
    });
  };
  let { value: r = [] } = e, o = null, { _fetch: s } = e, { load_component: u } = e, { allow_file_downloads: c } = e, { display_consecutive_in_same_bubble: f } = e, _ = {};
  const d = typeof window < "u";
  function h() {
    return a(this, void 0, void 0, function* () {
      t(33, _ = yield xc(ef(r), _, u));
    });
  }
  let { latex_delimiters: p } = e, { pending_message: v = !1 } = e, { generating: D = !1 } = e, { selectable: w = !1 } = e, { likeable: m = !1 } = e, { feedback_options: g } = e, { feedback_value: k = null } = e, { editable: b = null } = e, { show_share_button: y = !1 } = e, { show_copy_all_button: C = !1 } = e, { rtl: F = !1 } = e, { show_copy_button: B = !1 } = e, { avatar_images: I = [null, null, null] } = e, { sanitize_html: S = !0 } = e, { render_markdown: U = !0 } = e, { line_breaks: V = !0 } = e, { autoscroll: N = !0 } = e, { theme_mode: T } = e, { i18n: x } = e, { layout: H = "bubble" } = e, { placeholder: ee = null } = e, { upload: he } = e, { msg_format: q = "tuples" } = e, { examples: Q = null } = e, { _retryable: ve = !1 } = e, { _undoable: ue = !1 } = e, { like_user_message: be = !1 } = e, { allow_tags: _e = !1 } = e, { watermark: Be = null } = e, { show_progress: L = "full" } = e, ut = null, Je = null, qe = [];
  mo(() => {
    t(34, ut = document.querySelector("div.gradio-container"));
  });
  let ce, _t = !1;
  const Te = Eb();
  function nl() {
    return ce && ce.offsetHeight + ce.scrollTop > ce.scrollHeight - 100;
  }
  function $() {
    ce && (ce.scrollTo(0, ce.scrollHeight), t(38, _t = !1));
  }
  function we() {
    return a(this, void 0, void 0, function* () {
      N && nl() && (yield Cb(), yield new Promise((A) => setTimeout(A, 300)), $());
    });
  }
  mo(() => {
    N && $(), we();
  }), mo(() => {
    function A() {
      nl() ? t(38, _t = !1) : t(38, _t = !0);
    }
    return ce == null || ce.addEventListener("scroll", A), () => {
      ce == null || ce.removeEventListener("scroll", A);
    };
  });
  function kl(A, We, me) {
    if (me === "undo" || me === "retry") {
      const Xe = r;
      let xe = Xe.length - 1;
      for (; Xe[xe].role === "assistant"; )
        xe--;
      Te(me, {
        index: Xe[xe].index,
        value: Xe[xe].content
      });
    } else if (me == "edit")
      t(35, Je = A), qe.push(We.content);
    else if (me == "edit_cancel")
      t(35, Je = null);
    else if (me == "edit_submit")
      t(35, Je = null), Te("edit", {
        index: We.index,
        value: qe[A].slice(),
        previous_value: We.content
      });
    else {
      let Xe = me === "Like" ? !0 : me === "Dislike" ? !1 : me || "";
      if (q === "tuples")
        Te("like", {
          index: We.index,
          value: We.content,
          liked: Xe
        });
      else {
        if (!n) return;
        const xe = n[A], [Sn, Dl] = [xe[0], xe[xe.length - 1]];
        Te("like", {
          index: Sn.index,
          value: xe.map((aa) => aa.content),
          liked: Xe
        });
      }
    }
  }
  function xi() {
    if (!r || !n || n.length === 0) return;
    const A = n[n.length - 1];
    if (A[0].role === "assistant")
      return A[A.length - 1].options;
  }
  const ea = async () => {
    try {
      const A = await Xc(r);
      Te("share", { description: A });
    } catch (A) {
      console.error(A);
      let We = A instanceof bi ? A.message : "Share failed.";
      Te("error", We);
    }
  }, ta = () => Te("clear"), na = (A, We, me) => {
    me == "edit" && qe.splice(0, qe.length), me === "edit" || me === "edit_submit" ? A.forEach((Xe, xe) => {
      kl(me === "edit" ? We : xe, Xe, me);
    }) : kl(We, A[0], me);
  };
  function la(A) {
    qe = A, t(36, qe);
  }
  const ia = (A) => Te("copy", A.detail), E = (A, We) => Te("option_select", { index: A, value: We.value }), Oc = (A) => Te("example_select", A.detail);
  function Hc(A) {
    qc[A ? "unshift" : "push"](() => {
      ce = A, t(37, ce);
    });
  }
  return l.$$set = (A) => {
    "value" in A && t(0, r = A.value), "_fetch" in A && t(1, s = A._fetch), "load_component" in A && t(45, u = A.load_component), "allow_file_downloads" in A && t(2, c = A.allow_file_downloads), "display_consecutive_in_same_bubble" in A && t(3, f = A.display_consecutive_in_same_bubble), "latex_delimiters" in A && t(4, p = A.latex_delimiters), "pending_message" in A && t(5, v = A.pending_message), "generating" in A && t(6, D = A.generating), "selectable" in A && t(7, w = A.selectable), "likeable" in A && t(8, m = A.likeable), "feedback_options" in A && t(9, g = A.feedback_options), "feedback_value" in A && t(10, k = A.feedback_value), "editable" in A && t(11, b = A.editable), "show_share_button" in A && t(12, y = A.show_share_button), "show_copy_all_button" in A && t(13, C = A.show_copy_all_button), "rtl" in A && t(14, F = A.rtl), "show_copy_button" in A && t(15, B = A.show_copy_button), "avatar_images" in A && t(16, I = A.avatar_images), "sanitize_html" in A && t(17, S = A.sanitize_html), "render_markdown" in A && t(18, U = A.render_markdown), "line_breaks" in A && t(19, V = A.line_breaks), "autoscroll" in A && t(46, N = A.autoscroll), "theme_mode" in A && t(20, T = A.theme_mode), "i18n" in A && t(21, x = A.i18n), "layout" in A && t(22, H = A.layout), "placeholder" in A && t(23, ee = A.placeholder), "upload" in A && t(24, he = A.upload), "msg_format" in A && t(25, q = A.msg_format), "examples" in A && t(26, Q = A.examples), "_retryable" in A && t(27, ve = A._retryable), "_undoable" in A && t(28, ue = A._undoable), "like_user_message" in A && t(29, be = A.like_user_message), "allow_tags" in A && t(30, _e = A.allow_tags), "watermark" in A && t(31, Be = A.watermark), "show_progress" in A && t(32, L = A.show_progress);
  }, l.$$.update = () => {
    l.$$.dirty[0] & /*value*/
    1 && h(), l.$$.dirty[0] & /*value, pending_message*/
    33 | l.$$.dirty[1] & /*_components*/
    4 && (r || v || _) && we(), l.$$.dirty[0] & /*value*/
    1 | l.$$.dirty[1] & /*old_value*/
    65536 && (Ro(r, o) || (t(47, o = r), Te("change"))), l.$$.dirty[0] & /*value, msg_format, display_consecutive_in_same_bubble*/
    33554441 && t(39, n = r && Jc(r, q, f)), l.$$.dirty[0] & /*value*/
    1 && t(40, i = r && xi());
  }, [
    r,
    s,
    c,
    f,
    p,
    v,
    D,
    w,
    m,
    g,
    k,
    b,
    y,
    C,
    F,
    B,
    I,
    S,
    U,
    V,
    T,
    x,
    H,
    ee,
    he,
    q,
    Q,
    ve,
    ue,
    be,
    _e,
    Be,
    L,
    _,
    ut,
    Je,
    qe,
    ce,
    _t,
    n,
    i,
    d,
    Te,
    $,
    kl,
    u,
    N,
    o,
    ea,
    ta,
    na,
    la,
    ia,
    E,
    Oc,
    Hc
  ];
}
class zb extends mb {
  constructor(e) {
    super(), wb(
      this,
      e,
      Lb,
      Tb,
      Db,
      {
        value: 0,
        _fetch: 1,
        load_component: 45,
        allow_file_downloads: 2,
        display_consecutive_in_same_bubble: 3,
        latex_delimiters: 4,
        pending_message: 5,
        generating: 6,
        selectable: 7,
        likeable: 8,
        feedback_options: 9,
        feedback_value: 10,
        editable: 11,
        show_share_button: 12,
        show_copy_all_button: 13,
        rtl: 14,
        show_copy_button: 15,
        avatar_images: 16,
        sanitize_html: 17,
        render_markdown: 18,
        line_breaks: 19,
        autoscroll: 46,
        theme_mode: 20,
        i18n: 21,
        layout: 22,
        placeholder: 23,
        upload: 24,
        msg_format: 25,
        examples: 26,
        _retryable: 27,
        _undoable: 28,
        like_user_message: 29,
        allow_tags: 30,
        watermark: 31,
        show_progress: 32
      },
      null,
      [-1, -1, -1]
    );
  }
}
function fl(l) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; l > 1e3 && t < e.length - 1; )
    l /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(l) ? l : l.toFixed(1)) + n;
}
const {
  SvelteComponent: Mb,
  append_hydration: Dt,
  attr: P,
  children: dt,
  claim_element: Rb,
  claim_svg_element: yt,
  component_subscribe: o_,
  detach: nt,
  element: Nb,
  init: Ob,
  insert_hydration: Hb,
  noop: r_,
  safe_not_equal: Pb,
  set_style: pi,
  svg_element: Ft,
  toggle_class: s_
} = window.__gradio__svelte__internal, { onMount: Vb } = window.__gradio__svelte__internal;
function jb(l) {
  let e, t, n, i, a, r, o, s, u, c, f, _;
  return {
    c() {
      e = Nb("div"), t = Ft("svg"), n = Ft("g"), i = Ft("path"), a = Ft("path"), r = Ft("path"), o = Ft("path"), s = Ft("g"), u = Ft("path"), c = Ft("path"), f = Ft("path"), _ = Ft("path"), this.h();
    },
    l(d) {
      e = Rb(d, "DIV", { class: !0 });
      var h = dt(e);
      t = yt(h, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var p = dt(t);
      n = yt(p, "g", { style: !0 });
      var v = dt(n);
      i = yt(v, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), dt(i).forEach(nt), a = yt(v, "path", { d: !0, fill: !0, class: !0 }), dt(a).forEach(nt), r = yt(v, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), dt(r).forEach(nt), o = yt(v, "path", { d: !0, fill: !0, class: !0 }), dt(o).forEach(nt), v.forEach(nt), s = yt(p, "g", { style: !0 });
      var D = dt(s);
      u = yt(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), dt(u).forEach(nt), c = yt(D, "path", { d: !0, fill: !0, class: !0 }), dt(c).forEach(nt), f = yt(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), dt(f).forEach(nt), _ = yt(D, "path", { d: !0, fill: !0, class: !0 }), dt(_).forEach(nt), D.forEach(nt), p.forEach(nt), h.forEach(nt), this.h();
    },
    h() {
      P(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), P(i, "fill", "#FF7C00"), P(i, "fill-opacity", "0.4"), P(i, "class", "svelte-43sxxs"), P(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), P(a, "fill", "#FF7C00"), P(a, "class", "svelte-43sxxs"), P(r, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), P(r, "fill", "#FF7C00"), P(r, "fill-opacity", "0.4"), P(r, "class", "svelte-43sxxs"), P(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), P(o, "fill", "#FF7C00"), P(o, "class", "svelte-43sxxs"), pi(n, "transform", "translate(" + /*$top*/
      l[1][0] + "px, " + /*$top*/
      l[1][1] + "px)"), P(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), P(u, "fill", "#FF7C00"), P(u, "fill-opacity", "0.4"), P(u, "class", "svelte-43sxxs"), P(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), P(c, "fill", "#FF7C00"), P(c, "class", "svelte-43sxxs"), P(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), P(f, "fill", "#FF7C00"), P(f, "fill-opacity", "0.4"), P(f, "class", "svelte-43sxxs"), P(_, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), P(_, "fill", "#FF7C00"), P(_, "class", "svelte-43sxxs"), pi(s, "transform", "translate(" + /*$bottom*/
      l[2][0] + "px, " + /*$bottom*/
      l[2][1] + "px)"), P(t, "viewBox", "-1200 -1200 3000 3000"), P(t, "fill", "none"), P(t, "xmlns", "http://www.w3.org/2000/svg"), P(t, "class", "svelte-43sxxs"), P(e, "class", "svelte-43sxxs"), s_(
        e,
        "margin",
        /*margin*/
        l[0]
      );
    },
    m(d, h) {
      Hb(d, e, h), Dt(e, t), Dt(t, n), Dt(n, i), Dt(n, a), Dt(n, r), Dt(n, o), Dt(t, s), Dt(s, u), Dt(s, c), Dt(s, f), Dt(s, _);
    },
    p(d, [h]) {
      h & /*$top*/
      2 && pi(n, "transform", "translate(" + /*$top*/
      d[1][0] + "px, " + /*$top*/
      d[1][1] + "px)"), h & /*$bottom*/
      4 && pi(s, "transform", "translate(" + /*$bottom*/
      d[2][0] + "px, " + /*$bottom*/
      d[2][1] + "px)"), h & /*margin*/
      1 && s_(
        e,
        "margin",
        /*margin*/
        d[0]
      );
    },
    i: r_,
    o: r_,
    d(d) {
      d && nt(e);
    }
  };
}
function Ub(l, e, t) {
  let n, i;
  var a = this && this.__awaiter || function(d, h, p, v) {
    function D(w) {
      return w instanceof p ? w : new p(function(m) {
        m(w);
      });
    }
    return new (p || (p = Promise))(function(w, m) {
      function g(y) {
        try {
          b(v.next(y));
        } catch (C) {
          m(C);
        }
      }
      function k(y) {
        try {
          b(v.throw(y));
        } catch (C) {
          m(C);
        }
      }
      function b(y) {
        y.done ? w(y.value) : D(y.value).then(g, k);
      }
      b((v = v.apply(d, h || [])).next());
    });
  };
  let { margin: r = !0 } = e;
  const o = gu([0, 0]);
  o_(l, o, (d) => t(1, n = d));
  const s = gu([0, 0]);
  o_(l, s, (d) => t(2, i = d));
  let u;
  function c() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), s.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), s.set([125, -140])]), yield Promise.all([o.set([-125, 0]), s.set([125, -0])]), yield Promise.all([o.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function f() {
    return a(this, void 0, void 0, function* () {
      yield c(), u || f();
    });
  }
  function _() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), s.set([-125, 0])]), f();
    });
  }
  return Vb(() => (_(), () => u = !0)), l.$$set = (d) => {
    "margin" in d && t(0, r = d.margin);
  }, [r, n, i, o, s];
}
class Gb extends Mb {
  constructor(e) {
    super(), Ob(this, e, Ub, jb, Pb, { margin: 0 });
  }
}
const {
  SvelteComponent: Zb,
  append_hydration: At,
  attr: mt,
  binding_callbacks: u_,
  check_outros: ji,
  children: pt,
  claim_component: fr,
  claim_element: gt,
  claim_space: Ke,
  claim_text: ie,
  create_component: dr,
  create_slot: Ic,
  destroy_component: hr,
  destroy_each: Lc,
  detach: z,
  element: bt,
  empty: vt,
  ensure_array_like: Ui,
  get_all_dirty_from_scope: zc,
  get_slot_changes: Mc,
  group_outros: Gi,
  init: Wb,
  insert_hydration: R,
  mount_component: mr,
  noop: Po,
  safe_not_equal: Xb,
  set_data: st,
  set_style: mn,
  space: Ye,
  text: ae,
  toggle_class: ht,
  transition_in: Ze,
  transition_out: rt,
  update_slot_base: Rc
} = window.__gradio__svelte__internal, { tick: Kb } = window.__gradio__svelte__internal, { onDestroy: Yb } = window.__gradio__svelte__internal, { createEventDispatcher: Qb } = window.__gradio__svelte__internal, Jb = (l) => ({}), __ = (l) => ({}), xb = (l) => ({}), c_ = (l) => ({});
function f_(l, e, t) {
  const n = l.slice();
  return n[43] = e[t], n[45] = t, n;
}
function d_(l, e, t) {
  const n = l.slice();
  return n[43] = e[t], n;
}
function h_(l) {
  let e, t, n, i, a, r;
  return a = new Re({
    props: {
      Icon: Qo,
      label: (
        /*i18n*/
        l[2]("common.clear")
      ),
      disabled: !1,
      size: "x-small",
      background: "var(--background-fill-primary)",
      color: "var(--error-background-text)",
      border: "var(--border-color-primary)"
    }
  }), a.$on(
    "click",
    /*click_handler*/
    l[33]
  ), {
    c() {
      e = bt("div"), t = ae(
        /*validation_error*/
        l[1]
      ), n = Ye(), i = bt("button"), dr(a.$$.fragment), this.h();
    },
    l(o) {
      e = gt(o, "DIV", { class: !0 });
      var s = pt(e);
      t = ie(
        s,
        /*validation_error*/
        l[1]
      ), n = Ke(s), i = gt(s, "BUTTON", {});
      var u = pt(i);
      fr(a.$$.fragment, u), u.forEach(z), s.forEach(z), this.h();
    },
    h() {
      mt(e, "class", "validation-error svelte-vusapu");
    },
    m(o, s) {
      R(o, e, s), At(e, t), At(e, n), At(e, i), mr(a, i, null), r = !0;
    },
    p(o, s) {
      (!r || s[0] & /*validation_error*/
      2) && st(
        t,
        /*validation_error*/
        o[1]
      );
      const u = {};
      s[0] & /*i18n*/
      4 && (u.label = /*i18n*/
      o[2]("common.clear")), a.$set(u);
    },
    i(o) {
      r || (Ze(a.$$.fragment, o), r = !0);
    },
    o(o) {
      rt(a.$$.fragment, o), r = !1;
    },
    d(o) {
      o && z(e), hr(a);
    }
  };
}
function ev(l) {
  let e, t, n, i, a = (
    /*i18n*/
    l[2]("common.error") + ""
  ), r, o, s;
  t = new Re({
    props: {
      Icon: Qo,
      label: (
        /*i18n*/
        l[2]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler_1*/
    l[35]
  );
  const u = (
    /*#slots*/
    l[32].error
  ), c = Ic(
    u,
    l,
    /*$$scope*/
    l[31],
    __
  );
  return {
    c() {
      e = bt("div"), dr(t.$$.fragment), n = Ye(), i = bt("span"), r = ae(a), o = Ye(), c && c.c(), this.h();
    },
    l(f) {
      e = gt(f, "DIV", { class: !0 });
      var _ = pt(e);
      fr(t.$$.fragment, _), _.forEach(z), n = Ke(f), i = gt(f, "SPAN", { class: !0 });
      var d = pt(i);
      r = ie(d, a), d.forEach(z), o = Ke(f), c && c.l(f), this.h();
    },
    h() {
      mt(e, "class", "clear-status svelte-vusapu"), mt(i, "class", "error svelte-vusapu");
    },
    m(f, _) {
      R(f, e, _), mr(t, e, null), R(f, n, _), R(f, i, _), At(i, r), R(f, o, _), c && c.m(f, _), s = !0;
    },
    p(f, _) {
      const d = {};
      _[0] & /*i18n*/
      4 && (d.label = /*i18n*/
      f[2]("common.clear")), t.$set(d), (!s || _[0] & /*i18n*/
      4) && a !== (a = /*i18n*/
      f[2]("common.error") + "") && st(r, a), c && c.p && (!s || _[1] & /*$$scope*/
      1) && Rc(
        c,
        u,
        f,
        /*$$scope*/
        f[31],
        s ? Mc(
          u,
          /*$$scope*/
          f[31],
          _,
          Jb
        ) : zc(
          /*$$scope*/
          f[31]
        ),
        __
      );
    },
    i(f) {
      s || (Ze(t.$$.fragment, f), Ze(c, f), s = !0);
    },
    o(f) {
      rt(t.$$.fragment, f), rt(c, f), s = !1;
    },
    d(f) {
      f && (z(e), z(n), z(i), z(o)), hr(t), c && c.d(f);
    }
  };
}
function tv(l) {
  let e, t, n, i, a, r, o, s, u, c = (
    /*variant*/
    l[9] === "default" && /*show_eta_bar*/
    l[20] && /*show_progress*/
    l[7] === "full" && m_(l)
  );
  function f(m, g) {
    if (
      /*progress*/
      m[8]
    ) return iv;
    if (
      /*queue_position*/
      m[3] !== null && /*queue_size*/
      m[4] !== void 0 && /*queue_position*/
      m[3] >= 0
    ) return lv;
    if (
      /*queue_position*/
      m[3] === 0
    ) return nv;
  }
  let _ = f(l), d = _ && _(l), h = (
    /*timer*/
    l[6] && b_(l)
  );
  const p = [sv, rv], v = [];
  function D(m, g) {
    return (
      /*last_progress_level*/
      m[17] != null ? 0 : (
        /*show_progress*/
        m[7] === "full" ? 1 : -1
      )
    );
  }
  ~(a = D(l)) && (r = v[a] = p[a](l));
  let w = !/*timer*/
  l[6] && E_(l);
  return {
    c() {
      c && c.c(), e = Ye(), t = bt("div"), d && d.c(), n = Ye(), h && h.c(), i = Ye(), r && r.c(), o = Ye(), w && w.c(), s = vt(), this.h();
    },
    l(m) {
      c && c.l(m), e = Ke(m), t = gt(m, "DIV", { class: !0 });
      var g = pt(t);
      d && d.l(g), n = Ke(g), h && h.l(g), g.forEach(z), i = Ke(m), r && r.l(m), o = Ke(m), w && w.l(m), s = vt(), this.h();
    },
    h() {
      mt(t, "class", "progress-text svelte-vusapu"), ht(
        t,
        "meta-text-center",
        /*variant*/
        l[9] === "center"
      ), ht(
        t,
        "meta-text",
        /*variant*/
        l[9] === "default"
      );
    },
    m(m, g) {
      c && c.m(m, g), R(m, e, g), R(m, t, g), d && d.m(t, null), At(t, n), h && h.m(t, null), R(m, i, g), ~a && v[a].m(m, g), R(m, o, g), w && w.m(m, g), R(m, s, g), u = !0;
    },
    p(m, g) {
      /*variant*/
      m[9] === "default" && /*show_eta_bar*/
      m[20] && /*show_progress*/
      m[7] === "full" ? c ? c.p(m, g) : (c = m_(m), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), _ === (_ = f(m)) && d ? d.p(m, g) : (d && d.d(1), d = _ && _(m), d && (d.c(), d.m(t, n))), /*timer*/
      m[6] ? h ? h.p(m, g) : (h = b_(m), h.c(), h.m(t, null)) : h && (h.d(1), h = null), (!u || g[0] & /*variant*/
      512) && ht(
        t,
        "meta-text-center",
        /*variant*/
        m[9] === "center"
      ), (!u || g[0] & /*variant*/
      512) && ht(
        t,
        "meta-text",
        /*variant*/
        m[9] === "default"
      );
      let k = a;
      a = D(m), a === k ? ~a && v[a].p(m, g) : (r && (Gi(), rt(v[k], 1, 1, () => {
        v[k] = null;
      }), ji()), ~a ? (r = v[a], r ? r.p(m, g) : (r = v[a] = p[a](m), r.c()), Ze(r, 1), r.m(o.parentNode, o)) : r = null), /*timer*/
      m[6] ? w && (Gi(), rt(w, 1, 1, () => {
        w = null;
      }), ji()) : w ? (w.p(m, g), g[0] & /*timer*/
      64 && Ze(w, 1)) : (w = E_(m), w.c(), Ze(w, 1), w.m(s.parentNode, s));
    },
    i(m) {
      u || (Ze(r), Ze(w), u = !0);
    },
    o(m) {
      rt(r), rt(w), u = !1;
    },
    d(m) {
      m && (z(e), z(t), z(i), z(o), z(s)), c && c.d(m), d && d.d(), h && h.d(), ~a && v[a].d(m), w && w.d(m);
    }
  };
}
function m_(l) {
  let e, t = `translateX(${/*eta_level*/
  (l[19] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = bt("div"), this.h();
    },
    l(n) {
      e = gt(n, "DIV", { class: !0 }), pt(e).forEach(z), this.h();
    },
    h() {
      mt(e, "class", "eta-bar svelte-vusapu"), mn(e, "transform", t);
    },
    m(n, i) {
      R(n, e, i);
    },
    p(n, i) {
      i[0] & /*eta_level*/
      524288 && t !== (t = `translateX(${/*eta_level*/
      (n[19] || 0) * 100 - 100}%)`) && mn(e, "transform", t);
    },
    d(n) {
      n && z(e);
    }
  };
}
function nv(l) {
  let e;
  return {
    c() {
      e = ae("processing |");
    },
    l(t) {
      e = ie(t, "processing |");
    },
    m(t, n) {
      R(t, e, n);
    },
    p: Po,
    d(t) {
      t && z(e);
    }
  };
}
function lv(l) {
  let e, t = (
    /*queue_position*/
    l[3] + 1 + ""
  ), n, i, a, r;
  return {
    c() {
      e = ae("queue: "), n = ae(t), i = ae("/"), a = ae(
        /*queue_size*/
        l[4]
      ), r = ae(" |");
    },
    l(o) {
      e = ie(o, "queue: "), n = ie(o, t), i = ie(o, "/"), a = ie(
        o,
        /*queue_size*/
        l[4]
      ), r = ie(o, " |");
    },
    m(o, s) {
      R(o, e, s), R(o, n, s), R(o, i, s), R(o, a, s), R(o, r, s);
    },
    p(o, s) {
      s[0] & /*queue_position*/
      8 && t !== (t = /*queue_position*/
      o[3] + 1 + "") && st(n, t), s[0] & /*queue_size*/
      16 && st(
        a,
        /*queue_size*/
        o[4]
      );
    },
    d(o) {
      o && (z(e), z(n), z(i), z(a), z(r));
    }
  };
}
function iv(l) {
  let e, t = Ui(
    /*progress*/
    l[8]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = g_(d_(l, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = vt();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = vt();
    },
    m(i, a) {
      for (let r = 0; r < n.length; r += 1)
        n[r] && n[r].m(i, a);
      R(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress*/
      256) {
        t = Ui(
          /*progress*/
          i[8]
        );
        let r;
        for (r = 0; r < t.length; r += 1) {
          const o = d_(i, t, r);
          n[r] ? n[r].p(o, a) : (n[r] = g_(o), n[r].c(), n[r].m(e.parentNode, e));
        }
        for (; r < n.length; r += 1)
          n[r].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && z(e), Lc(n, i);
    }
  };
}
function p_(l) {
  let e, t = (
    /*p*/
    l[43].unit + ""
  ), n, i, a = " ", r;
  function o(c, f) {
    return (
      /*p*/
      c[43].length != null ? ov : av
    );
  }
  let s = o(l), u = s(l);
  return {
    c() {
      u.c(), e = Ye(), n = ae(t), i = ae(" | "), r = ae(a);
    },
    l(c) {
      u.l(c), e = Ke(c), n = ie(c, t), i = ie(c, " | "), r = ie(c, a);
    },
    m(c, f) {
      u.m(c, f), R(c, e, f), R(c, n, f), R(c, i, f), R(c, r, f);
    },
    p(c, f) {
      s === (s = o(c)) && u ? u.p(c, f) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), f[0] & /*progress*/
      256 && t !== (t = /*p*/
      c[43].unit + "") && st(n, t);
    },
    d(c) {
      c && (z(e), z(n), z(i), z(r)), u.d(c);
    }
  };
}
function av(l) {
  let e = fl(
    /*p*/
    l[43].index || 0
  ) + "", t;
  return {
    c() {
      t = ae(e);
    },
    l(n) {
      t = ie(n, e);
    },
    m(n, i) {
      R(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      256 && e !== (e = fl(
        /*p*/
        n[43].index || 0
      ) + "") && st(t, e);
    },
    d(n) {
      n && z(t);
    }
  };
}
function ov(l) {
  let e = fl(
    /*p*/
    l[43].index || 0
  ) + "", t, n, i = fl(
    /*p*/
    l[43].length
  ) + "", a;
  return {
    c() {
      t = ae(e), n = ae("/"), a = ae(i);
    },
    l(r) {
      t = ie(r, e), n = ie(r, "/"), a = ie(r, i);
    },
    m(r, o) {
      R(r, t, o), R(r, n, o), R(r, a, o);
    },
    p(r, o) {
      o[0] & /*progress*/
      256 && e !== (e = fl(
        /*p*/
        r[43].index || 0
      ) + "") && st(t, e), o[0] & /*progress*/
      256 && i !== (i = fl(
        /*p*/
        r[43].length
      ) + "") && st(a, i);
    },
    d(r) {
      r && (z(t), z(n), z(a));
    }
  };
}
function g_(l) {
  let e, t = (
    /*p*/
    l[43].index != null && p_(l)
  );
  return {
    c() {
      t && t.c(), e = vt();
    },
    l(n) {
      t && t.l(n), e = vt();
    },
    m(n, i) {
      t && t.m(n, i), R(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[43].index != null ? t ? t.p(n, i) : (t = p_(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && z(e), t && t.d(n);
    }
  };
}
function b_(l) {
  let e, t = (
    /*eta*/
    l[0] ? `/${/*formatted_eta*/
    l[21]}` : ""
  ), n, i;
  return {
    c() {
      e = ae(
        /*formatted_timer*/
        l[22]
      ), n = ae(t), i = ae("s");
    },
    l(a) {
      e = ie(
        a,
        /*formatted_timer*/
        l[22]
      ), n = ie(a, t), i = ie(a, "s");
    },
    m(a, r) {
      R(a, e, r), R(a, n, r), R(a, i, r);
    },
    p(a, r) {
      r[0] & /*formatted_timer*/
      4194304 && st(
        e,
        /*formatted_timer*/
        a[22]
      ), r[0] & /*eta, formatted_eta*/
      2097153 && t !== (t = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[21]}` : "") && st(n, t);
    },
    d(a) {
      a && (z(e), z(n), z(i));
    }
  };
}
function rv(l) {
  let e, t;
  return e = new Gb({
    props: { margin: (
      /*variant*/
      l[9] === "default"
    ) }
  }), {
    c() {
      dr(e.$$.fragment);
    },
    l(n) {
      fr(e.$$.fragment, n);
    },
    m(n, i) {
      mr(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*variant*/
      512 && (a.margin = /*variant*/
      n[9] === "default"), e.$set(a);
    },
    i(n) {
      t || (Ze(e.$$.fragment, n), t = !0);
    },
    o(n) {
      rt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      hr(e, n);
    }
  };
}
function sv(l) {
  let e, t, n, i, a, r = `${/*last_progress_level*/
  l[17] * 100}%`, o = (
    /*progress*/
    l[8] != null && v_(l)
  );
  return {
    c() {
      e = bt("div"), t = bt("div"), o && o.c(), n = Ye(), i = bt("div"), a = bt("div"), this.h();
    },
    l(s) {
      e = gt(s, "DIV", { class: !0 });
      var u = pt(e);
      t = gt(u, "DIV", { class: !0 });
      var c = pt(t);
      o && o.l(c), c.forEach(z), n = Ke(u), i = gt(u, "DIV", { class: !0 });
      var f = pt(i);
      a = gt(f, "DIV", { class: !0 }), pt(a).forEach(z), f.forEach(z), u.forEach(z), this.h();
    },
    h() {
      mt(t, "class", "progress-level-inner svelte-vusapu"), mt(a, "class", "progress-bar svelte-vusapu"), mn(a, "width", r), mt(i, "class", "progress-bar-wrap svelte-vusapu"), mt(e, "class", "progress-level svelte-vusapu");
    },
    m(s, u) {
      R(s, e, u), At(e, t), o && o.m(t, null), At(e, n), At(e, i), At(i, a), l[34](a);
    },
    p(s, u) {
      /*progress*/
      s[8] != null ? o ? o.p(s, u) : (o = v_(s), o.c(), o.m(t, null)) : o && (o.d(1), o = null), u[0] & /*last_progress_level*/
      131072 && r !== (r = `${/*last_progress_level*/
      s[17] * 100}%`) && mn(a, "width", r);
    },
    i: Po,
    o: Po,
    d(s) {
      s && z(e), o && o.d(), l[34](null);
    }
  };
}
function v_(l) {
  let e, t = Ui(
    /*progress*/
    l[8]
  ), n = [];
  for (let i = 0; i < t.length; i += 1)
    n[i] = F_(f_(l, t, i));
  return {
    c() {
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      e = vt();
    },
    l(i) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(i);
      e = vt();
    },
    m(i, a) {
      for (let r = 0; r < n.length; r += 1)
        n[r] && n[r].m(i, a);
      R(i, e, a);
    },
    p(i, a) {
      if (a[0] & /*progress_level, progress*/
      65792) {
        t = Ui(
          /*progress*/
          i[8]
        );
        let r;
        for (r = 0; r < t.length; r += 1) {
          const o = f_(i, t, r);
          n[r] ? n[r].p(o, a) : (n[r] = F_(o), n[r].c(), n[r].m(e.parentNode, e));
        }
        for (; r < n.length; r += 1)
          n[r].d(1);
        n.length = t.length;
      }
    },
    d(i) {
      i && z(e), Lc(n, i);
    }
  };
}
function w_(l) {
  let e, t, n, i, a = (
    /*i*/
    l[45] !== 0 && uv()
  ), r = (
    /*p*/
    l[43].desc != null && k_(l)
  ), o = (
    /*p*/
    l[43].desc != null && /*progress_level*/
    l[16] && /*progress_level*/
    l[16][
      /*i*/
      l[45]
    ] != null && D_()
  ), s = (
    /*progress_level*/
    l[16] != null && y_(l)
  );
  return {
    c() {
      a && a.c(), e = Ye(), r && r.c(), t = Ye(), o && o.c(), n = Ye(), s && s.c(), i = vt();
    },
    l(u) {
      a && a.l(u), e = Ke(u), r && r.l(u), t = Ke(u), o && o.l(u), n = Ke(u), s && s.l(u), i = vt();
    },
    m(u, c) {
      a && a.m(u, c), R(u, e, c), r && r.m(u, c), R(u, t, c), o && o.m(u, c), R(u, n, c), s && s.m(u, c), R(u, i, c);
    },
    p(u, c) {
      /*p*/
      u[43].desc != null ? r ? r.p(u, c) : (r = k_(u), r.c(), r.m(t.parentNode, t)) : r && (r.d(1), r = null), /*p*/
      u[43].desc != null && /*progress_level*/
      u[16] && /*progress_level*/
      u[16][
        /*i*/
        u[45]
      ] != null ? o || (o = D_(), o.c(), o.m(n.parentNode, n)) : o && (o.d(1), o = null), /*progress_level*/
      u[16] != null ? s ? s.p(u, c) : (s = y_(u), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (z(e), z(t), z(n), z(i)), a && a.d(u), r && r.d(u), o && o.d(u), s && s.d(u);
    }
  };
}
function uv(l) {
  let e;
  return {
    c() {
      e = ae(" /");
    },
    l(t) {
      e = ie(t, " /");
    },
    m(t, n) {
      R(t, e, n);
    },
    d(t) {
      t && z(e);
    }
  };
}
function k_(l) {
  let e = (
    /*p*/
    l[43].desc + ""
  ), t;
  return {
    c() {
      t = ae(e);
    },
    l(n) {
      t = ie(n, e);
    },
    m(n, i) {
      R(n, t, i);
    },
    p(n, i) {
      i[0] & /*progress*/
      256 && e !== (e = /*p*/
      n[43].desc + "") && st(t, e);
    },
    d(n) {
      n && z(t);
    }
  };
}
function D_(l) {
  let e;
  return {
    c() {
      e = ae("-");
    },
    l(t) {
      e = ie(t, "-");
    },
    m(t, n) {
      R(t, e, n);
    },
    d(t) {
      t && z(e);
    }
  };
}
function y_(l) {
  let e = (100 * /*progress_level*/
  (l[16][
    /*i*/
    l[45]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = ae(e), n = ae("%");
    },
    l(i) {
      t = ie(i, e), n = ie(i, "%");
    },
    m(i, a) {
      R(i, t, a), R(i, n, a);
    },
    p(i, a) {
      a[0] & /*progress_level*/
      65536 && e !== (e = (100 * /*progress_level*/
      (i[16][
        /*i*/
        i[45]
      ] || 0)).toFixed(1) + "") && st(t, e);
    },
    d(i) {
      i && (z(t), z(n));
    }
  };
}
function F_(l) {
  let e, t = (
    /*p*/
    (l[43].desc != null || /*progress_level*/
    l[16] && /*progress_level*/
    l[16][
      /*i*/
      l[45]
    ] != null) && w_(l)
  );
  return {
    c() {
      t && t.c(), e = vt();
    },
    l(n) {
      t && t.l(n), e = vt();
    },
    m(n, i) {
      t && t.m(n, i), R(n, e, i);
    },
    p(n, i) {
      /*p*/
      n[43].desc != null || /*progress_level*/
      n[16] && /*progress_level*/
      n[16][
        /*i*/
        n[45]
      ] != null ? t ? t.p(n, i) : (t = w_(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && z(e), t && t.d(n);
    }
  };
}
function E_(l) {
  let e, t, n, i;
  const a = (
    /*#slots*/
    l[32]["additional-loading-text"]
  ), r = Ic(
    a,
    l,
    /*$$scope*/
    l[31],
    c_
  );
  return {
    c() {
      e = bt("p"), t = ae(
        /*loading_text*/
        l[10]
      ), n = Ye(), r && r.c(), this.h();
    },
    l(o) {
      e = gt(o, "P", { class: !0 });
      var s = pt(e);
      t = ie(
        s,
        /*loading_text*/
        l[10]
      ), s.forEach(z), n = Ke(o), r && r.l(o), this.h();
    },
    h() {
      mt(e, "class", "loading svelte-vusapu");
    },
    m(o, s) {
      R(o, e, s), At(e, t), R(o, n, s), r && r.m(o, s), i = !0;
    },
    p(o, s) {
      (!i || s[0] & /*loading_text*/
      1024) && st(
        t,
        /*loading_text*/
        o[10]
      ), r && r.p && (!i || s[1] & /*$$scope*/
      1) && Rc(
        r,
        a,
        o,
        /*$$scope*/
        o[31],
        i ? Mc(
          a,
          /*$$scope*/
          o[31],
          s,
          xb
        ) : zc(
          /*$$scope*/
          o[31]
        ),
        c_
      );
    },
    i(o) {
      i || (Ze(r, o), i = !0);
    },
    o(o) {
      rt(r, o), i = !1;
    },
    d(o) {
      o && (z(e), z(n)), r && r.d(o);
    }
  };
}
function _v(l) {
  let e, t, n, i, a, r, o = (
    /*validation_error*/
    l[1] && /*show_validation_error*/
    l[14] && h_(l)
  );
  const s = [tv, ev], u = [];
  function c(f, _) {
    return (
      /*status*/
      f[5] === "pending" ? 0 : (
        /*status*/
        f[5] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = c(l)) && (i = u[n] = s[n](l)), {
    c() {
      e = bt("div"), o && o.c(), t = Ye(), i && i.c(), this.h();
    },
    l(f) {
      e = gt(f, "DIV", { class: !0 });
      var _ = pt(e);
      o && o.l(_), t = Ke(_), i && i.l(_), _.forEach(z), this.h();
    },
    h() {
      mt(e, "class", a = "wrap " + /*variant*/
      l[9] + " " + /*show_progress*/
      l[7] + " svelte-vusapu"), ht(e, "hide", (!/*status*/
      l[5] || /*status*/
      l[5] === "complete" || /*show_progress*/
      l[7] === "hidden" || /*status*/
      l[5] == "streaming") && !/*validation_error*/
      l[1]), ht(
        e,
        "translucent",
        /*variant*/
        l[9] === "center" && /*status*/
        (l[5] === "pending" || /*status*/
        l[5] === "error") || /*translucent*/
        l[12] || /*show_progress*/
        l[7] === "minimal" || /*validation_error*/
        l[1]
      ), ht(
        e,
        "generating",
        /*status*/
        l[5] === "generating" && /*show_progress*/
        l[7] === "full"
      ), ht(
        e,
        "border",
        /*border*/
        l[13]
      ), mn(
        e,
        "position",
        /*absolute*/
        l[11] ? "absolute" : "static"
      ), mn(
        e,
        "padding",
        /*absolute*/
        l[11] ? "0" : "var(--size-8) 0"
      );
    },
    m(f, _) {
      R(f, e, _), o && o.m(e, null), At(e, t), ~n && u[n].m(e, null), l[36](e), r = !0;
    },
    p(f, _) {
      /*validation_error*/
      f[1] && /*show_validation_error*/
      f[14] ? o ? (o.p(f, _), _[0] & /*validation_error, show_validation_error*/
      16386 && Ze(o, 1)) : (o = h_(f), o.c(), Ze(o, 1), o.m(e, t)) : o && (Gi(), rt(o, 1, 1, () => {
        o = null;
      }), ji());
      let d = n;
      n = c(f), n === d ? ~n && u[n].p(f, _) : (i && (Gi(), rt(u[d], 1, 1, () => {
        u[d] = null;
      }), ji()), ~n ? (i = u[n], i ? i.p(f, _) : (i = u[n] = s[n](f), i.c()), Ze(i, 1), i.m(e, null)) : i = null), (!r || _[0] & /*variant, show_progress*/
      640 && a !== (a = "wrap " + /*variant*/
      f[9] + " " + /*show_progress*/
      f[7] + " svelte-vusapu")) && mt(e, "class", a), (!r || _[0] & /*variant, show_progress, status, show_progress, validation_error*/
      674) && ht(e, "hide", (!/*status*/
      f[5] || /*status*/
      f[5] === "complete" || /*show_progress*/
      f[7] === "hidden" || /*status*/
      f[5] == "streaming") && !/*validation_error*/
      f[1]), (!r || _[0] & /*variant, show_progress, variant, status, translucent, show_progress, validation_error*/
      4770) && ht(
        e,
        "translucent",
        /*variant*/
        f[9] === "center" && /*status*/
        (f[5] === "pending" || /*status*/
        f[5] === "error") || /*translucent*/
        f[12] || /*show_progress*/
        f[7] === "minimal" || /*validation_error*/
        f[1]
      ), (!r || _[0] & /*variant, show_progress, status, show_progress*/
      672) && ht(
        e,
        "generating",
        /*status*/
        f[5] === "generating" && /*show_progress*/
        f[7] === "full"
      ), (!r || _[0] & /*variant, show_progress, border*/
      8832) && ht(
        e,
        "border",
        /*border*/
        f[13]
      ), _[0] & /*absolute*/
      2048 && mn(
        e,
        "position",
        /*absolute*/
        f[11] ? "absolute" : "static"
      ), _[0] & /*absolute*/
      2048 && mn(
        e,
        "padding",
        /*absolute*/
        f[11] ? "0" : "var(--size-8) 0"
      );
    },
    i(f) {
      r || (Ze(o), Ze(i), r = !0);
    },
    o(f) {
      rt(o), rt(i), r = !1;
    },
    d(f) {
      f && z(e), o && o.d(), ~n && u[n].d(), l[36](null);
    }
  };
}
var cv = function(l, e, t, n) {
  function i(a) {
    return a instanceof t ? a : new t(function(r) {
      r(a);
    });
  }
  return new (t || (t = Promise))(function(a, r) {
    function o(c) {
      try {
        u(n.next(c));
      } catch (f) {
        r(f);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (f) {
        r(f);
      }
    }
    function u(c) {
      c.done ? a(c.value) : i(c.value).then(o, s);
    }
    u((n = n.apply(l, e || [])).next());
  });
};
let gi = [], po = !1;
const fv = typeof window < "u", Nc = fv ? window.requestAnimationFrame : (l) => {
};
function dv(l) {
  return cv(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (gi.push(e), !po) po = !0;
      else return;
      yield Kb(), Nc(() => {
        let n = [0, 0];
        for (let i = 0; i < gi.length; i++) {
          const r = gi[i].getBoundingClientRect();
          (i === 0 || r.top + window.scrollY <= n[0]) && (n[0] = r.top + window.scrollY, n[1] = i);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), po = !1, gi = [];
      });
    }
  });
}
function hv(l, e, t) {
  let n, { $$slots: i = {}, $$scope: a } = e;
  const r = Qb();
  let { i18n: o } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: f } = e, { scroll_to_output: _ = !1 } = e, { timer: d = !0 } = e, { show_progress: h = "full" } = e, { message: p = null } = e, { progress: v = null } = e, { variant: D = "default" } = e, { loading_text: w = "Loading..." } = e, { absolute: m = !0 } = e, { translucent: g = !1 } = e, { border: k = !1 } = e, { autoscroll: b } = e, { validation_error: y = null } = e, { show_validation_error: C = !0 } = e, F, B = !1, I = 0, S = 0, U = null, V = null, N = 0, T = null, x, H = null, ee = !0;
  const he = () => {
    t(0, s = t(29, U = t(21, ve = null))), t(27, I = performance.now()), t(28, S = 0), B = !0, q();
  };
  function q() {
    Nc(() => {
      t(28, S = (performance.now() - I) / 1e3), B && q();
    });
  }
  function Q() {
    t(28, S = 0), t(0, s = t(29, U = t(21, ve = null))), B && (B = !1);
  }
  Yb(() => {
    B && Q();
  });
  let ve = null;
  const ue = () => t(1, y = null);
  function be(L) {
    u_[L ? "unshift" : "push"](() => {
      H = L, t(18, H), t(8, v), t(16, T), t(17, x);
    });
  }
  const _e = () => {
    r("clear_status");
  };
  function Be(L) {
    u_[L ? "unshift" : "push"](() => {
      F = L, t(15, F);
    });
  }
  return l.$$set = (L) => {
    "i18n" in L && t(2, o = L.i18n), "eta" in L && t(0, s = L.eta), "queue_position" in L && t(3, u = L.queue_position), "queue_size" in L && t(4, c = L.queue_size), "status" in L && t(5, f = L.status), "scroll_to_output" in L && t(24, _ = L.scroll_to_output), "timer" in L && t(6, d = L.timer), "show_progress" in L && t(7, h = L.show_progress), "message" in L && t(25, p = L.message), "progress" in L && t(8, v = L.progress), "variant" in L && t(9, D = L.variant), "loading_text" in L && t(10, w = L.loading_text), "absolute" in L && t(11, m = L.absolute), "translucent" in L && t(12, g = L.translucent), "border" in L && t(13, k = L.border), "autoscroll" in L && t(26, b = L.autoscroll), "validation_error" in L && t(1, y = L.validation_error), "show_validation_error" in L && t(14, C = L.show_validation_error), "$$scope" in L && t(31, a = L.$$scope);
  }, l.$$.update = () => {
    l.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    1744830465 && (s === null && t(0, s = U), s != null && U !== s && (t(30, V = (performance.now() - I) / 1e3 + s), t(21, ve = V.toFixed(1)), t(29, U = s))), l.$$.dirty[0] & /*eta_from_start, timer_diff*/
    1342177280 && t(19, N = V === null || V <= 0 || !S ? null : Math.min(S / V, 1)), l.$$.dirty[0] & /*progress*/
    256 && v != null && t(20, ee = !1), l.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    459008 && (v != null ? t(16, T = v.map((L) => {
      if (L.index != null && L.length != null)
        return L.index / L.length;
      if (L.progress != null)
        return L.progress;
    })) : t(16, T = null), T ? (t(17, x = T[T.length - 1]), H && (x === 0 ? t(18, H.style.transition = "0", H) : t(18, H.style.transition = "150ms", H))) : t(17, x = void 0)), l.$$.dirty[0] & /*status*/
    32 && (f === "pending" ? he() : Q()), l.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    83918880 && F && _ && (f === "pending" || f === "complete") && dv(F, b), l.$$.dirty[0] & /*status, message*/
    33554464, l.$$.dirty[0] & /*timer_diff*/
    268435456 && t(22, n = S.toFixed(1));
  }, [
    s,
    y,
    o,
    u,
    c,
    f,
    d,
    h,
    v,
    D,
    w,
    m,
    g,
    k,
    C,
    F,
    T,
    x,
    H,
    N,
    ee,
    ve,
    n,
    r,
    _,
    p,
    b,
    I,
    S,
    U,
    V,
    a,
    i,
    ue,
    be,
    _e,
    Be
  ];
}
class mv extends Zb {
  constructor(e) {
    super(), Wb(
      this,
      e,
      hv,
      _v,
      Xb,
      {
        i18n: 2,
        eta: 0,
        queue_position: 3,
        queue_size: 4,
        status: 5,
        scroll_to_output: 24,
        timer: 6,
        show_progress: 7,
        message: 25,
        progress: 8,
        variant: 9,
        loading_text: 10,
        absolute: 11,
        translucent: 12,
        border: 13,
        autoscroll: 26,
        validation_error: 1,
        show_validation_error: 14
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: U$,
  SvelteComponent: G$,
  add_render_callback: Z$,
  append_hydration: W$,
  attr: X$,
  bubble: K$,
  check_outros: Y$,
  children: Q$,
  claim_component: J$,
  claim_element: x$,
  claim_html_tag: eS,
  claim_space: tS,
  claim_text: nS,
  create_component: lS,
  create_in_transition: iS,
  create_out_transition: aS,
  destroy_component: oS,
  detach: rS,
  element: sS,
  get_svelte_dataset: uS,
  group_outros: _S,
  init: cS,
  insert_hydration: fS,
  listen: dS,
  mount_component: hS,
  run_all: mS,
  safe_not_equal: pS,
  set_data: gS,
  space: bS,
  stop_propagation: vS,
  text: wS,
  toggle_class: kS,
  transition_in: DS,
  transition_out: yS
} = window.__gradio__svelte__internal, { createEventDispatcher: FS, onMount: ES } = window.__gradio__svelte__internal, {
  SvelteComponent: CS,
  append_hydration: AS,
  attr: $S,
  bubble: SS,
  check_outros: BS,
  children: qS,
  claim_component: TS,
  claim_element: IS,
  claim_space: LS,
  component_subscribe: zS,
  create_animation: MS,
  create_component: RS,
  destroy_component: NS,
  detach: OS,
  element: HS,
  ensure_array_like: PS,
  fix_and_outro_and_destroy_block: VS,
  fix_position: jS,
  group_outros: US,
  init: GS,
  insert_hydration: ZS,
  mount_component: WS,
  noop: XS,
  safe_not_equal: KS,
  set_style: YS,
  space: QS,
  transition_in: JS,
  transition_out: xS,
  update_keyed_each: eB
} = window.__gradio__svelte__internal, {
  SvelteComponent: tB,
  attr: nB,
  children: lB,
  claim_element: iB,
  detach: aB,
  element: oB,
  empty: rB,
  init: sB,
  insert_hydration: uB,
  noop: _B,
  safe_not_equal: cB,
  set_style: fB
} = window.__gradio__svelte__internal, {
  SvelteComponent: pv,
  append_hydration: gv,
  assign: bv,
  attr: vv,
  check_outros: C_,
  children: wv,
  claim_component: Ki,
  claim_element: kv,
  claim_space: A_,
  create_component: Yi,
  destroy_component: Qi,
  detach: go,
  element: Dv,
  get_spread_object: yv,
  get_spread_update: Fv,
  group_outros: $_,
  init: Ev,
  insert_hydration: S_,
  mount_component: Ji,
  safe_not_equal: Cv,
  space: B_,
  transition_in: zt,
  transition_out: hn
} = window.__gradio__svelte__internal;
function q_(l) {
  let e, t;
  const n = [
    {
      autoscroll: (
        /*gradio*/
        l[27].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      l[27].i18n
    ) },
    /*loading_status*/
    l[30],
    {
      show_progress: (
        /*loading_status*/
        l[30].show_progress === "hidden" ? "hidden" : "minimal"
      )
    }
  ];
  let i = {};
  for (let a = 0; a < n.length; a += 1)
    i = bv(i, n[a]);
  return e = new mv({ props: i }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    l[43]
  ), {
    c() {
      Yi(e.$$.fragment);
    },
    l(a) {
      Ki(e.$$.fragment, a);
    },
    m(a, r) {
      Ji(e, a, r), t = !0;
    },
    p(a, r) {
      const o = r[0] & /*gradio, loading_status*/
      1207959552 ? Fv(n, [
        r[0] & /*gradio*/
        134217728 && {
          autoscroll: (
            /*gradio*/
            a[27].autoscroll
          )
        },
        r[0] & /*gradio*/
        134217728 && { i18n: (
          /*gradio*/
          a[27].i18n
        ) },
        r[0] & /*loading_status*/
        1073741824 && yv(
          /*loading_status*/
          a[30]
        ),
        r[0] & /*loading_status*/
        1073741824 && {
          show_progress: (
            /*loading_status*/
            a[30].show_progress === "hidden" ? "hidden" : "minimal"
          )
        }
      ]) : {};
      e.$set(o);
    },
    i(a) {
      t || (zt(e.$$.fragment, a), t = !0);
    },
    o(a) {
      hn(e.$$.fragment, a), t = !1;
    },
    d(a) {
      Qi(e, a);
    }
  };
}
function T_(l) {
  let e, t;
  return e = new Gh({
    props: {
      show_label: (
        /*show_label*/
        l[7]
      ),
      Icon: hm,
      float: !0,
      label: (
        /*label*/
        l[6] || "Chatbot"
      )
    }
  }), {
    c() {
      Yi(e.$$.fragment);
    },
    l(n) {
      Ki(e.$$.fragment, n);
    },
    m(n, i) {
      Ji(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*show_label*/
      128 && (a.show_label = /*show_label*/
      n[7]), i[0] & /*label*/
      64 && (a.label = /*label*/
      n[6] || "Chatbot"), e.$set(a);
    },
    i(n) {
      t || (zt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      hn(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Qi(e, n);
    }
  };
}
function Av(l) {
  var s, u, c;
  let e, t, n, i, a, r = (
    /*loading_status*/
    l[30] && q_(l)
  ), o = (
    /*show_label*/
    l[7] && T_(l)
  );
  return i = new zb({
    props: {
      i18n: (
        /*gradio*/
        l[27].i18n
      ),
      selectable: (
        /*_selectable*/
        l[8]
      ),
      likeable: (
        /*likeable*/
        l[9]
      ),
      feedback_options: (
        /*feedback_options*/
        l[10]
      ),
      feedback_value: (
        /*feedback_value*/
        l[11]
      ),
      show_share_button: (
        /*show_share_button*/
        l[12]
      ),
      show_copy_all_button: (
        /*show_copy_all_button*/
        l[15]
      ),
      value: (
        /*_value*/
        l[41]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        l[26]
      ),
      display_consecutive_in_same_bubble: (
        /*group_consecutive_messages*/
        l[24]
      ),
      render_markdown: (
        /*render_markdown*/
        l[19]
      ),
      theme_mode: (
        /*theme_mode*/
        l[38]
      ),
      editable: (
        /*editable*/
        l[35]
      ),
      pending_message: (
        /*loading_status*/
        ((s = l[30]) == null ? void 0 : s.status) === "pending"
      ),
      generating: (
        /*loading_status*/
        ((u = l[30]) == null ? void 0 : u.status) === "generating"
      ),
      rtl: (
        /*rtl*/
        l[13]
      ),
      show_copy_button: (
        /*show_copy_button*/
        l[14]
      ),
      like_user_message: (
        /*like_user_message*/
        l[29]
      ),
      show_progress: (
        /*loading_status*/
        ((c = l[30]) == null ? void 0 : c.show_progress) || "full"
      ),
      avatar_images: (
        /*avatar_images*/
        l[28]
      ),
      sanitize_html: (
        /*sanitize_html*/
        l[16]
      ),
      line_breaks: (
        /*line_breaks*/
        l[20]
      ),
      autoscroll: (
        /*autoscroll*/
        l[21]
      ),
      layout: (
        /*layout*/
        l[17]
      ),
      placeholder: (
        /*placeholder*/
        l[36]
      ),
      examples: (
        /*examples*/
        l[37]
      ),
      _retryable: (
        /*_retryable*/
        l[22]
      ),
      _undoable: (
        /*_undoable*/
        l[23]
      ),
      upload: (
        /*func*/
        l[44]
      ),
      _fetch: (
        /*func_1*/
        l[45]
      ),
      load_component: (
        /*gradio*/
        l[27].load_component
      ),
      msg_format: (
        /*type*/
        l[18]
      ),
      allow_file_downloads: (
        /*allow_file_downloads*/
        l[39]
      ),
      allow_tags: (
        /*allow_tags*/
        l[25]
      ),
      watermark: (
        /*watermark*/
        l[40]
      )
    }
  }), i.$on(
    "change",
    /*change_handler*/
    l[46]
  ), i.$on(
    "select",
    /*select_handler*/
    l[47]
  ), i.$on(
    "like",
    /*like_handler*/
    l[48]
  ), i.$on(
    "share",
    /*share_handler*/
    l[49]
  ), i.$on(
    "error",
    /*error_handler*/
    l[50]
  ), i.$on(
    "example_select",
    /*example_select_handler*/
    l[51]
  ), i.$on(
    "option_select",
    /*option_select_handler*/
    l[52]
  ), i.$on(
    "retry",
    /*retry_handler*/
    l[53]
  ), i.$on(
    "undo",
    /*undo_handler*/
    l[54]
  ), i.$on(
    "clear",
    /*clear_handler*/
    l[55]
  ), i.$on(
    "copy",
    /*copy_handler*/
    l[56]
  ), i.$on(
    "edit",
    /*edit_handler*/
    l[57]
  ), {
    c() {
      r && r.c(), e = B_(), t = Dv("div"), o && o.c(), n = B_(), Yi(i.$$.fragment), this.h();
    },
    l(f) {
      r && r.l(f), e = A_(f), t = kv(f, "DIV", { class: !0 });
      var _ = wv(t);
      o && o.l(_), n = A_(_), Ki(i.$$.fragment, _), _.forEach(go), this.h();
    },
    h() {
      vv(t, "class", "wrapper svelte-1ptfoyc");
    },
    m(f, _) {
      r && r.m(f, _), S_(f, e, _), S_(f, t, _), o && o.m(t, null), gv(t, n), Ji(i, t, null), a = !0;
    },
    p(f, _) {
      var h, p, v;
      /*loading_status*/
      f[30] ? r ? (r.p(f, _), _[0] & /*loading_status*/
      1073741824 && zt(r, 1)) : (r = q_(f), r.c(), zt(r, 1), r.m(e.parentNode, e)) : r && ($_(), hn(r, 1, 1, () => {
        r = null;
      }), C_()), /*show_label*/
      f[7] ? o ? (o.p(f, _), _[0] & /*show_label*/
      128 && zt(o, 1)) : (o = T_(f), o.c(), zt(o, 1), o.m(t, n)) : o && ($_(), hn(o, 1, 1, () => {
        o = null;
      }), C_());
      const d = {};
      _[0] & /*gradio*/
      134217728 && (d.i18n = /*gradio*/
      f[27].i18n), _[0] & /*_selectable*/
      256 && (d.selectable = /*_selectable*/
      f[8]), _[0] & /*likeable*/
      512 && (d.likeable = /*likeable*/
      f[9]), _[0] & /*feedback_options*/
      1024 && (d.feedback_options = /*feedback_options*/
      f[10]), _[0] & /*feedback_value*/
      2048 && (d.feedback_value = /*feedback_value*/
      f[11]), _[0] & /*show_share_button*/
      4096 && (d.show_share_button = /*show_share_button*/
      f[12]), _[0] & /*show_copy_all_button*/
      32768 && (d.show_copy_all_button = /*show_copy_all_button*/
      f[15]), _[1] & /*_value*/
      1024 && (d.value = /*_value*/
      f[41]), _[0] & /*latex_delimiters*/
      67108864 && (d.latex_delimiters = /*latex_delimiters*/
      f[26]), _[0] & /*group_consecutive_messages*/
      16777216 && (d.display_consecutive_in_same_bubble = /*group_consecutive_messages*/
      f[24]), _[0] & /*render_markdown*/
      524288 && (d.render_markdown = /*render_markdown*/
      f[19]), _[1] & /*theme_mode*/
      128 && (d.theme_mode = /*theme_mode*/
      f[38]), _[1] & /*editable*/
      16 && (d.editable = /*editable*/
      f[35]), _[0] & /*loading_status*/
      1073741824 && (d.pending_message = /*loading_status*/
      ((h = f[30]) == null ? void 0 : h.status) === "pending"), _[0] & /*loading_status*/
      1073741824 && (d.generating = /*loading_status*/
      ((p = f[30]) == null ? void 0 : p.status) === "generating"), _[0] & /*rtl*/
      8192 && (d.rtl = /*rtl*/
      f[13]), _[0] & /*show_copy_button*/
      16384 && (d.show_copy_button = /*show_copy_button*/
      f[14]), _[0] & /*like_user_message*/
      536870912 && (d.like_user_message = /*like_user_message*/
      f[29]), _[0] & /*loading_status*/
      1073741824 && (d.show_progress = /*loading_status*/
      ((v = f[30]) == null ? void 0 : v.show_progress) || "full"), _[0] & /*avatar_images*/
      268435456 && (d.avatar_images = /*avatar_images*/
      f[28]), _[0] & /*sanitize_html*/
      65536 && (d.sanitize_html = /*sanitize_html*/
      f[16]), _[0] & /*line_breaks*/
      1048576 && (d.line_breaks = /*line_breaks*/
      f[20]), _[0] & /*autoscroll*/
      2097152 && (d.autoscroll = /*autoscroll*/
      f[21]), _[0] & /*layout*/
      131072 && (d.layout = /*layout*/
      f[17]), _[1] & /*placeholder*/
      32 && (d.placeholder = /*placeholder*/
      f[36]), _[1] & /*examples*/
      64 && (d.examples = /*examples*/
      f[37]), _[0] & /*_retryable*/
      4194304 && (d._retryable = /*_retryable*/
      f[22]), _[0] & /*_undoable*/
      8388608 && (d._undoable = /*_undoable*/
      f[23]), _[0] & /*gradio*/
      134217728 && (d.upload = /*func*/
      f[44]), _[0] & /*gradio*/
      134217728 && (d._fetch = /*func_1*/
      f[45]), _[0] & /*gradio*/
      134217728 && (d.load_component = /*gradio*/
      f[27].load_component), _[0] & /*type*/
      262144 && (d.msg_format = /*type*/
      f[18]), _[1] & /*allow_file_downloads*/
      256 && (d.allow_file_downloads = /*allow_file_downloads*/
      f[39]), _[0] & /*allow_tags*/
      33554432 && (d.allow_tags = /*allow_tags*/
      f[25]), _[1] & /*watermark*/
      512 && (d.watermark = /*watermark*/
      f[40]), i.$set(d);
    },
    i(f) {
      a || (zt(r), zt(o), zt(i.$$.fragment, f), a = !0);
    },
    o(f) {
      hn(r), hn(o), hn(i.$$.fragment, f), a = !1;
    },
    d(f) {
      f && (go(e), go(t)), r && r.d(f), o && o.d(), Qi(i);
    }
  };
}
function $v(l) {
  let e, t;
  return e = new Hf({
    props: {
      elem_id: (
        /*elem_id*/
        l[1]
      ),
      elem_classes: (
        /*elem_classes*/
        l[2]
      ),
      visible: (
        /*visible*/
        l[3]
      ),
      padding: !1,
      scale: (
        /*scale*/
        l[4]
      ),
      min_width: (
        /*min_width*/
        l[5]
      ),
      height: (
        /*height*/
        l[31]
      ),
      resizable: (
        /*resizable*/
        l[32]
      ),
      min_height: (
        /*min_height*/
        l[33]
      ),
      max_height: (
        /*max_height*/
        l[34]
      ),
      allow_overflow: !0,
      flex: !0,
      overflow_behavior: "auto",
      $$slots: { default: [Av] },
      $$scope: { ctx: l }
    }
  }), {
    c() {
      Yi(e.$$.fragment);
    },
    l(n) {
      Ki(e.$$.fragment, n);
    },
    m(n, i) {
      Ji(e, n, i), t = !0;
    },
    p(n, i) {
      const a = {};
      i[0] & /*elem_id*/
      2 && (a.elem_id = /*elem_id*/
      n[1]), i[0] & /*elem_classes*/
      4 && (a.elem_classes = /*elem_classes*/
      n[2]), i[0] & /*visible*/
      8 && (a.visible = /*visible*/
      n[3]), i[0] & /*scale*/
      16 && (a.scale = /*scale*/
      n[4]), i[0] & /*min_width*/
      32 && (a.min_width = /*min_width*/
      n[5]), i[1] & /*height*/
      1 && (a.height = /*height*/
      n[31]), i[1] & /*resizable*/
      2 && (a.resizable = /*resizable*/
      n[32]), i[1] & /*min_height*/
      4 && (a.min_height = /*min_height*/
      n[33]), i[1] & /*max_height*/
      8 && (a.max_height = /*max_height*/
      n[34]), i[0] & /*gradio, _selectable, likeable, feedback_options, feedback_value, show_share_button, show_copy_all_button, latex_delimiters, group_consecutive_messages, render_markdown, loading_status, rtl, show_copy_button, like_user_message, avatar_images, sanitize_html, line_breaks, autoscroll, layout, _retryable, _undoable, type, allow_tags, value, show_label, label*/
      2147483585 | i[1] & /*$$scope, _value, theme_mode, editable, placeholder, examples, allow_file_downloads, watermark*/
      134219760 && (a.$$scope = { dirty: i, ctx: n }), e.$set(a);
    },
    i(n) {
      t || (zt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      hn(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Qi(e, n);
    }
  };
}
function Sv(l, e, t) {
  let { elem_id: n = "" } = e, { elem_classes: i = [] } = e, { visible: a = !0 } = e, { value: r = [] } = e, { scale: o = null } = e, { min_width: s = void 0 } = e, { label: u } = e, { show_label: c = !0 } = e, { root: f } = e, { _selectable: _ = !1 } = e, { likeable: d = !1 } = e, { feedback_options: h = ["Like", "Dislike"] } = e, { feedback_value: p = null } = e, { show_share_button: v = !1 } = e, { rtl: D = !1 } = e, { show_copy_button: w = !0 } = e, { show_copy_all_button: m = !1 } = e, { sanitize_html: g = !0 } = e, { layout: k = "bubble" } = e, { type: b = "tuples" } = e, { render_markdown: y = !0 } = e, { line_breaks: C = !0 } = e, { autoscroll: F = !0 } = e, { _retryable: B = !1 } = e, { _undoable: I = !1 } = e, { group_consecutive_messages: S = !0 } = e, { allow_tags: U = !1 } = e, { latex_delimiters: V } = e, { gradio: N } = e, T = [], { avatar_images: x = [null, null] } = e, { like_user_message: H = !1 } = e, { loading_status: ee = void 0 } = e, { height: he } = e, { resizable: q } = e, { min_height: Q } = e, { max_height: ve } = e, { editable: ue = null } = e, { placeholder: be = null } = e, { examples: _e = null } = e, { theme_mode: Be } = e, { allow_file_downloads: L = !0 } = e, { watermark: ut = null } = e;
  const Je = () => N.dispatch("clear_status", ee), qe = (...E) => N.client.upload(...E), ce = (...E) => N.client.fetch(...E), _t = () => N.dispatch("change", r), Te = (E) => N.dispatch("select", E.detail), nl = (E) => N.dispatch("like", E.detail), $ = (E) => N.dispatch("share", E.detail), we = (E) => N.dispatch("error", E.detail), kl = (E) => N.dispatch("example_select", E.detail), xi = (E) => N.dispatch("option_select", E.detail), ea = (E) => N.dispatch("retry", E.detail), ta = (E) => N.dispatch("undo", E.detail), na = () => {
    t(0, r = []), N.dispatch("clear");
  }, la = (E) => N.dispatch("copy", E.detail), ia = (E) => {
    r === null || r.length === 0 || (b === "messages" ? t(0, r[E.detail.index].content = E.detail.value, r) : t(0, r[E.detail.index[0]][E.detail.index[1]] = E.detail.value, r), t(0, r), N.dispatch("edit", E.detail));
  };
  return l.$$set = (E) => {
    "elem_id" in E && t(1, n = E.elem_id), "elem_classes" in E && t(2, i = E.elem_classes), "visible" in E && t(3, a = E.visible), "value" in E && t(0, r = E.value), "scale" in E && t(4, o = E.scale), "min_width" in E && t(5, s = E.min_width), "label" in E && t(6, u = E.label), "show_label" in E && t(7, c = E.show_label), "root" in E && t(42, f = E.root), "_selectable" in E && t(8, _ = E._selectable), "likeable" in E && t(9, d = E.likeable), "feedback_options" in E && t(10, h = E.feedback_options), "feedback_value" in E && t(11, p = E.feedback_value), "show_share_button" in E && t(12, v = E.show_share_button), "rtl" in E && t(13, D = E.rtl), "show_copy_button" in E && t(14, w = E.show_copy_button), "show_copy_all_button" in E && t(15, m = E.show_copy_all_button), "sanitize_html" in E && t(16, g = E.sanitize_html), "layout" in E && t(17, k = E.layout), "type" in E && t(18, b = E.type), "render_markdown" in E && t(19, y = E.render_markdown), "line_breaks" in E && t(20, C = E.line_breaks), "autoscroll" in E && t(21, F = E.autoscroll), "_retryable" in E && t(22, B = E._retryable), "_undoable" in E && t(23, I = E._undoable), "group_consecutive_messages" in E && t(24, S = E.group_consecutive_messages), "allow_tags" in E && t(25, U = E.allow_tags), "latex_delimiters" in E && t(26, V = E.latex_delimiters), "gradio" in E && t(27, N = E.gradio), "avatar_images" in E && t(28, x = E.avatar_images), "like_user_message" in E && t(29, H = E.like_user_message), "loading_status" in E && t(30, ee = E.loading_status), "height" in E && t(31, he = E.height), "resizable" in E && t(32, q = E.resizable), "min_height" in E && t(33, Q = E.min_height), "max_height" in E && t(34, ve = E.max_height), "editable" in E && t(35, ue = E.editable), "placeholder" in E && t(36, be = E.placeholder), "examples" in E && t(37, _e = E.examples), "theme_mode" in E && t(38, Be = E.theme_mode), "allow_file_downloads" in E && t(39, L = E.allow_file_downloads), "watermark" in E && t(40, ut = E.watermark);
  }, l.$$.update = () => {
    l.$$.dirty[0] & /*type, value*/
    262145 | l.$$.dirty[1] & /*root*/
    2048 && t(41, T = b === "tuples" ? Qc(r, f) : Yc(r, f));
  }, [
    r,
    n,
    i,
    a,
    o,
    s,
    u,
    c,
    _,
    d,
    h,
    p,
    v,
    D,
    w,
    m,
    g,
    k,
    b,
    y,
    C,
    F,
    B,
    I,
    S,
    U,
    V,
    N,
    x,
    H,
    ee,
    he,
    q,
    Q,
    ve,
    ue,
    be,
    _e,
    Be,
    L,
    ut,
    T,
    f,
    Je,
    qe,
    ce,
    _t,
    Te,
    nl,
    $,
    we,
    kl,
    xi,
    ea,
    ta,
    na,
    la,
    ia
  ];
}
class dB extends pv {
  constructor(e) {
    super(), Ev(
      this,
      e,
      Sv,
      $v,
      Cv,
      {
        elem_id: 1,
        elem_classes: 2,
        visible: 3,
        value: 0,
        scale: 4,
        min_width: 5,
        label: 6,
        show_label: 7,
        root: 42,
        _selectable: 8,
        likeable: 9,
        feedback_options: 10,
        feedback_value: 11,
        show_share_button: 12,
        rtl: 13,
        show_copy_button: 14,
        show_copy_all_button: 15,
        sanitize_html: 16,
        layout: 17,
        type: 18,
        render_markdown: 19,
        line_breaks: 20,
        autoscroll: 21,
        _retryable: 22,
        _undoable: 23,
        group_consecutive_messages: 24,
        allow_tags: 25,
        latex_delimiters: 26,
        gradio: 27,
        avatar_images: 28,
        like_user_message: 29,
        loading_status: 30,
        height: 31,
        resizable: 32,
        min_height: 33,
        max_height: 34,
        editable: 35,
        placeholder: 36,
        examples: 37,
        theme_mode: 38,
        allow_file_downloads: 39,
        watermark: 40
      },
      null,
      [-1, -1]
    );
  }
}
export {
  zb as C,
  dB as I,
  Or as c,
  o2 as g
};
