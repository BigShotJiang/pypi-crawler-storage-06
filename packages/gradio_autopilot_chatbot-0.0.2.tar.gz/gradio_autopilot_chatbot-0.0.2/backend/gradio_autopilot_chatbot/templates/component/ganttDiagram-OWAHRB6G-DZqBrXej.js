import { a$ as $e, b0 as Un, b1 as Je, b2 as Ke, b3 as tn, b4 as re, b5 as En, _ as h, g as Ln, s as An, q as In, p as Wn, a as On, b as Hn, c as _t, d as Zt, e as Nn, b6 as at, l as Qt, k as Vn, j as zn, y as Pn, u as Rn } from "./mermaid.core-B_TMhUWp.js";
import { c as Te, g as be } from "./Index-BC1pBwEQ.js";
import { b as Bn, t as Ie, c as Zn, a as qn, l as Gn } from "./linear-s-C0QcHm.js";
import { i as Xn } from "./init-DjUOC4st.js";
function jn(t, e) {
  let n;
  if (e === void 0)
    for (const r of t)
      r != null && (n < r || n === void 0 && r >= r) && (n = r);
  else {
    let r = -1;
    for (let a of t)
      (a = e(a, ++r, t)) != null && (n < a || n === void 0 && a >= a) && (n = a);
  }
  return n;
}
function Qn(t, e) {
  let n;
  if (e === void 0)
    for (const r of t)
      r != null && (n > r || n === void 0 && r >= r) && (n = r);
  else {
    let r = -1;
    for (let a of t)
      (a = e(a, ++r, t)) != null && (n > a || n === void 0 && a >= a) && (n = a);
  }
  return n;
}
function $n(t) {
  return t;
}
var Gt = 1, ae = 2, me = 3, qt = 4, We = 1e-6;
function Jn(t) {
  return "translate(" + t + ",0)";
}
function Kn(t) {
  return "translate(0," + t + ")";
}
function tr(t) {
  return (e) => +t(e);
}
function er(t, e) {
  return e = Math.max(0, t.bandwidth() - e * 2) / 2, t.round() && (e = Math.round(e)), (n) => +t(n) + e;
}
function nr() {
  return !this.__axis;
}
function en(t, e) {
  var n = [], r = null, a = null, i = 6, s = 6, y = 3, _ = typeof window < "u" && window.devicePixelRatio > 1 ? 0 : 0.5, p = t === Gt || t === qt ? -1 : 1, g = t === qt || t === ae ? "x" : "y", E = t === Gt || t === me ? Jn : Kn;
  function C(b) {
    var G = r ?? (e.ticks ? e.ticks.apply(e, n) : e.domain()), O = a ?? (e.tickFormat ? e.tickFormat.apply(e, n) : $n), M = Math.max(i, 0) + y, I = e.range(), V = +I[0] + _, W = +I[I.length - 1] + _, Z = (e.bandwidth ? er : tr)(e.copy(), _), Q = b.selection ? b.selection() : b, D = Q.selectAll(".domain").data([null]), H = Q.selectAll(".tick").data(G, e).order(), x = H.exit(), Y = H.enter().append("g").attr("class", "tick"), F = H.select("line"), S = H.select("text");
    D = D.merge(D.enter().insert("path", ".tick").attr("class", "domain").attr("stroke", "currentColor")), H = H.merge(Y), F = F.merge(Y.append("line").attr("stroke", "currentColor").attr(g + "2", p * i)), S = S.merge(Y.append("text").attr("fill", "currentColor").attr(g, p * M).attr("dy", t === Gt ? "0em" : t === me ? "0.71em" : "0.32em")), b !== Q && (D = D.transition(b), H = H.transition(b), F = F.transition(b), S = S.transition(b), x = x.transition(b).attr("opacity", We).attr("transform", function(v) {
      return isFinite(v = Z(v)) ? E(v + _) : this.getAttribute("transform");
    }), Y.attr("opacity", We).attr("transform", function(v) {
      var U = this.parentNode.__axis;
      return E((U && isFinite(U = U(v)) ? U : Z(v)) + _);
    })), x.remove(), D.attr("d", t === qt || t === ae ? s ? "M" + p * s + "," + V + "H" + _ + "V" + W + "H" + p * s : "M" + _ + "," + V + "V" + W : s ? "M" + V + "," + p * s + "V" + _ + "H" + W + "V" + p * s : "M" + V + "," + _ + "H" + W), H.attr("opacity", 1).attr("transform", function(v) {
      return E(Z(v) + _);
    }), F.attr(g + "2", p * i), S.attr(g, p * M).text(O), Q.filter(nr).attr("fill", "none").attr("font-size", 10).attr("font-family", "sans-serif").attr("text-anchor", t === ae ? "start" : t === qt ? "end" : "middle"), Q.each(function() {
      this.__axis = Z;
    });
  }
  return C.scale = function(b) {
    return arguments.length ? (e = b, C) : e;
  }, C.ticks = function() {
    return n = Array.from(arguments), C;
  }, C.tickArguments = function(b) {
    return arguments.length ? (n = b == null ? [] : Array.from(b), C) : n.slice();
  }, C.tickValues = function(b) {
    return arguments.length ? (r = b == null ? null : Array.from(b), C) : r && r.slice();
  }, C.tickFormat = function(b) {
    return arguments.length ? (a = b, C) : a;
  }, C.tickSize = function(b) {
    return arguments.length ? (i = s = +b, C) : i;
  }, C.tickSizeInner = function(b) {
    return arguments.length ? (i = +b, C) : i;
  }, C.tickSizeOuter = function(b) {
    return arguments.length ? (s = +b, C) : s;
  }, C.tickPadding = function(b) {
    return arguments.length ? (y = +b, C) : y;
  }, C.offset = function(b) {
    return arguments.length ? (_ = +b, C) : _;
  }, C;
}
function rr(t) {
  return en(Gt, t);
}
function ar(t) {
  return en(me, t);
}
const ir = Math.PI / 180, sr = 180 / Math.PI, $t = 18, nn = 0.96422, rn = 1, an = 0.82521, sn = 4 / 29, St = 6 / 29, on = 3 * St * St, or = St * St * St;
function cn(t) {
  if (t instanceof ft) return new ft(t.l, t.a, t.b, t.opacity);
  if (t instanceof dt) return ln(t);
  t instanceof $e || (t = Un(t));
  var e = ce(t.r), n = ce(t.g), r = ce(t.b), a = ie((0.2225045 * e + 0.7168786 * n + 0.0606169 * r) / rn), i, s;
  return e === n && n === r ? i = s = a : (i = ie((0.4360747 * e + 0.3850649 * n + 0.1430804 * r) / nn), s = ie((0.0139322 * e + 0.0971045 * n + 0.7141733 * r) / an)), new ft(116 * a - 16, 500 * (i - a), 200 * (a - s), t.opacity);
}
function cr(t, e, n, r) {
  return arguments.length === 1 ? cn(t) : new ft(t, e, n, r ?? 1);
}
function ft(t, e, n, r) {
  this.l = +t, this.a = +e, this.b = +n, this.opacity = +r;
}
Je(ft, cr, Ke(tn, {
  brighter(t) {
    return new ft(this.l + $t * (t ?? 1), this.a, this.b, this.opacity);
  },
  darker(t) {
    return new ft(this.l - $t * (t ?? 1), this.a, this.b, this.opacity);
  },
  rgb() {
    var t = (this.l + 16) / 116, e = isNaN(this.a) ? t : t + this.a / 500, n = isNaN(this.b) ? t : t - this.b / 200;
    return e = nn * se(e), t = rn * se(t), n = an * se(n), new $e(
      oe(3.1338561 * e - 1.6168667 * t - 0.4906146 * n),
      oe(-0.9787684 * e + 1.9161415 * t + 0.033454 * n),
      oe(0.0719453 * e - 0.2289914 * t + 1.4052427 * n),
      this.opacity
    );
  }
}));
function ie(t) {
  return t > or ? Math.pow(t, 1 / 3) : t / on + sn;
}
function se(t) {
  return t > St ? t * t * t : on * (t - sn);
}
function oe(t) {
  return 255 * (t <= 31308e-7 ? 12.92 * t : 1.055 * Math.pow(t, 1 / 2.4) - 0.055);
}
function ce(t) {
  return (t /= 255) <= 0.04045 ? t / 12.92 : Math.pow((t + 0.055) / 1.055, 2.4);
}
function lr(t) {
  if (t instanceof dt) return new dt(t.h, t.c, t.l, t.opacity);
  if (t instanceof ft || (t = cn(t)), t.a === 0 && t.b === 0) return new dt(NaN, 0 < t.l && t.l < 100 ? 0 : NaN, t.l, t.opacity);
  var e = Math.atan2(t.b, t.a) * sr;
  return new dt(e < 0 ? e + 360 : e, Math.sqrt(t.a * t.a + t.b * t.b), t.l, t.opacity);
}
function ge(t, e, n, r) {
  return arguments.length === 1 ? lr(t) : new dt(t, e, n, r ?? 1);
}
function dt(t, e, n, r) {
  this.h = +t, this.c = +e, this.l = +n, this.opacity = +r;
}
function ln(t) {
  if (isNaN(t.h)) return new ft(t.l, 0, 0, t.opacity);
  var e = t.h * ir;
  return new ft(t.l, Math.cos(e) * t.c, Math.sin(e) * t.c, t.opacity);
}
Je(dt, ge, Ke(tn, {
  brighter(t) {
    return new dt(this.h, this.c, this.l + $t * (t ?? 1), this.opacity);
  },
  darker(t) {
    return new dt(this.h, this.c, this.l - $t * (t ?? 1), this.opacity);
  },
  rgb() {
    return ln(this).rgb();
  }
}));
function ur(t) {
  return function(e, n) {
    var r = t((e = ge(e)).h, (n = ge(n)).h), a = re(e.c, n.c), i = re(e.l, n.l), s = re(e.opacity, n.opacity);
    return function(y) {
      return e.h = r(y), e.c = a(y), e.l = i(y), e.opacity = s(y), e + "";
    };
  };
}
const fr = ur(En);
function hr(t, e) {
  t = t.slice();
  var n = 0, r = t.length - 1, a = t[n], i = t[r], s;
  return i < a && (s = n, n = r, r = s, s = a, a = i, i = s), t[n] = e.floor(a), t[r] = e.ceil(i), t;
}
const le = /* @__PURE__ */ new Date(), ue = /* @__PURE__ */ new Date();
function et(t, e, n, r) {
  function a(i) {
    return t(i = arguments.length === 0 ? /* @__PURE__ */ new Date() : /* @__PURE__ */ new Date(+i)), i;
  }
  return a.floor = (i) => (t(i = /* @__PURE__ */ new Date(+i)), i), a.ceil = (i) => (t(i = new Date(i - 1)), e(i, 1), t(i), i), a.round = (i) => {
    const s = a(i), y = a.ceil(i);
    return i - s < y - i ? s : y;
  }, a.offset = (i, s) => (e(i = /* @__PURE__ */ new Date(+i), s == null ? 1 : Math.floor(s)), i), a.range = (i, s, y) => {
    const _ = [];
    if (i = a.ceil(i), y = y == null ? 1 : Math.floor(y), !(i < s) || !(y > 0)) return _;
    let p;
    do
      _.push(p = /* @__PURE__ */ new Date(+i)), e(i, y), t(i);
    while (p < i && i < s);
    return _;
  }, a.filter = (i) => et((s) => {
    if (s >= s) for (; t(s), !i(s); ) s.setTime(s - 1);
  }, (s, y) => {
    if (s >= s)
      if (y < 0) for (; ++y <= 0; )
        for (; e(s, -1), !i(s); )
          ;
      else for (; --y >= 0; )
        for (; e(s, 1), !i(s); )
          ;
  }), n && (a.count = (i, s) => (le.setTime(+i), ue.setTime(+s), t(le), t(ue), Math.floor(n(le, ue))), a.every = (i) => (i = Math.floor(i), !isFinite(i) || !(i > 0) ? null : i > 1 ? a.filter(r ? (s) => r(s) % i === 0 : (s) => a.count(0, s) % i === 0) : a)), a;
}
const Yt = et(() => {
}, (t, e) => {
  t.setTime(+t + e);
}, (t, e) => e - t);
Yt.every = (t) => (t = Math.floor(t), !isFinite(t) || !(t > 0) ? null : t > 1 ? et((e) => {
  e.setTime(Math.floor(e / t) * t);
}, (e, n) => {
  e.setTime(+e + n * t);
}, (e, n) => (n - e) / t) : Yt);
Yt.range;
const mt = 1e3, ct = mt * 60, gt = ct * 60, yt = gt * 24, xe = yt * 7, Oe = yt * 30, fe = yt * 365, vt = et((t) => {
  t.setTime(t - t.getMilliseconds());
}, (t, e) => {
  t.setTime(+t + e * mt);
}, (t, e) => (e - t) / mt, (t) => t.getUTCSeconds());
vt.range;
const Wt = et((t) => {
  t.setTime(t - t.getMilliseconds() - t.getSeconds() * mt);
}, (t, e) => {
  t.setTime(+t + e * ct);
}, (t, e) => (e - t) / ct, (t) => t.getMinutes());
Wt.range;
const dr = et((t) => {
  t.setUTCSeconds(0, 0);
}, (t, e) => {
  t.setTime(+t + e * ct);
}, (t, e) => (e - t) / ct, (t) => t.getUTCMinutes());
dr.range;
const Ot = et((t) => {
  t.setTime(t - t.getMilliseconds() - t.getSeconds() * mt - t.getMinutes() * ct);
}, (t, e) => {
  t.setTime(+t + e * gt);
}, (t, e) => (e - t) / gt, (t) => t.getHours());
Ot.range;
const mr = et((t) => {
  t.setUTCMinutes(0, 0, 0);
}, (t, e) => {
  t.setTime(+t + e * gt);
}, (t, e) => (e - t) / gt, (t) => t.getUTCHours());
mr.range;
const Tt = et(
  (t) => t.setHours(0, 0, 0, 0),
  (t, e) => t.setDate(t.getDate() + e),
  (t, e) => (e - t - (e.getTimezoneOffset() - t.getTimezoneOffset()) * ct) / yt,
  (t) => t.getDate() - 1
);
Tt.range;
const we = et((t) => {
  t.setUTCHours(0, 0, 0, 0);
}, (t, e) => {
  t.setUTCDate(t.getUTCDate() + e);
}, (t, e) => (e - t) / yt, (t) => t.getUTCDate() - 1);
we.range;
const gr = et((t) => {
  t.setUTCHours(0, 0, 0, 0);
}, (t, e) => {
  t.setUTCDate(t.getUTCDate() + e);
}, (t, e) => (e - t) / yt, (t) => Math.floor(t / yt));
gr.range;
function wt(t) {
  return et((e) => {
    e.setDate(e.getDate() - (e.getDay() + 7 - t) % 7), e.setHours(0, 0, 0, 0);
  }, (e, n) => {
    e.setDate(e.getDate() + n * 7);
  }, (e, n) => (n - e - (n.getTimezoneOffset() - e.getTimezoneOffset()) * ct) / xe);
}
const Vt = wt(0), Ht = wt(1), un = wt(2), fn = wt(3), bt = wt(4), hn = wt(5), dn = wt(6);
Vt.range;
Ht.range;
un.range;
fn.range;
bt.range;
hn.range;
dn.range;
function Dt(t) {
  return et((e) => {
    e.setUTCDate(e.getUTCDate() - (e.getUTCDay() + 7 - t) % 7), e.setUTCHours(0, 0, 0, 0);
  }, (e, n) => {
    e.setUTCDate(e.getUTCDate() + n * 7);
  }, (e, n) => (n - e) / xe);
}
const mn = Dt(0), Jt = Dt(1), yr = Dt(2), kr = Dt(3), Ut = Dt(4), pr = Dt(5), vr = Dt(6);
mn.range;
Jt.range;
yr.range;
kr.range;
Ut.range;
pr.range;
vr.range;
const Nt = et((t) => {
  t.setDate(1), t.setHours(0, 0, 0, 0);
}, (t, e) => {
  t.setMonth(t.getMonth() + e);
}, (t, e) => e.getMonth() - t.getMonth() + (e.getFullYear() - t.getFullYear()) * 12, (t) => t.getMonth());
Nt.range;
const Tr = et((t) => {
  t.setUTCDate(1), t.setUTCHours(0, 0, 0, 0);
}, (t, e) => {
  t.setUTCMonth(t.getUTCMonth() + e);
}, (t, e) => e.getUTCMonth() - t.getUTCMonth() + (e.getUTCFullYear() - t.getUTCFullYear()) * 12, (t) => t.getUTCMonth());
Tr.range;
const kt = et((t) => {
  t.setMonth(0, 1), t.setHours(0, 0, 0, 0);
}, (t, e) => {
  t.setFullYear(t.getFullYear() + e);
}, (t, e) => e.getFullYear() - t.getFullYear(), (t) => t.getFullYear());
kt.every = (t) => !isFinite(t = Math.floor(t)) || !(t > 0) ? null : et((e) => {
  e.setFullYear(Math.floor(e.getFullYear() / t) * t), e.setMonth(0, 1), e.setHours(0, 0, 0, 0);
}, (e, n) => {
  e.setFullYear(e.getFullYear() + n * t);
});
kt.range;
const xt = et((t) => {
  t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0);
}, (t, e) => {
  t.setUTCFullYear(t.getUTCFullYear() + e);
}, (t, e) => e.getUTCFullYear() - t.getUTCFullYear(), (t) => t.getUTCFullYear());
xt.every = (t) => !isFinite(t = Math.floor(t)) || !(t > 0) ? null : et((e) => {
  e.setUTCFullYear(Math.floor(e.getUTCFullYear() / t) * t), e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0);
}, (e, n) => {
  e.setUTCFullYear(e.getUTCFullYear() + n * t);
});
xt.range;
function br(t, e, n, r, a, i) {
  const s = [
    [vt, 1, mt],
    [vt, 5, 5 * mt],
    [vt, 15, 15 * mt],
    [vt, 30, 30 * mt],
    [i, 1, ct],
    [i, 5, 5 * ct],
    [i, 15, 15 * ct],
    [i, 30, 30 * ct],
    [a, 1, gt],
    [a, 3, 3 * gt],
    [a, 6, 6 * gt],
    [a, 12, 12 * gt],
    [r, 1, yt],
    [r, 2, 2 * yt],
    [n, 1, xe],
    [e, 1, Oe],
    [e, 3, 3 * Oe],
    [t, 1, fe]
  ];
  function y(p, g, E) {
    const C = g < p;
    C && ([p, g] = [g, p]);
    const b = E && typeof E.range == "function" ? E : _(p, g, E), G = b ? b.range(p, +g + 1) : [];
    return C ? G.reverse() : G;
  }
  function _(p, g, E) {
    const C = Math.abs(g - p) / E, b = Bn(([, , M]) => M).right(s, C);
    if (b === s.length) return t.every(Ie(p / fe, g / fe, E));
    if (b === 0) return Yt.every(Math.max(Ie(p, g, E), 1));
    const [G, O] = s[C / s[b - 1][2] < s[b][2] / C ? b - 1 : b];
    return G.every(O);
  }
  return [y, _];
}
const [xr, wr] = br(kt, Nt, Vt, Tt, Ot, Wt);
function he(t) {
  if (0 <= t.y && t.y < 100) {
    var e = new Date(-1, t.m, t.d, t.H, t.M, t.S, t.L);
    return e.setFullYear(t.y), e;
  }
  return new Date(t.y, t.m, t.d, t.H, t.M, t.S, t.L);
}
function de(t) {
  if (0 <= t.y && t.y < 100) {
    var e = new Date(Date.UTC(-1, t.m, t.d, t.H, t.M, t.S, t.L));
    return e.setUTCFullYear(t.y), e;
  }
  return new Date(Date.UTC(t.y, t.m, t.d, t.H, t.M, t.S, t.L));
}
function Lt(t, e, n) {
  return { y: t, m: e, d: n, H: 0, M: 0, S: 0, L: 0 };
}
function Dr(t) {
  var e = t.dateTime, n = t.date, r = t.time, a = t.periods, i = t.days, s = t.shortDays, y = t.months, _ = t.shortMonths, p = At(a), g = It(a), E = At(i), C = It(i), b = At(s), G = It(s), O = At(y), M = It(y), I = At(_), V = It(_), W = {
    a: d,
    A: w,
    b: c,
    B: l,
    c: null,
    d: Re,
    e: Re,
    f: Gr,
    g: ra,
    G: ia,
    H: Br,
    I: Zr,
    j: qr,
    L: gn,
    m: Xr,
    M: jr,
    p: o,
    q: P,
    Q: qe,
    s: Ge,
    S: Qr,
    u: $r,
    U: Jr,
    V: Kr,
    w: ta,
    W: ea,
    x: null,
    X: null,
    y: na,
    Y: aa,
    Z: sa,
    "%": Ze
  }, Z = {
    a: z,
    A: R,
    b: K,
    B: X,
    c: null,
    d: Be,
    e: Be,
    f: ua,
    g: Ta,
    G: xa,
    H: oa,
    I: ca,
    j: la,
    L: kn,
    m: fa,
    M: ha,
    p: $,
    q: it,
    Q: qe,
    s: Ge,
    S: da,
    u: ma,
    U: ga,
    V: ya,
    w: ka,
    W: pa,
    x: null,
    X: null,
    y: va,
    Y: ba,
    Z: wa,
    "%": Ze
  }, Q = {
    a: F,
    A: S,
    b: v,
    B: U,
    c: u,
    d: ze,
    e: ze,
    f: Vr,
    g: Ve,
    G: Ne,
    H: Pe,
    I: Pe,
    j: Wr,
    L: Nr,
    m: Ir,
    M: Or,
    p: Y,
    q: Ar,
    Q: Pr,
    s: Rr,
    S: Hr,
    u: Fr,
    U: Yr,
    V: Ur,
    w: Sr,
    W: Er,
    x: m,
    X: T,
    y: Ve,
    Y: Ne,
    Z: Lr,
    "%": zr
  };
  W.x = D(n, W), W.X = D(r, W), W.c = D(e, W), Z.x = D(n, Z), Z.X = D(r, Z), Z.c = D(e, Z);
  function D(k, A) {
    return function(N) {
      var f = [], J = -1, L = 0, j = k.length, q, rt, st;
      for (N instanceof Date || (N = /* @__PURE__ */ new Date(+N)); ++J < j; )
        k.charCodeAt(J) === 37 && (f.push(k.slice(L, J)), (rt = He[q = k.charAt(++J)]) != null ? q = k.charAt(++J) : rt = q === "e" ? " " : "0", (st = A[q]) && (q = st(N, rt)), f.push(q), L = J + 1);
      return f.push(k.slice(L, J)), f.join("");
    };
  }
  function H(k, A) {
    return function(N) {
      var f = Lt(1900, void 0, 1), J = x(f, k, N += "", 0), L, j;
      if (J != N.length) return null;
      if ("Q" in f) return new Date(f.Q);
      if ("s" in f) return new Date(f.s * 1e3 + ("L" in f ? f.L : 0));
      if (A && !("Z" in f) && (f.Z = 0), "p" in f && (f.H = f.H % 12 + f.p * 12), f.m === void 0 && (f.m = "q" in f ? f.q : 0), "V" in f) {
        if (f.V < 1 || f.V > 53) return null;
        "w" in f || (f.w = 1), "Z" in f ? (L = de(Lt(f.y, 0, 1)), j = L.getUTCDay(), L = j > 4 || j === 0 ? Jt.ceil(L) : Jt(L), L = we.offset(L, (f.V - 1) * 7), f.y = L.getUTCFullYear(), f.m = L.getUTCMonth(), f.d = L.getUTCDate() + (f.w + 6) % 7) : (L = he(Lt(f.y, 0, 1)), j = L.getDay(), L = j > 4 || j === 0 ? Ht.ceil(L) : Ht(L), L = Tt.offset(L, (f.V - 1) * 7), f.y = L.getFullYear(), f.m = L.getMonth(), f.d = L.getDate() + (f.w + 6) % 7);
      } else ("W" in f || "U" in f) && ("w" in f || (f.w = "u" in f ? f.u % 7 : "W" in f ? 1 : 0), j = "Z" in f ? de(Lt(f.y, 0, 1)).getUTCDay() : he(Lt(f.y, 0, 1)).getDay(), f.m = 0, f.d = "W" in f ? (f.w + 6) % 7 + f.W * 7 - (j + 5) % 7 : f.w + f.U * 7 - (j + 6) % 7);
      return "Z" in f ? (f.H += f.Z / 100 | 0, f.M += f.Z % 100, de(f)) : he(f);
    };
  }
  function x(k, A, N, f) {
    for (var J = 0, L = A.length, j = N.length, q, rt; J < L; ) {
      if (f >= j) return -1;
      if (q = A.charCodeAt(J++), q === 37) {
        if (q = A.charAt(J++), rt = Q[q in He ? A.charAt(J++) : q], !rt || (f = rt(k, N, f)) < 0) return -1;
      } else if (q != N.charCodeAt(f++))
        return -1;
    }
    return f;
  }
  function Y(k, A, N) {
    var f = p.exec(A.slice(N));
    return f ? (k.p = g.get(f[0].toLowerCase()), N + f[0].length) : -1;
  }
  function F(k, A, N) {
    var f = b.exec(A.slice(N));
    return f ? (k.w = G.get(f[0].toLowerCase()), N + f[0].length) : -1;
  }
  function S(k, A, N) {
    var f = E.exec(A.slice(N));
    return f ? (k.w = C.get(f[0].toLowerCase()), N + f[0].length) : -1;
  }
  function v(k, A, N) {
    var f = I.exec(A.slice(N));
    return f ? (k.m = V.get(f[0].toLowerCase()), N + f[0].length) : -1;
  }
  function U(k, A, N) {
    var f = O.exec(A.slice(N));
    return f ? (k.m = M.get(f[0].toLowerCase()), N + f[0].length) : -1;
  }
  function u(k, A, N) {
    return x(k, e, A, N);
  }
  function m(k, A, N) {
    return x(k, n, A, N);
  }
  function T(k, A, N) {
    return x(k, r, A, N);
  }
  function d(k) {
    return s[k.getDay()];
  }
  function w(k) {
    return i[k.getDay()];
  }
  function c(k) {
    return _[k.getMonth()];
  }
  function l(k) {
    return y[k.getMonth()];
  }
  function o(k) {
    return a[+(k.getHours() >= 12)];
  }
  function P(k) {
    return 1 + ~~(k.getMonth() / 3);
  }
  function z(k) {
    return s[k.getUTCDay()];
  }
  function R(k) {
    return i[k.getUTCDay()];
  }
  function K(k) {
    return _[k.getUTCMonth()];
  }
  function X(k) {
    return y[k.getUTCMonth()];
  }
  function $(k) {
    return a[+(k.getUTCHours() >= 12)];
  }
  function it(k) {
    return 1 + ~~(k.getUTCMonth() / 3);
  }
  return {
    format: function(k) {
      var A = D(k += "", W);
      return A.toString = function() {
        return k;
      }, A;
    },
    parse: function(k) {
      var A = H(k += "", !1);
      return A.toString = function() {
        return k;
      }, A;
    },
    utcFormat: function(k) {
      var A = D(k += "", Z);
      return A.toString = function() {
        return k;
      }, A;
    },
    utcParse: function(k) {
      var A = H(k += "", !0);
      return A.toString = function() {
        return k;
      }, A;
    }
  };
}
var He = { "-": "", _: " ", 0: "0" }, nt = /^\s*\d+/, Cr = /^%/, Mr = /[\\^$*+?|[\]().{}]/g;
function B(t, e, n) {
  var r = t < 0 ? "-" : "", a = (r ? -t : t) + "", i = a.length;
  return r + (i < n ? new Array(n - i + 1).join(e) + a : a);
}
function _r(t) {
  return t.replace(Mr, "\\$&");
}
function At(t) {
  return new RegExp("^(?:" + t.map(_r).join("|") + ")", "i");
}
function It(t) {
  return new Map(t.map((e, n) => [e.toLowerCase(), n]));
}
function Sr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 1));
  return r ? (t.w = +r[0], n + r[0].length) : -1;
}
function Fr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 1));
  return r ? (t.u = +r[0], n + r[0].length) : -1;
}
function Yr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.U = +r[0], n + r[0].length) : -1;
}
function Ur(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.V = +r[0], n + r[0].length) : -1;
}
function Er(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.W = +r[0], n + r[0].length) : -1;
}
function Ne(t, e, n) {
  var r = nt.exec(e.slice(n, n + 4));
  return r ? (t.y = +r[0], n + r[0].length) : -1;
}
function Ve(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.y = +r[0] + (+r[0] > 68 ? 1900 : 2e3), n + r[0].length) : -1;
}
function Lr(t, e, n) {
  var r = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(n, n + 6));
  return r ? (t.Z = r[1] ? 0 : -(r[2] + (r[3] || "00")), n + r[0].length) : -1;
}
function Ar(t, e, n) {
  var r = nt.exec(e.slice(n, n + 1));
  return r ? (t.q = r[0] * 3 - 3, n + r[0].length) : -1;
}
function Ir(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.m = r[0] - 1, n + r[0].length) : -1;
}
function ze(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.d = +r[0], n + r[0].length) : -1;
}
function Wr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 3));
  return r ? (t.m = 0, t.d = +r[0], n + r[0].length) : -1;
}
function Pe(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.H = +r[0], n + r[0].length) : -1;
}
function Or(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.M = +r[0], n + r[0].length) : -1;
}
function Hr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.S = +r[0], n + r[0].length) : -1;
}
function Nr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 3));
  return r ? (t.L = +r[0], n + r[0].length) : -1;
}
function Vr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 6));
  return r ? (t.L = Math.floor(r[0] / 1e3), n + r[0].length) : -1;
}
function zr(t, e, n) {
  var r = Cr.exec(e.slice(n, n + 1));
  return r ? n + r[0].length : -1;
}
function Pr(t, e, n) {
  var r = nt.exec(e.slice(n));
  return r ? (t.Q = +r[0], n + r[0].length) : -1;
}
function Rr(t, e, n) {
  var r = nt.exec(e.slice(n));
  return r ? (t.s = +r[0], n + r[0].length) : -1;
}
function Re(t, e) {
  return B(t.getDate(), e, 2);
}
function Br(t, e) {
  return B(t.getHours(), e, 2);
}
function Zr(t, e) {
  return B(t.getHours() % 12 || 12, e, 2);
}
function qr(t, e) {
  return B(1 + Tt.count(kt(t), t), e, 3);
}
function gn(t, e) {
  return B(t.getMilliseconds(), e, 3);
}
function Gr(t, e) {
  return gn(t, e) + "000";
}
function Xr(t, e) {
  return B(t.getMonth() + 1, e, 2);
}
function jr(t, e) {
  return B(t.getMinutes(), e, 2);
}
function Qr(t, e) {
  return B(t.getSeconds(), e, 2);
}
function $r(t) {
  var e = t.getDay();
  return e === 0 ? 7 : e;
}
function Jr(t, e) {
  return B(Vt.count(kt(t) - 1, t), e, 2);
}
function yn(t) {
  var e = t.getDay();
  return e >= 4 || e === 0 ? bt(t) : bt.ceil(t);
}
function Kr(t, e) {
  return t = yn(t), B(bt.count(kt(t), t) + (kt(t).getDay() === 4), e, 2);
}
function ta(t) {
  return t.getDay();
}
function ea(t, e) {
  return B(Ht.count(kt(t) - 1, t), e, 2);
}
function na(t, e) {
  return B(t.getFullYear() % 100, e, 2);
}
function ra(t, e) {
  return t = yn(t), B(t.getFullYear() % 100, e, 2);
}
function aa(t, e) {
  return B(t.getFullYear() % 1e4, e, 4);
}
function ia(t, e) {
  var n = t.getDay();
  return t = n >= 4 || n === 0 ? bt(t) : bt.ceil(t), B(t.getFullYear() % 1e4, e, 4);
}
function sa(t) {
  var e = t.getTimezoneOffset();
  return (e > 0 ? "-" : (e *= -1, "+")) + B(e / 60 | 0, "0", 2) + B(e % 60, "0", 2);
}
function Be(t, e) {
  return B(t.getUTCDate(), e, 2);
}
function oa(t, e) {
  return B(t.getUTCHours(), e, 2);
}
function ca(t, e) {
  return B(t.getUTCHours() % 12 || 12, e, 2);
}
function la(t, e) {
  return B(1 + we.count(xt(t), t), e, 3);
}
function kn(t, e) {
  return B(t.getUTCMilliseconds(), e, 3);
}
function ua(t, e) {
  return kn(t, e) + "000";
}
function fa(t, e) {
  return B(t.getUTCMonth() + 1, e, 2);
}
function ha(t, e) {
  return B(t.getUTCMinutes(), e, 2);
}
function da(t, e) {
  return B(t.getUTCSeconds(), e, 2);
}
function ma(t) {
  var e = t.getUTCDay();
  return e === 0 ? 7 : e;
}
function ga(t, e) {
  return B(mn.count(xt(t) - 1, t), e, 2);
}
function pn(t) {
  var e = t.getUTCDay();
  return e >= 4 || e === 0 ? Ut(t) : Ut.ceil(t);
}
function ya(t, e) {
  return t = pn(t), B(Ut.count(xt(t), t) + (xt(t).getUTCDay() === 4), e, 2);
}
function ka(t) {
  return t.getUTCDay();
}
function pa(t, e) {
  return B(Jt.count(xt(t) - 1, t), e, 2);
}
function va(t, e) {
  return B(t.getUTCFullYear() % 100, e, 2);
}
function Ta(t, e) {
  return t = pn(t), B(t.getUTCFullYear() % 100, e, 2);
}
function ba(t, e) {
  return B(t.getUTCFullYear() % 1e4, e, 4);
}
function xa(t, e) {
  var n = t.getUTCDay();
  return t = n >= 4 || n === 0 ? Ut(t) : Ut.ceil(t), B(t.getUTCFullYear() % 1e4, e, 4);
}
function wa() {
  return "+0000";
}
function Ze() {
  return "%";
}
function qe(t) {
  return +t;
}
function Ge(t) {
  return Math.floor(+t / 1e3);
}
var Mt, Kt;
Da({
  dateTime: "%x, %X",
  date: "%-m/%-d/%Y",
  time: "%-I:%M:%S %p",
  periods: ["AM", "PM"],
  days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
  shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
  shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
});
function Da(t) {
  return Mt = Dr(t), Kt = Mt.format, Mt.parse, Mt.utcFormat, Mt.utcParse, Mt;
}
function Ca(t) {
  return new Date(t);
}
function Ma(t) {
  return t instanceof Date ? +t : +/* @__PURE__ */ new Date(+t);
}
function vn(t, e, n, r, a, i, s, y, _, p) {
  var g = Zn(), E = g.invert, C = g.domain, b = p(".%L"), G = p(":%S"), O = p("%I:%M"), M = p("%I %p"), I = p("%a %d"), V = p("%b %d"), W = p("%B"), Z = p("%Y");
  function Q(D) {
    return (_(D) < D ? b : y(D) < D ? G : s(D) < D ? O : i(D) < D ? M : r(D) < D ? a(D) < D ? I : V : n(D) < D ? W : Z)(D);
  }
  return g.invert = function(D) {
    return new Date(E(D));
  }, g.domain = function(D) {
    return arguments.length ? C(Array.from(D, Ma)) : C().map(Ca);
  }, g.ticks = function(D) {
    var H = C();
    return t(H[0], H[H.length - 1], D ?? 10);
  }, g.tickFormat = function(D, H) {
    return H == null ? Q : p(H);
  }, g.nice = function(D) {
    var H = C();
    return (!D || typeof D.range != "function") && (D = e(H[0], H[H.length - 1], D ?? 10)), D ? C(hr(H, D)) : g;
  }, g.copy = function() {
    return qn(g, vn(t, e, n, r, a, i, s, y, _, p));
  }, g;
}
function _a() {
  return Xn.apply(vn(xr, wr, kt, Nt, Vt, Tt, Ot, Wt, vt, Kt).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)]), arguments);
}
var Tn = { exports: {} };
(function(t, e) {
  (function(n, r) {
    t.exports = r();
  })(Te, function() {
    var n = "day";
    return function(r, a, i) {
      var s = function(p) {
        return p.add(4 - p.isoWeekday(), n);
      }, y = a.prototype;
      y.isoWeekYear = function() {
        return s(this).year();
      }, y.isoWeek = function(p) {
        if (!this.$utils().u(p)) return this.add(7 * (p - this.isoWeek()), n);
        var g, E, C, b, G = s(this), O = (g = this.isoWeekYear(), E = this.$u, C = (E ? i.utc : i)().year(g).startOf("year"), b = 4 - C.isoWeekday(), C.isoWeekday() > 4 && (b += 7), C.add(b, n));
        return G.diff(O, "week") + 1;
      }, y.isoWeekday = function(p) {
        return this.$utils().u(p) ? this.day() || 7 : this.day(this.day() % 7 ? p : p - 7);
      };
      var _ = y.startOf;
      y.startOf = function(p, g) {
        var E = this.$utils(), C = !!E.u(g) || g;
        return E.p(p) === "isoweek" ? C ? this.date(this.date() - (this.isoWeekday() - 1)).startOf("day") : this.date(this.date() - 1 - (this.isoWeekday() - 1) + 7).endOf("day") : _.bind(this)(p, g);
      };
    };
  });
})(Tn);
var Sa = Tn.exports;
const Fa = /* @__PURE__ */ be(Sa);
var bn = { exports: {} };
(function(t, e) {
  (function(n, r) {
    t.exports = r();
  })(Te, function() {
    var n = { LTS: "h:mm:ss A", LT: "h:mm A", L: "MM/DD/YYYY", LL: "MMMM D, YYYY", LLL: "MMMM D, YYYY h:mm A", LLLL: "dddd, MMMM D, YYYY h:mm A" }, r = /(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g, a = /\d/, i = /\d\d/, s = /\d\d?/, y = /\d*[^-_:/,()\s\d]+/, _ = {}, p = function(M) {
      return (M = +M) + (M > 68 ? 1900 : 2e3);
    }, g = function(M) {
      return function(I) {
        this[M] = +I;
      };
    }, E = [/[+-]\d\d:?(\d\d)?|Z/, function(M) {
      (this.zone || (this.zone = {})).offset = function(I) {
        if (!I || I === "Z") return 0;
        var V = I.match(/([+-]|\d\d)/g), W = 60 * V[1] + (+V[2] || 0);
        return W === 0 ? 0 : V[0] === "+" ? -W : W;
      }(M);
    }], C = function(M) {
      var I = _[M];
      return I && (I.indexOf ? I : I.s.concat(I.f));
    }, b = function(M, I) {
      var V, W = _.meridiem;
      if (W) {
        for (var Z = 1; Z <= 24; Z += 1) if (M.indexOf(W(Z, 0, I)) > -1) {
          V = Z > 12;
          break;
        }
      } else V = M === (I ? "pm" : "PM");
      return V;
    }, G = { A: [y, function(M) {
      this.afternoon = b(M, !1);
    }], a: [y, function(M) {
      this.afternoon = b(M, !0);
    }], Q: [a, function(M) {
      this.month = 3 * (M - 1) + 1;
    }], S: [a, function(M) {
      this.milliseconds = 100 * +M;
    }], SS: [i, function(M) {
      this.milliseconds = 10 * +M;
    }], SSS: [/\d{3}/, function(M) {
      this.milliseconds = +M;
    }], s: [s, g("seconds")], ss: [s, g("seconds")], m: [s, g("minutes")], mm: [s, g("minutes")], H: [s, g("hours")], h: [s, g("hours")], HH: [s, g("hours")], hh: [s, g("hours")], D: [s, g("day")], DD: [i, g("day")], Do: [y, function(M) {
      var I = _.ordinal, V = M.match(/\d+/);
      if (this.day = V[0], I) for (var W = 1; W <= 31; W += 1) I(W).replace(/\[|\]/g, "") === M && (this.day = W);
    }], w: [s, g("week")], ww: [i, g("week")], M: [s, g("month")], MM: [i, g("month")], MMM: [y, function(M) {
      var I = C("months"), V = (C("monthsShort") || I.map(function(W) {
        return W.slice(0, 3);
      })).indexOf(M) + 1;
      if (V < 1) throw new Error();
      this.month = V % 12 || V;
    }], MMMM: [y, function(M) {
      var I = C("months").indexOf(M) + 1;
      if (I < 1) throw new Error();
      this.month = I % 12 || I;
    }], Y: [/[+-]?\d+/, g("year")], YY: [i, function(M) {
      this.year = p(M);
    }], YYYY: [/\d{4}/, g("year")], Z: E, ZZ: E };
    function O(M) {
      var I, V;
      I = M, V = _ && _.formats;
      for (var W = (M = I.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, function(F, S, v) {
        var U = v && v.toUpperCase();
        return S || V[v] || n[v] || V[U].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, function(u, m, T) {
          return m || T.slice(1);
        });
      })).match(r), Z = W.length, Q = 0; Q < Z; Q += 1) {
        var D = W[Q], H = G[D], x = H && H[0], Y = H && H[1];
        W[Q] = Y ? { regex: x, parser: Y } : D.replace(/^\[|\]$/g, "");
      }
      return function(F) {
        for (var S = {}, v = 0, U = 0; v < Z; v += 1) {
          var u = W[v];
          if (typeof u == "string") U += u.length;
          else {
            var m = u.regex, T = u.parser, d = F.slice(U), w = m.exec(d)[0];
            T.call(S, w), F = F.replace(w, "");
          }
        }
        return function(c) {
          var l = c.afternoon;
          if (l !== void 0) {
            var o = c.hours;
            l ? o < 12 && (c.hours += 12) : o === 12 && (c.hours = 0), delete c.afternoon;
          }
        }(S), S;
      };
    }
    return function(M, I, V) {
      V.p.customParseFormat = !0, M && M.parseTwoDigitYear && (p = M.parseTwoDigitYear);
      var W = I.prototype, Z = W.parse;
      W.parse = function(Q) {
        var D = Q.date, H = Q.utc, x = Q.args;
        this.$u = H;
        var Y = x[1];
        if (typeof Y == "string") {
          var F = x[2] === !0, S = x[3] === !0, v = F || S, U = x[2];
          S && (U = x[2]), _ = this.$locale(), !F && U && (_ = V.Ls[U]), this.$d = function(d, w, c, l) {
            try {
              if (["x", "X"].indexOf(w) > -1) return new Date((w === "X" ? 1e3 : 1) * d);
              var o = O(w)(d), P = o.year, z = o.month, R = o.day, K = o.hours, X = o.minutes, $ = o.seconds, it = o.milliseconds, k = o.zone, A = o.week, N = /* @__PURE__ */ new Date(), f = R || (P || z ? 1 : N.getDate()), J = P || N.getFullYear(), L = 0;
              P && !z || (L = z > 0 ? z - 1 : N.getMonth());
              var j, q = K || 0, rt = X || 0, st = $ || 0, pt = it || 0;
              return k ? new Date(Date.UTC(J, L, f, q, rt, st, pt + 60 * k.offset * 1e3)) : c ? new Date(Date.UTC(J, L, f, q, rt, st, pt)) : (j = new Date(J, L, f, q, rt, st, pt), A && (j = l(j).week(A).toDate()), j);
            } catch {
              return /* @__PURE__ */ new Date("");
            }
          }(D, Y, H, V), this.init(), U && U !== !0 && (this.$L = this.locale(U).$L), v && D != this.format(Y) && (this.$d = /* @__PURE__ */ new Date("")), _ = {};
        } else if (Y instanceof Array) for (var u = Y.length, m = 1; m <= u; m += 1) {
          x[1] = Y[m - 1];
          var T = V.apply(this, x);
          if (T.isValid()) {
            this.$d = T.$d, this.$L = T.$L, this.init();
            break;
          }
          m === u && (this.$d = /* @__PURE__ */ new Date(""));
        }
        else Z.call(this, Q);
      };
    };
  });
})(bn);
var Ya = bn.exports;
const Ua = /* @__PURE__ */ be(Ya);
var xn = { exports: {} };
(function(t, e) {
  (function(n, r) {
    t.exports = r();
  })(Te, function() {
    return function(n, r) {
      var a = r.prototype, i = a.format;
      a.format = function(s) {
        var y = this, _ = this.$locale();
        if (!this.isValid()) return i.bind(this)(s);
        var p = this.$utils(), g = (s || "YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g, function(E) {
          switch (E) {
            case "Q":
              return Math.ceil((y.$M + 1) / 3);
            case "Do":
              return _.ordinal(y.$D);
            case "gggg":
              return y.weekYear();
            case "GGGG":
              return y.isoWeekYear();
            case "wo":
              return _.ordinal(y.week(), "W");
            case "w":
            case "ww":
              return p.s(y.week(), E === "w" ? 1 : 2, "0");
            case "W":
            case "WW":
              return p.s(y.isoWeek(), E === "W" ? 1 : 2, "0");
            case "k":
            case "kk":
              return p.s(String(y.$H === 0 ? 24 : y.$H), E === "k" ? 1 : 2, "0");
            case "X":
              return Math.floor(y.$d.getTime() / 1e3);
            case "x":
              return y.$d.getTime();
            case "z":
              return "[" + y.offsetName() + "]";
            case "zzz":
              return "[" + y.offsetName("long") + "]";
            default:
              return E;
          }
        });
        return i.bind(this)(g);
      };
    };
  });
})(xn);
var Ea = xn.exports;
const La = /* @__PURE__ */ be(Ea);
var ye = function() {
  var t = /* @__PURE__ */ h(function(U, u, m, T) {
    for (m = m || {}, T = U.length; T--; m[U[T]] = u) ;
    return m;
  }, "o"), e = [6, 8, 10, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33, 35, 36, 38, 40], n = [1, 26], r = [1, 27], a = [1, 28], i = [1, 29], s = [1, 30], y = [1, 31], _ = [1, 32], p = [1, 33], g = [1, 34], E = [1, 9], C = [1, 10], b = [1, 11], G = [1, 12], O = [1, 13], M = [1, 14], I = [1, 15], V = [1, 16], W = [1, 19], Z = [1, 20], Q = [1, 21], D = [1, 22], H = [1, 23], x = [1, 25], Y = [1, 35], F = {
    trace: /* @__PURE__ */ h(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, gantt: 4, document: 5, EOF: 6, line: 7, SPACE: 8, statement: 9, NL: 10, weekday: 11, weekday_monday: 12, weekday_tuesday: 13, weekday_wednesday: 14, weekday_thursday: 15, weekday_friday: 16, weekday_saturday: 17, weekday_sunday: 18, weekend: 19, weekend_friday: 20, weekend_saturday: 21, dateFormat: 22, inclusiveEndDates: 23, topAxis: 24, axisFormat: 25, tickInterval: 26, excludes: 27, includes: 28, todayMarker: 29, title: 30, acc_title: 31, acc_title_value: 32, acc_descr: 33, acc_descr_value: 34, acc_descr_multiline_value: 35, section: 36, clickStatement: 37, taskTxt: 38, taskData: 39, click: 40, callbackname: 41, callbackargs: 42, href: 43, clickStatementDebug: 44, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 4: "gantt", 6: "EOF", 8: "SPACE", 10: "NL", 12: "weekday_monday", 13: "weekday_tuesday", 14: "weekday_wednesday", 15: "weekday_thursday", 16: "weekday_friday", 17: "weekday_saturday", 18: "weekday_sunday", 20: "weekend_friday", 21: "weekend_saturday", 22: "dateFormat", 23: "inclusiveEndDates", 24: "topAxis", 25: "axisFormat", 26: "tickInterval", 27: "excludes", 28: "includes", 29: "todayMarker", 30: "title", 31: "acc_title", 32: "acc_title_value", 33: "acc_descr", 34: "acc_descr_value", 35: "acc_descr_multiline_value", 36: "section", 38: "taskTxt", 39: "taskData", 40: "click", 41: "callbackname", 42: "callbackargs", 43: "href" },
    productions_: [0, [3, 3], [5, 0], [5, 2], [7, 2], [7, 1], [7, 1], [7, 1], [11, 1], [11, 1], [11, 1], [11, 1], [11, 1], [11, 1], [11, 1], [19, 1], [19, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 2], [9, 2], [9, 1], [9, 1], [9, 1], [9, 2], [37, 2], [37, 3], [37, 3], [37, 4], [37, 3], [37, 4], [37, 2], [44, 2], [44, 3], [44, 3], [44, 4], [44, 3], [44, 4], [44, 2]],
    performAction: /* @__PURE__ */ h(function(u, m, T, d, w, c, l) {
      var o = c.length - 1;
      switch (w) {
        case 1:
          return c[o - 1];
        case 2:
          this.$ = [];
          break;
        case 3:
          c[o - 1].push(c[o]), this.$ = c[o - 1];
          break;
        case 4:
        case 5:
          this.$ = c[o];
          break;
        case 6:
        case 7:
          this.$ = [];
          break;
        case 8:
          d.setWeekday("monday");
          break;
        case 9:
          d.setWeekday("tuesday");
          break;
        case 10:
          d.setWeekday("wednesday");
          break;
        case 11:
          d.setWeekday("thursday");
          break;
        case 12:
          d.setWeekday("friday");
          break;
        case 13:
          d.setWeekday("saturday");
          break;
        case 14:
          d.setWeekday("sunday");
          break;
        case 15:
          d.setWeekend("friday");
          break;
        case 16:
          d.setWeekend("saturday");
          break;
        case 17:
          d.setDateFormat(c[o].substr(11)), this.$ = c[o].substr(11);
          break;
        case 18:
          d.enableInclusiveEndDates(), this.$ = c[o].substr(18);
          break;
        case 19:
          d.TopAxis(), this.$ = c[o].substr(8);
          break;
        case 20:
          d.setAxisFormat(c[o].substr(11)), this.$ = c[o].substr(11);
          break;
        case 21:
          d.setTickInterval(c[o].substr(13)), this.$ = c[o].substr(13);
          break;
        case 22:
          d.setExcludes(c[o].substr(9)), this.$ = c[o].substr(9);
          break;
        case 23:
          d.setIncludes(c[o].substr(9)), this.$ = c[o].substr(9);
          break;
        case 24:
          d.setTodayMarker(c[o].substr(12)), this.$ = c[o].substr(12);
          break;
        case 27:
          d.setDiagramTitle(c[o].substr(6)), this.$ = c[o].substr(6);
          break;
        case 28:
          this.$ = c[o].trim(), d.setAccTitle(this.$);
          break;
        case 29:
        case 30:
          this.$ = c[o].trim(), d.setAccDescription(this.$);
          break;
        case 31:
          d.addSection(c[o].substr(8)), this.$ = c[o].substr(8);
          break;
        case 33:
          d.addTask(c[o - 1], c[o]), this.$ = "task";
          break;
        case 34:
          this.$ = c[o - 1], d.setClickEvent(c[o - 1], c[o], null);
          break;
        case 35:
          this.$ = c[o - 2], d.setClickEvent(c[o - 2], c[o - 1], c[o]);
          break;
        case 36:
          this.$ = c[o - 2], d.setClickEvent(c[o - 2], c[o - 1], null), d.setLink(c[o - 2], c[o]);
          break;
        case 37:
          this.$ = c[o - 3], d.setClickEvent(c[o - 3], c[o - 2], c[o - 1]), d.setLink(c[o - 3], c[o]);
          break;
        case 38:
          this.$ = c[o - 2], d.setClickEvent(c[o - 2], c[o], null), d.setLink(c[o - 2], c[o - 1]);
          break;
        case 39:
          this.$ = c[o - 3], d.setClickEvent(c[o - 3], c[o - 1], c[o]), d.setLink(c[o - 3], c[o - 2]);
          break;
        case 40:
          this.$ = c[o - 1], d.setLink(c[o - 1], c[o]);
          break;
        case 41:
        case 47:
          this.$ = c[o - 1] + " " + c[o];
          break;
        case 42:
        case 43:
        case 45:
          this.$ = c[o - 2] + " " + c[o - 1] + " " + c[o];
          break;
        case 44:
        case 46:
          this.$ = c[o - 3] + " " + c[o - 2] + " " + c[o - 1] + " " + c[o];
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: [1, 2] }, { 1: [3] }, t(e, [2, 2], { 5: 3 }), { 6: [1, 4], 7: 5, 8: [1, 6], 9: 7, 10: [1, 8], 11: 17, 12: n, 13: r, 14: a, 15: i, 16: s, 17: y, 18: _, 19: 18, 20: p, 21: g, 22: E, 23: C, 24: b, 25: G, 26: O, 27: M, 28: I, 29: V, 30: W, 31: Z, 33: Q, 35: D, 36: H, 37: 24, 38: x, 40: Y }, t(e, [2, 7], { 1: [2, 1] }), t(e, [2, 3]), { 9: 36, 11: 17, 12: n, 13: r, 14: a, 15: i, 16: s, 17: y, 18: _, 19: 18, 20: p, 21: g, 22: E, 23: C, 24: b, 25: G, 26: O, 27: M, 28: I, 29: V, 30: W, 31: Z, 33: Q, 35: D, 36: H, 37: 24, 38: x, 40: Y }, t(e, [2, 5]), t(e, [2, 6]), t(e, [2, 17]), t(e, [2, 18]), t(e, [2, 19]), t(e, [2, 20]), t(e, [2, 21]), t(e, [2, 22]), t(e, [2, 23]), t(e, [2, 24]), t(e, [2, 25]), t(e, [2, 26]), t(e, [2, 27]), { 32: [1, 37] }, { 34: [1, 38] }, t(e, [2, 30]), t(e, [2, 31]), t(e, [2, 32]), { 39: [1, 39] }, t(e, [2, 8]), t(e, [2, 9]), t(e, [2, 10]), t(e, [2, 11]), t(e, [2, 12]), t(e, [2, 13]), t(e, [2, 14]), t(e, [2, 15]), t(e, [2, 16]), { 41: [1, 40], 43: [1, 41] }, t(e, [2, 4]), t(e, [2, 28]), t(e, [2, 29]), t(e, [2, 33]), t(e, [2, 34], { 42: [1, 42], 43: [1, 43] }), t(e, [2, 40], { 41: [1, 44] }), t(e, [2, 35], { 43: [1, 45] }), t(e, [2, 36]), t(e, [2, 38], { 42: [1, 46] }), t(e, [2, 37]), t(e, [2, 39])],
    defaultActions: {},
    parseError: /* @__PURE__ */ h(function(u, m) {
      if (m.recoverable)
        this.trace(u);
      else {
        var T = new Error(u);
        throw T.hash = m, T;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ h(function(u) {
      var m = this, T = [0], d = [], w = [null], c = [], l = this.table, o = "", P = 0, z = 0, R = 2, K = 1, X = c.slice.call(arguments, 1), $ = Object.create(this.lexer), it = { yy: {} };
      for (var k in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, k) && (it.yy[k] = this.yy[k]);
      $.setInput(u, it.yy), it.yy.lexer = $, it.yy.parser = this, typeof $.yylloc > "u" && ($.yylloc = {});
      var A = $.yylloc;
      c.push(A);
      var N = $.options && $.options.ranges;
      typeof it.yy.parseError == "function" ? this.parseError = it.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function f(ot) {
        T.length = T.length - 2 * ot, w.length = w.length - ot, c.length = c.length - ot;
      }
      h(f, "popStack");
      function J() {
        var ot;
        return ot = d.pop() || $.lex() || K, typeof ot != "number" && (ot instanceof Array && (d = ot, ot = d.pop()), ot = m.symbols_[ot] || ot), ot;
      }
      h(J, "lex");
      for (var L, j, q, rt, st = {}, pt, lt, Ae, Bt; ; ) {
        if (j = T[T.length - 1], this.defaultActions[j] ? q = this.defaultActions[j] : ((L === null || typeof L > "u") && (L = J()), q = l[j] && l[j][L]), typeof q > "u" || !q.length || !q[0]) {
          var ne = "";
          Bt = [];
          for (pt in l[j])
            this.terminals_[pt] && pt > R && Bt.push("'" + this.terminals_[pt] + "'");
          $.showPosition ? ne = "Parse error on line " + (P + 1) + `:
` + $.showPosition() + `
Expecting ` + Bt.join(", ") + ", got '" + (this.terminals_[L] || L) + "'" : ne = "Parse error on line " + (P + 1) + ": Unexpected " + (L == K ? "end of input" : "'" + (this.terminals_[L] || L) + "'"), this.parseError(ne, {
            text: $.match,
            token: this.terminals_[L] || L,
            line: $.yylineno,
            loc: A,
            expected: Bt
          });
        }
        if (q[0] instanceof Array && q.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + j + ", token: " + L);
        switch (q[0]) {
          case 1:
            T.push(L), w.push($.yytext), c.push($.yylloc), T.push(q[1]), L = null, z = $.yyleng, o = $.yytext, P = $.yylineno, A = $.yylloc;
            break;
          case 2:
            if (lt = this.productions_[q[1]][1], st.$ = w[w.length - lt], st._$ = {
              first_line: c[c.length - (lt || 1)].first_line,
              last_line: c[c.length - 1].last_line,
              first_column: c[c.length - (lt || 1)].first_column,
              last_column: c[c.length - 1].last_column
            }, N && (st._$.range = [
              c[c.length - (lt || 1)].range[0],
              c[c.length - 1].range[1]
            ]), rt = this.performAction.apply(st, [
              o,
              z,
              P,
              it.yy,
              q[1],
              w,
              c
            ].concat(X)), typeof rt < "u")
              return rt;
            lt && (T = T.slice(0, -1 * lt * 2), w = w.slice(0, -1 * lt), c = c.slice(0, -1 * lt)), T.push(this.productions_[q[1]][0]), w.push(st.$), c.push(st._$), Ae = l[T[T.length - 2]][T[T.length - 1]], T.push(Ae);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, S = /* @__PURE__ */ function() {
    var U = {
      EOF: 1,
      parseError: /* @__PURE__ */ h(function(m, T) {
        if (this.yy.parser)
          this.yy.parser.parseError(m, T);
        else
          throw new Error(m);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ h(function(u, m) {
        return this.yy = m || this.yy || {}, this._input = u, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ h(function() {
        var u = this._input[0];
        this.yytext += u, this.yyleng++, this.offset++, this.match += u, this.matched += u;
        var m = u.match(/(?:\r\n?|\n).*/g);
        return m ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), u;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ h(function(u) {
        var m = u.length, T = u.split(/(?:\r\n?|\n)/g);
        this._input = u + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - m), this.offset -= m;
        var d = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), T.length - 1 && (this.yylineno -= T.length - 1);
        var w = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: T ? (T.length === d.length ? this.yylloc.first_column : 0) + d[d.length - T.length].length - T[0].length : this.yylloc.first_column - m
        }, this.options.ranges && (this.yylloc.range = [w[0], w[0] + this.yyleng - m]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ h(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ h(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ h(function(u) {
        this.unput(this.match.slice(u));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ h(function() {
        var u = this.matched.substr(0, this.matched.length - this.match.length);
        return (u.length > 20 ? "..." : "") + u.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ h(function() {
        var u = this.match;
        return u.length < 20 && (u += this._input.substr(0, 20 - u.length)), (u.substr(0, 20) + (u.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ h(function() {
        var u = this.pastInput(), m = new Array(u.length + 1).join("-");
        return u + this.upcomingInput() + `
` + m + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ h(function(u, m) {
        var T, d, w;
        if (this.options.backtrack_lexer && (w = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (w.yylloc.range = this.yylloc.range.slice(0))), d = u[0].match(/(?:\r\n?|\n).*/g), d && (this.yylineno += d.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: d ? d[d.length - 1].length - d[d.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + u[0].length
        }, this.yytext += u[0], this.match += u[0], this.matches = u, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(u[0].length), this.matched += u[0], T = this.performAction.call(this, this.yy, this, m, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), T)
          return T;
        if (this._backtrack) {
          for (var c in w)
            this[c] = w[c];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ h(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var u, m, T, d;
        this._more || (this.yytext = "", this.match = "");
        for (var w = this._currentRules(), c = 0; c < w.length; c++)
          if (T = this._input.match(this.rules[w[c]]), T && (!m || T[0].length > m[0].length)) {
            if (m = T, d = c, this.options.backtrack_lexer) {
              if (u = this.test_match(T, w[c]), u !== !1)
                return u;
              if (this._backtrack) {
                m = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return m ? (u = this.test_match(m, w[d]), u !== !1 ? u : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ h(function() {
        var m = this.next();
        return m || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ h(function(m) {
        this.conditionStack.push(m);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ h(function() {
        var m = this.conditionStack.length - 1;
        return m > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ h(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ h(function(m) {
        return m = this.conditionStack.length - 1 - Math.abs(m || 0), m >= 0 ? this.conditionStack[m] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ h(function(m) {
        this.begin(m);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ h(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ h(function(m, T, d, w) {
        switch (d) {
          case 0:
            return this.begin("open_directive"), "open_directive";
          case 1:
            return this.begin("acc_title"), 31;
          case 2:
            return this.popState(), "acc_title_value";
          case 3:
            return this.begin("acc_descr"), 33;
          case 4:
            return this.popState(), "acc_descr_value";
          case 5:
            this.begin("acc_descr_multiline");
            break;
          case 6:
            this.popState();
            break;
          case 7:
            return "acc_descr_multiline_value";
          case 8:
            break;
          case 9:
            break;
          case 10:
            break;
          case 11:
            return 10;
          case 12:
            break;
          case 13:
            break;
          case 14:
            this.begin("href");
            break;
          case 15:
            this.popState();
            break;
          case 16:
            return 43;
          case 17:
            this.begin("callbackname");
            break;
          case 18:
            this.popState();
            break;
          case 19:
            this.popState(), this.begin("callbackargs");
            break;
          case 20:
            return 41;
          case 21:
            this.popState();
            break;
          case 22:
            return 42;
          case 23:
            this.begin("click");
            break;
          case 24:
            this.popState();
            break;
          case 25:
            return 40;
          case 26:
            return 4;
          case 27:
            return 22;
          case 28:
            return 23;
          case 29:
            return 24;
          case 30:
            return 25;
          case 31:
            return 26;
          case 32:
            return 28;
          case 33:
            return 27;
          case 34:
            return 29;
          case 35:
            return 12;
          case 36:
            return 13;
          case 37:
            return 14;
          case 38:
            return 15;
          case 39:
            return 16;
          case 40:
            return 17;
          case 41:
            return 18;
          case 42:
            return 20;
          case 43:
            return 21;
          case 44:
            return "date";
          case 45:
            return 30;
          case 46:
            return "accDescription";
          case 47:
            return 36;
          case 48:
            return 38;
          case 49:
            return 39;
          case 50:
            return ":";
          case 51:
            return 6;
          case 52:
            return "INVALID";
        }
      }, "anonymous"),
      rules: [/^(?:%%\{)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?:%%(?!\{)*[^\n]*)/i, /^(?:[^\}]%%*[^\n]*)/i, /^(?:%%*[^\n]*[\n]*)/i, /^(?:[\n]+)/i, /^(?:\s+)/i, /^(?:%[^\n]*)/i, /^(?:href[\s]+["])/i, /^(?:["])/i, /^(?:[^"]*)/i, /^(?:call[\s]+)/i, /^(?:\([\s]*\))/i, /^(?:\()/i, /^(?:[^(]*)/i, /^(?:\))/i, /^(?:[^)]*)/i, /^(?:click[\s]+)/i, /^(?:[\s\n])/i, /^(?:[^\s\n]*)/i, /^(?:gantt\b)/i, /^(?:dateFormat\s[^#\n;]+)/i, /^(?:inclusiveEndDates\b)/i, /^(?:topAxis\b)/i, /^(?:axisFormat\s[^#\n;]+)/i, /^(?:tickInterval\s[^#\n;]+)/i, /^(?:includes\s[^#\n;]+)/i, /^(?:excludes\s[^#\n;]+)/i, /^(?:todayMarker\s[^\n;]+)/i, /^(?:weekday\s+monday\b)/i, /^(?:weekday\s+tuesday\b)/i, /^(?:weekday\s+wednesday\b)/i, /^(?:weekday\s+thursday\b)/i, /^(?:weekday\s+friday\b)/i, /^(?:weekday\s+saturday\b)/i, /^(?:weekday\s+sunday\b)/i, /^(?:weekend\s+friday\b)/i, /^(?:weekend\s+saturday\b)/i, /^(?:\d\d\d\d-\d\d-\d\d\b)/i, /^(?:title\s[^\n]+)/i, /^(?:accDescription\s[^#\n;]+)/i, /^(?:section\s[^\n]+)/i, /^(?:[^:\n]+)/i, /^(?::[^#\n;]+)/i, /^(?::)/i, /^(?:$)/i, /^(?:.)/i],
      conditions: { acc_descr_multiline: { rules: [6, 7], inclusive: !1 }, acc_descr: { rules: [4], inclusive: !1 }, acc_title: { rules: [2], inclusive: !1 }, callbackargs: { rules: [21, 22], inclusive: !1 }, callbackname: { rules: [18, 19, 20], inclusive: !1 }, href: { rules: [15, 16], inclusive: !1 }, click: { rules: [24, 25], inclusive: !1 }, INITIAL: { rules: [0, 1, 3, 5, 8, 9, 10, 11, 12, 13, 14, 17, 23, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52], inclusive: !0 } }
    };
    return U;
  }();
  F.lexer = S;
  function v() {
    this.yy = {};
  }
  return h(v, "Parser"), v.prototype = F, F.Parser = v, new v();
}();
ye.parser = ye;
var Aa = ye;
at.extend(Fa);
at.extend(Ua);
at.extend(La);
var Xe = { friday: 5, saturday: 6 }, ut = "", De = "", Ce = void 0, Me = "", zt = [], Pt = [], _e = /* @__PURE__ */ new Map(), Se = [], te = [], Et = "", Fe = "", wn = ["active", "done", "crit", "milestone", "vert"], Ye = [], Rt = !1, Ue = !1, Ee = "sunday", ee = "saturday", ke = 0, Ia = /* @__PURE__ */ h(function() {
  Se = [], te = [], Et = "", Ye = [], Xt = 0, ve = void 0, jt = void 0, tt = [], ut = "", De = "", Fe = "", Ce = void 0, Me = "", zt = [], Pt = [], Rt = !1, Ue = !1, ke = 0, _e = /* @__PURE__ */ new Map(), Pn(), Ee = "sunday", ee = "saturday";
}, "clear"), Wa = /* @__PURE__ */ h(function(t) {
  De = t;
}, "setAxisFormat"), Oa = /* @__PURE__ */ h(function() {
  return De;
}, "getAxisFormat"), Ha = /* @__PURE__ */ h(function(t) {
  Ce = t;
}, "setTickInterval"), Na = /* @__PURE__ */ h(function() {
  return Ce;
}, "getTickInterval"), Va = /* @__PURE__ */ h(function(t) {
  Me = t;
}, "setTodayMarker"), za = /* @__PURE__ */ h(function() {
  return Me;
}, "getTodayMarker"), Pa = /* @__PURE__ */ h(function(t) {
  ut = t;
}, "setDateFormat"), Ra = /* @__PURE__ */ h(function() {
  Rt = !0;
}, "enableInclusiveEndDates"), Ba = /* @__PURE__ */ h(function() {
  return Rt;
}, "endDatesAreInclusive"), Za = /* @__PURE__ */ h(function() {
  Ue = !0;
}, "enableTopAxis"), qa = /* @__PURE__ */ h(function() {
  return Ue;
}, "topAxisEnabled"), Ga = /* @__PURE__ */ h(function(t) {
  Fe = t;
}, "setDisplayMode"), Xa = /* @__PURE__ */ h(function() {
  return Fe;
}, "getDisplayMode"), ja = /* @__PURE__ */ h(function() {
  return ut;
}, "getDateFormat"), Qa = /* @__PURE__ */ h(function(t) {
  zt = t.toLowerCase().split(/[\s,]+/);
}, "setIncludes"), $a = /* @__PURE__ */ h(function() {
  return zt;
}, "getIncludes"), Ja = /* @__PURE__ */ h(function(t) {
  Pt = t.toLowerCase().split(/[\s,]+/);
}, "setExcludes"), Ka = /* @__PURE__ */ h(function() {
  return Pt;
}, "getExcludes"), ti = /* @__PURE__ */ h(function() {
  return _e;
}, "getLinks"), ei = /* @__PURE__ */ h(function(t) {
  Et = t, Se.push(t);
}, "addSection"), ni = /* @__PURE__ */ h(function() {
  return Se;
}, "getSections"), ri = /* @__PURE__ */ h(function() {
  let t = je();
  const e = 10;
  let n = 0;
  for (; !t && n < e; )
    t = je(), n++;
  return te = tt, te;
}, "getTasks"), Dn = /* @__PURE__ */ h(function(t, e, n, r) {
  const a = t.format(e.trim()), i = t.format("YYYY-MM-DD");
  return r.includes(a) || r.includes(i) ? !1 : n.includes("weekends") && (t.isoWeekday() === Xe[ee] || t.isoWeekday() === Xe[ee] + 1) || n.includes(t.format("dddd").toLowerCase()) ? !0 : n.includes(a) || n.includes(i);
}, "isInvalidDate"), ai = /* @__PURE__ */ h(function(t) {
  Ee = t;
}, "setWeekday"), ii = /* @__PURE__ */ h(function() {
  return Ee;
}, "getWeekday"), si = /* @__PURE__ */ h(function(t) {
  ee = t;
}, "setWeekend"), Cn = /* @__PURE__ */ h(function(t, e, n, r) {
  if (!n.length || t.manualEndTime)
    return;
  let a;
  t.startTime instanceof Date ? a = at(t.startTime) : a = at(t.startTime, e, !0), a = a.add(1, "d");
  let i;
  t.endTime instanceof Date ? i = at(t.endTime) : i = at(t.endTime, e, !0);
  const [s, y] = oi(
    a,
    i,
    e,
    n,
    r
  );
  t.endTime = s.toDate(), t.renderEndTime = y;
}, "checkTaskDates"), oi = /* @__PURE__ */ h(function(t, e, n, r, a) {
  let i = !1, s = null;
  for (; t <= e; )
    i || (s = e.toDate()), i = Dn(t, n, r, a), i && (e = e.add(1, "d")), t = t.add(1, "d");
  return [e, s];
}, "fixTaskDates"), pe = /* @__PURE__ */ h(function(t, e, n) {
  n = n.trim();
  const a = /^after\s+(?<ids>[\d\w- ]+)/.exec(n);
  if (a !== null) {
    let s = null;
    for (const _ of a.groups.ids.split(" ")) {
      let p = Ct(_);
      p !== void 0 && (!s || p.endTime > s.endTime) && (s = p);
    }
    if (s)
      return s.endTime;
    const y = /* @__PURE__ */ new Date();
    return y.setHours(0, 0, 0, 0), y;
  }
  let i = at(n, e.trim(), !0);
  if (i.isValid())
    return i.toDate();
  {
    Qt.debug("Invalid date:" + n), Qt.debug("With date format:" + e.trim());
    const s = new Date(n);
    if (s === void 0 || isNaN(s.getTime()) || // WebKit browsers can mis-parse invalid dates to be ridiculously
    // huge numbers, e.g. new Date('202304') gets parsed as January 1, 202304.
    // This can cause virtually infinite loops while rendering, so for the
    // purposes of Gantt charts we'll just treat any date beyond 10,000 AD/BC as
    // invalid.
    s.getFullYear() < -1e4 || s.getFullYear() > 1e4)
      throw new Error("Invalid date:" + n);
    return s;
  }
}, "getStartDate"), Mn = /* @__PURE__ */ h(function(t) {
  const e = /^(\d+(?:\.\d+)?)([Mdhmswy]|ms)$/.exec(t.trim());
  return e !== null ? [Number.parseFloat(e[1]), e[2]] : [NaN, "ms"];
}, "parseDuration"), _n = /* @__PURE__ */ h(function(t, e, n, r = !1) {
  n = n.trim();
  const i = /^until\s+(?<ids>[\d\w- ]+)/.exec(n);
  if (i !== null) {
    let g = null;
    for (const C of i.groups.ids.split(" ")) {
      let b = Ct(C);
      b !== void 0 && (!g || b.startTime < g.startTime) && (g = b);
    }
    if (g)
      return g.startTime;
    const E = /* @__PURE__ */ new Date();
    return E.setHours(0, 0, 0, 0), E;
  }
  let s = at(n, e.trim(), !0);
  if (s.isValid())
    return r && (s = s.add(1, "d")), s.toDate();
  let y = at(t);
  const [_, p] = Mn(n);
  if (!Number.isNaN(_)) {
    const g = y.add(_, p);
    g.isValid() && (y = g);
  }
  return y.toDate();
}, "getEndDate"), Xt = 0, Ft = /* @__PURE__ */ h(function(t) {
  return t === void 0 ? (Xt = Xt + 1, "task" + Xt) : t;
}, "parseId"), ci = /* @__PURE__ */ h(function(t, e) {
  let n;
  e.substr(0, 1) === ":" ? n = e.substr(1, e.length) : n = e;
  const r = n.split(","), a = {};
  Le(r, a, wn);
  for (let s = 0; s < r.length; s++)
    r[s] = r[s].trim();
  let i = "";
  switch (r.length) {
    case 1:
      a.id = Ft(), a.startTime = t.endTime, i = r[0];
      break;
    case 2:
      a.id = Ft(), a.startTime = pe(void 0, ut, r[0]), i = r[1];
      break;
    case 3:
      a.id = Ft(r[0]), a.startTime = pe(void 0, ut, r[1]), i = r[2];
      break;
  }
  return i && (a.endTime = _n(a.startTime, ut, i, Rt), a.manualEndTime = at(i, "YYYY-MM-DD", !0).isValid(), Cn(a, ut, Pt, zt)), a;
}, "compileData"), li = /* @__PURE__ */ h(function(t, e) {
  let n;
  e.substr(0, 1) === ":" ? n = e.substr(1, e.length) : n = e;
  const r = n.split(","), a = {};
  Le(r, a, wn);
  for (let i = 0; i < r.length; i++)
    r[i] = r[i].trim();
  switch (r.length) {
    case 1:
      a.id = Ft(), a.startTime = {
        type: "prevTaskEnd",
        id: t
      }, a.endTime = {
        data: r[0]
      };
      break;
    case 2:
      a.id = Ft(), a.startTime = {
        type: "getStartDate",
        startData: r[0]
      }, a.endTime = {
        data: r[1]
      };
      break;
    case 3:
      a.id = Ft(r[0]), a.startTime = {
        type: "getStartDate",
        startData: r[1]
      }, a.endTime = {
        data: r[2]
      };
      break;
  }
  return a;
}, "parseData"), ve, jt, tt = [], Sn = {}, ui = /* @__PURE__ */ h(function(t, e) {
  const n = {
    section: Et,
    type: Et,
    processed: !1,
    manualEndTime: !1,
    renderEndTime: null,
    raw: { data: e },
    task: t,
    classes: []
  }, r = li(jt, e);
  n.raw.startTime = r.startTime, n.raw.endTime = r.endTime, n.id = r.id, n.prevTaskId = jt, n.active = r.active, n.done = r.done, n.crit = r.crit, n.milestone = r.milestone, n.vert = r.vert, n.order = ke, ke++;
  const a = tt.push(n);
  jt = n.id, Sn[n.id] = a - 1;
}, "addTask"), Ct = /* @__PURE__ */ h(function(t) {
  const e = Sn[t];
  return tt[e];
}, "findTaskById"), fi = /* @__PURE__ */ h(function(t, e) {
  const n = {
    section: Et,
    type: Et,
    description: t,
    task: t,
    classes: []
  }, r = ci(ve, e);
  n.startTime = r.startTime, n.endTime = r.endTime, n.id = r.id, n.active = r.active, n.done = r.done, n.crit = r.crit, n.milestone = r.milestone, n.vert = r.vert, ve = n, te.push(n);
}, "addTaskOrg"), je = /* @__PURE__ */ h(function() {
  const t = /* @__PURE__ */ h(function(n) {
    const r = tt[n];
    let a = "";
    switch (tt[n].raw.startTime.type) {
      case "prevTaskEnd": {
        const i = Ct(r.prevTaskId);
        r.startTime = i.endTime;
        break;
      }
      case "getStartDate":
        a = pe(void 0, ut, tt[n].raw.startTime.startData), a && (tt[n].startTime = a);
        break;
    }
    return tt[n].startTime && (tt[n].endTime = _n(
      tt[n].startTime,
      ut,
      tt[n].raw.endTime.data,
      Rt
    ), tt[n].endTime && (tt[n].processed = !0, tt[n].manualEndTime = at(
      tt[n].raw.endTime.data,
      "YYYY-MM-DD",
      !0
    ).isValid(), Cn(tt[n], ut, Pt, zt))), tt[n].processed;
  }, "compileTask");
  let e = !0;
  for (const [n, r] of tt.entries())
    t(n), e = e && r.processed;
  return e;
}, "compileTasks"), hi = /* @__PURE__ */ h(function(t, e) {
  let n = e;
  _t().securityLevel !== "loose" && (n = zn(e)), t.split(",").forEach(function(r) {
    Ct(r) !== void 0 && (Yn(r, () => {
      window.open(n, "_self");
    }), _e.set(r, n));
  }), Fn(t, "clickable");
}, "setLink"), Fn = /* @__PURE__ */ h(function(t, e) {
  t.split(",").forEach(function(n) {
    let r = Ct(n);
    r !== void 0 && r.classes.push(e);
  });
}, "setClass"), di = /* @__PURE__ */ h(function(t, e, n) {
  if (_t().securityLevel !== "loose" || e === void 0)
    return;
  let r = [];
  if (typeof n == "string") {
    r = n.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
    for (let i = 0; i < r.length; i++) {
      let s = r[i].trim();
      s.startsWith('"') && s.endsWith('"') && (s = s.substr(1, s.length - 2)), r[i] = s;
    }
  }
  r.length === 0 && r.push(t), Ct(t) !== void 0 && Yn(t, () => {
    Rn.runFunc(e, ...r);
  });
}, "setClickFun"), Yn = /* @__PURE__ */ h(function(t, e) {
  Ye.push(
    function() {
      const n = document.querySelector(`[id="${t}"]`);
      n !== null && n.addEventListener("click", function() {
        e();
      });
    },
    function() {
      const n = document.querySelector(`[id="${t}-text"]`);
      n !== null && n.addEventListener("click", function() {
        e();
      });
    }
  );
}, "pushFun"), mi = /* @__PURE__ */ h(function(t, e, n) {
  t.split(",").forEach(function(r) {
    di(r, e, n);
  }), Fn(t, "clickable");
}, "setClickEvent"), gi = /* @__PURE__ */ h(function(t) {
  Ye.forEach(function(e) {
    e(t);
  });
}, "bindFunctions"), yi = {
  getConfig: /* @__PURE__ */ h(() => _t().gantt, "getConfig"),
  clear: Ia,
  setDateFormat: Pa,
  getDateFormat: ja,
  enableInclusiveEndDates: Ra,
  endDatesAreInclusive: Ba,
  enableTopAxis: Za,
  topAxisEnabled: qa,
  setAxisFormat: Wa,
  getAxisFormat: Oa,
  setTickInterval: Ha,
  getTickInterval: Na,
  setTodayMarker: Va,
  getTodayMarker: za,
  setAccTitle: Hn,
  getAccTitle: On,
  setDiagramTitle: Wn,
  getDiagramTitle: In,
  setDisplayMode: Ga,
  getDisplayMode: Xa,
  setAccDescription: An,
  getAccDescription: Ln,
  addSection: ei,
  getSections: ni,
  getTasks: ri,
  addTask: ui,
  findTaskById: Ct,
  addTaskOrg: fi,
  setIncludes: Qa,
  getIncludes: $a,
  setExcludes: Ja,
  getExcludes: Ka,
  setClickEvent: mi,
  setLink: hi,
  getLinks: ti,
  bindFunctions: gi,
  parseDuration: Mn,
  isInvalidDate: Dn,
  setWeekday: ai,
  getWeekday: ii,
  setWeekend: si
};
function Le(t, e, n) {
  let r = !0;
  for (; r; )
    r = !1, n.forEach(function(a) {
      const i = "^\\s*" + a + "\\s*$", s = new RegExp(i);
      t[0].match(s) && (e[a] = !0, t.shift(1), r = !0);
    });
}
h(Le, "getTaskTags");
var ki = /* @__PURE__ */ h(function() {
  Qt.debug("Something is calling, setConf, remove the call");
}, "setConf"), Qe = {
  monday: Ht,
  tuesday: un,
  wednesday: fn,
  thursday: bt,
  friday: hn,
  saturday: dn,
  sunday: Vt
}, pi = /* @__PURE__ */ h((t, e) => {
  let n = [...t].map(() => -1 / 0), r = [...t].sort((i, s) => i.startTime - s.startTime || i.order - s.order), a = 0;
  for (const i of r)
    for (let s = 0; s < n.length; s++)
      if (i.startTime >= n[s]) {
        n[s] = i.endTime, i.order = s + e, s > a && (a = s);
        break;
      }
  return a;
}, "getMaxIntersections"), ht, vi = /* @__PURE__ */ h(function(t, e, n, r) {
  const a = _t().gantt, i = _t().securityLevel;
  let s;
  i === "sandbox" && (s = Zt("#i" + e));
  const y = i === "sandbox" ? Zt(s.nodes()[0].contentDocument.body) : Zt("body"), _ = i === "sandbox" ? s.nodes()[0].contentDocument : document, p = _.getElementById(e);
  ht = p.parentElement.offsetWidth, ht === void 0 && (ht = 1200), a.useWidth !== void 0 && (ht = a.useWidth);
  const g = r.db.getTasks();
  let E = [];
  for (const x of g)
    E.push(x.type);
  E = H(E);
  const C = {};
  let b = 2 * a.topPadding;
  if (r.db.getDisplayMode() === "compact" || a.displayMode === "compact") {
    const x = {};
    for (const F of g)
      x[F.section] === void 0 ? x[F.section] = [F] : x[F.section].push(F);
    let Y = 0;
    for (const F of Object.keys(x)) {
      const S = pi(x[F], Y) + 1;
      Y += S, b += S * (a.barHeight + a.barGap), C[F] = S;
    }
  } else {
    b += g.length * (a.barHeight + a.barGap);
    for (const x of E)
      C[x] = g.filter((Y) => Y.type === x).length;
  }
  p.setAttribute("viewBox", "0 0 " + ht + " " + b);
  const G = y.select(`[id="${e}"]`), O = _a().domain([
    Qn(g, function(x) {
      return x.startTime;
    }),
    jn(g, function(x) {
      return x.endTime;
    })
  ]).rangeRound([0, ht - a.leftPadding - a.rightPadding]);
  function M(x, Y) {
    const F = x.startTime, S = Y.startTime;
    let v = 0;
    return F > S ? v = 1 : F < S && (v = -1), v;
  }
  h(M, "taskCompare"), g.sort(M), I(g, ht, b), Nn(G, b, ht, a.useMaxWidth), G.append("text").text(r.db.getDiagramTitle()).attr("x", ht / 2).attr("y", a.titleTopMargin).attr("class", "titleText");
  function I(x, Y, F) {
    const S = a.barHeight, v = S + a.barGap, U = a.topPadding, u = a.leftPadding, m = Gn().domain([0, E.length]).range(["#00B9FA", "#F95002"]).interpolate(fr);
    W(
      v,
      U,
      u,
      Y,
      F,
      x,
      r.db.getExcludes(),
      r.db.getIncludes()
    ), Z(u, U, Y, F), V(x, v, U, u, S, m, Y), Q(v, U), D(u, U, Y, F);
  }
  h(I, "makeGantt");
  function V(x, Y, F, S, v, U, u) {
    x.sort((l, o) => l.vert === o.vert ? 0 : l.vert ? 1 : -1);
    const T = [...new Set(x.map((l) => l.order))].map((l) => x.find((o) => o.order === l));
    G.append("g").selectAll("rect").data(T).enter().append("rect").attr("x", 0).attr("y", function(l, o) {
      return o = l.order, o * Y + F - 2;
    }).attr("width", function() {
      return u - a.rightPadding / 2;
    }).attr("height", Y).attr("class", function(l) {
      for (const [o, P] of E.entries())
        if (l.type === P)
          return "section section" + o % a.numberSectionStyles;
      return "section section0";
    }).enter();
    const d = G.append("g").selectAll("rect").data(x).enter(), w = r.db.getLinks();
    if (d.append("rect").attr("id", function(l) {
      return l.id;
    }).attr("rx", 3).attr("ry", 3).attr("x", function(l) {
      return l.milestone ? O(l.startTime) + S + 0.5 * (O(l.endTime) - O(l.startTime)) - 0.5 * v : O(l.startTime) + S;
    }).attr("y", function(l, o) {
      return o = l.order, l.vert ? a.gridLineStartPadding : o * Y + F;
    }).attr("width", function(l) {
      return l.milestone ? v : l.vert ? 0.08 * v : O(l.renderEndTime || l.endTime) - O(l.startTime);
    }).attr("height", function(l) {
      return l.vert ? g.length * (a.barHeight + a.barGap) + a.barHeight * 2 : v;
    }).attr("transform-origin", function(l, o) {
      return o = l.order, (O(l.startTime) + S + 0.5 * (O(l.endTime) - O(l.startTime))).toString() + "px " + (o * Y + F + 0.5 * v).toString() + "px";
    }).attr("class", function(l) {
      const o = "task";
      let P = "";
      l.classes.length > 0 && (P = l.classes.join(" "));
      let z = 0;
      for (const [K, X] of E.entries())
        l.type === X && (z = K % a.numberSectionStyles);
      let R = "";
      return l.active ? l.crit ? R += " activeCrit" : R = " active" : l.done ? l.crit ? R = " doneCrit" : R = " done" : l.crit && (R += " crit"), R.length === 0 && (R = " task"), l.milestone && (R = " milestone " + R), l.vert && (R = " vert " + R), R += z, R += " " + P, o + R;
    }), d.append("text").attr("id", function(l) {
      return l.id + "-text";
    }).text(function(l) {
      return l.task;
    }).attr("font-size", a.fontSize).attr("x", function(l) {
      let o = O(l.startTime), P = O(l.renderEndTime || l.endTime);
      if (l.milestone && (o += 0.5 * (O(l.endTime) - O(l.startTime)) - 0.5 * v, P = o + v), l.vert)
        return O(l.startTime) + S;
      const z = this.getBBox().width;
      return z > P - o ? P + z + 1.5 * a.leftPadding > u ? o + S - 5 : P + S + 5 : (P - o) / 2 + o + S;
    }).attr("y", function(l, o) {
      return l.vert ? a.gridLineStartPadding + g.length * (a.barHeight + a.barGap) + 60 : (o = l.order, o * Y + a.barHeight / 2 + (a.fontSize / 2 - 2) + F);
    }).attr("text-height", v).attr("class", function(l) {
      const o = O(l.startTime);
      let P = O(l.endTime);
      l.milestone && (P = o + v);
      const z = this.getBBox().width;
      let R = "";
      l.classes.length > 0 && (R = l.classes.join(" "));
      let K = 0;
      for (const [$, it] of E.entries())
        l.type === it && (K = $ % a.numberSectionStyles);
      let X = "";
      return l.active && (l.crit ? X = "activeCritText" + K : X = "activeText" + K), l.done ? l.crit ? X = X + " doneCritText" + K : X = X + " doneText" + K : l.crit && (X = X + " critText" + K), l.milestone && (X += " milestoneText"), l.vert && (X += " vertText"), z > P - o ? P + z + 1.5 * a.leftPadding > u ? R + " taskTextOutsideLeft taskTextOutside" + K + " " + X : R + " taskTextOutsideRight taskTextOutside" + K + " " + X + " width-" + z : R + " taskText taskText" + K + " " + X + " width-" + z;
    }), _t().securityLevel === "sandbox") {
      let l;
      l = Zt("#i" + e);
      const o = l.nodes()[0].contentDocument;
      d.filter(function(P) {
        return w.has(P.id);
      }).each(function(P) {
        var z = o.querySelector("#" + P.id), R = o.querySelector("#" + P.id + "-text");
        const K = z.parentNode;
        var X = o.createElement("a");
        X.setAttribute("xlink:href", w.get(P.id)), X.setAttribute("target", "_top"), K.appendChild(X), X.appendChild(z), X.appendChild(R);
      });
    }
  }
  h(V, "drawRects");
  function W(x, Y, F, S, v, U, u, m) {
    if (u.length === 0 && m.length === 0)
      return;
    let T, d;
    for (const { startTime: z, endTime: R } of U)
      (T === void 0 || z < T) && (T = z), (d === void 0 || R > d) && (d = R);
    if (!T || !d)
      return;
    if (at(d).diff(at(T), "year") > 5) {
      Qt.warn(
        "The difference between the min and max time is more than 5 years. This will cause performance issues. Skipping drawing exclude days."
      );
      return;
    }
    const w = r.db.getDateFormat(), c = [];
    let l = null, o = at(T);
    for (; o.valueOf() <= d; )
      r.db.isInvalidDate(o, w, u, m) ? l ? l.end = o : l = {
        start: o,
        end: o
      } : l && (c.push(l), l = null), o = o.add(1, "d");
    G.append("g").selectAll("rect").data(c).enter().append("rect").attr("id", (z) => "exclude-" + z.start.format("YYYY-MM-DD")).attr("x", (z) => O(z.start.startOf("day")) + F).attr("y", a.gridLineStartPadding).attr("width", (z) => O(z.end.endOf("day")) - O(z.start.startOf("day"))).attr("height", v - Y - a.gridLineStartPadding).attr("transform-origin", function(z, R) {
      return (O(z.start) + F + 0.5 * (O(z.end) - O(z.start))).toString() + "px " + (R * x + 0.5 * v).toString() + "px";
    }).attr("class", "exclude-range");
  }
  h(W, "drawExcludeDays");
  function Z(x, Y, F, S) {
    const v = r.db.getDateFormat(), U = r.db.getAxisFormat();
    let u;
    U ? u = U : v === "D" ? u = "%d" : u = a.axisFormat ?? "%Y-%m-%d";
    let m = ar(O).tickSize(-S + Y + a.gridLineStartPadding).tickFormat(Kt(u));
    const d = /^([1-9]\d*)(millisecond|second|minute|hour|day|week|month)$/.exec(
      r.db.getTickInterval() || a.tickInterval
    );
    if (d !== null) {
      const w = d[1], c = d[2], l = r.db.getWeekday() || a.weekday;
      switch (c) {
        case "millisecond":
          m.ticks(Yt.every(w));
          break;
        case "second":
          m.ticks(vt.every(w));
          break;
        case "minute":
          m.ticks(Wt.every(w));
          break;
        case "hour":
          m.ticks(Ot.every(w));
          break;
        case "day":
          m.ticks(Tt.every(w));
          break;
        case "week":
          m.ticks(Qe[l].every(w));
          break;
        case "month":
          m.ticks(Nt.every(w));
          break;
      }
    }
    if (G.append("g").attr("class", "grid").attr("transform", "translate(" + x + ", " + (S - 50) + ")").call(m).selectAll("text").style("text-anchor", "middle").attr("fill", "#000").attr("stroke", "none").attr("font-size", 10).attr("dy", "1em"), r.db.topAxisEnabled() || a.topAxis) {
      let w = rr(O).tickSize(-S + Y + a.gridLineStartPadding).tickFormat(Kt(u));
      if (d !== null) {
        const c = d[1], l = d[2], o = r.db.getWeekday() || a.weekday;
        switch (l) {
          case "millisecond":
            w.ticks(Yt.every(c));
            break;
          case "second":
            w.ticks(vt.every(c));
            break;
          case "minute":
            w.ticks(Wt.every(c));
            break;
          case "hour":
            w.ticks(Ot.every(c));
            break;
          case "day":
            w.ticks(Tt.every(c));
            break;
          case "week":
            w.ticks(Qe[o].every(c));
            break;
          case "month":
            w.ticks(Nt.every(c));
            break;
        }
      }
      G.append("g").attr("class", "grid").attr("transform", "translate(" + x + ", " + Y + ")").call(w).selectAll("text").style("text-anchor", "middle").attr("fill", "#000").attr("stroke", "none").attr("font-size", 10);
    }
  }
  h(Z, "makeGrid");
  function Q(x, Y) {
    let F = 0;
    const S = Object.keys(C).map((v) => [v, C[v]]);
    G.append("g").selectAll("text").data(S).enter().append(function(v) {
      const U = v[0].split(Vn.lineBreakRegex), u = -(U.length - 1) / 2, m = _.createElementNS("http://www.w3.org/2000/svg", "text");
      m.setAttribute("dy", u + "em");
      for (const [T, d] of U.entries()) {
        const w = _.createElementNS("http://www.w3.org/2000/svg", "tspan");
        w.setAttribute("alignment-baseline", "central"), w.setAttribute("x", "10"), T > 0 && w.setAttribute("dy", "1em"), w.textContent = d, m.appendChild(w);
      }
      return m;
    }).attr("x", 10).attr("y", function(v, U) {
      if (U > 0)
        for (let u = 0; u < U; u++)
          return F += S[U - 1][1], v[1] * x / 2 + F * x + Y;
      else
        return v[1] * x / 2 + Y;
    }).attr("font-size", a.sectionFontSize).attr("class", function(v) {
      for (const [U, u] of E.entries())
        if (v[0] === u)
          return "sectionTitle sectionTitle" + U % a.numberSectionStyles;
      return "sectionTitle";
    });
  }
  h(Q, "vertLabels");
  function D(x, Y, F, S) {
    const v = r.db.getTodayMarker();
    if (v === "off")
      return;
    const U = G.append("g").attr("class", "today"), u = /* @__PURE__ */ new Date(), m = U.append("line");
    m.attr("x1", O(u) + x).attr("x2", O(u) + x).attr("y1", a.titleTopMargin).attr("y2", S - a.titleTopMargin).attr("class", "today"), v !== "" && m.attr("style", v.replace(/,/g, ";"));
  }
  h(D, "drawToday");
  function H(x) {
    const Y = {}, F = [];
    for (let S = 0, v = x.length; S < v; ++S)
      Object.prototype.hasOwnProperty.call(Y, x[S]) || (Y[x[S]] = !0, F.push(x[S]));
    return F;
  }
  h(H, "checkUnique");
}, "draw"), Ti = {
  setConf: ki,
  draw: vi
}, bi = /* @__PURE__ */ h((t) => `
  .mermaid-main-font {
        font-family: ${t.fontFamily};
  }

  .exclude-range {
    fill: ${t.excludeBkgColor};
  }

  .section {
    stroke: none;
    opacity: 0.2;
  }

  .section0 {
    fill: ${t.sectionBkgColor};
  }

  .section2 {
    fill: ${t.sectionBkgColor2};
  }

  .section1,
  .section3 {
    fill: ${t.altSectionBkgColor};
    opacity: 0.2;
  }

  .sectionTitle0 {
    fill: ${t.titleColor};
  }

  .sectionTitle1 {
    fill: ${t.titleColor};
  }

  .sectionTitle2 {
    fill: ${t.titleColor};
  }

  .sectionTitle3 {
    fill: ${t.titleColor};
  }

  .sectionTitle {
    text-anchor: start;
    font-family: ${t.fontFamily};
  }


  /* Grid and axis */

  .grid .tick {
    stroke: ${t.gridColor};
    opacity: 0.8;
    shape-rendering: crispEdges;
  }

  .grid .tick text {
    font-family: ${t.fontFamily};
    fill: ${t.textColor};
  }

  .grid path {
    stroke-width: 0;
  }


  /* Today line */

  .today {
    fill: none;
    stroke: ${t.todayLineColor};
    stroke-width: 2px;
  }


  /* Task styling */

  /* Default task */

  .task {
    stroke-width: 2;
  }

  .taskText {
    text-anchor: middle;
    font-family: ${t.fontFamily};
  }

  .taskTextOutsideRight {
    fill: ${t.taskTextDarkColor};
    text-anchor: start;
    font-family: ${t.fontFamily};
  }

  .taskTextOutsideLeft {
    fill: ${t.taskTextDarkColor};
    text-anchor: end;
  }


  /* Special case clickable */

  .task.clickable {
    cursor: pointer;
  }

  .taskText.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideLeft.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideRight.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }


  /* Specific task settings for the sections*/

  .taskText0,
  .taskText1,
  .taskText2,
  .taskText3 {
    fill: ${t.taskTextColor};
  }

  .task0,
  .task1,
  .task2,
  .task3 {
    fill: ${t.taskBkgColor};
    stroke: ${t.taskBorderColor};
  }

  .taskTextOutside0,
  .taskTextOutside2
  {
    fill: ${t.taskTextOutsideColor};
  }

  .taskTextOutside1,
  .taskTextOutside3 {
    fill: ${t.taskTextOutsideColor};
  }


  /* Active task */

  .active0,
  .active1,
  .active2,
  .active3 {
    fill: ${t.activeTaskBkgColor};
    stroke: ${t.activeTaskBorderColor};
  }

  .activeText0,
  .activeText1,
  .activeText2,
  .activeText3 {
    fill: ${t.taskTextDarkColor} !important;
  }


  /* Completed task */

  .done0,
  .done1,
  .done2,
  .done3 {
    stroke: ${t.doneTaskBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
  }

  .doneText0,
  .doneText1,
  .doneText2,
  .doneText3 {
    fill: ${t.taskTextDarkColor} !important;
  }


  /* Tasks on the critical line */

  .crit0,
  .crit1,
  .crit2,
  .crit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.critBkgColor};
    stroke-width: 2;
  }

  .activeCrit0,
  .activeCrit1,
  .activeCrit2,
  .activeCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.activeTaskBkgColor};
    stroke-width: 2;
  }

  .doneCrit0,
  .doneCrit1,
  .doneCrit2,
  .doneCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
    cursor: pointer;
    shape-rendering: crispEdges;
  }

  .milestone {
    transform: rotate(45deg) scale(0.8,0.8);
  }

  .milestoneText {
    font-style: italic;
  }
  .doneCritText0,
  .doneCritText1,
  .doneCritText2,
  .doneCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  .vert {
    stroke: ${t.vertLineColor};
  }

  .vertText {
    font-size: 15px;
    text-anchor: middle;
    fill: ${t.vertLineColor} !important;
  }

  .activeCritText0,
  .activeCritText1,
  .activeCritText2,
  .activeCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  .titleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${t.titleColor || t.textColor};
    font-family: ${t.fontFamily};
  }
`, "getStyles"), xi = bi, _i = {
  parser: Aa,
  db: yi,
  renderer: Ti,
  styles: xi
};
export {
  _i as diagram
};
