import { C as e, I as o } from "./Index-BC1pBwEQ.js";
export {
  e as BaseChatBot,
  o as default
};
