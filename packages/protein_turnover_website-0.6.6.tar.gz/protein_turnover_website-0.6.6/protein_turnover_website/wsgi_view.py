from __future__ import annotations

from .app import create_view_app

application = create_view_app()

del create_view_app
