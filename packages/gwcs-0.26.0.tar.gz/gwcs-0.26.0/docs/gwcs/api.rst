.. _reference_api:

API
===

.. automodapi:: gwcs.wcs
  :inherited-members:

.. automodapi:: gwcs.coordinate_frames
  :inherited-members:

.. automodapi:: gwcs.wcstools

.. automodapi:: gwcs.selector
  :inherited-members:

.. automodapi:: gwcs.spectroscopy
  :inherited-members:

.. automodapi:: gwcs.geometry
  :inherited-members:
