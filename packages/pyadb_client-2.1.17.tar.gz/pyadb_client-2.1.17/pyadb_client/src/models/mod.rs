mod devices;
pub use devices::PyDeviceShort;
