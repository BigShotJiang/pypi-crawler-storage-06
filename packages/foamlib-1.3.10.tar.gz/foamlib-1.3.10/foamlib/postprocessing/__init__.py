"""
The postprocessing module provides utilities for processing and analyzing simulation data.

It includes table readers and data extraction tools.

"""
