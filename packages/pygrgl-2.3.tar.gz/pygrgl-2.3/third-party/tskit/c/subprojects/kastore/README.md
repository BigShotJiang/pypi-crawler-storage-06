This directory is an abbreviated version of the kastore distribution source.

All files should be updated when we are updating to a new kastore version.
