.. note: this is left in rst format to avoid Duplicate ID issues

.. _sec_changelogs:

==========
Changelogs
==========

******
Python
******

.. include:: ../python/CHANGELOG.rst

*****
C API
*****

.. include:: ../c/CHANGELOG.rst
