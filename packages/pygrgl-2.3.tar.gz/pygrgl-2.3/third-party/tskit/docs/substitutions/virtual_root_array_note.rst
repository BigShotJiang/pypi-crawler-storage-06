.. note:: The length of these arrays is
    equal to the number of nodes in the tree sequence plus 1, with the
    final element corresponding to the tree's :meth:`~.Tree.virtual_root`.
    Please see the :ref:`tree roots <sec_data_model_tree_roots>` section
    for more details.
