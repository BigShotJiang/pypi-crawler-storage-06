.. warning:: The current implementation of this operation is linear in the number of
    trees, so may be inefficient for large tree sequences. See
    `this issue <https://github.com/tskit-dev/tskit/issues/684>`_ for more
    information.
