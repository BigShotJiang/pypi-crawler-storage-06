.. warning:: The numpy arrays returned by table attribute accesses are copies
    of the underlying data. In particular, this means that editing
    individual values in the arrays will not change the table data
    Instead, you should set entire columns or rows at once
    (see :ref:`sec_tables_api_accessing_table_data`).
