*******
Install
*******

You can install it via conda_:

.. code-block:: bash

  conda install -c conda-forge bgen

Alternatively, it can be installed via:

.. code-block:: bash

  curl -fsSL https://git.io/JerYI | GITHUB_USER=limix GITHUB_PROJECT=bgen bash

Please, report any issue by `opening an issue`_ on Github.

.. _conda: http://conda.pydata.org/docs/index.html
.. _opening an issue: https://github.com/limix/bgen/issues/new
