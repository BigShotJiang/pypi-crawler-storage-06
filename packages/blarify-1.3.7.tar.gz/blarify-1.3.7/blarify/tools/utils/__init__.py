from .id_resolver import resolve_reference_id

__all__ = ["resolve_reference_id"]