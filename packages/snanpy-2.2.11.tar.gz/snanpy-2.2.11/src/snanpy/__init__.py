from snanpy.functions import figax
from snanpy.functions import snantest

# Version of the snanpy package
__version__ = "2.2.11"