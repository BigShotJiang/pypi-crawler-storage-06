API Reference
=============

.. toctree::
   :maxdepth: 3
   :titlesonly:

   tune
   predict
   post
   confidence_intervals
   zero_stratified_kfold
   zir
   log_grid_search
   aoa
   functions