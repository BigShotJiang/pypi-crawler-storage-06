Predict
==========

.. automodule:: abil.predict
   :members:
   :undoc-members:
   :show-inheritance:
   