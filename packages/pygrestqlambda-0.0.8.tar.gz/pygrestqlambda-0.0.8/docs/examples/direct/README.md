# Direct python script invocation example

Navigate to the current directory from the root of this project:
```shell
cd docs/examples/direct
```

First install dependency with:
```shell
pip install pygrestqlambda
```

Then execute the scripts in this directory with, for example:
```shell
python json_response.py
```
