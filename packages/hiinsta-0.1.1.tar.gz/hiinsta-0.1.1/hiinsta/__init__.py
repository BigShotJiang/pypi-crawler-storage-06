"""
hiinsta - A Python package for hiinsta functionality.
"""

__version__ = "0.1.1"
__author__ = "Tomas Santana"
__email__ = "tomas@cervant.chat"

from .InstagramMessenger import InstagramMessenger

__all__ = ["InstagramMessenger"]
