# TODO: implement a logic to summarize the text


class Summarizer:
    def __init__(
        self,
    ):
        pass

    def summarize(self, text: str, max_length: int = 200, min_length: int = 40) -> str:
        pass
