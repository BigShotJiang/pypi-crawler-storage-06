pip uninstall zcbot-crawl-core

pip install --upgrade zcbot-crawl-core -i https://pypi.python.org/simple
pip show zcbot-crawl-core
