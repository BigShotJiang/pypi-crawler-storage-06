# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Architecture Overview

Gapless Crypto Data is a high-performance cryptocurrency data collection tool providing authentic Binance data with zero-gap guarantee. The architecture follows a modular design with separation of concerns:

### Core Components

- **BinancePublicDataCollector**: Ultra-fast data collection from Binance's public data repository (22x faster than API calls). Handles monthly zip file downloads, processing, and conversion to 11-column microstructure format.
- **UniversalGapFiller**: Intelligent gap detection and filling using authentic Binance API data. Automatically detects timestamp gaps and fills with real market data, never synthetic data.
- **AtomicCSVOperations**: Corruption-proof file operations ensuring data integrity during writes and merges.
- **SafeCSVMerger**: Safe merging of multiple CSV files with validation and atomic operations.

### Data Flow Architecture

```
Binance Public Repository (monthly zips) � BinancePublicDataCollector � 11-column CSV files
                                                      �
Gap Detection � UniversalGapFiller � Binance API � Filled gapless datasets
                                                      �
AtomicCSVOperations � Final validated CSV files with complete market data
```

### Data Format Specifications

The tool produces 11-column microstructure format CSV files with:
- Standard OHLCV columns (Open, High, Low, Close, Volume)
- Order flow metrics (Quote Volume, Trade Count, Taker Buy Base Volume, Taker Buy Quote Volume)
- Timestamp (Close Time, Open Time)

This format provides authentic microstructure data essential for quantitative trading and backtesting.

## Development Commands

### Environment Setup
```bash
# Install dependencies
uv sync --dev

# Activate virtual environment (if not using uv run)
source .venv/bin/activate  # macOS/Linux
.venv\Scripts\activate     # Windows
```

### Testing and Quality Assurance
```bash
# Run full test suite
uv run pytest

# Run specific test files
uv run pytest tests/test_binance_collector.py -v
uv run pytest tests/test_gap_filler.py -v

# Test CLI functionality
uv run gapless-crypto-data --help
```

### Code Quality and Formatting
```bash
# Format code
uv run ruff format .

# Lint and auto-fix issues
uv run ruff check --fix .

# Type checking
uv run mypy src/

# Validate file encoding (required for CI)
find src/ tests/ examples/ -name "*.py" -o -name "*.md" | xargs file --mime-encoding
```

### Build and Package
```bash
# Build package
uv build

# Test package installation locally
uv tool install --editable .
```

## Data Collection Patterns

### Default Collection
The tool defaults to SOLUSDT with comprehensive timeframe coverage and 4.1-year historical range:
- Symbol: SOLUSDT
- Timeframes: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h
- Date Range: 2020-08-15 to 2025-03-20 (configurable)

### Dual Data Source Strategy
1. **Primary**: Binance Public Data Repository (monthly zip files) - 22x faster
2. **Secondary**: Binance API for gap filling - authentic real-time data

### Output Directory Structure
```
output_dir/
   {SYMBOL}_{TIMEFRAME}_{START_DATE}_to_{END_DATE}.csv
   (one file per symbol-timeframe combination)
```

Default output location: `src/gapless_crypto_data/sample_data/`

## CLI Usage Patterns

### Standard Collection
```bash
# Default comprehensive collection
uv run gapless-crypto-data

# Custom symbol and timeframes
uv run gapless-crypto-data --symbol BTCUSDT --timeframes 1h,4h

# Multiple symbols collection (native multi-symbol support)
uv run gapless-crypto-data --symbol BTCUSDT,ETHUSDT,SOLUSDT --timeframes 1h,4h

# Custom date range
uv run gapless-crypto-data --start 2023-01-01 --end 2023-12-31

# Multi-symbol with custom settings
uv run gapless-crypto-data --symbol BTCUSDT,ETHUSDT --timeframes 1h,4h --output-dir ./crypto_data
```

### Gap Filling Operations
```bash
# Manual gap filling for existing datasets
uv run gapless-crypto-data --fill-gaps --directory ./data

# Gap filling with specific filters
uv run gapless-crypto-data --fill-gaps --directory ./data --symbol BTCUSDT --timeframe 1h
```

## Python API Integration

### Basic Collection
```python
from gapless_crypto_data import BinancePublicDataCollector

collector = BinancePublicDataCollector()
collector.collect_data(
    symbol="BTCUSDT",
    timeframes=["1h", "4h"],
    start_date="2023-01-01",
    end_date="2023-12-31"
)
```

### Multi-Symbol Collection
```python
# For multiple symbols, use CLI multi-symbol support (recommended)
# or loop for complex per-symbol logic
symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
for symbol in symbols:
    collector = BinancePublicDataCollector(symbol=symbol)
    collector.collect_multiple_timeframes(["1h", "4h"])
```

### Gap Filling
```python
from gapless_crypto_data import UniversalGapFiller

gap_filler = UniversalGapFiller()
gap_filler.fill_gaps(directory="./data")
```

## CI/CD Integration

The project uses dual GitHub Actions workflows:

### CI Pipeline (`ci-cd.yml`)
- Triggers on push to main/develop branches and PRs
- Tests across Python 3.9-3.12
- Validates file encoding, linting, CLI functionality, and package building
- Publishes to PyPI on GitHub releases

### Continuous Deployment (`publish.yml`)
- Triggers on main branch pushes and manual dispatch
- Builds, tests, and automatically publishes to PyPI
- Includes Sigstore artifact signing for security

## Current Architecture (v2.5.0)

**Canonical Reference**: `docs/CURRENT_ARCHITECTURE_STATUS.yaml`

### Production-Ready Capabilities
- **Core Collection**: 22x faster than API-only with zero-gap guarantee
- **Intelligent Resume**: SOTA checkpointing with joblib Memory
- **Memory Streaming**: Unlimited datasets with Polars lazy evaluation
- **Regression Detection**: SOTA anomaly detection with PyOD ensemble
- **CLI Interface**: Native multi-symbol support with progress reporting

### SOTA Integrations
- joblib 1.5.2, polars 1.33.1, pyarrow 21.0.0, pyod 2.0.5, scipy 1.16.2
- 30 comprehensive tests covering all functionality
- Exception-only failure principles with atomic operations

## Authentication Requirements

- **No authentication required** for primary data collection (public repository)
- **No API keys needed** for standard usage
- Gap filling uses public Binance API endpoints (rate-limited but no auth required)
