from setuptools import setup
setup(name='word_count_mcp',
      version='0.1.0',
      py_modules=['word_count_mcp'],
      )