"""
DRF to MkDocs - Generate Markdown API docs from Django/DRF OpenAPI schema for MkDocs
"""

__version__ = "0.1.0"
__author__ = "ShayestehHs"
__email__ = "shayestehhs1@gmail.com"
