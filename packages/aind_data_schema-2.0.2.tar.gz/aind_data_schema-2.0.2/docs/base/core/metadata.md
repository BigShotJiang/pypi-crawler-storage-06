# Metadata

[Link to code](https://github.com/AllenNeuralDynamics/aind-data-schema/blob/dev/src/aind_data_schema/core/metadata.py)

The `metadata.json` gathers together the other metadata files and adds information about where the data asset is stored.
