# Licenses

## Model definitions

### License

Licenses

| Name | Value |
|------|-------|
| `MIT` | `MIT` |
| `CC_BY_40` | `CC-BY-4.0` |


