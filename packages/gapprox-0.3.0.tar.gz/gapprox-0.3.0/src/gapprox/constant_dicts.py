#from .miscellaneous.dot_dict import DotDict as _DotDict

import math as _math

default = {
'nan': _math.nan,
'inf': _math.inf,
'pi' : _math.pi,
'tau': _math.tau,
'e'  : _math.e,
}
