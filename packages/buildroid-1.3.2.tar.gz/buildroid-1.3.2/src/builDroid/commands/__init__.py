COMMAND_CATEGORIES = [
    "builDroid.commands.execute_code",
    "builDroid.commands.file_operations",
    "builDroid.commands.system",
    "builDroid.commands.gradle_build_error_solver",
]