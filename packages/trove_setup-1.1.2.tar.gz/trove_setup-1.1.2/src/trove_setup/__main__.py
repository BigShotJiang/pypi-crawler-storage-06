from .cli import run_typer

if __name__ == "__main__":
    run_typer()
