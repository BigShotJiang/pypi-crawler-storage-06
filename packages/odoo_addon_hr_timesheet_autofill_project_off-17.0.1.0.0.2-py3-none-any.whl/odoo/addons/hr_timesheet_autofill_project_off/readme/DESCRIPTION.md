Disables automatic filling of the project field based on previous entries on timesheets.
