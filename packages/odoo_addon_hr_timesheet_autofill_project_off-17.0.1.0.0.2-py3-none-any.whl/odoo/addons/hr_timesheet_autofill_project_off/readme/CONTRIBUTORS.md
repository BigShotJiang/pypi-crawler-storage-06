- [Innovara](https://innovara.tech):
  - Manuel Fombuena \<mfombuena@innovara.tech\>

- [Solvos](https://www.solvos.es):
   - David Alonso