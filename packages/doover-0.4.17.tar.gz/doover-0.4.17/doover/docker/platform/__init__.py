from .platform import (
    PlatformInterface as PlatformInterface,
    PulseCounter as PulseCounter,
)
from .platform_types import Location as Location, Event as Event
