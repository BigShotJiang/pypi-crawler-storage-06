.. py:currentmodule:: pydoover

Processor Applications
======================

.. autoclass:: pydoover.cloud.processor.ProcessorBase
   :members:

