.. py:currentmodule:: pydoover

Exceptions
==========

.. autoexception:: pydoover.cloud.api.DooverException

.. autoexception:: pydoover.cloud.api.HTTPException

.. autoexception:: pydoover.cloud.api.NotFound

.. autoexception:: pydoover.cloud.api.Forbidden
