# CHANGELOG


## v0.1.0 (2025-09-18)

### Chores

- Cleanup
  ([`54e7cff`](https://github.com/MicaelJarniac/sqlguardian/commit/54e7cffd247fffdba58d13af8f9d332595b7869d))

### Features

- Initial release, still WIP
  ([`06055f4`](https://github.com/MicaelJarniac/sqlguardian/commit/06055f4b3a0ec925d44492d49748cc7fc9dc12a3))


## v0.0.0 (2025-09-17)
