2024-09-27 Version: 1.2.0
- Support API ListTerminalCommands.


2024-08-21 Version: 1.1.0
- Support API GetInstanceRecordConfig.
- Support API ListInstanceRecords.
- Support API SetInstanceRecordConfig.
- Support API ViewInstanceRecords.


2024-02-19 Version: 1.0.2
- Generated python 2022-02-20 for ecs-workbench.

2024-02-05 Version: 1.0.1
- Update API LoginInstanceupdate InstanceLoginInfo param.


2023-08-21 Version: 1.0.0
- Generated python 2022-02-20 for ecs-workbench.

