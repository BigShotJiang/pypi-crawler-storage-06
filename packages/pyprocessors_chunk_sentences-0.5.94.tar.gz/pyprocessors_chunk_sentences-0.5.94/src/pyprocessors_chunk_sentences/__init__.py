"""Sherpa sentence chunking processor"""
__version__ = "0.5.94"
