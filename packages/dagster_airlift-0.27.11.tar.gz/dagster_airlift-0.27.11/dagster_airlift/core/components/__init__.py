from dagster_airlift.core.components.airflow_instance.component import (
    AirflowInstanceComponent as AirflowInstanceComponent,
)
