"""Transcription module for MFA"""
from montreal_forced_aligner.transcription.transcriber import Transcriber

__all__ = ["Transcriber", "transcriber"]
