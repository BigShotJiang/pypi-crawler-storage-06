"""Module for running MFA in online mode"""
