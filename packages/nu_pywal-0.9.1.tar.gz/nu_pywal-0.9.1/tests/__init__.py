"""
wal - Generate and change colorschemes on the fly.
Created by Dylan Araps.
"""
