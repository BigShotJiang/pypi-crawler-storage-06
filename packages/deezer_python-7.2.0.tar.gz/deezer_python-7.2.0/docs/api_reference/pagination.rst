.. _pagination-reference:

Pagination
----------

.. autoclass:: deezer.PaginatedList
    :members:
