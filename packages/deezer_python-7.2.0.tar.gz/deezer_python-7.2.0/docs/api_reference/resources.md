(resources-reference)=

# Resources

A collection of Python classes modelling each type of content that is returned by the Deezer API.

```{toctree}
:maxdepth: 1

resources/album
resources/artist
resources/chart
resources/editorial
resources/episode
resources/genre
resources/playlist
resources/podcast
resources/radio
resources/track
resources/user
```
