Track
-----

.. autoclass:: deezer.Track
    :members:
    :undoc-members:
