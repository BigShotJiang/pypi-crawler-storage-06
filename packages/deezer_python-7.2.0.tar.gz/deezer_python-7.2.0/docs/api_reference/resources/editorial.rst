Editorial
---------

.. autoclass:: deezer.Editorial
    :members:
    :undoc-members:
