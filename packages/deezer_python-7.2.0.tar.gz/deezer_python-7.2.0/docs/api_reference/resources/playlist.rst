Playlist
--------

.. autoclass:: deezer.Playlist
    :members:
    :undoc-members:
