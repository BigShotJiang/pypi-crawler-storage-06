::: abstract_dataloader.spec
    options:
        members:
        - Metadata
        - Sensor
        - Synchronization
        - Trace
        - Dataset
        - Transform
        - Collate
        - Pipeline
