::: abstract_dataloader.abstract
    options:
        members:
        - Metadata
        - Sensor
        - Synchronization
        - Trace
        - Dataset
        - Transform
        - Collate
        - Pipeline
