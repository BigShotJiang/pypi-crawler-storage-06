"""ADL specification extensions and non-generic utilities."""
