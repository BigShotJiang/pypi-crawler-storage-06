__version__ = "0.0.1"

def info():
    return "This is a dummy vishalkkk-upgrades package for PyPI."
