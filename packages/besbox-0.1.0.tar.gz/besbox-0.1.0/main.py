def main():
    print("Hello from besbox!")


if __name__ == "__main__":
    main()
