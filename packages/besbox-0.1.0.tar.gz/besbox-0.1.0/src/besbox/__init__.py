"""besbox - A library of utilities."""

from .core import add

__version__ = "0.1.0"
__all__ = ["add"]