__author__ = {
    "jackzzs": "jackzzs@outlook.com",
}
__version__ = "7.5.1"
__url__ = "https://emby-keeper.github.io"
