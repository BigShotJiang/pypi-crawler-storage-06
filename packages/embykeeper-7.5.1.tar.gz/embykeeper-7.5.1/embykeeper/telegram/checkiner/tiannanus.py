from ._templ_a import TemplateACheckin


class TiannanusCheckin(TemplateACheckin):
    name = "天南小筑 US"
    bot_username = "US_nan_bot"
