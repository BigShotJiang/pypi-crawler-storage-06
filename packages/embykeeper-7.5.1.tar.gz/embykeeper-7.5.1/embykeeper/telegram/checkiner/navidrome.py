from ._templ_a import TemplateACheckin

__ignore__ = True


class NavidromeCheckin(TemplateACheckin):
    name = "Navidrome"
    bot_username = "navidrome_bot"
    templ_panel_keywords = ["倾听音乐"]
