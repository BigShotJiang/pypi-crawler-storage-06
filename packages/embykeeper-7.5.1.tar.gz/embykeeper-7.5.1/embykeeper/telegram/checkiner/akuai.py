from ._templ_a import TemplateACheckin

__ignore__ = True


class AkuaiCheckin(TemplateACheckin):
    name = "Akuai"
    bot_username = "joulilibot"
