from ._templ_a import TemplateACheckin

__ignore__ = True


class ApopCheckin(TemplateACheckin):
    name = "Apop"
    bot_username = "apopcloudemby_bot"
