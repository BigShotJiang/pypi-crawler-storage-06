from ._templ_a import TemplateACheckin


class YomoCheckin(TemplateACheckin):
    name = "Yomo 服不服"
    bot_username = "yomoemby_bot"
    bot_use_captcha = False
