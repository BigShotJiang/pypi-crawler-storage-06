from .charon import CharonCheckin

__ignore__ = True


class TestCharonCheckin(CharonCheckin):
    name = "卡戎签到测试"
    bot_username = "embykeeper_test_bot"
