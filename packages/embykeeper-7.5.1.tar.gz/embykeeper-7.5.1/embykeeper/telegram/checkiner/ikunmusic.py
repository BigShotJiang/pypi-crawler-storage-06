from ._templ_a import TemplateACheckin


class IKunMusicCheckin(TemplateACheckin):
    name = "iKun 音乐服"
    bot_username = "iikun_bot"
    bot_success_pat = "签到成功"
