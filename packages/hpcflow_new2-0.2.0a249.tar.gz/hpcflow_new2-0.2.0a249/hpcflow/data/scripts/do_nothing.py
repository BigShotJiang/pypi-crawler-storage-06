def do_nothing():
    pass
