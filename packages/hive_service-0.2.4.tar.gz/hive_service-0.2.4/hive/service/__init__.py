from .service import Service as HiveService

__all__ = [
    "HiveService",
]
