.. meta::
  :copyright: SPDX-FileCopyrightText: Christian Amsüss and the aiocoap contributors
  :copyright: SPDX-License-Identifier: MIT

LICENSE
=======

.. include:: ../LICENSES/MIT.txt

Files in ``aiocoap/util/vendored/`` may have different (but compatible and OSI approved) licenses.
