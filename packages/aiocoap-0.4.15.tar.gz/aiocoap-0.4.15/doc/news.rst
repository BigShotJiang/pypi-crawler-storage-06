.. meta::
  :copyright: SPDX-FileCopyrightText: Christian Amsüss and the aiocoap contributors
  :copyright: SPDX-License-Identifier: MIT

Change log
==========

This summarizes the changes between released versions. For a complete change
log, see the git history. For details on the changes, see the respective git
commits indicated at the start of the entry.

.. include:: ../NEWS.rst
