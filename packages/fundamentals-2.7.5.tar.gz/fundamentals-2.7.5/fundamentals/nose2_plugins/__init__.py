"""
*plugins for nose2 unit testing*
"""
