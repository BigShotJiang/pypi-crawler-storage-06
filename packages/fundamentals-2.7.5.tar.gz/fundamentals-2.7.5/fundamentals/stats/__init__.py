"""
*Some reusable statistic functions*
"""
from .rolling_window_sigma_clip import rolling_window_sigma_clip
