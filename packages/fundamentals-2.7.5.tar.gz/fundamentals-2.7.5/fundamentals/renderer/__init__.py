"""
*Render python objects as various list and markup formats *
"""
from __future__ import absolute_import
from .list_of_dictionaries import list_of_dictionaries
