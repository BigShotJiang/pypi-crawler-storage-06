"""
*Common tools used thoughout the fundamentals package*
"""
from .getpackagepath import getpackagepath
