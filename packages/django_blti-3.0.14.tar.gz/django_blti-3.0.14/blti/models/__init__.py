# Copyright 2025 UW-IT, University of Washington
# SPDX-License-Identifier: Apache-2.0

from .canvas import CanvasData
