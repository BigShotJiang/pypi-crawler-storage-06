def main():
    print("Hello from mujoco-tools!")


if __name__ == "__main__":
    main()
