# 代码生成脚本

## Quick Start

- 安装依赖：
  - pip install -r requirements.txt

- 修改 generate.py 中 exported_*_methods 导出方法列表

- 生成代码
  - python generate.py