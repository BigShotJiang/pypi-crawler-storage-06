The DDMRP
[roadmap](https://github.com/OCA/ddmrp/issues?q=is%3Aopen+is%3Aissue+label%3Aenhancement)
and [known
issues](https://github.com/OCA/ddmrp/issues?q=is%3Aopen+is%3Aissue+label%3Abug)
can be found on GitHub.
