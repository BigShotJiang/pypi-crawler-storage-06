"""Provides a module to download a file."""

from .downloads import RemoteFileNotFoundError, download_file  # noqa: F401
