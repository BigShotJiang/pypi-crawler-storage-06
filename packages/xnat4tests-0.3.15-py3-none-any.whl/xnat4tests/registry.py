import docker.models.containers
from .utils import logger
from .config import Config
from .base import docker_network, connect


def start_registry(config_name: str = "default") -> docker.models.containers.Container:

    config = Config.load(config_name)

    xnat_docker_network = docker_network()
    dc = docker.from_env()
    try:
        image = dc.images.get(config.docker_registry_image)
    except docker.errors.ImageNotFound:
        logger.info(f"Pulling {config.docker_registry_image}")
        image = dc.images.pull(config.docker_registry_image)

    try:
        container = dc.containers.get(config.docker_registry_container)
    except docker.errors.NotFound:
        container = dc.containers.run(
            image.tags[0],
            detach=True,
            ports={"5000/tcp": config.registry_port},
            network=xnat_docker_network.id,
            remove=True,
            name=config.docker_registry_container,
        )

        with connect(config) as xlogin:
            # Set registry URI, Not working due to limitations in XNAT UI
            xlogin.post(
                "/xapi/docker/hubs",
                json={"name": "testregistry", "url": "http://host.docker.internal"},
            )

    return container


def stop_registry(config_name: str = "default") -> None:

    config = Config.load(config_name)

    dc = docker.from_env()
    try:
        container = dc.containers.get(config.docker_registry_container)
    except docker.errors.NotFound:
        logger.info(
            "Did not find registry running at %s", config.docker_registry_container
        )
    else:
        container.stop()
