To use this module, you need to:

1.  Go to *Settings \> Users*, choose yours and set *Manage Global
    Discounts*.
2.  Go to *Settings \> Parameters \> Global Discounts*
3.  Choose the discount scope (sales or purchases).
4.  You can also restrict it to a certain company if needed.
