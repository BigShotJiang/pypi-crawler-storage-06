﻿xgr.CompiledGrammar
========================

.. currentmodule:: xgrammar

.. autoclass:: CompiledGrammar
   :no-show-inheritance:
   :autosummary:
