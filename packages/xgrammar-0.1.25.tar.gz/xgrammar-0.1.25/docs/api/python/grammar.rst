﻿xgr.Grammar
================

.. currentmodule:: xgrammar

.. autoclass:: Grammar
   :no-show-inheritance:
   :special-members: __str__
   :autosummary:
