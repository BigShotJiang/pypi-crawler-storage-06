Config
==========================

.. currentmodule:: xgrammar

Recursion Depth Management
--------------------------

.. autofunction:: get_max_recursion_depth
.. autofunction:: set_max_recursion_depth
.. autofunction:: max_recursion_depth

Serialization Version
---------------------

.. autofunction:: get_serialization_version
