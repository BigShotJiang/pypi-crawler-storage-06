from yarp.vector_index.local_vector_index import LocalMemoryIndex

__all__ = ["LocalMemoryIndex"]
