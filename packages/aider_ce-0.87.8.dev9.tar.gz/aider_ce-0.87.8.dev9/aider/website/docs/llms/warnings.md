---
parent: Connecting to LLMs
nav_order: 900
---

# Model warnings

{% include model-warnings.md %}


