If you are part of the *Purchase Manager* group, you can force a
confirmed purchase order to **Full Received** status: you should first
*lock* the order, then check the field **Force Received** located in the
*Other Information* tab.
