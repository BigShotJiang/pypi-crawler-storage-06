.. _api:

API Reference
=============

.. toctree::
   :maxdepth: 1

   collection
   schema
   partition
   milvus_index
   search 
   connections
   utility
   future
