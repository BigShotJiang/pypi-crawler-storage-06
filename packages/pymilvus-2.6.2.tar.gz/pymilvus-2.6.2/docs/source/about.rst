=========================
About this documentation
=========================


.. mdinclude:: res/about_documentation.md

