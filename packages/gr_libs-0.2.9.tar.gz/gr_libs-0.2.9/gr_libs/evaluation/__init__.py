""" This is a directory that includes scripts for analysis of GR results. """
