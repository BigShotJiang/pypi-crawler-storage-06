from gr_libs.tutorials.Graql.graql_minigrid_tutorial import run_graql_minigrid_tutorial

def test_graql_minigrid_tutorial():
    run_graql_minigrid_tutorial()
