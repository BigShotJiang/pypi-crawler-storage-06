# gesture_blocks/core.py
import cv2
import mediapipe as mp
import serial
import time

# ========== GLOBALS ==========
_arduino = None   # Arduino connection (shared across projects)
_cap = None       # Camera object

# ========== MEDIAPIPE SETUP ==========
_mp_hands = mp.solutions.hands
_hands = _mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7
)
_mp_draw = mp.solutions.drawing_utils


# ========== ARDUINO HELPERS ==========
def connect_arduino(port='COM5', baud=9600):
    """
    Connect to Arduino over serial.
    Example:
        connect_arduino('COM3')
    """
    global _arduino
    _arduino = serial.Serial(port, baud, timeout=1)
    time.sleep(2)  # wait for reset
    print(f"✅ Arduino connected on {port} at {baud} baud")


def get_arduino():
    """
    Return the Arduino Serial object (or None if not connected).
    Used internally by project modules.
    """
    return _arduino


# ========== CAMERA HELPERS ==========
def start_camera(index=0):
    """
    Start the default webcam.
    Example:
        cap = start_camera()
    """
    global _cap
    _cap = cv2.VideoCapture(index)
    if not _cap.isOpened():
        raise RuntimeError("❌ Could not open webcam")
    return _cap


def get_camera():
    """
    Return the global camera object (or None if not started).
    """
    return _cap


# ========== FINGER DETECTION ==========
def detect_fingers(cap=None, show=True):
    """
    Detect number of fingers (0..5).
    Draws result on the frame if show=True.
    Returns the count.
    """
    global _cap, _hands, _mp_draw
    if cap is None:
        cap = _cap
    if cap is None:
        raise RuntimeError("❌ Camera not started. Call start_camera() first.")

    success, img = cap.read()
    if not success:
        return 0

    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = _hands.process(img_rgb)
    fingers_up = 0

    if results.multi_hand_landmarks:
        for handLms in results.multi_hand_landmarks:
            if show:
                _mp_draw.draw_landmarks(img, handLms, _mp_hands.HAND_CONNECTIONS)

            # check 5 tips
            tip_ids = [4, 8, 12, 16, 20]
            landmarks = handLms.landmark
            fingers = []

            # Thumb (simple heuristic assuming right hand)
            fingers.append(1 if landmarks[tip_ids[0]].x < landmarks[tip_ids[0] - 1].x else 0)

            # Other 4 fingers
            for i in range(1, 5):
                fingers.append(1 if landmarks[tip_ids[i]].y < landmarks[tip_ids[i] - 2].y else 0)

            fingers_up = fingers.count(1)

    if show:
        cv2.putText(img, f"Fingers: {fingers_up}", (60, 75),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255, 255), 3)
        cv2.imshow("Gesture Control", img)

    return fingers_up
