# Changelog

All notable changes to this project will be documented in this file.

## Unreleased

## 0.1.1 - 2025-09-23

Support for H264 decryption.

## 0.1.0 - 2025-09-08

Initial release.