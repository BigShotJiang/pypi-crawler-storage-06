# Davey!

[![Crates version](https://img.shields.io/crates/v/davey?maxAge=3600)](https://crates.io/crates/davey) [![Crates size](https://img.shields.io/crates/size/davey?maxAge=3600)](https://crates.io/crates/davey) [![Crates downloads](https://img.shields.io/crates/d/davey?maxAge=3600)](https://crates.io/crates/davey) [![discord chat](https://img.shields.io/discord/311027228177727508?logo=discord&logoColor=white&color=5865F2)](https://snaz.in/discord)

A [Discord Audio & Video End-to-End Encryption (DAVE) Protocol](https://daveprotocol.com/) implementation using [OpenMLS](https://openmls.tech/).

> Proper usage documentation does not exist yet, but you can [read the generated documentation](https://docs.rs/davey).