#!/usr/bin/env python

FUNCTION_COMBOS = {
        'avg': ['min','max','avg', 'sum'],
        'count':['min','max','avg', 'sum'],
        'min':['min','max','avg', 'sum'],
        'max':['min','max','avg', 'sum'],
        'first':['first'],
        'mode':['mode'],
        'sum': ['sum', 'avg', 'min', 'max', 'avg']
}
