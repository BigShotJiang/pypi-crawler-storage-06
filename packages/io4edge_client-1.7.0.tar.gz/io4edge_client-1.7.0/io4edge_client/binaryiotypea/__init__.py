# SPDX-License-Identifier: Apache-2.0
from .client import Client  # noqa: F401
import io4edge_client.api.binaryIoTypeA.python.binaryIoTypeA.v1alpha1.binaryIoTypeA_pb2 as Pb  # noqa: F401
