# SPDX-License-Identifier: Apache-2.0
version = (1, 7, 0)
VERSION = "%d.%d.%d" % version
