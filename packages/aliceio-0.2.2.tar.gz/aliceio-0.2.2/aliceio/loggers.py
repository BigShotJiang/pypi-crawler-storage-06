import logging

dispatcher = logging.getLogger("aliceio.dispatcher")
event = logging.getLogger("aliceio.event")
middlewares = logging.getLogger("aliceio.middlewares")
webhook = logging.getLogger("aliceio.webhook")
yandex_funcs = logging.getLogger("aliceio.yandex_funcs")
