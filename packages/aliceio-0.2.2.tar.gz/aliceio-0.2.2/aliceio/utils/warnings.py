class AliceioWarning(Warning):
    pass


class Recommendation(AliceioWarning):
    pass
