from aliceio.fsm.storage.memory import MemoryStorage, MemoryStorageRecord


class ApiStorageRecord(MemoryStorageRecord):
    """Аналогичен :class:`MemoryStorageRecord`."""


class ApiStorage(MemoryStorage):
    """Аналогичен :class:`MemoryStorage`."""
