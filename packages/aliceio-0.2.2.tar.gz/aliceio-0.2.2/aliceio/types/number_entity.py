from typing import Union

NumberEntity = Union[int, float]
# NLU Entity Целого или дробного числа
# https://yandex.ru/dev/dialogs/alice/doc/ru/naming-entities#number
