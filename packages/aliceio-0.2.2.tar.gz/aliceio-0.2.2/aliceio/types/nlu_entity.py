from abc import ABC

from .base import AliceObject


class NLUEntity(AliceObject, ABC):
    """Родителский класс для NLU сущностей"""
