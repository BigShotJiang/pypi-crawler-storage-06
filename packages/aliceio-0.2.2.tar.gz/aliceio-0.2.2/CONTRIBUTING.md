Пожалуйста, ознакомьтесь с [гайдом](https://aliceio.readthedocs.io/ru/latest/contributing/) на сайте документации.
