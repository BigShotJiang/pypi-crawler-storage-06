# Установка

## Через [PyPI](https://pypi.org/project/aliceio/){:target="_blank"}

```bash
pip install -U aliceio
```
