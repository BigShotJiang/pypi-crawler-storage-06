# Хаб

Добро пожаловать в документацию AliceIO!
Алисия - это асинхронный фреймворк на [python](https://www.python.org/){:target="_blank"},
упрощающий разработку [навыков Алисы](https://dialogs.yandex.ru/store){:target="_blank"}
из [Яндекс.Диалогов](https://dialogs.yandex.ru/development){:target="_blank"}.

Начинающим рекомендуется ознакомиться с [туториалом](tutorial/index.md).
Знание Python'а приветствуется и рекомендуется.

> Проект написан с использованием исходного кода [aiogram](https://github.com/aiogram/aiogram/){:target="_blank"},
> [vkbottle](https://github.com/vkbottle/vkbottle/){:target="_blank"}
> и [aioalice](https://github.com/mahenzon/aioalice){:target="_blank"}
>
> Спасибо авторам и участникам этих замечательных библиотек **<3**
