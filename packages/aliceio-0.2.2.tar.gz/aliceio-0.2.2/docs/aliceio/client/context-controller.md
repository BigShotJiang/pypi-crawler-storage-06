::: aliceio.client.context_controller.SkillContextController
    handler: python
    options:
      merge_init_into_class: false
      members:
        - as_
        - skill
