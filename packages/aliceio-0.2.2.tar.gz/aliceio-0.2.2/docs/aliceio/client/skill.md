::: aliceio.client.skill.Skill
    handler: python
    options:
      members:
        - id
        - skill_id
        - token
        - oauth_token
        - __init__
        - __call__
        - context
        - upload_image
        - get_images
        - delete_image
        - upload_sound
        - get_sounds
        - delete_sound
