::: aliceio.client.alice.AliceAPIServer
    handler: python
    options:
      merge_init_into_class: true
      members: true


```PRODUCTION = AliceAPIServer.from_base(base="https://dialogs.yandex.net/api/v1/")```
