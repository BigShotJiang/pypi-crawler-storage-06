::: aliceio.client.session.aiohttp.AiohttpSession
    handler: python
    options:
      merge_init_into_class: false
      members:
        - __init__
        - proxy
        - create_session
        - close
        - build_request_data
        - make_request
