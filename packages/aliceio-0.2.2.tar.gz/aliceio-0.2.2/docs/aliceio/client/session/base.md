::: aliceio.client.session.base.BaseSession
    handler: python
    options:
      merge_init_into_class: false
      members:
        - __init__
        - check_response
        - close
        - make_request
        - prepare_value
        - __call__
