::: aliceio.client.session.middlewares.base.NextRequestMiddlewareType
    handler: python
    options:
      merge_init_into_class: true
      members: true

<br/>

::: aliceio.client.session.middlewares.base.RequestMiddlewareType
    handler: python
    options:
      merge_init_into_class: true
      members: true

<br/>

::: aliceio.client.session.middlewares.base.BaseRequestMiddleware
    handler: python
    options:
      merge_init_into_class: true
      members: true
