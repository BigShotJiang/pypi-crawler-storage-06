::: aliceio.client.session.middlewares.request_logging.RequestLogging
    handler: python
    options:
      merge_init_into_class: false
      members:
        - __init__
        - __call__
