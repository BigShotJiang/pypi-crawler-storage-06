::: aliceio.webhook.yandex_functions.one_skill.OneSkillYandexFunctionsRequestHandler
    handler: python
    options:
      members:
        - __init__
        - close
        - resolve_skill
