::: aliceio.webhook.yandex_functions.base.BaseYandexFunctionsRequestHandler
    handler: python
    options:
      members:
        - __init__
        - close
        - resolve_skill
        - handle
        - __call__
