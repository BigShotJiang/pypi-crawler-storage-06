::: aliceio.webhook.aiohttp_server.base.BaseAiohttpRequestHandler
    handler: python
    options:
      members:
        - __init__
        - register
        - close
        - resolve_skill
        - handle
        - __call__
