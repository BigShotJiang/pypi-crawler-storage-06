::: aliceio.webhook.aiohttp_server.one_skill.OneSkillAiohttpRequestHandler
    handler: python
    options:
      members:
        - __init__
        - close
        - resolve_skill
