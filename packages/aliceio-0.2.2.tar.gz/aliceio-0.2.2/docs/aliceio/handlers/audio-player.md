::: aliceio.handlers.audio_player.AudioPlayerHandler
    handler: python
    options:
      merge_init_into_class: false
      members: true
