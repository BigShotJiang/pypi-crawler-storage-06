::: aliceio.handlers.message.MessageHandler
    handler: python
    options:
      merge_init_into_class: false
      members: true
