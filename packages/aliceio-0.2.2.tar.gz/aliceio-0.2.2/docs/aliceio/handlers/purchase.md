::: aliceio.handlers.purchase.PurchaseHandler
    handler: python
    options:
      merge_init_into_class: false
      members: true
