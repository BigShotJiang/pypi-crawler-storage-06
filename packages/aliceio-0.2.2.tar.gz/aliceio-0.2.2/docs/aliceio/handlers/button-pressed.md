::: aliceio.handlers.button_pressed.ButtonPressedHandler
    handler: python
    options:
      merge_init_into_class: false
      members: true
