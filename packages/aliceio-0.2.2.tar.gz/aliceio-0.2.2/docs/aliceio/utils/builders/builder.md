::: aliceio.utils.builders.Builder
    handler: python
    options:
      members:
        - __init__
        - add
        - to_collection
        - __len__
