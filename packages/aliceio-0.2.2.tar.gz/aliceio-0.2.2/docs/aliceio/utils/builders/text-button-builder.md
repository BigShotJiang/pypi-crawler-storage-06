::: aliceio.utils.builders.TextButtonsBuilder
    options:
      members:
        - add
        - to_collection
