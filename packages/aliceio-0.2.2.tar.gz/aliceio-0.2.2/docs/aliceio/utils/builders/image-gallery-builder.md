::: aliceio.utils.builders.ImageGalleryBuilder
    handler: python
    options:
      members:
        - add
        - to_collection
