::: aliceio.utils.builders.ItemsListBuilder
    handler: python
    options:
      members:
        - add
        - set_header
        - set_footer
        - to_collection
