::: aliceio.utils.warnings.AliceioWarning
    handler: python
    options:
      members: true

<br/>

::: aliceio.utils.warnings.Recommendation
    handler: python
    options:
      members: true
