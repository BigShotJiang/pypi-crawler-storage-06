::: aliceio.utils.funcs.prepare_value
    handler: python
    options:
      members: true

<br/>

::: aliceio.utils.funcs.build_json_payload
    handler: python
    options:
      members: true
