::: aliceio.utils.mixins.DataMixin
    handler: python
    options:
      members: true

<br/>

::: aliceio.utils.mixins.ContextInstanceMixin
    handler: python
    options:
      members:
        - get_current
        - set_current
        - reset_current
