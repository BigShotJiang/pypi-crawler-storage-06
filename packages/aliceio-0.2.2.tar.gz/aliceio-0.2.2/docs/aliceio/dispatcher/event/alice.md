::: aliceio.dispatcher.event.alice.AliceEventObserver
    handler: python
    options:
      members:
        - __init__
        - filter
        - register
        - wrap_outer_middleware
        - check_root_filters
        - trigger
        - __call__
