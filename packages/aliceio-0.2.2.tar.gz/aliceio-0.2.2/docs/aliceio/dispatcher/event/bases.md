::: aliceio.dispatcher.event.bases.SkipHandler
    handler: python
    options:
      merge_init_into_class: true
      members: true

<br/>

::: aliceio.dispatcher.event.bases.CancelHandler
    handler: python
    options:
      merge_init_into_class: true
      members: true

<br/>

::: aliceio.dispatcher.event.bases.skip
    handler: python
    options:
      members: true
