::: aliceio.dispatcher.event.event.EventObserver
    handler: python
    options:
      members:
        - __init__
        - register
        - trigger
        - __call__
