::: aliceio.dispatcher.event.handler.CallableObject
    handler: python
    options:
      merge_init_into_class: true
      members:
        - call

<br/>

::: aliceio.dispatcher.event.handler.FilterObject
    handler: python
    options:
      merge_init_into_class: true
      members: false

<br/>

::: aliceio.dispatcher.event.handler.HandlerObject
    handler: python
    options:
      merge_init_into_class: true
      members:
        - check
