::: aliceio.dispatcher.flags.Flag
    handler: python
    options:
      members: true

<br/>

::: aliceio.dispatcher.flags.FlagDecorator
    handler: python
    options:
      members:
        - __call__

<br/>

::: aliceio.dispatcher.flags.FlagGenerator
    handler: python
    options:
      merge_init_into_class: true
      members:
        - __getattr__

<br/>

::: aliceio.dispatcher.flags.extract_flags_from_object
    handler: python
    options:
      members: true

<br/>

::: aliceio.dispatcher.flags.extract_flags
    handler: python
    options:
      members: true

<br/>

::: aliceio.dispatcher.flags.get_flag
    handler: python
    options:
      members: true

<br/>

::: aliceio.dispatcher.flags.check_flags
    handler: python
    options:
      members: true


## Источники

* [aiogram](https://docs.aiogram.dev/en/dev-3.x/dispatcher/flags.html){:target="_blank"}
