::: aliceio.dispatcher.dispatcher.Dispatcher
    handler: python
    options:
      merge_init_into_class: false
      members:
        - __init__
        - storage
        - get
        - feed_webhook_update
        - feed_update
        - feed_raw_update
        - __getitem__
        - __setitem__
        - __delitem__
