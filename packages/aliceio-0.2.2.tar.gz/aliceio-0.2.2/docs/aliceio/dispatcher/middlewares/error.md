::: aliceio.dispatcher.middlewares.error.ErrorsMiddleware
    handler: python
    options:
      members:
        - __init__
        - __call__
