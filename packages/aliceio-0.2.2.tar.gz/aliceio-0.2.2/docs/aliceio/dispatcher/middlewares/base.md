::: aliceio.dispatcher.middlewares.base.BaseMiddleware
    handler: python
    options:
      merge_init_into_class: true
      members: true
