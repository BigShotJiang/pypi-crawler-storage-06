::: aliceio.dispatcher.middlewares.manager.MiddlewareManager
    handler: python
    options:
      members:
        - __init__
        - register
        - unregister
        - __call__
        - __getitem__
        - __len__
        - wrap_middlewares
