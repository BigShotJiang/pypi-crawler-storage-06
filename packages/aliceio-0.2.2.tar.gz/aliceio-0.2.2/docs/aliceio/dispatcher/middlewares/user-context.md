::: aliceio.dispatcher.middlewares.user_context.UserContextMiddleware
    handler: python
    options:
      members:
        - __call__
        - resolve_event_context
