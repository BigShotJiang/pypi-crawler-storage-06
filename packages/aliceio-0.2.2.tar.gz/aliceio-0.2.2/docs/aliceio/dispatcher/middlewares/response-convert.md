::: aliceio.dispatcher.middlewares.response_convert.ResponseConvertMiddleware
    handler: python
    options:
      members:
        - __call__
        - convert_response
