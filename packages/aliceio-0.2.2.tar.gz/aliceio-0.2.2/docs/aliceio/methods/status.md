::: aliceio.methods.status.Status
    handler: python
