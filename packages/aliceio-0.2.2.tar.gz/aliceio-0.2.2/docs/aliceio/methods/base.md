::: aliceio.methods.base.AliceMethod
    handler: python
    options:
      members:
        - __returning__
        - __http_method__
        - api_url
        - emit
        - __await__
