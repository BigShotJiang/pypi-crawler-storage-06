::: aliceio.methods.images.delete_image.DeleteImage
    handler: python
    options:
      members:
        - file_id
