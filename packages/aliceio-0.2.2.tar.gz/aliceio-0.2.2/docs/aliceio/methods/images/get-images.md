::: aliceio.methods.images.get_images.GetImages
    handler: python
