::: aliceio.methods.images.upload_image.UploadImage
    handler: python
    options:
      members:
        - file
        - url
