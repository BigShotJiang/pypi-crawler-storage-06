::: aliceio.methods.sounds.upload_sound.UploadSound
    handler: python
    options:
      members:
        - file
