::: aliceio.methods.sounds.delete_sound.DeleteSound
    handler: python
    options:
      members:
        - file_id
