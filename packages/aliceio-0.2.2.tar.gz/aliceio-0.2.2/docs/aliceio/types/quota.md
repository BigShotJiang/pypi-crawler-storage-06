::: aliceio.types.quota.Quota
    handler: python
    options:
      members:
        - total
        - used
        - available

<br/>

::: aliceio.types.quota.PreQuota
    handler: python
    options:
      members:
        - quota
