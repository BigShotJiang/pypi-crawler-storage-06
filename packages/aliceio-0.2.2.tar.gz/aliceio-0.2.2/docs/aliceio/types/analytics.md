::: aliceio.types.analytics.Analytics
    handler: python
    options:
      members:
        - events
