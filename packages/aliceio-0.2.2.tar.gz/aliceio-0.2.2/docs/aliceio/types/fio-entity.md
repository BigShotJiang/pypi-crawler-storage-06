::: aliceio.types.fio_entity.FIOEntity
    handler: python
    options:
      members:
        - first_name
        - patronymic_name
        - last_name
