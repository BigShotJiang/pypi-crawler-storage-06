::: aliceio.types.nlu_entity.NLUEntity
    handler: python
    options:
      show_source: true
