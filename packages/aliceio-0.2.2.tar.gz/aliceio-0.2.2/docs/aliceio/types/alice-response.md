::: aliceio.types.alice_response.AliceResponse
    handler: python
    options:
      members:
        - response
        - session_state
        - user_state_update
        - application_state
        - analytics
        - version
