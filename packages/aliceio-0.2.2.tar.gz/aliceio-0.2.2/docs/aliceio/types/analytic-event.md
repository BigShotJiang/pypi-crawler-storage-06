::: aliceio.types.analytic_event.AnalyticEvent
    handler: python
    options:
      members:
        - name
        - value
