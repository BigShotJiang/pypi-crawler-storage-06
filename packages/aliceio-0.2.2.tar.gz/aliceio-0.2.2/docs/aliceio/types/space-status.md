::: aliceio.types.space_status.SpaceStatus
    handler: python
    options:
      members:
        - images
        - sounds
