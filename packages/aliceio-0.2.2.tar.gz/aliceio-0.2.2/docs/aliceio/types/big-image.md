::: aliceio.types.big_image.BigImage
    handler: python
    options:
      members:
        - type
        - image_id
        - title
        - description
        - button
