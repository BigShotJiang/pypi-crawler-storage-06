::: aliceio.types.card_footer.CardFooter
    handler: python
    options:
      members:
        - text
        - button
