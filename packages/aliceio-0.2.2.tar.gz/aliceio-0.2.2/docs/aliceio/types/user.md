::: aliceio.types.user.User
    handler: python
    options:
      members:
        - user_id
        - access_token
