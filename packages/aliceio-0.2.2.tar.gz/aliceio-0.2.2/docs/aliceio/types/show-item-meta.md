::: aliceio.types.show_item_meta.ShowItemMeta
    handler: python
    options:
      members:
        - content_id
        - publication_date
        - title
        - title_tts
        - expiration_date
