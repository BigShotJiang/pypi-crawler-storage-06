## NumberEntity

[NLU Entity](https://yandex.ru/dev/dialogs/alice/doc/naming-entities.html#naming-entities__number){:target="_blank"} Целого или дробного числа.
```python
from typing import Union

NumberEntity = Union[int, float]
```
