::: aliceio.types.meta.Meta
    handler: python
    options:
      members:
        - locale
        - timezone
        - client_id
        - interfaces
