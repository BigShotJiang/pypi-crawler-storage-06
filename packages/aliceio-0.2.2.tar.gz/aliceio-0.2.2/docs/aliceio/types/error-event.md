::: aliceio.types.error_event.ErrorEvent
    handler: python
    options:
      members:
        - update
        - exception
