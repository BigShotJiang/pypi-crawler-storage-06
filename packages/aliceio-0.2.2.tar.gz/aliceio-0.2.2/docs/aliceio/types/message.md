::: aliceio.types.message.Message
    handler: python
    options:
      members:
        - type
        - command
        - original_utterance
        - payload
        - markup
        - nlu
