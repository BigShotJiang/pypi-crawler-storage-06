::: aliceio.types.input_file.InputFile
    handler: python
    options:
      members:
        - __init__
        - read

<br/>

::: aliceio.types.input_file.BufferedInputFile
    handler: python
    options:
      members:
        - __init__
        - from_file
        - read

<br/>

::: aliceio.types.input_file.FSInputFile
    handler: python
    options:
      members:
        - __init__
        - read
