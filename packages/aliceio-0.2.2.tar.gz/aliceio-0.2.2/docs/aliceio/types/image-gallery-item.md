::: aliceio.types.image_gallery_item.ImageGalleryItem
    handler: python
    options:
      members:
        - image_id
        - title
        - button
