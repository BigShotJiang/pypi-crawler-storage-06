::: aliceio.types.markup.Markup
    handler: python
    options:
      members:
        - dangerous_context
