::: aliceio.types.show_pull.ShowPull
    handler: python
    options:
      members:
        - type
        - show_type
