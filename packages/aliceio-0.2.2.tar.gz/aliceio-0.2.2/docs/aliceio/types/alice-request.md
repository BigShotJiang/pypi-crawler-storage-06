::: aliceio.types.alice_request.AliceRequest
    handler: python
    options:
      members:
        - type
        - payload
        - command
        - original_utterance
        - markup
        - nlu
        - error
        - purchase_request_id
        - purchase_token
        - order_id
        - purchase_timestamp
        - purchase_payload
        - signed_data
        - signature
        - show_type
