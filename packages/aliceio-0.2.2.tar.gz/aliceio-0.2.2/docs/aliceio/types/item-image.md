::: aliceio.types.item_image.ItemImage
    handler: python
    options:
      members:
        - image_id
        - title
        - description
        - button
