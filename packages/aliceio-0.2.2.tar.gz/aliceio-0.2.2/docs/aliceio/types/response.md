::: aliceio.types.response.Response
    handler: python
    options:
      members:
        - text
        - tts
        - card
        - buttons
        - directives
        - show_item_meta
        - should_listen
        - end_session
