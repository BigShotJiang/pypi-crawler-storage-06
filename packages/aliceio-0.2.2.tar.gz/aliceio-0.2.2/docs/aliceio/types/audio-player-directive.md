::: aliceio.types.audio_player_directive.AudioPlayerDirective
    handler: python
    options:
      members:
        - action
        - item

<br/>

::: aliceio.types.audio_player_directive.Action
    handler: python
    options:
      members: true
