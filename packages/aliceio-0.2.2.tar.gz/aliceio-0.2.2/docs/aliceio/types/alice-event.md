::: aliceio.types.alice_event.AliceEvent
    handler: python
    options:
      members:
        - user
        - from_user
        - session
