::: aliceio.types.nlu.NLU
    handler: python
    options:
      members:
        - tokens
        - entities
        - intents
