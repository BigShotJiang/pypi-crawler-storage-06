::: aliceio.types.button_pressed.ButtonPressed
    handler: python
    options:
      members:
        - type
        - payload
        - markup
        - nlu
