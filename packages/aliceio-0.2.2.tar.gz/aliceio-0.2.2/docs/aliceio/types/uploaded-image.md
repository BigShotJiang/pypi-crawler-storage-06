::: aliceio.types.uploaded_image.UploadedImage
    handler: python
    options:
      members:
        - id
        - size
        - origUrl
        - orig_url
        - createdAt
        - created_at

<br/>

::: aliceio.types.uploaded_image.PreUploadedImage
    handler: python
    options:
      members:
        - image

<br/>

::: aliceio.types.uploaded_image.UploadedImagesList
    handler: python
    options:
      members:
        - images
