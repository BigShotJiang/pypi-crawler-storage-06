::: aliceio.types.datetime.DateTimeEntity
    handler: python
    options:
      members:
        - year
        - month
        - day
        - hour
        - minute
        - year_is_relative
        - month_is_relative
        - day_is_relative
        - hour_is_relative
        - minute_is_relative
