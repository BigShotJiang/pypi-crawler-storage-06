::: aliceio.types.session.Session
    handler: python
    options:
      members:
        - message_id
        - session_id
        - skill_id
        - application
        - new
        - user
        - is_anonymous
