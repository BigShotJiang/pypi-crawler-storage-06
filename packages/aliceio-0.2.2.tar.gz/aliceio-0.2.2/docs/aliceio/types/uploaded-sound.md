::: aliceio.types.uploaded_sound.UploadedSound
    handler: python
    options:
      members:
        - id
        - skillId
        - skill_id
        - size
        - originalName
        - original_name
        - createdAt
        - created_at
        - isProcessed
        - is_processed
        - error

<br/>

::: aliceio.types.uploaded_sound.PreUploadedSound
    handler: python
    options:
      members:
        - sound

<br/>

::: aliceio.types.uploaded_sound.UploadedSoundsList
    handler: python
    options:
      members:
        - sounds
