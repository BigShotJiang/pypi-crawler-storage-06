```python
AccountLinking = dict[str, Any]
Screen = dict[str, Any]
AudioPlayer = dict[str, Any]
```

<br/>

::: aliceio.types.interfaces.Interfaces
    handler: python
    options:
      members:
        - account_linking
        - screen
        - audio_player
