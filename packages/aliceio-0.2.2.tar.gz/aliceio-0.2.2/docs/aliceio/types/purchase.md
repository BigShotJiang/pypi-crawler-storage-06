::: aliceio.types.purchase.Purchase
    handler: python
    options:
      members:
        - type
        - purchase_request_id
        - purchase_token
        - order_id
        - purchase_timestamp
        - purchase_payload
        - signed_data
        - signature
