::: aliceio.types.tokens_entity.TokensEntity
    handler: python
    options:
      members:
        - start
        - end
