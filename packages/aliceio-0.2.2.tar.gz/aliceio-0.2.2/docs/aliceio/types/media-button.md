::: aliceio.types.media_button.MediaButton
    handler: python
    options:
      members:
        - text
        - url
        - payload
