::: aliceio.types.error_result.ErrorResult
    handler: python
    options:
      members:
        - message
