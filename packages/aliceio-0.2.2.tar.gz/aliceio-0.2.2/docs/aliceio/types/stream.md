::: aliceio.types.stream.Stream
    handler: python
    options:
      members:
        - url
        - offset_ms
        - token
