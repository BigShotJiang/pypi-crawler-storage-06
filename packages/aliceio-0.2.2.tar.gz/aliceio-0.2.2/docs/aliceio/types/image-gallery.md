::: aliceio.types.image_gallery.ImageGallery
    handler: python
    options:
      members:
        - type
        - items
