::: aliceio.types.metadata.Metadata
    handler: python
    options:
      members:
        - title
        - sub_title
        - art
        - background_image
