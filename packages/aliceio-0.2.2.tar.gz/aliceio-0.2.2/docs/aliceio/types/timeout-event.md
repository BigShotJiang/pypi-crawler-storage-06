::: aliceio.types.timeout_event.TimeoutUpdate
    handler: python
    options:
      members:
        - event
        - event_type
