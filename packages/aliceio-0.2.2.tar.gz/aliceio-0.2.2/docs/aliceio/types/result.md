::: aliceio.types.result.Result
    handler: python
    options:
      members:
        - result
