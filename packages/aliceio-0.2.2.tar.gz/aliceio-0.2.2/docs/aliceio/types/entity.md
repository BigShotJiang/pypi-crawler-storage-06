::: aliceio.types.entity.Entity
    handler: python
    options:
      members:
        - type
        - tokens
        - value
