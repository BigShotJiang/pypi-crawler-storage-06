::: aliceio.types.items_list.ItemsList
    handler: python
    options:
      members:
        - type
        - items
        - header
        - footer
