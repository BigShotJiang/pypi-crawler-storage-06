::: aliceio.types.account_linking_complete.AccountLinkingComplete
    handler: python
