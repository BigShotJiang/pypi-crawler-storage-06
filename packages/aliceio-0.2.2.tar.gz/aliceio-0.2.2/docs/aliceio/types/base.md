::: aliceio.types.base.AliceObject
    handler: python
    options:
      members:
        - model_config

<br/>

::: aliceio.types.base.MutableAliceObject
    handler: python
    options:
      members:
        - model_config
