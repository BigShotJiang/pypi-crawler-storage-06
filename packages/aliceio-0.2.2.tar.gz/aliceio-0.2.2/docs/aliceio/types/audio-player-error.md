::: aliceio.types.audio_player_error.AudioPlayerError
    handler: python
    options:
      members:
        - message
        - type
