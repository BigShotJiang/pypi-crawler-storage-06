::: aliceio.types.application.Application
    handler: python
    options:
      members:
        - application_id
