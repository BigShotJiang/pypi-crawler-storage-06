::: aliceio.types.url.URL
    handler: python
    options:
      members:
        - url
