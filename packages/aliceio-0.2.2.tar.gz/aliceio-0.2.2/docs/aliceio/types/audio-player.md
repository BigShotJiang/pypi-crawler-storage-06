::: aliceio.types.audio_player.AudioPlayer
    handler: python
    options:
      members:
        - type
        - error
