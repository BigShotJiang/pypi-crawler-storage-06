::: aliceio.types.audio_player_item.AudioPlayerItem
    handler: python
    options:
      members:
        - stream
        - metadata
