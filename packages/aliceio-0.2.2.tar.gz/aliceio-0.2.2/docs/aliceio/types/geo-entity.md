::: aliceio.types.geo_entity.GeoEntity
    handler: python
    options:
      members:
        - country
        - city
        - street
        - house_number
        - airport
