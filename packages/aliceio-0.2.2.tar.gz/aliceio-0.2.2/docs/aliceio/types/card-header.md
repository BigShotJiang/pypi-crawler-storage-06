::: aliceio.types.card_header.CardHeader
    handler: python
    options:
      members:
        - text
