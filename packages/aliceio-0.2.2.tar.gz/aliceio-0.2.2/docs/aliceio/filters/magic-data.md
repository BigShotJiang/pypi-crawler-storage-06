::: aliceio.filters.magic_data.MagicData
    handler: python
    options:
      members:
        - __init__
        - __call__
