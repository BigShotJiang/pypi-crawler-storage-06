::: aliceio.filters.exception.ExceptionTypeFilter
    handler: python
    options:
      members:
        - __init__
        - __call__

<br/>

::: aliceio.filters.exception.ExceptionMessageFilter
    handler: python
    options:
      members:
        - __init__
        - __call__
