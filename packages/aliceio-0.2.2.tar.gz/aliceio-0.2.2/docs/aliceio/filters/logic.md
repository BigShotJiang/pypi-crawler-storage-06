::: aliceio.filters.logic.and_f
    handler: python

<br/>

::: aliceio.filters.logic.or_f
    handler: python

<br/>

::: aliceio.filters.logic.invert_f
    handler: python
