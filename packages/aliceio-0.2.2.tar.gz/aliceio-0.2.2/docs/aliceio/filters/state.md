::: aliceio.filters.state.StateFilter
    handler: python
    options:
      members:
        - __init__
        - __call__
