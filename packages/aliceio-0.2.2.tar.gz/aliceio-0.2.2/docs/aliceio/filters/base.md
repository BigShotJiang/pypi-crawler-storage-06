::: aliceio.filters.base.Filter
    handler: python
    options:
      members:
        - __call__
        - __invert__
        - update_handler_flags



## Примеры
1. [Пример](https://github.com/K1rL3s/aliceio/blob/examples/examples/filters.py){:target="_blank"}
2. [Пример](https://github.com/K1rL3s/aliceio/blob/examples/examples/custom_filter.py){:target="_blank"}
3. [Пример](https://github.com/K1rL3s/aliceio/blob/examples/examples/context_addition.py){:target="_blank"}
