# Все `enums`

::: aliceio.enums.base.ValuesEnum
    handler: python
    options:
      members:
        - values

<br/>

::: aliceio.enums.base.StrEnum
    handler: python
    options:
      members:
        - __str__

<br/>

::: aliceio.enums.audio_error.AudioErrorType
    handler: python
    options:
      members: true

::: aliceio.enums.card.CardType
    handler: python
    options:
      members: true

<br/>

::: aliceio.enums.entity.EntityType
    handler: python
    options:
      members: true

<br/>

::: aliceio.enums.file_type.FileType
    handler: python
    options:
      members: true

<br/>

::: aliceio.enums.http_method.HttpMethod
    handler: python
    options:
      members: true

<br/>

::: aliceio.enums.update.EventType
    handler: python
    options:
      members: true

<br/>

::: aliceio.enums.update.RequestType
    handler: python
    options:
      members: true
