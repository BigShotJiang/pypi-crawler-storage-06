::: aliceio.fsm.storage.base.BaseStorage
    handler: python
    options:
      members:
        - set_state
        - get_state
        - set_data
        - get_data
        - update_data
        - close


## Примеры
* [fsm_form](https://github.com/K1rL3s/aliceio/blob/master/examples/fsm_form.py){:target="_blank"}
* [fsm_games](https://github.com/K1rL3s/aliceio/blob/master/examples/fsm_games.py){:target="_blank"}
