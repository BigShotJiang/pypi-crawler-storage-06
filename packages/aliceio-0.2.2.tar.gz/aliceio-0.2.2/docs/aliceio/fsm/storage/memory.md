::: aliceio.fsm.storage.memory.MemoryStorage
    handler: python
    selection:
    options:
      members:
        - __init__
        - set_state
        - get_state
        - set_data
        - get_data
        - close
