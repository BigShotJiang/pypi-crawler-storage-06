::: aliceio.fsm.storage.redis.KeyBuilder
    handler: python
    options:
      members:
        - __init__
        - build
