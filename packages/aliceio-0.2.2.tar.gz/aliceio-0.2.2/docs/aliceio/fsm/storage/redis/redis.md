::: aliceio.fsm.storage.redis.RedisStorage
    handler: python
    options:
      selection:
      members:
        - __init__
        - from_url
        - set_state
        - get_state
        - set_data
        - get_data
        - close
