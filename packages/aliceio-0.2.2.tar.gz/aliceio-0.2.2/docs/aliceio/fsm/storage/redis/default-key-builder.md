::: aliceio.fsm.storage.redis.DefaultKeyBuilder
    handler: python
    options:
      members:
        - __init__
        - build
