::: aliceio.fsm.strategy.FSMStrategy
    handler: python
    options:
      merge_init_into_class: true
      members: true

<br/>

::: aliceio.fsm.strategy.apply_strategy
    handler: python
    options:
      members: true
