::: aliceio.fsm.context.FSMContext
    handler: python
    options:
      members:
        - __init__
        - set_state
        - get_state
        - set_data
        - get_data
        - update_data
        - clear
