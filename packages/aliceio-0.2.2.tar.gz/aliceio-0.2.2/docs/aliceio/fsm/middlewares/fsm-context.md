::: aliceio.fsm.middlewares.fsm_context.FSMContextMiddleware
    handler: python
    options:
      members:
        - __call__
        - resolve_event_context
        - resolve_context
        - get_context
        - close
