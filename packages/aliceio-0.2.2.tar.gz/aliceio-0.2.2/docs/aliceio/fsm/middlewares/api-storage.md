::: aliceio.fsm.middlewares.api_storage.FSMApiStorageMiddleware
    handler: python
    options:
      members:
        - __call__
        - set_state_from_alice
        - resolve_state_data
        - create_record_from_data
        - set_state_to_alice
        - set_new_state
