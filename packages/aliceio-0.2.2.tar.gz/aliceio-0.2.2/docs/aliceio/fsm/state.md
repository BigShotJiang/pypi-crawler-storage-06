::: aliceio.fsm.state.State
    handler: python
    options:
      members:
        - __init__
        - group
        - state
        - set_parent
        - __call__
