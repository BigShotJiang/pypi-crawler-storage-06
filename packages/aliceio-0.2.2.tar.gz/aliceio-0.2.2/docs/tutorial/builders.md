# Кнопки и альбомы

<...>

## Примеры

[builders.py](https://github.com/K1rL3s/aliceio/blob/master/examples/builders.py){:target="_blank"}
