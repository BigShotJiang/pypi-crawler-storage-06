Example usage
=============


.. literalinclude:: ../examples/example.py
