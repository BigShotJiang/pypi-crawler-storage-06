def main():
    print("Hello from compute-mcp!")


if __name__ == "__main__":
    main()
