from . import main
main()