ansys-api-lumerical
###################

Low level Python API for Ansys Lumerical.

Looking for the recommended Python API for Ansys Lumerical? Check out `PyLumerical <https://github.com/pyansys/pylumerical>`_.

