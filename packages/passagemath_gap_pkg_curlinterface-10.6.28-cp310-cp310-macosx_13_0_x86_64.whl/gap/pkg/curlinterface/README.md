The GAP 4 package `curlInterface'
==============================

[![Build Status](https://github.com/gap-packages/curlInterface/workflows/CI/badge.svg?branch=master)](https://github.com/gap-packages/curlInterface/actions?query=workflow%3ACI+branch%3Amaster)
[![Code Coverage](https://codecov.io/github/gap-packages/curlInterface/coverage.svg?branch=master&token=)](https://codecov.io/gh/gap-packages/curlInterface)

This Package provides a simple wrapper around libcurl, to allow downloading
files over http, ftp and https.
