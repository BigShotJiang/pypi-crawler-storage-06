"""Custom exceptions for Django Prosemirror package."""


class DjangoProsemirrorException(Exception):
    """Base exception for Django Prosemirror related errors."""

    pass
