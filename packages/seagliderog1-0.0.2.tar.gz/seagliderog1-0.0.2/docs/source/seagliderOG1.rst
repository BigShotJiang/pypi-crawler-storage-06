:mod:`seagliderOG1 API`
-----------------------

convertOG1
==========
.. automodule:: seagliderOG1.convertOG1
   :members:
   :undoc-members:

vocabularies
============
.. automodule:: seagliderOG1.vocabularies
   :members:
   :undoc-members:


readers
=======
.. automodule:: seagliderOG1.readers
   :members:
   :undoc-members:

plotters
========
.. automodule:: seagliderOG1.plotters
   :members:
   :undoc-members:

writers
=======
.. automodule:: seagliderOG1.writers
   :members:
   :undoc-members:

tools
=====
.. automodule:: seagliderOG1.tools
   :members:
   :undoc-members:

utilities
=========
.. automodule:: seagliderOG1.utilities
   :members:
   :undoc-members:

