"""
*common tools used throughout package*
"""
from . import getpackagepath
