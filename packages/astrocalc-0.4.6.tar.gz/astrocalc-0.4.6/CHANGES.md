
## Release Notes

**v0.4.6 - September 23, 2025**

* **FIXED:** setup.py typo

**v0.4.4 - September 22, 2025**

* **REFACTOR** speed improvements.

**v0.4.3 - May 6, 2025**

* small fix to `coordinates_to_array` for numpy 2.0

**v0.4.1 - May 2, 2020**

* Code now compliant with Python 3.7

Release Notes
