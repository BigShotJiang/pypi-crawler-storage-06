from .event_emitter import EventEmitter

__all__ = ["EventEmitter"]
