Implement methods in the backend to cancel lines (to be used by the
frontend in select_line & set_quantity).
