"""example module"""
