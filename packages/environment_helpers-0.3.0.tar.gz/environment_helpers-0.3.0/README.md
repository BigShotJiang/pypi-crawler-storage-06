# environment-helpers

[![CI test](https://github.com/FFY00/environment-helpers/actions/workflows/test.yml/badge.svg)](https://github.com/FFY00/environment-helpers/actions/workflows/test.yml)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/FFY00/environment-helpers/main.svg)](https://results.pre-commit.ci/latest/github/FFY00/environment-helpers/main)
[![codecov](https://codecov.io/gh/FFY00/environment-helpers/graph/badge.svg)](https://codecov.io/gh/FFY00/environment-helpers)

[![Documentation Status](https://readthedocs.org/projects/environment-helpers/badge/?version=latest)](https://environment-helpers.readthedocs.io/en/latest/?badge=latest)
[![PyPI version](https://badge.fury.io/py/environment-helpers.svg)](https://pypi.org/project/environment-helpers/)

Collection of helpers for managing Python environments.
