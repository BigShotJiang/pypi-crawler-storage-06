import pytest 
from pyrauli._core  import Pauli

def test_pauli():
    p = Pauli("I")
