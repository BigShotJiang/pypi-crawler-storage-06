def main():
    print("Hello from cogames!")


if __name__ == "__main__":
    main()
