============
Installation
============

Tempest automatically discovers installed plugins. That's why you just need
to install the Python packages that contains the Telemetry Tempest plugin in
the same environment where Tempest is installed.

At the command line::

    $ git clone https://opendev.org/openstack/telemetry-tempest-plugin
    $ cd telemetry-tempest-plugin/
    $ pip install telemetry-tempest-plugin
