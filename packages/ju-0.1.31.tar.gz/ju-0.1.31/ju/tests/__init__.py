"""Tests for ju."""
