from typing import Optional


def say_hi(name: Optional[str]):
    print(f"Hey {name}!")
