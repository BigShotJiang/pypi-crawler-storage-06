def process_item(item: int | str):
    print(item)
