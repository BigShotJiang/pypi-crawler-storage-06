"""CM1106 component for ESPHome."""
