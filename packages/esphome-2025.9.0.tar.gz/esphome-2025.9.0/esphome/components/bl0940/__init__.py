import esphome.codegen as cg

CODEOWNERS = ["@tobias-", "@dan-s-github"]

CONF_BL0940_ID = "bl0940_id"
bl0940_ns = cg.esphome_ns.namespace("bl0940")
