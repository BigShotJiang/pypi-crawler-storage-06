#  Copyright (c) 2023 BlackRock, Inc.
#  All Rights Reserved.

from ingen.generators.interface_generator import InterfaceGenerator
