"""A dictionary that stores ids and dataframes as key value pairs"""

#  Copyright (c) 2023 BlackRock, Inc.
#  All Rights Reserved.

store = {

}
