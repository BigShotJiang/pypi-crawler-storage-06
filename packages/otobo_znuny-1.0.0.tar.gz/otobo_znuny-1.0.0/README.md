# Python OTOBO Client Library

This package has been renamed to otobo_znuny. Please update your dependencies accordingly.
## Links
- [Github Repo](https://github.com/Softoft/otobo-znuny-python-client)
- [New Package](https://pypi.org/project/otobo_znuny/)
