from .energy import EnergyMonitor

__version__ = "0.1"
__author__ = "VIT College"

# Allow direct import of EnergyMonitor from the package
__all__ = ["EnergyMonitor"]
