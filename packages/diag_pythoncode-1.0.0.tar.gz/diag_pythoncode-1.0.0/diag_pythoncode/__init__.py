#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
DiagProxy诊断代理框架
基于DiagProxy完整技术架构文档的Python实现

主要组件:
- IDiagAction/IDiagCase: 基础接口
- DiagCommunication: 通信层管理
- DiagProxyContext: 上下文管理
- DiagAction*: 具体诊断动作实现
- DiagCase*: 具体诊断用例实现
- DiagProxy: 主控制器
"""

from .base_interfaces import (
    DiagProcessResult, DiagRespType, TargetAddressType,
    DiagRespMessage, IDiagAction, IDiagCase, ParamParser, CmdParam
)

from .diag_communication import DiagCommunication
from .diag_proxy_context import DiagProxyContext

from .diag_actions import (
    DiagActionSecurityAccess, UnlockType,
    DiagActionRequestDownload, DiagActionTransferData, DiagActionRequestTransferExit,
    DiagActionCommonReq, DiagActionSignatureVerification, DiagActionSBLActivation,
    DiagActionMemoryErase, DiagActionIntegrityCheck
)

from .diag_cases import (
    DiagCaseSecurityAccess, DiagCaseDownload, DiagCaseCommon, DiagCaseTesterPresent
)

from .diag_proxy import (
    DiagProxy, DiagCaseType,
    create_security_access_proxy, create_download_proxy
)

from .cpp_compliant_vbf_parser import (
    VbfType, VbfBlock, EraseInfo, CppCompliantVbfInfo,
    parse_vbf_files, get_vbf_download_sequence
)

from .uds_post_transfer_flow import (
    UDSPostTransferFlow, create_uds_post_transfer_flow, validate_uds_message_formats
)

__version__ = "1.0.0"
__author__ = "DiagProxy Framework"
__description__ = "基于DiagProxy架构的ECU诊断刷写框架"

__all__ = [
    # 基础类型
    'DiagProcessResult', 'DiagRespType', 'TargetAddressType',
    'DiagRespMessage', 'IDiagAction', 'IDiagCase', 'ParamParser', 'CmdParam',
    
    # 核心组件
    'DiagCommunication', 'DiagProxyContext',
    
    # 诊断动作
    'DiagActionSecurityAccess', 'UnlockType',
    'DiagActionRequestDownload', 'DiagActionTransferData', 'DiagActionRequestTransferExit',
    'DiagActionCommonReq', 'DiagActionSignatureVerification', 'DiagActionSBLActivation',
    'DiagActionMemoryErase', 'DiagActionIntegrityCheck',
    
    # 诊断用例
    'DiagCaseSecurityAccess', 'DiagCaseDownload', 'DiagCaseCommon', 'DiagCaseTesterPresent',
    
    # 主控制器
    'DiagProxy', 'DiagCaseType',
    'create_security_access_proxy', 'create_download_proxy',
    
    # VBF解析器
    'VbfType', 'VbfBlock', 'EraseInfo', 'CppCompliantVbfInfo',
    'parse_vbf_files', 'get_vbf_download_sequence',
    
    # UDS文件传输后流程
    'UDSPostTransferFlow', 'create_uds_post_transfer_flow', 'validate_uds_message_formats'
]