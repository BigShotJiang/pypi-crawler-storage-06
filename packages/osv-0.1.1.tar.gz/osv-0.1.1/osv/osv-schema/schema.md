Moved to <https://ossf.github.io/osv-schema>.
