from .suppress import Suppress

__all__ = ["Suppress"]
