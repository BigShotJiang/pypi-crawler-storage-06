class Channel:
    AUTO = 1
    SMS = 2
    TELEGRAM = 3
