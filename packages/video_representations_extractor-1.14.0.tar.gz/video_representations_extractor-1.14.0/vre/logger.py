"""VRE logger."""
from loggez import make_logger
vre_logger = make_logger("VRE")
