"""init file"""
from .RIFE_HDv2 import Model
