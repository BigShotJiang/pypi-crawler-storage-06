"""init file"""
from .dpt_depth import DPTDepthModel
from .utils import get_size
