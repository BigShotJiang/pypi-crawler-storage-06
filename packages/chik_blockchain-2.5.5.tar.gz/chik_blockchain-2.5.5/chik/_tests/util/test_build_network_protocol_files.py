from __future__ import annotations

from chik._tests.util.build_network_protocol_files import main


def test_build_network_protocol_files() -> None:
    main()
