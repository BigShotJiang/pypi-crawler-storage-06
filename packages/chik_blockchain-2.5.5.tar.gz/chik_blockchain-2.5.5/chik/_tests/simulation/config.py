from __future__ import annotations

job_timeout = 60
parallel = False
install_timelord = True
checkout_blocks_and_plots = True
