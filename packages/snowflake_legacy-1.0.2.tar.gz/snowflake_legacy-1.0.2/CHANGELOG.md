# Release History

## 1.0.2 (2025-09-23)
* Bump upper bound Python constraint to support Python 3.13.

## 1.0.1 (2025-06-10)
* Bump upper bound Python constraint to support Python 3.12.

## 0.7.0 (2024-03-18)
* No changes.

## 0.5.0 (2023-12-12)
* Remove Python requirements upper bound.

## 0.4.0 (2023-12-04)
* No changes.

## 0.3.0 (2023-11-17)
* Initial pre-release.
