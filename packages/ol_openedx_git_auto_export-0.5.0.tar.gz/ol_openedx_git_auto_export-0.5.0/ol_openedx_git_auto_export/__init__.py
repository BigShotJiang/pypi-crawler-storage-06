__version__ = 0.3
default_app_config = "git_auto_export.app.GitAutoExportConfig"
