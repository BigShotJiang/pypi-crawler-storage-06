"""The mlb data sportsball module."""

# ruff: noqa: F401
from .combined.mlb_combined_league_model import \
    MLBCombinedLeagueModel as MLBLeagueModel
