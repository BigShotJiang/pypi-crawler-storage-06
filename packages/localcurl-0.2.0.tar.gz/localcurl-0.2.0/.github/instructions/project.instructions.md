---
applyTo: '**'
---
The project is managed by `uv`, so you can use `uv` commands to run the project. Here are some common commands:
Run tests with pytest:
```bash
uv run pytest
```