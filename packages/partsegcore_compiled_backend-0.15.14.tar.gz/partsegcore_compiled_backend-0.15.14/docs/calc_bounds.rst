PartSegCore_compiled_backend.calc_bounds
========================================

.. automodule:: PartSegCore_compiled_backend.calc_bounds
   :members:
