PartSegCore_compiled_backend.napari_mapping
===========================================

.. automodule:: PartSegCore_compiled_backend.napari_mapping
   :members:
