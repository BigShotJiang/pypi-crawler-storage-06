PartSegCore_compiled_backend.sprawl_utils.find_split
====================================================

.. automodule:: PartSegCore_compiled_backend.sprawl_utils.find_split
   :members:
