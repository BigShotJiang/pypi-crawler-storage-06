from PartSegCore_compiled_backend.calc_bounds import calc_bounds

__all__ = ['calc_bounds']
