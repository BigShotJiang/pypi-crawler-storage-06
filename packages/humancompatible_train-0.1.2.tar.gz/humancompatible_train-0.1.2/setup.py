from setuptools import find_packages, setup

setup(
    name="humancompatible.train",
    version="0.1",
    packages=find_packages(),
)
