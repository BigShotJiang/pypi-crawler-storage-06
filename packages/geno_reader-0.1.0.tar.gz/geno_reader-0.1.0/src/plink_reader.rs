pub(crate) mod bim;
pub(crate) mod bed;
pub(crate) mod fam;