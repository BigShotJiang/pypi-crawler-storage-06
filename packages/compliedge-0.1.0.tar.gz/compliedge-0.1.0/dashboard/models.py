from django.db import models

# The dashboard app might not need models, but we'll keep this file for consistency