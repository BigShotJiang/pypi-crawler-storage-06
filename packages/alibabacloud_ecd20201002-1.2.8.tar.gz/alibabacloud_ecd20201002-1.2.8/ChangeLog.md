2025-08-22 Version: 1.2.7
- Update API GetLoginToken: add request parameters ClientName.


2025-08-22 Version: 1.2.7
- Update API GetLoginToken: add request parameters ClientName.


2025-07-30 Version: 1.2.6
- Update API GetLoginToken: add request parameters AvailableFeatures.


2025-05-08 Version: 1.2.5
- Update API GetLoginToken: add response parameters Body.NickName.


2025-05-07 Version: 1.2.4
- Update API DescribeUserResources: add response parameters Body.Resources.$.Sessions.$.NickName.


2025-04-19 Version: 1.2.3
- Update API StopDesktops: add request parameters Uuid.


2025-03-18 Version: 1.2.2
- Update API ApproveFotaUpdate: add param TargetStatus.
- Update API RebootDesktops: add param OsUpdate.
- Update API StopDesktops: add param OsUpdate.


2025-02-25 Version: 1.2.1
- Update API DescribeUserResources: update response param.


2025-01-24 Version: 1.2.0
- Support API DescribeUserResources.


2025-01-15 Version: 1.1.6
- Update API DescribeSnapshots: update response param.
- Update API ResetSnapshot: add param StopDesktop.


2024-11-24 Version: 1.1.5
- Update API GetConnectionTicket: add param Tag.


2024-11-09 Version: 1.1.4
- Update API DescribeGlobalDesktops: add param Language.
- Update API DescribeGlobalDesktops: update response param.
- Update API ResetSnapshot: add param DesktopId.


2024-08-13 Version: 1.1.3
- Update API DescribeGlobalDesktops: update response param.
- Update API StartRecordContent: update response param.
- Update API StopRecordContent: update response param.


2024-06-04 Version: 1.1.2
- Update API GetLoginToken: update response param.


2024-04-25 Version: 1.1.1
- Update API GetLoginToken: update response param.
- Update API RebootDesktops: add param Uuid.
- Update API StartDesktops: add param Uuid.


2024-03-21 Version: 1.1.0
- Support API GetConnectionTicket.
- Support API QueryEdsAgentReportConfig.
- Support API ReportEdsAgentInfo.


2020-11-16 Version: 1.0.0
- Generated python 2020-10-02 for ecd.

