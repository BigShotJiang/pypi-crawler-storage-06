from .bus import WaveShareBus as Bus, WaveShareBus

__all__ = ["WaveShareBus", "Bus"]
