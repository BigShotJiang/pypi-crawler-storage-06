2025-04-10 Version: 2.0.3
- Update API ConfigLayer4Rule: add request parameters UsTimeout.
- Update API CreateLayer4Rule: add request parameters UsTimeout.
- Update API DescribeLayer4Rules: add response parameters Body.Listeners.$.UsTimeout.


2025-03-12 Version: 2.0.2
- Generated python 2017-12-28 for ddoscoo.

2025-03-12 Version: 2.0.1
- Generated python 2017-12-28 for ddoscoo.

2021-05-13 Version: 1.0.3
- Generated python 2017-12-28 for ddoscoo.

2021-04-01 Version: 1.0.2
- Generated python 2017-12-28 for ddoscoo.

2020-12-30 Version: 2.0.0
- AMP Version Change.

2020-12-21 Version: 1.0.1
- Generated python 2017-12-28 for ddoscoo.

2020-11-30 Version: 1.0.0
- Generated python 2017-12-28 for ddoscoo.

