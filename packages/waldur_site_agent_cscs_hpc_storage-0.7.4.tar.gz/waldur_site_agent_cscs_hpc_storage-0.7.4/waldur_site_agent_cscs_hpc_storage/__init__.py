"""CSCS HPC Storage backend plugin for Waldur Site Agent."""

__version__ = "0.7.0"
