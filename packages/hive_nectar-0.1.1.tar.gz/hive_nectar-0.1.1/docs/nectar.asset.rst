nectar.asset module
===================

.. automodule:: nectar.asset
   :members:
   :show-inheritance:
   :undoc-members:
