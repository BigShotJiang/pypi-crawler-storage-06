#: Object types for object ids
object_type = {}
object_type["null"] = 0
object_type["base"] = 1
object_type["account"] = 2
object_type["OBJECT_TYPE_COUNT"] = 3
