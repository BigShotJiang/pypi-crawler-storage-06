def main():
    print("Go to https://pypi.org/project/telegram-bot-discussion/")


if __name__ == "__main__":
    main()
