Linkapy
-------

.. image:: imgs/linkapy.png
  :width: 400
  :alt: Image generated with Microsoft copilot

Linkapy - a general framework to process and analyze multimodal single-cell data, where at least one modality pertains to DNA methylation data.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   content/installation
   content/notes
   content/usage
   autoapi/index
