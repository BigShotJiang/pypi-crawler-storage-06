from dataclasses import dataclass

from .depth import Depth

@dataclass
class MarketStreams(Depth):
  ...