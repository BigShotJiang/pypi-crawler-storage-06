
Installation
============

There are a few ways to go about installing Theo, which we'll describe
here.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   manual
   fabric
   integration
