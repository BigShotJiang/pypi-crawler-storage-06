
Online Demo
===========

There is an online demo for Theo at https://demo-theo.rattailproject.org/

You can login with credentials:

* username: chuck
* passowrd: admin

This demo integrates with CORE-POS (also a demo) which contains some
sample data.  The data isn't great but should prove the concepts.

The CORE Office demo may be viewed at https://demo-fannie.rattailproject.org/
