
# tailbone-theo

This is an experimental project, as of this writing.  Its purpose is 2-fold:

* hopefully provide a useful app for managing special/case orders for customers
* either way, hopefully provide a good working example of the code

This may also attempt certain aspects of "curbside" and/or "delivery" orders at
some point, we'll see.  Nobody should be holding their breath maybe.

See the [Rattail Project](https://rattailproject.org/) for more info.
