.. automodule:: vivarium.framework.artifact.hdf
