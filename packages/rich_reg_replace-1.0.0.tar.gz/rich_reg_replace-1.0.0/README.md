# rich_reg_replace

Search and replace using regular expressions with a "rich" frontend.

By default, only files with the following extensions are searched:

	.php .css .js .ui .py .toml .conf

