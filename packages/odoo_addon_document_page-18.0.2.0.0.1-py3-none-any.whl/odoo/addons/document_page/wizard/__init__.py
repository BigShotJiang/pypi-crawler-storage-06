# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import document_page_create_menu
from . import document_page_show_diff
