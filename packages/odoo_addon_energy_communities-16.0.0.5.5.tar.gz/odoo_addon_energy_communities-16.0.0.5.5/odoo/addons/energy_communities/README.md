# Energy Communities

Base addon for the basis operacion with energy communities

## Changelog

### v16.0.0.5.5

- Clean commented code

### 2025-05-21

- Added Readme
