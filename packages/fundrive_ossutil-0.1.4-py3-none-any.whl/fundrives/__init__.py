"""
fundrives: 统一的云存储驱动器包

包含各种云存储服务的Python包装器。
"""

# 版本信息
__version__ = "0.1.0"
