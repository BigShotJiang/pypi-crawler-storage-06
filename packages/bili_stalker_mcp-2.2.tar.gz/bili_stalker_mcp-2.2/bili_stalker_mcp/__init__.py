"""
BiliStalkerMCP package

MCP Server for getting Bilibili user video updates
"""

__version__ = "2.2"
__author__ = "222wcnm"
__email__ = "2328072813li@gmail.com"
__license__ = "MIT"
__description__ = "MCP Server for getting Bilibili user video updates"
__url__ = "https://github.com/222wcnm/BiliStalkerMCP"