from importlib.metadata import version

"""Repology MCP Server package."""

__version__ = version("repology-mcp-server")
