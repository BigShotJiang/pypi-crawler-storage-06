from django.apps import AppConfig


class CutoutConfig(AppConfig):
    name = 'daiquiri.cutout'
    label = 'daiquiri_cutout'
    verbose_name = 'Cutout'
