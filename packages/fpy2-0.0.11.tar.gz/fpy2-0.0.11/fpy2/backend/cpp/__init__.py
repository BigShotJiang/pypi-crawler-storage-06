"""
C++ backend: compiler to C++
"""

from .compiler import CppBackend, CppCompileError
