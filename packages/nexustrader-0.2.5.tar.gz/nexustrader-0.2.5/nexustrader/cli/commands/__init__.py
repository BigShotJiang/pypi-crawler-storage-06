"""CLI commands for NexusTrader monitoring."""
