# test
source ./tests/.env
echo 'Testing with pytest'
pytest
