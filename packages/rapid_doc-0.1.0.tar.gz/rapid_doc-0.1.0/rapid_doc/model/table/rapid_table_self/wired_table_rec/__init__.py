# -*- encoding: utf-8 -*-
# @Author: SWHL
# @Contact: liekkaskono@163.com
from .main import WiredTableRecognition
from .utils.utils_table_recover import vis_table

__all__ = ["WiredTableRecognition", "vis_table"]
