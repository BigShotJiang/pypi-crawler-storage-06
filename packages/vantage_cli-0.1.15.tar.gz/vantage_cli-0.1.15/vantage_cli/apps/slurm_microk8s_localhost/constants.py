"""Constants for SLURM MicroK8s localhost deployment app."""
