- Odoo SA \<<info@odoo.com>\>
- Savoir-faire Linux \<<support@savoirfairelinux.com>\>
- Gervais Naoussi \<<gervaisnaoussi@gmail.com>\>
- Leonardo Donelli \<<leonardo.donelli@monksoftware.it>\>
- Maxime Chambreuil \<<mchambreuil@ursainfosystems.com>\>
- Fayez Qandeel
- Iván Todorovich \<<ivan.todorovich@gmail.com>\>
- Jordi Ballester \<<jordi.ballester@forgeflow.com>\>
- Marie Lejeune \<<marie.lejeune@acsone.eu>\>
- [Tecnativa](https://www.tecnativa.com):
  - Vicent Cubells
  - Ernesto Tejeda

Trobz

- Dung Tran \<<dungtd@trobz.com>\>
- Khoi (Kien Kim) <khoikk@trobz.com>
