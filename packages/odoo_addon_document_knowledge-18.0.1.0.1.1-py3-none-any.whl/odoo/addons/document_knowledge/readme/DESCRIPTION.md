This module is the base for any knowledge and document management
application.
