"""Utils

Shared utilities used across modules.

Classes:
- Base: Normalize and sort DataFrames by time columns.
  - get_dataframe: Return the processed DataFrame copy.
"""
