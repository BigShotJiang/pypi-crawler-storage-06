"""Supply Chain Events

Detectors for supply chain–related events and anomalies over shaped timeseries.

Classes:
- None yet: Placeholder module for future supply chain event detectors.
"""

