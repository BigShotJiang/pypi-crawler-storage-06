TARGET_NPUB = "npub18kpn83drge7x9vz4cuhh7xta79sl4tfq55se4e554yj90s8y3f7qa49nps"
TEST_PRIVATE_KEY = "nsec1j4c6269y9w0q2er2xjw8sv2ehyrtfxq3jwgdlxj6qfn8z4gjsq5qfvfk99"
TEST_RELAYS = [
    "wss://relay.damus.io",
    "wss://nos.lol",
    "wss://nostr.chaima.info"
]
