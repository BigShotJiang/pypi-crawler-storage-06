from amsdal.contrib.frontend_configs.conversion.convert import convert_to_frontend_config

__all__ = [
    'convert_to_frontend_config',
]
