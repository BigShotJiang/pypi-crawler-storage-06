# textnormx

Cleaning extracted text (PDF/OCR): PUA bullets (`\uf0b7`), NBSP, quotation marks, dashes,
control characters, summary lines, etc.

## Install

pip install textnormx
