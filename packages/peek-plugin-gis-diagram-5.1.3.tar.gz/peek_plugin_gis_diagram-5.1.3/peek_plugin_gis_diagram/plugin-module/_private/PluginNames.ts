export let gisDiagramFilt = { plugin: "peek_plugin_gis_diagram" };
export let gisDiagramTuplePrefix = "peek_plugin_gis_diagram.";

export let gisDiagramObservableName = "peek_plugin_gis_diagram";
export let gisDiagramActionProcessorName = "peek_plugin_gis_diagram";
export let gisDiagramTupleOfflineServiceName = "peek_plugin_gis_diagram";

export let gisDiagramBaseUrl = "peek_plugin_gis_diagram";

export let gisDiagramModelSetKey = "gisDiagram";
export let gisDiagramCoordSetKey = "gisDiagram";

export let modelSetKey = gisDiagramModelSetKey;
