# README

batches 数据通用预处理和数据存储结构
