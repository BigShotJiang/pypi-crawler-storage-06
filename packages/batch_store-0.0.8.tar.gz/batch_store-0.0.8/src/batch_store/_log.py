import logging

from util_common.logger import setup_logger

setup_logger()

logger = logging.getLogger('batch_store')
