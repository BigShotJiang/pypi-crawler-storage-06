# Changelog

## 0.1.1 (2025-09-22)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/AgentbaseHQ/agentbase-python/compare/v0.1.0...v0.1.1)

## 0.1.0 (2025-09-22)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/AgentbaseHQ/agentbase-python/compare/v0.0.1...v0.1.0)

### Chores

* configure new SDK language ([2e448ce](https://github.com/AgentbaseHQ/agentbase-python/commit/2e448ce075c5a14429adf3f0577fd1f357ed9f4f))
* update SDK settings ([812f1a4](https://github.com/AgentbaseHQ/agentbase-python/commit/812f1a4361f2319ea3339fa806c9e46c0ee1ebb2))
* update SDK settings ([f2fe6b8](https://github.com/AgentbaseHQ/agentbase-python/commit/f2fe6b84d51c36039583b2993fca76c3ad4f6125))
* update SDK settings ([cc64773](https://github.com/AgentbaseHQ/agentbase-python/commit/cc64773a3632a48301cdf7e505015d317fbc5aec))
