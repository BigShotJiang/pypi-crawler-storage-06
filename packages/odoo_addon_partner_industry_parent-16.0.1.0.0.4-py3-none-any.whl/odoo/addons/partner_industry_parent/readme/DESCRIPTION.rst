This module add a parent relation to the partner industry
