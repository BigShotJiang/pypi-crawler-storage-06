from . import res_partner_industry
from . import res_partner
