class ConfigurationError(Exception):
    pass


class InvalidVideoFile(Exception):
    pass
