from deepbookpy.version import __version__
