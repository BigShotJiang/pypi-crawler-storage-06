from .rand import rand
