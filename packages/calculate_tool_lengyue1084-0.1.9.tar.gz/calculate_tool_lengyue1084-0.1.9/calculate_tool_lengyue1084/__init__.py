"""
calculate_tool_lengyue1084 Package

一个简单的计算工具包，提供基本的数学运算和问候功能。
"""

__version__ = "0.1.9"
__author__ = "lengyue1084"
__email__ = "95695864@qq.com"

# 从main.py导入主要功能
from .main import lucky_star, num_add, greeting