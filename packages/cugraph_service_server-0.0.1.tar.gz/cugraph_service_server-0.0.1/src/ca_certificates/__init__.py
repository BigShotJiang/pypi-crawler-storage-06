__version__ = "0.0.1"

def info():
    return "This is a dummy cugraph-service-server package for PyPI."
