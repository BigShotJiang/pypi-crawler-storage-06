"""bioimageio.spec extensions for bioimage.io community partners"""

# todo: if not moving to its own module, add the dependency to a 'partner' extra in setup.py
