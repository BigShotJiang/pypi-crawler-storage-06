from main  import *

def handler(event, context):
    # 调用technical_analysis.py中的主函数
    return main()