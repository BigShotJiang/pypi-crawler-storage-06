"""PR Prompt - Generate pull request review prompts for LLMs."""

from .generator import PrPromptGenerator

__version__ = "0.5.0"
__all__ = ["PrPromptGenerator"]
