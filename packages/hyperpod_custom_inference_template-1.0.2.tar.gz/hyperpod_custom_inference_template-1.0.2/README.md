
# hyperpod-custom-inference-template

## Installation
`pip install hyperpod-custom-inference-template`

## Overview 
This package provides the configuration schema for Custom Inference Operator.


