from acai_aws.common.records.requirements import requirements as firehose_requirements


requirements = firehose_requirements
