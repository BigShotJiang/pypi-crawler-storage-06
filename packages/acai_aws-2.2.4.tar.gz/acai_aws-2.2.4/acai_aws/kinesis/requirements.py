from acai_aws.common.records.requirements import requirements as kinesis_requirements


requirements = kinesis_requirements
