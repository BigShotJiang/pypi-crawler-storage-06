from acai_aws.common.records.requirements import requirements as s3_requirements


requirements = s3_requirements
