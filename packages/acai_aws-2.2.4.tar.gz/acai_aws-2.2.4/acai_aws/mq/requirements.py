from acai_aws.common.records.requirements import requirements as mq_requirements


requirements = mq_requirements
