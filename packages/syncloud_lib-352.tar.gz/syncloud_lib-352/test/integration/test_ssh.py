from syncloudlib.integration.ssh import run_scp

def test_import():
    assert True