# flake8: noqa
from .cmip import parse_cmip6
