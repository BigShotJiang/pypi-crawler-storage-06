# Calculator

This is a simple example project.
