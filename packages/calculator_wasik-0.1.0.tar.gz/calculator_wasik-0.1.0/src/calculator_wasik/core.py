def add_one(number: int):
    return number + 1
