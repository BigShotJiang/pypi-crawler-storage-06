.. ExpertOp4Grid documentation master file, created by
   sphinx-quickstart on Thu Sep 17 11:13:57 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ExpertOp4Grid's documentation!
=========================================

.. toctree::
   :maxdepth: 2
   :caption: Starting kit

   README.rst
   INSTALL.rst
   GETTING_STARTED.rst

.. toctree::
   :maxdepth: 2
   :caption: Algorithms documentation

   DESCRIPTION.rst
   DETAILS.rst
