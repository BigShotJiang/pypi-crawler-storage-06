otcextensions.sdk.cce.v3.cluster
================================

.. automodule:: otcextensions.sdk.cce.v3.cluster

The CCE Cluster Class
---------------------

The ``Cluster`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.cce.v3.cluster.Cluster
   :members:

.. autoclass:: otcextensions.sdk.cce.v3.cluster.ClusterSpec
   :members:

.. autoclass:: otcextensions.sdk.cce.v3.cluster.HostNetworkSpec
   :members:

.. autoclass:: otcextensions.sdk.cce.v3.cluster.EniNetworkSpec
   :members:

.. autoclass:: otcextensions.sdk.cce.v3.cluster.StatusSpec
   :members:
