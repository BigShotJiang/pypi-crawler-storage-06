otcextensions.sdk.cce.v3.cluster_node
=====================================

.. automodule:: otcextensions.sdk.cce.v3.cluster_node

The CCE Cluster Host (Node) Class
---------------------------------

The ``ClusterHost`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.cce.v3.cluster_node.ClusterNode
   :members:
