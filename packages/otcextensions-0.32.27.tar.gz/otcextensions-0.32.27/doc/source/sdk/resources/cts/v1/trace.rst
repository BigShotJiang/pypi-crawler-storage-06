otcextensions.sdk.cts.v1.trace
==============================

.. automodule:: otcextensions.sdk.cts.v1.trace

The CTS Trace Class
-------------------

The ``Trace`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.cts.v1.trace.Trace
   :members:
