openstack.identity.v3.user
==========================

.. automodule:: openstack.identity.v3.user

The User Class
--------------

The ``User`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.user.User
   :members:
