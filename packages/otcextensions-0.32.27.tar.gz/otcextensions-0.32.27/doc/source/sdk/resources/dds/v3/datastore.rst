otcextensions.sdk.dds.v3.datastore
===================================

.. automodule:: otcextensions.sdk.dds.v3.datastore

The Datastore Class
-------------------

The ``Datastore`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dds.v3.datastore.Datastore
   :members:
