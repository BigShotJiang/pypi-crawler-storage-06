otcextensions.sdk.dds.v3.recycle_instance
==========================================

.. automodule:: otcextensions.sdk.dds.v3.recycle_instance

The RecycleInstance Class
----------------------------

The ``RecycleInstance`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dds.v3.recycle_instance.RecycleInstance
   :members:
