otcextensions.sdk.dcs.v1.backup
=================================

.. automodule:: otcextensions.sdk.dcs.v1.backup

The DCS Backup Class
--------------------

The ``Backup`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcs.v1.backup.Backup
   :members:
