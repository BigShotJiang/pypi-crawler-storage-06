otcextensions.sdk.dcs.v1.restore_record
=======================================

.. automodule:: otcextensions.sdk.dcs.v1.restore_record

The DCS RestoreRecord Class
---------------------------

The ``RestoreRecord`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcs.v1.restore_record.RestoreRecord
   :members:
