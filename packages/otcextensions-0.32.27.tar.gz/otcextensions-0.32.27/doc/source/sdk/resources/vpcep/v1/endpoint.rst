otcextensions.sdk.vpecp.v1.endpoint
===================================

.. automodule:: otcextensions.sdk.vpcep.v1.endpoint

The VPCEP Endpoint Class
------------------------

The ``Endpoint`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpcep.v1.endpoint.Endpoint
   :members:
