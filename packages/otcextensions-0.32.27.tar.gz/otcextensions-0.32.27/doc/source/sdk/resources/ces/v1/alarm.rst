otcextensions.sdk.ces.v1.alarm
==============================

.. automodule:: otcextensions.sdk.ces.v1.alarm

The CES Alarm Rule Class
------------------------

The ``Alarm`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.ces.v1.alarm.Alarm
   :members:
