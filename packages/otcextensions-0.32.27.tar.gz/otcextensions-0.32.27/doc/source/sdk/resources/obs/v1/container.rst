otcextensions.sdk.obs.v1.container
==================================

.. automodule:: otcextensions.sdk.obs.v1.container

The OBS Container (Bucket) Class
--------------------------------

The ``Container`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.obs.v1.container.Container
   :members:
