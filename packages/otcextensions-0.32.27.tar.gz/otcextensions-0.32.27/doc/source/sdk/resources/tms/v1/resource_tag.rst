otcextensions.sdk.tms.v1.resource_tag
=====================================

.. automodule:: otcextensions.sdk.tms.v1.resource_tag

The Resource Tag Class
----------------------

The ``ResourceTag`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.tms.v1.resource_tag.ResourceTag
   :members:
