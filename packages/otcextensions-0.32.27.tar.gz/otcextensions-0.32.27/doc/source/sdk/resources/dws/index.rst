DWS Resources
=============

.. toctree::
   :maxdepth: 1

   v1/cluster
   v1/snapshot
   v1/flavor
   v1/tag
