otcextensions.sdk.dws.v1.cluster
================================

.. automodule:: otcextensions.sdk.dws.v1.cluster

The DWS Cluster Class
---------------------

The ``Cluster`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.dws.v1.cluster.Cluster
   :members:
