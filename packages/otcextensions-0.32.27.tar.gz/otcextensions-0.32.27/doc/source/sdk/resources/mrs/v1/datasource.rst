otcextensions.sdk.mrs.v1.datasource
===================================

.. automodule:: otcextensions.sdk.mrs.v1.datasource

The MRS Datasource Class
------------------------

The ``Datasource`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.mrs.v1.datasource.Datasource
   :members:
