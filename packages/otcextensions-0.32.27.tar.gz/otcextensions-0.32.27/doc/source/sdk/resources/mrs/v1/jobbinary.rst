otcextensions.sdk.mrs.v1.jobbinary
==================================

.. automodule:: otcextensions.sdk.mrs.v1.jobbinary

The MRS Jobbinary Class
-----------------------

The ``Jobbinary`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.mrs.v1.jobbinary.Jobbinary
   :members:
