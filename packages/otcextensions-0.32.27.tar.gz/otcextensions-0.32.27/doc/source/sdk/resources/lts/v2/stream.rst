otcextensions.sdk.lts.v2.stream
===============================

.. automodule:: otcextensions.sdk.lts.v2.stream

The LTS Stream Class
--------------------

The ``Stream`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.lts.v2.stream.Stream
   :members:
