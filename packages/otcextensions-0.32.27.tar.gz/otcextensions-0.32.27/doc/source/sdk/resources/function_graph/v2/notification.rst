otcextensions.sdk.function_graph.v2.async_notification
======================================================

.. automodule:: otcextensions.sdk.function_graph.v2.async_notification

The Notification Class
----------------------

The ``Notification`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.async_notification.Notification
   :members:

The Requests Class
------------------

The ``Requests`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.async_notification.Requests
   :members:
