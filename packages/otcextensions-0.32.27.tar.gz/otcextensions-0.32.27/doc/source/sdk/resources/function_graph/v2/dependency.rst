otcextensions.sdk.function_graph.v2.dependency
==============================================

.. automodule:: otcextensions.sdk.function_graph.v2.dependency

The Dependency Class
--------------------

The ``Dependency`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.dependency.Dependency
   :members:
