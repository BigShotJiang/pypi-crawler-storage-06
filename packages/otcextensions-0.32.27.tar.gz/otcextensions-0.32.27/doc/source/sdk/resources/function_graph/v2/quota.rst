otcextensions.sdk.function_graph.v2.quota
=========================================

.. automodule:: otcextensions.sdk.function_graph.v2.quota

The Quota Class
---------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.quota.Quota
   :members:
