otcextensions.sdk.function_graph.v2.export_function
===================================================

.. automodule:: otcextensions.sdk.function_graph.v2.export_function

The Export Class
----------------

The ``Export`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.export_function.Export
   :members:
