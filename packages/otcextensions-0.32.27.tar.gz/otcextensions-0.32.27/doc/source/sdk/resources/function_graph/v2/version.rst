otcextensions.sdk.function_graph.v2.version
===========================================

.. automodule:: otcextensions.sdk.function_graph.v2.version

The Version Class
-----------------

The ``Version`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.version.Version
   :members:
