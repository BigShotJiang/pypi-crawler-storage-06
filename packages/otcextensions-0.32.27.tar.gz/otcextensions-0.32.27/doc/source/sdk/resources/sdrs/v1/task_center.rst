otcextensions.sdk.sdrs.v1.task_center.FailedTask
================================================

.. automodule:: otcextensions.sdk.sdrs.v1.task_center

The SDRS Task Center Class
--------------------------

The ``FailedTask`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.sdrs.v1.task_center.FailedTask
   :members:
