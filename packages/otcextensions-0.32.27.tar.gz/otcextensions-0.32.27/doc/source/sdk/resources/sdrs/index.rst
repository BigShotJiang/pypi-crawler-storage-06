Storage Disaster Recovery Service Resources
===========================================

.. toctree::
   :maxdepth: 1

   v1/active_domains
   v1/dr_drill
   v1/job
   v1/protected_instance
   v1/protection_group
   v1/quota
   v1/replication_pair
   v1/task_center
