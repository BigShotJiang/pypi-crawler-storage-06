otcextensions.sdk.nat.v2.dnat
=============================

.. automodule:: otcextensions.sdk.nat.v2.dnat

The DNAT Rule Class
--------------------

The ``Dnat`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.nat.v2.dnat.Dnat
   :members:
