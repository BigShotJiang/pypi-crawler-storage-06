otcextensions.sdk.dns.v2.nameserver
===================================

.. automodule:: otcextensions.sdk.dns.v2.nameserver

The DNS Nameserver Class
------------------------

The ``Nameserver`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dns.v2.nameserver.NameServer
   :members:
