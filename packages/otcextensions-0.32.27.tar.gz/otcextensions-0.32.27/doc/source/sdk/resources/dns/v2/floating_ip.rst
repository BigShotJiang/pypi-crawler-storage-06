otcextensions.sdk.dns.v2.floating_ip
====================================

.. automodule:: otcextensions.sdk.dns.v2.floating_ip

The DNS FloatingIP Class
------------------------

The ``floating_ip`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dns.v2.floating_ip.FloatingIP
   :members:
