otcextensions.sdk.auto_scaling.v1.policy
========================================

.. automodule:: otcextensions.sdk.auto_scaling.v1.policy

The AS Policy Class
-------------------

The ``Policy`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.auto_scaling.v1.policy.Policy
   :members:
