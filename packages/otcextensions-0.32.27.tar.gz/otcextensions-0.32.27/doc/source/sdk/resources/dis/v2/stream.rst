otcextensions.sdk.dis.v2.stream
================================

.. automodule:: otcextensions.sdk.dis.v2.stream

The DIS Stream Class
--------------------

The ``Stream`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.dis.v2.stream.Stream
   :members:
