otcextensions.sdk.dis.v2.app
============================

.. automodule:: otcextensions.sdk.dis.v2.app

The DIS App Class
-----------------

The ``App`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.dis.v2.app.App
   :members:
