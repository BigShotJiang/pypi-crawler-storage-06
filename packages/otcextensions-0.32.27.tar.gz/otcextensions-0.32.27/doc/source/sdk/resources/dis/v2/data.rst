otcextensions.sdk.dis.v2.data
=============================

.. automodule:: otcextensions.sdk.dis.v2.data

The DIS Data Class
------------------

The ``Data`` class inherits from
:class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.dis.v2.data.Data
   :members:
