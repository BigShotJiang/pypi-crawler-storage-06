otcextensions.sdk.vpc.v1.route
================================

.. automodule:: otcextensions.sdk.vpc.v1.route

The VPC Route Class
-------------------

The ``Route`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpc.v1.route.Route
   :members:
