otcextensions.sdk.modelartsv2.v2.dataset_import_task
====================================================

.. automodule:: otcextensions.sdk.modelartsv2.v2.dataset_import_task

The ModelArts DatasetImportTask Class
-------------------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv2.v2.dataset_import_task.DatasetImportTask
   :members:
