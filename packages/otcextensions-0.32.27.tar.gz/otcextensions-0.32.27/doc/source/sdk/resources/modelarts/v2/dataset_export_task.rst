otcextensions.sdk.modelartsv2.v2.dataset_export_task
====================================================

.. automodule:: otcextensions.sdk.modelartsv2.v2.dataset_export_task

The ModelArts DatasetExportTask Class
-------------------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv2.v2.dataset_export_task.DatasetExportTask
   :members:
