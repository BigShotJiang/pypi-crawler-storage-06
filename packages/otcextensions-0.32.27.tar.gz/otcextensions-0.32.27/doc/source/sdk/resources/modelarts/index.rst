ModelArts Resources
===================

.. toctree::
   :maxdepth: 1

   v1/builtin_model
   v1/devenv
   v1/model
   v1/service
   v1/training_job
   v1/training_job_config
   v1/training_job_version
   v2/dataset
   v2/dataset_export_task
   v2/dataset_import_task
   v2/dataset_label
   v2/dataset_sample
   v2/dataset_sync
