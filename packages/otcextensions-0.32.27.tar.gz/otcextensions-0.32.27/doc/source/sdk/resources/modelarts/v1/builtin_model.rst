otcextensions.sdk.modelartsv1.v1.builtin_model
==============================================

.. automodule:: otcextensions.sdk.modelartsv1.v1.builtin_model

The modelarts BuiltInModel Class
---------------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv1.v1.builtin_model.BuiltInModel
   :members:
