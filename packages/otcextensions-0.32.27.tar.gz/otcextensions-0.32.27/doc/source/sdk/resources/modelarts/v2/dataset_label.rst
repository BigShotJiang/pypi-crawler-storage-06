otcextensions.sdk.modelartsv2.v2.dataset_label
==============================================

.. automodule:: otcextensions.sdk.modelartsv2.v2.dataset_label

The ModelArts DatasetLabel Class
--------------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv2.v2.dataset_label.DatasetLabel
   :members:
