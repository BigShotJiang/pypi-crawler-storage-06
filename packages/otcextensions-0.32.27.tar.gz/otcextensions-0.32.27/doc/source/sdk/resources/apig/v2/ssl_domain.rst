otcextensions.sdk.apig.v2.ssl_domain
====================================

.. automodule:: otcextensions.sdk.apig.v2.ssl_domain

The SslDomain Class
-------------------
The ``SslDomain`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.ssl_domain.SslDomain
   :members:
