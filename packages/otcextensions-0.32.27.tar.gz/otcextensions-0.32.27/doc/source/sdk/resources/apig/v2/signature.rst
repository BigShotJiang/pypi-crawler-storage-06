otcextensions.sdk.apig.v2.signature
===================================

.. automodule:: otcextensions.sdk.apig.v2.signature

The Signature Class
-------------------

The ``Signature`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.signature.Signature
   :members:
