otcextensions.sdk.apig.v2.resource_query
========================================

.. automodule:: otcextensions.sdk.apig.v2.resource_query

The ApiQuantities Class
-----------------------

The ``ApiQuantities`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.resource_query.ApiQuantities
   :members:

The ApiGroupQuantities Class
----------------------------

The ``ApiGroupQuantities`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.resource_query.ApiGroupQuantities
   :members:

The AppQuantities Class
-----------------------

The ``AppQuantities`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.resource_query.AppQuantities
   :members:
