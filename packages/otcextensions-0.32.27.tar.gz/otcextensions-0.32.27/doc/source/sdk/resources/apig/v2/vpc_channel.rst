otcextensions.sdk.apig.v2.vpc_channel
=====================================

.. automodule:: otcextensions.sdk.apig.v2.vpc_channel

The VpcChannel Class
--------------------

The ``VpcChannel`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.vpc_channel.VpcChannel
   :members:

The MicroServiceCreateSpec Class
--------------------------------

The ``MicroServiceCreateSpec`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.vpc_channel.MicroServiceCreateSpec
   :members:

The MicroServiceInfoCCEBaseSpec Class
-------------------------------------

The ``MicroServiceInfoCCEBaseSpec`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.vpc_channel.MicroServiceInfoCCEBaseSpec
   :members:

The MicroServiceInfoCSEBaseSpec Class
-------------------------------------

The ``MicroServiceInfoCSEBaseSpec`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.vpc_channel.MicroServiceInfoCSEBaseSpec
   :members:

The VpcHealthConfigSpec Class
-----------------------------

The ``VpcHealthConfigSpec`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.vpc_channel.VpcHealthConfigSpec
   :members:

The MemberInfoSpec Class
------------------------

The ``MemberInfoSpec`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.vpc_channel.MemberInfoSpec
   :members:

The MemberGroupCreateSpec Class
-------------------------------

The ``MemberGroupCreateSpec`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.vpc_channel.MemberGroupCreateSpec
   :members:

The MicroserviceLabelSpec Class
-------------------------------

The ``MicroserviceLabelSpec`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.vpc_channel.MicroserviceLabelSpec
   :members:
