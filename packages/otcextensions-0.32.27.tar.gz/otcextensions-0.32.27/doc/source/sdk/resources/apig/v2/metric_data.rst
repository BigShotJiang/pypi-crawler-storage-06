otcextensions.sdk.apig.v2.metric_data
=====================================

.. automodule:: otcextensions.sdk.apig.v2.metric_data

The MetricData Class
--------------------
The ``MetricData`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.metric_data.MetricData
   :members:
