otcextensions.sdk.smn.v2.sms
============================

.. automodule:: otcextensions.sdk.smn.v2.sms

The SMN Sms Class
-----------------

The ``Sms`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.smn.v2.sms.Sms
   :members:
