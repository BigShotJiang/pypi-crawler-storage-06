otcextensions.sdk.smn.v2.subscription
=====================================

.. automodule:: otcextensions.sdk.smn.v2.subscription

The SMN Subscription Class
--------------------------

The ``Subscription`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.smn.v2.subscription.Subscription
   :members:
