otcextensions.sdk.cbr.v3.backup
===============================

.. automodule:: otcextensions.sdk.cbr.v3.backup

The CBR Backup Class
--------------------

The ``Backup`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.cbr.v3.backup.Backup
   :members:

.. autoclass:: otcextensions.sdk.cbr.v3.backup.ExtendInfo
   :members:

.. autoclass:: otcextensions.sdk.cbr.v3.backup.AppCSpec
   :members:
