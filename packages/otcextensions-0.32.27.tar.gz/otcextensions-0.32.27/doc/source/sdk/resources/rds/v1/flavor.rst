otcextensions.sdk.rds.v1.flavor
===============================

.. automodule:: otcextensions.sdk.rds.v1.flavor

The Flavor Class
----------------

The ``Flavor`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.rds.v1.flavor.Flavor
   :members:
