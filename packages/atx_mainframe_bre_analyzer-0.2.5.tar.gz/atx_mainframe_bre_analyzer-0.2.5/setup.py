"""
Setup script for atx-mainframe-bre-analyzer.
Uses setuptools with configuration in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
