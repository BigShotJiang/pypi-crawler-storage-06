## [v0.1.20](https://pypi.org/project/amsdal-glue-connections/0.1.20/) - 2025-09-21

### Fixed

- Fix for nested transactions in SQLite connection during schema migration
