# setuptools read this version through setup.py
# scripts/make-archive.sh updates this for `apkg make-archive`
__version__ = '0.7.0'
