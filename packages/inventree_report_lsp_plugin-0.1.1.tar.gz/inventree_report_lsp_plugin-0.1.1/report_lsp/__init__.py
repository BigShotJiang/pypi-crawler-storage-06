# -*- coding: utf-8 -*-

PLUGIN_VERSION = "0.1.1"
