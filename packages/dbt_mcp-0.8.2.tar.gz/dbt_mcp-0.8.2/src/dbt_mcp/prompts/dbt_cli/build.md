The dbt build command will:

- run models
- test tests
- snapshot snapshots
- seed seeds

In DAG order.
