"""
__init__.py
This file marks this directory as a Python package.
Imports key classes and functions for easy external use.
"""