import logging.config

LOGGING_CONF = {
    'version': 1,
    'disable_existing_loggers': False,  # to make sure this config is used
    'formatters': {
        'default': {
            'format': '%(asctime)s,%(msecs)01d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
            'datefmt': '%Y-%m-%d %H:%M:%S',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'default',
            'level': 'DEBUG',
            'stream': 'ext://sys.stdout'
        },
    },
    'loggers': {
        '': {  # this root logger is used for everything without a specific logger
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'Node': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}


def init():
    logging.config.dictConfig(LOGGING_CONF)


init()
