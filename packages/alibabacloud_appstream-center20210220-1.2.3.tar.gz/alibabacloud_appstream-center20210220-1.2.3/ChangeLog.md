2025-04-27 Version: 1.2.2
- Update API GetLoginToken: add request parameters ClientName.
- Update API GetLoginToken: add request parameters ProfileRegion.
- Update API GetLoginToken: add response parameters Body.NickName.


2024-12-13 Version: 1.2.1
- Update API FindIdpListByLoginIdentifier: update param ClientIp.
- Update API FindIdpListByLoginIdentifier: update param ClientIp.


2024-12-11 Version: 1.2.0
- Support API GetStsToken.
- Update API GetLoginToken: update param AvailableFeatures.
- Update API GetLoginToken: update param OfficeSiteId.
- Update API GetLoginToken: update param TokenCode.
- Update API GetLoginToken: update param UmidToken.
- Update API RefreshLoginToken: update param ProfileRegion.


2024-11-03 Version: 1.1.2
- Update API FindIdpListByLoginIdentifier: add param AvailableFeatures.
- Update API FindIdpListByLoginIdentifier: update response param.
- Update API GetLoginToken: add param AvailableFeatures.
- Update API GetLoginToken: add param MfaType.
- Update API GetLoginToken: update response param.


2024-08-13 Version: 1.1.1
- Generated python 2021-02-20 for appstream-center.

2024-07-22 Version: 1.1.0
- Support API FindIdpListByLoginIdentifier.
- Support API GetLoginToken.
- Update API RefreshLoginToken: add param ProfileRegion.


2024-03-23 Version: 1.0.0
- Generated python 2021-02-20 for appstream-center.

