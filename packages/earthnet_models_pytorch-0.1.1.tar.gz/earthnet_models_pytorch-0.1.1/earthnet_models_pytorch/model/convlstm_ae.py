"""ConvLSTM_ae
    ConvLSTM with an encoding-decoding architecture
"""

import argparse
import ast
import sys
from typing import Optional, Union

import torch
import torch.nn as nn
from earthnet_models_pytorch.model.layer_utils import inverse_permutation
from earthnet_models_pytorch.utils import str2bool

# Mapping of class labels to indices
class_mapping = {
    10: 0,
    20: 1,
    30: 2,
    40: 3,
    50: 4,
    60: 5,
    70: 6,
    80: 7,
    90: 8,
    95: 9,
    100: 10,
}


class ConvLSTMCell(nn.Module):
    def __init__(self, input_dim, hidden_dim, kernel_size, bias):
        """
        Initialize ConvLSTM cell.
        Parameters
        ----------
        input_dim: int
            Number of channels of input tensor.
        hidden_dim: int
            Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Number of channels of hidden state.
        kernel_size          Num