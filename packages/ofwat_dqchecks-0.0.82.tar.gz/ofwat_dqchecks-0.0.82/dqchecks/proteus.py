"""
Proteus code
"""
