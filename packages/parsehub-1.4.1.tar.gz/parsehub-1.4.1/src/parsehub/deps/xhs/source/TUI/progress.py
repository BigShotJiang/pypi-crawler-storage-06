from textual.app import ComposeResult
from textual.screen import Screen

__all__ = ["Progress"]


class Progress(Screen):
    def compose(self) -> ComposeResult:
        pass
