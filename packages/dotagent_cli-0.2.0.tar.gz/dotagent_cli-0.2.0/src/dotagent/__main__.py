"""Entry point for running dotclaude as a module."""

from dotagent.cli import app

if __name__ == "__main__":
    app()
