"""Universal CLI tool for managing AI agent configurations across different platforms."""

__version__ = "0.1.5"
__author__ = "FradSer"
__email__ = "fradser@gmail.com"
