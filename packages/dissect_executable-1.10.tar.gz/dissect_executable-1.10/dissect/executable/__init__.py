from dissect.executable.elf.elf import ELF
from dissect.executable.pe.pe import PE

__all__ = [
    "ELF",
    "PE",
]
