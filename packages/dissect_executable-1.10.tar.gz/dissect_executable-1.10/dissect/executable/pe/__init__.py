from dissect.executable.pe.pe import PE

__all__ = [
    "PE",
]
