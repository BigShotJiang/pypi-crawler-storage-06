# Process reference

-----

::: dda.utils.process.SubprocessRunner
    options:
      members:
      - run
      - capture
      - wait
      - redirect
      - exit_with
      - attach
      - spawn_daemon

::: dda.utils.process.EnvVars
    options:
      show_if_no_docstring: false
      merge_init_into_class: true
