# guilite/__init__.py
from .reportgenerator.simulatorapp import SimulatorApp
# Eksporter eventuelt flere symboler her etter behov
