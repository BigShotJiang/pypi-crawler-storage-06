"""AgentSwarm - Multi-Agent Orchestration CLI Framework"""

__version__ = "0.1.0"
__author__ = "AgentSwarm Team"
__description__ = "Enterprise-ready multi-agent orchestration and deployment system"