"""
Adsorption energy analysis module.
"""

from catbench.adsorption.analysis.analysis import AdsorptionAnalysis

__all__ = ['AdsorptionAnalysis']