"""
Adsorption energy calculation module.
"""

from catbench.adsorption.calculation.calculation import AdsorptionCalculation

__all__ = ['AdsorptionCalculation']