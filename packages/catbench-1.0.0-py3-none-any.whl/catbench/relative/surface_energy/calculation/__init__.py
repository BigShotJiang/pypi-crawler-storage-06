"""
Surface energy calculation module.
"""

from catbench.relative.surface_energy.calculation.calculation import RelativeEnergyCalculation

__all__ = ['RelativeEnergyCalculation']