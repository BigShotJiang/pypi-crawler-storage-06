"""
EOS data preprocessing module.
"""

from catbench.eos.data.vasp import eos_vasp_preprocessing

__all__ = ["eos_vasp_preprocessing"]