"""
EOS calculation module.
"""

from catbench.eos.calculation.calculation import EOSCalculation

__all__ = ["EOSCalculation"]