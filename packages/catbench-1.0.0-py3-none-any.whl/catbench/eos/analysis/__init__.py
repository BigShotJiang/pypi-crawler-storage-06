"""
EOS analysis module.
"""

from catbench.eos.analysis.analysis import EOSAnalysis

__all__ = ["EOSAnalysis"]