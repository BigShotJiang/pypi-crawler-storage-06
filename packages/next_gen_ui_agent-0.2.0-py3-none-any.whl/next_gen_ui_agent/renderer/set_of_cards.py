from next_gen_ui_agent.renderer.base_renderer import (
    RendererStrategyBaseWithArrayValueFileds,
)


class SetOfCardsRenderStrategy(RendererStrategyBaseWithArrayValueFileds):
    COMPONENT_NAME = "set-of-cards"
