from next_gen_ui_agent.renderer.base_renderer import (
    RendererStrategyBaseWithArrayValueFileds,
)


class TableRenderStrategy(RendererStrategyBaseWithArrayValueFileds):
    COMPONENT_NAME = "table"
