from next_gen_ui_agent.renderer.base_renderer import RenderStrategyBase


class AudioPlayerRenderStrategy(RenderStrategyBase):
    COMPONENT_NAME = "audio-player"
