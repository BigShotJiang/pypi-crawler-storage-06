from next_gen_ui_agent.renderer.base_renderer import RenderStrategyBase


class OneCardRenderStrategy(RenderStrategyBase):
    COMPONENT_NAME = "one-card"
