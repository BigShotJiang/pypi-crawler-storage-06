from next_gen_ui_agent.renderer.base_renderer import RenderStrategyBase


class HandBuildComponentRenderStrategy(RenderStrategyBase):
    COMPONENT_NAME = "hand-build-component"
