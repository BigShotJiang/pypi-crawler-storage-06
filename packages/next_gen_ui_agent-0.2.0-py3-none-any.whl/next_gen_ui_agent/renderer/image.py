from next_gen_ui_agent.renderer.base_renderer import RenderStrategyBase


class ImageRenderStrategy(RenderStrategyBase):
    COMPONENT_NAME = "image"
