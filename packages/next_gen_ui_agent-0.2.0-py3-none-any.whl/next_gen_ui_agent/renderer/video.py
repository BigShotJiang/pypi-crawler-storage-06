from next_gen_ui_agent.renderer.base_renderer import RenderStrategyBase


class VideoRenderStrategy(RenderStrategyBase):
    COMPONENT_NAME = "video-player"
