"""Feature based registration"""
