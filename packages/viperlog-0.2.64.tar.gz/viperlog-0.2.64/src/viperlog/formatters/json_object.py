
from .dict_formatter import DictFormatter


class JsonObjectFormatter(DictFormatter):
    """
    Just an empty subclass of DictFormatter
    for naming purposes
    """
    #def __init__(self):
    #    super().__init__()

