import web_diver as _WEBDIVER

_c0x_x0 = 'https://www.bondfaro.com.br/notebook'

_WEBDIVER.www_diver_add_task(_c0x_x0)
_WEBDIVER.www_diver_start('db_plugwarez_0x1.sqlite','_text')
