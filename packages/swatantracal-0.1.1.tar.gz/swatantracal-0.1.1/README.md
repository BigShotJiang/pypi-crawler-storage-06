# Swatantracal

A simple calculator package for Python.  
Perform basic arithmetic operations (addition, subtraction, multiplication, division) directly from your Python code or via the command line.

---

## Installation

You can install the package from [PyPI](https://pypi.org/project/Swatantracal/):

```bash
pip install Swatantracal
```
