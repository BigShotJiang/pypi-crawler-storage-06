def main():
    print("Hello from lionagi!")


if __name__ == "__main__":
    main()
