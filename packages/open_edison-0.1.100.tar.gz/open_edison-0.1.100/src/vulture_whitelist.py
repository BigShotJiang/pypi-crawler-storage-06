from src.oauth_override import OpenEdisonOAuth

OpenEdisonOAuth.redirect_handler  # noqa: B018 unused method (src/oauth_override.py:7)
