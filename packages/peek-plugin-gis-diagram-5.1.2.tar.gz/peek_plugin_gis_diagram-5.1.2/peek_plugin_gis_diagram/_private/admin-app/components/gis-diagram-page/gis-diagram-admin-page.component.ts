
import { Component, ChangeDetectionStrategy } from "@angular/core";

@Component({
    selector: "gisDiagram-admin",
    templateUrl: "gis-diagram-admin-page.component.html",
    styleUrls: ["gis-diagram-admin-page.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class GisDiagramAdminPageComponent {
    constructor() {}
}