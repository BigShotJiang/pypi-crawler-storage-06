from abc import ABCMeta, abstractmethod


class GisDiagramApiABC(metaclass=ABCMeta):
    pass
