=======================
Peek GIS Diagram Plugin
=======================

This is a Peek Plugin, from the gisDiagram.