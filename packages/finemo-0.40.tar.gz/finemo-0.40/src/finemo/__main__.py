"""
Entry point for running finemo's CLI as a module via 'python -m finemo'.
"""

from .main import cli

if __name__ == "__main__":
    cli()
