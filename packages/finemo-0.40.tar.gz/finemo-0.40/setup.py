from setuptools import setup

# Empty setup.py for compatibility with pip<21.1
# See pyproject.toml for package configuration

setup()
