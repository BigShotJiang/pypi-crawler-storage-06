from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    name = "vintasend_django"
