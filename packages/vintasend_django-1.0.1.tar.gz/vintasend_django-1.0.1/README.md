# VintaSend Django

Django implementations for VintaSend