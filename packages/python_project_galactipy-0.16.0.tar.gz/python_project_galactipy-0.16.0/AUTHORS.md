# Credits

## Main Developer

- The Galactipy Contributors <contact@galactipy.com>

## Contributors

We don't have contributors... yet. Why not be the first?
