
from python_project.tui.main_window import TerminalApp

app = TerminalApp()
app.run()
