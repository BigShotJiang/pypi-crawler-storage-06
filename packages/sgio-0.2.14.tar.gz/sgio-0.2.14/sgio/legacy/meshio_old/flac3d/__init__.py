from ._flac3d import read, write

__all__ = ["read", "write"]
