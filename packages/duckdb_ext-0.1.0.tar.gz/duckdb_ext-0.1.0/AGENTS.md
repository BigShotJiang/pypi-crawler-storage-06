## Code style
- Python 3.9 compatible
- Full type hints