"""File organizer package."""

from .core import organize, DEFAULT_GROUPS

__all__ = ["organize", "DEFAULT_GROUPS"]
