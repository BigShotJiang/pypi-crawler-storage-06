
| Origin | Type | Severity | Location | Description | Submitter |
|---|---|---|---|---|---|
|C|S|T|src/main/java/batsang/bo/RequestClientBO.java:30-50| xxx|Tom|
|C|S|T|src/main/java/batsang/bo/RequestUpdateClientBO.java:3-5|ooo|Tom|
|C|S|T|src/main/java/batsang/bo/RequestClientBO.java:30-50| xxx|Tom|
