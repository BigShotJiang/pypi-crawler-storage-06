"""
koxs文件编辑器 - 一个功能强大的纯Python文件编辑器
"""

__version__ = "0.1.0"
__author__ = "koxs"
__email__ = "koxs@example.com"

from .core import koxsFileEditor

__all__ = ['koxsFileEditor']