from .Client import MatrixClient
def hello_world():
    return 'Hello'
