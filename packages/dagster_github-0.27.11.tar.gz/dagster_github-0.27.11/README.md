# dagster-github

The docs for `dagster-github` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-github).
