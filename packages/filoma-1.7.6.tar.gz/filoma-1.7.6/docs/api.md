# API Reference

This page uses `mkdocstrings` to generate an API reference from the `src/filoma` package.

::: filoma
