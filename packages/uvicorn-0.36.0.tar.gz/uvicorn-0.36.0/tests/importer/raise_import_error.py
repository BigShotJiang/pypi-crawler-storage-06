# Used by test_importer.py

myattr = 123

import does_not_exist  # noqa
