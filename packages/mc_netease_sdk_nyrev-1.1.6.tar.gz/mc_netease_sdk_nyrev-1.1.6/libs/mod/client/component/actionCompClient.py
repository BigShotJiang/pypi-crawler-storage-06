# -*- coding: utf-8 -*-

from mod.common.component.baseComponent import BaseComponent

class ActionCompClient(BaseComponent):
    def GetAttackTarget(self):
        # type: () -> str
        """
        获取仇恨目标
        """
        pass

