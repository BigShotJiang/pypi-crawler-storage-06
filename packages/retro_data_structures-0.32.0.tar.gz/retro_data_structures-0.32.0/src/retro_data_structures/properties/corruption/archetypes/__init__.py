# Generated File
from retro_data_structures.properties.corruption.archetypes.Abilities import Abilities
from retro_data_structures.properties.corruption.archetypes.ActivationTime import ActivationTime
from retro_data_structures.properties.corruption.archetypes.ActorParameters import ActorParameters
from retro_data_structures.properties.corruption.archetypes.AiDifficultySettings import AiDifficultySettings
from retro_data_structures.properties.corruption.archetypes.Armor import Armor
from retro_data_structures.properties.corruption.archetypes.AuroraUnit1Data import AuroraUnit1Data
from retro_data_structures.properties.corruption.archetypes.AuroraUnit2Data import AuroraUnit2Data
from retro_data_structures.properties.corruption.archetypes.Ball import Ball
from retro_data_structures.properties.corruption.archetypes.BallMiscControls import BallMiscControls
from retro_data_structures.properties.corruption.archetypes.BallMovementControls import BallMovementControls
from retro_data_structures.properties.corruption.archetypes.BeastRiderData import BeastRiderData
from retro_data_structures.properties.corruption.archetypes.BerserkerData import BerserkerData
from retro_data_structures.properties.corruption.archetypes.BlinkWolfData import BlinkWolfData
from retro_data_structures.properties.corruption.archetypes.BonusCredit import BonusCredit
from retro_data_structures.properties.corruption.archetypes.CableProperties import CableProperties
from retro_data_structures.properties.corruption.archetypes.CameraConstraints import CameraConstraints
from retro_data_structures.properties.corruption.archetypes.CameraControls import CameraControls
from retro_data_structures.properties.corruption.archetypes.CameraFieldOfView import CameraFieldOfView
from retro_data_structures.properties.corruption.archetypes.CameraInterpolation import CameraInterpolation
from retro_data_structures.properties.corruption.archetypes.CameraMotion import CameraMotion
from retro_data_structures.properties.corruption.archetypes.CameraNavigation import CameraNavigation
from retro_data_structures.properties.corruption.archetypes.CameraOrientation import CameraOrientation
from retro_data_structures.properties.corruption.archetypes.CameraPosition import CameraPosition
from retro_data_structures.properties.corruption.archetypes.CameraRotation import CameraRotation
from retro_data_structures.properties.corruption.archetypes.CameraShakerData import CameraShakerData
from retro_data_structures.properties.corruption.archetypes.CameraShakerEnvelope import CameraShakerEnvelope
from retro_data_structures.properties.corruption.archetypes.CattleProd import CattleProd
from retro_data_structures.properties.corruption.archetypes.Chakram import Chakram
from retro_data_structures.properties.corruption.archetypes.ChasePosition import ChasePosition
from retro_data_structures.properties.corruption.archetypes.CinematicBlend import CinematicBlend
from retro_data_structures.properties.corruption.archetypes.CircleLineMode import CircleLineMode
from retro_data_structures.properties.corruption.archetypes.ColliderPosition import ColliderPosition
from retro_data_structures.properties.corruption.archetypes.CommandData import CommandData
from retro_data_structures.properties.corruption.archetypes.ConditionalTest import ConditionalTest
from retro_data_structures.properties.corruption.archetypes.Connection import Connection
from retro_data_structures.properties.corruption.archetypes.ContextActionCombinationLockStruct import ContextActionCombinationLockStruct
from retro_data_structures.properties.corruption.archetypes.ControlCommands import ControlCommands
from retro_data_structures.properties.corruption.archetypes.Convergence import Convergence
from retro_data_structures.properties.corruption.archetypes.CounterConditions import CounterConditions
from retro_data_structures.properties.corruption.archetypes.DamageInfo import DamageInfo
from retro_data_structures.properties.corruption.archetypes.DamageVulnerability import DamageVulnerability
from retro_data_structures.properties.corruption.archetypes.DarkSamusData import DarkSamusData
from retro_data_structures.properties.corruption.archetypes.DarkSamusEchoData import DarkSamusEchoData
from retro_data_structures.properties.corruption.archetypes.DebrisProperties import DebrisProperties
from retro_data_structures.properties.corruption.archetypes.DebrisPropertiesOrientationEnum import DebrisPropertiesOrientationEnum
from retro_data_structures.properties.corruption.archetypes.DebugControls import DebugControls
from retro_data_structures.properties.corruption.archetypes.DefenseMechanoidData import DefenseMechanoidData
from retro_data_structures.properties.corruption.archetypes.DynamicLightFalloff import DynamicLightFalloff
from retro_data_structures.properties.corruption.archetypes.DynamicLightIntensity import DynamicLightIntensity
from retro_data_structures.properties.corruption.archetypes.DynamicLightMotionSpline import DynamicLightMotionSpline
from retro_data_structures.properties.corruption.archetypes.DynamicLightParent import DynamicLightParent
from retro_data_structures.properties.corruption.archetypes.DynamicLightSpotlight import DynamicLightSpotlight
from retro_data_structures.properties.corruption.archetypes.EditorProperties import EditorProperties
from retro_data_structures.properties.corruption.archetypes.ElectricBeamInfo import ElectricBeamInfo
from retro_data_structures.properties.corruption.archetypes.EnergyWhip import EnergyWhip
from retro_data_structures.properties.corruption.archetypes.EyePodData import EyePodData
from retro_data_structures.properties.corruption.archetypes.EyePodStruct import EyePodStruct
from retro_data_structures.properties.corruption.archetypes.FOVInterpolationMethod import FOVInterpolationMethod
from retro_data_structures.properties.corruption.archetypes.FargullHatcherData import FargullHatcherData
from retro_data_structures.properties.corruption.archetypes.FargullHatcherSwarmData import FargullHatcherSwarmData
from retro_data_structures.properties.corruption.archetypes.FederationData import FederationData
from retro_data_structures.properties.corruption.archetypes.FishCloudAggressionData import FishCloudAggressionData
from retro_data_structures.properties.corruption.archetypes.FlareDef import FlareDef
from retro_data_structures.properties.corruption.archetypes.FluidProperties import FluidProperties
from retro_data_structures.properties.corruption.archetypes.FlyerMovementMode import FlyerMovementMode
from retro_data_structures.properties.corruption.archetypes.FlyerSwarmData import FlyerSwarmData
from retro_data_structures.properties.corruption.archetypes.FlyingPirateData import FlyingPirateData
from retro_data_structures.properties.corruption.archetypes.FlyingPirateHelixMissileData import FlyingPirateHelixMissileData
from retro_data_structures.properties.corruption.archetypes.FlyingPirateStruct import FlyingPirateStruct
from retro_data_structures.properties.corruption.archetypes.FriendlyData import FriendlyData
from retro_data_structures.properties.corruption.archetypes.GandraydaData import GandraydaData
from retro_data_structures.properties.corruption.archetypes.GeneratedObjectDeleterProperties import GeneratedObjectDeleterProperties
from retro_data_structures.properties.corruption.archetypes.GhorStructA import GhorStructA
from retro_data_structures.properties.corruption.archetypes.GhorStructB import GhorStructB
from retro_data_structures.properties.corruption.archetypes.GhorStructC import GhorStructC
from retro_data_structures.properties.corruption.archetypes.GragnolFlyerData import GragnolFlyerData
from retro_data_structures.properties.corruption.archetypes.GrappleBlock import GrappleBlock
from retro_data_structures.properties.corruption.archetypes.GrappleData import GrappleData
from retro_data_structures.properties.corruption.archetypes.GrappleInfo import GrappleInfo
from retro_data_structures.properties.corruption.archetypes.GuiWidgetProperties import GuiWidgetProperties
from retro_data_structures.properties.corruption.archetypes.GunTurretBaseData import GunTurretBaseData
from retro_data_structures.properties.corruption.archetypes.GunTurretTopData import GunTurretTopData
from retro_data_structures.properties.corruption.archetypes.HealthInfo import HealthInfo
from retro_data_structures.properties.corruption.archetypes.HoverThenHomeProjectile import HoverThenHomeProjectile
from retro_data_structures.properties.corruption.archetypes.HyperMode import HyperMode
from retro_data_structures.properties.corruption.archetypes.HyperModeData import HyperModeData
from retro_data_structures.properties.corruption.archetypes.InterpolationMethod import InterpolationMethod
from retro_data_structures.properties.corruption.archetypes.Inventory import Inventory
from retro_data_structures.properties.corruption.archetypes.InventoryControls import InventoryControls
from retro_data_structures.properties.corruption.archetypes.JetPack import JetPack
from retro_data_structures.properties.corruption.archetypes.KorakkData import KorakkData
from retro_data_structures.properties.corruption.archetypes.KorbaMawData import KorbaMawData
from retro_data_structures.properties.corruption.archetypes.KorbaSnatcherData import KorbaSnatcherData
from retro_data_structures.properties.corruption.archetypes.LaunchProjectileData import LaunchProjectileData
from retro_data_structures.properties.corruption.archetypes.LayerID import LayerID
from retro_data_structures.properties.corruption.archetypes.LayerInfo import LayerInfo
from retro_data_structures.properties.corruption.archetypes.LightParameters import LightParameters
from retro_data_structures.properties.corruption.archetypes.MapControls import MapControls
from retro_data_structures.properties.corruption.archetypes.MetroidHatcherData import MetroidHatcherData
from retro_data_structures.properties.corruption.archetypes.MetroidHopperData import MetroidHopperData
from retro_data_structures.properties.corruption.archetypes.MetroidHopperStruct import MetroidHopperStruct
from retro_data_structures.properties.corruption.archetypes.MetroidPhazeoidData import MetroidPhazeoidData
from retro_data_structures.properties.corruption.archetypes.MetroidPhazeoidStruct import MetroidPhazeoidStruct
from retro_data_structures.properties.corruption.archetypes.Misc import Misc
from retro_data_structures.properties.corruption.archetypes.MiscControls import MiscControls
from retro_data_structures.properties.corruption.archetypes.MiscControls_UnknownStruct1 import MiscControls_UnknownStruct1
from retro_data_structures.properties.corruption.archetypes.MiscControls_UnknownStruct2 import MiscControls_UnknownStruct2
from retro_data_structures.properties.corruption.archetypes.ModIncaData import ModIncaData
from retro_data_structures.properties.corruption.archetypes.MotionInterpolationMethod import MotionInterpolationMethod
from retro_data_structures.properties.corruption.archetypes.MultiModelActorStruct import MultiModelActorStruct
from retro_data_structures.properties.corruption.archetypes.MultiModelInformation import MultiModelInformation
from retro_data_structures.properties.corruption.archetypes.MysteryFlyerData import MysteryFlyerData
from retro_data_structures.properties.corruption.archetypes.NonSlowdown import NonSlowdown
from retro_data_structures.properties.corruption.archetypes.OffsetInterpolant import OffsetInterpolant
from retro_data_structures.properties.corruption.archetypes.OffsetPosition import OffsetPosition
from retro_data_structures.properties.corruption.archetypes.OffsetSplines import OffsetSplines
from retro_data_structures.properties.corruption.archetypes.OptionalAreaAssetTypes import OptionalAreaAssetTypes
from retro_data_structures.properties.corruption.archetypes.OrientationInterpolationMethod import OrientationInterpolationMethod
from retro_data_structures.properties.corruption.archetypes.PIDConvergence import PIDConvergence
from retro_data_structures.properties.corruption.archetypes.PTCNoseTurretData import PTCNoseTurretData
from retro_data_structures.properties.corruption.archetypes.ParticleBlaster import ParticleBlaster
from retro_data_structures.properties.corruption.archetypes.PathDetermination import PathDetermination
from retro_data_structures.properties.corruption.archetypes.PathDeterminationMethodType import PathDeterminationMethodType
from retro_data_structures.properties.corruption.archetypes.PathPosition import PathPosition
from retro_data_structures.properties.corruption.archetypes.PathType import PathType
from retro_data_structures.properties.corruption.archetypes.PatternedAITypedef import PatternedAITypedef
from retro_data_structures.properties.corruption.archetypes.PhaazoidData import PhaazoidData
from retro_data_structures.properties.corruption.archetypes.PhazonFlyerSwarmData import PhazonFlyerSwarmData
from retro_data_structures.properties.corruption.archetypes.PhazonHarvesterData import PhazonHarvesterData
from retro_data_structures.properties.corruption.archetypes.PhazonLeechData import PhazonLeechData
from retro_data_structures.properties.corruption.archetypes.PhazonPuddleData import PhazonPuddleData
from retro_data_structures.properties.corruption.archetypes.PhysicsDebrisProperties import PhysicsDebrisProperties
from retro_data_structures.properties.corruption.archetypes.PhysicsDebrisPropertiesOrientationEnum import PhysicsDebrisPropertiesOrientationEnum
from retro_data_structures.properties.corruption.archetypes.PirateDroneData import PirateDroneData
from retro_data_structures.properties.corruption.archetypes.PlasmaBeamInfo import PlasmaBeamInfo
from retro_data_structures.properties.corruption.archetypes.PlatformMotionProperties import PlatformMotionProperties
from retro_data_structures.properties.corruption.archetypes.PlayerActorStruct import PlayerActorStruct
from retro_data_structures.properties.corruption.archetypes.PlayerControls import PlayerControls
from retro_data_structures.properties.corruption.archetypes.PlayerInventoryItem import PlayerInventoryItem
from retro_data_structures.properties.corruption.archetypes.PlayerMiscControls import PlayerMiscControls
from retro_data_structures.properties.corruption.archetypes.PlayerMovementControls import PlayerMovementControls
from retro_data_structures.properties.corruption.archetypes.PlayerWeaponControls import PlayerWeaponControls
from retro_data_structures.properties.corruption.archetypes.ProportionalConvergence import ProportionalConvergence
from retro_data_structures.properties.corruption.archetypes.PuddleControlData import PuddleControlData
from retro_data_structures.properties.corruption.archetypes.PuddleControlPhaseData import PuddleControlPhaseData
from retro_data_structures.properties.corruption.archetypes.RagDollData import RagDollData
from retro_data_structures.properties.corruption.archetypes.RainProperties import RainProperties
from retro_data_structures.properties.corruption.archetypes.ReptilicusHunterData import ReptilicusHunterData
from retro_data_structures.properties.corruption.archetypes.ReptilicusHunterStruct import ReptilicusHunterStruct
from retro_data_structures.properties.corruption.archetypes.RevolutionControl import RevolutionControl
from retro_data_structures.properties.corruption.archetypes.RevolutionControl_UnknownStruct1 import RevolutionControl_UnknownStruct1
from retro_data_structures.properties.corruption.archetypes.RevolutionControl_UnknownStruct2 import RevolutionControl_UnknownStruct2
from retro_data_structures.properties.corruption.archetypes.RevolutionControl_UnknownStruct3 import RevolutionControl_UnknownStruct3
from retro_data_structures.properties.corruption.archetypes.RevolutionControl_UnknownStruct4 import RevolutionControl_UnknownStruct4
from retro_data_structures.properties.corruption.archetypes.RevolutionPhysicalControl import RevolutionPhysicalControl
from retro_data_structures.properties.corruption.archetypes.Ridley1Data import Ridley1Data
from retro_data_structures.properties.corruption.archetypes.RotationSplines import RotationSplines
from retro_data_structures.properties.corruption.archetypes.RundasData import RundasData
from retro_data_structures.properties.corruption.archetypes.SavedStateID import SavedStateID
from retro_data_structures.properties.corruption.archetypes.ScaleSplines import ScaleSplines
from retro_data_structures.properties.corruption.archetypes.ScanBeamInfo import ScanBeamInfo
from retro_data_structures.properties.corruption.archetypes.ScanInfoSecondaryModel import ScanInfoSecondaryModel
from retro_data_structures.properties.corruption.archetypes.ScannableParameters import ScannableParameters
from retro_data_structures.properties.corruption.archetypes.SeedBoss1Action import SeedBoss1Action
from retro_data_structures.properties.corruption.archetypes.SeedBoss1Data import SeedBoss1Data
from retro_data_structures.properties.corruption.archetypes.SeedBoss1HandData import SeedBoss1HandData
from retro_data_structures.properties.corruption.archetypes.SeedBoss1OrbData import SeedBoss1OrbData
from retro_data_structures.properties.corruption.archetypes.SeedBoss1Shield import SeedBoss1Shield
from retro_data_structures.properties.corruption.archetypes.SeedBoss1Stage import SeedBoss1Stage
from retro_data_structures.properties.corruption.archetypes.SeedBoss2PrimeBotData import SeedBoss2PrimeBotData
from retro_data_structures.properties.corruption.archetypes.SeedBoss3Data import SeedBoss3Data
from retro_data_structures.properties.corruption.archetypes.ShadowProjection import ShadowProjection
from retro_data_structures.properties.corruption.archetypes.ShellBugData import ShellBugData
from retro_data_structures.properties.corruption.archetypes.Ship import Ship
from retro_data_structures.properties.corruption.archetypes.ShipData import ShipData
from retro_data_structures.properties.corruption.archetypes.ShipDecalControllerStruct import ShipDecalControllerStruct
from retro_data_structures.properties.corruption.archetypes.ShockWaveInfo import ShockWaveInfo
from retro_data_structures.properties.corruption.archetypes.SpacePirateData import SpacePirateData
from retro_data_structures.properties.corruption.archetypes.SpacePirateStruct import SpacePirateStruct
from retro_data_structures.properties.corruption.archetypes.SpacePirateWeaponData import SpacePirateWeaponData
from retro_data_structures.properties.corruption.archetypes.SpindleOrientation import SpindleOrientation
from retro_data_structures.properties.corruption.archetypes.SpindlePosition import SpindlePosition
from retro_data_structures.properties.corruption.archetypes.SpindlePositionInterpolant import SpindlePositionInterpolant
from retro_data_structures.properties.corruption.archetypes.SplineType import SplineType
from retro_data_structures.properties.corruption.archetypes.SpringConvergence import SpringConvergence
from retro_data_structures.properties.corruption.archetypes.SpriteStruct import SpriteStruct
from retro_data_structures.properties.corruption.archetypes.StaticGeometryTest import StaticGeometryTest
from retro_data_structures.properties.corruption.archetypes.SteamBotData import SteamBotData
from retro_data_structures.properties.corruption.archetypes.SteamLordData import SteamLordData
from retro_data_structures.properties.corruption.archetypes.SurfaceOrientation import SurfaceOrientation
from retro_data_structures.properties.corruption.archetypes.SurfacePosition import SurfacePosition
from retro_data_structures.properties.corruption.archetypes.SurroundPan import SurroundPan
from retro_data_structures.properties.corruption.archetypes.SwarmBasicsData import SwarmBasicsData
from retro_data_structures.properties.corruption.archetypes.SwarmBotData import SwarmBotData
from retro_data_structures.properties.corruption.archetypes.SwarmSoundData import SwarmSoundData
from retro_data_structures.properties.corruption.archetypes.TBallTransitionResources import TBallTransitionResources
from retro_data_structures.properties.corruption.archetypes.TBeamInfo import TBeamInfo
from retro_data_structures.properties.corruption.archetypes.TDamageInfo import TDamageInfo
from retro_data_structures.properties.corruption.archetypes.TGunResources import TGunResources
from retro_data_structures.properties.corruption.archetypes.TIcon_Configurations import TIcon_Configurations
from retro_data_structures.properties.corruption.archetypes.TWeaponDamage import TWeaponDamage
from retro_data_structures.properties.corruption.archetypes.TeamAIDebugEnum import TeamAIDebugEnum
from retro_data_structures.properties.corruption.archetypes.TextProperties import TextProperties
from retro_data_structures.properties.corruption.archetypes.Transform import Transform
from retro_data_structures.properties.corruption.archetypes.TranslationSplines import TranslationSplines
from retro_data_structures.properties.corruption.archetypes.TriggerInfo import TriggerInfo
from retro_data_structures.properties.corruption.archetypes.TweakAutoMapper_Base import TweakAutoMapper_Base
from retro_data_structures.properties.corruption.archetypes.TweakAutoMapper_DoorColors import TweakAutoMapper_DoorColors
from retro_data_structures.properties.corruption.archetypes.TweakBall_BoostBall import TweakBall_BoostBall
from retro_data_structures.properties.corruption.archetypes.TweakBall_Camera import TweakBall_Camera
from retro_data_structures.properties.corruption.archetypes.TweakBall_CannonBall import TweakBall_CannonBall
from retro_data_structures.properties.corruption.archetypes.TweakBall_DeathBall import TweakBall_DeathBall
from retro_data_structures.properties.corruption.archetypes.TweakBall_FireBall import TweakBall_FireBall
from retro_data_structures.properties.corruption.archetypes.TweakBall_IceBall import TweakBall_IceBall
from retro_data_structures.properties.corruption.archetypes.TweakBall_Misc import TweakBall_Misc
from retro_data_structures.properties.corruption.archetypes.TweakBall_Movement import TweakBall_Movement
from retro_data_structures.properties.corruption.archetypes.TweakBall_PhazonBall import TweakBall_PhazonBall
from retro_data_structures.properties.corruption.archetypes.TweakBall_ScrewAttack import TweakBall_ScrewAttack
from retro_data_structures.properties.corruption.archetypes.TweakGuiColors_HUDColorsTypedef import TweakGuiColors_HUDColorsTypedef
from retro_data_structures.properties.corruption.archetypes.TweakGuiColors_Misc import TweakGuiColors_Misc
from retro_data_structures.properties.corruption.archetypes.TweakGuiColors_Multiplayer import TweakGuiColors_Multiplayer
from retro_data_structures.properties.corruption.archetypes.TweakGuiColors_TurretHudTypedef import TweakGuiColors_TurretHudTypedef
from retro_data_structures.properties.corruption.archetypes.TweakGui_Completion import TweakGui_Completion
from retro_data_structures.properties.corruption.archetypes.TweakGui_Credits import TweakGui_Credits
from retro_data_structures.properties.corruption.archetypes.TweakGui_HudColorTypedef import TweakGui_HudColorTypedef
from retro_data_structures.properties.corruption.archetypes.TweakGui_Misc import TweakGui_Misc
from retro_data_structures.properties.corruption.archetypes.TweakGui_Misc_UnknownStruct1 import TweakGui_Misc_UnknownStruct1
from retro_data_structures.properties.corruption.archetypes.TweakGui_MovieVolumes import TweakGui_MovieVolumes
from retro_data_structures.properties.corruption.archetypes.TweakGui_ScanVisor import TweakGui_ScanVisor
from retro_data_structures.properties.corruption.archetypes.TweakGui_ScannableObjectDownloadTimes import TweakGui_ScannableObjectDownloadTimes
from retro_data_structures.properties.corruption.archetypes.TweakGui_UnknownStruct1 import TweakGui_UnknownStruct1
from retro_data_structures.properties.corruption.archetypes.TweakGui_UnknownStruct2 import TweakGui_UnknownStruct2
from retro_data_structures.properties.corruption.archetypes.TweakGui_UnknownStruct3 import TweakGui_UnknownStruct3
from retro_data_structures.properties.corruption.archetypes.TweakGui_UnknownStruct4 import TweakGui_UnknownStruct4
from retro_data_structures.properties.corruption.archetypes.TweakGui_UnknownStruct5 import TweakGui_UnknownStruct5
from retro_data_structures.properties.corruption.archetypes.TweakGui_VisorColorSchemeTypedef import TweakGui_VisorColorSchemeTypedef
from retro_data_structures.properties.corruption.archetypes.TweakPlayerGun_Arm_Position import TweakPlayerGun_Arm_Position
from retro_data_structures.properties.corruption.archetypes.TweakPlayerGun_Beam_Misc import TweakPlayerGun_Beam_Misc
from retro_data_structures.properties.corruption.archetypes.TweakPlayerGun_Holstering import TweakPlayerGun_Holstering
from retro_data_structures.properties.corruption.archetypes.TweakPlayerGun_Misc import TweakPlayerGun_Misc
from retro_data_structures.properties.corruption.archetypes.TweakPlayerGun_Position import TweakPlayerGun_Position
from retro_data_structures.properties.corruption.archetypes.TweakPlayerGun_RicochetDamage_Factor import TweakPlayerGun_RicochetDamage_Factor
from retro_data_structures.properties.corruption.archetypes.TweakPlayerGun_Weapons import TweakPlayerGun_Weapons
from retro_data_structures.properties.corruption.archetypes.TweakPlayerRes_AutoMapperIcons import TweakPlayerRes_AutoMapperIcons
from retro_data_structures.properties.corruption.archetypes.TweakPlayerRes_MapScreenIcons import TweakPlayerRes_MapScreenIcons
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_AimStuff import TweakPlayer_AimStuff
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_Collision import TweakPlayer_Collision
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_FirstPersonCamera import TweakPlayer_FirstPersonCamera
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_Frozen import TweakPlayer_Frozen
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_Grapple import TweakPlayer_Grapple
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_GrappleBeam import TweakPlayer_GrappleBeam
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_HyperMode import TweakPlayer_HyperMode
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_Misc import TweakPlayer_Misc
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_Motion import TweakPlayer_Motion
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_Orbit import TweakPlayer_Orbit
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_ScanVisor import TweakPlayer_ScanVisor
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_Shield import TweakPlayer_Shield
from retro_data_structures.properties.corruption.archetypes.TweakPlayer_SuitDamageReduction import TweakPlayer_SuitDamageReduction
from retro_data_structures.properties.corruption.archetypes.TweakTargeting_Charge_Gauge import TweakTargeting_Charge_Gauge
from retro_data_structures.properties.corruption.archetypes.TweakTargeting_LockDagger import TweakTargeting_LockDagger
from retro_data_structures.properties.corruption.archetypes.TweakTargeting_LockFire import TweakTargeting_LockFire
from retro_data_structures.properties.corruption.archetypes.TweakTargeting_OuterBeamIcon import TweakTargeting_OuterBeamIcon
from retro_data_structures.properties.corruption.archetypes.TweakTargeting_Scan import TweakTargeting_Scan
from retro_data_structures.properties.corruption.archetypes.TweakTargeting_UnknownStruct1 import TweakTargeting_UnknownStruct1
from retro_data_structures.properties.corruption.archetypes.TweakTargeting_UnknownStruct2 import TweakTargeting_UnknownStruct2
from retro_data_structures.properties.corruption.archetypes.TweakTargeting_UnknownStruct3 import TweakTargeting_UnknownStruct3
from retro_data_structures.properties.corruption.archetypes.UnknownStruct1 import UnknownStruct1
from retro_data_structures.properties.corruption.archetypes.UnknownStruct10 import UnknownStruct10
from retro_data_structures.properties.corruption.archetypes.UnknownStruct11 import UnknownStruct11
from retro_data_structures.properties.corruption.archetypes.UnknownStruct12 import UnknownStruct12
from retro_data_structures.properties.corruption.archetypes.UnknownStruct13 import UnknownStruct13
from retro_data_structures.properties.corruption.archetypes.UnknownStruct14 import UnknownStruct14
from retro_data_structures.properties.corruption.archetypes.UnknownStruct15 import UnknownStruct15
from retro_data_structures.properties.corruption.archetypes.UnknownStruct16 import UnknownStruct16
from retro_data_structures.properties.corruption.archetypes.UnknownStruct17 import UnknownStruct17
from retro_data_structures.properties.corruption.archetypes.UnknownStruct18 import UnknownStruct18
from retro_data_structures.properties.corruption.archetypes.UnknownStruct19 import UnknownStruct19
from retro_data_structures.properties.corruption.archetypes.UnknownStruct2 import UnknownStruct2
from retro_data_structures.properties.corruption.archetypes.UnknownStruct20 import UnknownStruct20
from retro_data_structures.properties.corruption.archetypes.UnknownStruct21 import UnknownStruct21
from retro_data_structures.properties.corruption.archetypes.UnknownStruct22 import UnknownStruct22
from retro_data_structures.properties.corruption.archetypes.UnknownStruct23 import UnknownStruct23
from retro_data_structures.properties.corruption.archetypes.UnknownStruct24 import UnknownStruct24
from retro_data_structures.properties.corruption.archetypes.UnknownStruct25 import UnknownStruct25
from retro_data_structures.properties.corruption.archetypes.UnknownStruct26 import UnknownStruct26
from retro_data_structures.properties.corruption.archetypes.UnknownStruct27 import UnknownStruct27
from retro_data_structures.properties.corruption.archetypes.UnknownStruct28 import UnknownStruct28
from retro_data_structures.properties.corruption.archetypes.UnknownStruct29 import UnknownStruct29
from retro_data_structures.properties.corruption.archetypes.UnknownStruct3 import UnknownStruct3
from retro_data_structures.properties.corruption.archetypes.UnknownStruct30 import UnknownStruct30
from retro_data_structures.properties.corruption.archetypes.UnknownStruct31 import UnknownStruct31
from retro_data_structures.properties.corruption.archetypes.UnknownStruct32 import UnknownStruct32
from retro_data_structures.properties.corruption.archetypes.UnknownStruct33 import UnknownStruct33
from retro_data_structures.properties.corruption.archetypes.UnknownStruct34 import UnknownStruct34
from retro_data_structures.properties.corruption.archetypes.UnknownStruct35 import UnknownStruct35
from retro_data_structures.properties.corruption.archetypes.UnknownStruct36 import UnknownStruct36
from retro_data_structures.properties.corruption.archetypes.UnknownStruct37 import UnknownStruct37
from retro_data_structures.properties.corruption.archetypes.UnknownStruct38 import UnknownStruct38
from retro_data_structures.properties.corruption.archetypes.UnknownStruct39 import UnknownStruct39
from retro_data_structures.properties.corruption.archetypes.UnknownStruct4 import UnknownStruct4
from retro_data_structures.properties.corruption.archetypes.UnknownStruct40 import UnknownStruct40
from retro_data_structures.properties.corruption.archetypes.UnknownStruct41 import UnknownStruct41
from retro_data_structures.properties.corruption.archetypes.UnknownStruct42 import UnknownStruct42
from retro_data_structures.properties.corruption.archetypes.UnknownStruct43 import UnknownStruct43
from retro_data_structures.properties.corruption.archetypes.UnknownStruct44 import UnknownStruct44
from retro_data_structures.properties.corruption.archetypes.UnknownStruct45 import UnknownStruct45
from retro_data_structures.properties.corruption.archetypes.UnknownStruct47 import UnknownStruct47
from retro_data_structures.properties.corruption.archetypes.UnknownStruct48 import UnknownStruct48
from retro_data_structures.properties.corruption.archetypes.UnknownStruct50 import UnknownStruct50
from retro_data_structures.properties.corruption.archetypes.UnknownStruct51 import UnknownStruct51
from retro_data_structures.properties.corruption.archetypes.UnknownStruct52 import UnknownStruct52
from retro_data_structures.properties.corruption.archetypes.UnknownStruct53 import UnknownStruct53
from retro_data_structures.properties.corruption.archetypes.UnknownStruct54 import UnknownStruct54
from retro_data_structures.properties.corruption.archetypes.UnknownStruct55 import UnknownStruct55
from retro_data_structures.properties.corruption.archetypes.UnknownStruct56 import UnknownStruct56
from retro_data_structures.properties.corruption.archetypes.UnknownStruct57 import UnknownStruct57
from retro_data_structures.properties.corruption.archetypes.UnknownStruct58 import UnknownStruct58
from retro_data_structures.properties.corruption.archetypes.UnknownStruct59 import UnknownStruct59
from retro_data_structures.properties.corruption.archetypes.UnknownStruct6 import UnknownStruct6
from retro_data_structures.properties.corruption.archetypes.UnknownStruct60 import UnknownStruct60
from retro_data_structures.properties.corruption.archetypes.UnknownStruct61 import UnknownStruct61
from retro_data_structures.properties.corruption.archetypes.UnknownStruct63 import UnknownStruct63
from retro_data_structures.properties.corruption.archetypes.UnknownStruct64 import UnknownStruct64
from retro_data_structures.properties.corruption.archetypes.UnknownStruct65 import UnknownStruct65
from retro_data_structures.properties.corruption.archetypes.UnknownStruct66 import UnknownStruct66
from retro_data_structures.properties.corruption.archetypes.UnknownStruct7 import UnknownStruct7
from retro_data_structures.properties.corruption.archetypes.UnknownStruct8 import UnknownStruct8
from retro_data_structures.properties.corruption.archetypes.UnknownStruct9 import UnknownStruct9
from retro_data_structures.properties.corruption.archetypes.Vector2f import Vector2f
from retro_data_structures.properties.corruption.archetypes.VelocityConvergence import VelocityConvergence
from retro_data_structures.properties.corruption.archetypes.VisorParameters import VisorParameters
from retro_data_structures.properties.corruption.archetypes.Visors import Visors
from retro_data_structures.properties.corruption.archetypes.WallCrawlerData import WallCrawlerData
from retro_data_structures.properties.corruption.archetypes.WeaponGeneratorProperties import WeaponGeneratorProperties
from retro_data_structures.properties.corruption.archetypes.WeaponVulnerability import WeaponVulnerability
from retro_data_structures.properties.corruption.archetypes.Weapons import Weapons

__all__ = [
    "Abilities",
    "ActivationTime",
    "ActorParameters",
    "AiDifficultySettings",
    "Armor",
    "AuroraUnit1Data",
    "AuroraUnit2Data",
    "Ball",
    "BallMiscControls",
    "BallMovementControls",
    "BeastRiderData",
    "BerserkerData",
    "BlinkWolfData",
    "BonusCredit",
    "CableProperties",
    "CameraConstraints",
    "CameraControls",
    "CameraFieldOfView",
    "CameraInterpolation",
    "CameraMotion",
    "CameraNavigation",
    "CameraOrientation",
    "CameraPosition",
    "CameraRotation",
    "CameraShakerData",
    "CameraShakerEnvelope",
    "CattleProd",
    "Chakram",
    "ChasePosition",
    "CinematicBlend",
    "CircleLineMode",
    "ColliderPosition",
    "CommandData",
    "ConditionalTest",
    "Connection",
    "ContextActionCombinationLockStruct",
    "ControlCommands",
    "Convergence",
    "CounterConditions",
    "DamageInfo",
    "DamageVulnerability",
    "DarkSamusData",
    "DarkSamusEchoData",
    "DebrisProperties",
    "DebrisPropertiesOrientationEnum",
    "DebugControls",
    "DefenseMechanoidData",
    "DynamicLightFalloff",
    "DynamicLightIntensity",
    "DynamicLightMotionSpline",
    "DynamicLightParent",
    "DynamicLightSpotlight",
    "EditorProperties",
    "ElectricBeamInfo",
    "EnergyWhip",
    "EyePodData",
    "EyePodStruct",
    "FOVInterpolationMethod",
    "FargullHatcherData",
    "FargullHatcherSwarmData",
    "FederationData",
    "FishCloudAggressionData",
    "FlareDef",
    "FluidProperties",
    "FlyerMovementMode",
    "FlyerSwarmData",
    "FlyingPirateData",
    "FlyingPirateHelixMissileData",
    "FlyingPirateStruct",
    "FriendlyData",
    "GandraydaData",
    "GeneratedObjectDeleterProperties",
    "GhorStructA",
    "GhorStructB",
    "GhorStructC",
    "GragnolFlyerData",
    "GrappleBlock",
    "GrappleData",
    "GrappleInfo",
    "GuiWidgetProperties",
    "GunTurretBaseData",
    "GunTurretTopData",
    "HealthInfo",
    "HoverThenHomeProjectile",
    "HyperMode",
    "HyperModeData",
    "InterpolationMethod",
    "Inventory",
    "InventoryControls",
    "JetPack",
    "KorakkData",
    "KorbaMawData",
    "KorbaSnatcherData",
    "LaunchProjectileData",
    "LayerID",
    "LayerInfo",
    "LightParameters",
    "MapControls",
    "MetroidHatcherData",
    "MetroidHopperData",
    "MetroidHopperStruct",
    "MetroidPhazeoidData",
    "MetroidPhazeoidStruct",
    "Misc",
    "MiscControls",
    "MiscControls_UnknownStruct1",
    "MiscControls_UnknownStruct2",
    "ModIncaData",
    "MotionInterpolationMethod",
    "MultiModelActorStruct",
    "MultiModelInformation",
    "MysteryFlyerData",
    "NonSlowdown",
    "OffsetInterpolant",
    "OffsetPosition",
    "OffsetSplines",
    "OptionalAreaAssetTypes",
    "OrientationInterpolationMethod",
    "PIDConvergence",
    "PTCNoseTurretData",
    "ParticleBlaster",
    "PathDetermination",
    "PathDeterminationMethodType",
    "PathPosition",
    "PathType",
    "PatternedAITypedef",
    "PhaazoidData",
    "PhazonFlyerSwarmData",
    "PhazonHarvesterData",
    "PhazonLeechData",
    "PhazonPuddleData",
    "PhysicsDebrisProperties",
    "PhysicsDebrisPropertiesOrientationEnum",
    "PirateDroneData",
    "PlasmaBeamInfo",
    "PlatformMotionProperties",
    "PlayerActorStruct",
    "PlayerControls",
    "PlayerInventoryItem",
    "PlayerMiscControls",
    "PlayerMovementControls",
    "PlayerWeaponControls",
    "ProportionalConvergence",
    "PuddleControlData",
    "PuddleControlPhaseData",
    "RagDollData",
    "RainProperties",
    "ReptilicusHunterData",
    "ReptilicusHunterStruct",
    "RevolutionControl",
    "RevolutionControl_UnknownStruct1",
    "RevolutionControl_UnknownStruct2",
    "RevolutionControl_UnknownStruct3",
    "RevolutionControl_UnknownStruct4",
    "RevolutionPhysicalControl",
    "Ridley1Data",
    "RotationSplines",
    "RundasData",
    "SavedStateID",
    "ScaleSplines",
    "ScanBeamInfo",
    "ScanInfoSecondaryModel",
    "ScannableParameters",
    "SeedBoss1Action",
    "SeedBoss1Data",
    "SeedBoss1HandData",
    "SeedBoss1OrbData",
    "SeedBoss1Shield",
    "SeedBoss1Stage",
    "SeedBoss2PrimeBotData",
    "SeedBoss3Data",
    "ShadowProjection",
    "ShellBugData",
    "Ship",
    "ShipData",
    "ShipDecalControllerStruct",
    "ShockWaveInfo",
    "SpacePirateData",
    "SpacePirateStruct",
    "SpacePirateWeaponData",
    "SpindleOrientation",
    "SpindlePosition",
    "SpindlePositionInterpolant",
    "SplineType",
    "SpringConvergence",
    "SpriteStruct",
    "StaticGeometryTest",
    "SteamBotData",
    "SteamLordData",
    "SurfaceOrientation",
    "SurfacePosition",
    "SurroundPan",
    "SwarmBasicsData",
    "SwarmBotData",
    "SwarmSoundData",
    "TBallTransitionResources",
    "TBeamInfo",
    "TDamageInfo",
    "TGunResources",
    "TIcon_Configurations",
    "TWeaponDamage",
    "TeamAIDebugEnum",
    "TextProperties",
    "Transform",
    "TranslationSplines",
    "TriggerInfo",
    "TweakAutoMapper_Base",
    "TweakAutoMapper_DoorColors",
    "TweakBall_BoostBall",
    "TweakBall_Camera",
    "TweakBall_CannonBall",
    "TweakBall_DeathBall",
    "TweakBall_FireBall",
    "TweakBall_IceBall",
    "TweakBall_Misc",
    "TweakBall_Movement",
    "TweakBall_PhazonBall",
    "TweakBall_ScrewAttack",
    "TweakGuiColors_HUDColorsTypedef",
    "TweakGuiColors_Misc",
    "TweakGuiColors_Multiplayer",
    "TweakGuiColors_TurretHudTypedef",
    "TweakGui_Completion",
    "TweakGui_Credits",
    "TweakGui_HudColorTypedef",
    "TweakGui_Misc",
    "TweakGui_Misc_UnknownStruct1",
    "TweakGui_MovieVolumes",
    "TweakGui_ScanVisor",
    "TweakGui_ScannableObjectDownloadTimes",
    "TweakGui_UnknownStruct1",
    "TweakGui_UnknownStruct2",
    "TweakGui_UnknownStruct3",
    "TweakGui_UnknownStruct4",
    "TweakGui_UnknownStruct5",
    "TweakGui_VisorColorSchemeTypedef",
    "TweakPlayerGun_Arm_Position",
    "TweakPlayerGun_Beam_Misc",
    "TweakPlayerGun_Holstering",
    "TweakPlayerGun_Misc",
    "TweakPlayerGun_Position",
    "TweakPlayerGun_RicochetDamage_Factor",
    "TweakPlayerGun_Weapons",
    "TweakPlayerRes_AutoMapperIcons",
    "TweakPlayerRes_MapScreenIcons",
    "TweakPlayer_AimStuff",
    "TweakPlayer_Collision",
    "TweakPlayer_FirstPersonCamera",
    "TweakPlayer_Frozen",
    "TweakPlayer_Grapple",
    "TweakPlayer_GrappleBeam",
    "TweakPlayer_HyperMode",
    "TweakPlayer_Misc",
    "TweakPlayer_Motion",
    "TweakPlayer_Orbit",
    "TweakPlayer_ScanVisor",
    "TweakPlayer_Shield",
    "TweakPlayer_SuitDamageReduction",
    "TweakTargeting_Charge_Gauge",
    "TweakTargeting_LockDagger",
    "TweakTargeting_LockFire",
    "TweakTargeting_OuterBeamIcon",
    "TweakTargeting_Scan",
    "TweakTargeting_UnknownStruct1",
    "TweakTargeting_UnknownStruct2",
    "TweakTargeting_UnknownStruct3",
    "UnknownStruct1",
    "UnknownStruct10",
    "UnknownStruct11",
    "UnknownStruct12",
    "UnknownStruct13",
    "UnknownStruct14",
    "UnknownStruct15",
    "UnknownStruct16",
    "UnknownStruct17",
    "UnknownStruct18",
    "UnknownStruct19",
    "UnknownStruct2",
    "UnknownStruct20",
    "UnknownStruct21",
    "UnknownStruct22",
    "UnknownStruct23",
    "UnknownStruct24",
    "UnknownStruct25",
    "UnknownStruct26",
    "UnknownStruct27",
    "UnknownStruct28",
    "UnknownStruct29",
    "UnknownStruct3",
    "UnknownStruct30",
    "UnknownStruct31",
    "UnknownStruct32",
    "UnknownStruct33",
    "UnknownStruct34",
    "UnknownStruct35",
    "UnknownStruct36",
    "UnknownStruct37",
    "UnknownStruct38",
    "UnknownStruct39",
    "UnknownStruct4",
    "UnknownStruct40",
    "UnknownStruct41",
    "UnknownStruct42",
    "UnknownStruct43",
    "UnknownStruct44",
    "UnknownStruct45",
    "UnknownStruct47",
    "UnknownStruct48",
    "UnknownStruct50",
    "UnknownStruct51",
    "UnknownStruct52",
    "UnknownStruct53",
    "UnknownStruct54",
    "UnknownStruct55",
    "UnknownStruct56",
    "UnknownStruct57",
    "UnknownStruct58",
    "UnknownStruct59",
    "UnknownStruct6",
    "UnknownStruct60",
    "UnknownStruct61",
    "UnknownStruct63",
    "UnknownStruct64",
    "UnknownStruct65",
    "UnknownStruct66",
    "UnknownStruct7",
    "UnknownStruct8",
    "UnknownStruct9",
    "Vector2f",
    "VelocityConvergence",
    "VisorParameters",
    "Visors",
    "WallCrawlerData",
    "WeaponGeneratorProperties",
    "WeaponVulnerability",
    "Weapons",
]
