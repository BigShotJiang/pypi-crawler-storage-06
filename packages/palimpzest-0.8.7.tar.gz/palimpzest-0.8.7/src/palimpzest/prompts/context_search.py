
CONTEXT_SEARCH_PROMPT = """You are a helpful agent whose job is to propose search queries that will assist in finding information that is relevant to performing a computation.

Please propose a concise sentence which will be used to search for relevant information for the following computation instruction.

INSTRUCTION: {instruction}

SEARCH QUERY: 
"""
