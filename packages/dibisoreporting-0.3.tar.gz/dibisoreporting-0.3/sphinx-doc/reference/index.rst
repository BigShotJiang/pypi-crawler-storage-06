Reference
=========

.. toctree::
   :maxdepth: 1

   biso


.. currentmodule:: dibisoreporting

BiSO
----

.. autosummary::

   Biso.__init__
   Biso.generate_report

