from slotlist.core import *
from slotlist.tests import *

if __name__ == "__main__":
    main()
