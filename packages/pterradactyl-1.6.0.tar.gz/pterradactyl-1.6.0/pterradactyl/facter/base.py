class BaseFacter(object):

  def __init__(self, config):
    pass

  def parser_setup(self, parser):
    pass

  def facts(self, facts):
    return {}
