def to_upper(text: str) -> str:
    """Convert text to uppercase"""
    return text.upper() 

def to_lower(text: str) -> str:
    """Convert text to lowercase"""
    return text.lower() 
