from .core import to_upper, to_lower
