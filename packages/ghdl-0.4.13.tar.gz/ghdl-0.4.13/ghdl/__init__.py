__version__ = "0.4.13"

from ghdl.main import main, set_dry, set_single
