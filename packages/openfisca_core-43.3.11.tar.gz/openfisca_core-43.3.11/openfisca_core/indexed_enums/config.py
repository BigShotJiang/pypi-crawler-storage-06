import numpy

ENUM_ARRAY_DTYPE = numpy.int16


__all__ = ["ENUM_ARRAY_DTYPE"]
