class LibYAMLWarning(UserWarning):
    """Custom warning for LibYAML not installed."""
