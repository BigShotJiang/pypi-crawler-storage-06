# authbox django template

Use for convert bootstrap template or tailwind template to django version template

### How to use
      # named your environment
    > mkvirtualenv env_test             
      # activate yout environment
    > workon env_test                   
      # install this library on active environmnet
    > pip install authbox_django_template  
      # your library is ready to use (just call library name)
    > authbox_django_template [option][source][dir] 
