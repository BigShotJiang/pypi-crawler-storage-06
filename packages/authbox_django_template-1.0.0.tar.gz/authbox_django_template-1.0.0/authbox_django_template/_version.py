"""
Provides authbox_django_template version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update authbox_django_template` to change this file.

from incremental import Version

__version__ = Version("authbox_django_template", 1, 0, 0)
__all__ = ["__version__"]
