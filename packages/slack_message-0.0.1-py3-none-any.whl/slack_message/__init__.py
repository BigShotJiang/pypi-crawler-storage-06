__version__ = "0.0.1"

from .config import configure_slack
