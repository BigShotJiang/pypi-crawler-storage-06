class Divider:
    @classmethod
    def divider(cls):
        return [{"type": "divider"}]
