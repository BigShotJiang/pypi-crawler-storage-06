import sys
sys.path.append('./src')
from music_bassline_generator.music_bassline_generator import Bassline

__version__ = "0.1.7"
