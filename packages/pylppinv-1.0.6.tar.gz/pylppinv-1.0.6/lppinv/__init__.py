__version__ = "1.0.6"

from .lppinv import lppinv

__all__ = [
    "lppinv",
    "__version__"
]
