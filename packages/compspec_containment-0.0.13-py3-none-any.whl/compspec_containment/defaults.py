# These are required to be given to compspec
spec_version = "0.0.0"
namespace = "compspec.github.io.containment"
