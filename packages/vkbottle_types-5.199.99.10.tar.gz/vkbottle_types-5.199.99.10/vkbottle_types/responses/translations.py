from vkbottle_types.codegen.responses.translations import *  # noqa: F403,F401
