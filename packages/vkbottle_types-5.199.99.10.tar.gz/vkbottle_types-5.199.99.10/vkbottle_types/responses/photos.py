from vkbottle_types.codegen.responses.photos import *  # noqa: F403,F401
