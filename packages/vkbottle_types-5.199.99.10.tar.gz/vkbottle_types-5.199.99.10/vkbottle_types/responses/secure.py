from vkbottle_types.codegen.responses.secure import *  # noqa: F403,F401


class SecureSetCounterIntegerResponse(BaseResponse):
    response: int
