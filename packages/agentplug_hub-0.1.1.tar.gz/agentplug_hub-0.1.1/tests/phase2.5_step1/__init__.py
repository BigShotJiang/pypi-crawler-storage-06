"""Phase 2.5 Step 1 Tests - Core Tools Foundation

Unit tests for the tool registry, @tool decorator, and FastMCP integration.
"""
