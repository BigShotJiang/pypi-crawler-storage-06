Credits
=======

PyAFBFdatabase is written and maintained by Frederic Richard, Professor at Aix-Marseille University, France.
