from __future__ import annotations

from django.apps import AppConfig


class DjangoMinifyHtmlAppConfig(AppConfig):
    name = "django_minify_html"
    verbose_name = "django-minify-html"
