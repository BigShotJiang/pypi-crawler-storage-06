"""
Templates package for RepoGif
"""