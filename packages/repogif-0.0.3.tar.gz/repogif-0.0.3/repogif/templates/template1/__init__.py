"""
Template 1 for RepoGif - A simple 2-frame GIF showing star button animation
"""