from .parse_args import run

run()