
class UnknownUsernameFormat(Exception):
    pass

class RelationDoesNotExist(Exception):
    pass

class ImproperConfigurationError(Exception):
    pass
