"""Main module entry point for elasticsearch_mcp_server."""

from .cli import cli_main

if __name__ == "__main__":
    cli_main()