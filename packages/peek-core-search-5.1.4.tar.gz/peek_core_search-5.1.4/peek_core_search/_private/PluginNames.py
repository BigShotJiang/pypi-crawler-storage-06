searchFilt = {"plugin": "peek_core_search"}
searchTuplePrefix = "peek_core_search."
searchObservableName = "peek_core_search"
searchActionProcessorName = "peek_core_search"
searchTupleOfflineServiceName = "peek_core_search"
