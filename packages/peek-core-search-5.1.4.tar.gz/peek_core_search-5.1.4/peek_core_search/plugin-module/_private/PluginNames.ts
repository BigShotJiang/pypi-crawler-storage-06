export let searchFilt = { plugin: "peek_core_search" };
export let searchTuplePrefix = "peek_core_search.";

export let searchObservableName = "peek_core_search";
export let searchActionProcessorName = "peek_core_search";
export let searchTupleOfflineServiceName = "peek_core_search";

export let searchBaseUrl = "peek_core_search";

export let searchIndexCacheStorageName = "peek_core_search.SearchIndex";

export let searchObjectCacheStorageName = "peek_core_search.SearchObject";

export let searchPluginName = "peek_core_search";
