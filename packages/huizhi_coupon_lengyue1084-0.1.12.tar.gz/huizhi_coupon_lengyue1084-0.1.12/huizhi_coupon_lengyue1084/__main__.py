from huizhi_coupon_lengyue1084 import main

main()