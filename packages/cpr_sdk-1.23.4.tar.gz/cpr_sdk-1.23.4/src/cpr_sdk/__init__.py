from .version import VERSION

__version__ = VERSION
