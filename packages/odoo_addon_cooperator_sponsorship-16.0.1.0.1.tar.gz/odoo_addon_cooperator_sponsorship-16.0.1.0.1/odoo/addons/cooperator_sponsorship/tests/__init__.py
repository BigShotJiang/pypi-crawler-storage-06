from .models import test_res_partner, test_subscription
from .wizards import test_member_wizard