This module extends the functionality of partners job position to
support having them categorized in list form and allow you to choose a
categorized job position for your contacts in addition to the current
custom string for job position.
