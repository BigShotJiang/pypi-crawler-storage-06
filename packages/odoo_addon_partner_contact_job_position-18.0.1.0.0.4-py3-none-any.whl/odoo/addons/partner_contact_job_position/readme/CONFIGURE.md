To configure job positions, you need to:

- Go to *Contacts \> Configuration \> Job Positions*.
