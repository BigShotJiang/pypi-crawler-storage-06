"""The `xml-etree-from-tree-sitter` module."""

__all__ = [
    "internal",
]

from . import internal
