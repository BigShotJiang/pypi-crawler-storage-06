# Citation

```
@InProceedings{McMillanHPCSYSPROS18,
  author = {McMillan, Scott},
  title = {Making Containers Easier with HPC Container Maker},
  url = {https://github.com/HPCSYSPROS/Workshop18/tree/master/Making_Containers_Easier_with_HPC_Container_Maker},
  booktitle = {In HPCSYSPROS18: HPC System Professionals Workshop},
  year = {2018},
  month = {November},
  address = {Dallas, TX},
}
```
