include('include2.py')
Stage0 += compiler
