"""This is bad python"""

Stage0 += baseimage()

# missing parenthesis
Stage0 += apt_get(['gcc']

Stage0 += apt_get(['make'])
