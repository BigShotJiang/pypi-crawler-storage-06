Stage0 += baseimage(image='ubuntu:16.04')
