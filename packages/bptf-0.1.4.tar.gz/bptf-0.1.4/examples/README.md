# backpack-tf - Examples
[`listings.py`](/examples/listing.py) for how to create and delete listings, [`websocket.py`](/examples/websocket.py) for how to listen to Backpack.tf listings using their [Websocket Service](https://next.backpack.tf/developer/websocket).


> [!TIP]
> Consider using tf2-utils' [ListingManager](https://github.com/offish/tf2-utils) instead of `backpack-tf` directly.