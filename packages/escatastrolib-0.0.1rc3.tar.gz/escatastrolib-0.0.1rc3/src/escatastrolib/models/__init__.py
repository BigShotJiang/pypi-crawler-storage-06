# ESCatastroLib/models/__init__.py
from .Calle import Calle
from .Municipio import Municipio
from .InfoCatastral import ParcelaCatastral, MetaParcela