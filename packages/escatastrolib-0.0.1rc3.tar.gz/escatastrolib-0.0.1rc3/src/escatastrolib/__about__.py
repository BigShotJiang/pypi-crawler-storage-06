# SPDX-FileCopyrightText: 2025-present Iván V.R <IvanVR@protonmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.0.1rc3'
