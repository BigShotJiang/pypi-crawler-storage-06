# SPDX-FileCopyrightText: 2025-present Iván V.R <IvanVR@protonmail.com>
#
# SPDX-License-Identifier: MIT

from .models import Calle, Municipio, ParcelaCatastral, MetaParcela
from .utils import exceptions, statics, utils