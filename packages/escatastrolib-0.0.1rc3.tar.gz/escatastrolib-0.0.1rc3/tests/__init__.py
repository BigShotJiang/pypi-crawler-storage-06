# SPDX-FileCopyrightText: 2025-present Iván V.R <IvanVR@protonmail.com>
#
# SPDX-License-Identifier: MIT
