# Query, search & stream

```{toctree}
:maxdepth: 1

registries
arrays
```
