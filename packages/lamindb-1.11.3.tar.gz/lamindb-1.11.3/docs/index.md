```{include} ../README.md
:start-line: 0
:end-line: 5
```

<meta http-equiv="Refresh" content="0; url=./guide.html" />

```{toctree}
:maxdepth: 1
:hidden:

guide
api
changelog
```
