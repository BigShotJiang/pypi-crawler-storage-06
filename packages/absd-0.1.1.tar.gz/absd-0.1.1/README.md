# absd

A simple Python library that prints 16 code snippets when functions are called.

## Usage

```python
import absd

absd.snippet1()
absd.snippet10()
```
