Now it's possible to search by and/or group by day of week for timesheets:

![Search by day of week](../static/img/01_search.png)

![Group by day of week](../static/img/02_groupby.png)

For timesheet and timesheet report list views, it's possible to view in a
different color those timesheets that belong to weekends:

![Colored list](../static/img/03_list.png)

and additionally use a filter for them:

![Filter by weekend timesheets](../static/img/04_filter.png)
