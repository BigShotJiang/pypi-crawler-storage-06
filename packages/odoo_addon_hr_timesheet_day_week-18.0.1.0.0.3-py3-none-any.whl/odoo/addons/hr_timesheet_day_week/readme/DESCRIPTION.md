For timesheets, enables search, group by the day of the week.
This is useful when e.g. weekend timesheets needs to be located.
