"""A suite of AI-powered command-line tools for text correction, audio transcription, and voice assistance."""
