def get_interface_label(interface):
    return f"{interface.device} {interface}"