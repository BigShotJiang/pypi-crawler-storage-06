from .slack import Slack


__all__ = [
    "Slack",
]
