# the special??wiki page8

with two, count 'em, 2 question marks (and no spaces after them) in the page name
