# what   about? #??____this ##page

spaces, question marks, octothorpes, and underscores

can you read it?
