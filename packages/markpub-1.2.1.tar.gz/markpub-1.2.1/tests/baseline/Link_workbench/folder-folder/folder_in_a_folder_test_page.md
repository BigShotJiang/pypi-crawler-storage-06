# folder in a folder page

2022-04-27:

 - this note is here to test finding wiki-links to a folder that is in a folder (or how to deal with the slashes and not get burned)

