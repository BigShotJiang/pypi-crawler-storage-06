# pageZero

On this page we are constructing a test page to help test some code to
create a data structure of what we call ...

[[backlinks|backlinks]].

The goal is to support the generation of html pages that contain both
so-called forward links [[to another page]], and then on that
particular page, here named "to another page", be able to provide a
link back to this page, the one we have named pageZero.md.

The simple thinking here is to read each wiki page and as we find
links append the needed backlink information; viz., the name of this
page, to a data item about that page. Got it? No? Me neither.



