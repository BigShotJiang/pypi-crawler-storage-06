# backlinks

these critters seemed to be called "Linked mentions" here in Obsidian.

(aside: it is interesting that i find this whole thing hard to think about or visualize)

