# the 80% good enough claim

- that is only 4 out of 5
- so maybe good enough?  
- good enough for AI work?  

let's link to a [[SaplingPage]], just for the connection  



