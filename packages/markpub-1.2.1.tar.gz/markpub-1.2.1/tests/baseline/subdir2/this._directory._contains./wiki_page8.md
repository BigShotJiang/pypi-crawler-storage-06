# wiki page8

The primary use of this page is to provide a test case for a path name
containing ". " elements.  
 - e.g.: `.../subdir2/this. directory. contains./wiki page8.md`  
 
 
