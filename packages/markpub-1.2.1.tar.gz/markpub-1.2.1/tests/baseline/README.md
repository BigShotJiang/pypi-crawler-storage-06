This directory contains corner-case directories, markdown files, and other non-markdown files.

This file is for you, a human to read, to know about this directory. It will also be read by mwb.py and be transformed into an output `index.html` file.

It is used as input for mwb.py to transform into generated output files. Those generated output files can then be compared with known good output files to see if mwb.py has had any regressions.

