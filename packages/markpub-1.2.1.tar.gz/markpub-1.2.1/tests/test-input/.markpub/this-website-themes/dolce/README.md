# Dolce

This is the "Dolce" theme for MarkPub.

It is licensed under the MIT License.
