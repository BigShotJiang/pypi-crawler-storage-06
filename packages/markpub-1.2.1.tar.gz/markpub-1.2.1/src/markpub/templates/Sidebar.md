### Site Navigation

{< div class="navlinks" >}
- [[README|HOME]]
- [SEARCH](/search.html)  
- [ALL PAGES](/all-pages.html)  
- [RECENT CHANGES](/recent-pages.html)
{< /div >}

{< div class="navlinks" >}
  <button onclick="location.href=`${randomPageLink()}`">
    RANDOM PAGE
  </button>
{< /div >}

