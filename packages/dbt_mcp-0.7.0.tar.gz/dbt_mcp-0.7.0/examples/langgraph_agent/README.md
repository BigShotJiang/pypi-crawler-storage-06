# LangGraph Agent Example

This is a simple example of how to create conversational agent with remote dbt MCP & LangGraph.

## Usage

1. Set an `ANTHROPIC_API_KEY` environment variable with your Anthropic API key.
2. Run `uv run main.py`.
