from .data_dto import DataEntity
