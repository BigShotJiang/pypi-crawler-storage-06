from .base_event import BaseEvent


class ScheduledEvent(BaseEvent): ...
