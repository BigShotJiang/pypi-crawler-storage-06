from .biomechzoo import BiomechZoo  # or from .core, etc.

__all__ = ['BiomechZoo']

__version__ = "0.1.0"
