def main():
    print("Hello from biomechzoo!")


if __name__ == "__main__":
    main()
