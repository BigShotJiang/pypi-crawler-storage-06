from skeletoken.decase.decase import decase_vocabulary

__all__ = ["decase_vocabulary"]
