from fglatch.workflows._provenance import get_execution_name
from fglatch.workflows._provenance import get_workflow_version

__all__ = [
    "get_execution_name",
    "get_workflow_version",
]
