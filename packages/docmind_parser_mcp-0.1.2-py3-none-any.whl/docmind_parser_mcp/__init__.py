from .server import start_main
def main() -> None:
    start_main()
