[← Back to Extensions index](index.md)

# Acceptable types
`schema.type` may be one of:
- `string`
- `number`
- `integer`
- `boolean`
- `array`
- `object`

