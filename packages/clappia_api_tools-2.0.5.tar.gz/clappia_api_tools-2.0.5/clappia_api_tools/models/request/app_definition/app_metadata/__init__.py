from .request import (
    UpdateAppMetadataRequest,
)

__all__ = [
    "UpdateAppMetadataRequest",
]