# npllm - No Prompt For LLM
