"""History management utilities for Shotgun agents."""

from .history_processors import token_limit_compactor

__all__ = ["token_limit_compactor"]
