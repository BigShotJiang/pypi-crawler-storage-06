"""
Utility functions for the diode package.
"""
