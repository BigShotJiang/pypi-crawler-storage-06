"""Tests for torch-mpo package."""
