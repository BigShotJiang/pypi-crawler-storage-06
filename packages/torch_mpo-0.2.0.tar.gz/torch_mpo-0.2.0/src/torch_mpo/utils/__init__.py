"""Utility functions for TT/MPO operations."""

from torch_mpo.utils.compression import compress_model

__all__ = ["compress_model"]
