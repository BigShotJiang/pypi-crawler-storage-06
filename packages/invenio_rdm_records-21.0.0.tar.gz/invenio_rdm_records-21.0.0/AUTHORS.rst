..
    Copyright (C) 2019 CERN.
    Copyright (C) 2019 Northwestern University.
    Copyright (C) 2021 TU Wien.
    Copyright (C) 2021 Graz University of Technology.

    Invenio-RDM-Records is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Authors
=======

DataCite-based data model for Invenio.

- CERN <info@inveniosoftware.org>

Translation:

- German
  - Graz University of Technology
  - University of Bamberg
