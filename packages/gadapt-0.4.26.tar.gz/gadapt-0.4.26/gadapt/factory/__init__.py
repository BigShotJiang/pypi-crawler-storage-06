"""
Instantiation of appropriate classes, based on selected options.
"""
