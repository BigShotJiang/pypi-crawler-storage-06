"""
GA Options validation
"""
