"""
Genetic Algorithm Model
"""
