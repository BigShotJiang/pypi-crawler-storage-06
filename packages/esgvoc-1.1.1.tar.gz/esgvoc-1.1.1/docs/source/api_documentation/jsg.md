# Json schema generator

```{eval-rst}
.. automodule:: esgvoc.apps.jsg.json_schema_generator
   :members:
   :member-order: groupwise
```
