.. _api_grab_spider_base:

.. module:: grab.spider.base

Module grab.spider
==================

.. module:: grab.spider.base
.. autoclass:: Spider
    :members: