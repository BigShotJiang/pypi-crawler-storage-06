from collections import namedtuple

UnsetType = namedtuple("UnsetType", "UNSET")(object())
UNSET = UnsetType.UNSET
