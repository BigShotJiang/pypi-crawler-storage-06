# Back-ward compatibility
# pylint: disable=unused-import, unused-wildcard-import, wildcard-import
from grab.document import *  # noqa
from grab.document import Document as Response  # noqa
# FIXME: throw warnings when anything from this proxy-module is used
