## cdf 

### Fixed

- [alpha] When running `cdf purge instances`, Toolkit now handles 408
responses from the API by splitting the request into multiple requests.
 
## templates

No changes.