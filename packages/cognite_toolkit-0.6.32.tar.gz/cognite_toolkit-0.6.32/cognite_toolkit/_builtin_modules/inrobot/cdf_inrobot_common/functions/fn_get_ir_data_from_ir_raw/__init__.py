"""Extract ir image data and ir temperature data from the ir raw file."""
