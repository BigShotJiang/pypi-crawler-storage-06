::: harp.devices.cameracontroller
