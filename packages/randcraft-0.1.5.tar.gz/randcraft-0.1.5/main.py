def main():
    print("Hello from randcraft!")


if __name__ == "__main__":
    main()
