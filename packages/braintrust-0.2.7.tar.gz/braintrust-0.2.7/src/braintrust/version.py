VERSION = "0.2.7"

# this will be templated during the build
GIT_COMMIT = "f7e1f2ac9f1767984bd125184f8b87563f249bfd"
