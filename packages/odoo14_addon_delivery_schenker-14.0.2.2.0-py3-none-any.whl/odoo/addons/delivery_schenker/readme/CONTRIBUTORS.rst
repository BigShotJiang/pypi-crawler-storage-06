* `Tecnativa <https://www.tecnativa.com>`_:

  * David Vidal

* `Studio73 <https://www.studio73.es>`_:

  * Ethan Hildick
* Michael Tietz (MT Software) <mtietz@mt-software.de>
