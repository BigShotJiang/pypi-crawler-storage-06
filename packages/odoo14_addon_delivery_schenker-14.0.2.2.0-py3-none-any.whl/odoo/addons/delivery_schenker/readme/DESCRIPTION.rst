This module links the `DB Schenker <https://www.dbschenker.com>`_ booking and tracking
APIs with Odoo delivery system.
