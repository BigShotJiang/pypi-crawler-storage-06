This module depends on the `zeep` python library and the OCA/delivery-carrier
`delivery_package_number` and `delivery_state` modules.

The Schenker API doesn't provide delivery rating methods, so OCA's
`delivery_price_method` is advised in order to use this carrier in a sales workflow.
