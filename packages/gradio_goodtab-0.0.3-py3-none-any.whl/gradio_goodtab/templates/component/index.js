var $s = Object.defineProperty;
var Da = (n) => {
  throw TypeError(n);
};
var Fs = (n, e, t) => e in n ? $s(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var he = (n, e, t) => Fs(n, typeof e != "symbol" ? e + "" : e, t), Cs = (n, e, t) => e.has(n) || Da("Cannot " + t);
var xa = (n, e, t) => e.has(n) ? Da("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(n) : e.set(n, t);
var er = (n, e, t) => (Cs(n, e, "access private method"), t);
function y0(n) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; n > 1e3 && t < e.length - 1; )
    n /= 1e3, t++;
  let r = e[t];
  return (Number.isInteger(n) ? n : n.toFixed(1)) + r;
}
function br() {
}
function Es(n, e) {
  return n != n ? e == e : n !== e || n && typeof n == "object" || typeof n == "function";
}
const Ki = typeof window < "u";
let Sa = Ki ? () => window.performance.now() : () => Date.now(), Qi = Ki ? (n) => requestAnimationFrame(n) : br;
const w0 = /* @__PURE__ */ new Set();
function Ji(n) {
  w0.forEach((e) => {
    e.c(n) || (w0.delete(e), e.f());
  }), w0.size !== 0 && Qi(Ji);
}
function Ts(n) {
  let e;
  return w0.size === 0 && Qi(Ji), {
    promise: new Promise((t) => {
      w0.add(e = { c: n, f: t });
    }),
    abort() {
      w0.delete(e);
    }
  };
}
const v0 = [];
function Ms(n, e = br) {
  let t;
  const r = /* @__PURE__ */ new Set();
  function a(o) {
    if (Es(n, o) && (n = o, t)) {
      const c = !v0.length;
      for (const m of r)
        m[1](), v0.push(m, n);
      if (c) {
        for (let m = 0; m < v0.length; m += 2)
          v0[m][0](v0[m + 1]);
        v0.length = 0;
      }
    }
  }
  function i(o) {
    a(o(n));
  }
  function l(o, c = br) {
    const m = [o, c];
    return r.add(m), r.size === 1 && (t = e(a, i) || br), o(n), () => {
      r.delete(m), r.size === 0 && t && (t(), t = null);
    };
  }
  return { set: a, update: i, subscribe: l };
}
function Aa(n) {
  return Object.prototype.toString.call(n) === "[object Date]";
}
function vn(n, e, t, r) {
  if (typeof t == "number" || Aa(t)) {
    const a = r - t, i = (t - e) / (n.dt || 1 / 60), l = n.opts.stiffness * a, o = n.opts.damping * i, c = (l - o) * n.inv_mass, m = (i + c) * n.dt;
    return Math.abs(m) < n.opts.precision && Math.abs(a) < n.opts.precision ? r : (n.settled = !1, Aa(t) ? new Date(t.getTime() + m) : t + m);
  } else {
    if (Array.isArray(t))
      return t.map(
        (a, i) => vn(n, e[i], t[i], r[i])
      );
    if (typeof t == "object") {
      const a = {};
      for (const i in t)
        a[i] = vn(n, e[i], t[i], r[i]);
      return a;
    } else
      throw new Error(`Cannot spring ${typeof t} values`);
  }
}
function $a(n, e = {}) {
  const t = Ms(n), { stiffness: r = 0.15, damping: a = 0.8, precision: i = 0.01 } = e;
  let l, o, c, m = n, d = n, p = 1, y = 0, v = !1;
  function x(F, E = {}) {
    d = F;
    const D = c = {};
    return n == null || E.hard || S.stiffness >= 1 && S.damping >= 1 ? (v = !0, l = Sa(), m = F, t.set(n = d), Promise.resolve()) : (E.soft && (y = 1 / ((E.soft === !0 ? 0.5 : +E.soft) * 60), p = 0), o || (l = Sa(), v = !1, o = Ts((g) => {
      if (v)
        return v = !1, o = null, !1;
      p = Math.min(p + y, 1);
      const A = {
        inv_mass: p,
        opts: S,
        settled: !0,
        dt: (g - l) * 60 / 1e3
      }, C = vn(A, m, n, d);
      return l = g, m = n, t.set(n = C), A.settled && (o = null), !A.settled;
    })), new Promise((g) => {
      o.promise.then(() => {
        D === c && g();
      });
    }));
  }
  const S = {
    set: x,
    update: (F, E) => x(F(d, n), E),
    subscribe: t.subscribe,
    stiffness: r,
    damping: a,
    precision: i
  };
  return S;
}
const {
  SvelteComponent: zs,
  append_hydration: ct,
  attr: ne,
  children: Ke,
  claim_element: Bs,
  claim_svg_element: mt,
  component_subscribe: Fa,
  detach: We,
  element: qs,
  init: Rs,
  insert_hydration: Ns,
  noop: Ca,
  safe_not_equal: Is,
  set_style: tr,
  svg_element: ht,
  toggle_class: Ea
} = window.__gradio__svelte__internal, { onMount: Ls } = window.__gradio__svelte__internal;
function Os(n) {
  let e, t, r, a, i, l, o, c, m, d, p, y;
  return {
    c() {
      e = qs("div"), t = ht("svg"), r = ht("g"), a = ht("path"), i = ht("path"), l = ht("path"), o = ht("path"), c = ht("g"), m = ht("path"), d = ht("path"), p = ht("path"), y = ht("path"), this.h();
    },
    l(v) {
      e = Bs(v, "DIV", { class: !0 });
      var x = Ke(e);
      t = mt(x, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var S = Ke(t);
      r = mt(S, "g", { style: !0 });
      var F = Ke(r);
      a = mt(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ke(a).forEach(We), i = mt(F, "path", { d: !0, fill: !0, class: !0 }), Ke(i).forEach(We), l = mt(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ke(l).forEach(We), o = mt(F, "path", { d: !0, fill: !0, class: !0 }), Ke(o).forEach(We), F.forEach(We), c = mt(S, "g", { style: !0 });
      var E = Ke(c);
      m = mt(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ke(m).forEach(We), d = mt(E, "path", { d: !0, fill: !0, class: !0 }), Ke(d).forEach(We), p = mt(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ke(p).forEach(We), y = mt(E, "path", { d: !0, fill: !0, class: !0 }), Ke(y).forEach(We), E.forEach(We), S.forEach(We), x.forEach(We), this.h();
    },
    h() {
      ne(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), ne(a, "fill", "#FF7C00"), ne(a, "fill-opacity", "0.4"), ne(a, "class", "svelte-43sxxs"), ne(i, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), ne(i, "fill", "#FF7C00"), ne(i, "class", "svelte-43sxxs"), ne(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), ne(l, "fill", "#FF7C00"), ne(l, "fill-opacity", "0.4"), ne(l, "class", "svelte-43sxxs"), ne(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), ne(o, "fill", "#FF7C00"), ne(o, "class", "svelte-43sxxs"), tr(r, "transform", "translate(" + /*$top*/
      n[1][0] + "px, " + /*$top*/
      n[1][1] + "px)"), ne(m, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), ne(m, "fill", "#FF7C00"), ne(m, "fill-opacity", "0.4"), ne(m, "class", "svelte-43sxxs"), ne(d, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), ne(d, "fill", "#FF7C00"), ne(d, "class", "svelte-43sxxs"), ne(p, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), ne(p, "fill", "#FF7C00"), ne(p, "fill-opacity", "0.4"), ne(p, "class", "svelte-43sxxs"), ne(y, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), ne(y, "fill", "#FF7C00"), ne(y, "class", "svelte-43sxxs"), tr(c, "transform", "translate(" + /*$bottom*/
      n[2][0] + "px, " + /*$bottom*/
      n[2][1] + "px)"), ne(t, "viewBox", "-1200 -1200 3000 3000"), ne(t, "fill", "none"), ne(t, "xmlns", "http://www.w3.org/2000/svg"), ne(t, "class", "svelte-43sxxs"), ne(e, "class", "svelte-43sxxs"), Ea(
        e,
        "margin",
        /*margin*/
        n[0]
      );
    },
    m(v, x) {
      Ns(v, e, x), ct(e, t), ct(t, r), ct(r, a), ct(r, i), ct(r, l), ct(r, o), ct(t, c), ct(c, m), ct(c, d), ct(c, p), ct(c, y);
    },
    p(v, [x]) {
      x & /*$top*/
      2 && tr(r, "transform", "translate(" + /*$top*/
      v[1][0] + "px, " + /*$top*/
      v[1][1] + "px)"), x & /*$bottom*/
      4 && tr(c, "transform", "translate(" + /*$bottom*/
      v[2][0] + "px, " + /*$bottom*/
      v[2][1] + "px)"), x & /*margin*/
      1 && Ea(
        e,
        "margin",
        /*margin*/
        v[0]
      );
    },
    i: Ca,
    o: Ca,
    d(v) {
      v && We(e);
    }
  };
}
function Ps(n, e, t) {
  let r, a, { margin: i = !0 } = e;
  const l = $a([0, 0]);
  Fa(n, l, (y) => t(1, r = y));
  const o = $a([0, 0]);
  Fa(n, o, (y) => t(2, a = y));
  let c;
  async function m() {
    await Promise.all([l.set([125, 140]), o.set([-125, -140])]), await Promise.all([l.set([-125, 140]), o.set([125, -140])]), await Promise.all([l.set([-125, 0]), o.set([125, -0])]), await Promise.all([l.set([125, 0]), o.set([-125, 0])]);
  }
  async function d() {
    await m(), c || d();
  }
  async function p() {
    await Promise.all([l.set([125, 0]), o.set([-125, 0])]), d();
  }
  return Ls(() => (p(), () => c = !0)), n.$$set = (y) => {
    "margin" in y && t(0, i = y.margin);
  }, [i, r, a, l, o];
}
class Hs extends zs {
  constructor(e) {
    super(), Rs(this, e, Ps, Os, Is, { margin: 0 });
  }
}
const {
  SvelteComponent: Pc,
  append_hydration: Hc,
  assign: Uc,
  attr: Vc,
  binding_callbacks: Gc,
  children: Yc,
  claim_element: Wc,
  claim_space: jc,
  claim_svg_element: Xc,
  create_slot: Zc,
  detach: Kc,
  element: Qc,
  empty: Jc,
  get_all_dirty_from_scope: em,
  get_slot_changes: tm,
  get_spread_update: rm,
  init: nm,
  insert_hydration: am,
  listen: im,
  noop: lm,
  safe_not_equal: sm,
  set_dynamic_element_data: om,
  set_style: um,
  space: cm,
  svg_element: mm,
  toggle_class: hm,
  transition_in: dm,
  transition_out: fm,
  update_slot_base: pm
} = window.__gradio__svelte__internal;
class Bn {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(e, t, r) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = r;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(e, t) {
    return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new Bn(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
  }
}
class qn {
  // don't expand the token
  // used in \noexpand
  constructor(e, t) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(e, t) {
    return new qn(t, Bn.range(this, e));
  }
}
class G {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(e, t) {
    this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
    var r = "KaTeX parse error: " + e, a, i, l = t && t.loc;
    if (l && l.start <= l.end) {
      var o = l.lexer.input;
      a = l.start, i = l.end, a === o.length ? r += " at end of input: " : r += " at position " + (a + 1) + ": ";
      var c = o.slice(a, i).replace(/[^]/g, "$&̲"), m;
      a > 15 ? m = "…" + o.slice(a - 15, a) : m = o.slice(0, a);
      var d;
      i + 15 < o.length ? d = o.slice(i, i + 15) + "…" : d = o.slice(i), r += m + c + d;
    }
    var p = new Error(r);
    return p.name = "ParseError", p.__proto__ = G.prototype, p.position = a, a != null && i != null && (p.length = i - a), p.rawMessage = e, p;
  }
}
G.prototype.__proto__ = Error.prototype;
var Us = function(e, t) {
  return e.indexOf(t) !== -1;
}, Vs = function(e, t) {
  return e === void 0 ? t : e;
}, Gs = /([A-Z])/g, Ys = function(e) {
  return e.replace(Gs, "-$1").toLowerCase();
}, Ws = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
}, js = /[&><"']/g;
function Xs(n) {
  return String(n).replace(js, (e) => Ws[e]);
}
var el = function n(e) {
  return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? n(e.body[0]) : e : e.type === "font" ? n(e.body) : e;
}, Zs = function(e) {
  var t = el(e);
  return t.type === "mathord" || t.type === "textord" || t.type === "atom";
}, Ks = function(e) {
  if (!e)
    throw new Error("Expected non-null, but got " + String(e));
  return e;
}, Qs = function(e) {
  var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
  return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, j = {
  contains: Us,
  deflt: Vs,
  escape: Xs,
  hyphenate: Ys,
  getBaseElem: el,
  isCharacterBox: Zs,
  protocolFromUrl: Qs
};
class Xt {
  constructor(e, t, r) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = r;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return Dt[Js[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return Dt[eo[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return Dt[to[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return Dt[ro[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return Dt[no[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return Dt[ao[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var Rn = 0, xr = 1, k0 = 2, Gt = 3, V0 = 4, et = 5, D0 = 6, Ie = 7, Dt = [new Xt(Rn, 0, !1), new Xt(xr, 0, !0), new Xt(k0, 1, !1), new Xt(Gt, 1, !0), new Xt(V0, 2, !1), new Xt(et, 2, !0), new Xt(D0, 3, !1), new Xt(Ie, 3, !0)], Js = [V0, et, V0, et, D0, Ie, D0, Ie], eo = [et, et, et, et, Ie, Ie, Ie, Ie], to = [k0, Gt, V0, et, D0, Ie, D0, Ie], ro = [Gt, Gt, et, et, Ie, Ie, Ie, Ie], no = [xr, xr, Gt, Gt, et, et, Ie, Ie], ao = [Rn, xr, k0, Gt, k0, Gt, k0, Gt], X = {
  DISPLAY: Dt[Rn],
  TEXT: Dt[k0],
  SCRIPT: Dt[V0],
  SCRIPTSCRIPT: Dt[D0]
}, bn = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function io(n) {
  for (var e = 0; e < bn.length; e++)
    for (var t = bn[e], r = 0; r < t.blocks.length; r++) {
      var a = t.blocks[r];
      if (n >= a[0] && n <= a[1])
        return t.name;
    }
  return null;
}
var yr = [];
bn.forEach((n) => n.blocks.forEach((e) => yr.push(...e)));
function lo(n) {
  for (var e = 0; e < yr.length; e += 2)
    if (n >= yr[e] && n <= yr[e + 1])
      return !0;
  return !1;
}
var b0 = 80, so = function(e, t) {
  return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, oo = function(e, t) {
  return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, uo = function(e, t) {
  return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, co = function(e, t) {
  return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, mo = function(e, t) {
  return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, ho = function(e) {
  var t = e / 2;
  return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, fo = function(e, t, r) {
  var a = r - 54 - t - e;
  return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + a + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, po = function(e, t, r) {
  t = 1e3 * t;
  var a = "";
  switch (e) {
    case "sqrtMain":
      a = so(t, b0);
      break;
    case "sqrtSize1":
      a = oo(t, b0);
      break;
    case "sqrtSize2":
      a = uo(t, b0);
      break;
    case "sqrtSize3":
      a = co(t, b0);
      break;
    case "sqrtSize4":
      a = mo(t, b0);
      break;
    case "sqrtTall":
      a = fo(t, b0, r);
  }
  return a;
}, go = function(e, t) {
  switch (e) {
    case "⎜":
      return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
    case "∣":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
    case "∥":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
    case "⎟":
      return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
    case "⎢":
      return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
    case "⎥":
      return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
    case "⎪":
      return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
    case "⏐":
      return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
    case "‖":
      return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
    default:
      return "";
  }
}, Ta = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
  leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
  leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
  leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
  leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
  leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
  leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
  leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
  longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
  midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
  midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
  oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
  oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
  oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
  oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
  rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
  rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
  rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
  rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
  rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
  rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
  rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
  rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
  rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
  righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
  rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
  rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
  twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
  // ditto tilde2, tilde3, & tilde4
  tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
  tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
  tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
  // ditto widehat2, widehat3, & widehat4
  widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  // widecheck paths are all inverted versions of widehat
  widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
  widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
  rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
  shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
  shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
}, _o = function(e, t) {
  switch (e) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
    case "lparen":
      return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
    case "rparen":
      return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class Y0 {
  // HtmlDomNode
  // Never used; needed for satisfying interface.
  constructor(e) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  /** Convert the fragment into a node. */
  toNode() {
    for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
      e.appendChild(this.children[t].toNode());
    return e;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    for (var e = "", t = 0; t < this.children.length; t++)
      e += this.children[t].toMarkup();
    return e;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var e = (t) => t.toText();
    return this.children.map(e).join("");
  }
}
var Vt = {
  "AMS-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68889, 0, 0, 0.72222],
    66: [0, 0.68889, 0, 0, 0.66667],
    67: [0, 0.68889, 0, 0, 0.72222],
    68: [0, 0.68889, 0, 0, 0.72222],
    69: [0, 0.68889, 0, 0, 0.66667],
    70: [0, 0.68889, 0, 0, 0.61111],
    71: [0, 0.68889, 0, 0, 0.77778],
    72: [0, 0.68889, 0, 0, 0.77778],
    73: [0, 0.68889, 0, 0, 0.38889],
    74: [0.16667, 0.68889, 0, 0, 0.5],
    75: [0, 0.68889, 0, 0, 0.77778],
    76: [0, 0.68889, 0, 0, 0.66667],
    77: [0, 0.68889, 0, 0, 0.94445],
    78: [0, 0.68889, 0, 0, 0.72222],
    79: [0.16667, 0.68889, 0, 0, 0.77778],
    80: [0, 0.68889, 0, 0, 0.61111],
    81: [0.16667, 0.68889, 0, 0, 0.77778],
    82: [0, 0.68889, 0, 0, 0.72222],
    83: [0, 0.68889, 0, 0, 0.55556],
    84: [0, 0.68889, 0, 0, 0.66667],
    85: [0, 0.68889, 0, 0, 0.72222],
    86: [0, 0.68889, 0, 0, 0.72222],
    87: [0, 0.68889, 0, 0, 1],
    88: [0, 0.68889, 0, 0, 0.72222],
    89: [0, 0.68889, 0, 0, 0.72222],
    90: [0, 0.68889, 0, 0, 0.66667],
    107: [0, 0.68889, 0, 0, 0.55556],
    160: [0, 0, 0, 0, 0.25],
    165: [0, 0.675, 0.025, 0, 0.75],
    174: [0.15559, 0.69224, 0, 0, 0.94666],
    240: [0, 0.68889, 0, 0, 0.55556],
    295: [0, 0.68889, 0, 0, 0.54028],
    710: [0, 0.825, 0, 0, 2.33334],
    732: [0, 0.9, 0, 0, 2.33334],
    770: [0, 0.825, 0, 0, 2.33334],
    771: [0, 0.9, 0, 0, 2.33334],
    989: [0.08167, 0.58167, 0, 0, 0.77778],
    1008: [0, 0.43056, 0.04028, 0, 0.66667],
    8245: [0, 0.54986, 0, 0, 0.275],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8487: [0, 0.68889, 0, 0, 0.72222],
    8498: [0, 0.68889, 0, 0, 0.55556],
    8502: [0, 0.68889, 0, 0, 0.66667],
    8503: [0, 0.68889, 0, 0, 0.44445],
    8504: [0, 0.68889, 0, 0, 0.66667],
    8513: [0, 0.68889, 0, 0, 0.63889],
    8592: [-0.03598, 0.46402, 0, 0, 0.5],
    8594: [-0.03598, 0.46402, 0, 0, 0.5],
    8602: [-0.13313, 0.36687, 0, 0, 1],
    8603: [-0.13313, 0.36687, 0, 0, 1],
    8606: [0.01354, 0.52239, 0, 0, 1],
    8608: [0.01354, 0.52239, 0, 0, 1],
    8610: [0.01354, 0.52239, 0, 0, 1.11111],
    8611: [0.01354, 0.52239, 0, 0, 1.11111],
    8619: [0, 0.54986, 0, 0, 1],
    8620: [0, 0.54986, 0, 0, 1],
    8621: [-0.13313, 0.37788, 0, 0, 1.38889],
    8622: [-0.13313, 0.36687, 0, 0, 1],
    8624: [0, 0.69224, 0, 0, 0.5],
    8625: [0, 0.69224, 0, 0, 0.5],
    8630: [0, 0.43056, 0, 0, 1],
    8631: [0, 0.43056, 0, 0, 1],
    8634: [0.08198, 0.58198, 0, 0, 0.77778],
    8635: [0.08198, 0.58198, 0, 0, 0.77778],
    8638: [0.19444, 0.69224, 0, 0, 0.41667],
    8639: [0.19444, 0.69224, 0, 0, 0.41667],
    8642: [0.19444, 0.69224, 0, 0, 0.41667],
    8643: [0.19444, 0.69224, 0, 0, 0.41667],
    8644: [0.1808, 0.675, 0, 0, 1],
    8646: [0.1808, 0.675, 0, 0, 1],
    8647: [0.1808, 0.675, 0, 0, 1],
    8648: [0.19444, 0.69224, 0, 0, 0.83334],
    8649: [0.1808, 0.675, 0, 0, 1],
    8650: [0.19444, 0.69224, 0, 0, 0.83334],
    8651: [0.01354, 0.52239, 0, 0, 1],
    8652: [0.01354, 0.52239, 0, 0, 1],
    8653: [-0.13313, 0.36687, 0, 0, 1],
    8654: [-0.13313, 0.36687, 0, 0, 1],
    8655: [-0.13313, 0.36687, 0, 0, 1],
    8666: [0.13667, 0.63667, 0, 0, 1],
    8667: [0.13667, 0.63667, 0, 0, 1],
    8669: [-0.13313, 0.37788, 0, 0, 1],
    8672: [-0.064, 0.437, 0, 0, 1.334],
    8674: [-0.064, 0.437, 0, 0, 1.334],
    8705: [0, 0.825, 0, 0, 0.5],
    8708: [0, 0.68889, 0, 0, 0.55556],
    8709: [0.08167, 0.58167, 0, 0, 0.77778],
    8717: [0, 0.43056, 0, 0, 0.42917],
    8722: [-0.03598, 0.46402, 0, 0, 0.5],
    8724: [0.08198, 0.69224, 0, 0, 0.77778],
    8726: [0.08167, 0.58167, 0, 0, 0.77778],
    8733: [0, 0.69224, 0, 0, 0.77778],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8737: [0, 0.69224, 0, 0, 0.72222],
    8738: [0.03517, 0.52239, 0, 0, 0.72222],
    8739: [0.08167, 0.58167, 0, 0, 0.22222],
    8740: [0.25142, 0.74111, 0, 0, 0.27778],
    8741: [0.08167, 0.58167, 0, 0, 0.38889],
    8742: [0.25142, 0.74111, 0, 0, 0.5],
    8756: [0, 0.69224, 0, 0, 0.66667],
    8757: [0, 0.69224, 0, 0, 0.66667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8765: [-0.13313, 0.37788, 0, 0, 0.77778],
    8769: [-0.13313, 0.36687, 0, 0, 0.77778],
    8770: [-0.03625, 0.46375, 0, 0, 0.77778],
    8774: [0.30274, 0.79383, 0, 0, 0.77778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8778: [0.08167, 0.58167, 0, 0, 0.77778],
    8782: [0.06062, 0.54986, 0, 0, 0.77778],
    8783: [0.06062, 0.54986, 0, 0, 0.77778],
    8785: [0.08198, 0.58198, 0, 0, 0.77778],
    8786: [0.08198, 0.58198, 0, 0, 0.77778],
    8787: [0.08198, 0.58198, 0, 0, 0.77778],
    8790: [0, 0.69224, 0, 0, 0.77778],
    8791: [0.22958, 0.72958, 0, 0, 0.77778],
    8796: [0.08198, 0.91667, 0, 0, 0.77778],
    8806: [0.25583, 0.75583, 0, 0, 0.77778],
    8807: [0.25583, 0.75583, 0, 0, 0.77778],
    8808: [0.25142, 0.75726, 0, 0, 0.77778],
    8809: [0.25142, 0.75726, 0, 0, 0.77778],
    8812: [0.25583, 0.75583, 0, 0, 0.5],
    8814: [0.20576, 0.70576, 0, 0, 0.77778],
    8815: [0.20576, 0.70576, 0, 0, 0.77778],
    8816: [0.30274, 0.79383, 0, 0, 0.77778],
    8817: [0.30274, 0.79383, 0, 0, 0.77778],
    8818: [0.22958, 0.72958, 0, 0, 0.77778],
    8819: [0.22958, 0.72958, 0, 0, 0.77778],
    8822: [0.1808, 0.675, 0, 0, 0.77778],
    8823: [0.1808, 0.675, 0, 0, 0.77778],
    8828: [0.13667, 0.63667, 0, 0, 0.77778],
    8829: [0.13667, 0.63667, 0, 0, 0.77778],
    8830: [0.22958, 0.72958, 0, 0, 0.77778],
    8831: [0.22958, 0.72958, 0, 0, 0.77778],
    8832: [0.20576, 0.70576, 0, 0, 0.77778],
    8833: [0.20576, 0.70576, 0, 0, 0.77778],
    8840: [0.30274, 0.79383, 0, 0, 0.77778],
    8841: [0.30274, 0.79383, 0, 0, 0.77778],
    8842: [0.13597, 0.63597, 0, 0, 0.77778],
    8843: [0.13597, 0.63597, 0, 0, 0.77778],
    8847: [0.03517, 0.54986, 0, 0, 0.77778],
    8848: [0.03517, 0.54986, 0, 0, 0.77778],
    8858: [0.08198, 0.58198, 0, 0, 0.77778],
    8859: [0.08198, 0.58198, 0, 0, 0.77778],
    8861: [0.08198, 0.58198, 0, 0, 0.77778],
    8862: [0, 0.675, 0, 0, 0.77778],
    8863: [0, 0.675, 0, 0, 0.77778],
    8864: [0, 0.675, 0, 0, 0.77778],
    8865: [0, 0.675, 0, 0, 0.77778],
    8872: [0, 0.69224, 0, 0, 0.61111],
    8873: [0, 0.69224, 0, 0, 0.72222],
    8874: [0, 0.69224, 0, 0, 0.88889],
    8876: [0, 0.68889, 0, 0, 0.61111],
    8877: [0, 0.68889, 0, 0, 0.61111],
    8878: [0, 0.68889, 0, 0, 0.72222],
    8879: [0, 0.68889, 0, 0, 0.72222],
    8882: [0.03517, 0.54986, 0, 0, 0.77778],
    8883: [0.03517, 0.54986, 0, 0, 0.77778],
    8884: [0.13667, 0.63667, 0, 0, 0.77778],
    8885: [0.13667, 0.63667, 0, 0, 0.77778],
    8888: [0, 0.54986, 0, 0, 1.11111],
    8890: [0.19444, 0.43056, 0, 0, 0.55556],
    8891: [0.19444, 0.69224, 0, 0, 0.61111],
    8892: [0.19444, 0.69224, 0, 0, 0.61111],
    8901: [0, 0.54986, 0, 0, 0.27778],
    8903: [0.08167, 0.58167, 0, 0, 0.77778],
    8905: [0.08167, 0.58167, 0, 0, 0.77778],
    8906: [0.08167, 0.58167, 0, 0, 0.77778],
    8907: [0, 0.69224, 0, 0, 0.77778],
    8908: [0, 0.69224, 0, 0, 0.77778],
    8909: [-0.03598, 0.46402, 0, 0, 0.77778],
    8910: [0, 0.54986, 0, 0, 0.76042],
    8911: [0, 0.54986, 0, 0, 0.76042],
    8912: [0.03517, 0.54986, 0, 0, 0.77778],
    8913: [0.03517, 0.54986, 0, 0, 0.77778],
    8914: [0, 0.54986, 0, 0, 0.66667],
    8915: [0, 0.54986, 0, 0, 0.66667],
    8916: [0, 0.69224, 0, 0, 0.66667],
    8918: [0.0391, 0.5391, 0, 0, 0.77778],
    8919: [0.0391, 0.5391, 0, 0, 0.77778],
    8920: [0.03517, 0.54986, 0, 0, 1.33334],
    8921: [0.03517, 0.54986, 0, 0, 1.33334],
    8922: [0.38569, 0.88569, 0, 0, 0.77778],
    8923: [0.38569, 0.88569, 0, 0, 0.77778],
    8926: [0.13667, 0.63667, 0, 0, 0.77778],
    8927: [0.13667, 0.63667, 0, 0, 0.77778],
    8928: [0.30274, 0.79383, 0, 0, 0.77778],
    8929: [0.30274, 0.79383, 0, 0, 0.77778],
    8934: [0.23222, 0.74111, 0, 0, 0.77778],
    8935: [0.23222, 0.74111, 0, 0, 0.77778],
    8936: [0.23222, 0.74111, 0, 0, 0.77778],
    8937: [0.23222, 0.74111, 0, 0, 0.77778],
    8938: [0.20576, 0.70576, 0, 0, 0.77778],
    8939: [0.20576, 0.70576, 0, 0, 0.77778],
    8940: [0.30274, 0.79383, 0, 0, 0.77778],
    8941: [0.30274, 0.79383, 0, 0, 0.77778],
    8994: [0.19444, 0.69224, 0, 0, 0.77778],
    8995: [0.19444, 0.69224, 0, 0, 0.77778],
    9416: [0.15559, 0.69224, 0, 0, 0.90222],
    9484: [0, 0.69224, 0, 0, 0.5],
    9488: [0, 0.69224, 0, 0, 0.5],
    9492: [0, 0.37788, 0, 0, 0.5],
    9496: [0, 0.37788, 0, 0, 0.5],
    9585: [0.19444, 0.68889, 0, 0, 0.88889],
    9586: [0.19444, 0.74111, 0, 0, 0.88889],
    9632: [0, 0.675, 0, 0, 0.77778],
    9633: [0, 0.675, 0, 0, 0.77778],
    9650: [0, 0.54986, 0, 0, 0.72222],
    9651: [0, 0.54986, 0, 0, 0.72222],
    9654: [0.03517, 0.54986, 0, 0, 0.77778],
    9660: [0, 0.54986, 0, 0, 0.72222],
    9661: [0, 0.54986, 0, 0, 0.72222],
    9664: [0.03517, 0.54986, 0, 0, 0.77778],
    9674: [0.11111, 0.69224, 0, 0, 0.66667],
    9733: [0.19444, 0.69224, 0, 0, 0.94445],
    10003: [0, 0.69224, 0, 0, 0.83334],
    10016: [0, 0.69224, 0, 0, 0.83334],
    10731: [0.11111, 0.69224, 0, 0, 0.66667],
    10846: [0.19444, 0.75583, 0, 0, 0.61111],
    10877: [0.13667, 0.63667, 0, 0, 0.77778],
    10878: [0.13667, 0.63667, 0, 0, 0.77778],
    10885: [0.25583, 0.75583, 0, 0, 0.77778],
    10886: [0.25583, 0.75583, 0, 0, 0.77778],
    10887: [0.13597, 0.63597, 0, 0, 0.77778],
    10888: [0.13597, 0.63597, 0, 0, 0.77778],
    10889: [0.26167, 0.75726, 0, 0, 0.77778],
    10890: [0.26167, 0.75726, 0, 0, 0.77778],
    10891: [0.48256, 0.98256, 0, 0, 0.77778],
    10892: [0.48256, 0.98256, 0, 0, 0.77778],
    10901: [0.13667, 0.63667, 0, 0, 0.77778],
    10902: [0.13667, 0.63667, 0, 0, 0.77778],
    10933: [0.25142, 0.75726, 0, 0, 0.77778],
    10934: [0.25142, 0.75726, 0, 0, 0.77778],
    10935: [0.26167, 0.75726, 0, 0, 0.77778],
    10936: [0.26167, 0.75726, 0, 0, 0.77778],
    10937: [0.26167, 0.75726, 0, 0, 0.77778],
    10938: [0.26167, 0.75726, 0, 0, 0.77778],
    10949: [0.25583, 0.75583, 0, 0, 0.77778],
    10950: [0.25583, 0.75583, 0, 0, 0.77778],
    10955: [0.28481, 0.79383, 0, 0, 0.77778],
    10956: [0.28481, 0.79383, 0, 0, 0.77778],
    57350: [0.08167, 0.58167, 0, 0, 0.22222],
    57351: [0.08167, 0.58167, 0, 0, 0.38889],
    57352: [0.08167, 0.58167, 0, 0, 0.77778],
    57353: [0, 0.43056, 0.04028, 0, 0.66667],
    57356: [0.25142, 0.75726, 0, 0, 0.77778],
    57357: [0.25142, 0.75726, 0, 0, 0.77778],
    57358: [0.41951, 0.91951, 0, 0, 0.77778],
    57359: [0.30274, 0.79383, 0, 0, 0.77778],
    57360: [0.30274, 0.79383, 0, 0, 0.77778],
    57361: [0.41951, 0.91951, 0, 0, 0.77778],
    57366: [0.25142, 0.75726, 0, 0, 0.77778],
    57367: [0.25142, 0.75726, 0, 0, 0.77778],
    57368: [0.25142, 0.75726, 0, 0, 0.77778],
    57369: [0.25142, 0.75726, 0, 0, 0.77778],
    57370: [0.13597, 0.63597, 0, 0, 0.77778],
    57371: [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68333, 0, 0.19445, 0.79847],
    66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
    67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
    68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
    69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
    70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
    71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
    73: [0, 0.68333, 0.07382, 0, 0.54452],
    74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
    76: [0, 0.68333, 0, 0.13889, 0.68972],
    77: [0, 0.68333, 0, 0.13889, 1.2009],
    78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
    79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
    80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
    81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
    82: [0, 0.68333, 0, 0.08334, 0.8475],
    83: [0, 0.68333, 0.075, 0.13889, 0.60556],
    84: [0, 0.68333, 0.25417, 0, 0.54464],
    85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
    86: [0, 0.68333, 0.08222, 0, 0.61278],
    87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
    88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
    89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
    160: [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69141, 0, 0, 0.29574],
    34: [0, 0.69141, 0, 0, 0.21471],
    38: [0, 0.69141, 0, 0, 0.73786],
    39: [0, 0.69141, 0, 0, 0.21201],
    40: [0.24982, 0.74947, 0, 0, 0.38865],
    41: [0.24982, 0.74947, 0, 0, 0.38865],
    42: [0, 0.62119, 0, 0, 0.27764],
    43: [0.08319, 0.58283, 0, 0, 0.75623],
    44: [0, 0.10803, 0, 0, 0.27764],
    45: [0.08319, 0.58283, 0, 0, 0.75623],
    46: [0, 0.10803, 0, 0, 0.27764],
    47: [0.24982, 0.74947, 0, 0, 0.50181],
    48: [0, 0.47534, 0, 0, 0.50181],
    49: [0, 0.47534, 0, 0, 0.50181],
    50: [0, 0.47534, 0, 0, 0.50181],
    51: [0.18906, 0.47534, 0, 0, 0.50181],
    52: [0.18906, 0.47534, 0, 0, 0.50181],
    53: [0.18906, 0.47534, 0, 0, 0.50181],
    54: [0, 0.69141, 0, 0, 0.50181],
    55: [0.18906, 0.47534, 0, 0, 0.50181],
    56: [0, 0.69141, 0, 0, 0.50181],
    57: [0.18906, 0.47534, 0, 0, 0.50181],
    58: [0, 0.47534, 0, 0, 0.21606],
    59: [0.12604, 0.47534, 0, 0, 0.21606],
    61: [-0.13099, 0.36866, 0, 0, 0.75623],
    63: [0, 0.69141, 0, 0, 0.36245],
    65: [0, 0.69141, 0, 0, 0.7176],
    66: [0, 0.69141, 0, 0, 0.88397],
    67: [0, 0.69141, 0, 0, 0.61254],
    68: [0, 0.69141, 0, 0, 0.83158],
    69: [0, 0.69141, 0, 0, 0.66278],
    70: [0.12604, 0.69141, 0, 0, 0.61119],
    71: [0, 0.69141, 0, 0, 0.78539],
    72: [0.06302, 0.69141, 0, 0, 0.7203],
    73: [0, 0.69141, 0, 0, 0.55448],
    74: [0.12604, 0.69141, 0, 0, 0.55231],
    75: [0, 0.69141, 0, 0, 0.66845],
    76: [0, 0.69141, 0, 0, 0.66602],
    77: [0, 0.69141, 0, 0, 1.04953],
    78: [0, 0.69141, 0, 0, 0.83212],
    79: [0, 0.69141, 0, 0, 0.82699],
    80: [0.18906, 0.69141, 0, 0, 0.82753],
    81: [0.03781, 0.69141, 0, 0, 0.82699],
    82: [0, 0.69141, 0, 0, 0.82807],
    83: [0, 0.69141, 0, 0, 0.82861],
    84: [0, 0.69141, 0, 0, 0.66899],
    85: [0, 0.69141, 0, 0, 0.64576],
    86: [0, 0.69141, 0, 0, 0.83131],
    87: [0, 0.69141, 0, 0, 1.04602],
    88: [0, 0.69141, 0, 0, 0.71922],
    89: [0.18906, 0.69141, 0, 0, 0.83293],
    90: [0.12604, 0.69141, 0, 0, 0.60201],
    91: [0.24982, 0.74947, 0, 0, 0.27764],
    93: [0.24982, 0.74947, 0, 0, 0.27764],
    94: [0, 0.69141, 0, 0, 0.49965],
    97: [0, 0.47534, 0, 0, 0.50046],
    98: [0, 0.69141, 0, 0, 0.51315],
    99: [0, 0.47534, 0, 0, 0.38946],
    100: [0, 0.62119, 0, 0, 0.49857],
    101: [0, 0.47534, 0, 0, 0.40053],
    102: [0.18906, 0.69141, 0, 0, 0.32626],
    103: [0.18906, 0.47534, 0, 0, 0.5037],
    104: [0.18906, 0.69141, 0, 0, 0.52126],
    105: [0, 0.69141, 0, 0, 0.27899],
    106: [0, 0.69141, 0, 0, 0.28088],
    107: [0, 0.69141, 0, 0, 0.38946],
    108: [0, 0.69141, 0, 0, 0.27953],
    109: [0, 0.47534, 0, 0, 0.76676],
    110: [0, 0.47534, 0, 0, 0.52666],
    111: [0, 0.47534, 0, 0, 0.48885],
    112: [0.18906, 0.52396, 0, 0, 0.50046],
    113: [0.18906, 0.47534, 0, 0, 0.48912],
    114: [0, 0.47534, 0, 0, 0.38919],
    115: [0, 0.47534, 0, 0, 0.44266],
    116: [0, 0.62119, 0, 0, 0.33301],
    117: [0, 0.47534, 0, 0, 0.5172],
    118: [0, 0.52396, 0, 0, 0.5118],
    119: [0, 0.52396, 0, 0, 0.77351],
    120: [0.18906, 0.47534, 0, 0, 0.38865],
    121: [0.18906, 0.47534, 0, 0, 0.49884],
    122: [0.18906, 0.47534, 0, 0, 0.39054],
    160: [0, 0, 0, 0, 0.25],
    8216: [0, 0.69141, 0, 0, 0.21471],
    8217: [0, 0.69141, 0, 0, 0.21471],
    58112: [0, 0.62119, 0, 0, 0.49749],
    58113: [0, 0.62119, 0, 0, 0.4983],
    58114: [0.18906, 0.69141, 0, 0, 0.33328],
    58115: [0.18906, 0.69141, 0, 0, 0.32923],
    58116: [0.18906, 0.47534, 0, 0, 0.50343],
    58117: [0, 0.69141, 0, 0, 0.33301],
    58118: [0, 0.62119, 0, 0, 0.33409],
    58119: [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.35],
    34: [0, 0.69444, 0, 0, 0.60278],
    35: [0.19444, 0.69444, 0, 0, 0.95833],
    36: [0.05556, 0.75, 0, 0, 0.575],
    37: [0.05556, 0.75, 0, 0, 0.95833],
    38: [0, 0.69444, 0, 0, 0.89444],
    39: [0, 0.69444, 0, 0, 0.31944],
    40: [0.25, 0.75, 0, 0, 0.44722],
    41: [0.25, 0.75, 0, 0, 0.44722],
    42: [0, 0.75, 0, 0, 0.575],
    43: [0.13333, 0.63333, 0, 0, 0.89444],
    44: [0.19444, 0.15556, 0, 0, 0.31944],
    45: [0, 0.44444, 0, 0, 0.38333],
    46: [0, 0.15556, 0, 0, 0.31944],
    47: [0.25, 0.75, 0, 0, 0.575],
    48: [0, 0.64444, 0, 0, 0.575],
    49: [0, 0.64444, 0, 0, 0.575],
    50: [0, 0.64444, 0, 0, 0.575],
    51: [0, 0.64444, 0, 0, 0.575],
    52: [0, 0.64444, 0, 0, 0.575],
    53: [0, 0.64444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0, 0.64444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0, 0.64444, 0, 0, 0.575],
    58: [0, 0.44444, 0, 0, 0.31944],
    59: [0.19444, 0.44444, 0, 0, 0.31944],
    60: [0.08556, 0.58556, 0, 0, 0.89444],
    61: [-0.10889, 0.39111, 0, 0, 0.89444],
    62: [0.08556, 0.58556, 0, 0, 0.89444],
    63: [0, 0.69444, 0, 0, 0.54305],
    64: [0, 0.69444, 0, 0, 0.89444],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0, 0, 0.81805],
    67: [0, 0.68611, 0, 0, 0.83055],
    68: [0, 0.68611, 0, 0, 0.88194],
    69: [0, 0.68611, 0, 0, 0.75555],
    70: [0, 0.68611, 0, 0, 0.72361],
    71: [0, 0.68611, 0, 0, 0.90416],
    72: [0, 0.68611, 0, 0, 0.9],
    73: [0, 0.68611, 0, 0, 0.43611],
    74: [0, 0.68611, 0, 0, 0.59444],
    75: [0, 0.68611, 0, 0, 0.90138],
    76: [0, 0.68611, 0, 0, 0.69166],
    77: [0, 0.68611, 0, 0, 1.09166],
    78: [0, 0.68611, 0, 0, 0.9],
    79: [0, 0.68611, 0, 0, 0.86388],
    80: [0, 0.68611, 0, 0, 0.78611],
    81: [0.19444, 0.68611, 0, 0, 0.86388],
    82: [0, 0.68611, 0, 0, 0.8625],
    83: [0, 0.68611, 0, 0, 0.63889],
    84: [0, 0.68611, 0, 0, 0.8],
    85: [0, 0.68611, 0, 0, 0.88472],
    86: [0, 0.68611, 0.01597, 0, 0.86944],
    87: [0, 0.68611, 0.01597, 0, 1.18888],
    88: [0, 0.68611, 0, 0, 0.86944],
    89: [0, 0.68611, 0.02875, 0, 0.86944],
    90: [0, 0.68611, 0, 0, 0.70277],
    91: [0.25, 0.75, 0, 0, 0.31944],
    92: [0.25, 0.75, 0, 0, 0.575],
    93: [0.25, 0.75, 0, 0, 0.31944],
    94: [0, 0.69444, 0, 0, 0.575],
    95: [0.31, 0.13444, 0.03194, 0, 0.575],
    97: [0, 0.44444, 0, 0, 0.55902],
    98: [0, 0.69444, 0, 0, 0.63889],
    99: [0, 0.44444, 0, 0, 0.51111],
    100: [0, 0.69444, 0, 0, 0.63889],
    101: [0, 0.44444, 0, 0, 0.52708],
    102: [0, 0.69444, 0.10903, 0, 0.35139],
    103: [0.19444, 0.44444, 0.01597, 0, 0.575],
    104: [0, 0.69444, 0, 0, 0.63889],
    105: [0, 0.69444, 0, 0, 0.31944],
    106: [0.19444, 0.69444, 0, 0, 0.35139],
    107: [0, 0.69444, 0, 0, 0.60694],
    108: [0, 0.69444, 0, 0, 0.31944],
    109: [0, 0.44444, 0, 0, 0.95833],
    110: [0, 0.44444, 0, 0, 0.63889],
    111: [0, 0.44444, 0, 0, 0.575],
    112: [0.19444, 0.44444, 0, 0, 0.63889],
    113: [0.19444, 0.44444, 0, 0, 0.60694],
    114: [0, 0.44444, 0, 0, 0.47361],
    115: [0, 0.44444, 0, 0, 0.45361],
    116: [0, 0.63492, 0, 0, 0.44722],
    117: [0, 0.44444, 0, 0, 0.63889],
    118: [0, 0.44444, 0.01597, 0, 0.60694],
    119: [0, 0.44444, 0.01597, 0, 0.83055],
    120: [0, 0.44444, 0, 0, 0.60694],
    121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
    122: [0, 0.44444, 0, 0, 0.51111],
    123: [0.25, 0.75, 0, 0, 0.575],
    124: [0.25, 0.75, 0, 0, 0.31944],
    125: [0.25, 0.75, 0, 0, 0.575],
    126: [0.35, 0.34444, 0, 0, 0.575],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.86853],
    168: [0, 0.69444, 0, 0, 0.575],
    172: [0, 0.44444, 0, 0, 0.76666],
    176: [0, 0.69444, 0, 0, 0.86944],
    177: [0.13333, 0.63333, 0, 0, 0.89444],
    184: [0.17014, 0, 0, 0, 0.51111],
    198: [0, 0.68611, 0, 0, 1.04166],
    215: [0.13333, 0.63333, 0, 0, 0.89444],
    216: [0.04861, 0.73472, 0, 0, 0.89444],
    223: [0, 0.69444, 0, 0, 0.59722],
    230: [0, 0.44444, 0, 0, 0.83055],
    247: [0.13333, 0.63333, 0, 0, 0.89444],
    248: [0.09722, 0.54167, 0, 0, 0.575],
    305: [0, 0.44444, 0, 0, 0.31944],
    338: [0, 0.68611, 0, 0, 1.16944],
    339: [0, 0.44444, 0, 0, 0.89444],
    567: [0.19444, 0.44444, 0, 0, 0.35139],
    710: [0, 0.69444, 0, 0, 0.575],
    711: [0, 0.63194, 0, 0, 0.575],
    713: [0, 0.59611, 0, 0, 0.575],
    714: [0, 0.69444, 0, 0, 0.575],
    715: [0, 0.69444, 0, 0, 0.575],
    728: [0, 0.69444, 0, 0, 0.575],
    729: [0, 0.69444, 0, 0, 0.31944],
    730: [0, 0.69444, 0, 0, 0.86944],
    732: [0, 0.69444, 0, 0, 0.575],
    733: [0, 0.69444, 0, 0, 0.575],
    915: [0, 0.68611, 0, 0, 0.69166],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0, 0, 0.89444],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0, 0, 0.76666],
    928: [0, 0.68611, 0, 0, 0.9],
    931: [0, 0.68611, 0, 0, 0.83055],
    933: [0, 0.68611, 0, 0, 0.89444],
    934: [0, 0.68611, 0, 0, 0.83055],
    936: [0, 0.68611, 0, 0, 0.89444],
    937: [0, 0.68611, 0, 0, 0.83055],
    8211: [0, 0.44444, 0.03194, 0, 0.575],
    8212: [0, 0.44444, 0.03194, 0, 1.14999],
    8216: [0, 0.69444, 0, 0, 0.31944],
    8217: [0, 0.69444, 0, 0, 0.31944],
    8220: [0, 0.69444, 0, 0, 0.60278],
    8221: [0, 0.69444, 0, 0, 0.60278],
    8224: [0.19444, 0.69444, 0, 0, 0.51111],
    8225: [0.19444, 0.69444, 0, 0, 0.51111],
    8242: [0, 0.55556, 0, 0, 0.34444],
    8407: [0, 0.72444, 0.15486, 0, 0.575],
    8463: [0, 0.69444, 0, 0, 0.66759],
    8465: [0, 0.69444, 0, 0, 0.83055],
    8467: [0, 0.69444, 0, 0, 0.47361],
    8472: [0.19444, 0.44444, 0, 0, 0.74027],
    8476: [0, 0.69444, 0, 0, 0.83055],
    8501: [0, 0.69444, 0, 0, 0.70277],
    8592: [-0.10889, 0.39111, 0, 0, 1.14999],
    8593: [0.19444, 0.69444, 0, 0, 0.575],
    8594: [-0.10889, 0.39111, 0, 0, 1.14999],
    8595: [0.19444, 0.69444, 0, 0, 0.575],
    8596: [-0.10889, 0.39111, 0, 0, 1.14999],
    8597: [0.25, 0.75, 0, 0, 0.575],
    8598: [0.19444, 0.69444, 0, 0, 1.14999],
    8599: [0.19444, 0.69444, 0, 0, 1.14999],
    8600: [0.19444, 0.69444, 0, 0, 1.14999],
    8601: [0.19444, 0.69444, 0, 0, 1.14999],
    8636: [-0.10889, 0.39111, 0, 0, 1.14999],
    8637: [-0.10889, 0.39111, 0, 0, 1.14999],
    8640: [-0.10889, 0.39111, 0, 0, 1.14999],
    8641: [-0.10889, 0.39111, 0, 0, 1.14999],
    8656: [-0.10889, 0.39111, 0, 0, 1.14999],
    8657: [0.19444, 0.69444, 0, 0, 0.70277],
    8658: [-0.10889, 0.39111, 0, 0, 1.14999],
    8659: [0.19444, 0.69444, 0, 0, 0.70277],
    8660: [-0.10889, 0.39111, 0, 0, 1.14999],
    8661: [0.25, 0.75, 0, 0, 0.70277],
    8704: [0, 0.69444, 0, 0, 0.63889],
    8706: [0, 0.69444, 0.06389, 0, 0.62847],
    8707: [0, 0.69444, 0, 0, 0.63889],
    8709: [0.05556, 0.75, 0, 0, 0.575],
    8711: [0, 0.68611, 0, 0, 0.95833],
    8712: [0.08556, 0.58556, 0, 0, 0.76666],
    8715: [0.08556, 0.58556, 0, 0, 0.76666],
    8722: [0.13333, 0.63333, 0, 0, 0.89444],
    8723: [0.13333, 0.63333, 0, 0, 0.89444],
    8725: [0.25, 0.75, 0, 0, 0.575],
    8726: [0.25, 0.75, 0, 0, 0.575],
    8727: [-0.02778, 0.47222, 0, 0, 0.575],
    8728: [-0.02639, 0.47361, 0, 0, 0.575],
    8729: [-0.02639, 0.47361, 0, 0, 0.575],
    8730: [0.18, 0.82, 0, 0, 0.95833],
    8733: [0, 0.44444, 0, 0, 0.89444],
    8734: [0, 0.44444, 0, 0, 1.14999],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.31944],
    8741: [0.25, 0.75, 0, 0, 0.575],
    8743: [0, 0.55556, 0, 0, 0.76666],
    8744: [0, 0.55556, 0, 0, 0.76666],
    8745: [0, 0.55556, 0, 0, 0.76666],
    8746: [0, 0.55556, 0, 0, 0.76666],
    8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
    8764: [-0.10889, 0.39111, 0, 0, 0.89444],
    8768: [0.19444, 0.69444, 0, 0, 0.31944],
    8771: [222e-5, 0.50222, 0, 0, 0.89444],
    8773: [0.027, 0.638, 0, 0, 0.894],
    8776: [0.02444, 0.52444, 0, 0, 0.89444],
    8781: [222e-5, 0.50222, 0, 0, 0.89444],
    8801: [222e-5, 0.50222, 0, 0, 0.89444],
    8804: [0.19667, 0.69667, 0, 0, 0.89444],
    8805: [0.19667, 0.69667, 0, 0, 0.89444],
    8810: [0.08556, 0.58556, 0, 0, 1.14999],
    8811: [0.08556, 0.58556, 0, 0, 1.14999],
    8826: [0.08556, 0.58556, 0, 0, 0.89444],
    8827: [0.08556, 0.58556, 0, 0, 0.89444],
    8834: [0.08556, 0.58556, 0, 0, 0.89444],
    8835: [0.08556, 0.58556, 0, 0, 0.89444],
    8838: [0.19667, 0.69667, 0, 0, 0.89444],
    8839: [0.19667, 0.69667, 0, 0, 0.89444],
    8846: [0, 0.55556, 0, 0, 0.76666],
    8849: [0.19667, 0.69667, 0, 0, 0.89444],
    8850: [0.19667, 0.69667, 0, 0, 0.89444],
    8851: [0, 0.55556, 0, 0, 0.76666],
    8852: [0, 0.55556, 0, 0, 0.76666],
    8853: [0.13333, 0.63333, 0, 0, 0.89444],
    8854: [0.13333, 0.63333, 0, 0, 0.89444],
    8855: [0.13333, 0.63333, 0, 0, 0.89444],
    8856: [0.13333, 0.63333, 0, 0, 0.89444],
    8857: [0.13333, 0.63333, 0, 0, 0.89444],
    8866: [0, 0.69444, 0, 0, 0.70277],
    8867: [0, 0.69444, 0, 0, 0.70277],
    8868: [0, 0.69444, 0, 0, 0.89444],
    8869: [0, 0.69444, 0, 0, 0.89444],
    8900: [-0.02639, 0.47361, 0, 0, 0.575],
    8901: [-0.02639, 0.47361, 0, 0, 0.31944],
    8902: [-0.02778, 0.47222, 0, 0, 0.575],
    8968: [0.25, 0.75, 0, 0, 0.51111],
    8969: [0.25, 0.75, 0, 0, 0.51111],
    8970: [0.25, 0.75, 0, 0, 0.51111],
    8971: [0.25, 0.75, 0, 0, 0.51111],
    8994: [-0.13889, 0.36111, 0, 0, 1.14999],
    8995: [-0.13889, 0.36111, 0, 0, 1.14999],
    9651: [0.19444, 0.69444, 0, 0, 1.02222],
    9657: [-0.02778, 0.47222, 0, 0, 0.575],
    9661: [0.19444, 0.69444, 0, 0, 1.02222],
    9667: [-0.02778, 0.47222, 0, 0, 0.575],
    9711: [0.19444, 0.69444, 0, 0, 1.14999],
    9824: [0.12963, 0.69444, 0, 0, 0.89444],
    9825: [0.12963, 0.69444, 0, 0, 0.89444],
    9826: [0.12963, 0.69444, 0, 0, 0.89444],
    9827: [0.12963, 0.69444, 0, 0, 0.89444],
    9837: [0, 0.75, 0, 0, 0.44722],
    9838: [0.19444, 0.69444, 0, 0, 0.44722],
    9839: [0.19444, 0.69444, 0, 0, 0.44722],
    10216: [0.25, 0.75, 0, 0, 0.44722],
    10217: [0.25, 0.75, 0, 0, 0.44722],
    10815: [0, 0.68611, 0, 0, 0.9],
    10927: [0.19667, 0.69667, 0, 0, 0.89444],
    10928: [0.19667, 0.69667, 0, 0, 0.89444],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.11417, 0, 0.38611],
    34: [0, 0.69444, 0.07939, 0, 0.62055],
    35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
    37: [0.05556, 0.75, 0.12861, 0, 0.94444],
    38: [0, 0.69444, 0.08528, 0, 0.88555],
    39: [0, 0.69444, 0.12945, 0, 0.35555],
    40: [0.25, 0.75, 0.15806, 0, 0.47333],
    41: [0.25, 0.75, 0.03306, 0, 0.47333],
    42: [0, 0.75, 0.14333, 0, 0.59111],
    43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
    44: [0.19444, 0.14722, 0, 0, 0.35555],
    45: [0, 0.44444, 0.02611, 0, 0.41444],
    46: [0, 0.14722, 0, 0, 0.35555],
    47: [0.25, 0.75, 0.15806, 0, 0.59111],
    48: [0, 0.64444, 0.13167, 0, 0.59111],
    49: [0, 0.64444, 0.13167, 0, 0.59111],
    50: [0, 0.64444, 0.13167, 0, 0.59111],
    51: [0, 0.64444, 0.13167, 0, 0.59111],
    52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    53: [0, 0.64444, 0.13167, 0, 0.59111],
    54: [0, 0.64444, 0.13167, 0, 0.59111],
    55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    56: [0, 0.64444, 0.13167, 0, 0.59111],
    57: [0, 0.64444, 0.13167, 0, 0.59111],
    58: [0, 0.44444, 0.06695, 0, 0.35555],
    59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
    61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    63: [0, 0.69444, 0.11472, 0, 0.59111],
    64: [0, 0.69444, 0.09208, 0, 0.88555],
    65: [0, 0.68611, 0, 0, 0.86555],
    66: [0, 0.68611, 0.0992, 0, 0.81666],
    67: [0, 0.68611, 0.14208, 0, 0.82666],
    68: [0, 0.68611, 0.09062, 0, 0.87555],
    69: [0, 0.68611, 0.11431, 0, 0.75666],
    70: [0, 0.68611, 0.12903, 0, 0.72722],
    71: [0, 0.68611, 0.07347, 0, 0.89527],
    72: [0, 0.68611, 0.17208, 0, 0.8961],
    73: [0, 0.68611, 0.15681, 0, 0.47166],
    74: [0, 0.68611, 0.145, 0, 0.61055],
    75: [0, 0.68611, 0.14208, 0, 0.89499],
    76: [0, 0.68611, 0, 0, 0.69777],
    77: [0, 0.68611, 0.17208, 0, 1.07277],
    78: [0, 0.68611, 0.17208, 0, 0.8961],
    79: [0, 0.68611, 0.09062, 0, 0.85499],
    80: [0, 0.68611, 0.0992, 0, 0.78721],
    81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
    82: [0, 0.68611, 0.02559, 0, 0.85944],
    83: [0, 0.68611, 0.11264, 0, 0.64999],
    84: [0, 0.68611, 0.12903, 0, 0.7961],
    85: [0, 0.68611, 0.17208, 0, 0.88083],
    86: [0, 0.68611, 0.18625, 0, 0.86555],
    87: [0, 0.68611, 0.18625, 0, 1.15999],
    88: [0, 0.68611, 0.15681, 0, 0.86555],
    89: [0, 0.68611, 0.19803, 0, 0.86555],
    90: [0, 0.68611, 0.14208, 0, 0.70888],
    91: [0.25, 0.75, 0.1875, 0, 0.35611],
    93: [0.25, 0.75, 0.09972, 0, 0.35611],
    94: [0, 0.69444, 0.06709, 0, 0.59111],
    95: [0.31, 0.13444, 0.09811, 0, 0.59111],
    97: [0, 0.44444, 0.09426, 0, 0.59111],
    98: [0, 0.69444, 0.07861, 0, 0.53222],
    99: [0, 0.44444, 0.05222, 0, 0.53222],
    100: [0, 0.69444, 0.10861, 0, 0.59111],
    101: [0, 0.44444, 0.085, 0, 0.53222],
    102: [0.19444, 0.69444, 0.21778, 0, 0.4],
    103: [0.19444, 0.44444, 0.105, 0, 0.53222],
    104: [0, 0.69444, 0.09426, 0, 0.59111],
    105: [0, 0.69326, 0.11387, 0, 0.35555],
    106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
    107: [0, 0.69444, 0.11111, 0, 0.53222],
    108: [0, 0.69444, 0.10861, 0, 0.29666],
    109: [0, 0.44444, 0.09426, 0, 0.94444],
    110: [0, 0.44444, 0.09426, 0, 0.64999],
    111: [0, 0.44444, 0.07861, 0, 0.59111],
    112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
    113: [0.19444, 0.44444, 0.105, 0, 0.53222],
    114: [0, 0.44444, 0.11111, 0, 0.50167],
    115: [0, 0.44444, 0.08167, 0, 0.48694],
    116: [0, 0.63492, 0.09639, 0, 0.385],
    117: [0, 0.44444, 0.09426, 0, 0.62055],
    118: [0, 0.44444, 0.11111, 0, 0.53222],
    119: [0, 0.44444, 0.11111, 0, 0.76777],
    120: [0, 0.44444, 0.12583, 0, 0.56055],
    121: [0.19444, 0.44444, 0.105, 0, 0.56166],
    122: [0, 0.44444, 0.13889, 0, 0.49055],
    126: [0.35, 0.34444, 0.11472, 0, 0.59111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0.11473, 0, 0.59111],
    176: [0, 0.69444, 0, 0, 0.94888],
    184: [0.17014, 0, 0, 0, 0.53222],
    198: [0, 0.68611, 0.11431, 0, 1.02277],
    216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
    223: [0.19444, 0.69444, 0.09736, 0, 0.665],
    230: [0, 0.44444, 0.085, 0, 0.82666],
    248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
    305: [0, 0.44444, 0.09426, 0, 0.35555],
    338: [0, 0.68611, 0.11431, 0, 1.14054],
    339: [0, 0.44444, 0.085, 0, 0.82666],
    567: [0.19444, 0.44444, 0.04611, 0, 0.385],
    710: [0, 0.69444, 0.06709, 0, 0.59111],
    711: [0, 0.63194, 0.08271, 0, 0.59111],
    713: [0, 0.59444, 0.10444, 0, 0.59111],
    714: [0, 0.69444, 0.08528, 0, 0.59111],
    715: [0, 0.69444, 0, 0, 0.59111],
    728: [0, 0.69444, 0.10333, 0, 0.59111],
    729: [0, 0.69444, 0.12945, 0, 0.35555],
    730: [0, 0.69444, 0, 0, 0.94888],
    732: [0, 0.69444, 0.11472, 0, 0.59111],
    733: [0, 0.69444, 0.11472, 0, 0.59111],
    915: [0, 0.68611, 0.12903, 0, 0.69777],
    916: [0, 0.68611, 0, 0, 0.94444],
    920: [0, 0.68611, 0.09062, 0, 0.88555],
    923: [0, 0.68611, 0, 0, 0.80666],
    926: [0, 0.68611, 0.15092, 0, 0.76777],
    928: [0, 0.68611, 0.17208, 0, 0.8961],
    931: [0, 0.68611, 0.11431, 0, 0.82666],
    933: [0, 0.68611, 0.10778, 0, 0.88555],
    934: [0, 0.68611, 0.05632, 0, 0.82666],
    936: [0, 0.68611, 0.10778, 0, 0.88555],
    937: [0, 0.68611, 0.0992, 0, 0.82666],
    8211: [0, 0.44444, 0.09811, 0, 0.59111],
    8212: [0, 0.44444, 0.09811, 0, 1.18221],
    8216: [0, 0.69444, 0.12945, 0, 0.35555],
    8217: [0, 0.69444, 0.12945, 0, 0.35555],
    8220: [0, 0.69444, 0.16772, 0, 0.62055],
    8221: [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.12417, 0, 0.30667],
    34: [0, 0.69444, 0.06961, 0, 0.51444],
    35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
    37: [0.05556, 0.75, 0.13639, 0, 0.81777],
    38: [0, 0.69444, 0.09694, 0, 0.76666],
    39: [0, 0.69444, 0.12417, 0, 0.30667],
    40: [0.25, 0.75, 0.16194, 0, 0.40889],
    41: [0.25, 0.75, 0.03694, 0, 0.40889],
    42: [0, 0.75, 0.14917, 0, 0.51111],
    43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
    44: [0.19444, 0.10556, 0, 0, 0.30667],
    45: [0, 0.43056, 0.02826, 0, 0.35778],
    46: [0, 0.10556, 0, 0, 0.30667],
    47: [0.25, 0.75, 0.16194, 0, 0.51111],
    48: [0, 0.64444, 0.13556, 0, 0.51111],
    49: [0, 0.64444, 0.13556, 0, 0.51111],
    50: [0, 0.64444, 0.13556, 0, 0.51111],
    51: [0, 0.64444, 0.13556, 0, 0.51111],
    52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    53: [0, 0.64444, 0.13556, 0, 0.51111],
    54: [0, 0.64444, 0.13556, 0, 0.51111],
    55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    56: [0, 0.64444, 0.13556, 0, 0.51111],
    57: [0, 0.64444, 0.13556, 0, 0.51111],
    58: [0, 0.43056, 0.0582, 0, 0.30667],
    59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
    61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    63: [0, 0.69444, 0.1225, 0, 0.51111],
    64: [0, 0.69444, 0.09597, 0, 0.76666],
    65: [0, 0.68333, 0, 0, 0.74333],
    66: [0, 0.68333, 0.10257, 0, 0.70389],
    67: [0, 0.68333, 0.14528, 0, 0.71555],
    68: [0, 0.68333, 0.09403, 0, 0.755],
    69: [0, 0.68333, 0.12028, 0, 0.67833],
    70: [0, 0.68333, 0.13305, 0, 0.65277],
    71: [0, 0.68333, 0.08722, 0, 0.77361],
    72: [0, 0.68333, 0.16389, 0, 0.74333],
    73: [0, 0.68333, 0.15806, 0, 0.38555],
    74: [0, 0.68333, 0.14028, 0, 0.525],
    75: [0, 0.68333, 0.14528, 0, 0.76888],
    76: [0, 0.68333, 0, 0, 0.62722],
    77: [0, 0.68333, 0.16389, 0, 0.89666],
    78: [0, 0.68333, 0.16389, 0, 0.74333],
    79: [0, 0.68333, 0.09403, 0, 0.76666],
    80: [0, 0.68333, 0.10257, 0, 0.67833],
    81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
    82: [0, 0.68333, 0.03868, 0, 0.72944],
    83: [0, 0.68333, 0.11972, 0, 0.56222],
    84: [0, 0.68333, 0.13305, 0, 0.71555],
    85: [0, 0.68333, 0.16389, 0, 0.74333],
    86: [0, 0.68333, 0.18361, 0, 0.74333],
    87: [0, 0.68333, 0.18361, 0, 0.99888],
    88: [0, 0.68333, 0.15806, 0, 0.74333],
    89: [0, 0.68333, 0.19383, 0, 0.74333],
    90: [0, 0.68333, 0.14528, 0, 0.61333],
    91: [0.25, 0.75, 0.1875, 0, 0.30667],
    93: [0.25, 0.75, 0.10528, 0, 0.30667],
    94: [0, 0.69444, 0.06646, 0, 0.51111],
    95: [0.31, 0.12056, 0.09208, 0, 0.51111],
    97: [0, 0.43056, 0.07671, 0, 0.51111],
    98: [0, 0.69444, 0.06312, 0, 0.46],
    99: [0, 0.43056, 0.05653, 0, 0.46],
    100: [0, 0.69444, 0.10333, 0, 0.51111],
    101: [0, 0.43056, 0.07514, 0, 0.46],
    102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
    103: [0.19444, 0.43056, 0.08847, 0, 0.46],
    104: [0, 0.69444, 0.07671, 0, 0.51111],
    105: [0, 0.65536, 0.1019, 0, 0.30667],
    106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
    107: [0, 0.69444, 0.10764, 0, 0.46],
    108: [0, 0.69444, 0.10333, 0, 0.25555],
    109: [0, 0.43056, 0.07671, 0, 0.81777],
    110: [0, 0.43056, 0.07671, 0, 0.56222],
    111: [0, 0.43056, 0.06312, 0, 0.51111],
    112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
    113: [0.19444, 0.43056, 0.08847, 0, 0.46],
    114: [0, 0.43056, 0.10764, 0, 0.42166],
    115: [0, 0.43056, 0.08208, 0, 0.40889],
    116: [0, 0.61508, 0.09486, 0, 0.33222],
    117: [0, 0.43056, 0.07671, 0, 0.53666],
    118: [0, 0.43056, 0.10764, 0, 0.46],
    119: [0, 0.43056, 0.10764, 0, 0.66444],
    120: [0, 0.43056, 0.12042, 0, 0.46389],
    121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
    122: [0, 0.43056, 0.12292, 0, 0.40889],
    126: [0.35, 0.31786, 0.11585, 0, 0.51111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.66786, 0.10474, 0, 0.51111],
    176: [0, 0.69444, 0, 0, 0.83129],
    184: [0.17014, 0, 0, 0, 0.46],
    198: [0, 0.68333, 0.12028, 0, 0.88277],
    216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
    223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
    230: [0, 0.43056, 0.07514, 0, 0.71555],
    248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
    338: [0, 0.68333, 0.12028, 0, 0.98499],
    339: [0, 0.43056, 0.07514, 0, 0.71555],
    710: [0, 0.69444, 0.06646, 0, 0.51111],
    711: [0, 0.62847, 0.08295, 0, 0.51111],
    713: [0, 0.56167, 0.10333, 0, 0.51111],
    714: [0, 0.69444, 0.09694, 0, 0.51111],
    715: [0, 0.69444, 0, 0, 0.51111],
    728: [0, 0.69444, 0.10806, 0, 0.51111],
    729: [0, 0.66786, 0.11752, 0, 0.30667],
    730: [0, 0.69444, 0, 0, 0.83129],
    732: [0, 0.66786, 0.11585, 0, 0.51111],
    733: [0, 0.69444, 0.1225, 0, 0.51111],
    915: [0, 0.68333, 0.13305, 0, 0.62722],
    916: [0, 0.68333, 0, 0, 0.81777],
    920: [0, 0.68333, 0.09403, 0, 0.76666],
    923: [0, 0.68333, 0, 0, 0.69222],
    926: [0, 0.68333, 0.15294, 0, 0.66444],
    928: [0, 0.68333, 0.16389, 0, 0.74333],
    931: [0, 0.68333, 0.12028, 0, 0.71555],
    933: [0, 0.68333, 0.11111, 0, 0.76666],
    934: [0, 0.68333, 0.05986, 0, 0.71555],
    936: [0, 0.68333, 0.11111, 0, 0.76666],
    937: [0, 0.68333, 0.10257, 0, 0.71555],
    8211: [0, 0.43056, 0.09208, 0, 0.51111],
    8212: [0, 0.43056, 0.09208, 0, 1.02222],
    8216: [0, 0.69444, 0.12417, 0, 0.30667],
    8217: [0, 0.69444, 0.12417, 0, 0.30667],
    8220: [0, 0.69444, 0.1685, 0, 0.51444],
    8221: [0, 0.69444, 0.06961, 0, 0.51444],
    8463: [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.27778],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.77778],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.19444, 0.10556, 0, 0, 0.27778],
    45: [0, 0.43056, 0, 0, 0.33333],
    46: [0, 0.10556, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.64444, 0, 0, 0.5],
    49: [0, 0.64444, 0, 0, 0.5],
    50: [0, 0.64444, 0, 0, 0.5],
    51: [0, 0.64444, 0, 0, 0.5],
    52: [0, 0.64444, 0, 0, 0.5],
    53: [0, 0.64444, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0, 0.64444, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0, 0.64444, 0, 0, 0.5],
    58: [0, 0.43056, 0, 0, 0.27778],
    59: [0.19444, 0.43056, 0, 0, 0.27778],
    60: [0.0391, 0.5391, 0, 0, 0.77778],
    61: [-0.13313, 0.36687, 0, 0, 0.77778],
    62: [0.0391, 0.5391, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.77778],
    65: [0, 0.68333, 0, 0, 0.75],
    66: [0, 0.68333, 0, 0, 0.70834],
    67: [0, 0.68333, 0, 0, 0.72222],
    68: [0, 0.68333, 0, 0, 0.76389],
    69: [0, 0.68333, 0, 0, 0.68056],
    70: [0, 0.68333, 0, 0, 0.65278],
    71: [0, 0.68333, 0, 0, 0.78472],
    72: [0, 0.68333, 0, 0, 0.75],
    73: [0, 0.68333, 0, 0, 0.36111],
    74: [0, 0.68333, 0, 0, 0.51389],
    75: [0, 0.68333, 0, 0, 0.77778],
    76: [0, 0.68333, 0, 0, 0.625],
    77: [0, 0.68333, 0, 0, 0.91667],
    78: [0, 0.68333, 0, 0, 0.75],
    79: [0, 0.68333, 0, 0, 0.77778],
    80: [0, 0.68333, 0, 0, 0.68056],
    81: [0.19444, 0.68333, 0, 0, 0.77778],
    82: [0, 0.68333, 0, 0, 0.73611],
    83: [0, 0.68333, 0, 0, 0.55556],
    84: [0, 0.68333, 0, 0, 0.72222],
    85: [0, 0.68333, 0, 0, 0.75],
    86: [0, 0.68333, 0.01389, 0, 0.75],
    87: [0, 0.68333, 0.01389, 0, 1.02778],
    88: [0, 0.68333, 0, 0, 0.75],
    89: [0, 0.68333, 0.025, 0, 0.75],
    90: [0, 0.68333, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.27778],
    92: [0.25, 0.75, 0, 0, 0.5],
    93: [0.25, 0.75, 0, 0, 0.27778],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.31, 0.12056, 0.02778, 0, 0.5],
    97: [0, 0.43056, 0, 0, 0.5],
    98: [0, 0.69444, 0, 0, 0.55556],
    99: [0, 0.43056, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.55556],
    101: [0, 0.43056, 0, 0, 0.44445],
    102: [0, 0.69444, 0.07778, 0, 0.30556],
    103: [0.19444, 0.43056, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.55556],
    105: [0, 0.66786, 0, 0, 0.27778],
    106: [0.19444, 0.66786, 0, 0, 0.30556],
    107: [0, 0.69444, 0, 0, 0.52778],
    108: [0, 0.69444, 0, 0, 0.27778],
    109: [0, 0.43056, 0, 0, 0.83334],
    110: [0, 0.43056, 0, 0, 0.55556],
    111: [0, 0.43056, 0, 0, 0.5],
    112: [0.19444, 0.43056, 0, 0, 0.55556],
    113: [0.19444, 0.43056, 0, 0, 0.52778],
    114: [0, 0.43056, 0, 0, 0.39167],
    115: [0, 0.43056, 0, 0, 0.39445],
    116: [0, 0.61508, 0, 0, 0.38889],
    117: [0, 0.43056, 0, 0, 0.55556],
    118: [0, 0.43056, 0.01389, 0, 0.52778],
    119: [0, 0.43056, 0.01389, 0, 0.72222],
    120: [0, 0.43056, 0, 0, 0.52778],
    121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
    122: [0, 0.43056, 0, 0, 0.44445],
    123: [0.25, 0.75, 0, 0, 0.5],
    124: [0.25, 0.75, 0, 0, 0.27778],
    125: [0.25, 0.75, 0, 0, 0.5],
    126: [0.35, 0.31786, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.76909],
    167: [0.19444, 0.69444, 0, 0, 0.44445],
    168: [0, 0.66786, 0, 0, 0.5],
    172: [0, 0.43056, 0, 0, 0.66667],
    176: [0, 0.69444, 0, 0, 0.75],
    177: [0.08333, 0.58333, 0, 0, 0.77778],
    182: [0.19444, 0.69444, 0, 0, 0.61111],
    184: [0.17014, 0, 0, 0, 0.44445],
    198: [0, 0.68333, 0, 0, 0.90278],
    215: [0.08333, 0.58333, 0, 0, 0.77778],
    216: [0.04861, 0.73194, 0, 0, 0.77778],
    223: [0, 0.69444, 0, 0, 0.5],
    230: [0, 0.43056, 0, 0, 0.72222],
    247: [0.08333, 0.58333, 0, 0, 0.77778],
    248: [0.09722, 0.52778, 0, 0, 0.5],
    305: [0, 0.43056, 0, 0, 0.27778],
    338: [0, 0.68333, 0, 0, 1.01389],
    339: [0, 0.43056, 0, 0, 0.77778],
    567: [0.19444, 0.43056, 0, 0, 0.30556],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.62847, 0, 0, 0.5],
    713: [0, 0.56778, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.66786, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.75],
    732: [0, 0.66786, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.68333, 0, 0, 0.625],
    916: [0, 0.68333, 0, 0, 0.83334],
    920: [0, 0.68333, 0, 0, 0.77778],
    923: [0, 0.68333, 0, 0, 0.69445],
    926: [0, 0.68333, 0, 0, 0.66667],
    928: [0, 0.68333, 0, 0, 0.75],
    931: [0, 0.68333, 0, 0, 0.72222],
    933: [0, 0.68333, 0, 0, 0.77778],
    934: [0, 0.68333, 0, 0, 0.72222],
    936: [0, 0.68333, 0, 0, 0.77778],
    937: [0, 0.68333, 0, 0, 0.72222],
    8211: [0, 0.43056, 0.02778, 0, 0.5],
    8212: [0, 0.43056, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5],
    8224: [0.19444, 0.69444, 0, 0, 0.44445],
    8225: [0.19444, 0.69444, 0, 0, 0.44445],
    8230: [0, 0.123, 0, 0, 1.172],
    8242: [0, 0.55556, 0, 0, 0.275],
    8407: [0, 0.71444, 0.15382, 0, 0.5],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8465: [0, 0.69444, 0, 0, 0.72222],
    8467: [0, 0.69444, 0, 0.11111, 0.41667],
    8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
    8476: [0, 0.69444, 0, 0, 0.72222],
    8501: [0, 0.69444, 0, 0, 0.61111],
    8592: [-0.13313, 0.36687, 0, 0, 1],
    8593: [0.19444, 0.69444, 0, 0, 0.5],
    8594: [-0.13313, 0.36687, 0, 0, 1],
    8595: [0.19444, 0.69444, 0, 0, 0.5],
    8596: [-0.13313, 0.36687, 0, 0, 1],
    8597: [0.25, 0.75, 0, 0, 0.5],
    8598: [0.19444, 0.69444, 0, 0, 1],
    8599: [0.19444, 0.69444, 0, 0, 1],
    8600: [0.19444, 0.69444, 0, 0, 1],
    8601: [0.19444, 0.69444, 0, 0, 1],
    8614: [0.011, 0.511, 0, 0, 1],
    8617: [0.011, 0.511, 0, 0, 1.126],
    8618: [0.011, 0.511, 0, 0, 1.126],
    8636: [-0.13313, 0.36687, 0, 0, 1],
    8637: [-0.13313, 0.36687, 0, 0, 1],
    8640: [-0.13313, 0.36687, 0, 0, 1],
    8641: [-0.13313, 0.36687, 0, 0, 1],
    8652: [0.011, 0.671, 0, 0, 1],
    8656: [-0.13313, 0.36687, 0, 0, 1],
    8657: [0.19444, 0.69444, 0, 0, 0.61111],
    8658: [-0.13313, 0.36687, 0, 0, 1],
    8659: [0.19444, 0.69444, 0, 0, 0.61111],
    8660: [-0.13313, 0.36687, 0, 0, 1],
    8661: [0.25, 0.75, 0, 0, 0.61111],
    8704: [0, 0.69444, 0, 0, 0.55556],
    8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
    8707: [0, 0.69444, 0, 0, 0.55556],
    8709: [0.05556, 0.75, 0, 0, 0.5],
    8711: [0, 0.68333, 0, 0, 0.83334],
    8712: [0.0391, 0.5391, 0, 0, 0.66667],
    8715: [0.0391, 0.5391, 0, 0, 0.66667],
    8722: [0.08333, 0.58333, 0, 0, 0.77778],
    8723: [0.08333, 0.58333, 0, 0, 0.77778],
    8725: [0.25, 0.75, 0, 0, 0.5],
    8726: [0.25, 0.75, 0, 0, 0.5],
    8727: [-0.03472, 0.46528, 0, 0, 0.5],
    8728: [-0.05555, 0.44445, 0, 0, 0.5],
    8729: [-0.05555, 0.44445, 0, 0, 0.5],
    8730: [0.2, 0.8, 0, 0, 0.83334],
    8733: [0, 0.43056, 0, 0, 0.77778],
    8734: [0, 0.43056, 0, 0, 1],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.27778],
    8741: [0.25, 0.75, 0, 0, 0.5],
    8743: [0, 0.55556, 0, 0, 0.66667],
    8744: [0, 0.55556, 0, 0, 0.66667],
    8745: [0, 0.55556, 0, 0, 0.66667],
    8746: [0, 0.55556, 0, 0, 0.66667],
    8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8768: [0.19444, 0.69444, 0, 0, 0.27778],
    8771: [-0.03625, 0.46375, 0, 0, 0.77778],
    8773: [-0.022, 0.589, 0, 0, 0.778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8781: [-0.03625, 0.46375, 0, 0, 0.77778],
    8784: [-0.133, 0.673, 0, 0, 0.778],
    8801: [-0.03625, 0.46375, 0, 0, 0.77778],
    8804: [0.13597, 0.63597, 0, 0, 0.77778],
    8805: [0.13597, 0.63597, 0, 0, 0.77778],
    8810: [0.0391, 0.5391, 0, 0, 1],
    8811: [0.0391, 0.5391, 0, 0, 1],
    8826: [0.0391, 0.5391, 0, 0, 0.77778],
    8827: [0.0391, 0.5391, 0, 0, 0.77778],
    8834: [0.0391, 0.5391, 0, 0, 0.77778],
    8835: [0.0391, 0.5391, 0, 0, 0.77778],
    8838: [0.13597, 0.63597, 0, 0, 0.77778],
    8839: [0.13597, 0.63597, 0, 0, 0.77778],
    8846: [0, 0.55556, 0, 0, 0.66667],
    8849: [0.13597, 0.63597, 0, 0, 0.77778],
    8850: [0.13597, 0.63597, 0, 0, 0.77778],
    8851: [0, 0.55556, 0, 0, 0.66667],
    8852: [0, 0.55556, 0, 0, 0.66667],
    8853: [0.08333, 0.58333, 0, 0, 0.77778],
    8854: [0.08333, 0.58333, 0, 0, 0.77778],
    8855: [0.08333, 0.58333, 0, 0, 0.77778],
    8856: [0.08333, 0.58333, 0, 0, 0.77778],
    8857: [0.08333, 0.58333, 0, 0, 0.77778],
    8866: [0, 0.69444, 0, 0, 0.61111],
    8867: [0, 0.69444, 0, 0, 0.61111],
    8868: [0, 0.69444, 0, 0, 0.77778],
    8869: [0, 0.69444, 0, 0, 0.77778],
    8872: [0.249, 0.75, 0, 0, 0.867],
    8900: [-0.05555, 0.44445, 0, 0, 0.5],
    8901: [-0.05555, 0.44445, 0, 0, 0.27778],
    8902: [-0.03472, 0.46528, 0, 0, 0.5],
    8904: [5e-3, 0.505, 0, 0, 0.9],
    8942: [0.03, 0.903, 0, 0, 0.278],
    8943: [-0.19, 0.313, 0, 0, 1.172],
    8945: [-0.1, 0.823, 0, 0, 1.282],
    8968: [0.25, 0.75, 0, 0, 0.44445],
    8969: [0.25, 0.75, 0, 0, 0.44445],
    8970: [0.25, 0.75, 0, 0, 0.44445],
    8971: [0.25, 0.75, 0, 0, 0.44445],
    8994: [-0.14236, 0.35764, 0, 0, 1],
    8995: [-0.14236, 0.35764, 0, 0, 1],
    9136: [0.244, 0.744, 0, 0, 0.412],
    9137: [0.244, 0.745, 0, 0, 0.412],
    9651: [0.19444, 0.69444, 0, 0, 0.88889],
    9657: [-0.03472, 0.46528, 0, 0, 0.5],
    9661: [0.19444, 0.69444, 0, 0, 0.88889],
    9667: [-0.03472, 0.46528, 0, 0, 0.5],
    9711: [0.19444, 0.69444, 0, 0, 1],
    9824: [0.12963, 0.69444, 0, 0, 0.77778],
    9825: [0.12963, 0.69444, 0, 0, 0.77778],
    9826: [0.12963, 0.69444, 0, 0, 0.77778],
    9827: [0.12963, 0.69444, 0, 0, 0.77778],
    9837: [0, 0.75, 0, 0, 0.38889],
    9838: [0.19444, 0.69444, 0, 0, 0.38889],
    9839: [0.19444, 0.69444, 0, 0, 0.38889],
    10216: [0.25, 0.75, 0, 0, 0.38889],
    10217: [0.25, 0.75, 0, 0, 0.38889],
    10222: [0.244, 0.744, 0, 0, 0.412],
    10223: [0.244, 0.745, 0, 0, 0.412],
    10229: [0.011, 0.511, 0, 0, 1.609],
    10230: [0.011, 0.511, 0, 0, 1.638],
    10231: [0.011, 0.511, 0, 0, 1.859],
    10232: [0.024, 0.525, 0, 0, 1.609],
    10233: [0.024, 0.525, 0, 0, 1.638],
    10234: [0.024, 0.525, 0, 0, 1.858],
    10236: [0.011, 0.511, 0, 0, 1.638],
    10815: [0, 0.68333, 0, 0, 0.75],
    10927: [0.13597, 0.63597, 0, 0, 0.77778],
    10928: [0.13597, 0.63597, 0, 0, 0.77778],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.44444, 0, 0, 0.575],
    49: [0, 0.44444, 0, 0, 0.575],
    50: [0, 0.44444, 0, 0, 0.575],
    51: [0.19444, 0.44444, 0, 0, 0.575],
    52: [0.19444, 0.44444, 0, 0, 0.575],
    53: [0.19444, 0.44444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0.19444, 0.44444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0.19444, 0.44444, 0, 0, 0.575],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0.04835, 0, 0.8664],
    67: [0, 0.68611, 0.06979, 0, 0.81694],
    68: [0, 0.68611, 0.03194, 0, 0.93812],
    69: [0, 0.68611, 0.05451, 0, 0.81007],
    70: [0, 0.68611, 0.15972, 0, 0.68889],
    71: [0, 0.68611, 0, 0, 0.88673],
    72: [0, 0.68611, 0.08229, 0, 0.98229],
    73: [0, 0.68611, 0.07778, 0, 0.51111],
    74: [0, 0.68611, 0.10069, 0, 0.63125],
    75: [0, 0.68611, 0.06979, 0, 0.97118],
    76: [0, 0.68611, 0, 0, 0.75555],
    77: [0, 0.68611, 0.11424, 0, 1.14201],
    78: [0, 0.68611, 0.11424, 0, 0.95034],
    79: [0, 0.68611, 0.03194, 0, 0.83666],
    80: [0, 0.68611, 0.15972, 0, 0.72309],
    81: [0.19444, 0.68611, 0, 0, 0.86861],
    82: [0, 0.68611, 421e-5, 0, 0.87235],
    83: [0, 0.68611, 0.05382, 0, 0.69271],
    84: [0, 0.68611, 0.15972, 0, 0.63663],
    85: [0, 0.68611, 0.11424, 0, 0.80027],
    86: [0, 0.68611, 0.25555, 0, 0.67778],
    87: [0, 0.68611, 0.15972, 0, 1.09305],
    88: [0, 0.68611, 0.07778, 0, 0.94722],
    89: [0, 0.68611, 0.25555, 0, 0.67458],
    90: [0, 0.68611, 0.06979, 0, 0.77257],
    97: [0, 0.44444, 0, 0, 0.63287],
    98: [0, 0.69444, 0, 0, 0.52083],
    99: [0, 0.44444, 0, 0, 0.51342],
    100: [0, 0.69444, 0, 0, 0.60972],
    101: [0, 0.44444, 0, 0, 0.55361],
    102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
    103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
    104: [0, 0.69444, 0, 0, 0.66759],
    105: [0, 0.69326, 0, 0, 0.4048],
    106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
    107: [0, 0.69444, 0.01852, 0, 0.6037],
    108: [0, 0.69444, 88e-4, 0, 0.34815],
    109: [0, 0.44444, 0, 0, 1.0324],
    110: [0, 0.44444, 0, 0, 0.71296],
    111: [0, 0.44444, 0, 0, 0.58472],
    112: [0.19444, 0.44444, 0, 0, 0.60092],
    113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
    114: [0, 0.44444, 0.03194, 0, 0.5287],
    115: [0, 0.44444, 0, 0, 0.53125],
    116: [0, 0.63492, 0, 0, 0.41528],
    117: [0, 0.44444, 0, 0, 0.68102],
    118: [0, 0.44444, 0.03704, 0, 0.56666],
    119: [0, 0.44444, 0.02778, 0, 0.83148],
    120: [0, 0.44444, 0, 0, 0.65903],
    121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
    122: [0, 0.44444, 0.04213, 0, 0.55509],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68611, 0.15972, 0, 0.65694],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0.03194, 0, 0.86722],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0.07458, 0, 0.84125],
    928: [0, 0.68611, 0.08229, 0, 0.98229],
    931: [0, 0.68611, 0.05451, 0, 0.88507],
    933: [0, 0.68611, 0.15972, 0, 0.67083],
    934: [0, 0.68611, 0, 0, 0.76666],
    936: [0, 0.68611, 0.11653, 0, 0.71402],
    937: [0, 0.68611, 0.04835, 0, 0.8789],
    945: [0, 0.44444, 0, 0, 0.76064],
    946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
    947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
    948: [0, 0.69444, 0.03819, 0, 0.52222],
    949: [0, 0.44444, 0, 0, 0.52882],
    950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
    951: [0.19444, 0.44444, 0.03704, 0, 0.6],
    952: [0, 0.69444, 0.03194, 0, 0.5618],
    953: [0, 0.44444, 0, 0, 0.41204],
    954: [0, 0.44444, 0, 0, 0.66759],
    955: [0, 0.69444, 0, 0, 0.67083],
    956: [0.19444, 0.44444, 0, 0, 0.70787],
    957: [0, 0.44444, 0.06898, 0, 0.57685],
    958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
    959: [0, 0.44444, 0, 0, 0.58472],
    960: [0, 0.44444, 0.03704, 0, 0.68241],
    961: [0.19444, 0.44444, 0, 0, 0.6118],
    962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
    963: [0, 0.44444, 0.03704, 0, 0.68588],
    964: [0, 0.44444, 0.13472, 0, 0.52083],
    965: [0, 0.44444, 0.03704, 0, 0.63055],
    966: [0.19444, 0.44444, 0, 0, 0.74722],
    967: [0.19444, 0.44444, 0, 0, 0.71805],
    968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
    969: [0, 0.44444, 0.03704, 0, 0.71782],
    977: [0, 0.69444, 0, 0, 0.69155],
    981: [0.19444, 0.69444, 0, 0, 0.7125],
    982: [0, 0.44444, 0.03194, 0, 0.975],
    1009: [0.19444, 0.44444, 0, 0, 0.6118],
    1013: [0, 0.44444, 0, 0, 0.48333],
    57649: [0, 0.44444, 0, 0, 0.39352],
    57911: [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.43056, 0, 0, 0.5],
    49: [0, 0.43056, 0, 0, 0.5],
    50: [0, 0.43056, 0, 0, 0.5],
    51: [0.19444, 0.43056, 0, 0, 0.5],
    52: [0.19444, 0.43056, 0, 0, 0.5],
    53: [0.19444, 0.43056, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0.19444, 0.43056, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0.19444, 0.43056, 0, 0, 0.5],
    65: [0, 0.68333, 0, 0.13889, 0.75],
    66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
    67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
    68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
    69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
    70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
    71: [0, 0.68333, 0, 0.08334, 0.78625],
    72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
    74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
    75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
    76: [0, 0.68333, 0, 0.02778, 0.68056],
    77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
    78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
    79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
    81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
    82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
    83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
    84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
    85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
    86: [0, 0.68333, 0.22222, 0, 0.58333],
    87: [0, 0.68333, 0.13889, 0, 0.94445],
    88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
    89: [0, 0.68333, 0.22222, 0, 0.58056],
    90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
    97: [0, 0.43056, 0, 0, 0.52859],
    98: [0, 0.69444, 0, 0, 0.42917],
    99: [0, 0.43056, 0, 0.05556, 0.43276],
    100: [0, 0.69444, 0, 0.16667, 0.52049],
    101: [0, 0.43056, 0, 0.05556, 0.46563],
    102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    104: [0, 0.69444, 0, 0, 0.57616],
    105: [0, 0.65952, 0, 0, 0.34451],
    106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
    107: [0, 0.69444, 0.03148, 0, 0.5206],
    108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
    109: [0, 0.43056, 0, 0, 0.87801],
    110: [0, 0.43056, 0, 0, 0.60023],
    111: [0, 0.43056, 0, 0.05556, 0.48472],
    112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
    113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
    115: [0, 0.43056, 0, 0.05556, 0.46875],
    116: [0, 0.61508, 0, 0.08334, 0.36111],
    117: [0, 0.43056, 0, 0.02778, 0.57246],
    118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
    119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
    120: [0, 0.43056, 0, 0.02778, 0.57153],
    121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
    916: [0, 0.68333, 0, 0.16667, 0.83334],
    920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    923: [0, 0.68333, 0, 0.16667, 0.69445],
    926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
    928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
    933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
    934: [0, 0.68333, 0, 0.08334, 0.66667],
    936: [0, 0.68333, 0.11, 0.05556, 0.61222],
    937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
    945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
    946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
    948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
    949: [0, 0.43056, 0, 0.08334, 0.46632],
    950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
    953: [0, 0.43056, 0, 0.05556, 0.35394],
    954: [0, 0.43056, 0, 0, 0.57616],
    955: [0, 0.69444, 0, 0, 0.58334],
    956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
    957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
    958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    959: [0, 0.43056, 0, 0.05556, 0.48472],
    960: [0, 0.43056, 0.03588, 0, 0.57003],
    961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    963: [0, 0.43056, 0.03588, 0, 0.57141],
    964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
    965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
    966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
    967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
    968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    969: [0, 0.43056, 0.03588, 0, 0.62245],
    977: [0, 0.69444, 0, 0.08334, 0.59144],
    981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
    982: [0, 0.43056, 0.02778, 0, 0.82813],
    1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    1013: [0, 0.43056, 0, 0.05556, 0.4059],
    57649: [0, 0.43056, 0, 0.02778, 0.32246],
    57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.36667],
    34: [0, 0.69444, 0, 0, 0.55834],
    35: [0.19444, 0.69444, 0, 0, 0.91667],
    36: [0.05556, 0.75, 0, 0, 0.55],
    37: [0.05556, 0.75, 0, 0, 1.02912],
    38: [0, 0.69444, 0, 0, 0.83056],
    39: [0, 0.69444, 0, 0, 0.30556],
    40: [0.25, 0.75, 0, 0, 0.42778],
    41: [0.25, 0.75, 0, 0, 0.42778],
    42: [0, 0.75, 0, 0, 0.55],
    43: [0.11667, 0.61667, 0, 0, 0.85556],
    44: [0.10556, 0.13056, 0, 0, 0.30556],
    45: [0, 0.45833, 0, 0, 0.36667],
    46: [0, 0.13056, 0, 0, 0.30556],
    47: [0.25, 0.75, 0, 0, 0.55],
    48: [0, 0.69444, 0, 0, 0.55],
    49: [0, 0.69444, 0, 0, 0.55],
    50: [0, 0.69444, 0, 0, 0.55],
    51: [0, 0.69444, 0, 0, 0.55],
    52: [0, 0.69444, 0, 0, 0.55],
    53: [0, 0.69444, 0, 0, 0.55],
    54: [0, 0.69444, 0, 0, 0.55],
    55: [0, 0.69444, 0, 0, 0.55],
    56: [0, 0.69444, 0, 0, 0.55],
    57: [0, 0.69444, 0, 0, 0.55],
    58: [0, 0.45833, 0, 0, 0.30556],
    59: [0.10556, 0.45833, 0, 0, 0.30556],
    61: [-0.09375, 0.40625, 0, 0, 0.85556],
    63: [0, 0.69444, 0, 0, 0.51945],
    64: [0, 0.69444, 0, 0, 0.73334],
    65: [0, 0.69444, 0, 0, 0.73334],
    66: [0, 0.69444, 0, 0, 0.73334],
    67: [0, 0.69444, 0, 0, 0.70278],
    68: [0, 0.69444, 0, 0, 0.79445],
    69: [0, 0.69444, 0, 0, 0.64167],
    70: [0, 0.69444, 0, 0, 0.61111],
    71: [0, 0.69444, 0, 0, 0.73334],
    72: [0, 0.69444, 0, 0, 0.79445],
    73: [0, 0.69444, 0, 0, 0.33056],
    74: [0, 0.69444, 0, 0, 0.51945],
    75: [0, 0.69444, 0, 0, 0.76389],
    76: [0, 0.69444, 0, 0, 0.58056],
    77: [0, 0.69444, 0, 0, 0.97778],
    78: [0, 0.69444, 0, 0, 0.79445],
    79: [0, 0.69444, 0, 0, 0.79445],
    80: [0, 0.69444, 0, 0, 0.70278],
    81: [0.10556, 0.69444, 0, 0, 0.79445],
    82: [0, 0.69444, 0, 0, 0.70278],
    83: [0, 0.69444, 0, 0, 0.61111],
    84: [0, 0.69444, 0, 0, 0.73334],
    85: [0, 0.69444, 0, 0, 0.76389],
    86: [0, 0.69444, 0.01528, 0, 0.73334],
    87: [0, 0.69444, 0.01528, 0, 1.03889],
    88: [0, 0.69444, 0, 0, 0.73334],
    89: [0, 0.69444, 0.0275, 0, 0.73334],
    90: [0, 0.69444, 0, 0, 0.67223],
    91: [0.25, 0.75, 0, 0, 0.34306],
    93: [0.25, 0.75, 0, 0, 0.34306],
    94: [0, 0.69444, 0, 0, 0.55],
    95: [0.35, 0.10833, 0.03056, 0, 0.55],
    97: [0, 0.45833, 0, 0, 0.525],
    98: [0, 0.69444, 0, 0, 0.56111],
    99: [0, 0.45833, 0, 0, 0.48889],
    100: [0, 0.69444, 0, 0, 0.56111],
    101: [0, 0.45833, 0, 0, 0.51111],
    102: [0, 0.69444, 0.07639, 0, 0.33611],
    103: [0.19444, 0.45833, 0.01528, 0, 0.55],
    104: [0, 0.69444, 0, 0, 0.56111],
    105: [0, 0.69444, 0, 0, 0.25556],
    106: [0.19444, 0.69444, 0, 0, 0.28611],
    107: [0, 0.69444, 0, 0, 0.53056],
    108: [0, 0.69444, 0, 0, 0.25556],
    109: [0, 0.45833, 0, 0, 0.86667],
    110: [0, 0.45833, 0, 0, 0.56111],
    111: [0, 0.45833, 0, 0, 0.55],
    112: [0.19444, 0.45833, 0, 0, 0.56111],
    113: [0.19444, 0.45833, 0, 0, 0.56111],
    114: [0, 0.45833, 0.01528, 0, 0.37222],
    115: [0, 0.45833, 0, 0, 0.42167],
    116: [0, 0.58929, 0, 0, 0.40417],
    117: [0, 0.45833, 0, 0, 0.56111],
    118: [0, 0.45833, 0.01528, 0, 0.5],
    119: [0, 0.45833, 0.01528, 0, 0.74445],
    120: [0, 0.45833, 0, 0, 0.5],
    121: [0.19444, 0.45833, 0.01528, 0, 0.5],
    122: [0, 0.45833, 0, 0, 0.47639],
    126: [0.35, 0.34444, 0, 0, 0.55],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0, 0, 0.55],
    176: [0, 0.69444, 0, 0, 0.73334],
    180: [0, 0.69444, 0, 0, 0.55],
    184: [0.17014, 0, 0, 0, 0.48889],
    305: [0, 0.45833, 0, 0, 0.25556],
    567: [0.19444, 0.45833, 0, 0, 0.28611],
    710: [0, 0.69444, 0, 0, 0.55],
    711: [0, 0.63542, 0, 0, 0.55],
    713: [0, 0.63778, 0, 0, 0.55],
    728: [0, 0.69444, 0, 0, 0.55],
    729: [0, 0.69444, 0, 0, 0.30556],
    730: [0, 0.69444, 0, 0, 0.73334],
    732: [0, 0.69444, 0, 0, 0.55],
    733: [0, 0.69444, 0, 0, 0.55],
    915: [0, 0.69444, 0, 0, 0.58056],
    916: [0, 0.69444, 0, 0, 0.91667],
    920: [0, 0.69444, 0, 0, 0.85556],
    923: [0, 0.69444, 0, 0, 0.67223],
    926: [0, 0.69444, 0, 0, 0.73334],
    928: [0, 0.69444, 0, 0, 0.79445],
    931: [0, 0.69444, 0, 0, 0.79445],
    933: [0, 0.69444, 0, 0, 0.85556],
    934: [0, 0.69444, 0, 0, 0.79445],
    936: [0, 0.69444, 0, 0, 0.85556],
    937: [0, 0.69444, 0, 0, 0.79445],
    8211: [0, 0.45833, 0.03056, 0, 0.55],
    8212: [0, 0.45833, 0.03056, 0, 1.10001],
    8216: [0, 0.69444, 0, 0, 0.30556],
    8217: [0, 0.69444, 0, 0, 0.30556],
    8220: [0, 0.69444, 0, 0, 0.55834],
    8221: [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.05733, 0, 0.31945],
    34: [0, 0.69444, 316e-5, 0, 0.5],
    35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
    36: [0.05556, 0.75, 0.11156, 0, 0.5],
    37: [0.05556, 0.75, 0.03126, 0, 0.83334],
    38: [0, 0.69444, 0.03058, 0, 0.75834],
    39: [0, 0.69444, 0.07816, 0, 0.27778],
    40: [0.25, 0.75, 0.13164, 0, 0.38889],
    41: [0.25, 0.75, 0.02536, 0, 0.38889],
    42: [0, 0.75, 0.11775, 0, 0.5],
    43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0.01946, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0.13164, 0, 0.5],
    48: [0, 0.65556, 0.11156, 0, 0.5],
    49: [0, 0.65556, 0.11156, 0, 0.5],
    50: [0, 0.65556, 0.11156, 0, 0.5],
    51: [0, 0.65556, 0.11156, 0, 0.5],
    52: [0, 0.65556, 0.11156, 0, 0.5],
    53: [0, 0.65556, 0.11156, 0, 0.5],
    54: [0, 0.65556, 0.11156, 0, 0.5],
    55: [0, 0.65556, 0.11156, 0, 0.5],
    56: [0, 0.65556, 0.11156, 0, 0.5],
    57: [0, 0.65556, 0.11156, 0, 0.5],
    58: [0, 0.44444, 0.02502, 0, 0.27778],
    59: [0.125, 0.44444, 0.02502, 0, 0.27778],
    61: [-0.13, 0.37, 0.05087, 0, 0.77778],
    63: [0, 0.69444, 0.11809, 0, 0.47222],
    64: [0, 0.69444, 0.07555, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0.08293, 0, 0.66667],
    67: [0, 0.69444, 0.11983, 0, 0.63889],
    68: [0, 0.69444, 0.07555, 0, 0.72223],
    69: [0, 0.69444, 0.11983, 0, 0.59722],
    70: [0, 0.69444, 0.13372, 0, 0.56945],
    71: [0, 0.69444, 0.11983, 0, 0.66667],
    72: [0, 0.69444, 0.08094, 0, 0.70834],
    73: [0, 0.69444, 0.13372, 0, 0.27778],
    74: [0, 0.69444, 0.08094, 0, 0.47222],
    75: [0, 0.69444, 0.11983, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0.08094, 0, 0.875],
    78: [0, 0.69444, 0.08094, 0, 0.70834],
    79: [0, 0.69444, 0.07555, 0, 0.73611],
    80: [0, 0.69444, 0.08293, 0, 0.63889],
    81: [0.125, 0.69444, 0.07555, 0, 0.73611],
    82: [0, 0.69444, 0.08293, 0, 0.64584],
    83: [0, 0.69444, 0.09205, 0, 0.55556],
    84: [0, 0.69444, 0.13372, 0, 0.68056],
    85: [0, 0.69444, 0.08094, 0, 0.6875],
    86: [0, 0.69444, 0.1615, 0, 0.66667],
    87: [0, 0.69444, 0.1615, 0, 0.94445],
    88: [0, 0.69444, 0.13372, 0, 0.66667],
    89: [0, 0.69444, 0.17261, 0, 0.66667],
    90: [0, 0.69444, 0.11983, 0, 0.61111],
    91: [0.25, 0.75, 0.15942, 0, 0.28889],
    93: [0.25, 0.75, 0.08719, 0, 0.28889],
    94: [0, 0.69444, 0.0799, 0, 0.5],
    95: [0.35, 0.09444, 0.08616, 0, 0.5],
    97: [0, 0.44444, 981e-5, 0, 0.48056],
    98: [0, 0.69444, 0.03057, 0, 0.51667],
    99: [0, 0.44444, 0.08336, 0, 0.44445],
    100: [0, 0.69444, 0.09483, 0, 0.51667],
    101: [0, 0.44444, 0.06778, 0, 0.44445],
    102: [0, 0.69444, 0.21705, 0, 0.30556],
    103: [0.19444, 0.44444, 0.10836, 0, 0.5],
    104: [0, 0.69444, 0.01778, 0, 0.51667],
    105: [0, 0.67937, 0.09718, 0, 0.23889],
    106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
    107: [0, 0.69444, 0.08336, 0, 0.48889],
    108: [0, 0.69444, 0.09483, 0, 0.23889],
    109: [0, 0.44444, 0.01778, 0, 0.79445],
    110: [0, 0.44444, 0.01778, 0, 0.51667],
    111: [0, 0.44444, 0.06613, 0, 0.5],
    112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
    113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
    114: [0, 0.44444, 0.10836, 0, 0.34167],
    115: [0, 0.44444, 0.0778, 0, 0.38333],
    116: [0, 0.57143, 0.07225, 0, 0.36111],
    117: [0, 0.44444, 0.04169, 0, 0.51667],
    118: [0, 0.44444, 0.10836, 0, 0.46111],
    119: [0, 0.44444, 0.10836, 0, 0.68334],
    120: [0, 0.44444, 0.09169, 0, 0.46111],
    121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
    122: [0, 0.44444, 0.08752, 0, 0.43472],
    126: [0.35, 0.32659, 0.08826, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0.06385, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.73752],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0.04169, 0, 0.23889],
    567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
    710: [0, 0.69444, 0.0799, 0, 0.5],
    711: [0, 0.63194, 0.08432, 0, 0.5],
    713: [0, 0.60889, 0.08776, 0, 0.5],
    714: [0, 0.69444, 0.09205, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0.09483, 0, 0.5],
    729: [0, 0.67937, 0.07774, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.73752],
    732: [0, 0.67659, 0.08826, 0, 0.5],
    733: [0, 0.69444, 0.09205, 0, 0.5],
    915: [0, 0.69444, 0.13372, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0.07555, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0.12816, 0, 0.66667],
    928: [0, 0.69444, 0.08094, 0, 0.70834],
    931: [0, 0.69444, 0.11983, 0, 0.72222],
    933: [0, 0.69444, 0.09031, 0, 0.77778],
    934: [0, 0.69444, 0.04603, 0, 0.72222],
    936: [0, 0.69444, 0.09031, 0, 0.77778],
    937: [0, 0.69444, 0.08293, 0, 0.72222],
    8211: [0, 0.44444, 0.08616, 0, 0.5],
    8212: [0, 0.44444, 0.08616, 0, 1],
    8216: [0, 0.69444, 0.07816, 0, 0.27778],
    8217: [0, 0.69444, 0.07816, 0, 0.27778],
    8220: [0, 0.69444, 0.14205, 0, 0.5],
    8221: [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.31945],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.75834],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.65556, 0, 0, 0.5],
    49: [0, 0.65556, 0, 0, 0.5],
    50: [0, 0.65556, 0, 0, 0.5],
    51: [0, 0.65556, 0, 0, 0.5],
    52: [0, 0.65556, 0, 0, 0.5],
    53: [0, 0.65556, 0, 0, 0.5],
    54: [0, 0.65556, 0, 0, 0.5],
    55: [0, 0.65556, 0, 0, 0.5],
    56: [0, 0.65556, 0, 0, 0.5],
    57: [0, 0.65556, 0, 0, 0.5],
    58: [0, 0.44444, 0, 0, 0.27778],
    59: [0.125, 0.44444, 0, 0, 0.27778],
    61: [-0.13, 0.37, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0, 0, 0.66667],
    67: [0, 0.69444, 0, 0, 0.63889],
    68: [0, 0.69444, 0, 0, 0.72223],
    69: [0, 0.69444, 0, 0, 0.59722],
    70: [0, 0.69444, 0, 0, 0.56945],
    71: [0, 0.69444, 0, 0, 0.66667],
    72: [0, 0.69444, 0, 0, 0.70834],
    73: [0, 0.69444, 0, 0, 0.27778],
    74: [0, 0.69444, 0, 0, 0.47222],
    75: [0, 0.69444, 0, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0, 0, 0.875],
    78: [0, 0.69444, 0, 0, 0.70834],
    79: [0, 0.69444, 0, 0, 0.73611],
    80: [0, 0.69444, 0, 0, 0.63889],
    81: [0.125, 0.69444, 0, 0, 0.73611],
    82: [0, 0.69444, 0, 0, 0.64584],
    83: [0, 0.69444, 0, 0, 0.55556],
    84: [0, 0.69444, 0, 0, 0.68056],
    85: [0, 0.69444, 0, 0, 0.6875],
    86: [0, 0.69444, 0.01389, 0, 0.66667],
    87: [0, 0.69444, 0.01389, 0, 0.94445],
    88: [0, 0.69444, 0, 0, 0.66667],
    89: [0, 0.69444, 0.025, 0, 0.66667],
    90: [0, 0.69444, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.28889],
    93: [0.25, 0.75, 0, 0, 0.28889],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.35, 0.09444, 0.02778, 0, 0.5],
    97: [0, 0.44444, 0, 0, 0.48056],
    98: [0, 0.69444, 0, 0, 0.51667],
    99: [0, 0.44444, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.51667],
    101: [0, 0.44444, 0, 0, 0.44445],
    102: [0, 0.69444, 0.06944, 0, 0.30556],
    103: [0.19444, 0.44444, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.51667],
    105: [0, 0.67937, 0, 0, 0.23889],
    106: [0.19444, 0.67937, 0, 0, 0.26667],
    107: [0, 0.69444, 0, 0, 0.48889],
    108: [0, 0.69444, 0, 0, 0.23889],
    109: [0, 0.44444, 0, 0, 0.79445],
    110: [0, 0.44444, 0, 0, 0.51667],
    111: [0, 0.44444, 0, 0, 0.5],
    112: [0.19444, 0.44444, 0, 0, 0.51667],
    113: [0.19444, 0.44444, 0, 0, 0.51667],
    114: [0, 0.44444, 0.01389, 0, 0.34167],
    115: [0, 0.44444, 0, 0, 0.38333],
    116: [0, 0.57143, 0, 0, 0.36111],
    117: [0, 0.44444, 0, 0, 0.51667],
    118: [0, 0.44444, 0.01389, 0, 0.46111],
    119: [0, 0.44444, 0.01389, 0, 0.68334],
    120: [0, 0.44444, 0, 0, 0.46111],
    121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
    122: [0, 0.44444, 0, 0, 0.43472],
    126: [0.35, 0.32659, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.66667],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0, 0, 0.23889],
    567: [0.19444, 0.44444, 0, 0, 0.26667],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.63194, 0, 0, 0.5],
    713: [0, 0.60889, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.67937, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.66667],
    732: [0, 0.67659, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.69444, 0, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0, 0, 0.66667],
    928: [0, 0.69444, 0, 0, 0.70834],
    931: [0, 0.69444, 0, 0, 0.72222],
    933: [0, 0.69444, 0, 0, 0.77778],
    934: [0, 0.69444, 0, 0, 0.72222],
    936: [0, 0.69444, 0, 0, 0.77778],
    937: [0, 0.69444, 0, 0, 0.72222],
    8211: [0, 0.44444, 0.02778, 0, 0.5],
    8212: [0, 0.44444, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.7, 0.22925, 0, 0.80253],
    66: [0, 0.7, 0.04087, 0, 0.90757],
    67: [0, 0.7, 0.1689, 0, 0.66619],
    68: [0, 0.7, 0.09371, 0, 0.77443],
    69: [0, 0.7, 0.18583, 0, 0.56162],
    70: [0, 0.7, 0.13634, 0, 0.89544],
    71: [0, 0.7, 0.17322, 0, 0.60961],
    72: [0, 0.7, 0.29694, 0, 0.96919],
    73: [0, 0.7, 0.19189, 0, 0.80907],
    74: [0.27778, 0.7, 0.19189, 0, 1.05159],
    75: [0, 0.7, 0.31259, 0, 0.91364],
    76: [0, 0.7, 0.19189, 0, 0.87373],
    77: [0, 0.7, 0.15981, 0, 1.08031],
    78: [0, 0.7, 0.3525, 0, 0.9015],
    79: [0, 0.7, 0.08078, 0, 0.73787],
    80: [0, 0.7, 0.08078, 0, 1.01262],
    81: [0, 0.7, 0.03305, 0, 0.88282],
    82: [0, 0.7, 0.06259, 0, 0.85],
    83: [0, 0.7, 0.19189, 0, 0.86767],
    84: [0, 0.7, 0.29087, 0, 0.74697],
    85: [0, 0.7, 0.25815, 0, 0.79996],
    86: [0, 0.7, 0.27523, 0, 0.62204],
    87: [0, 0.7, 0.27523, 0, 0.80532],
    88: [0, 0.7, 0.26006, 0, 0.94445],
    89: [0, 0.7, 0.2939, 0, 0.70961],
    90: [0, 0.7, 0.24037, 0, 0.8212],
    160: [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.35001, 0.85, 0, 0, 0.45834],
    41: [0.35001, 0.85, 0, 0, 0.45834],
    47: [0.35001, 0.85, 0, 0, 0.57778],
    91: [0.35001, 0.85, 0, 0, 0.41667],
    92: [0.35001, 0.85, 0, 0, 0.57778],
    93: [0.35001, 0.85, 0, 0, 0.41667],
    123: [0.35001, 0.85, 0, 0, 0.58334],
    125: [0.35001, 0.85, 0, 0, 0.58334],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.72222, 0, 0, 0.55556],
    732: [0, 0.72222, 0, 0, 0.55556],
    770: [0, 0.72222, 0, 0, 0.55556],
    771: [0, 0.72222, 0, 0, 0.55556],
    8214: [-99e-5, 0.601, 0, 0, 0.77778],
    8593: [1e-5, 0.6, 0, 0, 0.66667],
    8595: [1e-5, 0.6, 0, 0, 0.66667],
    8657: [1e-5, 0.6, 0, 0, 0.77778],
    8659: [1e-5, 0.6, 0, 0, 0.77778],
    8719: [0.25001, 0.75, 0, 0, 0.94445],
    8720: [0.25001, 0.75, 0, 0, 0.94445],
    8721: [0.25001, 0.75, 0, 0, 1.05556],
    8730: [0.35001, 0.85, 0, 0, 1],
    8739: [-599e-5, 0.606, 0, 0, 0.33333],
    8741: [-599e-5, 0.606, 0, 0, 0.55556],
    8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8748: [0.306, 0.805, 0.19445, 0, 0.47222],
    8749: [0.306, 0.805, 0.19445, 0, 0.47222],
    8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8896: [0.25001, 0.75, 0, 0, 0.83334],
    8897: [0.25001, 0.75, 0, 0, 0.83334],
    8898: [0.25001, 0.75, 0, 0, 0.83334],
    8899: [0.25001, 0.75, 0, 0, 0.83334],
    8968: [0.35001, 0.85, 0, 0, 0.47222],
    8969: [0.35001, 0.85, 0, 0, 0.47222],
    8970: [0.35001, 0.85, 0, 0, 0.47222],
    8971: [0.35001, 0.85, 0, 0, 0.47222],
    9168: [-99e-5, 0.601, 0, 0, 0.66667],
    10216: [0.35001, 0.85, 0, 0, 0.47222],
    10217: [0.35001, 0.85, 0, 0, 0.47222],
    10752: [0.25001, 0.75, 0, 0, 1.11111],
    10753: [0.25001, 0.75, 0, 0, 1.11111],
    10754: [0.25001, 0.75, 0, 0, 1.11111],
    10756: [0.25001, 0.75, 0, 0, 0.83334],
    10758: [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.65002, 1.15, 0, 0, 0.59722],
    41: [0.65002, 1.15, 0, 0, 0.59722],
    47: [0.65002, 1.15, 0, 0, 0.81111],
    91: [0.65002, 1.15, 0, 0, 0.47222],
    92: [0.65002, 1.15, 0, 0, 0.81111],
    93: [0.65002, 1.15, 0, 0, 0.47222],
    123: [0.65002, 1.15, 0, 0, 0.66667],
    125: [0.65002, 1.15, 0, 0, 0.66667],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1],
    732: [0, 0.75, 0, 0, 1],
    770: [0, 0.75, 0, 0, 1],
    771: [0, 0.75, 0, 0, 1],
    8719: [0.55001, 1.05, 0, 0, 1.27778],
    8720: [0.55001, 1.05, 0, 0, 1.27778],
    8721: [0.55001, 1.05, 0, 0, 1.44445],
    8730: [0.65002, 1.15, 0, 0, 1],
    8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8748: [0.862, 1.36, 0.44445, 0, 0.55556],
    8749: [0.862, 1.36, 0.44445, 0, 0.55556],
    8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8896: [0.55001, 1.05, 0, 0, 1.11111],
    8897: [0.55001, 1.05, 0, 0, 1.11111],
    8898: [0.55001, 1.05, 0, 0, 1.11111],
    8899: [0.55001, 1.05, 0, 0, 1.11111],
    8968: [0.65002, 1.15, 0, 0, 0.52778],
    8969: [0.65002, 1.15, 0, 0, 0.52778],
    8970: [0.65002, 1.15, 0, 0, 0.52778],
    8971: [0.65002, 1.15, 0, 0, 0.52778],
    10216: [0.65002, 1.15, 0, 0, 0.61111],
    10217: [0.65002, 1.15, 0, 0, 0.61111],
    10752: [0.55001, 1.05, 0, 0, 1.51112],
    10753: [0.55001, 1.05, 0, 0, 1.51112],
    10754: [0.55001, 1.05, 0, 0, 1.51112],
    10756: [0.55001, 1.05, 0, 0, 1.11111],
    10758: [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.95003, 1.45, 0, 0, 0.73611],
    41: [0.95003, 1.45, 0, 0, 0.73611],
    47: [0.95003, 1.45, 0, 0, 1.04445],
    91: [0.95003, 1.45, 0, 0, 0.52778],
    92: [0.95003, 1.45, 0, 0, 1.04445],
    93: [0.95003, 1.45, 0, 0, 0.52778],
    123: [0.95003, 1.45, 0, 0, 0.75],
    125: [0.95003, 1.45, 0, 0, 0.75],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1.44445],
    732: [0, 0.75, 0, 0, 1.44445],
    770: [0, 0.75, 0, 0, 1.44445],
    771: [0, 0.75, 0, 0, 1.44445],
    8730: [0.95003, 1.45, 0, 0, 1],
    8968: [0.95003, 1.45, 0, 0, 0.58334],
    8969: [0.95003, 1.45, 0, 0, 0.58334],
    8970: [0.95003, 1.45, 0, 0, 0.58334],
    8971: [0.95003, 1.45, 0, 0, 0.58334],
    10216: [0.95003, 1.45, 0, 0, 0.75],
    10217: [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [1.25003, 1.75, 0, 0, 0.79167],
    41: [1.25003, 1.75, 0, 0, 0.79167],
    47: [1.25003, 1.75, 0, 0, 1.27778],
    91: [1.25003, 1.75, 0, 0, 0.58334],
    92: [1.25003, 1.75, 0, 0, 1.27778],
    93: [1.25003, 1.75, 0, 0, 0.58334],
    123: [1.25003, 1.75, 0, 0, 0.80556],
    125: [1.25003, 1.75, 0, 0, 0.80556],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.825, 0, 0, 1.8889],
    732: [0, 0.825, 0, 0, 1.8889],
    770: [0, 0.825, 0, 0, 1.8889],
    771: [0, 0.825, 0, 0, 1.8889],
    8730: [1.25003, 1.75, 0, 0, 1],
    8968: [1.25003, 1.75, 0, 0, 0.63889],
    8969: [1.25003, 1.75, 0, 0, 0.63889],
    8970: [1.25003, 1.75, 0, 0, 0.63889],
    8971: [1.25003, 1.75, 0, 0, 0.63889],
    9115: [0.64502, 1.155, 0, 0, 0.875],
    9116: [1e-5, 0.6, 0, 0, 0.875],
    9117: [0.64502, 1.155, 0, 0, 0.875],
    9118: [0.64502, 1.155, 0, 0, 0.875],
    9119: [1e-5, 0.6, 0, 0, 0.875],
    9120: [0.64502, 1.155, 0, 0, 0.875],
    9121: [0.64502, 1.155, 0, 0, 0.66667],
    9122: [-99e-5, 0.601, 0, 0, 0.66667],
    9123: [0.64502, 1.155, 0, 0, 0.66667],
    9124: [0.64502, 1.155, 0, 0, 0.66667],
    9125: [-99e-5, 0.601, 0, 0, 0.66667],
    9126: [0.64502, 1.155, 0, 0, 0.66667],
    9127: [1e-5, 0.9, 0, 0, 0.88889],
    9128: [0.65002, 1.15, 0, 0, 0.88889],
    9129: [0.90001, 0, 0, 0, 0.88889],
    9130: [0, 0.3, 0, 0, 0.88889],
    9131: [1e-5, 0.9, 0, 0, 0.88889],
    9132: [0.65002, 1.15, 0, 0, 0.88889],
    9133: [0.90001, 0, 0, 0, 0.88889],
    9143: [0.88502, 0.915, 0, 0, 1.05556],
    10216: [1.25003, 1.75, 0, 0, 0.80556],
    10217: [1.25003, 1.75, 0, 0, 0.80556],
    57344: [-499e-5, 0.605, 0, 0, 1.05556],
    57345: [-499e-5, 0.605, 0, 0, 1.05556],
    57680: [0, 0.12, 0, 0, 0.45],
    57681: [0, 0.12, 0, 0, 0.45],
    57682: [0, 0.12, 0, 0, 0.45],
    57683: [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    32: [0, 0, 0, 0, 0.525],
    33: [0, 0.61111, 0, 0, 0.525],
    34: [0, 0.61111, 0, 0, 0.525],
    35: [0, 0.61111, 0, 0, 0.525],
    36: [0.08333, 0.69444, 0, 0, 0.525],
    37: [0.08333, 0.69444, 0, 0, 0.525],
    38: [0, 0.61111, 0, 0, 0.525],
    39: [0, 0.61111, 0, 0, 0.525],
    40: [0.08333, 0.69444, 0, 0, 0.525],
    41: [0.08333, 0.69444, 0, 0, 0.525],
    42: [0, 0.52083, 0, 0, 0.525],
    43: [-0.08056, 0.53055, 0, 0, 0.525],
    44: [0.13889, 0.125, 0, 0, 0.525],
    45: [-0.08056, 0.53055, 0, 0, 0.525],
    46: [0, 0.125, 0, 0, 0.525],
    47: [0.08333, 0.69444, 0, 0, 0.525],
    48: [0, 0.61111, 0, 0, 0.525],
    49: [0, 0.61111, 0, 0, 0.525],
    50: [0, 0.61111, 0, 0, 0.525],
    51: [0, 0.61111, 0, 0, 0.525],
    52: [0, 0.61111, 0, 0, 0.525],
    53: [0, 0.61111, 0, 0, 0.525],
    54: [0, 0.61111, 0, 0, 0.525],
    55: [0, 0.61111, 0, 0, 0.525],
    56: [0, 0.61111, 0, 0, 0.525],
    57: [0, 0.61111, 0, 0, 0.525],
    58: [0, 0.43056, 0, 0, 0.525],
    59: [0.13889, 0.43056, 0, 0, 0.525],
    60: [-0.05556, 0.55556, 0, 0, 0.525],
    61: [-0.19549, 0.41562, 0, 0, 0.525],
    62: [-0.05556, 0.55556, 0, 0, 0.525],
    63: [0, 0.61111, 0, 0, 0.525],
    64: [0, 0.61111, 0, 0, 0.525],
    65: [0, 0.61111, 0, 0, 0.525],
    66: [0, 0.61111, 0, 0, 0.525],
    67: [0, 0.61111, 0, 0, 0.525],
    68: [0, 0.61111, 0, 0, 0.525],
    69: [0, 0.61111, 0, 0, 0.525],
    70: [0, 0.61111, 0, 0, 0.525],
    71: [0, 0.61111, 0, 0, 0.525],
    72: [0, 0.61111, 0, 0, 0.525],
    73: [0, 0.61111, 0, 0, 0.525],
    74: [0, 0.61111, 0, 0, 0.525],
    75: [0, 0.61111, 0, 0, 0.525],
    76: [0, 0.61111, 0, 0, 0.525],
    77: [0, 0.61111, 0, 0, 0.525],
    78: [0, 0.61111, 0, 0, 0.525],
    79: [0, 0.61111, 0, 0, 0.525],
    80: [0, 0.61111, 0, 0, 0.525],
    81: [0.13889, 0.61111, 0, 0, 0.525],
    82: [0, 0.61111, 0, 0, 0.525],
    83: [0, 0.61111, 0, 0, 0.525],
    84: [0, 0.61111, 0, 0, 0.525],
    85: [0, 0.61111, 0, 0, 0.525],
    86: [0, 0.61111, 0, 0, 0.525],
    87: [0, 0.61111, 0, 0, 0.525],
    88: [0, 0.61111, 0, 0, 0.525],
    89: [0, 0.61111, 0, 0, 0.525],
    90: [0, 0.61111, 0, 0, 0.525],
    91: [0.08333, 0.69444, 0, 0, 0.525],
    92: [0.08333, 0.69444, 0, 0, 0.525],
    93: [0.08333, 0.69444, 0, 0, 0.525],
    94: [0, 0.61111, 0, 0, 0.525],
    95: [0.09514, 0, 0, 0, 0.525],
    96: [0, 0.61111, 0, 0, 0.525],
    97: [0, 0.43056, 0, 0, 0.525],
    98: [0, 0.61111, 0, 0, 0.525],
    99: [0, 0.43056, 0, 0, 0.525],
    100: [0, 0.61111, 0, 0, 0.525],
    101: [0, 0.43056, 0, 0, 0.525],
    102: [0, 0.61111, 0, 0, 0.525],
    103: [0.22222, 0.43056, 0, 0, 0.525],
    104: [0, 0.61111, 0, 0, 0.525],
    105: [0, 0.61111, 0, 0, 0.525],
    106: [0.22222, 0.61111, 0, 0, 0.525],
    107: [0, 0.61111, 0, 0, 0.525],
    108: [0, 0.61111, 0, 0, 0.525],
    109: [0, 0.43056, 0, 0, 0.525],
    110: [0, 0.43056, 0, 0, 0.525],
    111: [0, 0.43056, 0, 0, 0.525],
    112: [0.22222, 0.43056, 0, 0, 0.525],
    113: [0.22222, 0.43056, 0, 0, 0.525],
    114: [0, 0.43056, 0, 0, 0.525],
    115: [0, 0.43056, 0, 0, 0.525],
    116: [0, 0.55358, 0, 0, 0.525],
    117: [0, 0.43056, 0, 0, 0.525],
    118: [0, 0.43056, 0, 0, 0.525],
    119: [0, 0.43056, 0, 0, 0.525],
    120: [0, 0.43056, 0, 0, 0.525],
    121: [0.22222, 0.43056, 0, 0, 0.525],
    122: [0, 0.43056, 0, 0, 0.525],
    123: [0.08333, 0.69444, 0, 0, 0.525],
    124: [0.08333, 0.69444, 0, 0, 0.525],
    125: [0.08333, 0.69444, 0, 0, 0.525],
    126: [0, 0.61111, 0, 0, 0.525],
    127: [0, 0.61111, 0, 0, 0.525],
    160: [0, 0, 0, 0, 0.525],
    176: [0, 0.61111, 0, 0, 0.525],
    184: [0.19445, 0, 0, 0, 0.525],
    305: [0, 0.43056, 0, 0, 0.525],
    567: [0.22222, 0.43056, 0, 0, 0.525],
    711: [0, 0.56597, 0, 0, 0.525],
    713: [0, 0.56555, 0, 0, 0.525],
    714: [0, 0.61111, 0, 0, 0.525],
    715: [0, 0.61111, 0, 0, 0.525],
    728: [0, 0.61111, 0, 0, 0.525],
    730: [0, 0.61111, 0, 0, 0.525],
    770: [0, 0.61111, 0, 0, 0.525],
    771: [0, 0.61111, 0, 0, 0.525],
    776: [0, 0.61111, 0, 0, 0.525],
    915: [0, 0.61111, 0, 0, 0.525],
    916: [0, 0.61111, 0, 0, 0.525],
    920: [0, 0.61111, 0, 0, 0.525],
    923: [0, 0.61111, 0, 0, 0.525],
    926: [0, 0.61111, 0, 0, 0.525],
    928: [0, 0.61111, 0, 0, 0.525],
    931: [0, 0.61111, 0, 0, 0.525],
    933: [0, 0.61111, 0, 0, 0.525],
    934: [0, 0.61111, 0, 0, 0.525],
    936: [0, 0.61111, 0, 0, 0.525],
    937: [0, 0.61111, 0, 0, 0.525],
    8216: [0, 0.61111, 0, 0, 0.525],
    8217: [0, 0.61111, 0, 0, 0.525],
    8242: [0, 0.61111, 0, 0, 0.525],
    9251: [0.11111, 0.21944, 0, 0, 0.525]
  }
}, Ma = {
  // Latin-1
  Å: "A",
  Ð: "D",
  Þ: "o",
  å: "a",
  ð: "d",
  þ: "o",
  // Cyrillic
  А: "A",
  Б: "B",
  В: "B",
  Г: "F",
  Д: "A",
  Е: "E",
  Ж: "K",
  З: "3",
  И: "N",
  Й: "N",
  К: "K",
  Л: "N",
  М: "M",
  Н: "H",
  О: "O",
  П: "N",
  Р: "P",
  С: "C",
  Т: "T",
  У: "y",
  Ф: "O",
  Х: "X",
  Ц: "U",
  Ч: "h",
  Ш: "W",
  Щ: "W",
  Ъ: "B",
  Ы: "X",
  Ь: "B",
  Э: "3",
  Ю: "X",
  Я: "R",
  а: "a",
  б: "b",
  в: "a",
  г: "r",
  д: "y",
  е: "e",
  ж: "m",
  з: "e",
  и: "n",
  й: "n",
  к: "n",
  л: "n",
  м: "m",
  н: "n",
  о: "o",
  п: "n",
  р: "p",
  с: "c",
  т: "o",
  у: "y",
  ф: "b",
  х: "x",
  ц: "n",
  ч: "n",
  ш: "w",
  щ: "w",
  ъ: "a",
  ы: "m",
  ь: "a",
  э: "e",
  ю: "m",
  я: "r"
};
function Nn(n, e, t) {
  if (!Vt[e])
    throw new Error("Font metrics not found for font: " + e + ".");
  var r = n.charCodeAt(0), a = Vt[e][r];
  if (!a && n[0] in Ma && (r = Ma[n[0]].charCodeAt(0), a = Vt[e][r]), !a && t === "text" && lo(r) && (a = Vt[e][77]), a)
    return {
      depth: a[0],
      height: a[1],
      italic: a[2],
      skew: a[3],
      width: a[4]
    };
}
var yn = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  pt: 1,
  // TeX point
  mm: 7227 / 2540,
  // millimeter
  cm: 7227 / 254,
  // centimeter
  in: 72.27,
  // inch
  bp: 803 / 800,
  // big (PostScript) points
  pc: 12,
  // pica
  dd: 1238 / 1157,
  // didot
  cc: 14856 / 1157,
  // cicero (12 didot)
  nd: 685 / 642,
  // new didot
  nc: 1370 / 107,
  // new cicero (12 new didot)
  sp: 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  px: 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
}, vo = {
  ex: !0,
  em: !0,
  mu: !0
}, bo = function(e) {
  return typeof e != "string" && (e = e.unit), e in yn || e in vo || e === "ex";
}, ge = function(e, t) {
  var r;
  if (e.unit in yn)
    r = yn[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
  else if (e.unit === "mu")
    r = t.fontMetrics().cssEmPerMu;
  else {
    var a;
    if (t.style.isTight() ? a = t.havingStyle(t.style.text()) : a = t, e.unit === "ex")
      r = a.fontMetrics().xHeight;
    else if (e.unit === "em")
      r = a.fontMetrics().quad;
    else
      throw new G("Invalid unit: '" + e.unit + "'");
    a !== t && (r *= a.sizeMultiplier / t.sizeMultiplier);
  }
  return Math.min(e.number * r, t.maxSize);
}, I = function(e) {
  return +e.toFixed(4) + "em";
}, Jt = function(e) {
  return e.filter((t) => t).join(" ");
}, tl = function(e, t, r) {
  if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = r || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var a = t.getColor();
    a && (this.style.color = a);
  }
}, rl = function(e) {
  var t = document.createElement(e);
  t.className = Jt(this.classes);
  for (var r in this.style)
    this.style.hasOwnProperty(r) && (t.style[r] = this.style[r]);
  for (var a in this.attributes)
    this.attributes.hasOwnProperty(a) && t.setAttribute(a, this.attributes[a]);
  for (var i = 0; i < this.children.length; i++)
    t.appendChild(this.children[i].toNode());
  return t;
}, yo = /[\s"'>/=\x00-\x1f]/, nl = function(e) {
  var t = "<" + e;
  this.classes.length && (t += ' class="' + j.escape(Jt(this.classes)) + '"');
  var r = "";
  for (var a in this.style)
    this.style.hasOwnProperty(a) && (r += j.hyphenate(a) + ":" + this.style[a] + ";");
  r && (t += ' style="' + j.escape(r) + '"');
  for (var i in this.attributes)
    if (this.attributes.hasOwnProperty(i)) {
      if (yo.test(i))
        throw new G("Invalid attribute name '" + i + "'");
      t += " " + i + '="' + j.escape(this.attributes[i]) + '"';
    }
  t += ">";
  for (var l = 0; l < this.children.length; l++)
    t += this.children[l].toMarkup();
  return t += "</" + e + ">", t;
};
class zr {
  constructor(e, t, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, tl.call(this, e, r, a), this.children = t || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  toNode() {
    return rl.call(this, "span");
  }
  toMarkup() {
    return nl.call(this, "span");
  }
}
class al {
  constructor(e, t, r, a) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, tl.call(this, t, a), this.children = r || [], this.setAttribute("href", e);
  }
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  toNode() {
    return rl.call(this, "a");
  }
  toMarkup() {
    return nl.call(this, "a");
  }
}
class wo {
  constructor(e, t, r) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = r;
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  toNode() {
    var e = document.createElement("img");
    e.src = this.src, e.alt = this.alt, e.className = "mord";
    for (var t in this.style)
      this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
    return e;
  }
  toMarkup() {
    var e = '<img src="' + j.escape(this.src) + '"' + (' alt="' + j.escape(this.alt) + '"'), t = "";
    for (var r in this.style)
      this.style.hasOwnProperty(r) && (t += j.hyphenate(r) + ":" + this.style[r] + ";");
    return t && (e += ' style="' + j.escape(t) + '"'), e += "'/>", e;
  }
}
var ko = {
  î: "ı̂",
  ï: "ı̈",
  í: "ı́",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  ì: "ı̀"
};
class Tt {
  constructor(e, t, r, a, i, l, o, c) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = r || 0, this.italic = a || 0, this.skew = i || 0, this.width = l || 0, this.classes = o || [], this.style = c || {}, this.maxFontSize = 0;
    var m = io(this.text.charCodeAt(0));
    m && this.classes.push(m + "_fallback"), /[îïíì]/.test(this.text) && (this.text = ko[this.text]);
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var e = document.createTextNode(this.text), t = null;
    this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = I(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = Jt(this.classes));
    for (var r in this.style)
      this.style.hasOwnProperty(r) && (t = t || document.createElement("span"), t.style[r] = this.style[r]);
    return t ? (t.appendChild(e), t) : e;
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var e = !1, t = "<span";
    this.classes.length && (e = !0, t += ' class="', t += j.escape(Jt(this.classes)), t += '"');
    var r = "";
    this.italic > 0 && (r += "margin-right:" + this.italic + "em;");
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (r += j.hyphenate(a) + ":" + this.style[a] + ";");
    r && (e = !0, t += ' style="' + j.escape(r) + '"');
    var i = j.escape(this.text);
    return e ? (t += ">", t += i, t += "</span>", t) : i;
  }
}
class e0 {
  constructor(e, t) {
    this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
    for (var r in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, r) && t.setAttribute(r, this.attributes[r]);
    for (var a = 0; a < this.children.length; a++)
      t.appendChild(this.children[a].toNode());
    return t;
  }
  toMarkup() {
    var e = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + j.escape(this.attributes[t]) + '"');
    e += ">";
    for (var r = 0; r < this.children.length; r++)
      e += this.children[r].toMarkup();
    return e += "</svg>", e;
  }
}
class l0 {
  constructor(e, t) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
    return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", Ta[this.pathName]), t;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + j.escape(this.alternate) + '"/>' : '<path d="' + j.escape(Ta[this.pathName]) + '"/>';
  }
}
class za {
  constructor(e) {
    this.attributes = void 0, this.attributes = e || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
    for (var r in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, r) && t.setAttribute(r, this.attributes[r]);
    return t;
  }
  toMarkup() {
    var e = "<line";
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + j.escape(this.attributes[t]) + '"');
    return e += "/>", e;
  }
}
function Ba(n) {
  if (n instanceof Tt)
    return n;
  throw new Error("Expected symbolNode but got " + String(n) + ".");
}
function Do(n) {
  if (n instanceof zr)
    return n;
  throw new Error("Expected span<HtmlDomNode> but got " + String(n) + ".");
}
var xo = {
  "accent-token": 1,
  mathord: 1,
  "op-token": 1,
  spacing: 1,
  textord: 1
}, xe = {
  math: {},
  text: {}
};
function s(n, e, t, r, a, i) {
  xe[n][a] = {
    font: e,
    group: t,
    replace: r
  }, i && r && (xe[n][r] = xe[n][a]);
}
var u = "math", M = "text", h = "main", _ = "ams", fe = "accent-token", O = "bin", Pe = "close", S0 = "inner", W = "mathord", Se = "op-token", Xe = "open", Br = "punct", b = "rel", jt = "spacing", w = "textord";
s(u, h, b, "≡", "\\equiv", !0);
s(u, h, b, "≺", "\\prec", !0);
s(u, h, b, "≻", "\\succ", !0);
s(u, h, b, "∼", "\\sim", !0);
s(u, h, b, "⊥", "\\perp");
s(u, h, b, "⪯", "\\preceq", !0);
s(u, h, b, "⪰", "\\succeq", !0);
s(u, h, b, "≃", "\\simeq", !0);
s(u, h, b, "∣", "\\mid", !0);
s(u, h, b, "≪", "\\ll", !0);
s(u, h, b, "≫", "\\gg", !0);
s(u, h, b, "≍", "\\asymp", !0);
s(u, h, b, "∥", "\\parallel");
s(u, h, b, "⋈", "\\bowtie", !0);
s(u, h, b, "⌣", "\\smile", !0);
s(u, h, b, "⊑", "\\sqsubseteq", !0);
s(u, h, b, "⊒", "\\sqsupseteq", !0);
s(u, h, b, "≐", "\\doteq", !0);
s(u, h, b, "⌢", "\\frown", !0);
s(u, h, b, "∋", "\\ni", !0);
s(u, h, b, "∝", "\\propto", !0);
s(u, h, b, "⊢", "\\vdash", !0);
s(u, h, b, "⊣", "\\dashv", !0);
s(u, h, b, "∋", "\\owns");
s(u, h, Br, ".", "\\ldotp");
s(u, h, Br, "⋅", "\\cdotp");
s(u, h, w, "#", "\\#");
s(M, h, w, "#", "\\#");
s(u, h, w, "&", "\\&");
s(M, h, w, "&", "\\&");
s(u, h, w, "ℵ", "\\aleph", !0);
s(u, h, w, "∀", "\\forall", !0);
s(u, h, w, "ℏ", "\\hbar", !0);
s(u, h, w, "∃", "\\exists", !0);
s(u, h, w, "∇", "\\nabla", !0);
s(u, h, w, "♭", "\\flat", !0);
s(u, h, w, "ℓ", "\\ell", !0);
s(u, h, w, "♮", "\\natural", !0);
s(u, h, w, "♣", "\\clubsuit", !0);
s(u, h, w, "℘", "\\wp", !0);
s(u, h, w, "♯", "\\sharp", !0);
s(u, h, w, "♢", "\\diamondsuit", !0);
s(u, h, w, "ℜ", "\\Re", !0);
s(u, h, w, "♡", "\\heartsuit", !0);
s(u, h, w, "ℑ", "\\Im", !0);
s(u, h, w, "♠", "\\spadesuit", !0);
s(u, h, w, "§", "\\S", !0);
s(M, h, w, "§", "\\S");
s(u, h, w, "¶", "\\P", !0);
s(M, h, w, "¶", "\\P");
s(u, h, w, "†", "\\dag");
s(M, h, w, "†", "\\dag");
s(M, h, w, "†", "\\textdagger");
s(u, h, w, "‡", "\\ddag");
s(M, h, w, "‡", "\\ddag");
s(M, h, w, "‡", "\\textdaggerdbl");
s(u, h, Pe, "⎱", "\\rmoustache", !0);
s(u, h, Xe, "⎰", "\\lmoustache", !0);
s(u, h, Pe, "⟯", "\\rgroup", !0);
s(u, h, Xe, "⟮", "\\lgroup", !0);
s(u, h, O, "∓", "\\mp", !0);
s(u, h, O, "⊖", "\\ominus", !0);
s(u, h, O, "⊎", "\\uplus", !0);
s(u, h, O, "⊓", "\\sqcap", !0);
s(u, h, O, "∗", "\\ast");
s(u, h, O, "⊔", "\\sqcup", !0);
s(u, h, O, "◯", "\\bigcirc", !0);
s(u, h, O, "∙", "\\bullet", !0);
s(u, h, O, "‡", "\\ddagger");
s(u, h, O, "≀", "\\wr", !0);
s(u, h, O, "⨿", "\\amalg");
s(u, h, O, "&", "\\And");
s(u, h, b, "⟵", "\\longleftarrow", !0);
s(u, h, b, "⇐", "\\Leftarrow", !0);
s(u, h, b, "⟸", "\\Longleftarrow", !0);
s(u, h, b, "⟶", "\\longrightarrow", !0);
s(u, h, b, "⇒", "\\Rightarrow", !0);
s(u, h, b, "⟹", "\\Longrightarrow", !0);
s(u, h, b, "↔", "\\leftrightarrow", !0);
s(u, h, b, "⟷", "\\longleftrightarrow", !0);
s(u, h, b, "⇔", "\\Leftrightarrow", !0);
s(u, h, b, "⟺", "\\Longleftrightarrow", !0);
s(u, h, b, "↦", "\\mapsto", !0);
s(u, h, b, "⟼", "\\longmapsto", !0);
s(u, h, b, "↗", "\\nearrow", !0);
s(u, h, b, "↩", "\\hookleftarrow", !0);
s(u, h, b, "↪", "\\hookrightarrow", !0);
s(u, h, b, "↘", "\\searrow", !0);
s(u, h, b, "↼", "\\leftharpoonup", !0);
s(u, h, b, "⇀", "\\rightharpoonup", !0);
s(u, h, b, "↙", "\\swarrow", !0);
s(u, h, b, "↽", "\\leftharpoondown", !0);
s(u, h, b, "⇁", "\\rightharpoondown", !0);
s(u, h, b, "↖", "\\nwarrow", !0);
s(u, h, b, "⇌", "\\rightleftharpoons", !0);
s(u, _, b, "≮", "\\nless", !0);
s(u, _, b, "", "\\@nleqslant");
s(u, _, b, "", "\\@nleqq");
s(u, _, b, "⪇", "\\lneq", !0);
s(u, _, b, "≨", "\\lneqq", !0);
s(u, _, b, "", "\\@lvertneqq");
s(u, _, b, "⋦", "\\lnsim", !0);
s(u, _, b, "⪉", "\\lnapprox", !0);
s(u, _, b, "⊀", "\\nprec", !0);
s(u, _, b, "⋠", "\\npreceq", !0);
s(u, _, b, "⋨", "\\precnsim", !0);
s(u, _, b, "⪹", "\\precnapprox", !0);
s(u, _, b, "≁", "\\nsim", !0);
s(u, _, b, "", "\\@nshortmid");
s(u, _, b, "∤", "\\nmid", !0);
s(u, _, b, "⊬", "\\nvdash", !0);
s(u, _, b, "⊭", "\\nvDash", !0);
s(u, _, b, "⋪", "\\ntriangleleft");
s(u, _, b, "⋬", "\\ntrianglelefteq", !0);
s(u, _, b, "⊊", "\\subsetneq", !0);
s(u, _, b, "", "\\@varsubsetneq");
s(u, _, b, "⫋", "\\subsetneqq", !0);
s(u, _, b, "", "\\@varsubsetneqq");
s(u, _, b, "≯", "\\ngtr", !0);
s(u, _, b, "", "\\@ngeqslant");
s(u, _, b, "", "\\@ngeqq");
s(u, _, b, "⪈", "\\gneq", !0);
s(u, _, b, "≩", "\\gneqq", !0);
s(u, _, b, "", "\\@gvertneqq");
s(u, _, b, "⋧", "\\gnsim", !0);
s(u, _, b, "⪊", "\\gnapprox", !0);
s(u, _, b, "⊁", "\\nsucc", !0);
s(u, _, b, "⋡", "\\nsucceq", !0);
s(u, _, b, "⋩", "\\succnsim", !0);
s(u, _, b, "⪺", "\\succnapprox", !0);
s(u, _, b, "≆", "\\ncong", !0);
s(u, _, b, "", "\\@nshortparallel");
s(u, _, b, "∦", "\\nparallel", !0);
s(u, _, b, "⊯", "\\nVDash", !0);
s(u, _, b, "⋫", "\\ntriangleright");
s(u, _, b, "⋭", "\\ntrianglerighteq", !0);
s(u, _, b, "", "\\@nsupseteqq");
s(u, _, b, "⊋", "\\supsetneq", !0);
s(u, _, b, "", "\\@varsupsetneq");
s(u, _, b, "⫌", "\\supsetneqq", !0);
s(u, _, b, "", "\\@varsupsetneqq");
s(u, _, b, "⊮", "\\nVdash", !0);
s(u, _, b, "⪵", "\\precneqq", !0);
s(u, _, b, "⪶", "\\succneqq", !0);
s(u, _, b, "", "\\@nsubseteqq");
s(u, _, O, "⊴", "\\unlhd");
s(u, _, O, "⊵", "\\unrhd");
s(u, _, b, "↚", "\\nleftarrow", !0);
s(u, _, b, "↛", "\\nrightarrow", !0);
s(u, _, b, "⇍", "\\nLeftarrow", !0);
s(u, _, b, "⇏", "\\nRightarrow", !0);
s(u, _, b, "↮", "\\nleftrightarrow", !0);
s(u, _, b, "⇎", "\\nLeftrightarrow", !0);
s(u, _, b, "△", "\\vartriangle");
s(u, _, w, "ℏ", "\\hslash");
s(u, _, w, "▽", "\\triangledown");
s(u, _, w, "◊", "\\lozenge");
s(u, _, w, "Ⓢ", "\\circledS");
s(u, _, w, "®", "\\circledR");
s(M, _, w, "®", "\\circledR");
s(u, _, w, "∡", "\\measuredangle", !0);
s(u, _, w, "∄", "\\nexists");
s(u, _, w, "℧", "\\mho");
s(u, _, w, "Ⅎ", "\\Finv", !0);
s(u, _, w, "⅁", "\\Game", !0);
s(u, _, w, "‵", "\\backprime");
s(u, _, w, "▲", "\\blacktriangle");
s(u, _, w, "▼", "\\blacktriangledown");
s(u, _, w, "■", "\\blacksquare");
s(u, _, w, "⧫", "\\blacklozenge");
s(u, _, w, "★", "\\bigstar");
s(u, _, w, "∢", "\\sphericalangle", !0);
s(u, _, w, "∁", "\\complement", !0);
s(u, _, w, "ð", "\\eth", !0);
s(M, h, w, "ð", "ð");
s(u, _, w, "╱", "\\diagup");
s(u, _, w, "╲", "\\diagdown");
s(u, _, w, "□", "\\square");
s(u, _, w, "□", "\\Box");
s(u, _, w, "◊", "\\Diamond");
s(u, _, w, "¥", "\\yen", !0);
s(M, _, w, "¥", "\\yen", !0);
s(u, _, w, "✓", "\\checkmark", !0);
s(M, _, w, "✓", "\\checkmark");
s(u, _, w, "ℶ", "\\beth", !0);
s(u, _, w, "ℸ", "\\daleth", !0);
s(u, _, w, "ℷ", "\\gimel", !0);
s(u, _, w, "ϝ", "\\digamma", !0);
s(u, _, w, "ϰ", "\\varkappa");
s(u, _, Xe, "┌", "\\@ulcorner", !0);
s(u, _, Pe, "┐", "\\@urcorner", !0);
s(u, _, Xe, "└", "\\@llcorner", !0);
s(u, _, Pe, "┘", "\\@lrcorner", !0);
s(u, _, b, "≦", "\\leqq", !0);
s(u, _, b, "⩽", "\\leqslant", !0);
s(u, _, b, "⪕", "\\eqslantless", !0);
s(u, _, b, "≲", "\\lesssim", !0);
s(u, _, b, "⪅", "\\lessapprox", !0);
s(u, _, b, "≊", "\\approxeq", !0);
s(u, _, O, "⋖", "\\lessdot");
s(u, _, b, "⋘", "\\lll", !0);
s(u, _, b, "≶", "\\lessgtr", !0);
s(u, _, b, "⋚", "\\lesseqgtr", !0);
s(u, _, b, "⪋", "\\lesseqqgtr", !0);
s(u, _, b, "≑", "\\doteqdot");
s(u, _, b, "≓", "\\risingdotseq", !0);
s(u, _, b, "≒", "\\fallingdotseq", !0);
s(u, _, b, "∽", "\\backsim", !0);
s(u, _, b, "⋍", "\\backsimeq", !0);
s(u, _, b, "⫅", "\\subseteqq", !0);
s(u, _, b, "⋐", "\\Subset", !0);
s(u, _, b, "⊏", "\\sqsubset", !0);
s(u, _, b, "≼", "\\preccurlyeq", !0);
s(u, _, b, "⋞", "\\curlyeqprec", !0);
s(u, _, b, "≾", "\\precsim", !0);
s(u, _, b, "⪷", "\\precapprox", !0);
s(u, _, b, "⊲", "\\vartriangleleft");
s(u, _, b, "⊴", "\\trianglelefteq");
s(u, _, b, "⊨", "\\vDash", !0);
s(u, _, b, "⊪", "\\Vvdash", !0);
s(u, _, b, "⌣", "\\smallsmile");
s(u, _, b, "⌢", "\\smallfrown");
s(u, _, b, "≏", "\\bumpeq", !0);
s(u, _, b, "≎", "\\Bumpeq", !0);
s(u, _, b, "≧", "\\geqq", !0);
s(u, _, b, "⩾", "\\geqslant", !0);
s(u, _, b, "⪖", "\\eqslantgtr", !0);
s(u, _, b, "≳", "\\gtrsim", !0);
s(u, _, b, "⪆", "\\gtrapprox", !0);
s(u, _, O, "⋗", "\\gtrdot");
s(u, _, b, "⋙", "\\ggg", !0);
s(u, _, b, "≷", "\\gtrless", !0);
s(u, _, b, "⋛", "\\gtreqless", !0);
s(u, _, b, "⪌", "\\gtreqqless", !0);
s(u, _, b, "≖", "\\eqcirc", !0);
s(u, _, b, "≗", "\\circeq", !0);
s(u, _, b, "≜", "\\triangleq", !0);
s(u, _, b, "∼", "\\thicksim");
s(u, _, b, "≈", "\\thickapprox");
s(u, _, b, "⫆", "\\supseteqq", !0);
s(u, _, b, "⋑", "\\Supset", !0);
s(u, _, b, "⊐", "\\sqsupset", !0);
s(u, _, b, "≽", "\\succcurlyeq", !0);
s(u, _, b, "⋟", "\\curlyeqsucc", !0);
s(u, _, b, "≿", "\\succsim", !0);
s(u, _, b, "⪸", "\\succapprox", !0);
s(u, _, b, "⊳", "\\vartriangleright");
s(u, _, b, "⊵", "\\trianglerighteq");
s(u, _, b, "⊩", "\\Vdash", !0);
s(u, _, b, "∣", "\\shortmid");
s(u, _, b, "∥", "\\shortparallel");
s(u, _, b, "≬", "\\between", !0);
s(u, _, b, "⋔", "\\pitchfork", !0);
s(u, _, b, "∝", "\\varpropto");
s(u, _, b, "◀", "\\blacktriangleleft");
s(u, _, b, "∴", "\\therefore", !0);
s(u, _, b, "∍", "\\backepsilon");
s(u, _, b, "▶", "\\blacktriangleright");
s(u, _, b, "∵", "\\because", !0);
s(u, _, b, "⋘", "\\llless");
s(u, _, b, "⋙", "\\gggtr");
s(u, _, O, "⊲", "\\lhd");
s(u, _, O, "⊳", "\\rhd");
s(u, _, b, "≂", "\\eqsim", !0);
s(u, h, b, "⋈", "\\Join");
s(u, _, b, "≑", "\\Doteq", !0);
s(u, _, O, "∔", "\\dotplus", !0);
s(u, _, O, "∖", "\\smallsetminus");
s(u, _, O, "⋒", "\\Cap", !0);
s(u, _, O, "⋓", "\\Cup", !0);
s(u, _, O, "⩞", "\\doublebarwedge", !0);
s(u, _, O, "⊟", "\\boxminus", !0);
s(u, _, O, "⊞", "\\boxplus", !0);
s(u, _, O, "⋇", "\\divideontimes", !0);
s(u, _, O, "⋉", "\\ltimes", !0);
s(u, _, O, "⋊", "\\rtimes", !0);
s(u, _, O, "⋋", "\\leftthreetimes", !0);
s(u, _, O, "⋌", "\\rightthreetimes", !0);
s(u, _, O, "⋏", "\\curlywedge", !0);
s(u, _, O, "⋎", "\\curlyvee", !0);
s(u, _, O, "⊝", "\\circleddash", !0);
s(u, _, O, "⊛", "\\circledast", !0);
s(u, _, O, "⋅", "\\centerdot");
s(u, _, O, "⊺", "\\intercal", !0);
s(u, _, O, "⋒", "\\doublecap");
s(u, _, O, "⋓", "\\doublecup");
s(u, _, O, "⊠", "\\boxtimes", !0);
s(u, _, b, "⇢", "\\dashrightarrow", !0);
s(u, _, b, "⇠", "\\dashleftarrow", !0);
s(u, _, b, "⇇", "\\leftleftarrows", !0);
s(u, _, b, "⇆", "\\leftrightarrows", !0);
s(u, _, b, "⇚", "\\Lleftarrow", !0);
s(u, _, b, "↞", "\\twoheadleftarrow", !0);
s(u, _, b, "↢", "\\leftarrowtail", !0);
s(u, _, b, "↫", "\\looparrowleft", !0);
s(u, _, b, "⇋", "\\leftrightharpoons", !0);
s(u, _, b, "↶", "\\curvearrowleft", !0);
s(u, _, b, "↺", "\\circlearrowleft", !0);
s(u, _, b, "↰", "\\Lsh", !0);
s(u, _, b, "⇈", "\\upuparrows", !0);
s(u, _, b, "↿", "\\upharpoonleft", !0);
s(u, _, b, "⇃", "\\downharpoonleft", !0);
s(u, h, b, "⊶", "\\origof", !0);
s(u, h, b, "⊷", "\\imageof", !0);
s(u, _, b, "⊸", "\\multimap", !0);
s(u, _, b, "↭", "\\leftrightsquigarrow", !0);
s(u, _, b, "⇉", "\\rightrightarrows", !0);
s(u, _, b, "⇄", "\\rightleftarrows", !0);
s(u, _, b, "↠", "\\twoheadrightarrow", !0);
s(u, _, b, "↣", "\\rightarrowtail", !0);
s(u, _, b, "↬", "\\looparrowright", !0);
s(u, _, b, "↷", "\\curvearrowright", !0);
s(u, _, b, "↻", "\\circlearrowright", !0);
s(u, _, b, "↱", "\\Rsh", !0);
s(u, _, b, "⇊", "\\downdownarrows", !0);
s(u, _, b, "↾", "\\upharpoonright", !0);
s(u, _, b, "⇂", "\\downharpoonright", !0);
s(u, _, b, "⇝", "\\rightsquigarrow", !0);
s(u, _, b, "⇝", "\\leadsto");
s(u, _, b, "⇛", "\\Rrightarrow", !0);
s(u, _, b, "↾", "\\restriction");
s(u, h, w, "‘", "`");
s(u, h, w, "$", "\\$");
s(M, h, w, "$", "\\$");
s(M, h, w, "$", "\\textdollar");
s(u, h, w, "%", "\\%");
s(M, h, w, "%", "\\%");
s(u, h, w, "_", "\\_");
s(M, h, w, "_", "\\_");
s(M, h, w, "_", "\\textunderscore");
s(u, h, w, "∠", "\\angle", !0);
s(u, h, w, "∞", "\\infty", !0);
s(u, h, w, "′", "\\prime");
s(u, h, w, "△", "\\triangle");
s(u, h, w, "Γ", "\\Gamma", !0);
s(u, h, w, "Δ", "\\Delta", !0);
s(u, h, w, "Θ", "\\Theta", !0);
s(u, h, w, "Λ", "\\Lambda", !0);
s(u, h, w, "Ξ", "\\Xi", !0);
s(u, h, w, "Π", "\\Pi", !0);
s(u, h, w, "Σ", "\\Sigma", !0);
s(u, h, w, "Υ", "\\Upsilon", !0);
s(u, h, w, "Φ", "\\Phi", !0);
s(u, h, w, "Ψ", "\\Psi", !0);
s(u, h, w, "Ω", "\\Omega", !0);
s(u, h, w, "A", "Α");
s(u, h, w, "B", "Β");
s(u, h, w, "E", "Ε");
s(u, h, w, "Z", "Ζ");
s(u, h, w, "H", "Η");
s(u, h, w, "I", "Ι");
s(u, h, w, "K", "Κ");
s(u, h, w, "M", "Μ");
s(u, h, w, "N", "Ν");
s(u, h, w, "O", "Ο");
s(u, h, w, "P", "Ρ");
s(u, h, w, "T", "Τ");
s(u, h, w, "X", "Χ");
s(u, h, w, "¬", "\\neg", !0);
s(u, h, w, "¬", "\\lnot");
s(u, h, w, "⊤", "\\top");
s(u, h, w, "⊥", "\\bot");
s(u, h, w, "∅", "\\emptyset");
s(u, _, w, "∅", "\\varnothing");
s(u, h, W, "α", "\\alpha", !0);
s(u, h, W, "β", "\\beta", !0);
s(u, h, W, "γ", "\\gamma", !0);
s(u, h, W, "δ", "\\delta", !0);
s(u, h, W, "ϵ", "\\epsilon", !0);
s(u, h, W, "ζ", "\\zeta", !0);
s(u, h, W, "η", "\\eta", !0);
s(u, h, W, "θ", "\\theta", !0);
s(u, h, W, "ι", "\\iota", !0);
s(u, h, W, "κ", "\\kappa", !0);
s(u, h, W, "λ", "\\lambda", !0);
s(u, h, W, "μ", "\\mu", !0);
s(u, h, W, "ν", "\\nu", !0);
s(u, h, W, "ξ", "\\xi", !0);
s(u, h, W, "ο", "\\omicron", !0);
s(u, h, W, "π", "\\pi", !0);
s(u, h, W, "ρ", "\\rho", !0);
s(u, h, W, "σ", "\\sigma", !0);
s(u, h, W, "τ", "\\tau", !0);
s(u, h, W, "υ", "\\upsilon", !0);
s(u, h, W, "ϕ", "\\phi", !0);
s(u, h, W, "χ", "\\chi", !0);
s(u, h, W, "ψ", "\\psi", !0);
s(u, h, W, "ω", "\\omega", !0);
s(u, h, W, "ε", "\\varepsilon", !0);
s(u, h, W, "ϑ", "\\vartheta", !0);
s(u, h, W, "ϖ", "\\varpi", !0);
s(u, h, W, "ϱ", "\\varrho", !0);
s(u, h, W, "ς", "\\varsigma", !0);
s(u, h, W, "φ", "\\varphi", !0);
s(u, h, O, "∗", "*", !0);
s(u, h, O, "+", "+");
s(u, h, O, "−", "-", !0);
s(u, h, O, "⋅", "\\cdot", !0);
s(u, h, O, "∘", "\\circ", !0);
s(u, h, O, "÷", "\\div", !0);
s(u, h, O, "±", "\\pm", !0);
s(u, h, O, "×", "\\times", !0);
s(u, h, O, "∩", "\\cap", !0);
s(u, h, O, "∪", "\\cup", !0);
s(u, h, O, "∖", "\\setminus", !0);
s(u, h, O, "∧", "\\land");
s(u, h, O, "∨", "\\lor");
s(u, h, O, "∧", "\\wedge", !0);
s(u, h, O, "∨", "\\vee", !0);
s(u, h, w, "√", "\\surd");
s(u, h, Xe, "⟨", "\\langle", !0);
s(u, h, Xe, "∣", "\\lvert");
s(u, h, Xe, "∥", "\\lVert");
s(u, h, Pe, "?", "?");
s(u, h, Pe, "!", "!");
s(u, h, Pe, "⟩", "\\rangle", !0);
s(u, h, Pe, "∣", "\\rvert");
s(u, h, Pe, "∥", "\\rVert");
s(u, h, b, "=", "=");
s(u, h, b, ":", ":");
s(u, h, b, "≈", "\\approx", !0);
s(u, h, b, "≅", "\\cong", !0);
s(u, h, b, "≥", "\\ge");
s(u, h, b, "≥", "\\geq", !0);
s(u, h, b, "←", "\\gets");
s(u, h, b, ">", "\\gt", !0);
s(u, h, b, "∈", "\\in", !0);
s(u, h, b, "", "\\@not");
s(u, h, b, "⊂", "\\subset", !0);
s(u, h, b, "⊃", "\\supset", !0);
s(u, h, b, "⊆", "\\subseteq", !0);
s(u, h, b, "⊇", "\\supseteq", !0);
s(u, _, b, "⊈", "\\nsubseteq", !0);
s(u, _, b, "⊉", "\\nsupseteq", !0);
s(u, h, b, "⊨", "\\models");
s(u, h, b, "←", "\\leftarrow", !0);
s(u, h, b, "≤", "\\le");
s(u, h, b, "≤", "\\leq", !0);
s(u, h, b, "<", "\\lt", !0);
s(u, h, b, "→", "\\rightarrow", !0);
s(u, h, b, "→", "\\to");
s(u, _, b, "≱", "\\ngeq", !0);
s(u, _, b, "≰", "\\nleq", !0);
s(u, h, jt, " ", "\\ ");
s(u, h, jt, " ", "\\space");
s(u, h, jt, " ", "\\nobreakspace");
s(M, h, jt, " ", "\\ ");
s(M, h, jt, " ", " ");
s(M, h, jt, " ", "\\space");
s(M, h, jt, " ", "\\nobreakspace");
s(u, h, jt, null, "\\nobreak");
s(u, h, jt, null, "\\allowbreak");
s(u, h, Br, ",", ",");
s(u, h, Br, ";", ";");
s(u, _, O, "⊼", "\\barwedge", !0);
s(u, _, O, "⊻", "\\veebar", !0);
s(u, h, O, "⊙", "\\odot", !0);
s(u, h, O, "⊕", "\\oplus", !0);
s(u, h, O, "⊗", "\\otimes", !0);
s(u, h, w, "∂", "\\partial", !0);
s(u, h, O, "⊘", "\\oslash", !0);
s(u, _, O, "⊚", "\\circledcirc", !0);
s(u, _, O, "⊡", "\\boxdot", !0);
s(u, h, O, "△", "\\bigtriangleup");
s(u, h, O, "▽", "\\bigtriangledown");
s(u, h, O, "†", "\\dagger");
s(u, h, O, "⋄", "\\diamond");
s(u, h, O, "⋆", "\\star");
s(u, h, O, "◃", "\\triangleleft");
s(u, h, O, "▹", "\\triangleright");
s(u, h, Xe, "{", "\\{");
s(M, h, w, "{", "\\{");
s(M, h, w, "{", "\\textbraceleft");
s(u, h, Pe, "}", "\\}");
s(M, h, w, "}", "\\}");
s(M, h, w, "}", "\\textbraceright");
s(u, h, Xe, "{", "\\lbrace");
s(u, h, Pe, "}", "\\rbrace");
s(u, h, Xe, "[", "\\lbrack", !0);
s(M, h, w, "[", "\\lbrack", !0);
s(u, h, Pe, "]", "\\rbrack", !0);
s(M, h, w, "]", "\\rbrack", !0);
s(u, h, Xe, "(", "\\lparen", !0);
s(u, h, Pe, ")", "\\rparen", !0);
s(M, h, w, "<", "\\textless", !0);
s(M, h, w, ">", "\\textgreater", !0);
s(u, h, Xe, "⌊", "\\lfloor", !0);
s(u, h, Pe, "⌋", "\\rfloor", !0);
s(u, h, Xe, "⌈", "\\lceil", !0);
s(u, h, Pe, "⌉", "\\rceil", !0);
s(u, h, w, "\\", "\\backslash");
s(u, h, w, "∣", "|");
s(u, h, w, "∣", "\\vert");
s(M, h, w, "|", "\\textbar", !0);
s(u, h, w, "∥", "\\|");
s(u, h, w, "∥", "\\Vert");
s(M, h, w, "∥", "\\textbardbl");
s(M, h, w, "~", "\\textasciitilde");
s(M, h, w, "\\", "\\textbackslash");
s(M, h, w, "^", "\\textasciicircum");
s(u, h, b, "↑", "\\uparrow", !0);
s(u, h, b, "⇑", "\\Uparrow", !0);
s(u, h, b, "↓", "\\downarrow", !0);
s(u, h, b, "⇓", "\\Downarrow", !0);
s(u, h, b, "↕", "\\updownarrow", !0);
s(u, h, b, "⇕", "\\Updownarrow", !0);
s(u, h, Se, "∐", "\\coprod");
s(u, h, Se, "⋁", "\\bigvee");
s(u, h, Se, "⋀", "\\bigwedge");
s(u, h, Se, "⨄", "\\biguplus");
s(u, h, Se, "⋂", "\\bigcap");
s(u, h, Se, "⋃", "\\bigcup");
s(u, h, Se, "∫", "\\int");
s(u, h, Se, "∫", "\\intop");
s(u, h, Se, "∬", "\\iint");
s(u, h, Se, "∭", "\\iiint");
s(u, h, Se, "∏", "\\prod");
s(u, h, Se, "∑", "\\sum");
s(u, h, Se, "⨂", "\\bigotimes");
s(u, h, Se, "⨁", "\\bigoplus");
s(u, h, Se, "⨀", "\\bigodot");
s(u, h, Se, "∮", "\\oint");
s(u, h, Se, "∯", "\\oiint");
s(u, h, Se, "∰", "\\oiiint");
s(u, h, Se, "⨆", "\\bigsqcup");
s(u, h, Se, "∫", "\\smallint");
s(M, h, S0, "…", "\\textellipsis");
s(u, h, S0, "…", "\\mathellipsis");
s(M, h, S0, "…", "\\ldots", !0);
s(u, h, S0, "…", "\\ldots", !0);
s(u, h, S0, "⋯", "\\@cdots", !0);
s(u, h, S0, "⋱", "\\ddots", !0);
s(u, h, w, "⋮", "\\varvdots");
s(M, h, w, "⋮", "\\varvdots");
s(u, h, fe, "ˊ", "\\acute");
s(u, h, fe, "ˋ", "\\grave");
s(u, h, fe, "¨", "\\ddot");
s(u, h, fe, "~", "\\tilde");
s(u, h, fe, "ˉ", "\\bar");
s(u, h, fe, "˘", "\\breve");
s(u, h, fe, "ˇ", "\\check");
s(u, h, fe, "^", "\\hat");
s(u, h, fe, "⃗", "\\vec");
s(u, h, fe, "˙", "\\dot");
s(u, h, fe, "˚", "\\mathring");
s(u, h, W, "", "\\@imath");
s(u, h, W, "", "\\@jmath");
s(u, h, w, "ı", "ı");
s(u, h, w, "ȷ", "ȷ");
s(M, h, w, "ı", "\\i", !0);
s(M, h, w, "ȷ", "\\j", !0);
s(M, h, w, "ß", "\\ss", !0);
s(M, h, w, "æ", "\\ae", !0);
s(M, h, w, "œ", "\\oe", !0);
s(M, h, w, "ø", "\\o", !0);
s(M, h, w, "Æ", "\\AE", !0);
s(M, h, w, "Œ", "\\OE", !0);
s(M, h, w, "Ø", "\\O", !0);
s(M, h, fe, "ˊ", "\\'");
s(M, h, fe, "ˋ", "\\`");
s(M, h, fe, "ˆ", "\\^");
s(M, h, fe, "˜", "\\~");
s(M, h, fe, "ˉ", "\\=");
s(M, h, fe, "˘", "\\u");
s(M, h, fe, "˙", "\\.");
s(M, h, fe, "¸", "\\c");
s(M, h, fe, "˚", "\\r");
s(M, h, fe, "ˇ", "\\v");
s(M, h, fe, "¨", '\\"');
s(M, h, fe, "˝", "\\H");
s(M, h, fe, "◯", "\\textcircled");
var il = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
s(M, h, w, "–", "--", !0);
s(M, h, w, "–", "\\textendash");
s(M, h, w, "—", "---", !0);
s(M, h, w, "—", "\\textemdash");
s(M, h, w, "‘", "`", !0);
s(M, h, w, "‘", "\\textquoteleft");
s(M, h, w, "’", "'", !0);
s(M, h, w, "’", "\\textquoteright");
s(M, h, w, "“", "``", !0);
s(M, h, w, "“", "\\textquotedblleft");
s(M, h, w, "”", "''", !0);
s(M, h, w, "”", "\\textquotedblright");
s(u, h, w, "°", "\\degree", !0);
s(M, h, w, "°", "\\degree");
s(M, h, w, "°", "\\textdegree", !0);
s(u, h, w, "£", "\\pounds");
s(u, h, w, "£", "\\mathsterling", !0);
s(M, h, w, "£", "\\pounds");
s(M, h, w, "£", "\\textsterling", !0);
s(u, _, w, "✠", "\\maltese");
s(M, _, w, "✠", "\\maltese");
var qa = '0123456789/@."';
for (var jr = 0; jr < qa.length; jr++) {
  var Ra = qa.charAt(jr);
  s(u, h, w, Ra, Ra);
}
var Na = '0123456789!@*()-=+";:?/.,';
for (var Xr = 0; Xr < Na.length; Xr++) {
  var Ia = Na.charAt(Xr);
  s(M, h, w, Ia, Ia);
}
var Sr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var Zr = 0; Zr < Sr.length; Zr++) {
  var rr = Sr.charAt(Zr);
  s(u, h, W, rr, rr), s(M, h, w, rr, rr);
}
s(u, _, w, "C", "ℂ");
s(M, _, w, "C", "ℂ");
s(u, _, w, "H", "ℍ");
s(M, _, w, "H", "ℍ");
s(u, _, w, "N", "ℕ");
s(M, _, w, "N", "ℕ");
s(u, _, w, "P", "ℙ");
s(M, _, w, "P", "ℙ");
s(u, _, w, "Q", "ℚ");
s(M, _, w, "Q", "ℚ");
s(u, _, w, "R", "ℝ");
s(M, _, w, "R", "ℝ");
s(u, _, w, "Z", "ℤ");
s(M, _, w, "Z", "ℤ");
s(u, h, W, "h", "ℎ");
s(M, h, W, "h", "ℎ");
var Z = "";
for (var Re = 0; Re < Sr.length; Re++) {
  var be = Sr.charAt(Re);
  Z = String.fromCharCode(55349, 56320 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Z = String.fromCharCode(55349, 56372 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Z = String.fromCharCode(55349, 56424 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Z = String.fromCharCode(55349, 56580 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Z = String.fromCharCode(55349, 56684 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Z = String.fromCharCode(55349, 56736 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Z = String.fromCharCode(55349, 56788 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Z = String.fromCharCode(55349, 56840 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Z = String.fromCharCode(55349, 56944 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Re < 26 && (Z = String.fromCharCode(55349, 56632 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z), Z = String.fromCharCode(55349, 56476 + Re), s(u, h, W, be, Z), s(M, h, w, be, Z));
}
Z = "𝕜";
s(u, h, W, "k", Z);
s(M, h, w, "k", Z);
for (var n0 = 0; n0 < 10; n0++) {
  var Zt = n0.toString();
  Z = String.fromCharCode(55349, 57294 + n0), s(u, h, W, Zt, Z), s(M, h, w, Zt, Z), Z = String.fromCharCode(55349, 57314 + n0), s(u, h, W, Zt, Z), s(M, h, w, Zt, Z), Z = String.fromCharCode(55349, 57324 + n0), s(u, h, W, Zt, Z), s(M, h, w, Zt, Z), Z = String.fromCharCode(55349, 57334 + n0), s(u, h, W, Zt, Z), s(M, h, w, Zt, Z);
}
var La = "ÐÞþ";
for (var Kr = 0; Kr < La.length; Kr++) {
  var nr = La.charAt(Kr);
  s(u, h, W, nr, nr), s(M, h, w, nr, nr);
}
var ar = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
], Oa = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
], So = function(e, t) {
  var r = e.charCodeAt(0), a = e.charCodeAt(1), i = (r - 55296) * 1024 + (a - 56320) + 65536, l = t === "math" ? 0 : 1;
  if (119808 <= i && i < 120484) {
    var o = Math.floor((i - 119808) / 26);
    return [ar[o][2], ar[o][l]];
  } else if (120782 <= i && i <= 120831) {
    var c = Math.floor((i - 120782) / 10);
    return [Oa[c][2], Oa[c][l]];
  } else {
    if (i === 120485 || i === 120486)
      return [ar[0][2], ar[0][l]];
    if (120486 < i && i < 120782)
      return ["", ""];
    throw new G("Unsupported character: " + e);
  }
}, qr = function(e, t, r) {
  return xe[r][e] && xe[r][e].replace && (e = xe[r][e].replace), {
    value: e,
    metrics: Nn(e, t, r)
  };
}, pt = function(e, t, r, a, i) {
  var l = qr(e, t, r), o = l.metrics;
  e = l.value;
  var c;
  if (o) {
    var m = o.italic;
    (r === "text" || a && a.font === "mathit") && (m = 0), c = new Tt(e, o.height, o.depth, m, o.skew, o.width, i);
  } else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + r + "'")), c = new Tt(e, 0, 0, 0, 0, 0, i);
  if (a) {
    c.maxFontSize = a.sizeMultiplier, a.style.isTight() && c.classes.push("mtight");
    var d = a.getColor();
    d && (c.style.color = d);
  }
  return c;
}, Ao = function(e, t, r, a) {
  return a === void 0 && (a = []), r.font === "boldsymbol" && qr(e, "Main-Bold", t).metrics ? pt(e, "Main-Bold", t, r, a.concat(["mathbf"])) : e === "\\" || xe[t][e].font === "main" ? pt(e, "Main-Regular", t, r, a) : pt(e, "AMS-Regular", t, r, a.concat(["amsrm"]));
}, $o = function(e, t, r, a, i) {
  return i !== "textord" && qr(e, "Math-BoldItalic", t).metrics ? {
    fontName: "Math-BoldItalic",
    fontClass: "boldsymbol"
  } : {
    fontName: "Main-Bold",
    fontClass: "mathbf"
  };
}, Fo = function(e, t, r) {
  var a = e.mode, i = e.text, l = ["mord"], o = a === "math" || a === "text" && t.font, c = o ? t.font : t.fontFamily, m = "", d = "";
  if (i.charCodeAt(0) === 55349 && ([m, d] = So(i, a)), m.length > 0)
    return pt(i, m, a, t, l.concat(d));
  if (c) {
    var p, y;
    if (c === "boldsymbol") {
      var v = $o(i, a, t, l, r);
      p = v.fontName, y = [v.fontClass];
    } else o ? (p = ol[c].fontName, y = [c]) : (p = ir(c, t.fontWeight, t.fontShape), y = [c, t.fontWeight, t.fontShape]);
    if (qr(i, p, a).metrics)
      return pt(i, p, a, t, l.concat(y));
    if (il.hasOwnProperty(i) && p.slice(0, 10) === "Typewriter") {
      for (var x = [], S = 0; S < i.length; S++)
        x.push(pt(i[S], p, a, t, l.concat(y)));
      return sl(x);
    }
  }
  if (r === "mathord")
    return pt(i, "Math-Italic", a, t, l.concat(["mathnormal"]));
  if (r === "textord") {
    var F = xe[a][i] && xe[a][i].font;
    if (F === "ams") {
      var E = ir("amsrm", t.fontWeight, t.fontShape);
      return pt(i, E, a, t, l.concat("amsrm", t.fontWeight, t.fontShape));
    } else if (F === "main" || !F) {
      var D = ir("textrm", t.fontWeight, t.fontShape);
      return pt(i, D, a, t, l.concat(t.fontWeight, t.fontShape));
    } else {
      var g = ir(F, t.fontWeight, t.fontShape);
      return pt(i, g, a, t, l.concat(g, t.fontWeight, t.fontShape));
    }
  } else
    throw new Error("unexpected type: " + r + " in makeOrd");
}, Co = (n, e) => {
  if (Jt(n.classes) !== Jt(e.classes) || n.skew !== e.skew || n.maxFontSize !== e.maxFontSize)
    return !1;
  if (n.classes.length === 1) {
    var t = n.classes[0];
    if (t === "mbin" || t === "mord")
      return !1;
  }
  for (var r in n.style)
    if (n.style.hasOwnProperty(r) && n.style[r] !== e.style[r])
      return !1;
  for (var a in e.style)
    if (e.style.hasOwnProperty(a) && n.style[a] !== e.style[a])
      return !1;
  return !0;
}, Eo = (n) => {
  for (var e = 0; e < n.length - 1; e++) {
    var t = n[e], r = n[e + 1];
    t instanceof Tt && r instanceof Tt && Co(t, r) && (t.text += r.text, t.height = Math.max(t.height, r.height), t.depth = Math.max(t.depth, r.depth), t.italic = r.italic, n.splice(e + 1, 1), e--);
  }
  return n;
}, In = function(e) {
  for (var t = 0, r = 0, a = 0, i = 0; i < e.children.length; i++) {
    var l = e.children[i];
    l.height > t && (t = l.height), l.depth > r && (r = l.depth), l.maxFontSize > a && (a = l.maxFontSize);
  }
  e.height = t, e.depth = r, e.maxFontSize = a;
}, Ve = function(e, t, r, a) {
  var i = new zr(e, t, r, a);
  return In(i), i;
}, ll = (n, e, t, r) => new zr(n, e, t, r), To = function(e, t, r) {
  var a = Ve([e], [], t);
  return a.height = Math.max(r || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), a.style.borderBottomWidth = I(a.height), a.maxFontSize = 1, a;
}, Mo = function(e, t, r, a) {
  var i = new al(e, t, r, a);
  return In(i), i;
}, sl = function(e) {
  var t = new Y0(e);
  return In(t), t;
}, zo = function(e, t) {
  return e instanceof Y0 ? Ve([], [e], t) : e;
}, Bo = function(e) {
  if (e.positionType === "individualShift") {
    for (var t = e.children, r = [t[0]], a = -t[0].shift - t[0].elem.depth, i = a, l = 1; l < t.length; l++) {
      var o = -t[l].shift - i - t[l].elem.depth, c = o - (t[l - 1].elem.height + t[l - 1].elem.depth);
      i = i + o, r.push({
        type: "kern",
        size: c
      }), r.push(t[l]);
    }
    return {
      children: r,
      depth: a
    };
  }
  var m;
  if (e.positionType === "top") {
    for (var d = e.positionData, p = 0; p < e.children.length; p++) {
      var y = e.children[p];
      d -= y.type === "kern" ? y.size : y.elem.height + y.elem.depth;
    }
    m = d;
  } else if (e.positionType === "bottom")
    m = -e.positionData;
  else {
    var v = e.children[0];
    if (v.type !== "elem")
      throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
      m = -v.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
      m = -v.elem.depth;
    else
      throw new Error("Invalid positionType " + e.positionType + ".");
  }
  return {
    children: e.children,
    depth: m
  };
}, qo = function(e, t) {
  for (var {
    children: r,
    depth: a
  } = Bo(e), i = 0, l = 0; l < r.length; l++) {
    var o = r[l];
    if (o.type === "elem") {
      var c = o.elem;
      i = Math.max(i, c.maxFontSize, c.height);
    }
  }
  i += 2;
  var m = Ve(["pstrut"], []);
  m.style.height = I(i);
  for (var d = [], p = a, y = a, v = a, x = 0; x < r.length; x++) {
    var S = r[x];
    if (S.type === "kern")
      v += S.size;
    else {
      var F = S.elem, E = S.wrapperClasses || [], D = S.wrapperStyle || {}, g = Ve(E, [m, F], void 0, D);
      g.style.top = I(-i - v - F.depth), S.marginLeft && (g.style.marginLeft = S.marginLeft), S.marginRight && (g.style.marginRight = S.marginRight), d.push(g), v += F.height + F.depth;
    }
    p = Math.min(p, v), y = Math.max(y, v);
  }
  var A = Ve(["vlist"], d);
  A.style.height = I(y);
  var C;
  if (p < 0) {
    var T = Ve([], []), z = Ve(["vlist"], [T]);
    z.style.height = I(-p);
    var P = Ve(["vlist-s"], [new Tt("​")]);
    C = [Ve(["vlist-r"], [A, P]), Ve(["vlist-r"], [z])];
  } else
    C = [Ve(["vlist-r"], [A])];
  var R = Ve(["vlist-t"], C);
  return C.length === 2 && R.classes.push("vlist-t2"), R.height = y, R.depth = -p, R;
}, Ro = (n, e) => {
  var t = Ve(["mspace"], [], e), r = ge(n, e);
  return t.style.marginRight = I(r), t;
}, ir = function(e, t, r) {
  var a = "";
  switch (e) {
    case "amsrm":
      a = "AMS";
      break;
    case "textrm":
      a = "Main";
      break;
    case "textsf":
      a = "SansSerif";
      break;
    case "texttt":
      a = "Typewriter";
      break;
    default:
      a = e;
  }
  var i;
  return t === "textbf" && r === "textit" ? i = "BoldItalic" : t === "textbf" ? i = "Bold" : t === "textit" ? i = "Italic" : i = "Regular", a + "-" + i;
}, ol = {
  // styles
  mathbf: {
    variant: "bold",
    fontName: "Main-Bold"
  },
  mathrm: {
    variant: "normal",
    fontName: "Main-Regular"
  },
  textit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathnormal: {
    variant: "italic",
    fontName: "Math-Italic"
  },
  mathsfit: {
    variant: "sans-serif-italic",
    fontName: "SansSerif-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  mathbb: {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  mathcal: {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  mathfrak: {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  mathscr: {
    variant: "script",
    fontName: "Script-Regular"
  },
  mathsf: {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  mathtt: {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
}, ul = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
}, No = function(e, t) {
  var [r, a, i] = ul[e], l = new l0(r), o = new e0([l], {
    width: I(a),
    height: I(i),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + I(a),
    viewBox: "0 0 " + 1e3 * a + " " + 1e3 * i,
    preserveAspectRatio: "xMinYMin"
  }), c = ll(["overlay"], [o], t);
  return c.height = i, c.style.height = I(i), c.style.width = I(a), c;
}, $ = {
  fontMap: ol,
  makeSymbol: pt,
  mathsym: Ao,
  makeSpan: Ve,
  makeSvgSpan: ll,
  makeLineSpan: To,
  makeAnchor: Mo,
  makeFragment: sl,
  wrapFragment: zo,
  makeVList: qo,
  makeOrd: Fo,
  makeGlue: Ro,
  staticSvg: No,
  svgData: ul,
  tryCombineChars: Eo
}, pe = {
  number: 3,
  unit: "mu"
}, a0 = {
  number: 4,
  unit: "mu"
}, Pt = {
  number: 5,
  unit: "mu"
}, Io = {
  mord: {
    mop: pe,
    mbin: a0,
    mrel: Pt,
    minner: pe
  },
  mop: {
    mord: pe,
    mop: pe,
    mrel: Pt,
    minner: pe
  },
  mbin: {
    mord: a0,
    mop: a0,
    mopen: a0,
    minner: a0
  },
  mrel: {
    mord: Pt,
    mop: Pt,
    mopen: Pt,
    minner: Pt
  },
  mopen: {},
  mclose: {
    mop: pe,
    mbin: a0,
    mrel: Pt,
    minner: pe
  },
  mpunct: {
    mord: pe,
    mop: pe,
    mrel: Pt,
    mopen: pe,
    mclose: pe,
    mpunct: pe,
    minner: pe
  },
  minner: {
    mord: pe,
    mop: pe,
    mbin: a0,
    mrel: Pt,
    mopen: pe,
    mpunct: pe,
    minner: pe
  }
}, Lo = {
  mord: {
    mop: pe
  },
  mop: {
    mord: pe,
    mop: pe
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: pe
  },
  mpunct: {},
  minner: {
    mop: pe
  }
}, cl = {}, Ar = {}, $r = {};
function L(n) {
  for (var {
    type: e,
    names: t,
    props: r,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = n, o = {
    type: e,
    numArgs: r.numArgs,
    argTypes: r.argTypes,
    allowedInArgument: !!r.allowedInArgument,
    allowedInText: !!r.allowedInText,
    allowedInMath: r.allowedInMath === void 0 ? !0 : r.allowedInMath,
    numOptionalArgs: r.numOptionalArgs || 0,
    infix: !!r.infix,
    primitive: !!r.primitive,
    handler: a
  }, c = 0; c < t.length; ++c)
    cl[t[c]] = o;
  e && (i && (Ar[e] = i), l && ($r[e] = l));
}
function u0(n) {
  var {
    type: e,
    htmlBuilder: t,
    mathmlBuilder: r
  } = n;
  L({
    type: e,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: t,
    mathmlBuilder: r
  });
}
var Fr = function(e) {
  return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, De = function(e) {
  return e.type === "ordgroup" ? e.body : [e];
}, x0 = $.makeSpan, Oo = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], Po = ["rightmost", "mrel", "mclose", "mpunct"], Ho = {
  display: X.DISPLAY,
  text: X.TEXT,
  script: X.SCRIPT,
  scriptscript: X.SCRIPTSCRIPT
}, Uo = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
}, Te = function(e, t, r, a) {
  a === void 0 && (a = [null, null]);
  for (var i = [], l = 0; l < e.length; l++) {
    var o = ae(e[l], t);
    if (o instanceof Y0) {
      var c = o.children;
      i.push(...c);
    } else
      i.push(o);
  }
  if ($.tryCombineChars(i), !r)
    return i;
  var m = t;
  if (e.length === 1) {
    var d = e[0];
    d.type === "sizing" ? m = t.havingSize(d.size) : d.type === "styling" && (m = t.havingStyle(Ho[d.style]));
  }
  var p = x0([a[0] || "leftmost"], [], t), y = x0([a[1] || "rightmost"], [], t), v = r === "root";
  return Pa(i, (x, S) => {
    var F = S.classes[0], E = x.classes[0];
    F === "mbin" && j.contains(Po, E) ? S.classes[0] = "mord" : E === "mbin" && j.contains(Oo, F) && (x.classes[0] = "mord");
  }, {
    node: p
  }, y, v), Pa(i, (x, S) => {
    var F = wn(S), E = wn(x), D = F && E ? x.hasClass("mtight") ? Lo[F][E] : Io[F][E] : null;
    if (D)
      return $.makeGlue(D, m);
  }, {
    node: p
  }, y, v), i;
}, Pa = function n(e, t, r, a, i) {
  a && e.push(a);
  for (var l = 0; l < e.length; l++) {
    var o = e[l], c = ml(o);
    if (c) {
      n(c.children, t, r, null, i);
      continue;
    }
    var m = !o.hasClass("mspace");
    if (m) {
      var d = t(o, r.node);
      d && (r.insertAfter ? r.insertAfter(d) : (e.unshift(d), l++));
    }
    m ? r.node = o : i && o.hasClass("newline") && (r.node = x0(["leftmost"])), r.insertAfter = /* @__PURE__ */ ((p) => (y) => {
      e.splice(p + 1, 0, y), l++;
    })(l);
  }
  a && e.pop();
}, ml = function(e) {
  return e instanceof Y0 || e instanceof al || e instanceof zr && e.hasClass("enclosing") ? e : null;
}, Vo = function n(e, t) {
  var r = ml(e);
  if (r) {
    var a = r.children;
    if (a.length) {
      if (t === "right")
        return n(a[a.length - 1], "right");
      if (t === "left")
        return n(a[0], "left");
    }
  }
  return e;
}, wn = function(e, t) {
  return e ? (t && (e = Vo(e, t)), Uo[e.classes[0]] || null) : null;
}, G0 = function(e, t) {
  var r = ["nulldelimiter"].concat(e.baseSizingClasses());
  return x0(t.concat(r));
}, ae = function(e, t, r) {
  if (!e)
    return x0();
  if (Ar[e.type]) {
    var a = Ar[e.type](e, t);
    if (r && t.size !== r.size) {
      a = x0(t.sizingClasses(r), [a], t);
      var i = t.sizeMultiplier / r.sizeMultiplier;
      a.height *= i, a.depth *= i;
    }
    return a;
  } else
    throw new G("Got group of unknown type: '" + e.type + "'");
};
function hl(n) {
  return new Y0(n);
}
class Je {
  constructor(e, t, r) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = r || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(e) {
    return this.attributes[e];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
    this.classes.length > 0 && (e.className = Jt(this.classes));
    for (var r = 0; r < this.children.length; r++)
      if (this.children[r] instanceof xt && this.children[r + 1] instanceof xt) {
        for (var a = this.children[r].toText() + this.children[++r].toText(); this.children[r + 1] instanceof xt; )
          a += this.children[++r].toText();
        e.appendChild(new xt(a).toNode());
      } else
        e.appendChild(this.children[r].toNode());
    return e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var e = "<" + this.type;
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += j.escape(this.attributes[t]), e += '"');
    this.classes.length > 0 && (e += ' class ="' + j.escape(Jt(this.classes)) + '"'), e += ">";
    for (var r = 0; r < this.children.length; r++)
      e += this.children[r].toMarkup();
    return e += "</" + this.type + ">", e;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((e) => e.toText()).join("");
  }
}
class xt {
  constructor(e) {
    this.text = void 0, this.text = e;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return j.escape(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class Go {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(e) {
    this.width = void 0, this.character = void 0, this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = " " : e >= 0.1666 && e <= 0.1667 ? this.character = " " : e >= 0.2222 && e <= 0.2223 ? this.character = " " : e >= 0.2777 && e <= 0.2778 ? this.character = "  " : e >= -0.05556 && e <= -0.05555 ? this.character = " ⁣" : e >= -0.1667 && e <= -0.1666 ? this.character = " ⁣" : e >= -0.2223 && e <= -0.2222 ? this.character = " ⁣" : e >= -0.2778 && e <= -0.2777 ? this.character = " ⁣" : this.character = null;
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character)
      return document.createTextNode(this.character);
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return e.setAttribute("width", I(this.width)), e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + I(this.width) + '"/>';
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    return this.character ? this.character : " ";
  }
}
var B = {
  MathNode: Je,
  TextNode: xt,
  SpaceNode: Go,
  newDocumentFragment: hl
}, nt = function(e, t, r) {
  return xe[t][e] && xe[t][e].replace && e.charCodeAt(0) !== 55349 && !(il.hasOwnProperty(e) && r && (r.fontFamily && r.fontFamily.slice(4, 6) === "tt" || r.font && r.font.slice(4, 6) === "tt")) && (e = xe[t][e].replace), new B.TextNode(e);
}, Ln = function(e) {
  return e.length === 1 ? e[0] : new B.MathNode("mrow", e);
}, On = function(e, t) {
  if (t.fontFamily === "texttt")
    return "monospace";
  if (t.fontFamily === "textsf")
    return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
  if (t.fontShape === "textit" && t.fontWeight === "textbf")
    return "bold-italic";
  if (t.fontShape === "textit")
    return "italic";
  if (t.fontWeight === "textbf")
    return "bold";
  var r = t.font;
  if (!r || r === "mathnormal")
    return null;
  var a = e.mode;
  if (r === "mathit")
    return "italic";
  if (r === "boldsymbol")
    return e.type === "textord" ? "bold" : "bold-italic";
  if (r === "mathbf")
    return "bold";
  if (r === "mathbb")
    return "double-struck";
  if (r === "mathsfit")
    return "sans-serif-italic";
  if (r === "mathfrak")
    return "fraktur";
  if (r === "mathscr" || r === "mathcal")
    return "script";
  if (r === "mathsf")
    return "sans-serif";
  if (r === "mathtt")
    return "monospace";
  var i = e.text;
  if (j.contains(["\\imath", "\\jmath"], i))
    return null;
  xe[a][i] && xe[a][i].replace && (i = xe[a][i].replace);
  var l = $.fontMap[r].fontName;
  return Nn(i, l, a) ? $.fontMap[r].variant : null;
};
function Qr(n) {
  if (!n)
    return !1;
  if (n.type === "mi" && n.children.length === 1) {
    var e = n.children[0];
    return e instanceof xt && e.text === ".";
  } else if (n.type === "mo" && n.children.length === 1 && n.getAttribute("separator") === "true" && n.getAttribute("lspace") === "0em" && n.getAttribute("rspace") === "0em") {
    var t = n.children[0];
    return t instanceof xt && t.text === ",";
  } else
    return !1;
}
var Ze = function(e, t, r) {
  if (e.length === 1) {
    var a = me(e[0], t);
    return r && a instanceof Je && a.type === "mo" && (a.setAttribute("lspace", "0em"), a.setAttribute("rspace", "0em")), [a];
  }
  for (var i = [], l, o = 0; o < e.length; o++) {
    var c = me(e[o], t);
    if (c instanceof Je && l instanceof Je) {
      if (c.type === "mtext" && l.type === "mtext" && c.getAttribute("mathvariant") === l.getAttribute("mathvariant")) {
        l.children.push(...c.children);
        continue;
      } else if (c.type === "mn" && l.type === "mn") {
        l.children.push(...c.children);
        continue;
      } else if (Qr(c) && l.type === "mn") {
        l.children.push(...c.children);
        continue;
      } else if (c.type === "mn" && Qr(l))
        c.children = [...l.children, ...c.children], i.pop();
      else if ((c.type === "msup" || c.type === "msub") && c.children.length >= 1 && (l.type === "mn" || Qr(l))) {
        var m = c.children[0];
        m instanceof Je && m.type === "mn" && (m.children = [...l.children, ...m.children], i.pop());
      } else if (l.type === "mi" && l.children.length === 1) {
        var d = l.children[0];
        if (d instanceof xt && d.text === "̸" && (c.type === "mo" || c.type === "mi" || c.type === "mn")) {
          var p = c.children[0];
          p instanceof xt && p.text.length > 0 && (p.text = p.text.slice(0, 1) + "̸" + p.text.slice(1), i.pop());
        }
      }
    }
    i.push(c), l = c;
  }
  return i;
}, t0 = function(e, t, r) {
  return Ln(Ze(e, t, r));
}, me = function(e, t) {
  if (!e)
    return new B.MathNode("mrow");
  if ($r[e.type]) {
    var r = $r[e.type](e, t);
    return r;
  } else
    throw new G("Got group of unknown type: '" + e.type + "'");
}, Yo = {
  widehat: "^",
  widecheck: "ˇ",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "←",
  underleftarrow: "←",
  xleftarrow: "←",
  overrightarrow: "→",
  underrightarrow: "→",
  xrightarrow: "→",
  underbrace: "⏟",
  overbrace: "⏞",
  overgroup: "⏠",
  undergroup: "⏡",
  overleftrightarrow: "↔",
  underleftrightarrow: "↔",
  xleftrightarrow: "↔",
  Overrightarrow: "⇒",
  xRightarrow: "⇒",
  overleftharpoon: "↼",
  xleftharpoonup: "↼",
  overrightharpoon: "⇀",
  xrightharpoonup: "⇀",
  xLeftarrow: "⇐",
  xLeftrightarrow: "⇔",
  xhookleftarrow: "↩",
  xhookrightarrow: "↪",
  xmapsto: "↦",
  xrightharpoondown: "⇁",
  xleftharpoondown: "↽",
  xrightleftharpoons: "⇌",
  xleftrightharpoons: "⇋",
  xtwoheadleftarrow: "↞",
  xtwoheadrightarrow: "↠",
  xlongequal: "=",
  xtofrom: "⇄",
  xrightleftarrows: "⇄",
  xrightequilibrium: "⇌",
  // Not a perfect match.
  xleftequilibrium: "⇋",
  // None better available.
  "\\cdrightarrow": "→",
  "\\cdleftarrow": "←",
  "\\cdlongequal": "="
}, Wo = function(e) {
  var t = new B.MathNode("mo", [new B.TextNode(Yo[e.replace(/^\\/, "")])]);
  return t.setAttribute("stretchy", "true"), t;
}, jo = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
}, Xo = function(e) {
  return e.type === "ordgroup" ? e.body.length : 1;
}, Zo = function(e, t) {
  function r() {
    var o = 4e5, c = e.label.slice(1);
    if (j.contains(["widehat", "widecheck", "widetilde", "utilde"], c)) {
      var m = e, d = Xo(m.base), p, y, v;
      if (d > 5)
        c === "widehat" || c === "widecheck" ? (p = 420, o = 2364, v = 0.42, y = c + "4") : (p = 312, o = 2340, v = 0.34, y = "tilde4");
      else {
        var x = [1, 1, 2, 2, 3, 3][d];
        c === "widehat" || c === "widecheck" ? (o = [0, 1062, 2364, 2364, 2364][x], p = [0, 239, 300, 360, 420][x], v = [0, 0.24, 0.3, 0.3, 0.36, 0.42][x], y = c + x) : (o = [0, 600, 1033, 2339, 2340][x], p = [0, 260, 286, 306, 312][x], v = [0, 0.26, 0.286, 0.3, 0.306, 0.34][x], y = "tilde" + x);
      }
      var S = new l0(y), F = new e0([S], {
        width: "100%",
        height: I(v),
        viewBox: "0 0 " + o + " " + p,
        preserveAspectRatio: "none"
      });
      return {
        span: $.makeSvgSpan([], [F], t),
        minWidth: 0,
        height: v
      };
    } else {
      var E = [], D = jo[c], [g, A, C] = D, T = C / 1e3, z = g.length, P, R;
      if (z === 1) {
        var Q = D[3];
        P = ["hide-tail"], R = [Q];
      } else if (z === 2)
        P = ["halfarrow-left", "halfarrow-right"], R = ["xMinYMin", "xMaxYMin"];
      else if (z === 3)
        P = ["brace-left", "brace-center", "brace-right"], R = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      else
        throw new Error(`Correct katexImagesData or update code here to support
                    ` + z + " children.");
      for (var U = 0; U < z; U++) {
        var ee = new l0(g[U]), Ce = new e0([ee], {
          width: "400em",
          height: I(T),
          viewBox: "0 0 " + o + " " + C,
          preserveAspectRatio: R[U] + " slice"
        }), ie = $.makeSvgSpan([P[U]], [Ce], t);
        if (z === 1)
          return {
            span: ie,
            minWidth: A,
            height: T
          };
        ie.style.height = I(T), E.push(ie);
      }
      return {
        span: $.makeSpan(["stretchy"], E, t),
        minWidth: A,
        height: T
      };
    }
  }
  var {
    span: a,
    minWidth: i,
    height: l
  } = r();
  return a.height = l, a.style.height = I(l), i > 0 && (a.style.minWidth = I(i)), a;
}, Ko = function(e, t, r, a, i) {
  var l, o = e.height + e.depth + r + a;
  if (/fbox|color|angl/.test(t)) {
    if (l = $.makeSpan(["stretchy", t], [], i), t === "fbox") {
      var c = i.color && i.getColor();
      c && (l.style.borderColor = c);
    }
  } else {
    var m = [];
    /^[bx]cancel$/.test(t) && m.push(new za({
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%",
      "stroke-width": "0.046em"
    })), /^x?cancel$/.test(t) && m.push(new za({
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0",
      "stroke-width": "0.046em"
    }));
    var d = new e0(m, {
      width: "100%",
      height: I(o)
    });
    l = $.makeSvgSpan([], [d], i);
  }
  return l.height = o, l.style.height = I(o), l;
}, Wt = {
  encloseSpan: Ko,
  mathMLnode: Wo,
  svgSpan: Zo
};
function J(n, e) {
  if (!n || n.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (n ? "node of type " + n.type : String(n)));
  return n;
}
function Pn(n) {
  var e = Rr(n);
  if (!e)
    throw new Error("Expected node of symbol group type, but got " + (n ? "node of type " + n.type : String(n)));
  return e;
}
function Rr(n) {
  return n && (n.type === "atom" || xo.hasOwnProperty(n.type)) ? n : null;
}
var Hn = (n, e) => {
  var t, r, a;
  n && n.type === "supsub" ? (r = J(n.base, "accent"), t = r.base, n.base = t, a = Do(ae(n, e)), n.base = r) : (r = J(n, "accent"), t = r.base);
  var i = ae(t, e.havingCrampedStyle()), l = r.isShifty && j.isCharacterBox(t), o = 0;
  if (l) {
    var c = j.getBaseElem(t), m = ae(c, e.havingCrampedStyle());
    o = Ba(m).skew;
  }
  var d = r.label === "\\c", p = d ? i.height + i.depth : Math.min(i.height, e.fontMetrics().xHeight), y;
  if (r.isStretchy)
    y = Wt.svgSpan(r, e), y = $.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "elem",
        elem: y,
        wrapperClasses: ["svg-align"],
        wrapperStyle: o > 0 ? {
          width: "calc(100% - " + I(2 * o) + ")",
          marginLeft: I(2 * o)
        } : void 0
      }]
    }, e);
  else {
    var v, x;
    r.label === "\\vec" ? (v = $.staticSvg("vec", e), x = $.svgData.vec[1]) : (v = $.makeOrd({
      mode: r.mode,
      text: r.label
    }, e, "textord"), v = Ba(v), v.italic = 0, x = v.width, d && (p += v.depth)), y = $.makeSpan(["accent-body"], [v]);
    var S = r.label === "\\textcircled";
    S && (y.classes.push("accent-full"), p = i.height);
    var F = o;
    S || (F -= x / 2), y.style.left = I(F), r.label === "\\textcircled" && (y.style.top = ".2em"), y = $.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: -p
      }, {
        type: "elem",
        elem: y
      }]
    }, e);
  }
  var E = $.makeSpan(["mord", "accent"], [y], e);
  return a ? (a.children[0] = E, a.height = Math.max(E.height, a.height), a.classes[0] = "mord", a) : E;
}, dl = (n, e) => {
  var t = n.isStretchy ? Wt.mathMLnode(n.label) : new B.MathNode("mo", [nt(n.label, n.mode)]), r = new B.MathNode("mover", [me(n.base, e), t]);
  return r.setAttribute("accent", "true"), r;
}, Qo = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((n) => "\\" + n).join("|"));
L({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var t = Fr(e[0]), r = !Qo.test(n.funcName), a = !r || n.funcName === "\\widehat" || n.funcName === "\\widetilde" || n.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: n.parser.mode,
      label: n.funcName,
      isStretchy: r,
      isShifty: a,
      base: t
    };
  },
  htmlBuilder: Hn,
  mathmlBuilder: dl
});
L({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (n, e) => {
    var t = e[0], r = n.parser.mode;
    return r === "math" && (n.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + n.funcName + " works only in text mode"), r = "text"), {
      type: "accent",
      mode: r,
      label: n.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: t
    };
  },
  htmlBuilder: Hn,
  mathmlBuilder: dl
});
L({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "accentUnder",
      mode: t.mode,
      label: r,
      base: a
    };
  },
  htmlBuilder: (n, e) => {
    var t = ae(n.base, e), r = Wt.svgSpan(n, e), a = n.label === "\\utilde" ? 0.12 : 0, i = $.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "elem",
        elem: r,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return $.makeSpan(["mord", "accentunder"], [i], e);
  },
  mathmlBuilder: (n, e) => {
    var t = Wt.mathMLnode(n.label), r = new B.MathNode("munder", [me(n.base, e), t]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
var lr = (n) => {
  var e = new B.MathNode("mpadded", n ? [n] : []);
  return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
};
L({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n;
    return {
      type: "xArrow",
      mode: r.mode,
      label: a,
      body: e[0],
      below: t[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(n, e) {
    var t = e.style, r = e.havingStyle(t.sup()), a = $.wrapFragment(ae(n.body, r, e), e), i = n.label.slice(0, 2) === "\\x" ? "x" : "cd";
    a.classes.push(i + "-arrow-pad");
    var l;
    n.below && (r = e.havingStyle(t.sub()), l = $.wrapFragment(ae(n.below, r, e), e), l.classes.push(i + "-arrow-pad"));
    var o = Wt.svgSpan(n, e), c = -e.fontMetrics().axisHeight + 0.5 * o.height, m = -e.fontMetrics().axisHeight - 0.5 * o.height - 0.111;
    (a.depth > 0.25 || n.label === "\\xleftequilibrium") && (m -= a.depth);
    var d;
    if (l) {
      var p = -e.fontMetrics().axisHeight + l.height + 0.5 * o.height + 0.111;
      d = $.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: m
        }, {
          type: "elem",
          elem: o,
          shift: c
        }, {
          type: "elem",
          elem: l,
          shift: p
        }]
      }, e);
    } else
      d = $.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: a,
          shift: m
        }, {
          type: "elem",
          elem: o,
          shift: c
        }]
      }, e);
    return d.children[0].children[0].children[1].classes.push("svg-align"), $.makeSpan(["mrel", "x-arrow"], [d], e);
  },
  mathmlBuilder(n, e) {
    var t = Wt.mathMLnode(n.label);
    t.setAttribute("minsize", n.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var r;
    if (n.body) {
      var a = lr(me(n.body, e));
      if (n.below) {
        var i = lr(me(n.below, e));
        r = new B.MathNode("munderover", [t, i, a]);
      } else
        r = new B.MathNode("mover", [t, a]);
    } else if (n.below) {
      var l = lr(me(n.below, e));
      r = new B.MathNode("munder", [t, l]);
    } else
      r = lr(), r = new B.MathNode("mover", [t, r]);
    return r;
  }
});
var Jo = $.makeSpan;
function fl(n, e) {
  var t = Te(n.body, e, !0);
  return Jo([n.mclass], t, e);
}
function pl(n, e) {
  var t, r = Ze(n.body, e);
  return n.mclass === "minner" ? t = new B.MathNode("mpadded", r) : n.mclass === "mord" ? n.isCharacterBox ? (t = r[0], t.type = "mi") : t = new B.MathNode("mi", r) : (n.isCharacterBox ? (t = r[0], t.type = "mo") : t = new B.MathNode("mo", r), n.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : n.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : n.mclass === "mopen" || n.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : n.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
}
L({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: "m" + r.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: De(a),
      isCharacterBox: j.isCharacterBox(a)
    };
  },
  htmlBuilder: fl,
  mathmlBuilder: pl
});
var Nr = (n) => {
  var e = n.type === "ordgroup" && n.body.length ? n.body[0] : n;
  return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
};
L({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "mclass",
      mode: t.mode,
      mclass: Nr(e[0]),
      body: De(e[1]),
      isCharacterBox: j.isCharacterBox(e[1])
    };
  }
});
L({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[1], i = e[0], l;
    r !== "\\stackrel" ? l = Nr(a) : l = "mrel";
    var o = {
      type: "op",
      mode: a.mode,
      limits: !0,
      alwaysHandleSupSub: !0,
      parentIsSupSub: !1,
      symbol: !1,
      suppressBaseShift: r !== "\\stackrel",
      body: De(a)
    }, c = {
      type: "supsub",
      mode: i.mode,
      base: o,
      sup: r === "\\underset" ? null : i,
      sub: r === "\\underset" ? i : null
    };
    return {
      type: "mclass",
      mode: t.mode,
      mclass: l,
      body: [c],
      isCharacterBox: j.isCharacterBox(c)
    };
  },
  htmlBuilder: fl,
  mathmlBuilder: pl
});
L({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "pmb",
      mode: t.mode,
      mclass: Nr(e[0]),
      body: De(e[0])
    };
  },
  htmlBuilder(n, e) {
    var t = Te(n.body, e, !0), r = $.makeSpan([n.mclass], t, e);
    return r.style.textShadow = "0.02em 0.01em 0.04px", r;
  },
  mathmlBuilder(n, e) {
    var t = Ze(n.body, e), r = new B.MathNode("mstyle", t);
    return r.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), r;
  }
});
var e1 = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  A: "\\uparrow",
  V: "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
}, Ha = () => ({
  type: "styling",
  body: [],
  mode: "math",
  style: "display"
}), Ua = (n) => n.type === "textord" && n.text === "@", t1 = (n, e) => (n.type === "mathord" || n.type === "atom") && n.text === e;
function r1(n, e, t) {
  var r = e1[n];
  switch (r) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return t.callFunction(r, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var a = t.callFunction("\\\\cdleft", [e[0]], []), i = {
        type: "atom",
        text: r,
        mode: "math",
        family: "rel"
      }, l = t.callFunction("\\Big", [i], []), o = t.callFunction("\\\\cdright", [e[1]], []), c = {
        type: "ordgroup",
        mode: "math",
        body: [a, l, o]
      };
      return t.callFunction("\\\\cdparent", [c], []);
    }
    case "\\\\cdlongequal":
      return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var m = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return t.callFunction("\\Big", [m], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function n1(n) {
  var e = [];
  for (n.gullet.beginGroup(), n.gullet.macros.set("\\cr", "\\\\\\relax"), n.gullet.beginGroup(); ; ) {
    e.push(n.parseExpression(!1, "\\\\")), n.gullet.endGroup(), n.gullet.beginGroup();
    var t = n.fetch().text;
    if (t === "&" || t === "\\\\")
      n.consume();
    else if (t === "\\end") {
      e[e.length - 1].length === 0 && e.pop();
      break;
    } else
      throw new G("Expected \\\\ or \\cr or \\end", n.nextToken);
  }
  for (var r = [], a = [r], i = 0; i < e.length; i++) {
    for (var l = e[i], o = Ha(), c = 0; c < l.length; c++)
      if (!Ua(l[c]))
        o.body.push(l[c]);
      else {
        r.push(o), c += 1;
        var m = Pn(l[c]).text, d = new Array(2);
        if (d[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, d[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, !("=|.".indexOf(m) > -1)) if ("<>AV".indexOf(m) > -1)
          for (var p = 0; p < 2; p++) {
            for (var y = !0, v = c + 1; v < l.length; v++) {
              if (t1(l[v], m)) {
                y = !1, c = v;
                break;
              }
              if (Ua(l[v]))
                throw new G("Missing a " + m + " character to complete a CD arrow.", l[v]);
              d[p].body.push(l[v]);
            }
            if (y)
              throw new G("Missing a " + m + " character to complete a CD arrow.", l[c]);
          }
        else
          throw new G('Expected one of "<>AV=|." after @', l[c]);
        var x = r1(m, d, n), S = {
          type: "styling",
          body: [x],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        r.push(S), o = Ha();
      }
    i % 2 === 0 ? r.push(o) : r.shift(), r = [], a.push(r);
  }
  n.gullet.endGroup(), n.gullet.endGroup();
  var F = new Array(a[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body: a,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: F,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(a.length + 1).fill([])
  };
}
L({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n;
    return {
      type: "cdlabel",
      mode: t.mode,
      side: r.slice(4),
      label: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = e.havingStyle(e.style.sup()), r = $.wrapFragment(ae(n.label, t, e), e);
    return r.classes.push("cd-label-" + n.side), r.style.bottom = I(0.8 - r.depth), r.height = 0, r.depth = 0, r;
  },
  mathmlBuilder(n, e) {
    var t = new B.MathNode("mrow", [me(n.label, e)]);
    return t = new B.MathNode("mpadded", [t]), t.setAttribute("width", "0"), n.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new B.MathNode("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
  }
});
L({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "cdlabelparent",
      mode: t.mode,
      fragment: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = $.wrapFragment(ae(n.fragment, e), e);
    return t.classes.push("cd-vert-arrow"), t;
  },
  mathmlBuilder(n, e) {
    return new B.MathNode("mrow", [me(n.fragment, e)]);
  }
});
L({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    for (var {
      parser: t
    } = n, r = J(e[0], "ordgroup"), a = r.body, i = "", l = 0; l < a.length; l++) {
      var o = J(a[l], "textord");
      i += o.text;
    }
    var c = parseInt(i), m;
    if (isNaN(c))
      throw new G("\\@char has non-numeric argument " + i);
    if (c < 0 || c >= 1114111)
      throw new G("\\@char with invalid code point " + i);
    return c <= 65535 ? m = String.fromCharCode(c) : (c -= 65536, m = String.fromCharCode((c >> 10) + 55296, (c & 1023) + 56320)), {
      type: "textord",
      mode: t.mode,
      text: m
    };
  }
});
var gl = (n, e) => {
  var t = Te(n.body, e.withColor(n.color), !1);
  return $.makeFragment(t);
}, _l = (n, e) => {
  var t = Ze(n.body, e.withColor(n.color)), r = new B.MathNode("mstyle", t);
  return r.setAttribute("mathcolor", n.color), r;
};
L({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "original"]
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = J(e[0], "color-token").color, a = e[1];
    return {
      type: "color",
      mode: t.mode,
      color: r,
      body: De(a)
    };
  },
  htmlBuilder: gl,
  mathmlBuilder: _l
});
L({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    argTypes: ["color"]
  },
  handler(n, e) {
    var {
      parser: t,
      breakOnTokenText: r
    } = n, a = J(e[0], "color-token").color;
    t.gullet.macros.set("\\current@color", a);
    var i = t.parseExpression(!0, r);
    return {
      type: "color",
      mode: t.mode,
      color: a,
      body: i
    };
  },
  htmlBuilder: gl,
  mathmlBuilder: _l
});
L({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: !0
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = r.gullet.future().text === "[" ? r.parseSizeGroup(!0) : null, i = !r.settings.displayMode || !r.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: r.mode,
      newLine: i,
      size: a && J(a, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(n, e) {
    var t = $.makeSpan(["mspace"], [], e);
    return n.newLine && (t.classes.push("newline"), n.size && (t.style.marginTop = I(ge(n.size, e)))), t;
  },
  mathmlBuilder(n, e) {
    var t = new B.MathNode("mspace");
    return n.newLine && (t.setAttribute("linebreak", "newline"), n.size && t.setAttribute("height", I(ge(n.size, e)))), t;
  }
});
var kn = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
}, vl = (n) => {
  var e = n.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new G("Expected a control sequence", n);
  return e;
}, a1 = (n) => {
  var e = n.gullet.popToken();
  return e.text === "=" && (e = n.gullet.popToken(), e.text === " " && (e = n.gullet.popToken())), e;
}, bl = (n, e, t, r) => {
  var a = n.gullet.macros.get(t.text);
  a == null && (t.noexpand = !0, a = {
    tokens: [t],
    numArgs: 0,
    // reproduce the same behavior in expansion
    unexpandable: !n.gullet.isExpandable(t.text)
  }), n.gullet.macros.set(e, a, r);
};
L({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    e.consumeSpaces();
    var r = e.fetch();
    if (kn[r.text])
      return (t === "\\global" || t === "\\\\globallong") && (r.text = kn[r.text]), J(e.parseFunction(), "internal");
    throw new G("Invalid token after macro prefix", r);
  }
});
L({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = e.gullet.popToken(), a = r.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(a))
      throw new G("Expected a control sequence", r);
    for (var i = 0, l, o = [[]]; e.gullet.future().text !== "{"; )
      if (r = e.gullet.popToken(), r.text === "#") {
        if (e.gullet.future().text === "{") {
          l = e.gullet.future(), o[i].push("{");
          break;
        }
        if (r = e.gullet.popToken(), !/^[1-9]$/.test(r.text))
          throw new G('Invalid argument number "' + r.text + '"');
        if (parseInt(r.text) !== i + 1)
          throw new G('Argument number "' + r.text + '" out of order');
        i++, o.push([]);
      } else {
        if (r.text === "EOF")
          throw new G("Expected a macro definition");
        o[i].push(r.text);
      }
    var {
      tokens: c
    } = e.gullet.consumeArg();
    return l && c.unshift(l), (t === "\\edef" || t === "\\xdef") && (c = e.gullet.expandTokens(c), c.reverse()), e.gullet.macros.set(a, {
      tokens: c,
      numArgs: i,
      delimiters: o
    }, t === kn[t]), {
      type: "internal",
      mode: e.mode
    };
  }
});
L({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = vl(e.gullet.popToken());
    e.gullet.consumeSpaces();
    var a = a1(e);
    return bl(e, r, a, t === "\\\\globallet"), {
      type: "internal",
      mode: e.mode
    };
  }
});
L({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = vl(e.gullet.popToken()), a = e.gullet.popToken(), i = e.gullet.popToken();
    return bl(e, r, i, t === "\\\\globalfuture"), e.gullet.pushToken(i), e.gullet.pushToken(a), {
      type: "internal",
      mode: e.mode
    };
  }
});
var I0 = function(e, t, r) {
  var a = xe.math[e] && xe.math[e].replace, i = Nn(a || e, t, r);
  if (!i)
    throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
  return i;
}, Un = function(e, t, r, a) {
  var i = r.havingBaseStyle(t), l = $.makeSpan(a.concat(i.sizingClasses(r)), [e], r), o = i.sizeMultiplier / r.sizeMultiplier;
  return l.height *= o, l.depth *= o, l.maxFontSize = i.sizeMultiplier, l;
}, yl = function(e, t, r) {
  var a = t.havingBaseStyle(r), i = (1 - t.sizeMultiplier / a.sizeMultiplier) * t.fontMetrics().axisHeight;
  e.classes.push("delimcenter"), e.style.top = I(i), e.height -= i, e.depth += i;
}, i1 = function(e, t, r, a, i, l) {
  var o = $.makeSymbol(e, "Main-Regular", i, a), c = Un(o, t, a, l);
  return r && yl(c, a, t), c;
}, l1 = function(e, t, r, a) {
  return $.makeSymbol(e, "Size" + t + "-Regular", r, a);
}, wl = function(e, t, r, a, i, l) {
  var o = l1(e, t, i, a), c = Un($.makeSpan(["delimsizing", "size" + t], [o], a), X.TEXT, a, l);
  return r && yl(c, a, X.TEXT), c;
}, Jr = function(e, t, r) {
  var a;
  t === "Size1-Regular" ? a = "delim-size1" : a = "delim-size4";
  var i = $.makeSpan(["delimsizinginner", a], [$.makeSpan([], [$.makeSymbol(e, t, r)])]);
  return {
    type: "elem",
    elem: i
  };
}, en = function(e, t, r) {
  var a = Vt["Size4-Regular"][e.charCodeAt(0)] ? Vt["Size4-Regular"][e.charCodeAt(0)][4] : Vt["Size1-Regular"][e.charCodeAt(0)][4], i = new l0("inner", go(e, Math.round(1e3 * t))), l = new e0([i], {
    width: I(a),
    height: I(t),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + I(a),
    viewBox: "0 0 " + 1e3 * a + " " + Math.round(1e3 * t),
    preserveAspectRatio: "xMinYMin"
  }), o = $.makeSvgSpan([], [l], r);
  return o.height = t, o.style.height = I(t), o.style.width = I(a), {
    type: "elem",
    elem: o
  };
}, Dn = 8e-3, sr = {
  type: "kern",
  size: -1 * Dn
}, s1 = ["|", "\\lvert", "\\rvert", "\\vert"], o1 = ["\\|", "\\lVert", "\\rVert", "\\Vert"], kl = function(e, t, r, a, i, l) {
  var o, c, m, d, p = "", y = 0;
  o = m = d = e, c = null;
  var v = "Size1-Regular";
  e === "\\uparrow" ? m = d = "⏐" : e === "\\Uparrow" ? m = d = "‖" : e === "\\downarrow" ? o = m = "⏐" : e === "\\Downarrow" ? o = m = "‖" : e === "\\updownarrow" ? (o = "\\uparrow", m = "⏐", d = "\\downarrow") : e === "\\Updownarrow" ? (o = "\\Uparrow", m = "‖", d = "\\Downarrow") : j.contains(s1, e) ? (m = "∣", p = "vert", y = 333) : j.contains(o1, e) ? (m = "∥", p = "doublevert", y = 556) : e === "[" || e === "\\lbrack" ? (o = "⎡", m = "⎢", d = "⎣", v = "Size4-Regular", p = "lbrack", y = 667) : e === "]" || e === "\\rbrack" ? (o = "⎤", m = "⎥", d = "⎦", v = "Size4-Regular", p = "rbrack", y = 667) : e === "\\lfloor" || e === "⌊" ? (m = o = "⎢", d = "⎣", v = "Size4-Regular", p = "lfloor", y = 667) : e === "\\lceil" || e === "⌈" ? (o = "⎡", m = d = "⎢", v = "Size4-Regular", p = "lceil", y = 667) : e === "\\rfloor" || e === "⌋" ? (m = o = "⎥", d = "⎦", v = "Size4-Regular", p = "rfloor", y = 667) : e === "\\rceil" || e === "⌉" ? (o = "⎤", m = d = "⎥", v = "Size4-Regular", p = "rceil", y = 667) : e === "(" || e === "\\lparen" ? (o = "⎛", m = "⎜", d = "⎝", v = "Size4-Regular", p = "lparen", y = 875) : e === ")" || e === "\\rparen" ? (o = "⎞", m = "⎟", d = "⎠", v = "Size4-Regular", p = "rparen", y = 875) : e === "\\{" || e === "\\lbrace" ? (o = "⎧", c = "⎨", d = "⎩", m = "⎪", v = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (o = "⎫", c = "⎬", d = "⎭", m = "⎪", v = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (o = "⎧", d = "⎩", m = "⎪", v = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (o = "⎫", d = "⎭", m = "⎪", v = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (o = "⎧", d = "⎭", m = "⎪", v = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (o = "⎫", d = "⎩", m = "⎪", v = "Size4-Regular");
  var x = I0(o, v, i), S = x.height + x.depth, F = I0(m, v, i), E = F.height + F.depth, D = I0(d, v, i), g = D.height + D.depth, A = 0, C = 1;
  if (c !== null) {
    var T = I0(c, v, i);
    A = T.height + T.depth, C = 2;
  }
  var z = S + g + A, P = Math.max(0, Math.ceil((t - z) / (C * E))), R = z + P * C * E, Q = a.fontMetrics().axisHeight;
  r && (Q *= a.sizeMultiplier);
  var U = R / 2 - Q, ee = [];
  if (p.length > 0) {
    var Ce = R - S - g, ie = Math.round(R * 1e3), ye = _o(p, Math.round(Ce * 1e3)), we = new l0(p, ye), He = (y / 1e3).toFixed(3) + "em", se = (ie / 1e3).toFixed(3) + "em", Ae = new e0([we], {
      width: He,
      height: se,
      viewBox: "0 0 " + y + " " + ie
    }), ke = $.makeSvgSpan([], [Ae], a);
    ke.height = ie / 1e3, ke.style.width = He, ke.style.height = se, ee.push({
      type: "elem",
      elem: ke
    });
  } else {
    if (ee.push(Jr(d, v, i)), ee.push(sr), c === null) {
      var te = R - S - g + 2 * Dn;
      ee.push(en(m, te, a));
    } else {
      var le = (R - S - g - A) / 2 + 2 * Dn;
      ee.push(en(m, le, a)), ee.push(sr), ee.push(Jr(c, v, i)), ee.push(sr), ee.push(en(m, le, a));
    }
    ee.push(sr), ee.push(Jr(o, v, i));
  }
  var ce = a.havingBaseStyle(X.TEXT), Ee = $.makeVList({
    positionType: "bottom",
    positionData: U,
    children: ee
  }, ce);
  return Un($.makeSpan(["delimsizing", "mult"], [Ee], ce), X.TEXT, a, l);
}, tn = 80, rn = 0.08, nn = function(e, t, r, a, i) {
  var l = po(e, a, r), o = new l0(e, l), c = new e0([o], {
    // Note: 1000:1 ratio of viewBox to document em width.
    width: "400em",
    height: I(t),
    viewBox: "0 0 400000 " + r,
    preserveAspectRatio: "xMinYMin slice"
  });
  return $.makeSvgSpan(["hide-tail"], [c], i);
}, u1 = function(e, t) {
  var r = t.havingBaseSizing(), a = Al("\\surd", e * r.sizeMultiplier, Sl, r), i = r.sizeMultiplier, l = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), o, c = 0, m = 0, d = 0, p;
  return a.type === "small" ? (d = 1e3 + 1e3 * l + tn, e < 1 ? i = 1 : e < 1.4 && (i = 0.7), c = (1 + l + rn) / i, m = (1 + l) / i, o = nn("sqrtMain", c, d, l, t), o.style.minWidth = "0.853em", p = 0.833 / i) : a.type === "large" ? (d = (1e3 + tn) * O0[a.size], m = (O0[a.size] + l) / i, c = (O0[a.size] + l + rn) / i, o = nn("sqrtSize" + a.size, c, d, l, t), o.style.minWidth = "1.02em", p = 1 / i) : (c = e + l + rn, m = e + l, d = Math.floor(1e3 * e + l) + tn, o = nn("sqrtTall", c, d, l, t), o.style.minWidth = "0.742em", p = 1.056), o.height = m, o.style.height = I(c), {
    span: o,
    advanceWidth: p,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (t.fontMetrics().sqrtRuleThickness + l) * i
  };
}, Dl = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], c1 = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], xl = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], O0 = [0, 1.2, 1.8, 2.4, 3], m1 = function(e, t, r, a, i) {
  if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), j.contains(Dl, e) || j.contains(xl, e))
    return wl(e, t, !1, r, a, i);
  if (j.contains(c1, e))
    return kl(e, O0[t], !1, r, a, i);
  throw new G("Illegal delimiter: '" + e + "'");
}, h1 = [{
  type: "small",
  style: X.SCRIPTSCRIPT
}, {
  type: "small",
  style: X.SCRIPT
}, {
  type: "small",
  style: X.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}], d1 = [{
  type: "small",
  style: X.SCRIPTSCRIPT
}, {
  type: "small",
  style: X.SCRIPT
}, {
  type: "small",
  style: X.TEXT
}, {
  type: "stack"
}], Sl = [{
  type: "small",
  style: X.SCRIPTSCRIPT
}, {
  type: "small",
  style: X.SCRIPT
}, {
  type: "small",
  style: X.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}], f1 = function(e) {
  if (e.type === "small")
    return "Main-Regular";
  if (e.type === "large")
    return "Size" + e.size + "-Regular";
  if (e.type === "stack")
    return "Size4-Regular";
  throw new Error("Add support for delim type '" + e.type + "' here.");
}, Al = function(e, t, r, a) {
  for (var i = Math.min(2, 3 - a.style.size), l = i; l < r.length && r[l].type !== "stack"; l++) {
    var o = I0(e, f1(r[l]), "math"), c = o.height + o.depth;
    if (r[l].type === "small") {
      var m = a.havingBaseStyle(r[l].style);
      c *= m.sizeMultiplier;
    }
    if (c > t)
      return r[l];
  }
  return r[r.length - 1];
}, $l = function(e, t, r, a, i, l) {
  e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
  var o;
  j.contains(xl, e) ? o = h1 : j.contains(Dl, e) ? o = Sl : o = d1;
  var c = Al(e, t, o, a);
  return c.type === "small" ? i1(e, c.style, r, a, i, l) : c.type === "large" ? wl(e, c.size, r, a, i, l) : kl(e, t, r, a, i, l);
}, p1 = function(e, t, r, a, i, l) {
  var o = a.fontMetrics().axisHeight * a.sizeMultiplier, c = 901, m = 5 / a.fontMetrics().ptPerEm, d = Math.max(t - o, r + o), p = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    d / 500 * c,
    2 * d - m
  );
  return $l(e, p, !0, a, i, l);
}, Yt = {
  sqrtImage: u1,
  sizedDelim: m1,
  sizeToMaxHeight: O0,
  customSizedDelim: $l,
  leftRightDelim: p1
}, Va = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
}, g1 = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
function Ir(n, e) {
  var t = Rr(n);
  if (t && j.contains(g1, t.text))
    return t;
  throw t ? new G("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", n) : new G("Invalid delimiter type '" + n.type + "'", n);
}
L({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (n, e) => {
    var t = Ir(e[0], n);
    return {
      type: "delimsizing",
      mode: n.parser.mode,
      size: Va[n.funcName].size,
      mclass: Va[n.funcName].mclass,
      delim: t.text
    };
  },
  htmlBuilder: (n, e) => n.delim === "." ? $.makeSpan([n.mclass]) : Yt.sizedDelim(n.delim, n.size, e, n.mode, [n.mclass]),
  mathmlBuilder: (n) => {
    var e = [];
    n.delim !== "." && e.push(nt(n.delim, n.mode));
    var t = new B.MathNode("mo", e);
    n.mclass === "mopen" || n.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
    var r = I(Yt.sizeToMaxHeight[n.size]);
    return t.setAttribute("minsize", r), t.setAttribute("maxsize", r), t;
  }
});
function Ga(n) {
  if (!n.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
L({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = n.parser.gullet.macros.get("\\current@color");
    if (t && typeof t != "string")
      throw new G("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: n.parser.mode,
      delim: Ir(e[0], n).text,
      color: t
      // undefined if not set via \color
    };
  }
});
L({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = Ir(e[0], n), r = n.parser;
    ++r.leftrightDepth;
    var a = r.parseExpression(!1);
    --r.leftrightDepth, r.expect("\\right", !1);
    var i = J(r.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: r.mode,
      body: a,
      left: t.text,
      right: i.delim,
      rightColor: i.color
    };
  },
  htmlBuilder: (n, e) => {
    Ga(n);
    for (var t = Te(n.body, e, !0, ["mopen", "mclose"]), r = 0, a = 0, i = !1, l = 0; l < t.length; l++)
      t[l].isMiddle ? i = !0 : (r = Math.max(t[l].height, r), a = Math.max(t[l].depth, a));
    r *= e.sizeMultiplier, a *= e.sizeMultiplier;
    var o;
    if (n.left === "." ? o = G0(e, ["mopen"]) : o = Yt.leftRightDelim(n.left, r, a, e, n.mode, ["mopen"]), t.unshift(o), i)
      for (var c = 1; c < t.length; c++) {
        var m = t[c], d = m.isMiddle;
        d && (t[c] = Yt.leftRightDelim(d.delim, r, a, d.options, n.mode, []));
      }
    var p;
    if (n.right === ".")
      p = G0(e, ["mclose"]);
    else {
      var y = n.rightColor ? e.withColor(n.rightColor) : e;
      p = Yt.leftRightDelim(n.right, r, a, y, n.mode, ["mclose"]);
    }
    return t.push(p), $.makeSpan(["minner"], t, e);
  },
  mathmlBuilder: (n, e) => {
    Ga(n);
    var t = Ze(n.body, e);
    if (n.left !== ".") {
      var r = new B.MathNode("mo", [nt(n.left, n.mode)]);
      r.setAttribute("fence", "true"), t.unshift(r);
    }
    if (n.right !== ".") {
      var a = new B.MathNode("mo", [nt(n.right, n.mode)]);
      a.setAttribute("fence", "true"), n.rightColor && a.setAttribute("mathcolor", n.rightColor), t.push(a);
    }
    return Ln(t);
  }
});
L({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var t = Ir(e[0], n);
    if (!n.parser.leftrightDepth)
      throw new G("\\middle without preceding \\left", t);
    return {
      type: "middle",
      mode: n.parser.mode,
      delim: t.text
    };
  },
  htmlBuilder: (n, e) => {
    var t;
    if (n.delim === ".")
      t = G0(e, []);
    else {
      t = Yt.sizedDelim(n.delim, 1, e, n.mode, []);
      var r = {
        delim: n.delim,
        options: e
      };
      t.isMiddle = r;
    }
    return t;
  },
  mathmlBuilder: (n, e) => {
    var t = n.delim === "\\vert" || n.delim === "|" ? nt("|", "text") : nt(n.delim, n.mode), r = new B.MathNode("mo", [t]);
    return r.setAttribute("fence", "true"), r.setAttribute("lspace", "0.05em"), r.setAttribute("rspace", "0.05em"), r;
  }
});
var Vn = (n, e) => {
  var t = $.wrapFragment(ae(n.body, e), e), r = n.label.slice(1), a = e.sizeMultiplier, i, l = 0, o = j.isCharacterBox(n.body);
  if (r === "sout")
    i = $.makeSpan(["stretchy", "sout"]), i.height = e.fontMetrics().defaultRuleThickness / a, l = -0.5 * e.fontMetrics().xHeight;
  else if (r === "phase") {
    var c = ge({
      number: 0.6,
      unit: "pt"
    }, e), m = ge({
      number: 0.35,
      unit: "ex"
    }, e), d = e.havingBaseSizing();
    a = a / d.sizeMultiplier;
    var p = t.height + t.depth + c + m;
    t.style.paddingLeft = I(p / 2 + c);
    var y = Math.floor(1e3 * p * a), v = ho(y), x = new e0([new l0("phase", v)], {
      width: "400em",
      height: I(y / 1e3),
      viewBox: "0 0 400000 " + y,
      preserveAspectRatio: "xMinYMin slice"
    });
    i = $.makeSvgSpan(["hide-tail"], [x], e), i.style.height = I(p), l = t.depth + c + m;
  } else {
    /cancel/.test(r) ? o || t.classes.push("cancel-pad") : r === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var S = 0, F = 0, E = 0;
    /box/.test(r) ? (E = Math.max(
      e.fontMetrics().fboxrule,
      // default
      e.minRuleThickness
      // User override.
    ), S = e.fontMetrics().fboxsep + (r === "colorbox" ? 0 : E), F = S) : r === "angl" ? (E = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), S = 4 * E, F = Math.max(0, 0.25 - t.depth)) : (S = o ? 0.2 : 0, F = S), i = Wt.encloseSpan(t, r, S, F, e), /fbox|boxed|fcolorbox/.test(r) ? (i.style.borderStyle = "solid", i.style.borderWidth = I(E)) : r === "angl" && E !== 0.049 && (i.style.borderTopWidth = I(E), i.style.borderRightWidth = I(E)), l = t.depth + F, n.backgroundColor && (i.style.backgroundColor = n.backgroundColor, n.borderColor && (i.style.borderColor = n.borderColor));
  }
  var D;
  if (n.backgroundColor)
    D = $.makeVList({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: i,
          shift: l
        },
        {
          type: "elem",
          elem: t,
          shift: 0
        }
      ]
    }, e);
  else {
    var g = /cancel|phase/.test(r) ? ["svg-align"] : [];
    D = $.makeVList({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: t,
          shift: 0
        },
        {
          type: "elem",
          elem: i,
          shift: l,
          wrapperClasses: g
        }
      ]
    }, e);
  }
  return /cancel/.test(r) && (D.height = t.height, D.depth = t.depth), /cancel/.test(r) && !o ? $.makeSpan(["mord", "cancel-lap"], [D], e) : $.makeSpan(["mord"], [D], e);
}, Gn = (n, e) => {
  var t = 0, r = new B.MathNode(n.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [me(n.body, e)]);
  switch (n.label) {
    case "\\cancel":
      r.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      r.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      r.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      r.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      r.setAttribute("notation", "box");
      break;
    case "\\angl":
      r.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, r.setAttribute("width", "+" + 2 * t + "pt"), r.setAttribute("height", "+" + 2 * t + "pt"), r.setAttribute("lspace", t + "pt"), r.setAttribute("voffset", t + "pt"), n.label === "\\fcolorbox") {
        var a = Math.max(
          e.fontMetrics().fboxrule,
          // default
          e.minRuleThickness
          // user override
        );
        r.setAttribute("style", "border: " + a + "em solid " + String(n.borderColor));
      }
      break;
    case "\\xcancel":
      r.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  return n.backgroundColor && r.setAttribute("mathbackground", n.backgroundColor), r;
};
L({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "text"]
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n, i = J(e[0], "color-token").color, l = e[1];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: i,
      body: l
    };
  },
  htmlBuilder: Vn,
  mathmlBuilder: Gn
});
L({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: !0,
    argTypes: ["color", "color", "text"]
  },
  handler(n, e, t) {
    var {
      parser: r,
      funcName: a
    } = n, i = J(e[0], "color-token").color, l = J(e[1], "color-token").color, o = e[2];
    return {
      type: "enclose",
      mode: r.mode,
      label: a,
      backgroundColor: l,
      borderColor: i,
      body: o
    };
  },
  htmlBuilder: Vn,
  mathmlBuilder: Gn
});
L({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\fbox",
      body: e[0]
    };
  }
});
L({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "enclose",
      mode: t.mode,
      label: r,
      body: a
    };
  },
  htmlBuilder: Vn,
  mathmlBuilder: Gn
});
L({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\angl",
      body: e[0]
    };
  }
});
var Fl = {};
function Mt(n) {
  for (var {
    type: e,
    names: t,
    props: r,
    handler: a,
    htmlBuilder: i,
    mathmlBuilder: l
  } = n, o = {
    type: e,
    numArgs: r.numArgs || 0,
    allowedInText: !1,
    numOptionalArgs: 0,
    handler: a
  }, c = 0; c < t.length; ++c)
    Fl[t[c]] = o;
  i && (Ar[e] = i), l && ($r[e] = l);
}
var _1 = {};
function f(n, e) {
  _1[n] = e;
}
function Ya(n) {
  var e = [];
  n.consumeSpaces();
  var t = n.fetch().text;
  for (t === "\\relax" && (n.consume(), n.consumeSpaces(), t = n.fetch().text); t === "\\hline" || t === "\\hdashline"; )
    n.consume(), e.push(t === "\\hdashline"), n.consumeSpaces(), t = n.fetch().text;
  return e;
}
var Lr = (n) => {
  var e = n.parser.settings;
  if (!e.displayMode)
    throw new G("{" + n.envName + "} can be used only in display mode.");
};
function Yn(n) {
  if (n.indexOf("ed") === -1)
    return n.indexOf("*") === -1;
}
function r0(n, e, t) {
  var {
    hskipBeforeAndAfter: r,
    addJot: a,
    cols: i,
    arraystretch: l,
    colSeparationType: o,
    autoTag: c,
    singleRow: m,
    emptySingleRow: d,
    maxNumCols: p,
    leqno: y
  } = e;
  if (n.gullet.beginGroup(), m || n.gullet.macros.set("\\cr", "\\\\\\relax"), !l) {
    var v = n.gullet.expandMacroAsText("\\arraystretch");
    if (v == null)
      l = 1;
    else if (l = parseFloat(v), !l || l < 0)
      throw new G("Invalid \\arraystretch: " + v);
  }
  n.gullet.beginGroup();
  var x = [], S = [x], F = [], E = [], D = c != null ? [] : void 0;
  function g() {
    c && n.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function A() {
    D && (n.gullet.macros.get("\\df@tag") ? (D.push(n.subparse([new qn("\\df@tag")])), n.gullet.macros.set("\\df@tag", void 0, !0)) : D.push(!!c && n.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (g(), E.push(Ya(n)); ; ) {
    var C = n.parseExpression(!1, m ? "\\end" : "\\\\");
    n.gullet.endGroup(), n.gullet.beginGroup(), C = {
      type: "ordgroup",
      mode: n.mode,
      body: C
    }, t && (C = {
      type: "styling",
      mode: n.mode,
      style: t,
      body: [C]
    }), x.push(C);
    var T = n.fetch().text;
    if (T === "&") {
      if (p && x.length === p) {
        if (m || o)
          throw new G("Too many tab characters: &", n.nextToken);
        n.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      n.consume();
    } else if (T === "\\end") {
      A(), x.length === 1 && C.type === "styling" && C.body[0].body.length === 0 && (S.length > 1 || !d) && S.pop(), E.length < S.length + 1 && E.push([]);
      break;
    } else if (T === "\\\\") {
      n.consume();
      var z = void 0;
      n.gullet.future().text !== " " && (z = n.parseSizeGroup(!0)), F.push(z ? z.value : null), A(), E.push(Ya(n)), x = [], S.push(x), g();
    } else
      throw new G("Expected & or \\\\ or \\cr or \\end", n.nextToken);
  }
  return n.gullet.endGroup(), n.gullet.endGroup(), {
    type: "array",
    mode: n.mode,
    addJot: a,
    arraystretch: l,
    body: S,
    cols: i,
    rowGaps: F,
    hskipBeforeAndAfter: r,
    hLinesBeforeRow: E,
    colSeparationType: o,
    tags: D,
    leqno: y
  };
}
function Wn(n) {
  return n.slice(0, 1) === "d" ? "display" : "text";
}
var zt = function(e, t) {
  var r, a, i = e.body.length, l = e.hLinesBeforeRow, o = 0, c = new Array(i), m = [], d = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    t.fontMetrics().arrayRuleWidth,
    t.minRuleThickness
    // User override.
  ), p = 1 / t.fontMetrics().ptPerEm, y = 5 * p;
  if (e.colSeparationType && e.colSeparationType === "small") {
    var v = t.havingStyle(X.SCRIPT).sizeMultiplier;
    y = 0.2778 * (v / t.sizeMultiplier);
  }
  var x = e.colSeparationType === "CD" ? ge({
    number: 3,
    unit: "ex"
  }, t) : 12 * p, S = 3 * p, F = e.arraystretch * x, E = 0.7 * F, D = 0.3 * F, g = 0;
  function A(Rt) {
    for (var Nt = 0; Nt < Rt.length; ++Nt)
      Nt > 0 && (g += 0.25), m.push({
        pos: g,
        isDashed: Rt[Nt]
      });
  }
  for (A(l[0]), r = 0; r < e.body.length; ++r) {
    var C = e.body[r], T = E, z = D;
    o < C.length && (o = C.length);
    var P = new Array(C.length);
    for (a = 0; a < C.length; ++a) {
      var R = ae(C[a], t);
      z < R.depth && (z = R.depth), T < R.height && (T = R.height), P[a] = R;
    }
    var Q = e.rowGaps[r], U = 0;
    Q && (U = ge(Q, t), U > 0 && (U += D, z < U && (z = U), U = 0)), e.addJot && (z += S), P.height = T, P.depth = z, g += T, P.pos = g, g += z + U, c[r] = P, A(l[r + 1]);
  }
  var ee = g / 2 + t.fontMetrics().axisHeight, Ce = e.cols || [], ie = [], ye, we, He = [];
  if (e.tags && e.tags.some((Rt) => Rt))
    for (r = 0; r < i; ++r) {
      var se = c[r], Ae = se.pos - ee, ke = e.tags[r], te = void 0;
      ke === !0 ? te = $.makeSpan(["eqn-num"], [], t) : ke === !1 ? te = $.makeSpan([], [], t) : te = $.makeSpan([], Te(ke, t, !0), t), te.depth = se.depth, te.height = se.height, He.push({
        type: "elem",
        elem: te,
        shift: Ae
      });
    }
  for (
    a = 0, we = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    a < o || we < Ce.length;
    ++a, ++we
  ) {
    for (var le = Ce[we] || {}, ce = !0; le.type === "separator"; ) {
      if (ce || (ye = $.makeSpan(["arraycolsep"], []), ye.style.width = I(t.fontMetrics().doubleRuleSep), ie.push(ye)), le.separator === "|" || le.separator === ":") {
        var Ee = le.separator === "|" ? "solid" : "dashed", N = $.makeSpan(["vertical-separator"], [], t);
        N.style.height = I(g), N.style.borderRightWidth = I(d), N.style.borderRightStyle = Ee, N.style.margin = "0 " + I(-d / 2);
        var Ge = g - ee;
        Ge && (N.style.verticalAlign = I(-Ge)), ie.push(N);
      } else
        throw new G("Invalid separator type: " + le.separator);
      we++, le = Ce[we] || {}, ce = !1;
    }
    if (!(a >= o)) {
      var qe = void 0;
      (a > 0 || e.hskipBeforeAndAfter) && (qe = j.deflt(le.pregap, y), qe !== 0 && (ye = $.makeSpan(["arraycolsep"], []), ye.style.width = I(qe), ie.push(ye)));
      var Ye = [];
      for (r = 0; r < i; ++r) {
        var st = c[r], ot = st[a];
        if (ot) {
          var qt = st.pos - ee;
          ot.depth = st.depth, ot.height = st.height, Ye.push({
            type: "elem",
            elem: ot,
            shift: qt
          });
        }
      }
      Ye = $.makeVList({
        positionType: "individualShift",
        children: Ye
      }, t), Ye = $.makeSpan(["col-align-" + (le.align || "c")], [Ye]), ie.push(Ye), (a < o - 1 || e.hskipBeforeAndAfter) && (qe = j.deflt(le.postgap, y), qe !== 0 && (ye = $.makeSpan(["arraycolsep"], []), ye.style.width = I(qe), ie.push(ye)));
    }
  }
  if (c = $.makeSpan(["mtable"], ie), m.length > 0) {
    for (var vt = $.makeLineSpan("hline", t, d), bt = $.makeLineSpan("hdashline", t, d), ut = [{
      type: "elem",
      elem: c,
      shift: 0
    }]; m.length > 0; ) {
      var m0 = m.pop(), h0 = m0.pos - ee;
      m0.isDashed ? ut.push({
        type: "elem",
        elem: bt,
        shift: h0
      }) : ut.push({
        type: "elem",
        elem: vt,
        shift: h0
      });
    }
    c = $.makeVList({
      positionType: "individualShift",
      children: ut
    }, t);
  }
  if (He.length === 0)
    return $.makeSpan(["mord"], [c], t);
  var yt = $.makeVList({
    positionType: "individualShift",
    children: He
  }, t);
  return yt = $.makeSpan(["tag"], [yt], t), $.makeFragment([c, yt]);
}, v1 = {
  c: "center ",
  l: "left ",
  r: "right "
}, Bt = function(e, t) {
  for (var r = [], a = new B.MathNode("mtd", [], ["mtr-glue"]), i = new B.MathNode("mtd", [], ["mml-eqn-num"]), l = 0; l < e.body.length; l++) {
    for (var o = e.body[l], c = [], m = 0; m < o.length; m++)
      c.push(new B.MathNode("mtd", [me(o[m], t)]));
    e.tags && e.tags[l] && (c.unshift(a), c.push(a), e.leqno ? c.unshift(i) : c.push(i)), r.push(new B.MathNode("mtr", c));
  }
  var d = new B.MathNode("mtable", r), p = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
  d.setAttribute("rowspacing", I(p));
  var y = "", v = "";
  if (e.cols && e.cols.length > 0) {
    var x = e.cols, S = "", F = !1, E = 0, D = x.length;
    x[0].type === "separator" && (y += "top ", E = 1), x[x.length - 1].type === "separator" && (y += "bottom ", D -= 1);
    for (var g = E; g < D; g++)
      x[g].type === "align" ? (v += v1[x[g].align], F && (S += "none "), F = !0) : x[g].type === "separator" && F && (S += x[g].separator === "|" ? "solid " : "dashed ", F = !1);
    d.setAttribute("columnalign", v.trim()), /[sd]/.test(S) && d.setAttribute("columnlines", S.trim());
  }
  if (e.colSeparationType === "align") {
    for (var A = e.cols || [], C = "", T = 1; T < A.length; T++)
      C += T % 2 ? "0em " : "1em ";
    d.setAttribute("columnspacing", C.trim());
  } else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? d.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? d.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? d.setAttribute("columnspacing", "0.5em") : d.setAttribute("columnspacing", "1em");
  var z = "", P = e.hLinesBeforeRow;
  y += P[0].length > 0 ? "left " : "", y += P[P.length - 1].length > 0 ? "right " : "";
  for (var R = 1; R < P.length - 1; R++)
    z += P[R].length === 0 ? "none " : P[R][0] ? "dashed " : "solid ";
  return /[sd]/.test(z) && d.setAttribute("rowlines", z.trim()), y !== "" && (d = new B.MathNode("menclose", [d]), d.setAttribute("notation", y.trim())), e.arraystretch && e.arraystretch < 1 && (d = new B.MathNode("mstyle", [d]), d.setAttribute("scriptlevel", "1")), d;
}, Cl = function(e, t) {
  e.envName.indexOf("ed") === -1 && Lr(e);
  var r = [], a = e.envName.indexOf("at") > -1 ? "alignat" : "align", i = e.envName === "split", l = r0(e.parser, {
    cols: r,
    addJot: !0,
    autoTag: i ? void 0 : Yn(e.envName),
    emptySingleRow: !0,
    colSeparationType: a,
    maxNumCols: i ? 2 : void 0,
    leqno: e.parser.settings.leqno
  }, "display"), o, c = 0, m = {
    type: "ordgroup",
    mode: e.mode,
    body: []
  };
  if (t[0] && t[0].type === "ordgroup") {
    for (var d = "", p = 0; p < t[0].body.length; p++) {
      var y = J(t[0].body[p], "textord");
      d += y.text;
    }
    o = Number(d), c = o * 2;
  }
  var v = !c;
  l.body.forEach(function(E) {
    for (var D = 1; D < E.length; D += 2) {
      var g = J(E[D], "styling"), A = J(g.body[0], "ordgroup");
      A.body.unshift(m);
    }
    if (v)
      c < E.length && (c = E.length);
    else {
      var C = E.length / 2;
      if (o < C)
        throw new G("Too many math in a row: " + ("expected " + o + ", but got " + C), E[0]);
    }
  });
  for (var x = 0; x < c; ++x) {
    var S = "r", F = 0;
    x % 2 === 1 ? S = "l" : x > 0 && v && (F = 1), r[x] = {
      type: "align",
      align: S,
      pregap: F,
      postgap: 0
    };
  }
  return l.colSeparationType = v ? "align" : "alignat", l;
};
Mt({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var t = Rr(e[0]), r = t ? [e[0]] : J(e[0], "ordgroup").body, a = r.map(function(l) {
      var o = Pn(l), c = o.text;
      if ("lcr".indexOf(c) !== -1)
        return {
          type: "align",
          align: c
        };
      if (c === "|")
        return {
          type: "separator",
          separator: "|"
        };
      if (c === ":")
        return {
          type: "separator",
          separator: ":"
        };
      throw new G("Unknown column alignment: " + c, l);
    }), i = {
      cols: a,
      hskipBeforeAndAfter: !0,
      // \@preamble in lttab.dtx
      maxNumCols: a.length
    };
    return r0(n.parser, i, Wn(n.envName));
  },
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
Mt({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      matrix: null,
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["\\{", "\\}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\\Vert", "\\Vert"]
    }[n.envName.replace("*", "")], t = "c", r = {
      hskipBeforeAndAfter: !1,
      cols: [{
        type: "align",
        align: t
      }]
    };
    if (n.envName.charAt(n.envName.length - 1) === "*") {
      var a = n.parser;
      if (a.consumeSpaces(), a.fetch().text === "[") {
        if (a.consume(), a.consumeSpaces(), t = a.fetch().text, "lcr".indexOf(t) === -1)
          throw new G("Expected l or c or r", a.nextToken);
        a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), r.cols = [{
          type: "align",
          align: t
        }];
      }
    }
    var i = r0(n.parser, r, Wn(n.envName)), l = Math.max(0, ...i.body.map((o) => o.length));
    return i.cols = new Array(l).fill({
      type: "align",
      align: t
    }), e ? {
      type: "leftright",
      mode: n.mode,
      body: [i],
      left: e[0],
      right: e[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : i;
  },
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
Mt({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      arraystretch: 0.5
    }, t = r0(n.parser, e, "script");
    return t.colSeparationType = "small", t;
  },
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
Mt({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var t = Rr(e[0]), r = t ? [e[0]] : J(e[0], "ordgroup").body, a = r.map(function(l) {
      var o = Pn(l), c = o.text;
      if ("lc".indexOf(c) !== -1)
        return {
          type: "align",
          align: c
        };
      throw new G("Unknown column alignment: " + c, l);
    });
    if (a.length > 1)
      throw new G("{subarray} can contain only one column");
    var i = {
      cols: a,
      hskipBeforeAndAfter: !1,
      arraystretch: 0.5
    };
    if (i = r0(n.parser, i, "script"), i.body.length > 0 && i.body[0].length > 1)
      throw new G("{subarray} can contain only one column");
    return i;
  },
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
Mt({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var e = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    }, t = r0(n.parser, e, Wn(n.envName));
    return {
      type: "leftright",
      mode: n.mode,
      body: [t],
      left: n.envName.indexOf("r") > -1 ? "." : "\\{",
      right: n.envName.indexOf("r") > -1 ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
Mt({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: Cl,
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
Mt({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    j.contains(["gather", "gather*"], n.envName) && Lr(n);
    var e = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: Yn(n.envName),
      emptySingleRow: !0,
      leqno: n.parser.settings.leqno
    };
    return r0(n.parser, e, "display");
  },
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
Mt({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: Cl,
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
Mt({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(n) {
    Lr(n);
    var e = {
      autoTag: Yn(n.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: n.parser.settings.leqno
    };
    return r0(n.parser, e, "display");
  },
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
Mt({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(n) {
    return Lr(n), n1(n.parser);
  },
  htmlBuilder: zt,
  mathmlBuilder: Bt
});
f("\\nonumber", "\\gdef\\@eqnsw{0}");
f("\\notag", "\\nonumber");
L({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !0
  },
  handler(n, e) {
    throw new G(n.funcName + " valid only within array environment");
  }
});
var Wa = Fl;
L({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    if (a.type !== "ordgroup")
      throw new G("Invalid environment name", a);
    for (var i = "", l = 0; l < a.body.length; ++l)
      i += J(a.body[l], "textord").text;
    if (r === "\\begin") {
      if (!Wa.hasOwnProperty(i))
        throw new G("No such environment: " + i, a);
      var o = Wa[i], {
        args: c,
        optArgs: m
      } = t.parseArguments("\\begin{" + i + "}", o), d = {
        mode: t.mode,
        envName: i,
        parser: t
      }, p = o.handler(d, c, m);
      t.expect("\\end", !1);
      var y = t.nextToken, v = J(t.parseFunction(), "environment");
      if (v.name !== i)
        throw new G("Mismatch: \\begin{" + i + "} matched by \\end{" + v.name + "}", y);
      return p;
    }
    return {
      type: "environment",
      mode: t.mode,
      name: i,
      nameGroup: a
    };
  }
});
var El = (n, e) => {
  var t = n.font, r = e.withFont(t);
  return ae(n.body, r);
}, Tl = (n, e) => {
  var t = n.font, r = e.withFont(t);
  return me(n.body, r);
}, ja = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
L({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    "\\mathsfit",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = Fr(e[0]), i = r;
    return i in ja && (i = ja[i]), {
      type: "font",
      mode: t.mode,
      font: i.slice(1),
      body: a
    };
  },
  htmlBuilder: El,
  mathmlBuilder: Tl
});
L({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0], a = j.isCharacterBox(r);
    return {
      type: "mclass",
      mode: t.mode,
      mclass: Nr(r),
      body: [{
        type: "font",
        mode: t.mode,
        font: "boldsymbol",
        body: r
      }],
      isCharacterBox: a
    };
  }
});
L({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r,
      breakOnTokenText: a
    } = n, {
      mode: i
    } = t, l = t.parseExpression(!0, a), o = "math" + r.slice(1);
    return {
      type: "font",
      mode: i,
      font: o,
      body: {
        type: "ordgroup",
        mode: t.mode,
        body: l
      }
    };
  },
  htmlBuilder: El,
  mathmlBuilder: Tl
});
var Ml = (n, e) => {
  var t = e;
  return n === "display" ? t = t.id >= X.SCRIPT.id ? t.text() : X.DISPLAY : n === "text" && t.size === X.DISPLAY.size ? t = X.TEXT : n === "script" ? t = X.SCRIPT : n === "scriptscript" && (t = X.SCRIPTSCRIPT), t;
}, jn = (n, e) => {
  var t = Ml(n.size, e.style), r = t.fracNum(), a = t.fracDen(), i;
  i = e.havingStyle(r);
  var l = ae(n.numer, i, e);
  if (n.continued) {
    var o = 8.5 / e.fontMetrics().ptPerEm, c = 3.5 / e.fontMetrics().ptPerEm;
    l.height = l.height < o ? o : l.height, l.depth = l.depth < c ? c : l.depth;
  }
  i = e.havingStyle(a);
  var m = ae(n.denom, i, e), d, p, y;
  n.hasBarLine ? (n.barSize ? (p = ge(n.barSize, e), d = $.makeLineSpan("frac-line", e, p)) : d = $.makeLineSpan("frac-line", e), p = d.height, y = d.height) : (d = null, p = 0, y = e.fontMetrics().defaultRuleThickness);
  var v, x, S;
  t.size === X.DISPLAY.size || n.size === "display" ? (v = e.fontMetrics().num1, p > 0 ? x = 3 * y : x = 7 * y, S = e.fontMetrics().denom1) : (p > 0 ? (v = e.fontMetrics().num2, x = y) : (v = e.fontMetrics().num3, x = 3 * y), S = e.fontMetrics().denom2);
  var F;
  if (d) {
    var D = e.fontMetrics().axisHeight;
    v - l.depth - (D + 0.5 * p) < x && (v += x - (v - l.depth - (D + 0.5 * p))), D - 0.5 * p - (m.height - S) < x && (S += x - (D - 0.5 * p - (m.height - S)));
    var g = -(D - 0.5 * p);
    F = $.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: m,
        shift: S
      }, {
        type: "elem",
        elem: d,
        shift: g
      }, {
        type: "elem",
        elem: l,
        shift: -v
      }]
    }, e);
  } else {
    var E = v - l.depth - (m.height - S);
    E < x && (v += 0.5 * (x - E), S += 0.5 * (x - E)), F = $.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: m,
        shift: S
      }, {
        type: "elem",
        elem: l,
        shift: -v
      }]
    }, e);
  }
  i = e.havingStyle(t), F.height *= i.sizeMultiplier / e.sizeMultiplier, F.depth *= i.sizeMultiplier / e.sizeMultiplier;
  var A;
  t.size === X.DISPLAY.size ? A = e.fontMetrics().delim1 : t.size === X.SCRIPTSCRIPT.size ? A = e.havingStyle(X.SCRIPT).fontMetrics().delim2 : A = e.fontMetrics().delim2;
  var C, T;
  return n.leftDelim == null ? C = G0(e, ["mopen"]) : C = Yt.customSizedDelim(n.leftDelim, A, !0, e.havingStyle(t), n.mode, ["mopen"]), n.continued ? T = $.makeSpan([]) : n.rightDelim == null ? T = G0(e, ["mclose"]) : T = Yt.customSizedDelim(n.rightDelim, A, !0, e.havingStyle(t), n.mode, ["mclose"]), $.makeSpan(["mord"].concat(i.sizingClasses(e)), [C, $.makeSpan(["mfrac"], [F]), T], e);
}, Xn = (n, e) => {
  var t = new B.MathNode("mfrac", [me(n.numer, e), me(n.denom, e)]);
  if (!n.hasBarLine)
    t.setAttribute("linethickness", "0px");
  else if (n.barSize) {
    var r = ge(n.barSize, e);
    t.setAttribute("linethickness", I(r));
  }
  var a = Ml(n.size, e.style);
  if (a.size !== e.style.size) {
    t = new B.MathNode("mstyle", [t]);
    var i = a.size === X.DISPLAY.size ? "true" : "false";
    t.setAttribute("displaystyle", i), t.setAttribute("scriptlevel", "0");
  }
  if (n.leftDelim != null || n.rightDelim != null) {
    var l = [];
    if (n.leftDelim != null) {
      var o = new B.MathNode("mo", [new B.TextNode(n.leftDelim.replace("\\", ""))]);
      o.setAttribute("fence", "true"), l.push(o);
    }
    if (l.push(t), n.rightDelim != null) {
      var c = new B.MathNode("mo", [new B.TextNode(n.rightDelim.replace("\\", ""))]);
      c.setAttribute("fence", "true"), l.push(c);
    }
    return Ln(l);
  }
  return t;
};
L({
  type: "genfrac",
  names: [
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = e[1], l, o = null, c = null, m = "auto";
    switch (r) {
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        l = !0;
        break;
      case "\\\\atopfrac":
        l = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        l = !1, o = "(", c = ")";
        break;
      case "\\\\bracefrac":
        l = !1, o = "\\{", c = "\\}";
        break;
      case "\\\\brackfrac":
        l = !1, o = "[", c = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    switch (r) {
      case "\\dfrac":
      case "\\dbinom":
        m = "display";
        break;
      case "\\tfrac":
      case "\\tbinom":
        m = "text";
        break;
    }
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !1,
      numer: a,
      denom: i,
      hasBarLine: l,
      leftDelim: o,
      rightDelim: c,
      size: m,
      barSize: null
    };
  },
  htmlBuilder: jn,
  mathmlBuilder: Xn
});
L({
  type: "genfrac",
  names: ["\\cfrac"],
  props: {
    numArgs: 2
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = e[1];
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !0,
      numer: a,
      denom: i,
      hasBarLine: !0,
      leftDelim: null,
      rightDelim: null,
      size: "display",
      barSize: null
    };
  }
});
L({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: !0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t,
      token: r
    } = n, a;
    switch (t) {
      case "\\over":
        a = "\\frac";
        break;
      case "\\choose":
        a = "\\binom";
        break;
      case "\\atop":
        a = "\\\\atopfrac";
        break;
      case "\\brace":
        a = "\\\\bracefrac";
        break;
      case "\\brack":
        a = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: e.mode,
      replaceWith: a,
      token: r
    };
  }
});
var Xa = ["display", "text", "script", "scriptscript"], Za = function(e) {
  var t = null;
  return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
L({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: !0,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = e[4], a = e[5], i = Fr(e[0]), l = i.type === "atom" && i.family === "open" ? Za(i.text) : null, o = Fr(e[1]), c = o.type === "atom" && o.family === "close" ? Za(o.text) : null, m = J(e[2], "size"), d, p = null;
    m.isBlank ? d = !0 : (p = m.value, d = p.number > 0);
    var y = "auto", v = e[3];
    if (v.type === "ordgroup") {
      if (v.body.length > 0) {
        var x = J(v.body[0], "textord");
        y = Xa[Number(x.text)];
      }
    } else
      v = J(v, "textord"), y = Xa[Number(v.text)];
    return {
      type: "genfrac",
      mode: t.mode,
      numer: r,
      denom: a,
      continued: !1,
      hasBarLine: d,
      barSize: p,
      leftDelim: l,
      rightDelim: c,
      size: y
    };
  },
  htmlBuilder: jn,
  mathmlBuilder: Xn
});
L({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r,
      token: a
    } = n;
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: "\\\\abovefrac",
      size: J(e[0], "size").value,
      token: a
    };
  }
});
L({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0], i = Ks(J(e[1], "infix").size), l = e[2], o = i.number > 0;
    return {
      type: "genfrac",
      mode: t.mode,
      numer: a,
      denom: l,
      continued: !1,
      hasBarLine: o,
      barSize: i,
      leftDelim: null,
      rightDelim: null,
      size: "auto"
    };
  },
  htmlBuilder: jn,
  mathmlBuilder: Xn
});
var zl = (n, e) => {
  var t = e.style, r, a;
  n.type === "supsub" ? (r = n.sup ? ae(n.sup, e.havingStyle(t.sup()), e) : ae(n.sub, e.havingStyle(t.sub()), e), a = J(n.base, "horizBrace")) : a = J(n, "horizBrace");
  var i = ae(a.base, e.havingBaseStyle(X.DISPLAY)), l = Wt.svgSpan(a, e), o;
  if (a.isOver ? (o = $.makeVList({
    positionType: "firstBaseline",
    children: [{
      type: "elem",
      elem: i
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: l
    }]
  }, e), o.children[0].children[0].children[1].classes.push("svg-align")) : (o = $.makeVList({
    positionType: "bottom",
    positionData: i.depth + 0.1 + l.height,
    children: [{
      type: "elem",
      elem: l
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: i
    }]
  }, e), o.children[0].children[0].children[0].classes.push("svg-align")), r) {
    var c = $.makeSpan(["mord", a.isOver ? "mover" : "munder"], [o], e);
    a.isOver ? o = $.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: c
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: r
      }]
    }, e) : o = $.makeVList({
      positionType: "bottom",
      positionData: c.depth + 0.2 + r.height + r.depth,
      children: [{
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: c
      }]
    }, e);
  }
  return $.makeSpan(["mord", a.isOver ? "mover" : "munder"], [o], e);
}, b1 = (n, e) => {
  var t = Wt.mathMLnode(n.label);
  return new B.MathNode(n.isOver ? "mover" : "munder", [me(n.base, e), t]);
};
L({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n;
    return {
      type: "horizBrace",
      mode: t.mode,
      label: r,
      isOver: /^\\over/.test(r),
      base: e[0]
    };
  },
  htmlBuilder: zl,
  mathmlBuilder: b1
});
L({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[1], a = J(e[0], "url").url;
    return t.settings.isTrusted({
      command: "\\href",
      url: a
    }) ? {
      type: "href",
      mode: t.mode,
      href: a,
      body: De(r)
    } : t.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (n, e) => {
    var t = Te(n.body, e, !1);
    return $.makeAnchor(n.href, [], t, e);
  },
  mathmlBuilder: (n, e) => {
    var t = t0(n.body, e);
    return t instanceof Je || (t = new Je("mrow", [t])), t.setAttribute("href", n.href), t;
  }
});
L({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = J(e[0], "url").url;
    if (!t.settings.isTrusted({
      command: "\\url",
      url: r
    }))
      return t.formatUnsupportedCmd("\\url");
    for (var a = [], i = 0; i < r.length; i++) {
      var l = r[i];
      l === "~" && (l = "\\textasciitilde"), a.push({
        type: "textord",
        mode: "text",
        text: l
      });
    }
    var o = {
      type: "text",
      mode: t.mode,
      font: "\\texttt",
      body: a
    };
    return {
      type: "href",
      mode: t.mode,
      href: r,
      body: De(o)
    };
  }
});
L({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: !0,
    primitive: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "hbox",
      mode: t.mode,
      body: De(e[0])
    };
  },
  htmlBuilder(n, e) {
    var t = Te(n.body, e, !1);
    return $.makeFragment(t);
  },
  mathmlBuilder(n, e) {
    return new B.MathNode("mrow", Ze(n.body, e));
  }
});
L({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r,
      token: a
    } = n, i = J(e[0], "raw").string, l = e[1];
    t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var o, c = {};
    switch (r) {
      case "\\htmlClass":
        c.class = i, o = {
          command: "\\htmlClass",
          class: i
        };
        break;
      case "\\htmlId":
        c.id = i, o = {
          command: "\\htmlId",
          id: i
        };
        break;
      case "\\htmlStyle":
        c.style = i, o = {
          command: "\\htmlStyle",
          style: i
        };
        break;
      case "\\htmlData": {
        for (var m = i.split(","), d = 0; d < m.length; d++) {
          var p = m[d].split("=");
          if (p.length !== 2)
            throw new G("Error parsing key-value for \\htmlData");
          c["data-" + p[0].trim()] = p[1].trim();
        }
        o = {
          command: "\\htmlData",
          attributes: c
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    return t.settings.isTrusted(o) ? {
      type: "html",
      mode: t.mode,
      attributes: c,
      body: De(l)
    } : t.formatUnsupportedCmd(r);
  },
  htmlBuilder: (n, e) => {
    var t = Te(n.body, e, !1), r = ["enclosing"];
    n.attributes.class && r.push(...n.attributes.class.trim().split(/\s+/));
    var a = $.makeSpan(r, t, e);
    for (var i in n.attributes)
      i !== "class" && n.attributes.hasOwnProperty(i) && a.setAttribute(i, n.attributes[i]);
    return a;
  },
  mathmlBuilder: (n, e) => t0(n.body, e)
});
L({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n;
    return {
      type: "htmlmathml",
      mode: t.mode,
      html: De(e[0]),
      mathml: De(e[1])
    };
  },
  htmlBuilder: (n, e) => {
    var t = Te(n.html, e, !1);
    return $.makeFragment(t);
  },
  mathmlBuilder: (n, e) => t0(n.mathml, e)
});
var an = function(e) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return {
      number: +e,
      unit: "bp"
    };
  var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
  if (!t)
    throw new G("Invalid size: '" + e + "' in \\includegraphics");
  var r = {
    number: +(t[1] + t[2]),
    // sign + magnitude, cast to number
    unit: t[3]
  };
  if (!bo(r))
    throw new G("Invalid unit: '" + r.unit + "' in \\includegraphics.");
  return r;
};
L({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: !1
  },
  handler: (n, e, t) => {
    var {
      parser: r
    } = n, a = {
      number: 0,
      unit: "em"
    }, i = {
      number: 0.9,
      unit: "em"
    }, l = {
      number: 0,
      unit: "em"
    }, o = "";
    if (t[0])
      for (var c = J(t[0], "raw").string, m = c.split(","), d = 0; d < m.length; d++) {
        var p = m[d].split("=");
        if (p.length === 2) {
          var y = p[1].trim();
          switch (p[0].trim()) {
            case "alt":
              o = y;
              break;
            case "width":
              a = an(y);
              break;
            case "height":
              i = an(y);
              break;
            case "totalheight":
              l = an(y);
              break;
            default:
              throw new G("Invalid key: '" + p[0] + "' in \\includegraphics.");
          }
        }
      }
    var v = J(e[0], "url").url;
    return o === "" && (o = v, o = o.replace(/^.*[\\/]/, ""), o = o.substring(0, o.lastIndexOf("."))), r.settings.isTrusted({
      command: "\\includegraphics",
      url: v
    }) ? {
      type: "includegraphics",
      mode: r.mode,
      alt: o,
      width: a,
      height: i,
      totalheight: l,
      src: v
    } : r.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (n, e) => {
    var t = ge(n.height, e), r = 0;
    n.totalheight.number > 0 && (r = ge(n.totalheight, e) - t);
    var a = 0;
    n.width.number > 0 && (a = ge(n.width, e));
    var i = {
      height: I(t + r)
    };
    a > 0 && (i.width = I(a)), r > 0 && (i.verticalAlign = I(-r));
    var l = new wo(n.src, n.alt, i);
    return l.height = t, l.depth = r, l;
  },
  mathmlBuilder: (n, e) => {
    var t = new B.MathNode("mglyph", []);
    t.setAttribute("alt", n.alt);
    var r = ge(n.height, e), a = 0;
    if (n.totalheight.number > 0 && (a = ge(n.totalheight, e) - r, t.setAttribute("valign", I(-a))), t.setAttribute("height", I(r + a)), n.width.number > 0) {
      var i = ge(n.width, e);
      t.setAttribute("width", I(i));
    }
    return t.setAttribute("src", n.src), t;
  }
});
L({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: !0,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = J(e[0], "size");
    if (t.settings.strict) {
      var i = r[1] === "m", l = a.value.unit === "mu";
      i ? (l || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " supports only mu units, " + ("not " + a.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " works only in math mode")) : l && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + r + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: t.mode,
      dimension: a.value
    };
  },
  htmlBuilder(n, e) {
    return $.makeGlue(n.dimension, e);
  },
  mathmlBuilder(n, e) {
    var t = ge(n.dimension, e);
    return new B.SpaceNode(t);
  }
});
L({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "lap",
      mode: t.mode,
      alignment: r.slice(5),
      body: a
    };
  },
  htmlBuilder: (n, e) => {
    var t;
    n.alignment === "clap" ? (t = $.makeSpan([], [ae(n.body, e)]), t = $.makeSpan(["inner"], [t], e)) : t = $.makeSpan(["inner"], [ae(n.body, e)]);
    var r = $.makeSpan(["fix"], []), a = $.makeSpan([n.alignment], [t, r], e), i = $.makeSpan(["strut"]);
    return i.style.height = I(a.height + a.depth), a.depth && (i.style.verticalAlign = I(-a.depth)), a.children.unshift(i), a = $.makeSpan(["thinbox"], [a], e), $.makeSpan(["mord", "vbox"], [a], e);
  },
  mathmlBuilder: (n, e) => {
    var t = new B.MathNode("mpadded", [me(n.body, e)]);
    if (n.alignment !== "rlap") {
      var r = n.alignment === "llap" ? "-1" : "-0.5";
      t.setAttribute("lspace", r + "width");
    }
    return t.setAttribute("width", "0px"), t;
  }
});
L({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(n, e) {
    var {
      funcName: t,
      parser: r
    } = n, a = r.mode;
    r.switchMode("math");
    var i = t === "\\(" ? "\\)" : "$", l = r.parseExpression(!1, i);
    return r.expect(i), r.switchMode(a), {
      type: "styling",
      mode: r.mode,
      style: "text",
      body: l
    };
  }
});
L({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(n, e) {
    throw new G("Mismatched " + n.funcName);
  }
});
var Ka = (n, e) => {
  switch (e.style.size) {
    case X.DISPLAY.size:
      return n.display;
    case X.TEXT.size:
      return n.text;
    case X.SCRIPT.size:
      return n.script;
    case X.SCRIPTSCRIPT.size:
      return n.scriptscript;
    default:
      return n.text;
  }
};
L({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n;
    return {
      type: "mathchoice",
      mode: t.mode,
      display: De(e[0]),
      text: De(e[1]),
      script: De(e[2]),
      scriptscript: De(e[3])
    };
  },
  htmlBuilder: (n, e) => {
    var t = Ka(n, e), r = Te(t, e, !1);
    return $.makeFragment(r);
  },
  mathmlBuilder: (n, e) => {
    var t = Ka(n, e);
    return t0(t, e);
  }
});
var Bl = (n, e, t, r, a, i, l) => {
  n = $.makeSpan([], [n]);
  var o = t && j.isCharacterBox(t), c, m;
  if (e) {
    var d = ae(e, r.havingStyle(a.sup()), r);
    m = {
      elem: d,
      kern: Math.max(r.fontMetrics().bigOpSpacing1, r.fontMetrics().bigOpSpacing3 - d.depth)
    };
  }
  if (t) {
    var p = ae(t, r.havingStyle(a.sub()), r);
    c = {
      elem: p,
      kern: Math.max(r.fontMetrics().bigOpSpacing2, r.fontMetrics().bigOpSpacing4 - p.height)
    };
  }
  var y;
  if (m && c) {
    var v = r.fontMetrics().bigOpSpacing5 + c.elem.height + c.elem.depth + c.kern + n.depth + l;
    y = $.makeVList({
      positionType: "bottom",
      positionData: v,
      children: [{
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: c.elem,
        marginLeft: I(-i)
      }, {
        type: "kern",
        size: c.kern
      }, {
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: m.kern
      }, {
        type: "elem",
        elem: m.elem,
        marginLeft: I(i)
      }, {
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }]
    }, r);
  } else if (c) {
    var x = n.height - l;
    y = $.makeVList({
      positionType: "top",
      positionData: x,
      children: [{
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: c.elem,
        marginLeft: I(-i)
      }, {
        type: "kern",
        size: c.kern
      }, {
        type: "elem",
        elem: n
      }]
    }, r);
  } else if (m) {
    var S = n.depth + l;
    y = $.makeVList({
      positionType: "bottom",
      positionData: S,
      children: [{
        type: "elem",
        elem: n
      }, {
        type: "kern",
        size: m.kern
      }, {
        type: "elem",
        elem: m.elem,
        marginLeft: I(i)
      }, {
        type: "kern",
        size: r.fontMetrics().bigOpSpacing5
      }]
    }, r);
  } else
    return n;
  var F = [y];
  if (c && i !== 0 && !o) {
    var E = $.makeSpan(["mspace"], [], r);
    E.style.marginRight = I(i), F.unshift(E);
  }
  return $.makeSpan(["mop", "op-limits"], F, r);
}, ql = ["\\smallint"], A0 = (n, e) => {
  var t, r, a = !1, i;
  n.type === "supsub" ? (t = n.sup, r = n.sub, i = J(n.base, "op"), a = !0) : i = J(n, "op");
  var l = e.style, o = !1;
  l.size === X.DISPLAY.size && i.symbol && !j.contains(ql, i.name) && (o = !0);
  var c;
  if (i.symbol) {
    var m = o ? "Size2-Regular" : "Size1-Regular", d = "";
    if ((i.name === "\\oiint" || i.name === "\\oiiint") && (d = i.name.slice(1), i.name = d === "oiint" ? "\\iint" : "\\iiint"), c = $.makeSymbol(i.name, m, "math", e, ["mop", "op-symbol", o ? "large-op" : "small-op"]), d.length > 0) {
      var p = c.italic, y = $.staticSvg(d + "Size" + (o ? "2" : "1"), e);
      c = $.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: c,
          shift: 0
        }, {
          type: "elem",
          elem: y,
          shift: o ? 0.08 : 0
        }]
      }, e), i.name = "\\" + d, c.classes.unshift("mop"), c.italic = p;
    }
  } else if (i.body) {
    var v = Te(i.body, e, !0);
    v.length === 1 && v[0] instanceof Tt ? (c = v[0], c.classes[0] = "mop") : c = $.makeSpan(["mop"], v, e);
  } else {
    for (var x = [], S = 1; S < i.name.length; S++)
      x.push($.mathsym(i.name[S], i.mode, e));
    c = $.makeSpan(["mop"], x, e);
  }
  var F = 0, E = 0;
  return (c instanceof Tt || i.name === "\\oiint" || i.name === "\\oiiint") && !i.suppressBaseShift && (F = (c.height - c.depth) / 2 - e.fontMetrics().axisHeight, E = c.italic), a ? Bl(c, t, r, e, l, E, F) : (F && (c.style.position = "relative", c.style.top = I(F)), c);
}, W0 = (n, e) => {
  var t;
  if (n.symbol)
    t = new Je("mo", [nt(n.name, n.mode)]), j.contains(ql, n.name) && t.setAttribute("largeop", "false");
  else if (n.body)
    t = new Je("mo", Ze(n.body, e));
  else {
    t = new Je("mi", [new xt(n.name.slice(1))]);
    var r = new Je("mo", [nt("⁡", "text")]);
    n.parentIsSupSub ? t = new Je("mrow", [t, r]) : t = hl([t, r]);
  }
  return t;
}, y1 = {
  "∏": "\\prod",
  "∐": "\\coprod",
  "∑": "\\sum",
  "⋀": "\\bigwedge",
  "⋁": "\\bigvee",
  "⋂": "\\bigcap",
  "⋃": "\\bigcup",
  "⨀": "\\bigodot",
  "⨁": "\\bigoplus",
  "⨂": "\\bigotimes",
  "⨄": "\\biguplus",
  "⨆": "\\bigsqcup"
};
L({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  props: {
    numArgs: 0
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = r;
    return a.length === 1 && (a = y1[a]), {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: A0,
  mathmlBuilder: W0
});
L({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: De(r)
    };
  },
  htmlBuilder: A0,
  mathmlBuilder: W0
});
var w1 = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
L({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    return {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: A0,
  mathmlBuilder: W0
});
L({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n;
    return {
      type: "op",
      mode: e.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: A0,
  mathmlBuilder: W0
});
L({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  props: {
    numArgs: 0
  },
  handler(n) {
    var {
      parser: e,
      funcName: t
    } = n, r = t;
    return r.length === 1 && (r = w1[r]), {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: r
    };
  },
  htmlBuilder: A0,
  mathmlBuilder: W0
});
var Rl = (n, e) => {
  var t, r, a = !1, i;
  n.type === "supsub" ? (t = n.sup, r = n.sub, i = J(n.base, "operatorname"), a = !0) : i = J(n, "operatorname");
  var l;
  if (i.body.length > 0) {
    for (var o = i.body.map((p) => {
      var y = p.text;
      return typeof y == "string" ? {
        type: "textord",
        mode: p.mode,
        text: y
      } : p;
    }), c = Te(o, e.withFont("mathrm"), !0), m = 0; m < c.length; m++) {
      var d = c[m];
      d instanceof Tt && (d.text = d.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    l = $.makeSpan(["mop"], c, e);
  } else
    l = $.makeSpan(["mop"], [], e);
  return a ? Bl(l, t, r, e, e.style, 0, 0) : l;
}, k1 = (n, e) => {
  for (var t = Ze(n.body, e.withFont("mathrm")), r = !0, a = 0; a < t.length; a++) {
    var i = t[a];
    if (!(i instanceof B.SpaceNode)) if (i instanceof B.MathNode)
      switch (i.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        case "mo": {
          var l = i.children[0];
          i.children.length === 1 && l instanceof B.TextNode ? l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : r = !1;
          break;
        }
        default:
          r = !1;
      }
    else
      r = !1;
  }
  if (r) {
    var o = t.map((d) => d.toText()).join("");
    t = [new B.TextNode(o)];
  }
  var c = new B.MathNode("mi", t);
  c.setAttribute("mathvariant", "normal");
  var m = new B.MathNode("mo", [nt("⁡", "text")]);
  return n.parentIsSupSub ? new B.MathNode("mrow", [c, m]) : B.newDocumentFragment([c, m]);
};
L({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (n, e) => {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "operatorname",
      mode: t.mode,
      body: De(a),
      alwaysHandleSupSub: r === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: Rl,
  mathmlBuilder: k1
});
f("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
u0({
  type: "ordgroup",
  htmlBuilder(n, e) {
    return n.semisimple ? $.makeFragment(Te(n.body, e, !1)) : $.makeSpan(["mord"], Te(n.body, e, !0), e);
  },
  mathmlBuilder(n, e) {
    return t0(n.body, e, !0);
  }
});
L({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "overline",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder(n, e) {
    var t = ae(n.body, e.havingCrampedStyle()), r = $.makeLineSpan("overline-line", e), a = e.fontMetrics().defaultRuleThickness, i = $.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: a
      }]
    }, e);
    return $.makeSpan(["mord", "overline"], [i], e);
  },
  mathmlBuilder(n, e) {
    var t = new B.MathNode("mo", [new B.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var r = new B.MathNode("mover", [me(n.body, e), t]);
    return r.setAttribute("accent", "true"), r;
  }
});
L({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "phantom",
      mode: t.mode,
      body: De(r)
    };
  },
  htmlBuilder: (n, e) => {
    var t = Te(n.body, e.withPhantom(), !1);
    return $.makeFragment(t);
  },
  mathmlBuilder: (n, e) => {
    var t = Ze(n.body, e);
    return new B.MathNode("mphantom", t);
  }
});
L({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "hphantom",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder: (n, e) => {
    var t = $.makeSpan([], [ae(n.body, e.withPhantom())]);
    if (t.height = 0, t.depth = 0, t.children)
      for (var r = 0; r < t.children.length; r++)
        t.children[r].height = 0, t.children[r].depth = 0;
    return t = $.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e), $.makeSpan(["mord"], [t], e);
  },
  mathmlBuilder: (n, e) => {
    var t = Ze(De(n.body), e), r = new B.MathNode("mphantom", t), a = new B.MathNode("mpadded", [r]);
    return a.setAttribute("height", "0px"), a.setAttribute("depth", "0px"), a;
  }
});
L({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      parser: t
    } = n, r = e[0];
    return {
      type: "vphantom",
      mode: t.mode,
      body: r
    };
  },
  htmlBuilder: (n, e) => {
    var t = $.makeSpan(["inner"], [ae(n.body, e.withPhantom())]), r = $.makeSpan(["fix"], []);
    return $.makeSpan(["mord", "rlap"], [t, r], e);
  },
  mathmlBuilder: (n, e) => {
    var t = Ze(De(n.body), e), r = new B.MathNode("mphantom", t), a = new B.MathNode("mpadded", [r]);
    return a.setAttribute("width", "0px"), a;
  }
});
L({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n, r = J(e[0], "size").value, a = e[1];
    return {
      type: "raisebox",
      mode: t.mode,
      dy: r,
      body: a
    };
  },
  htmlBuilder(n, e) {
    var t = ae(n.body, e), r = ge(n.dy, e);
    return $.makeVList({
      positionType: "shift",
      positionData: -r,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(n, e) {
    var t = new B.MathNode("mpadded", [me(n.body, e)]), r = n.dy.number + n.dy.unit;
    return t.setAttribute("voffset", r), t;
  }
});
L({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInArgument: !0
  },
  handler(n) {
    var {
      parser: e
    } = n;
    return {
      type: "internal",
      mode: e.mode
    };
  }
});
L({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    argTypes: ["size", "size", "size"]
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = t[0], i = J(e[0], "size"), l = J(e[1], "size");
    return {
      type: "rule",
      mode: r.mode,
      shift: a && J(a, "size").value,
      width: i.value,
      height: l.value
    };
  },
  htmlBuilder(n, e) {
    var t = $.makeSpan(["mord", "rule"], [], e), r = ge(n.width, e), a = ge(n.height, e), i = n.shift ? ge(n.shift, e) : 0;
    return t.style.borderRightWidth = I(r), t.style.borderTopWidth = I(a), t.style.bottom = I(i), t.width = r, t.height = a + i, t.depth = -i, t.maxFontSize = a * 1.125 * e.sizeMultiplier, t;
  },
  mathmlBuilder(n, e) {
    var t = ge(n.width, e), r = ge(n.height, e), a = n.shift ? ge(n.shift, e) : 0, i = e.color && e.getColor() || "black", l = new B.MathNode("mspace");
    l.setAttribute("mathbackground", i), l.setAttribute("width", I(t)), l.setAttribute("height", I(r));
    var o = new B.MathNode("mpadded", [l]);
    return a >= 0 ? o.setAttribute("height", I(a)) : (o.setAttribute("height", I(a)), o.setAttribute("depth", I(-a))), o.setAttribute("voffset", I(a)), o;
  }
});
function Nl(n, e, t) {
  for (var r = Te(n, e, !1), a = e.sizeMultiplier / t.sizeMultiplier, i = 0; i < r.length; i++) {
    var l = r[i].classes.indexOf("sizing");
    l < 0 ? Array.prototype.push.apply(r[i].classes, e.sizingClasses(t)) : r[i].classes[l + 1] === "reset-size" + e.size && (r[i].classes[l + 1] = "reset-size" + t.size), r[i].height *= a, r[i].depth *= a;
  }
  return $.makeFragment(r);
}
var Qa = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], D1 = (n, e) => {
  var t = e.havingSize(n.size);
  return Nl(n.body, t, e);
};
L({
  type: "sizing",
  names: Qa,
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (n, e) => {
    var {
      breakOnTokenText: t,
      funcName: r,
      parser: a
    } = n, i = a.parseExpression(!1, t);
    return {
      type: "sizing",
      mode: a.mode,
      // Figure out what size to use based on the list of functions above
      size: Qa.indexOf(r) + 1,
      body: i
    };
  },
  htmlBuilder: D1,
  mathmlBuilder: (n, e) => {
    var t = e.havingSize(n.size), r = Ze(n.body, t), a = new B.MathNode("mstyle", r);
    return a.setAttribute("mathsize", I(t.sizeMultiplier)), a;
  }
});
L({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: !0
  },
  handler: (n, e, t) => {
    var {
      parser: r
    } = n, a = !1, i = !1, l = t[0] && J(t[0], "ordgroup");
    if (l)
      for (var o = "", c = 0; c < l.body.length; ++c) {
        var m = l.body[c];
        if (o = m.text, o === "t")
          a = !0;
        else if (o === "b")
          i = !0;
        else {
          a = !1, i = !1;
          break;
        }
      }
    else
      a = !0, i = !0;
    var d = e[0];
    return {
      type: "smash",
      mode: r.mode,
      body: d,
      smashHeight: a,
      smashDepth: i
    };
  },
  htmlBuilder: (n, e) => {
    var t = $.makeSpan([], [ae(n.body, e)]);
    if (!n.smashHeight && !n.smashDepth)
      return t;
    if (n.smashHeight && (t.height = 0, t.children))
      for (var r = 0; r < t.children.length; r++)
        t.children[r].height = 0;
    if (n.smashDepth && (t.depth = 0, t.children))
      for (var a = 0; a < t.children.length; a++)
        t.children[a].depth = 0;
    var i = $.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
    return $.makeSpan(["mord"], [i], e);
  },
  mathmlBuilder: (n, e) => {
    var t = new B.MathNode("mpadded", [me(n.body, e)]);
    return n.smashHeight && t.setAttribute("height", "0px"), n.smashDepth && t.setAttribute("depth", "0px"), t;
  }
});
L({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(n, e, t) {
    var {
      parser: r
    } = n, a = t[0], i = e[0];
    return {
      type: "sqrt",
      mode: r.mode,
      body: i,
      index: a
    };
  },
  htmlBuilder(n, e) {
    var t = ae(n.body, e.havingCrampedStyle());
    t.height === 0 && (t.height = e.fontMetrics().xHeight), t = $.wrapFragment(t, e);
    var r = e.fontMetrics(), a = r.defaultRuleThickness, i = a;
    e.style.id < X.TEXT.id && (i = e.fontMetrics().xHeight);
    var l = a + i / 4, o = t.height + t.depth + l + a, {
      span: c,
      ruleWidth: m,
      advanceWidth: d
    } = Yt.sqrtImage(o, e), p = c.height - m;
    p > t.height + t.depth + l && (l = (l + p - t.height - t.depth) / 2);
    var y = c.height - t.height - l - m;
    t.style.paddingLeft = I(d);
    var v = $.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(t.height + y)
      }, {
        type: "elem",
        elem: c
      }, {
        type: "kern",
        size: m
      }]
    }, e);
    if (n.index) {
      var x = e.havingStyle(X.SCRIPTSCRIPT), S = ae(n.index, x, e), F = 0.6 * (v.height - v.depth), E = $.makeVList({
        positionType: "shift",
        positionData: -F,
        children: [{
          type: "elem",
          elem: S
        }]
      }, e), D = $.makeSpan(["root"], [E]);
      return $.makeSpan(["mord", "sqrt"], [D, v], e);
    } else
      return $.makeSpan(["mord", "sqrt"], [v], e);
  },
  mathmlBuilder(n, e) {
    var {
      body: t,
      index: r
    } = n;
    return r ? new B.MathNode("mroot", [me(t, e), me(r, e)]) : new B.MathNode("msqrt", [me(t, e)]);
  }
});
var Ja = {
  display: X.DISPLAY,
  text: X.TEXT,
  script: X.SCRIPT,
  scriptscript: X.SCRIPTSCRIPT
};
L({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(n, e) {
    var {
      breakOnTokenText: t,
      funcName: r,
      parser: a
    } = n, i = a.parseExpression(!0, t), l = r.slice(1, r.length - 5);
    return {
      type: "styling",
      mode: a.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style: l,
      body: i
    };
  },
  htmlBuilder(n, e) {
    var t = Ja[n.style], r = e.havingStyle(t).withFont("");
    return Nl(n.body, r, e);
  },
  mathmlBuilder(n, e) {
    var t = Ja[n.style], r = e.havingStyle(t), a = Ze(n.body, r), i = new B.MathNode("mstyle", a), l = {
      display: ["0", "true"],
      text: ["0", "false"],
      script: ["1", "false"],
      scriptscript: ["2", "false"]
    }, o = l[n.style];
    return i.setAttribute("scriptlevel", o[0]), i.setAttribute("displaystyle", o[1]), i;
  }
});
var x1 = function(e, t) {
  var r = e.base;
  if (r)
    if (r.type === "op") {
      var a = r.limits && (t.style.size === X.DISPLAY.size || r.alwaysHandleSupSub);
      return a ? A0 : null;
    } else if (r.type === "operatorname") {
      var i = r.alwaysHandleSupSub && (t.style.size === X.DISPLAY.size || r.limits);
      return i ? Rl : null;
    } else {
      if (r.type === "accent")
        return j.isCharacterBox(r.base) ? Hn : null;
      if (r.type === "horizBrace") {
        var l = !e.sub;
        return l === r.isOver ? zl : null;
      } else
        return null;
    }
  else return null;
};
u0({
  type: "supsub",
  htmlBuilder(n, e) {
    var t = x1(n, e);
    if (t)
      return t(n, e);
    var {
      base: r,
      sup: a,
      sub: i
    } = n, l = ae(r, e), o, c, m = e.fontMetrics(), d = 0, p = 0, y = r && j.isCharacterBox(r);
    if (a) {
      var v = e.havingStyle(e.style.sup());
      o = ae(a, v, e), y || (d = l.height - v.fontMetrics().supDrop * v.sizeMultiplier / e.sizeMultiplier);
    }
    if (i) {
      var x = e.havingStyle(e.style.sub());
      c = ae(i, x, e), y || (p = l.depth + x.fontMetrics().subDrop * x.sizeMultiplier / e.sizeMultiplier);
    }
    var S;
    e.style === X.DISPLAY ? S = m.sup1 : e.style.cramped ? S = m.sup3 : S = m.sup2;
    var F = e.sizeMultiplier, E = I(0.5 / m.ptPerEm / F), D = null;
    if (c) {
      var g = n.base && n.base.type === "op" && n.base.name && (n.base.name === "\\oiint" || n.base.name === "\\oiiint");
      (l instanceof Tt || g) && (D = I(-l.italic));
    }
    var A;
    if (o && c) {
      d = Math.max(d, S, o.depth + 0.25 * m.xHeight), p = Math.max(p, m.sub2);
      var C = m.defaultRuleThickness, T = 4 * C;
      if (d - o.depth - (c.height - p) < T) {
        p = T - (d - o.depth) + c.height;
        var z = 0.8 * m.xHeight - (d - o.depth);
        z > 0 && (d += z, p -= z);
      }
      var P = [{
        type: "elem",
        elem: c,
        shift: p,
        marginRight: E,
        marginLeft: D
      }, {
        type: "elem",
        elem: o,
        shift: -d,
        marginRight: E
      }];
      A = $.makeVList({
        positionType: "individualShift",
        children: P
      }, e);
    } else if (c) {
      p = Math.max(p, m.sub1, c.height - 0.8 * m.xHeight);
      var R = [{
        type: "elem",
        elem: c,
        marginLeft: D,
        marginRight: E
      }];
      A = $.makeVList({
        positionType: "shift",
        positionData: p,
        children: R
      }, e);
    } else if (o)
      d = Math.max(d, S, o.depth + 0.25 * m.xHeight), A = $.makeVList({
        positionType: "shift",
        positionData: -d,
        children: [{
          type: "elem",
          elem: o,
          marginRight: E
        }]
      }, e);
    else
      throw new Error("supsub must have either sup or sub.");
    var Q = wn(l, "right") || "mord";
    return $.makeSpan([Q], [l, $.makeSpan(["msupsub"], [A])], e);
  },
  mathmlBuilder(n, e) {
    var t = !1, r, a;
    n.base && n.base.type === "horizBrace" && (a = !!n.sup, a === n.base.isOver && (t = !0, r = n.base.isOver)), n.base && (n.base.type === "op" || n.base.type === "operatorname") && (n.base.parentIsSupSub = !0);
    var i = [me(n.base, e)];
    n.sub && i.push(me(n.sub, e)), n.sup && i.push(me(n.sup, e));
    var l;
    if (t)
      l = r ? "mover" : "munder";
    else if (n.sub)
      if (n.sup) {
        var m = n.base;
        m && m.type === "op" && m.limits && e.style === X.DISPLAY || m && m.type === "operatorname" && m.alwaysHandleSupSub && (e.style === X.DISPLAY || m.limits) ? l = "munderover" : l = "msubsup";
      } else {
        var c = n.base;
        c && c.type === "op" && c.limits && (e.style === X.DISPLAY || c.alwaysHandleSupSub) || c && c.type === "operatorname" && c.alwaysHandleSupSub && (c.limits || e.style === X.DISPLAY) ? l = "munder" : l = "msub";
      }
    else {
      var o = n.base;
      o && o.type === "op" && o.limits && (e.style === X.DISPLAY || o.alwaysHandleSupSub) || o && o.type === "operatorname" && o.alwaysHandleSupSub && (o.limits || e.style === X.DISPLAY) ? l = "mover" : l = "msup";
    }
    return new B.MathNode(l, i);
  }
});
u0({
  type: "atom",
  htmlBuilder(n, e) {
    return $.mathsym(n.text, n.mode, e, ["m" + n.family]);
  },
  mathmlBuilder(n, e) {
    var t = new B.MathNode("mo", [nt(n.text, n.mode)]);
    if (n.family === "bin") {
      var r = On(n, e);
      r === "bold-italic" && t.setAttribute("mathvariant", r);
    } else n.family === "punct" ? t.setAttribute("separator", "true") : (n.family === "open" || n.family === "close") && t.setAttribute("stretchy", "false");
    return t;
  }
});
var Il = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
u0({
  type: "mathord",
  htmlBuilder(n, e) {
    return $.makeOrd(n, e, "mathord");
  },
  mathmlBuilder(n, e) {
    var t = new B.MathNode("mi", [nt(n.text, n.mode, e)]), r = On(n, e) || "italic";
    return r !== Il[t.type] && t.setAttribute("mathvariant", r), t;
  }
});
u0({
  type: "textord",
  htmlBuilder(n, e) {
    return $.makeOrd(n, e, "textord");
  },
  mathmlBuilder(n, e) {
    var t = nt(n.text, n.mode, e), r = On(n, e) || "normal", a;
    return n.mode === "text" ? a = new B.MathNode("mtext", [t]) : /[0-9]/.test(n.text) ? a = new B.MathNode("mn", [t]) : n.text === "\\prime" ? a = new B.MathNode("mo", [t]) : a = new B.MathNode("mi", [t]), r !== Il[a.type] && a.setAttribute("mathvariant", r), a;
  }
});
var ln = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
}, sn = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
u0({
  type: "spacing",
  htmlBuilder(n, e) {
    if (sn.hasOwnProperty(n.text)) {
      var t = sn[n.text].className || "";
      if (n.mode === "text") {
        var r = $.makeOrd(n, e, "textord");
        return r.classes.push(t), r;
      } else
        return $.makeSpan(["mspace", t], [$.mathsym(n.text, n.mode, e)], e);
    } else {
      if (ln.hasOwnProperty(n.text))
        return $.makeSpan(["mspace", ln[n.text]], [], e);
      throw new G('Unknown type of space "' + n.text + '"');
    }
  },
  mathmlBuilder(n, e) {
    var t;
    if (sn.hasOwnProperty(n.text))
      t = new B.MathNode("mtext", [new B.TextNode(" ")]);
    else {
      if (ln.hasOwnProperty(n.text))
        return new B.MathNode("mspace");
      throw new G('Unknown type of space "' + n.text + '"');
    }
    return t;
  }
});
var ei = () => {
  var n = new B.MathNode("mtd", []);
  return n.setAttribute("width", "50%"), n;
};
u0({
  type: "tag",
  mathmlBuilder(n, e) {
    var t = new B.MathNode("mtable", [new B.MathNode("mtr", [ei(), new B.MathNode("mtd", [t0(n.body, e)]), ei(), new B.MathNode("mtd", [t0(n.tag, e)])])]);
    return t.setAttribute("width", "100%"), t;
  }
});
var ti = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
}, ri = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
}, S1 = {
  "\\textit": "textit",
  "\\textup": "textup"
}, ni = (n, e) => {
  var t = n.font;
  if (t) {
    if (ti[t])
      return e.withTextFontFamily(ti[t]);
    if (ri[t])
      return e.withTextFontWeight(ri[t]);
    if (t === "\\emph")
      return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
  } else return e;
  return e.withTextFontShape(S1[t]);
};
L({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t,
      funcName: r
    } = n, a = e[0];
    return {
      type: "text",
      mode: t.mode,
      body: De(a),
      font: r
    };
  },
  htmlBuilder(n, e) {
    var t = ni(n, e), r = Te(n.body, t, !0);
    return $.makeSpan(["mord", "text"], r, t);
  },
  mathmlBuilder(n, e) {
    var t = ni(n, e);
    return t0(n.body, t);
  }
});
L({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "underline",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = ae(n.body, e), r = $.makeLineSpan("underline-line", e), a = e.fontMetrics().defaultRuleThickness, i = $.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "kern",
        size: a
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: 3 * a
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return $.makeSpan(["mord", "underline"], [i], e);
  },
  mathmlBuilder(n, e) {
    var t = new B.MathNode("mo", [new B.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var r = new B.MathNode("munder", [me(n.body, e), t]);
    return r.setAttribute("accentunder", "true"), r;
  }
});
L({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: !1
  },
  handler(n, e) {
    var {
      parser: t
    } = n;
    return {
      type: "vcenter",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(n, e) {
    var t = ae(n.body, e), r = e.fontMetrics().axisHeight, a = 0.5 * (t.height - r - (t.depth + r));
    return $.makeVList({
      positionType: "shift",
      positionData: a,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(n, e) {
    return new B.MathNode("mpadded", [me(n.body, e)], ["vcenter"]);
  }
});
L({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(n, e, t) {
    throw new G("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(n, e) {
    for (var t = ai(n), r = [], a = e.havingStyle(e.style.text()), i = 0; i < t.length; i++) {
      var l = t[i];
      l === "~" && (l = "\\textasciitilde"), r.push($.makeSymbol(l, "Typewriter-Regular", n.mode, a, ["mord", "texttt"]));
    }
    return $.makeSpan(["mord", "text"].concat(a.sizingClasses(e)), $.tryCombineChars(r), a);
  },
  mathmlBuilder(n, e) {
    var t = new B.TextNode(ai(n)), r = new B.MathNode("mtext", [t]);
    return r.setAttribute("mathvariant", "monospace"), r;
  }
});
var ai = (n) => n.body.replace(/ /g, n.star ? "␣" : " "), A1 = cl;
f("\\noexpand", function(n) {
  var e = n.popToken();
  return n.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
    tokens: [e],
    numArgs: 0
  };
});
f("\\expandafter", function(n) {
  var e = n.popToken();
  return n.expandOnce(!0), {
    tokens: [e],
    numArgs: 0
  };
});
f("\\@firstoftwo", function(n) {
  var e = n.consumeArgs(2);
  return {
    tokens: e[0],
    numArgs: 0
  };
});
f("\\@secondoftwo", function(n) {
  var e = n.consumeArgs(2);
  return {
    tokens: e[1],
    numArgs: 0
  };
});
f("\\@ifnextchar", function(n) {
  var e = n.consumeArgs(3);
  n.consumeSpaces();
  var t = n.future();
  return e[0].length === 1 && e[0][0].text === t.text ? {
    tokens: e[1],
    numArgs: 0
  } : {
    tokens: e[2],
    numArgs: 0
  };
});
f("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
f("\\TextOrMath", function(n) {
  var e = n.consumeArgs(2);
  return n.mode === "text" ? {
    tokens: e[0],
    numArgs: 0
  } : {
    tokens: e[1],
    numArgs: 0
  };
});
var ii = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
f("\\char", function(n) {
  var e = n.popToken(), t, r = "";
  if (e.text === "'")
    t = 8, e = n.popToken();
  else if (e.text === '"')
    t = 16, e = n.popToken();
  else if (e.text === "`")
    if (e = n.popToken(), e.text[0] === "\\")
      r = e.text.charCodeAt(1);
    else {
      if (e.text === "EOF")
        throw new G("\\char` missing argument");
      r = e.text.charCodeAt(0);
    }
  else
    t = 10;
  if (t) {
    if (r = ii[e.text], r == null || r >= t)
      throw new G("Invalid base-" + t + " digit " + e.text);
    for (var a; (a = ii[n.future().text]) != null && a < t; )
      r *= t, r += a, n.popToken();
  }
  return "\\@char{" + r + "}";
});
var Zn = (n, e, t, r) => {
  var a = n.consumeArg().tokens;
  if (a.length !== 1)
    throw new G("\\newcommand's first argument must be a macro name");
  var i = a[0].text, l = n.isDefined(i);
  if (l && !e)
    throw new G("\\newcommand{" + i + "} attempting to redefine " + (i + "; use \\renewcommand"));
  if (!l && !t)
    throw new G("\\renewcommand{" + i + "} when command " + i + " does not yet exist; use \\newcommand");
  var o = 0;
  if (a = n.consumeArg().tokens, a.length === 1 && a[0].text === "[") {
    for (var c = "", m = n.expandNextToken(); m.text !== "]" && m.text !== "EOF"; )
      c += m.text, m = n.expandNextToken();
    if (!c.match(/^\s*[0-9]+\s*$/))
      throw new G("Invalid number of arguments: " + c);
    o = parseInt(c), a = n.consumeArg().tokens;
  }
  return l && r || n.macros.set(i, {
    tokens: a,
    numArgs: o
  }), "";
};
f("\\newcommand", (n) => Zn(n, !1, !0, !1));
f("\\renewcommand", (n) => Zn(n, !0, !1, !1));
f("\\providecommand", (n) => Zn(n, !0, !0, !0));
f("\\message", (n) => {
  var e = n.consumeArgs(1)[0];
  return console.log(e.reverse().map((t) => t.text).join("")), "";
});
f("\\errmessage", (n) => {
  var e = n.consumeArgs(1)[0];
  return console.error(e.reverse().map((t) => t.text).join("")), "";
});
f("\\show", (n) => {
  var e = n.popToken(), t = e.text;
  return console.log(e, n.macros.get(t), A1[t], xe.math[t], xe.text[t]), "";
});
f("\\bgroup", "{");
f("\\egroup", "}");
f("~", "\\nobreakspace");
f("\\lq", "`");
f("\\rq", "'");
f("\\aa", "\\r a");
f("\\AA", "\\r A");
f("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
f("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
f("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
f("ℬ", "\\mathscr{B}");
f("ℰ", "\\mathscr{E}");
f("ℱ", "\\mathscr{F}");
f("ℋ", "\\mathscr{H}");
f("ℐ", "\\mathscr{I}");
f("ℒ", "\\mathscr{L}");
f("ℳ", "\\mathscr{M}");
f("ℛ", "\\mathscr{R}");
f("ℭ", "\\mathfrak{C}");
f("ℌ", "\\mathfrak{H}");
f("ℨ", "\\mathfrak{Z}");
f("\\Bbbk", "\\Bbb{k}");
f("·", "\\cdotp");
f("\\llap", "\\mathllap{\\textrm{#1}}");
f("\\rlap", "\\mathrlap{\\textrm{#1}}");
f("\\clap", "\\mathclap{\\textrm{#1}}");
f("\\mathstrut", "\\vphantom{(}");
f("\\underbar", "\\underline{\\text{#1}}");
f("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}');
f("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
f("\\ne", "\\neq");
f("≠", "\\neq");
f("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
f("∉", "\\notin");
f("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
f("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
f("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
f("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
f("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
f("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
f("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
f("⟂", "\\perp");
f("‼", "\\mathclose{!\\mkern-0.8mu!}");
f("∌", "\\notni");
f("⌜", "\\ulcorner");
f("⌝", "\\urcorner");
f("⌞", "\\llcorner");
f("⌟", "\\lrcorner");
f("©", "\\copyright");
f("®", "\\textregistered");
f("️", "\\textregistered");
f("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
f("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
f("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
f("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
f("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
f("⋮", "\\vdots");
f("\\varGamma", "\\mathit{\\Gamma}");
f("\\varDelta", "\\mathit{\\Delta}");
f("\\varTheta", "\\mathit{\\Theta}");
f("\\varLambda", "\\mathit{\\Lambda}");
f("\\varXi", "\\mathit{\\Xi}");
f("\\varPi", "\\mathit{\\Pi}");
f("\\varSigma", "\\mathit{\\Sigma}");
f("\\varUpsilon", "\\mathit{\\Upsilon}");
f("\\varPhi", "\\mathit{\\Phi}");
f("\\varPsi", "\\mathit{\\Psi}");
f("\\varOmega", "\\mathit{\\Omega}");
f("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
f("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
f("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
f("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
f("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
f("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
f("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
f("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var li = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
};
f("\\dots", function(n) {
  var e = "\\dotso", t = n.expandAfterFuture().text;
  return t in li ? e = li[t] : (t.slice(0, 4) === "\\not" || t in xe.math && j.contains(["bin", "rel"], xe.math[t].group)) && (e = "\\dotsb"), e;
});
var Kn = {
  // \rightdelim@ checks for the following:
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  // \extra@ also tests for the following:
  $: !0,
  // \extrap@ checks for the following:
  ";": !0,
  ".": !0,
  ",": !0
};
f("\\dotso", function(n) {
  var e = n.future().text;
  return e in Kn ? "\\ldots\\," : "\\ldots";
});
f("\\dotsc", function(n) {
  var e = n.future().text;
  return e in Kn && e !== "," ? "\\ldots\\," : "\\ldots";
});
f("\\cdots", function(n) {
  var e = n.future().text;
  return e in Kn ? "\\@cdots\\," : "\\@cdots";
});
f("\\dotsb", "\\cdots");
f("\\dotsm", "\\cdots");
f("\\dotsi", "\\!\\cdots");
f("\\dotsx", "\\ldots\\,");
f("\\DOTSI", "\\relax");
f("\\DOTSB", "\\relax");
f("\\DOTSX", "\\relax");
f("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
f("\\,", "\\tmspace+{3mu}{.1667em}");
f("\\thinspace", "\\,");
f("\\>", "\\mskip{4mu}");
f("\\:", "\\tmspace+{4mu}{.2222em}");
f("\\medspace", "\\:");
f("\\;", "\\tmspace+{5mu}{.2777em}");
f("\\thickspace", "\\;");
f("\\!", "\\tmspace-{3mu}{.1667em}");
f("\\negthinspace", "\\!");
f("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
f("\\negthickspace", "\\tmspace-{5mu}{.277em}");
f("\\enspace", "\\kern.5em ");
f("\\enskip", "\\hskip.5em\\relax");
f("\\quad", "\\hskip1em\\relax");
f("\\qquad", "\\hskip2em\\relax");
f("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
f("\\tag@paren", "\\tag@literal{({#1})}");
f("\\tag@literal", (n) => {
  if (n.macros.get("\\df@tag"))
    throw new G("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
f("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
f("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
f("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
f("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
f("\\newline", "\\\\\\relax");
f("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var Ll = I(Vt["Main-Regular"][84][1] - 0.7 * Vt["Main-Regular"][65][1]);
f("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + Ll + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
f("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + Ll + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
f("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
f("\\@hspace", "\\hskip #1\\relax");
f("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
f("\\ordinarycolon", ":");
f("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
f("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
f("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
f("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
f("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
f("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
f("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
f("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
f("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
f("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
f("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
f("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
f("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
f("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
f("∷", "\\dblcolon");
f("∹", "\\eqcolon");
f("≔", "\\coloneqq");
f("≕", "\\eqqcolon");
f("⩴", "\\Coloneqq");
f("\\ratio", "\\vcentcolon");
f("\\coloncolon", "\\dblcolon");
f("\\colonequals", "\\coloneqq");
f("\\coloncolonequals", "\\Coloneqq");
f("\\equalscolon", "\\eqqcolon");
f("\\equalscoloncolon", "\\Eqqcolon");
f("\\colonminus", "\\coloneq");
f("\\coloncolonminus", "\\Coloneq");
f("\\minuscolon", "\\eqcolon");
f("\\minuscoloncolon", "\\Eqcolon");
f("\\coloncolonapprox", "\\Colonapprox");
f("\\coloncolonsim", "\\Colonsim");
f("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
f("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
f("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
f("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
f("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
f("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
f("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
f("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
f("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
f("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
f("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
f("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
f("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
f("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
f("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
f("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
f("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
f("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
f("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
f("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
f("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
f("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
f("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
f("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
f("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
f("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
f("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
f("\\imath", "\\html@mathml{\\@imath}{ı}");
f("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
f("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
f("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
f("⟦", "\\llbracket");
f("⟧", "\\rrbracket");
f("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
f("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
f("⦃", "\\lBrace");
f("⦄", "\\rBrace");
f("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
f("⦵", "\\minuso");
f("\\darr", "\\downarrow");
f("\\dArr", "\\Downarrow");
f("\\Darr", "\\Downarrow");
f("\\lang", "\\langle");
f("\\rang", "\\rangle");
f("\\uarr", "\\uparrow");
f("\\uArr", "\\Uparrow");
f("\\Uarr", "\\Uparrow");
f("\\N", "\\mathbb{N}");
f("\\R", "\\mathbb{R}");
f("\\Z", "\\mathbb{Z}");
f("\\alef", "\\aleph");
f("\\alefsym", "\\aleph");
f("\\Alpha", "\\mathrm{A}");
f("\\Beta", "\\mathrm{B}");
f("\\bull", "\\bullet");
f("\\Chi", "\\mathrm{X}");
f("\\clubs", "\\clubsuit");
f("\\cnums", "\\mathbb{C}");
f("\\Complex", "\\mathbb{C}");
f("\\Dagger", "\\ddagger");
f("\\diamonds", "\\diamondsuit");
f("\\empty", "\\emptyset");
f("\\Epsilon", "\\mathrm{E}");
f("\\Eta", "\\mathrm{H}");
f("\\exist", "\\exists");
f("\\harr", "\\leftrightarrow");
f("\\hArr", "\\Leftrightarrow");
f("\\Harr", "\\Leftrightarrow");
f("\\hearts", "\\heartsuit");
f("\\image", "\\Im");
f("\\infin", "\\infty");
f("\\Iota", "\\mathrm{I}");
f("\\isin", "\\in");
f("\\Kappa", "\\mathrm{K}");
f("\\larr", "\\leftarrow");
f("\\lArr", "\\Leftarrow");
f("\\Larr", "\\Leftarrow");
f("\\lrarr", "\\leftrightarrow");
f("\\lrArr", "\\Leftrightarrow");
f("\\Lrarr", "\\Leftrightarrow");
f("\\Mu", "\\mathrm{M}");
f("\\natnums", "\\mathbb{N}");
f("\\Nu", "\\mathrm{N}");
f("\\Omicron", "\\mathrm{O}");
f("\\plusmn", "\\pm");
f("\\rarr", "\\rightarrow");
f("\\rArr", "\\Rightarrow");
f("\\Rarr", "\\Rightarrow");
f("\\real", "\\Re");
f("\\reals", "\\mathbb{R}");
f("\\Reals", "\\mathbb{R}");
f("\\Rho", "\\mathrm{P}");
f("\\sdot", "\\cdot");
f("\\sect", "\\S");
f("\\spades", "\\spadesuit");
f("\\sub", "\\subset");
f("\\sube", "\\subseteq");
f("\\supe", "\\supseteq");
f("\\Tau", "\\mathrm{T}");
f("\\thetasym", "\\vartheta");
f("\\weierp", "\\wp");
f("\\Zeta", "\\mathrm{Z}");
f("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
f("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
f("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
f("\\bra", "\\mathinner{\\langle{#1}|}");
f("\\ket", "\\mathinner{|{#1}\\rangle}");
f("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
f("\\Bra", "\\left\\langle#1\\right|");
f("\\Ket", "\\left|#1\\right\\rangle");
var Ol = (n) => (e) => {
  var t = e.consumeArg().tokens, r = e.consumeArg().tokens, a = e.consumeArg().tokens, i = e.consumeArg().tokens, l = e.macros.get("|"), o = e.macros.get("\\|");
  e.macros.beginGroup();
  var c = (p) => (y) => {
    n && (y.macros.set("|", l), a.length && y.macros.set("\\|", o));
    var v = p;
    if (!p && a.length) {
      var x = y.future();
      x.text === "|" && (y.popToken(), v = !0);
    }
    return {
      tokens: v ? a : r,
      numArgs: 0
    };
  };
  e.macros.set("|", c(!1)), a.length && e.macros.set("\\|", c(!0));
  var m = e.consumeArg().tokens, d = e.expandTokens([
    ...i,
    ...m,
    ...t
    // reversed
  ]);
  return e.macros.endGroup(), {
    tokens: d.reverse(),
    numArgs: 0
  };
};
f("\\bra@ket", Ol(!1));
f("\\bra@set", Ol(!0));
f("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
f("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
f("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
f("\\angln", "{\\angl n}");
f("\\blue", "\\textcolor{##6495ed}{#1}");
f("\\orange", "\\textcolor{##ffa500}{#1}");
f("\\pink", "\\textcolor{##ff00af}{#1}");
f("\\red", "\\textcolor{##df0030}{#1}");
f("\\green", "\\textcolor{##28ae7b}{#1}");
f("\\gray", "\\textcolor{gray}{#1}");
f("\\purple", "\\textcolor{##9d38bd}{#1}");
f("\\blueA", "\\textcolor{##ccfaff}{#1}");
f("\\blueB", "\\textcolor{##80f6ff}{#1}");
f("\\blueC", "\\textcolor{##63d9ea}{#1}");
f("\\blueD", "\\textcolor{##11accd}{#1}");
f("\\blueE", "\\textcolor{##0c7f99}{#1}");
f("\\tealA", "\\textcolor{##94fff5}{#1}");
f("\\tealB", "\\textcolor{##26edd5}{#1}");
f("\\tealC", "\\textcolor{##01d1c1}{#1}");
f("\\tealD", "\\textcolor{##01a995}{#1}");
f("\\tealE", "\\textcolor{##208170}{#1}");
f("\\greenA", "\\textcolor{##b6ffb0}{#1}");
f("\\greenB", "\\textcolor{##8af281}{#1}");
f("\\greenC", "\\textcolor{##74cf70}{#1}");
f("\\greenD", "\\textcolor{##1fab54}{#1}");
f("\\greenE", "\\textcolor{##0d923f}{#1}");
f("\\goldA", "\\textcolor{##ffd0a9}{#1}");
f("\\goldB", "\\textcolor{##ffbb71}{#1}");
f("\\goldC", "\\textcolor{##ff9c39}{#1}");
f("\\goldD", "\\textcolor{##e07d10}{#1}");
f("\\goldE", "\\textcolor{##a75a05}{#1}");
f("\\redA", "\\textcolor{##fca9a9}{#1}");
f("\\redB", "\\textcolor{##ff8482}{#1}");
f("\\redC", "\\textcolor{##f9685d}{#1}");
f("\\redD", "\\textcolor{##e84d39}{#1}");
f("\\redE", "\\textcolor{##bc2612}{#1}");
f("\\maroonA", "\\textcolor{##ffbde0}{#1}");
f("\\maroonB", "\\textcolor{##ff92c6}{#1}");
f("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
f("\\maroonD", "\\textcolor{##ca337c}{#1}");
f("\\maroonE", "\\textcolor{##9e034e}{#1}");
f("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
f("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
f("\\purpleC", "\\textcolor{##aa87ff}{#1}");
f("\\purpleD", "\\textcolor{##7854ab}{#1}");
f("\\purpleE", "\\textcolor{##543b78}{#1}");
f("\\mintA", "\\textcolor{##f5f9e8}{#1}");
f("\\mintB", "\\textcolor{##edf2df}{#1}");
f("\\mintC", "\\textcolor{##e0e5cc}{#1}");
f("\\grayA", "\\textcolor{##f6f7f7}{#1}");
f("\\grayB", "\\textcolor{##f0f1f2}{#1}");
f("\\grayC", "\\textcolor{##e3e5e6}{#1}");
f("\\grayD", "\\textcolor{##d6d8da}{#1}");
f("\\grayE", "\\textcolor{##babec2}{#1}");
f("\\grayF", "\\textcolor{##888d93}{#1}");
f("\\grayG", "\\textcolor{##626569}{#1}");
f("\\grayH", "\\textcolor{##3b3e40}{#1}");
f("\\grayI", "\\textcolor{##21242c}{#1}");
f("\\kaBlue", "\\textcolor{##314453}{#1}");
f("\\kaGreen", "\\textcolor{##71B307}{#1}");
typeof document < "u" && document.compatMode !== "CSS1Compat" && typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
function Qn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let c0 = Qn();
function Pl(n) {
  c0 = n;
}
const Hl = /[&<>"']/, $1 = new RegExp(Hl.source, "g"), Ul = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, F1 = new RegExp(Ul.source, "g"), C1 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, si = (n) => C1[n];
function je(n, e) {
  if (e) {
    if (Hl.test(n))
      return n.replace($1, si);
  } else if (Ul.test(n))
    return n.replace(F1, si);
  return n;
}
const E1 = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function T1(n) {
  return n.replace(E1, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const M1 = /(^|[^\[])\^/g;
function ue(n, e) {
  let t = typeof n == "string" ? n : n.source;
  e = e || "";
  const r = {
    replace: (a, i) => {
      let l = typeof i == "string" ? i : i.source;
      return l = l.replace(M1, "$1"), t = t.replace(a, l), r;
    },
    getRegex: () => new RegExp(t, e)
  };
  return r;
}
function oi(n) {
  try {
    n = encodeURI(n).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return n;
}
const P0 = { exec: () => null };
function ui(n, e) {
  const t = n.replace(/\|/g, (i, l, o) => {
    let c = !1, m = l;
    for (; --m >= 0 && o[m] === "\\"; )
      c = !c;
    return c ? "|" : " |";
  }), r = t.split(/ \|/);
  let a = 0;
  if (r[0].trim() || r.shift(), r.length > 0 && !r[r.length - 1].trim() && r.pop(), e)
    if (r.length > e)
      r.splice(e);
    else
      for (; r.length < e; )
        r.push("");
  for (; a < r.length; a++)
    r[a] = r[a].trim().replace(/\\\|/g, "|");
  return r;
}
function or(n, e, t) {
  const r = n.length;
  if (r === 0)
    return "";
  let a = 0;
  for (; a < r && n.charAt(r - a - 1) === e; )
    a++;
  return n.slice(0, r - a);
}
function z1(n, e) {
  if (n.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let r = 0; r < n.length; r++)
    if (n[r] === "\\")
      r++;
    else if (n[r] === e[0])
      t++;
    else if (n[r] === e[1] && (t--, t < 0))
      return r;
  return -1;
}
function ci(n, e, t, r) {
  const a = e.href, i = e.title ? je(e.title) : null, l = n[1].replace(/\\([\[\]])/g, "$1");
  if (n[0].charAt(0) !== "!") {
    r.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: a,
      title: i,
      text: l,
      tokens: r.inlineTokens(l)
    };
    return r.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: i,
    text: je(l)
  };
}
function B1(n, e) {
  const t = n.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const r = t[1];
  return e.split(`
`).map((a) => {
    const i = a.match(/^\s+/);
    if (i === null)
      return a;
    const [l] = i;
    return l.length >= r.length ? a.slice(r.length) : a;
  }).join(`
`);
}
class Cr {
  // set by the lexer
  constructor(e) {
    he(this, "options");
    he(this, "rules");
    // set by the lexer
    he(this, "lexer");
    this.options = e || c0;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const r = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? r : or(r, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const r = t[0], a = B1(r, t[3] || "");
      return {
        type: "code",
        raw: r,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let r = t[2].trim();
      if (/#$/.test(r)) {
        const a = or(r, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (r = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let r = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      r = or(r.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const i = this.lexer.blockTokens(r);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: i,
        text: r
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let r = t[1].trim();
      const a = r.length > 1, i = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +r.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      r = a ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = a ? r : "[*+-]");
      const l = new RegExp(`^( {0,3}${r})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", c = "", m = !1;
      for (; e; ) {
        let d = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let p = t[2].split(`
`, 1)[0].replace(/^\t+/, (E) => " ".repeat(3 * E.length)), y = e.split(`
`, 1)[0], v = 0;
        this.options.pedantic ? (v = 2, c = p.trimStart()) : (v = t[2].search(/[^ ]/), v = v > 4 ? 1 : v, c = p.slice(v), v += t[1].length);
        let x = !1;
        if (!p && /^ *$/.test(y) && (o += y + `
`, e = e.substring(y.length + 1), d = !0), !d) {
          const E = new RegExp(`^ {0,${Math.min(3, v - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), D = new RegExp(`^ {0,${Math.min(3, v - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), g = new RegExp(`^ {0,${Math.min(3, v - 1)}}(?:\`\`\`|~~~)`), A = new RegExp(`^ {0,${Math.min(3, v - 1)}}#`);
          for (; e; ) {
            const C = e.split(`
`, 1)[0];
            if (y = C, this.options.pedantic && (y = y.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), g.test(y) || A.test(y) || E.test(y) || D.test(e))
              break;
            if (y.search(/[^ ]/) >= v || !y.trim())
              c += `
` + y.slice(v);
            else {
              if (x || p.search(/[^ ]/) >= 4 || g.test(p) || A.test(p) || D.test(p))
                break;
              c += `
` + y;
            }
            !x && !y.trim() && (x = !0), o += C + `
`, e = e.substring(C.length + 1), p = y.slice(v);
          }
        }
        i.loose || (m ? i.loose = !0 : /\n *\n *$/.test(o) && (m = !0));
        let S = null, F;
        this.options.gfm && (S = /^\[[ xX]\] /.exec(c), S && (F = S[0] !== "[ ] ", c = c.replace(/^\[[ xX]\] +/, ""))), i.items.push({
          type: "list_item",
          raw: o,
          task: !!S,
          checked: F,
          loose: !1,
          text: c,
          tokens: []
        }), i.raw += o;
      }
      i.items[i.items.length - 1].raw = o.trimEnd(), i.items[i.items.length - 1].text = c.trimEnd(), i.raw = i.raw.trimEnd();
      for (let d = 0; d < i.items.length; d++)
        if (this.lexer.state.top = !1, i.items[d].tokens = this.lexer.blockTokens(i.items[d].text, []), !i.loose) {
          const p = i.items[d].tokens.filter((v) => v.type === "space"), y = p.length > 0 && p.some((v) => /\n.*\n/.test(v.raw));
          i.loose = y;
        }
      if (i.loose)
        for (let d = 0; d < i.items.length; d++)
          i.items[d].loose = !0;
      return i;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const r = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: r,
        raw: t[0],
        href: a,
        title: i
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const r = ui(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), i = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (r.length === a.length) {
      for (const o of a)
        /^ *-+: *$/.test(o) ? l.align.push("right") : /^ *:-+: *$/.test(o) ? l.align.push("center") : /^ *:-+ *$/.test(o) ? l.align.push("left") : l.align.push(null);
      for (const o of r)
        l.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of i)
        l.rows.push(ui(o, l.header.length).map((c) => ({
          text: c,
          tokens: this.lexer.inline(c)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const r = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: je(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const r = t[2].trim();
      if (!this.options.pedantic && /^</.test(r)) {
        if (!/>$/.test(r))
          return;
        const l = or(r.slice(0, -1), "\\");
        if ((r.length - l.length) % 2 === 0)
          return;
      } else {
        const l = z1(t[2], "()");
        if (l > -1) {
          const c = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, c).trim(), t[3] = "";
        }
      }
      let a = t[2], i = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], i = l[3]);
      } else
        i = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(r) ? a = a.slice(1) : a = a.slice(1, -1)), ci(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      const a = (r[2] || r[1]).replace(/\s+/g, " "), i = t[a.toLowerCase()];
      if (!i) {
        const l = r[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return ci(r, i, r[0], this.lexer);
    }
  }
  emStrong(e, t, r = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && r.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !r || this.rules.inline.punctuation.exec(r)) {
      const l = [...a[0]].length - 1;
      let o, c, m = l, d = 0;
      const p = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (p.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = p.exec(t)) != null; ) {
        if (o = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !o)
          continue;
        if (c = [...o].length, a[3] || a[4]) {
          m += c;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + c) % 3)) {
          d += c;
          continue;
        }
        if (m -= c, m > 0)
          continue;
        c = Math.min(c, c + m + d);
        const y = [...a[0]][0].length, v = e.slice(0, l + a.index + y + c);
        if (Math.min(l, c) % 2) {
          const S = v.slice(1, -1);
          return {
            type: "em",
            raw: v,
            text: S,
            tokens: this.lexer.inlineTokens(S)
          };
        }
        const x = v.slice(2, -2);
        return {
          type: "strong",
          raw: v,
          text: x,
          tokens: this.lexer.inlineTokens(x)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let r = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(r), i = /^ /.test(r) && / $/.test(r);
      return a && i && (r = r.substring(1, r.length - 1)), r = je(r, !0), {
        type: "codespan",
        raw: t[0],
        text: r
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let r, a;
      return t[2] === "@" ? (r = je(t[1]), a = "mailto:" + r) : (r = je(t[1]), a = r), {
        type: "link",
        raw: t[0],
        text: r,
        href: a,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  url(e) {
    var r;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, i;
      if (t[2] === "@")
        a = je(t[0]), i = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((r = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : r[0]) ?? "";
        while (l !== t[0]);
        a = je(t[0]), t[1] === "www." ? i = "http://" + t[0] : i = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: i,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let r;
      return this.lexer.state.inRawBlock ? r = t[0] : r = je(t[0]), {
        type: "text",
        raw: t[0],
        text: r
      };
    }
  }
}
const q1 = /^(?: *(?:\n|$))+/, R1 = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, N1 = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, j0 = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, I1 = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Vl = /(?:[*+-]|\d{1,9}[.)])/, Gl = ue(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Vl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Jn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, L1 = /^[^\n]+/, ea = /(?!\s*\])(?:\\.|[^\[\]\\])+/, O1 = ue(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", ea).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), P1 = ue(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Vl).getRegex(), Or = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", ta = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, H1 = ue("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", ta).replace("tag", Or).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Yl = ue(Jn).replace("hr", j0).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Or).getRegex(), U1 = ue(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Yl).getRegex(), ra = {
  blockquote: U1,
  code: R1,
  def: O1,
  fences: N1,
  heading: I1,
  hr: j0,
  html: H1,
  lheading: Gl,
  list: P1,
  newline: q1,
  paragraph: Yl,
  table: P0,
  text: L1
}, mi = ue("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", j0).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Or).getRegex(), V1 = {
  ...ra,
  table: mi,
  paragraph: ue(Jn).replace("hr", j0).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", mi).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Or).getRegex()
}, G1 = {
  ...ra,
  html: ue(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", ta).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: P0,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: ue(Jn).replace("hr", j0).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Gl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Wl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Y1 = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, jl = /^( {2,}|\\)\n(?!\s*$)/, W1 = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, X0 = "\\p{P}\\p{S}", j1 = ue(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, X0).getRegex(), X1 = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Z1 = ue(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, X0).getRegex(), K1 = ue("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, X0).getRegex(), Q1 = ue("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, X0).getRegex(), J1 = ue(/\\([punct])/, "gu").replace(/punct/g, X0).getRegex(), eu = ue(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), tu = ue(ta).replace("(?:-->|$)", "-->").getRegex(), ru = ue("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", tu).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Er = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, nu = ue(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Er).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Xl = ue(/^!?\[(label)\]\[(ref)\]/).replace("label", Er).replace("ref", ea).getRegex(), Zl = ue(/^!?\[(ref)\](?:\[\])?/).replace("ref", ea).getRegex(), au = ue("reflink|nolink(?!\\()", "g").replace("reflink", Xl).replace("nolink", Zl).getRegex(), na = {
  _backpedal: P0,
  // only used for GFM url
  anyPunctuation: J1,
  autolink: eu,
  blockSkip: X1,
  br: jl,
  code: Y1,
  del: P0,
  emStrongLDelim: Z1,
  emStrongRDelimAst: K1,
  emStrongRDelimUnd: Q1,
  escape: Wl,
  link: nu,
  nolink: Zl,
  punctuation: j1,
  reflink: Xl,
  reflinkSearch: au,
  tag: ru,
  text: W1,
  url: P0
}, iu = {
  ...na,
  link: ue(/^!?\[(label)\]\((.*?)\)/).replace("label", Er).getRegex(),
  reflink: ue(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Er).getRegex()
}, xn = {
  ...na,
  escape: ue(Wl).replace("])", "~|])").getRegex(),
  url: ue(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, lu = {
  ...xn,
  br: ue(jl).replace("{2,}", "*").getRegex(),
  text: ue(xn.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, ur = {
  normal: ra,
  gfm: V1,
  pedantic: G1
}, E0 = {
  normal: na,
  gfm: xn,
  breaks: lu,
  pedantic: iu
};
class St {
  constructor(e) {
    he(this, "tokens");
    he(this, "options");
    he(this, "state");
    he(this, "tokenizer");
    he(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || c0, this.options.tokenizer = this.options.tokenizer || new Cr(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: ur.normal,
      inline: E0.normal
    };
    this.options.pedantic ? (t.block = ur.pedantic, t.inline = E0.pedantic) : this.options.gfm && (t.block = ur.gfm, this.options.breaks ? t.inline = E0.breaks : t.inline = E0.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: ur,
      inline: E0
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new St(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new St(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const r = this.inlineQueue[t];
      this.inlineTokens(r.src, r.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, c, m) => c + "    ".repeat(m.length));
    let r, a, i, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (r = o.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.space(e)) {
          e = e.substring(r.raw.length), r.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(r);
          continue;
        }
        if (r = this.tokenizer.code(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.fences(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.heading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.hr(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.blockquote(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.list(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.html(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.def(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + r.raw, a.text += `
` + r.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[r.tag] || (this.tokens.links[r.tag] = {
            href: r.href,
            title: r.title
          });
          continue;
        }
        if (r = this.tokenizer.table(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.lheading(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const c = e.slice(1);
          let m;
          this.options.extensions.startBlock.forEach((d) => {
            m = d.call({ lexer: this }, c), typeof m == "number" && m >= 0 && (o = Math.min(o, m));
          }), o < 1 / 0 && o >= 0 && (i = e.substring(0, o + 1));
        }
        if (this.state.top && (r = this.tokenizer.paragraph(i))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r), l = i.length !== e.length, e = e.substring(r.raw.length);
          continue;
        }
        if (r = this.tokenizer.text(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + r.raw, a.text += `
` + r.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(r);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let r, a, i, l = e, o, c, m;
    if (this.tokens.links) {
      const d = Object.keys(this.tokens.links);
      if (d.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          d.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, o.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (c || (m = ""), c = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((d) => (r = d.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1))) {
        if (r = this.tokenizer.escape(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.tag(e)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && r.type === "text" && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.link(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(r.raw.length), a = t[t.length - 1], a && r.type === "text" && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (r = this.tokenizer.emStrong(e, l, m)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.codespan(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.br(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.del(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (r = this.tokenizer.autolink(e)) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (!this.state.inLink && (r = this.tokenizer.url(e))) {
          e = e.substring(r.raw.length), t.push(r);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startInline) {
          let d = 1 / 0;
          const p = e.slice(1);
          let y;
          this.options.extensions.startInline.forEach((v) => {
            y = v.call({ lexer: this }, p), typeof y == "number" && y >= 0 && (d = Math.min(d, y));
          }), d < 1 / 0 && d >= 0 && (i = e.substring(0, d + 1));
        }
        if (r = this.tokenizer.inlineText(i)) {
          e = e.substring(r.raw.length), r.raw.slice(-1) !== "_" && (m = r.raw.slice(-1)), c = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += r.raw, a.text += r.text) : t.push(r);
          continue;
        }
        if (e) {
          const d = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(d);
            break;
          } else
            throw new Error(d);
        }
      }
    return t;
  }
}
class Tr {
  constructor(e) {
    he(this, "options");
    this.options = e || c0;
  }
  code(e, t, r) {
    var i;
    const a = (i = (t || "").match(/^\S*/)) == null ? void 0 : i[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + je(a) + '">' + (r ? e : je(e, !0)) + `</code></pre>
` : "<pre><code>" + (r ? e : je(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, r) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, r) {
    const a = t ? "ol" : "ul", i = t && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + a + i + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, r) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const r = t.header ? "th" : "td";
    return (t.align ? `<${r} align="${t.align}">` : `<${r}>`) + e + `</${r}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, r) {
    const a = oi(e);
    if (a === null)
      return r;
    e = a;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + t + '"'), i += ">" + r + "</a>", i;
  }
  image(e, t, r) {
    const a = oi(e);
    if (a === null)
      return r;
    e = a;
    let i = `<img src="${e}" alt="${r}"`;
    return t && (i += ` title="${t}"`), i += ">", i;
  }
  text(e) {
    return e;
  }
}
class aa {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, r) {
    return "" + r;
  }
  image(e, t, r) {
    return "" + r;
  }
  br() {
    return "";
  }
}
class At {
  constructor(e) {
    he(this, "options");
    he(this, "renderer");
    he(this, "textRenderer");
    this.options = e || c0, this.options.renderer = this.options.renderer || new Tr(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new aa();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new At(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new At(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let r = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = i, o = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          r += o || "";
          continue;
        }
      }
      switch (i.type) {
        case "space":
          continue;
        case "hr": {
          r += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = i;
          r += this.renderer.heading(this.parseInline(l.tokens), l.depth, T1(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = i;
          r += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = i;
          let o = "", c = "";
          for (let d = 0; d < l.header.length; d++)
            c += this.renderer.tablecell(this.parseInline(l.header[d].tokens), { header: !0, align: l.align[d] });
          o += this.renderer.tablerow(c);
          let m = "";
          for (let d = 0; d < l.rows.length; d++) {
            const p = l.rows[d];
            c = "";
            for (let y = 0; y < p.length; y++)
              c += this.renderer.tablecell(this.parseInline(p[y].tokens), { header: !1, align: l.align[y] });
            m += this.renderer.tablerow(c);
          }
          r += this.renderer.table(o, m);
          continue;
        }
        case "blockquote": {
          const l = i, o = this.parse(l.tokens);
          r += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const l = i, o = l.ordered, c = l.start, m = l.loose;
          let d = "";
          for (let p = 0; p < l.items.length; p++) {
            const y = l.items[p], v = y.checked, x = y.task;
            let S = "";
            if (y.task) {
              const F = this.renderer.checkbox(!!v);
              m ? y.tokens.length > 0 && y.tokens[0].type === "paragraph" ? (y.tokens[0].text = F + " " + y.tokens[0].text, y.tokens[0].tokens && y.tokens[0].tokens.length > 0 && y.tokens[0].tokens[0].type === "text" && (y.tokens[0].tokens[0].text = F + " " + y.tokens[0].tokens[0].text)) : y.tokens.unshift({
                type: "text",
                text: F + " "
              }) : S += F + " ";
            }
            S += this.parse(y.tokens, m), d += this.renderer.listitem(S, x, !!v);
          }
          r += this.renderer.list(d, o, c);
          continue;
        }
        case "html": {
          const l = i;
          r += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = i;
          r += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = i, o = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], o += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          r += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return r;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let r = "";
    for (let a = 0; a < e.length; a++) {
      const i = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
          r += l || "";
          continue;
        }
      }
      switch (i.type) {
        case "escape": {
          const l = i;
          r += t.text(l.text);
          break;
        }
        case "html": {
          const l = i;
          r += t.html(l.text);
          break;
        }
        case "link": {
          const l = i;
          r += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = i;
          r += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = i;
          r += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = i;
          r += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = i;
          r += t.codespan(l.text);
          break;
        }
        case "br": {
          r += t.br();
          break;
        }
        case "del": {
          const l = i;
          r += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = i;
          r += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return r;
  }
}
class H0 {
  constructor(e) {
    he(this, "options");
    this.options = e || c0;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
he(H0, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var o0, Sn, Kl;
class su {
  constructor(...e) {
    xa(this, o0);
    he(this, "defaults", Qn());
    he(this, "options", this.setOptions);
    he(this, "parse", er(this, o0, Sn).call(this, St.lex, At.parse));
    he(this, "parseInline", er(this, o0, Sn).call(this, St.lexInline, At.parseInline));
    he(this, "Parser", At);
    he(this, "Renderer", Tr);
    he(this, "TextRenderer", aa);
    he(this, "Lexer", St);
    he(this, "Tokenizer", Cr);
    he(this, "Hooks", H0);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, i;
    let r = [];
    for (const l of e)
      switch (r = r.concat(t.call(this, l)), l.type) {
        case "table": {
          const o = l;
          for (const c of o.header)
            r = r.concat(this.walkTokens(c.tokens, t));
          for (const c of o.rows)
            for (const m of c)
              r = r.concat(this.walkTokens(m.tokens, t));
          break;
        }
        case "list": {
          const o = l;
          r = r.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = l;
          (i = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && i[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((c) => {
            const m = o[c].flat(1 / 0);
            r = r.concat(this.walkTokens(m, t));
          }) : o.tokens && (r = r.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return r;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      const a = { ...r };
      if (a.async = this.defaults.async || a.async || !1, r.extensions && (r.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const l = t.renderers[i.name];
          l ? t.renderers[i.name] = function(...o) {
            let c = i.renderer.apply(this, o);
            return c === !1 && (c = l.apply(this, o)), c;
          } : t.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[i.level];
          l ? l.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
      }), a.extensions = t), r.renderer) {
        const i = this.defaults.renderer || new Tr(this.defaults);
        for (const l in r.renderer) {
          if (!(l in i))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, c = r.renderer[o], m = i[o];
          i[o] = (...d) => {
            let p = c.apply(i, d);
            return p === !1 && (p = m.apply(i, d)), p || "";
          };
        }
        a.renderer = i;
      }
      if (r.tokenizer) {
        const i = this.defaults.tokenizer || new Cr(this.defaults);
        for (const l in r.tokenizer) {
          if (!(l in i))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const o = l, c = r.tokenizer[o], m = i[o];
          i[o] = (...d) => {
            let p = c.apply(i, d);
            return p === !1 && (p = m.apply(i, d)), p;
          };
        }
        a.tokenizer = i;
      }
      if (r.hooks) {
        const i = this.defaults.hooks || new H0();
        for (const l in r.hooks) {
          if (!(l in i))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, c = r.hooks[o], m = i[o];
          H0.passThroughHooks.has(l) ? i[o] = (d) => {
            if (this.defaults.async)
              return Promise.resolve(c.call(i, d)).then((y) => m.call(i, y));
            const p = c.call(i, d);
            return m.call(i, p);
          } : i[o] = (...d) => {
            let p = c.apply(i, d);
            return p === !1 && (p = m.apply(i, d)), p;
          };
        }
        a.hooks = i;
      }
      if (r.walkTokens) {
        const i = this.defaults.walkTokens, l = r.walkTokens;
        a.walkTokens = function(o) {
          let c = [];
          return c.push(l.call(this, o)), i && (c = c.concat(i.call(this, o))), c;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return St.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return At.parse(e, t ?? this.defaults);
  }
}
o0 = new WeakSet(), Sn = function(e, t) {
  return (r, a) => {
    const i = { ...a }, l = { ...this.defaults, ...i };
    this.defaults.async === !0 && i.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const o = er(this, o0, Kl).call(this, !!l.silent, !!l.async);
    if (typeof r > "u" || r === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof r != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(r) : r).then((c) => e(c, l)).then((c) => l.hooks ? l.hooks.processAllTokens(c) : c).then((c) => l.walkTokens ? Promise.all(this.walkTokens(c, l.walkTokens)).then(() => c) : c).then((c) => t(c, l)).then((c) => l.hooks ? l.hooks.postprocess(c) : c).catch(o);
    try {
      l.hooks && (r = l.hooks.preprocess(r));
      let c = e(r, l);
      l.hooks && (c = l.hooks.processAllTokens(c)), l.walkTokens && this.walkTokens(c, l.walkTokens);
      let m = t(c, l);
      return l.hooks && (m = l.hooks.postprocess(m)), m;
    } catch (c) {
      return o(c);
    }
  };
}, Kl = function(e, t) {
  return (r) => {
    if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + je(r.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(r);
    throw r;
  };
};
const s0 = new su();
function oe(n, e) {
  return s0.parse(n, e);
}
oe.options = oe.setOptions = function(n) {
  return s0.setOptions(n), oe.defaults = s0.defaults, Pl(oe.defaults), oe;
};
oe.getDefaults = Qn;
oe.defaults = c0;
oe.use = function(...n) {
  return s0.use(...n), oe.defaults = s0.defaults, Pl(oe.defaults), oe;
};
oe.walkTokens = function(n, e) {
  return s0.walkTokens(n, e);
};
oe.parseInline = s0.parseInline;
oe.Parser = At;
oe.parser = At.parse;
oe.Renderer = Tr;
oe.TextRenderer = aa;
oe.Lexer = St;
oe.lexer = St.lex;
oe.Tokenizer = Cr;
oe.Hooks = H0;
oe.parse = oe;
oe.options;
oe.setOptions;
oe.use;
oe.walkTokens;
oe.parseInline;
At.parse;
St.lex;
const ou = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, uu = Object.hasOwnProperty;
class Ql {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const r = this;
    let a = cu(e, t === !0);
    const i = a;
    for (; uu.call(r.occurrences, a); )
      r.occurrences[i]++, a = i + "-" + r.occurrences[i];
    return r.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function cu(n, e) {
  return typeof n != "string" ? "" : (e || (n = n.toLowerCase()), n.replace(ou, "").replace(/ /g, "-"));
}
new Ql();
var hi = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, mu = { exports: {} };
(function(n) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(r) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, i = 0, l = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: r.Prism && r.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: r.Prism && r.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function D(g) {
          return g instanceof c ? new c(g.type, D(g.content), g.alias) : Array.isArray(g) ? g.map(D) : g.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(D) {
          return Object.prototype.toString.call(D).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(D) {
          return D.__id || Object.defineProperty(D, "__id", { value: ++i }), D.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function D(g, A) {
          A = A || {};
          var C, T;
          switch (o.util.type(g)) {
            case "Object":
              if (T = o.util.objId(g), A[T])
                return A[T];
              C = /** @type {Record<string, any>} */
              {}, A[T] = C;
              for (var z in g)
                g.hasOwnProperty(z) && (C[z] = D(g[z], A));
              return (
                /** @type {any} */
                C
              );
            case "Array":
              return T = o.util.objId(g), A[T] ? A[T] : (C = [], A[T] = C, /** @type {Array} */
              /** @type {any} */
              g.forEach(function(P, R) {
                C[R] = D(P, A);
              }), /** @type {any} */
              C);
            default:
              return g;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(D) {
          for (; D; ) {
            var g = a.exec(D.className);
            if (g)
              return g[1].toLowerCase();
            D = D.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(D, g) {
          D.className = D.className.replace(RegExp(a, "gi"), ""), D.classList.add("language-" + g);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (C) {
            var D = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(C.stack) || [])[1];
            if (D) {
              var g = document.getElementsByTagName("script");
              for (var A in g)
                if (g[A].src == D)
                  return g[A];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(D, g, A) {
          for (var C = "no-" + g; D; ) {
            var T = D.classList;
            if (T.contains(g))
              return !0;
            if (T.contains(C))
              return !1;
            D = D.parentElement;
          }
          return !!A;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(D, g) {
          var A = o.util.clone(o.languages[D]);
          for (var C in g)
            A[C] = g[C];
          return A;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(D, g, A, C) {
          C = C || /** @type {any} */
          o.languages;
          var T = C[D], z = {};
          for (var P in T)
            if (T.hasOwnProperty(P)) {
              if (P == g)
                for (var R in A)
                  A.hasOwnProperty(R) && (z[R] = A[R]);
              A.hasOwnProperty(P) || (z[P] = T[P]);
            }
          var Q = C[D];
          return C[D] = z, o.languages.DFS(o.languages, function(U, ee) {
            ee === Q && U != D && (this[U] = z);
          }), z;
        },
        // Traverse a language definition with Depth First Search
        DFS: function D(g, A, C, T) {
          T = T || {};
          var z = o.util.objId;
          for (var P in g)
            if (g.hasOwnProperty(P)) {
              A.call(g, P, g[P], C || P);
              var R = g[P], Q = o.util.type(R);
              Q === "Object" && !T[z(R)] ? (T[z(R)] = !0, D(R, A, null, T)) : Q === "Array" && !T[z(R)] && (T[z(R)] = !0, D(R, A, P, T));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(D, g) {
        o.highlightAllUnder(document, D, g);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(D, g, A) {
        var C = {
          callback: A,
          container: D,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", C), C.elements = Array.prototype.slice.apply(C.container.querySelectorAll(C.selector)), o.hooks.run("before-all-elements-highlight", C);
        for (var T = 0, z; z = C.elements[T++]; )
          o.highlightElement(z, g === !0, C.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(D, g, A) {
        var C = o.util.getLanguage(D), T = o.languages[C];
        o.util.setLanguage(D, C);
        var z = D.parentElement;
        z && z.nodeName.toLowerCase() === "pre" && o.util.setLanguage(z, C);
        var P = D.textContent, R = {
          element: D,
          language: C,
          grammar: T,
          code: P
        };
        function Q(ee) {
          R.highlightedCode = ee, o.hooks.run("before-insert", R), R.element.innerHTML = R.highlightedCode, o.hooks.run("after-highlight", R), o.hooks.run("complete", R), A && A.call(R.element);
        }
        if (o.hooks.run("before-sanity-check", R), z = R.element.parentElement, z && z.nodeName.toLowerCase() === "pre" && !z.hasAttribute("tabindex") && z.setAttribute("tabindex", "0"), !R.code) {
          o.hooks.run("complete", R), A && A.call(R.element);
          return;
        }
        if (o.hooks.run("before-highlight", R), !R.grammar) {
          Q(o.util.encode(R.code));
          return;
        }
        if (g && r.Worker) {
          var U = new Worker(o.filename);
          U.onmessage = function(ee) {
            Q(ee.data);
          }, U.postMessage(JSON.stringify({
            language: R.language,
            code: R.code,
            immediateClose: !0
          }));
        } else
          Q(o.highlight(R.code, R.grammar, R.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(D, g, A) {
        var C = {
          code: D,
          grammar: g,
          language: A
        };
        if (o.hooks.run("before-tokenize", C), !C.grammar)
          throw new Error('The language "' + C.language + '" has no grammar.');
        return C.tokens = o.tokenize(C.code, C.grammar), o.hooks.run("after-tokenize", C), c.stringify(o.util.encode(C.tokens), C.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(D, g) {
        var A = g.rest;
        if (A) {
          for (var C in A)
            g[C] = A[C];
          delete g.rest;
        }
        var T = new p();
        return y(T, T.head, D), d(D, T, g, T.head, 0), x(T);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(D, g) {
          var A = o.hooks.all;
          A[D] = A[D] || [], A[D].push(g);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(D, g) {
          var A = o.hooks.all[D];
          if (!(!A || !A.length))
            for (var C = 0, T; T = A[C++]; )
              T(g);
        }
      },
      Token: c
    };
    r.Prism = o;
    function c(D, g, A, C) {
      this.type = D, this.content = g, this.alias = A, this.length = (C || "").length | 0;
    }
    c.stringify = function D(g, A) {
      if (typeof g == "string")
        return g;
      if (Array.isArray(g)) {
        var C = "";
        return g.forEach(function(Q) {
          C += D(Q, A);
        }), C;
      }
      var T = {
        type: g.type,
        content: D(g.content, A),
        tag: "span",
        classes: ["token", g.type],
        attributes: {},
        language: A
      }, z = g.alias;
      z && (Array.isArray(z) ? Array.prototype.push.apply(T.classes, z) : T.classes.push(z)), o.hooks.run("wrap", T);
      var P = "";
      for (var R in T.attributes)
        P += " " + R + '="' + (T.attributes[R] || "").replace(/"/g, "&quot;") + '"';
      return "<" + T.tag + ' class="' + T.classes.join(" ") + '"' + P + ">" + T.content + "</" + T.tag + ">";
    };
    function m(D, g, A, C) {
      D.lastIndex = g;
      var T = D.exec(A);
      if (T && C && T[1]) {
        var z = T[1].length;
        T.index += z, T[0] = T[0].slice(z);
      }
      return T;
    }
    function d(D, g, A, C, T, z) {
      for (var P in A)
        if (!(!A.hasOwnProperty(P) || !A[P])) {
          var R = A[P];
          R = Array.isArray(R) ? R : [R];
          for (var Q = 0; Q < R.length; ++Q) {
            if (z && z.cause == P + "," + Q)
              return;
            var U = R[Q], ee = U.inside, Ce = !!U.lookbehind, ie = !!U.greedy, ye = U.alias;
            if (ie && !U.pattern.global) {
              var we = U.pattern.toString().match(/[imsuy]*$/)[0];
              U.pattern = RegExp(U.pattern.source, we + "g");
            }
            for (var He = U.pattern || U, se = C.next, Ae = T; se !== g.tail && !(z && Ae >= z.reach); Ae += se.value.length, se = se.next) {
              var ke = se.value;
              if (g.length > D.length)
                return;
              if (!(ke instanceof c)) {
                var te = 1, le;
                if (ie) {
                  if (le = m(He, Ae, D, Ce), !le || le.index >= D.length)
                    break;
                  var Ge = le.index, ce = le.index + le[0].length, Ee = Ae;
                  for (Ee += se.value.length; Ge >= Ee; )
                    se = se.next, Ee += se.value.length;
                  if (Ee -= se.value.length, Ae = Ee, se.value instanceof c)
                    continue;
                  for (var N = se; N !== g.tail && (Ee < ce || typeof N.value == "string"); N = N.next)
                    te++, Ee += N.value.length;
                  te--, ke = D.slice(Ae, Ee), le.index -= Ae;
                } else if (le = m(He, 0, ke, Ce), !le)
                  continue;
                var Ge = le.index, qe = le[0], Ye = ke.slice(0, Ge), st = ke.slice(Ge + qe.length), ot = Ae + ke.length;
                z && ot > z.reach && (z.reach = ot);
                var qt = se.prev;
                Ye && (qt = y(g, qt, Ye), Ae += Ye.length), v(g, qt, te);
                var vt = new c(P, ee ? o.tokenize(qe, ee) : qe, ye, qe);
                if (se = y(g, qt, vt), st && y(g, se, st), te > 1) {
                  var bt = {
                    cause: P + "," + Q,
                    reach: ot
                  };
                  d(D, g, A, se.prev, Ae, bt), z && bt.reach > z.reach && (z.reach = bt.reach);
                }
              }
            }
          }
        }
    }
    function p() {
      var D = { value: null, prev: null, next: null }, g = { value: null, prev: D, next: null };
      D.next = g, this.head = D, this.tail = g, this.length = 0;
    }
    function y(D, g, A) {
      var C = g.next, T = { value: A, prev: g, next: C };
      return g.next = T, C.prev = T, D.length++, T;
    }
    function v(D, g, A) {
      for (var C = g.next, T = 0; T < A && C !== D.tail; T++)
        C = C.next;
      g.next = C, C.prev = g, D.length -= T;
    }
    function x(D) {
      for (var g = [], A = D.head.next; A !== D.tail; )
        g.push(A.value), A = A.next;
      return g;
    }
    if (!r.document)
      return r.addEventListener && (o.disableWorkerMessageHandler || r.addEventListener("message", function(D) {
        var g = JSON.parse(D.data), A = g.language, C = g.code, T = g.immediateClose;
        r.postMessage(o.highlight(C, o.languages[A], A)), T && r.close();
      }, !1)), o;
    var S = o.util.currentScript();
    S && (o.filename = S.src, S.hasAttribute("data-manual") && (o.manual = !0));
    function F() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var E = document.readyState;
      E === "loading" || E === "interactive" && S && S.defer ? document.addEventListener("DOMContentLoaded", F) : window.requestAnimationFrame ? window.requestAnimationFrame(F) : window.setTimeout(F, 16);
    }
    return o;
  }(e);
  n.exports && (n.exports = t), typeof hi < "u" && (hi.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(r) {
    r.type === "entity" && (r.attributes.title = r.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, i) {
      var l = {};
      l["language-" + i] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[i]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      o["language-" + i] = {
        pattern: /[\s\S]+/,
        inside: t.languages[i]
      };
      var c = {};
      c[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", c);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(r, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + r + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(r) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    r.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, r.languages.css.atrule.inside.rest = r.languages.css;
    var i = r.languages.markup;
    i && (i.tag.addInlined("style", "css"), i.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var r = "Loading…", a = function(S, F) {
      return "✖ Error " + S + " while fetching file: " + F;
    }, i = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", c = "loading", m = "loaded", d = "failed", p = "pre[data-src]:not([" + o + '="' + m + '"]):not([' + o + '="' + c + '"])';
    function y(S, F, E) {
      var D = new XMLHttpRequest();
      D.open("GET", S, !0), D.onreadystatechange = function() {
        D.readyState == 4 && (D.status < 400 && D.responseText ? F(D.responseText) : D.status >= 400 ? E(a(D.status, D.statusText)) : E(i));
      }, D.send(null);
    }
    function v(S) {
      var F = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(S || "");
      if (F) {
        var E = Number(F[1]), D = F[2], g = F[3];
        return D ? g ? [E, Number(g)] : [E, void 0] : [E, E];
      }
    }
    t.hooks.add("before-highlightall", function(S) {
      S.selector += ", " + p;
    }), t.hooks.add("before-sanity-check", function(S) {
      var F = (
        /** @type {HTMLPreElement} */
        S.element
      );
      if (F.matches(p)) {
        S.code = "", F.setAttribute(o, c);
        var E = F.appendChild(document.createElement("CODE"));
        E.textContent = r;
        var D = F.getAttribute("data-src"), g = S.language;
        if (g === "none") {
          var A = (/\.(\w+)$/.exec(D) || [, "none"])[1];
          g = l[A] || A;
        }
        t.util.setLanguage(E, g), t.util.setLanguage(F, g);
        var C = t.plugins.autoloader;
        C && C.loadLanguages(g), y(
          D,
          function(T) {
            F.setAttribute(o, m);
            var z = v(F.getAttribute("data-range"));
            if (z) {
              var P = T.split(/\r\n?|\n/g), R = z[0], Q = z[1] == null ? P.length : z[1];
              R < 0 && (R += P.length), R = Math.max(0, Math.min(R - 1, P.length)), Q < 0 && (Q += P.length), Q = Math.max(0, Math.min(Q, P.length)), T = P.slice(R, Q).join(`
`), F.hasAttribute("data-start") || F.setAttribute("data-start", String(R + 1));
            }
            E.textContent = T, t.highlightElement(E);
          },
          function(T) {
            F.setAttribute(o, d), E.textContent = T;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(F) {
        for (var E = (F || document).querySelectorAll(p), D = 0, g; g = E[D++]; )
          t.highlightElement(g);
      }
    };
    var x = !1;
    t.fileHighlight = function() {
      x || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), x = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(mu);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(n) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  n.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, n.languages.tex = n.languages.latex, n.languages.context = n.languages.latex;
})(Prism);
(function(n) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, r = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  n.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: r
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: r.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: r.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = n.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], i = r.variable[1].inside, l = 0; l < a.length; l++)
    i[a[l]] = n.languages.bash[a[l]];
  n.languages.sh = n.languages.bash, n.languages.shell = n.languages.bash;
})(Prism);
new Ql();
const hu = (n) => {
  const e = {};
  for (let t = 0, r = n.length; t < r; t++) {
    const a = n[t];
    for (const i in a)
      e[i] ? e[i] = e[i].concat(a[i]) : e[i] = a[i];
  }
  return e;
}, du = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], fu = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], pu = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
hu([
  Object.fromEntries(du.map((n) => [n, ["*"]])),
  Object.fromEntries(fu.map((n) => [n, ["svg:*"]])),
  Object.fromEntries(pu.map((n) => [n, ["math:*"]]))
]);
const {
  HtmlTagHydration: gm,
  SvelteComponent: _m,
  attr: vm,
  binding_callbacks: bm,
  children: ym,
  claim_element: wm,
  claim_html_tag: km,
  detach: Dm,
  element: xm,
  init: Sm,
  insert_hydration: Am,
  noop: $m,
  safe_not_equal: Fm,
  toggle_class: Cm
} = window.__gradio__svelte__internal, { afterUpdate: Em, tick: Tm, onMount: Mm } = window.__gradio__svelte__internal, {
  SvelteComponent: zm,
  attr: Bm,
  children: qm,
  claim_component: Rm,
  claim_element: Nm,
  create_component: Im,
  destroy_component: Lm,
  detach: Om,
  element: Pm,
  init: Hm,
  insert_hydration: Um,
  mount_component: Vm,
  safe_not_equal: Gm,
  transition_in: Ym,
  transition_out: Wm
} = window.__gradio__svelte__internal, {
  SvelteComponent: jm,
  attr: Xm,
  check_outros: Zm,
  children: Km,
  claim_component: Qm,
  claim_element: Jm,
  claim_space: eh,
  create_component: th,
  create_slot: rh,
  destroy_component: nh,
  detach: ah,
  element: ih,
  empty: lh,
  get_all_dirty_from_scope: sh,
  get_slot_changes: oh,
  group_outros: uh,
  init: ch,
  insert_hydration: mh,
  mount_component: hh,
  safe_not_equal: dh,
  space: fh,
  toggle_class: ph,
  transition_in: gh,
  transition_out: _h,
  update_slot_base: vh
} = window.__gradio__svelte__internal, {
  SvelteComponent: bh,
  append_hydration: yh,
  attr: wh,
  children: kh,
  claim_component: Dh,
  claim_element: xh,
  claim_space: Sh,
  claim_text: Ah,
  create_component: $h,
  destroy_component: Fh,
  detach: Ch,
  element: Eh,
  init: Th,
  insert_hydration: Mh,
  mount_component: zh,
  safe_not_equal: Bh,
  set_data: qh,
  space: Rh,
  text: Nh,
  toggle_class: Ih,
  transition_in: Lh,
  transition_out: Oh
} = window.__gradio__svelte__internal, {
  SvelteComponent: gu,
  append_hydration: wr,
  attr: Ht,
  bubble: _u,
  check_outros: vu,
  children: An,
  claim_component: bu,
  claim_element: $n,
  claim_space: di,
  claim_text: yu,
  construct_svelte_component: fi,
  create_component: pi,
  create_slot: wu,
  destroy_component: gi,
  detach: U0,
  element: Fn,
  get_all_dirty_from_scope: ku,
  get_slot_changes: Du,
  group_outros: xu,
  init: Su,
  insert_hydration: Jl,
  listen: Au,
  mount_component: _i,
  safe_not_equal: $u,
  set_data: Fu,
  set_style: cr,
  space: vi,
  text: Cu,
  toggle_class: Be,
  transition_in: on,
  transition_out: un,
  update_slot_base: Eu
} = window.__gradio__svelte__internal;
function bi(n) {
  let e, t;
  return {
    c() {
      e = Fn("span"), t = Cu(
        /*label*/
        n[1]
      ), this.h();
    },
    l(r) {
      e = $n(r, "SPAN", { class: !0 });
      var a = An(e);
      t = yu(
        a,
        /*label*/
        n[1]
      ), a.forEach(U0), this.h();
    },
    h() {
      Ht(e, "class", "svelte-qgco6m");
    },
    m(r, a) {
      Jl(r, e, a), wr(e, t);
    },
    p(r, a) {
      a & /*label*/
      2 && Fu(
        t,
        /*label*/
        r[1]
      );
    },
    d(r) {
      r && U0(e);
    }
  };
}
function Tu(n) {
  let e, t, r, a, i, l, o, c, m = (
    /*show_label*/
    n[2] && bi(n)
  );
  var d = (
    /*Icon*/
    n[0]
  );
  function p(x, S) {
    return {};
  }
  d && (a = fi(d, p()));
  const y = (
    /*#slots*/
    n[14].default
  ), v = wu(
    y,
    n,
    /*$$scope*/
    n[13],
    null
  );
  return {
    c() {
      e = Fn("button"), m && m.c(), t = vi(), r = Fn("div"), a && pi(a.$$.fragment), i = vi(), v && v.c(), this.h();
    },
    l(x) {
      e = $n(x, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var S = An(e);
      m && m.l(S), t = di(S), r = $n(S, "DIV", { class: !0 });
      var F = An(r);
      a && bu(a.$$.fragment, F), i = di(F), v && v.l(F), F.forEach(U0), S.forEach(U0), this.h();
    },
    h() {
      Ht(r, "class", "svelte-qgco6m"), Be(
        r,
        "x-small",
        /*size*/
        n[4] === "x-small"
      ), Be(
        r,
        "small",
        /*size*/
        n[4] === "small"
      ), Be(
        r,
        "large",
        /*size*/
        n[4] === "large"
      ), Be(
        r,
        "medium",
        /*size*/
        n[4] === "medium"
      ), e.disabled = /*disabled*/
      n[7], Ht(
        e,
        "aria-label",
        /*label*/
        n[1]
      ), Ht(
        e,
        "aria-haspopup",
        /*hasPopup*/
        n[8]
      ), Ht(
        e,
        "title",
        /*label*/
        n[1]
      ), Ht(e, "class", "svelte-qgco6m"), Be(
        e,
        "pending",
        /*pending*/
        n[3]
      ), Be(
        e,
        "padded",
        /*padded*/
        n[5]
      ), Be(
        e,
        "highlight",
        /*highlight*/
        n[6]
      ), Be(
        e,
        "transparent",
        /*transparent*/
        n[9]
      ), cr(e, "color", !/*disabled*/
      n[7] && /*_color*/
      n[11] ? (
        /*_color*/
        n[11]
      ) : "var(--block-label-text-color)"), cr(e, "--bg-color", /*disabled*/
      n[7] ? "auto" : (
        /*background*/
        n[10]
      ));
    },
    m(x, S) {
      Jl(x, e, S), m && m.m(e, null), wr(e, t), wr(e, r), a && _i(a, r, null), wr(r, i), v && v.m(r, null), l = !0, o || (c = Au(
        e,
        "click",
        /*click_handler*/
        n[15]
      ), o = !0);
    },
    p(x, [S]) {
      if (/*show_label*/
      x[2] ? m ? m.p(x, S) : (m = bi(x), m.c(), m.m(e, t)) : m && (m.d(1), m = null), S & /*Icon*/
      1 && d !== (d = /*Icon*/
      x[0])) {
        if (a) {
          xu();
          const F = a;
          un(F.$$.fragment, 1, 0, () => {
            gi(F, 1);
          }), vu();
        }
        d ? (a = fi(d, p()), pi(a.$$.fragment), on(a.$$.fragment, 1), _i(a, r, i)) : a = null;
      }
      v && v.p && (!l || S & /*$$scope*/
      8192) && Eu(
        v,
        y,
        x,
        /*$$scope*/
        x[13],
        l ? Du(
          y,
          /*$$scope*/
          x[13],
          S,
          null
        ) : ku(
          /*$$scope*/
          x[13]
        ),
        null
      ), (!l || S & /*size*/
      16) && Be(
        r,
        "x-small",
        /*size*/
        x[4] === "x-small"
      ), (!l || S & /*size*/
      16) && Be(
        r,
        "small",
        /*size*/
        x[4] === "small"
      ), (!l || S & /*size*/
      16) && Be(
        r,
        "large",
        /*size*/
        x[4] === "large"
      ), (!l || S & /*size*/
      16) && Be(
        r,
        "medium",
        /*size*/
        x[4] === "medium"
      ), (!l || S & /*disabled*/
      128) && (e.disabled = /*disabled*/
      x[7]), (!l || S & /*label*/
      2) && Ht(
        e,
        "aria-label",
        /*label*/
        x[1]
      ), (!l || S & /*hasPopup*/
      256) && Ht(
        e,
        "aria-haspopup",
        /*hasPopup*/
        x[8]
      ), (!l || S & /*label*/
      2) && Ht(
        e,
        "title",
        /*label*/
        x[1]
      ), (!l || S & /*pending*/
      8) && Be(
        e,
        "pending",
        /*pending*/
        x[3]
      ), (!l || S & /*padded*/
      32) && Be(
        e,
        "padded",
        /*padded*/
        x[5]
      ), (!l || S & /*highlight*/
      64) && Be(
        e,
        "highlight",
        /*highlight*/
        x[6]
      ), (!l || S & /*transparent*/
      512) && Be(
        e,
        "transparent",
        /*transparent*/
        x[9]
      ), S & /*disabled, _color*/
      2176 && cr(e, "color", !/*disabled*/
      x[7] && /*_color*/
      x[11] ? (
        /*_color*/
        x[11]
      ) : "var(--block-label-text-color)"), S & /*disabled, background*/
      1152 && cr(e, "--bg-color", /*disabled*/
      x[7] ? "auto" : (
        /*background*/
        x[10]
      ));
    },
    i(x) {
      l || (a && on(a.$$.fragment, x), on(v, x), l = !0);
    },
    o(x) {
      a && un(a.$$.fragment, x), un(v, x), l = !1;
    },
    d(x) {
      x && U0(e), m && m.d(), a && gi(a), v && v.d(x), o = !1, c();
    }
  };
}
function Mu(n, e, t) {
  let r, { $$slots: a = {}, $$scope: i } = e, { Icon: l } = e, { label: o = "" } = e, { show_label: c = !1 } = e, { pending: m = !1 } = e, { size: d = "small" } = e, { padded: p = !0 } = e, { highlight: y = !1 } = e, { disabled: v = !1 } = e, { hasPopup: x = !1 } = e, { color: S = "var(--block-label-text-color)" } = e, { transparent: F = !1 } = e, { background: E = "var(--block-background-fill)" } = e;
  function D(g) {
    _u.call(this, n, g);
  }
  return n.$$set = (g) => {
    "Icon" in g && t(0, l = g.Icon), "label" in g && t(1, o = g.label), "show_label" in g && t(2, c = g.show_label), "pending" in g && t(3, m = g.pending), "size" in g && t(4, d = g.size), "padded" in g && t(5, p = g.padded), "highlight" in g && t(6, y = g.highlight), "disabled" in g && t(7, v = g.disabled), "hasPopup" in g && t(8, x = g.hasPopup), "color" in g && t(12, S = g.color), "transparent" in g && t(9, F = g.transparent), "background" in g && t(10, E = g.background), "$$scope" in g && t(13, i = g.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*highlight, color*/
    4160 && t(11, r = y ? "var(--color-accent)" : S);
  }, [
    l,
    o,
    c,
    m,
    d,
    p,
    y,
    v,
    x,
    F,
    E,
    r,
    S,
    i,
    a,
    D
  ];
}
class zu extends gu {
  constructor(e) {
    super(), Su(this, e, Mu, Tu, $u, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Ph,
  append_hydration: Hh,
  attr: Uh,
  binding_callbacks: Vh,
  children: Gh,
  claim_element: Yh,
  create_slot: Wh,
  detach: jh,
  element: Xh,
  get_all_dirty_from_scope: Zh,
  get_slot_changes: Kh,
  init: Qh,
  insert_hydration: Jh,
  safe_not_equal: e2,
  toggle_class: t2,
  transition_in: r2,
  transition_out: n2,
  update_slot_base: a2
} = window.__gradio__svelte__internal, {
  SvelteComponent: i2,
  append_hydration: l2,
  attr: s2,
  children: o2,
  claim_svg_element: u2,
  detach: c2,
  init: m2,
  insert_hydration: h2,
  noop: d2,
  safe_not_equal: f2,
  svg_element: p2
} = window.__gradio__svelte__internal, {
  SvelteComponent: g2,
  append_hydration: _2,
  attr: v2,
  children: b2,
  claim_svg_element: y2,
  detach: w2,
  init: k2,
  insert_hydration: D2,
  noop: x2,
  safe_not_equal: S2,
  svg_element: A2
} = window.__gradio__svelte__internal, {
  SvelteComponent: $2,
  append_hydration: F2,
  attr: C2,
  children: E2,
  claim_svg_element: T2,
  detach: M2,
  init: z2,
  insert_hydration: B2,
  noop: q2,
  safe_not_equal: R2,
  svg_element: N2
} = window.__gradio__svelte__internal, {
  SvelteComponent: I2,
  append_hydration: L2,
  attr: O2,
  children: P2,
  claim_svg_element: H2,
  detach: U2,
  init: V2,
  insert_hydration: G2,
  noop: Y2,
  safe_not_equal: W2,
  svg_element: j2
} = window.__gradio__svelte__internal, {
  SvelteComponent: X2,
  append_hydration: Z2,
  attr: K2,
  children: Q2,
  claim_svg_element: J2,
  detach: ed,
  init: td,
  insert_hydration: rd,
  noop: nd,
  safe_not_equal: ad,
  svg_element: id
} = window.__gradio__svelte__internal, {
  SvelteComponent: ld,
  append_hydration: sd,
  attr: od,
  children: ud,
  claim_svg_element: cd,
  detach: md,
  init: hd,
  insert_hydration: dd,
  noop: fd,
  safe_not_equal: pd,
  svg_element: gd
} = window.__gradio__svelte__internal, {
  SvelteComponent: _d,
  append_hydration: vd,
  attr: bd,
  children: yd,
  claim_svg_element: wd,
  detach: kd,
  init: Dd,
  insert_hydration: xd,
  noop: Sd,
  safe_not_equal: Ad,
  svg_element: $d
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fd,
  append_hydration: Cd,
  attr: Ed,
  children: Td,
  claim_svg_element: Md,
  detach: zd,
  init: Bd,
  insert_hydration: qd,
  noop: Rd,
  safe_not_equal: Nd,
  svg_element: Id
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ld,
  append_hydration: Od,
  attr: Pd,
  children: Hd,
  claim_svg_element: Ud,
  detach: Vd,
  init: Gd,
  insert_hydration: Yd,
  noop: Wd,
  safe_not_equal: jd,
  svg_element: Xd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zd,
  append_hydration: Kd,
  attr: Qd,
  children: Jd,
  claim_svg_element: e5,
  detach: t5,
  init: r5,
  insert_hydration: n5,
  noop: a5,
  safe_not_equal: i5,
  svg_element: l5
} = window.__gradio__svelte__internal, {
  SvelteComponent: s5,
  append_hydration: o5,
  attr: u5,
  children: c5,
  claim_svg_element: m5,
  detach: h5,
  init: d5,
  insert_hydration: f5,
  noop: p5,
  safe_not_equal: g5,
  svg_element: _5
} = window.__gradio__svelte__internal, {
  SvelteComponent: v5,
  append_hydration: b5,
  attr: y5,
  children: w5,
  claim_svg_element: k5,
  detach: D5,
  init: x5,
  insert_hydration: S5,
  noop: A5,
  safe_not_equal: $5,
  svg_element: F5
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bu,
  append_hydration: cn,
  attr: dt,
  children: mr,
  claim_svg_element: hr,
  detach: T0,
  init: qu,
  insert_hydration: Ru,
  noop: mn,
  safe_not_equal: Nu,
  set_style: kt,
  svg_element: dr
} = window.__gradio__svelte__internal;
function Iu(n) {
  let e, t, r, a;
  return {
    c() {
      e = dr("svg"), t = dr("g"), r = dr("path"), a = dr("path"), this.h();
    },
    l(i) {
      e = hr(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = mr(e);
      t = hr(l, "g", { transform: !0 });
      var o = mr(t);
      r = hr(o, "path", { d: !0, style: !0 }), mr(r).forEach(T0), o.forEach(T0), a = hr(l, "path", { d: !0, style: !0 }), mr(a).forEach(T0), l.forEach(T0), this.h();
    },
    h() {
      dt(r, "d", "M18,6L6.087,17.913"), kt(r, "fill", "none"), kt(r, "fill-rule", "nonzero"), kt(r, "stroke-width", "2px"), dt(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), dt(a, "d", "M4.364,4.364L19.636,19.636"), kt(a, "fill", "none"), kt(a, "fill-rule", "nonzero"), kt(a, "stroke-width", "2px"), dt(e, "width", "100%"), dt(e, "height", "100%"), dt(e, "viewBox", "0 0 24 24"), dt(e, "version", "1.1"), dt(e, "xmlns", "http://www.w3.org/2000/svg"), dt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), dt(e, "xml:space", "preserve"), dt(e, "stroke", "currentColor"), kt(e, "fill-rule", "evenodd"), kt(e, "clip-rule", "evenodd"), kt(e, "stroke-linecap", "round"), kt(e, "stroke-linejoin", "round");
    },
    m(i, l) {
      Ru(i, e, l), cn(e, t), cn(t, r), cn(e, a);
    },
    p: mn,
    i: mn,
    o: mn,
    d(i) {
      i && T0(e);
    }
  };
}
class Lu extends Bu {
  constructor(e) {
    super(), qu(this, e, null, Iu, Nu, {});
  }
}
const {
  SvelteComponent: C5,
  append_hydration: E5,
  attr: T5,
  children: M5,
  claim_svg_element: z5,
  detach: B5,
  init: q5,
  insert_hydration: R5,
  noop: N5,
  safe_not_equal: I5,
  svg_element: L5
} = window.__gradio__svelte__internal, {
  SvelteComponent: O5,
  append_hydration: P5,
  attr: H5,
  children: U5,
  claim_svg_element: V5,
  detach: G5,
  init: Y5,
  insert_hydration: W5,
  noop: j5,
  safe_not_equal: X5,
  svg_element: Z5
} = window.__gradio__svelte__internal, {
  SvelteComponent: K5,
  append_hydration: Q5,
  attr: J5,
  children: e3,
  claim_svg_element: t3,
  detach: r3,
  init: n3,
  insert_hydration: a3,
  noop: i3,
  safe_not_equal: l3,
  svg_element: s3
} = window.__gradio__svelte__internal, {
  SvelteComponent: o3,
  append_hydration: u3,
  attr: c3,
  children: m3,
  claim_svg_element: h3,
  detach: d3,
  init: f3,
  insert_hydration: p3,
  noop: g3,
  safe_not_equal: _3,
  svg_element: v3
} = window.__gradio__svelte__internal, {
  SvelteComponent: b3,
  append_hydration: y3,
  attr: w3,
  children: k3,
  claim_svg_element: D3,
  detach: x3,
  init: S3,
  insert_hydration: A3,
  noop: $3,
  safe_not_equal: F3,
  svg_element: C3
} = window.__gradio__svelte__internal, {
  SvelteComponent: E3,
  append_hydration: T3,
  attr: M3,
  children: z3,
  claim_svg_element: B3,
  detach: q3,
  init: R3,
  insert_hydration: N3,
  noop: I3,
  safe_not_equal: L3,
  svg_element: O3
} = window.__gradio__svelte__internal, {
  SvelteComponent: P3,
  append_hydration: H3,
  attr: U3,
  children: V3,
  claim_svg_element: G3,
  detach: Y3,
  init: W3,
  insert_hydration: j3,
  noop: X3,
  safe_not_equal: Z3,
  svg_element: K3
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q3,
  append_hydration: J3,
  attr: e6,
  children: t6,
  claim_svg_element: r6,
  detach: n6,
  init: a6,
  insert_hydration: i6,
  noop: l6,
  safe_not_equal: s6,
  svg_element: o6
} = window.__gradio__svelte__internal, {
  SvelteComponent: u6,
  append_hydration: c6,
  attr: m6,
  children: h6,
  claim_svg_element: d6,
  detach: f6,
  init: p6,
  insert_hydration: g6,
  noop: _6,
  safe_not_equal: v6,
  svg_element: b6
} = window.__gradio__svelte__internal, {
  SvelteComponent: y6,
  append_hydration: w6,
  attr: k6,
  children: D6,
  claim_svg_element: x6,
  detach: S6,
  init: A6,
  insert_hydration: $6,
  noop: F6,
  safe_not_equal: C6,
  svg_element: E6
} = window.__gradio__svelte__internal, {
  SvelteComponent: T6,
  append_hydration: M6,
  attr: z6,
  children: B6,
  claim_svg_element: q6,
  detach: R6,
  init: N6,
  insert_hydration: I6,
  noop: L6,
  safe_not_equal: O6,
  svg_element: P6
} = window.__gradio__svelte__internal, {
  SvelteComponent: H6,
  append_hydration: U6,
  attr: V6,
  children: G6,
  claim_svg_element: Y6,
  detach: W6,
  init: j6,
  insert_hydration: X6,
  noop: Z6,
  safe_not_equal: K6,
  svg_element: Q6
} = window.__gradio__svelte__internal, {
  SvelteComponent: J6,
  append_hydration: e7,
  attr: t7,
  children: r7,
  claim_svg_element: n7,
  detach: a7,
  init: i7,
  insert_hydration: l7,
  noop: s7,
  safe_not_equal: o7,
  svg_element: u7
} = window.__gradio__svelte__internal, {
  SvelteComponent: c7,
  append_hydration: m7,
  attr: h7,
  children: d7,
  claim_svg_element: f7,
  detach: p7,
  init: g7,
  insert_hydration: _7,
  noop: v7,
  safe_not_equal: b7,
  svg_element: y7
} = window.__gradio__svelte__internal, {
  SvelteComponent: w7,
  append_hydration: k7,
  attr: D7,
  children: x7,
  claim_svg_element: S7,
  detach: A7,
  init: $7,
  insert_hydration: F7,
  noop: C7,
  safe_not_equal: E7,
  svg_element: T7
} = window.__gradio__svelte__internal, {
  SvelteComponent: M7,
  append_hydration: z7,
  attr: B7,
  children: q7,
  claim_svg_element: R7,
  detach: N7,
  init: I7,
  insert_hydration: L7,
  noop: O7,
  safe_not_equal: P7,
  svg_element: H7
} = window.__gradio__svelte__internal, {
  SvelteComponent: U7,
  append_hydration: V7,
  attr: G7,
  children: Y7,
  claim_svg_element: W7,
  detach: j7,
  init: X7,
  insert_hydration: Z7,
  noop: K7,
  safe_not_equal: Q7,
  svg_element: J7
} = window.__gradio__svelte__internal, {
  SvelteComponent: ef,
  append_hydration: tf,
  attr: rf,
  children: nf,
  claim_svg_element: af,
  detach: lf,
  init: sf,
  insert_hydration: of,
  noop: uf,
  safe_not_equal: cf,
  svg_element: mf
} = window.__gradio__svelte__internal, {
  SvelteComponent: hf,
  append_hydration: df,
  attr: ff,
  children: pf,
  claim_svg_element: gf,
  detach: _f,
  init: vf,
  insert_hydration: bf,
  noop: yf,
  safe_not_equal: wf,
  svg_element: kf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Df,
  append_hydration: xf,
  attr: Sf,
  children: Af,
  claim_svg_element: $f,
  detach: Ff,
  init: Cf,
  insert_hydration: Ef,
  noop: Tf,
  safe_not_equal: Mf,
  svg_element: zf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bf,
  append_hydration: qf,
  attr: Rf,
  children: Nf,
  claim_svg_element: If,
  detach: Lf,
  init: Of,
  insert_hydration: Pf,
  noop: Hf,
  safe_not_equal: Uf,
  svg_element: Vf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gf,
  append_hydration: Yf,
  attr: Wf,
  children: jf,
  claim_svg_element: Xf,
  detach: Zf,
  init: Kf,
  insert_hydration: Qf,
  noop: Jf,
  safe_not_equal: ep,
  svg_element: tp
} = window.__gradio__svelte__internal, {
  SvelteComponent: rp,
  append_hydration: np,
  attr: ap,
  children: ip,
  claim_svg_element: lp,
  detach: sp,
  init: op,
  insert_hydration: up,
  noop: cp,
  safe_not_equal: mp,
  svg_element: hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: dp,
  append_hydration: fp,
  attr: pp,
  children: gp,
  claim_svg_element: _p,
  detach: vp,
  init: bp,
  insert_hydration: yp,
  noop: wp,
  safe_not_equal: kp,
  svg_element: Dp
} = window.__gradio__svelte__internal, {
  SvelteComponent: xp,
  append_hydration: Sp,
  attr: Ap,
  children: $p,
  claim_svg_element: Fp,
  detach: Cp,
  init: Ep,
  insert_hydration: Tp,
  noop: Mp,
  safe_not_equal: zp,
  svg_element: Bp
} = window.__gradio__svelte__internal, {
  SvelteComponent: qp,
  append_hydration: Rp,
  attr: Np,
  children: Ip,
  claim_svg_element: Lp,
  detach: Op,
  init: Pp,
  insert_hydration: Hp,
  noop: Up,
  safe_not_equal: Vp,
  svg_element: Gp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yp,
  append_hydration: Wp,
  attr: jp,
  children: Xp,
  claim_svg_element: Zp,
  detach: Kp,
  init: Qp,
  insert_hydration: Jp,
  noop: e8,
  safe_not_equal: t8,
  svg_element: r8
} = window.__gradio__svelte__internal, {
  SvelteComponent: n8,
  append_hydration: a8,
  attr: i8,
  children: l8,
  claim_svg_element: s8,
  detach: o8,
  init: u8,
  insert_hydration: c8,
  noop: m8,
  safe_not_equal: h8,
  svg_element: d8
} = window.__gradio__svelte__internal, {
  SvelteComponent: f8,
  append_hydration: p8,
  attr: g8,
  children: _8,
  claim_svg_element: v8,
  detach: b8,
  init: y8,
  insert_hydration: w8,
  noop: k8,
  safe_not_equal: D8,
  svg_element: x8
} = window.__gradio__svelte__internal, {
  SvelteComponent: S8,
  append_hydration: A8,
  attr: $8,
  children: F8,
  claim_svg_element: C8,
  detach: E8,
  init: T8,
  insert_hydration: M8,
  noop: z8,
  safe_not_equal: B8,
  svg_element: q8
} = window.__gradio__svelte__internal, {
  SvelteComponent: R8,
  append_hydration: N8,
  attr: I8,
  children: L8,
  claim_svg_element: O8,
  detach: P8,
  init: H8,
  insert_hydration: U8,
  noop: V8,
  safe_not_equal: G8,
  svg_element: Y8
} = window.__gradio__svelte__internal, {
  SvelteComponent: W8,
  append_hydration: j8,
  attr: X8,
  children: Z8,
  claim_svg_element: K8,
  detach: Q8,
  init: J8,
  insert_hydration: e9,
  noop: t9,
  safe_not_equal: r9,
  svg_element: n9
} = window.__gradio__svelte__internal, {
  SvelteComponent: a9,
  append_hydration: i9,
  attr: l9,
  children: s9,
  claim_svg_element: o9,
  detach: u9,
  init: c9,
  insert_hydration: m9,
  noop: h9,
  safe_not_equal: d9,
  svg_element: f9
} = window.__gradio__svelte__internal, {
  SvelteComponent: p9,
  append_hydration: g9,
  attr: _9,
  children: v9,
  claim_svg_element: b9,
  detach: y9,
  init: w9,
  insert_hydration: k9,
  noop: D9,
  safe_not_equal: x9,
  svg_element: S9
} = window.__gradio__svelte__internal, {
  SvelteComponent: A9,
  append_hydration: $9,
  attr: F9,
  children: C9,
  claim_svg_element: E9,
  detach: T9,
  init: M9,
  insert_hydration: z9,
  noop: B9,
  safe_not_equal: q9,
  set_style: R9,
  svg_element: N9
} = window.__gradio__svelte__internal, {
  SvelteComponent: I9,
  append_hydration: L9,
  attr: O9,
  children: P9,
  claim_svg_element: H9,
  detach: U9,
  init: V9,
  insert_hydration: G9,
  noop: Y9,
  safe_not_equal: W9,
  svg_element: j9
} = window.__gradio__svelte__internal, {
  SvelteComponent: X9,
  append_hydration: Z9,
  attr: K9,
  children: Q9,
  claim_svg_element: J9,
  detach: eg,
  init: tg,
  insert_hydration: rg,
  noop: ng,
  safe_not_equal: ag,
  svg_element: ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: lg,
  append_hydration: sg,
  attr: og,
  children: ug,
  claim_svg_element: cg,
  detach: mg,
  init: hg,
  insert_hydration: dg,
  noop: fg,
  safe_not_equal: pg,
  svg_element: gg
} = window.__gradio__svelte__internal, {
  SvelteComponent: _g,
  append_hydration: vg,
  attr: bg,
  children: yg,
  claim_svg_element: wg,
  detach: kg,
  init: Dg,
  insert_hydration: xg,
  noop: Sg,
  safe_not_equal: Ag,
  svg_element: $g
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fg,
  append_hydration: Cg,
  attr: Eg,
  children: Tg,
  claim_svg_element: Mg,
  detach: zg,
  init: Bg,
  insert_hydration: qg,
  noop: Rg,
  safe_not_equal: Ng,
  svg_element: Ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lg,
  append_hydration: Og,
  attr: Pg,
  children: Hg,
  claim_svg_element: Ug,
  detach: Vg,
  init: Gg,
  insert_hydration: Yg,
  noop: Wg,
  safe_not_equal: jg,
  svg_element: Xg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zg,
  append_hydration: Kg,
  attr: Qg,
  children: Jg,
  claim_svg_element: e_,
  detach: t_,
  init: r_,
  insert_hydration: n_,
  noop: a_,
  safe_not_equal: i_,
  svg_element: l_
} = window.__gradio__svelte__internal, {
  SvelteComponent: s_,
  append_hydration: o_,
  attr: u_,
  children: c_,
  claim_svg_element: m_,
  detach: h_,
  init: d_,
  insert_hydration: f_,
  noop: p_,
  safe_not_equal: g_,
  svg_element: __
} = window.__gradio__svelte__internal, {
  SvelteComponent: v_,
  append_hydration: b_,
  attr: y_,
  children: w_,
  claim_svg_element: k_,
  claim_text: D_,
  detach: x_,
  init: S_,
  insert_hydration: A_,
  noop: $_,
  safe_not_equal: F_,
  svg_element: C_,
  text: E_
} = window.__gradio__svelte__internal, {
  SvelteComponent: T_,
  append_hydration: M_,
  attr: z_,
  children: B_,
  claim_svg_element: q_,
  detach: R_,
  init: N_,
  insert_hydration: I_,
  noop: L_,
  safe_not_equal: O_,
  svg_element: P_
} = window.__gradio__svelte__internal, {
  SvelteComponent: H_,
  append_hydration: U_,
  attr: V_,
  children: G_,
  claim_svg_element: Y_,
  detach: W_,
  init: j_,
  insert_hydration: X_,
  noop: Z_,
  safe_not_equal: K_,
  svg_element: Q_
} = window.__gradio__svelte__internal, {
  SvelteComponent: J_,
  append_hydration: ev,
  attr: tv,
  children: rv,
  claim_svg_element: nv,
  detach: av,
  init: iv,
  insert_hydration: lv,
  noop: sv,
  safe_not_equal: ov,
  svg_element: uv
} = window.__gradio__svelte__internal, {
  SvelteComponent: cv,
  append_hydration: mv,
  attr: hv,
  children: dv,
  claim_svg_element: fv,
  detach: pv,
  init: gv,
  insert_hydration: _v,
  noop: vv,
  safe_not_equal: bv,
  svg_element: yv
} = window.__gradio__svelte__internal, {
  SvelteComponent: wv,
  append_hydration: kv,
  attr: Dv,
  children: xv,
  claim_svg_element: Sv,
  detach: Av,
  init: $v,
  insert_hydration: Fv,
  noop: Cv,
  safe_not_equal: Ev,
  svg_element: Tv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mv,
  append_hydration: zv,
  attr: Bv,
  children: qv,
  claim_svg_element: Rv,
  detach: Nv,
  init: Iv,
  insert_hydration: Lv,
  noop: Ov,
  safe_not_equal: Pv,
  svg_element: Hv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uv,
  append_hydration: Vv,
  attr: Gv,
  children: Yv,
  claim_svg_element: Wv,
  detach: jv,
  init: Xv,
  insert_hydration: Zv,
  noop: Kv,
  safe_not_equal: Qv,
  svg_element: Jv
} = window.__gradio__svelte__internal, {
  SvelteComponent: eb,
  append_hydration: tb,
  attr: rb,
  children: nb,
  claim_svg_element: ab,
  claim_text: ib,
  detach: lb,
  init: sb,
  insert_hydration: ob,
  noop: ub,
  safe_not_equal: cb,
  svg_element: mb,
  text: hb
} = window.__gradio__svelte__internal, {
  SvelteComponent: db,
  append_hydration: fb,
  attr: pb,
  children: gb,
  claim_svg_element: _b,
  claim_text: vb,
  detach: bb,
  init: yb,
  insert_hydration: wb,
  noop: kb,
  safe_not_equal: Db,
  svg_element: xb,
  text: Sb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ab,
  append_hydration: $b,
  attr: Fb,
  children: Cb,
  claim_svg_element: Eb,
  claim_text: Tb,
  detach: Mb,
  init: zb,
  insert_hydration: Bb,
  noop: qb,
  safe_not_equal: Rb,
  svg_element: Nb,
  text: Ib
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lb,
  append_hydration: Ob,
  attr: Pb,
  children: Hb,
  claim_svg_element: Ub,
  detach: Vb,
  init: Gb,
  insert_hydration: Yb,
  noop: Wb,
  safe_not_equal: jb,
  svg_element: Xb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zb,
  append_hydration: Kb,
  attr: Qb,
  children: Jb,
  claim_svg_element: ey,
  detach: ty,
  init: ry,
  insert_hydration: ny,
  noop: ay,
  safe_not_equal: iy,
  svg_element: ly
} = window.__gradio__svelte__internal, {
  SvelteComponent: sy,
  append_hydration: oy,
  attr: uy,
  children: cy,
  claim_svg_element: my,
  detach: hy,
  init: dy,
  insert_hydration: fy,
  noop: py,
  safe_not_equal: gy,
  svg_element: _y
} = window.__gradio__svelte__internal, {
  SvelteComponent: vy,
  append_hydration: by,
  attr: yy,
  children: wy,
  claim_svg_element: ky,
  detach: Dy,
  init: xy,
  insert_hydration: Sy,
  noop: Ay,
  safe_not_equal: $y,
  svg_element: Fy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cy,
  append_hydration: Ey,
  attr: Ty,
  children: My,
  claim_svg_element: zy,
  detach: By,
  init: qy,
  insert_hydration: Ry,
  noop: Ny,
  safe_not_equal: Iy,
  svg_element: Ly
} = window.__gradio__svelte__internal, {
  SvelteComponent: Oy,
  append_hydration: Py,
  attr: Hy,
  children: Uy,
  claim_svg_element: Vy,
  detach: Gy,
  init: Yy,
  insert_hydration: Wy,
  noop: jy,
  safe_not_equal: Xy,
  svg_element: Zy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ky,
  append_hydration: Qy,
  attr: Jy,
  children: ew,
  claim_svg_element: tw,
  detach: rw,
  init: nw,
  insert_hydration: aw,
  noop: iw,
  safe_not_equal: lw,
  svg_element: sw
} = window.__gradio__svelte__internal, {
  SvelteComponent: ow,
  append_hydration: uw,
  attr: cw,
  children: mw,
  claim_svg_element: hw,
  detach: dw,
  init: fw,
  insert_hydration: pw,
  noop: gw,
  safe_not_equal: _w,
  svg_element: vw
} = window.__gradio__svelte__internal, Ou = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], yi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Ou.reduce(
  (n, { color: e, primary: t, secondary: r }) => ({
    ...n,
    [e]: {
      primary: yi[e][t],
      secondary: yi[e][r]
    }
  }),
  {}
);
const {
  SvelteComponent: bw,
  claim_component: yw,
  create_component: ww,
  destroy_component: kw,
  init: Dw,
  mount_component: xw,
  safe_not_equal: Sw,
  transition_in: Aw,
  transition_out: $w
} = window.__gradio__svelte__internal, { createEventDispatcher: Fw } = window.__gradio__svelte__internal, {
  SvelteComponent: Cw,
  append_hydration: Ew,
  attr: Tw,
  check_outros: Mw,
  children: zw,
  claim_component: Bw,
  claim_element: qw,
  claim_space: Rw,
  claim_text: Nw,
  create_component: Iw,
  destroy_component: Lw,
  detach: Ow,
  element: Pw,
  empty: Hw,
  group_outros: Uw,
  init: Vw,
  insert_hydration: Gw,
  mount_component: Yw,
  safe_not_equal: Ww,
  set_data: jw,
  space: Xw,
  text: Zw,
  toggle_class: Kw,
  transition_in: Qw,
  transition_out: Jw
} = window.__gradio__svelte__internal, {
  SvelteComponent: ek,
  attr: tk,
  children: rk,
  claim_element: nk,
  create_slot: ak,
  detach: ik,
  element: lk,
  get_all_dirty_from_scope: sk,
  get_slot_changes: ok,
  init: uk,
  insert_hydration: ck,
  safe_not_equal: mk,
  toggle_class: hk,
  transition_in: dk,
  transition_out: fk,
  update_slot_base: pk
} = window.__gradio__svelte__internal, {
  SvelteComponent: gk,
  append_hydration: _k,
  attr: vk,
  check_outros: bk,
  children: yk,
  claim_component: wk,
  claim_element: kk,
  claim_space: Dk,
  create_component: xk,
  destroy_component: Sk,
  detach: Ak,
  element: $k,
  empty: Fk,
  group_outros: Ck,
  init: Ek,
  insert_hydration: Tk,
  listen: Mk,
  mount_component: zk,
  safe_not_equal: Bk,
  space: qk,
  toggle_class: Rk,
  transition_in: Nk,
  transition_out: Ik
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lk,
  attr: Ok,
  children: Pk,
  claim_element: Hk,
  create_slot: Uk,
  detach: Vk,
  element: Gk,
  get_all_dirty_from_scope: Yk,
  get_slot_changes: Wk,
  init: jk,
  insert_hydration: Xk,
  null_to_empty: Zk,
  safe_not_equal: Kk,
  transition_in: Qk,
  transition_out: Jk,
  update_slot_base: eD
} = window.__gradio__svelte__internal, {
  SvelteComponent: tD,
  check_outros: rD,
  claim_component: nD,
  create_component: aD,
  destroy_component: iD,
  detach: lD,
  empty: sD,
  group_outros: oD,
  init: uD,
  insert_hydration: cD,
  mount_component: mD,
  noop: hD,
  safe_not_equal: dD,
  transition_in: fD,
  transition_out: pD
} = window.__gradio__svelte__internal, { createEventDispatcher: gD } = window.__gradio__svelte__internal, {
  SvelteComponent: Pu,
  append_hydration: i0,
  attr: _t,
  binding_callbacks: wi,
  check_outros: Cn,
  children: $t,
  claim_component: es,
  claim_element: Ft,
  claim_space: tt,
  claim_text: _e,
  create_component: ts,
  create_slot: rs,
  destroy_component: ns,
  destroy_each: as,
  detach: Y,
  element: Ct,
  empty: at,
  ensure_array_like: Mr,
  get_all_dirty_from_scope: is,
  get_slot_changes: ls,
  group_outros: En,
  init: Hu,
  insert_hydration: K,
  mount_component: ss,
  noop: Tn,
  safe_not_equal: Uu,
  set_data: it,
  set_style: Qt,
  space: rt,
  text: ve,
  toggle_class: Qe,
  transition_in: gt,
  transition_out: Et,
  update_slot_base: os
} = window.__gradio__svelte__internal, { tick: Vu } = window.__gradio__svelte__internal, { onDestroy: Gu } = window.__gradio__svelte__internal, { createEventDispatcher: Yu } = window.__gradio__svelte__internal, Wu = (n) => ({}), ki = (n) => ({}), ju = (n) => ({}), Di = (n) => ({});
function xi(n, e, t) {
  const r = n.slice();
  return r[40] = e[t], r[42] = t, r;
}
function Si(n, e, t) {
  const r = n.slice();
  return r[40] = e[t], r;
}
function Xu(n) {
  let e, t, r, a, i = (
    /*i18n*/
    n[1]("common.error") + ""
  ), l, o, c;
  t = new zu({
    props: {
      Icon: Lu,
      label: (
        /*i18n*/
        n[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    n[32]
  );
  const m = (
    /*#slots*/
    n[30].error
  ), d = rs(
    m,
    n,
    /*$$scope*/
    n[29],
    ki
  );
  return {
    c() {
      e = Ct("div"), ts(t.$$.fragment), r = rt(), a = Ct("span"), l = ve(i), o = rt(), d && d.c(), this.h();
    },
    l(p) {
      e = Ft(p, "DIV", { class: !0 });
      var y = $t(e);
      es(t.$$.fragment, y), y.forEach(Y), r = tt(p), a = Ft(p, "SPAN", { class: !0 });
      var v = $t(a);
      l = _e(v, i), v.forEach(Y), o = tt(p), d && d.l(p), this.h();
    },
    h() {
      _t(e, "class", "clear-status svelte-17v219f"), _t(a, "class", "error svelte-17v219f");
    },
    m(p, y) {
      K(p, e, y), ss(t, e, null), K(p, r, y), K(p, a, y), i0(a, l), K(p, o, y), d && d.m(p, y), c = !0;
    },
    p(p, y) {
      const v = {};
      y[0] & /*i18n*/
      2 && (v.label = /*i18n*/
      p[1]("common.clear")), t.$set(v), (!c || y[0] & /*i18n*/
      2) && i !== (i = /*i18n*/
      p[1]("common.error") + "") && it(l, i), d && d.p && (!c || y[0] & /*$$scope*/
      536870912) && os(
        d,
        m,
        p,
        /*$$scope*/
        p[29],
        c ? ls(
          m,
          /*$$scope*/
          p[29],
          y,
          Wu
        ) : is(
          /*$$scope*/
          p[29]
        ),
        ki
      );
    },
    i(p) {
      c || (gt(t.$$.fragment, p), gt(d, p), c = !0);
    },
    o(p) {
      Et(t.$$.fragment, p), Et(d, p), c = !1;
    },
    d(p) {
      p && (Y(e), Y(r), Y(a), Y(o)), ns(t), d && d.d(p);
    }
  };
}
function Zu(n) {
  let e, t, r, a, i, l, o, c, m, d = (
    /*variant*/
    n[8] === "default" && /*show_eta_bar*/
    n[18] && /*show_progress*/
    n[6] === "full" && Ai(n)
  );
  function p(g, A) {
    if (
      /*progress*/
      g[7]
    ) return Ju;
    if (
      /*queue_position*/
      g[2] !== null && /*queue_size*/
      g[3] !== void 0 && /*queue_position*/
      g[2] >= 0
    ) return Qu;
    if (
      /*queue_position*/
      g[2] === 0
    ) return Ku;
  }
  let y = p(n), v = y && y(n), x = (
    /*timer*/
    n[5] && Ci(n)
  );
  const S = [n4, r4], F = [];
  function E(g, A) {
    return (
      /*last_progress_level*/
      g[15] != null ? 0 : (
        /*show_progress*/
        g[6] === "full" ? 1 : -1
      )
    );
  }
  ~(i = E(n)) && (l = F[i] = S[i](n));
  let D = !/*timer*/
  n[5] && Ri(n);
  return {
    c() {
      d && d.c(), e = rt(), t = Ct("div"), v && v.c(), r = rt(), x && x.c(), a = rt(), l && l.c(), o = rt(), D && D.c(), c = at(), this.h();
    },
    l(g) {
      d && d.l(g), e = tt(g), t = Ft(g, "DIV", { class: !0 });
      var A = $t(t);
      v && v.l(A), r = tt(A), x && x.l(A), A.forEach(Y), a = tt(g), l && l.l(g), o = tt(g), D && D.l(g), c = at(), this.h();
    },
    h() {
      _t(t, "class", "progress-text svelte-17v219f"), Qe(
        t,
        "meta-text-center",
        /*variant*/
        n[8] === "center"
      ), Qe(
        t,
        "meta-text",
        /*variant*/
        n[8] === "default"
      );
    },
    m(g, A) {
      d && d.m(g, A), K(g, e, A), K(g, t, A), v && v.m(t, null), i0(t, r), x && x.m(t, null), K(g, a, A), ~i && F[i].m(g, A), K(g, o, A), D && D.m(g, A), K(g, c, A), m = !0;
    },
    p(g, A) {
      /*variant*/
      g[8] === "default" && /*show_eta_bar*/
      g[18] && /*show_progress*/
      g[6] === "full" ? d ? d.p(g, A) : (d = Ai(g), d.c(), d.m(e.parentNode, e)) : d && (d.d(1), d = null), y === (y = p(g)) && v ? v.p(g, A) : (v && v.d(1), v = y && y(g), v && (v.c(), v.m(t, r))), /*timer*/
      g[5] ? x ? x.p(g, A) : (x = Ci(g), x.c(), x.m(t, null)) : x && (x.d(1), x = null), (!m || A[0] & /*variant*/
      256) && Qe(
        t,
        "meta-text-center",
        /*variant*/
        g[8] === "center"
      ), (!m || A[0] & /*variant*/
      256) && Qe(
        t,
        "meta-text",
        /*variant*/
        g[8] === "default"
      );
      let C = i;
      i = E(g), i === C ? ~i && F[i].p(g, A) : (l && (En(), Et(F[C], 1, 1, () => {
        F[C] = null;
      }), Cn()), ~i ? (l = F[i], l ? l.p(g, A) : (l = F[i] = S[i](g), l.c()), gt(l, 1), l.m(o.parentNode, o)) : l = null), /*timer*/
      g[5] ? D && (En(), Et(D, 1, 1, () => {
        D = null;
      }), Cn()) : D ? (D.p(g, A), A[0] & /*timer*/
      32 && gt(D, 1)) : (D = Ri(g), D.c(), gt(D, 1), D.m(c.parentNode, c));
    },
    i(g) {
      m || (gt(l), gt(D), m = !0);
    },
    o(g) {
      Et(l), Et(D), m = !1;
    },
    d(g) {
      g && (Y(e), Y(t), Y(a), Y(o), Y(c)), d && d.d(g), v && v.d(), x && x.d(), ~i && F[i].d(g), D && D.d(g);
    }
  };
}
function Ai(n) {
  let e, t = `translateX(${/*eta_level*/
  (n[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Ct("div"), this.h();
    },
    l(r) {
      e = Ft(r, "DIV", { class: !0 }), $t(e).forEach(Y), this.h();
    },
    h() {
      _t(e, "class", "eta-bar svelte-17v219f"), Qt(e, "transform", t);
    },
    m(r, a) {
      K(r, e, a);
    },
    p(r, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (r[17] || 0) * 100 - 100}%)`) && Qt(e, "transform", t);
    },
    d(r) {
      r && Y(e);
    }
  };
}
function Ku(n) {
  let e;
  return {
    c() {
      e = ve("processing |");
    },
    l(t) {
      e = _e(t, "processing |");
    },
    m(t, r) {
      K(t, e, r);
    },
    p: Tn,
    d(t) {
      t && Y(e);
    }
  };
}
function Qu(n) {
  let e, t = (
    /*queue_position*/
    n[2] + 1 + ""
  ), r, a, i, l;
  return {
    c() {
      e = ve("queue: "), r = ve(t), a = ve("/"), i = ve(
        /*queue_size*/
        n[3]
      ), l = ve(" |");
    },
    l(o) {
      e = _e(o, "queue: "), r = _e(o, t), a = _e(o, "/"), i = _e(
        o,
        /*queue_size*/
        n[3]
      ), l = _e(o, " |");
    },
    m(o, c) {
      K(o, e, c), K(o, r, c), K(o, a, c), K(o, i, c), K(o, l, c);
    },
    p(o, c) {
      c[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      o[2] + 1 + "") && it(r, t), c[0] & /*queue_size*/
      8 && it(
        i,
        /*queue_size*/
        o[3]
      );
    },
    d(o) {
      o && (Y(e), Y(r), Y(a), Y(i), Y(l));
    }
  };
}
function Ju(n) {
  let e, t = Mr(
    /*progress*/
    n[7]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = Fi(Si(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = at();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = at();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      K(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress*/
      128) {
        t = Mr(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = Si(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = Fi(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && Y(e), as(r, a);
    }
  };
}
function $i(n) {
  let e, t = (
    /*p*/
    n[40].unit + ""
  ), r, a, i = " ", l;
  function o(d, p) {
    return (
      /*p*/
      d[40].length != null ? t4 : e4
    );
  }
  let c = o(n), m = c(n);
  return {
    c() {
      m.c(), e = rt(), r = ve(t), a = ve(" | "), l = ve(i);
    },
    l(d) {
      m.l(d), e = tt(d), r = _e(d, t), a = _e(d, " | "), l = _e(d, i);
    },
    m(d, p) {
      m.m(d, p), K(d, e, p), K(d, r, p), K(d, a, p), K(d, l, p);
    },
    p(d, p) {
      c === (c = o(d)) && m ? m.p(d, p) : (m.d(1), m = c(d), m && (m.c(), m.m(e.parentNode, e))), p[0] & /*progress*/
      128 && t !== (t = /*p*/
      d[40].unit + "") && it(r, t);
    },
    d(d) {
      d && (Y(e), Y(r), Y(a), Y(l)), m.d(d);
    }
  };
}
function e4(n) {
  let e = y0(
    /*p*/
    n[40].index || 0
  ) + "", t;
  return {
    c() {
      t = ve(e);
    },
    l(r) {
      t = _e(r, e);
    },
    m(r, a) {
      K(r, t, a);
    },
    p(r, a) {
      a[0] & /*progress*/
      128 && e !== (e = y0(
        /*p*/
        r[40].index || 0
      ) + "") && it(t, e);
    },
    d(r) {
      r && Y(t);
    }
  };
}
function t4(n) {
  let e = y0(
    /*p*/
    n[40].index || 0
  ) + "", t, r, a = y0(
    /*p*/
    n[40].length
  ) + "", i;
  return {
    c() {
      t = ve(e), r = ve("/"), i = ve(a);
    },
    l(l) {
      t = _e(l, e), r = _e(l, "/"), i = _e(l, a);
    },
    m(l, o) {
      K(l, t, o), K(l, r, o), K(l, i, o);
    },
    p(l, o) {
      o[0] & /*progress*/
      128 && e !== (e = y0(
        /*p*/
        l[40].index || 0
      ) + "") && it(t, e), o[0] & /*progress*/
      128 && a !== (a = y0(
        /*p*/
        l[40].length
      ) + "") && it(i, a);
    },
    d(l) {
      l && (Y(t), Y(r), Y(i));
    }
  };
}
function Fi(n) {
  let e, t = (
    /*p*/
    n[40].index != null && $i(n)
  );
  return {
    c() {
      t && t.c(), e = at();
    },
    l(r) {
      t && t.l(r), e = at();
    },
    m(r, a) {
      t && t.m(r, a), K(r, e, a);
    },
    p(r, a) {
      /*p*/
      r[40].index != null ? t ? t.p(r, a) : (t = $i(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && Y(e), t && t.d(r);
    }
  };
}
function Ci(n) {
  let e, t = (
    /*eta*/
    n[0] ? `/${/*formatted_eta*/
    n[19]}` : ""
  ), r, a;
  return {
    c() {
      e = ve(
        /*formatted_timer*/
        n[20]
      ), r = ve(t), a = ve("s");
    },
    l(i) {
      e = _e(
        i,
        /*formatted_timer*/
        n[20]
      ), r = _e(i, t), a = _e(i, "s");
    },
    m(i, l) {
      K(i, e, l), K(i, r, l), K(i, a, l);
    },
    p(i, l) {
      l[0] & /*formatted_timer*/
      1048576 && it(
        e,
        /*formatted_timer*/
        i[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      i[0] ? `/${/*formatted_eta*/
      i[19]}` : "") && it(r, t);
    },
    d(i) {
      i && (Y(e), Y(r), Y(a));
    }
  };
}
function r4(n) {
  let e, t;
  return e = new Hs({
    props: { margin: (
      /*variant*/
      n[8] === "default"
    ) }
  }), {
    c() {
      ts(e.$$.fragment);
    },
    l(r) {
      es(e.$$.fragment, r);
    },
    m(r, a) {
      ss(e, r, a), t = !0;
    },
    p(r, a) {
      const i = {};
      a[0] & /*variant*/
      256 && (i.margin = /*variant*/
      r[8] === "default"), e.$set(i);
    },
    i(r) {
      t || (gt(e.$$.fragment, r), t = !0);
    },
    o(r) {
      Et(e.$$.fragment, r), t = !1;
    },
    d(r) {
      ns(e, r);
    }
  };
}
function n4(n) {
  let e, t, r, a, i, l = `${/*last_progress_level*/
  n[15] * 100}%`, o = (
    /*progress*/
    n[7] != null && Ei(n)
  );
  return {
    c() {
      e = Ct("div"), t = Ct("div"), o && o.c(), r = rt(), a = Ct("div"), i = Ct("div"), this.h();
    },
    l(c) {
      e = Ft(c, "DIV", { class: !0 });
      var m = $t(e);
      t = Ft(m, "DIV", { class: !0 });
      var d = $t(t);
      o && o.l(d), d.forEach(Y), r = tt(m), a = Ft(m, "DIV", { class: !0 });
      var p = $t(a);
      i = Ft(p, "DIV", { class: !0 }), $t(i).forEach(Y), p.forEach(Y), m.forEach(Y), this.h();
    },
    h() {
      _t(t, "class", "progress-level-inner svelte-17v219f"), _t(i, "class", "progress-bar svelte-17v219f"), Qt(i, "width", l), _t(a, "class", "progress-bar-wrap svelte-17v219f"), _t(e, "class", "progress-level svelte-17v219f");
    },
    m(c, m) {
      K(c, e, m), i0(e, t), o && o.m(t, null), i0(e, r), i0(e, a), i0(a, i), n[31](i);
    },
    p(c, m) {
      /*progress*/
      c[7] != null ? o ? o.p(c, m) : (o = Ei(c), o.c(), o.m(t, null)) : o && (o.d(1), o = null), m[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      c[15] * 100}%`) && Qt(i, "width", l);
    },
    i: Tn,
    o: Tn,
    d(c) {
      c && Y(e), o && o.d(), n[31](null);
    }
  };
}
function Ei(n) {
  let e, t = Mr(
    /*progress*/
    n[7]
  ), r = [];
  for (let a = 0; a < t.length; a += 1)
    r[a] = qi(xi(n, t, a));
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      e = at();
    },
    l(a) {
      for (let i = 0; i < r.length; i += 1)
        r[i].l(a);
      e = at();
    },
    m(a, i) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(a, i);
      K(a, e, i);
    },
    p(a, i) {
      if (i[0] & /*progress_level, progress*/
      16512) {
        t = Mr(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = xi(a, t, l);
          r[l] ? r[l].p(o, i) : (r[l] = qi(o), r[l].c(), r[l].m(e.parentNode, e));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = t.length;
      }
    },
    d(a) {
      a && Y(e), as(r, a);
    }
  };
}
function Ti(n) {
  let e, t, r, a, i = (
    /*i*/
    n[42] !== 0 && a4()
  ), l = (
    /*p*/
    n[40].desc != null && Mi(n)
  ), o = (
    /*p*/
    n[40].desc != null && /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null && zi()
  ), c = (
    /*progress_level*/
    n[14] != null && Bi(n)
  );
  return {
    c() {
      i && i.c(), e = rt(), l && l.c(), t = rt(), o && o.c(), r = rt(), c && c.c(), a = at();
    },
    l(m) {
      i && i.l(m), e = tt(m), l && l.l(m), t = tt(m), o && o.l(m), r = tt(m), c && c.l(m), a = at();
    },
    m(m, d) {
      i && i.m(m, d), K(m, e, d), l && l.m(m, d), K(m, t, d), o && o.m(m, d), K(m, r, d), c && c.m(m, d), K(m, a, d);
    },
    p(m, d) {
      /*p*/
      m[40].desc != null ? l ? l.p(m, d) : (l = Mi(m), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      m[40].desc != null && /*progress_level*/
      m[14] && /*progress_level*/
      m[14][
        /*i*/
        m[42]
      ] != null ? o || (o = zi(), o.c(), o.m(r.parentNode, r)) : o && (o.d(1), o = null), /*progress_level*/
      m[14] != null ? c ? c.p(m, d) : (c = Bi(m), c.c(), c.m(a.parentNode, a)) : c && (c.d(1), c = null);
    },
    d(m) {
      m && (Y(e), Y(t), Y(r), Y(a)), i && i.d(m), l && l.d(m), o && o.d(m), c && c.d(m);
    }
  };
}
function a4(n) {
  let e;
  return {
    c() {
      e = ve(" /");
    },
    l(t) {
      e = _e(t, " /");
    },
    m(t, r) {
      K(t, e, r);
    },
    d(t) {
      t && Y(e);
    }
  };
}
function Mi(n) {
  let e = (
    /*p*/
    n[40].desc + ""
  ), t;
  return {
    c() {
      t = ve(e);
    },
    l(r) {
      t = _e(r, e);
    },
    m(r, a) {
      K(r, t, a);
    },
    p(r, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      r[40].desc + "") && it(t, e);
    },
    d(r) {
      r && Y(t);
    }
  };
}
function zi(n) {
  let e;
  return {
    c() {
      e = ve("-");
    },
    l(t) {
      e = _e(t, "-");
    },
    m(t, r) {
      K(t, e, r);
    },
    d(t) {
      t && Y(e);
    }
  };
}
function Bi(n) {
  let e = (100 * /*progress_level*/
  (n[14][
    /*i*/
    n[42]
  ] || 0)).toFixed(1) + "", t, r;
  return {
    c() {
      t = ve(e), r = ve("%");
    },
    l(a) {
      t = _e(a, e), r = _e(a, "%");
    },
    m(a, i) {
      K(a, t, i), K(a, r, i);
    },
    p(a, i) {
      i[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[42]
      ] || 0)).toFixed(1) + "") && it(t, e);
    },
    d(a) {
      a && (Y(t), Y(r));
    }
  };
}
function qi(n) {
  let e, t = (
    /*p*/
    (n[40].desc != null || /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null) && Ti(n)
  );
  return {
    c() {
      t && t.c(), e = at();
    },
    l(r) {
      t && t.l(r), e = at();
    },
    m(r, a) {
      t && t.m(r, a), K(r, e, a);
    },
    p(r, a) {
      /*p*/
      r[40].desc != null || /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[42]
      ] != null ? t ? t.p(r, a) : (t = Ti(r), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(r) {
      r && Y(e), t && t.d(r);
    }
  };
}
function Ri(n) {
  let e, t, r, a;
  const i = (
    /*#slots*/
    n[30]["additional-loading-text"]
  ), l = rs(
    i,
    n,
    /*$$scope*/
    n[29],
    Di
  );
  return {
    c() {
      e = Ct("p"), t = ve(
        /*loading_text*/
        n[9]
      ), r = rt(), l && l.c(), this.h();
    },
    l(o) {
      e = Ft(o, "P", { class: !0 });
      var c = $t(e);
      t = _e(
        c,
        /*loading_text*/
        n[9]
      ), c.forEach(Y), r = tt(o), l && l.l(o), this.h();
    },
    h() {
      _t(e, "class", "loading svelte-17v219f");
    },
    m(o, c) {
      K(o, e, c), i0(e, t), K(o, r, c), l && l.m(o, c), a = !0;
    },
    p(o, c) {
      (!a || c[0] & /*loading_text*/
      512) && it(
        t,
        /*loading_text*/
        o[9]
      ), l && l.p && (!a || c[0] & /*$$scope*/
      536870912) && os(
        l,
        i,
        o,
        /*$$scope*/
        o[29],
        a ? ls(
          i,
          /*$$scope*/
          o[29],
          c,
          ju
        ) : is(
          /*$$scope*/
          o[29]
        ),
        Di
      );
    },
    i(o) {
      a || (gt(l, o), a = !0);
    },
    o(o) {
      Et(l, o), a = !1;
    },
    d(o) {
      o && (Y(e), Y(r)), l && l.d(o);
    }
  };
}
function i4(n) {
  let e, t, r, a, i;
  const l = [Zu, Xu], o = [];
  function c(m, d) {
    return (
      /*status*/
      m[4] === "pending" ? 0 : (
        /*status*/
        m[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = c(n)) && (r = o[t] = l[t](n)), {
    c() {
      e = Ct("div"), r && r.c(), this.h();
    },
    l(m) {
      e = Ft(m, "DIV", { class: !0 });
      var d = $t(e);
      r && r.l(d), d.forEach(Y), this.h();
    },
    h() {
      _t(e, "class", a = "wrap " + /*variant*/
      n[8] + " " + /*show_progress*/
      n[6] + " svelte-17v219f"), Qe(e, "hide", !/*status*/
      n[4] || /*status*/
      n[4] === "complete" || /*show_progress*/
      n[6] === "hidden" || /*status*/
      n[4] == "streaming"), Qe(
        e,
        "translucent",
        /*variant*/
        n[8] === "center" && /*status*/
        (n[4] === "pending" || /*status*/
        n[4] === "error") || /*translucent*/
        n[11] || /*show_progress*/
        n[6] === "minimal"
      ), Qe(
        e,
        "generating",
        /*status*/
        n[4] === "generating" && /*show_progress*/
        n[6] === "full"
      ), Qe(
        e,
        "border",
        /*border*/
        n[12]
      ), Qt(
        e,
        "position",
        /*absolute*/
        n[10] ? "absolute" : "static"
      ), Qt(
        e,
        "padding",
        /*absolute*/
        n[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(m, d) {
      K(m, e, d), ~t && o[t].m(e, null), n[33](e), i = !0;
    },
    p(m, d) {
      let p = t;
      t = c(m), t === p ? ~t && o[t].p(m, d) : (r && (En(), Et(o[p], 1, 1, () => {
        o[p] = null;
      }), Cn()), ~t ? (r = o[t], r ? r.p(m, d) : (r = o[t] = l[t](m), r.c()), gt(r, 1), r.m(e, null)) : r = null), (!i || d[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      m[8] + " " + /*show_progress*/
      m[6] + " svelte-17v219f")) && _t(e, "class", a), (!i || d[0] & /*variant, show_progress, status, show_progress*/
      336) && Qe(e, "hide", !/*status*/
      m[4] || /*status*/
      m[4] === "complete" || /*show_progress*/
      m[6] === "hidden" || /*status*/
      m[4] == "streaming"), (!i || d[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Qe(
        e,
        "translucent",
        /*variant*/
        m[8] === "center" && /*status*/
        (m[4] === "pending" || /*status*/
        m[4] === "error") || /*translucent*/
        m[11] || /*show_progress*/
        m[6] === "minimal"
      ), (!i || d[0] & /*variant, show_progress, status, show_progress*/
      336) && Qe(
        e,
        "generating",
        /*status*/
        m[4] === "generating" && /*show_progress*/
        m[6] === "full"
      ), (!i || d[0] & /*variant, show_progress, border*/
      4416) && Qe(
        e,
        "border",
        /*border*/
        m[12]
      ), d[0] & /*absolute*/
      1024 && Qt(
        e,
        "position",
        /*absolute*/
        m[10] ? "absolute" : "static"
      ), d[0] & /*absolute*/
      1024 && Qt(
        e,
        "padding",
        /*absolute*/
        m[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(m) {
      i || (gt(r), i = !0);
    },
    o(m) {
      Et(r), i = !1;
    },
    d(m) {
      m && Y(e), ~t && o[t].d(), n[33](null);
    }
  };
}
let fr = [], hn = !1;
const l4 = typeof window < "u", us = l4 ? window.requestAnimationFrame : (n) => {
};
async function s4(n, e = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && e !== !0)) {
    if (fr.push(n), !hn) hn = !0;
    else return;
    await Vu(), us(() => {
      let t = [0, 0];
      for (let r = 0; r < fr.length; r++) {
        const i = fr[r].getBoundingClientRect();
        (r === 0 || i.top + window.scrollY <= t[0]) && (t[0] = i.top + window.scrollY, t[1] = r);
      }
      window.scrollTo({ top: t[0] - 20, behavior: "smooth" }), hn = !1, fr = [];
    });
  }
}
function o4(n, e, t) {
  let r, { $$slots: a = {}, $$scope: i } = e;
  const l = Yu();
  let { i18n: o } = e, { eta: c = null } = e, { queue_position: m } = e, { queue_size: d } = e, { status: p } = e, { scroll_to_output: y = !1 } = e, { timer: v = !0 } = e, { show_progress: x = "full" } = e, { message: S = null } = e, { progress: F = null } = e, { variant: E = "default" } = e, { loading_text: D = "Loading..." } = e, { absolute: g = !0 } = e, { translucent: A = !1 } = e, { border: C = !1 } = e, { autoscroll: T } = e, z, P = !1, R = 0, Q = 0, U = null, ee = null, Ce = 0, ie = null, ye, we = null, He = !0;
  const se = () => {
    t(0, c = t(27, U = t(19, te = null))), t(25, R = performance.now()), t(26, Q = 0), P = !0, Ae();
  };
  function Ae() {
    us(() => {
      t(26, Q = (performance.now() - R) / 1e3), P && Ae();
    });
  }
  function ke() {
    t(26, Q = 0), t(0, c = t(27, U = t(19, te = null))), P && (P = !1);
  }
  Gu(() => {
    P && ke();
  });
  let te = null;
  function le(N) {
    wi[N ? "unshift" : "push"](() => {
      we = N, t(16, we), t(7, F), t(14, ie), t(15, ye);
    });
  }
  const ce = () => {
    l("clear_status");
  };
  function Ee(N) {
    wi[N ? "unshift" : "push"](() => {
      z = N, t(13, z);
    });
  }
  return n.$$set = (N) => {
    "i18n" in N && t(1, o = N.i18n), "eta" in N && t(0, c = N.eta), "queue_position" in N && t(2, m = N.queue_position), "queue_size" in N && t(3, d = N.queue_size), "status" in N && t(4, p = N.status), "scroll_to_output" in N && t(22, y = N.scroll_to_output), "timer" in N && t(5, v = N.timer), "show_progress" in N && t(6, x = N.show_progress), "message" in N && t(23, S = N.message), "progress" in N && t(7, F = N.progress), "variant" in N && t(8, E = N.variant), "loading_text" in N && t(9, D = N.loading_text), "absolute" in N && t(10, g = N.absolute), "translucent" in N && t(11, A = N.translucent), "border" in N && t(12, C = N.border), "autoscroll" in N && t(24, T = N.autoscroll), "$$scope" in N && t(29, i = N.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (c === null && t(0, c = U), c != null && U !== c && (t(28, ee = (performance.now() - R) / 1e3 + c), t(19, te = ee.toFixed(1)), t(27, U = c))), n.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, Ce = ee === null || ee <= 0 || !Q ? null : Math.min(Q / ee, 1)), n.$$.dirty[0] & /*progress*/
    128 && F != null && t(18, He = !1), n.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (F != null ? t(14, ie = F.map((N) => {
      if (N.index != null && N.length != null)
        return N.index / N.length;
      if (N.progress != null)
        return N.progress;
    })) : t(14, ie = null), ie ? (t(15, ye = ie[ie.length - 1]), we && (ye === 0 ? t(16, we.style.transition = "0", we) : t(16, we.style.transition = "150ms", we))) : t(15, ye = void 0)), n.$$.dirty[0] & /*status*/
    16 && (p === "pending" ? se() : ke()), n.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && z && y && (p === "pending" || p === "complete") && s4(z, T), n.$$.dirty[0] & /*status, message*/
    8388624, n.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, r = Q.toFixed(1));
  }, [
    c,
    o,
    m,
    d,
    p,
    v,
    x,
    F,
    E,
    D,
    g,
    A,
    C,
    z,
    ie,
    ye,
    we,
    Ce,
    He,
    te,
    r,
    l,
    y,
    S,
    T,
    R,
    Q,
    U,
    ee,
    i,
    a,
    le,
    ce,
    Ee
  ];
}
class u4 extends Pu {
  constructor(e) {
    super(), Hu(
      this,
      e,
      o4,
      i4,
      Uu,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: cs,
  setPrototypeOf: Ni,
  isFrozen: c4,
  getPrototypeOf: m4,
  getOwnPropertyDescriptor: h4
} = Object;
let {
  freeze: Le,
  seal: lt,
  create: ms
} = Object, {
  apply: Mn,
  construct: zn
} = typeof Reflect < "u" && Reflect;
Le || (Le = function(e) {
  return e;
});
lt || (lt = function(e) {
  return e;
});
Mn || (Mn = function(e, t, r) {
  return e.apply(t, r);
});
zn || (zn = function(e, t) {
  return new e(...t);
});
const pr = Oe(Array.prototype.forEach), d4 = Oe(Array.prototype.lastIndexOf), Ii = Oe(Array.prototype.pop), M0 = Oe(Array.prototype.push), f4 = Oe(Array.prototype.splice), kr = Oe(String.prototype.toLowerCase), dn = Oe(String.prototype.toString), Li = Oe(String.prototype.match), z0 = Oe(String.prototype.replace), p4 = Oe(String.prototype.indexOf), g4 = Oe(String.prototype.trim), ft = Oe(Object.prototype.hasOwnProperty), Ne = Oe(RegExp.prototype.test), B0 = _4(TypeError);
function Oe(n) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      r[a - 1] = arguments[a];
    return Mn(n, e, r);
  };
}
function _4(n) {
  return function() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++)
      t[r] = arguments[r];
    return zn(n, t);
  };
}
function re(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : kr;
  Ni && Ni(n, null);
  let r = e.length;
  for (; r--; ) {
    let a = e[r];
    if (typeof a == "string") {
      const i = t(a);
      i !== a && (c4(e) || (e[r] = i), a = i);
    }
    n[a] = !0;
  }
  return n;
}
function v4(n) {
  for (let e = 0; e < n.length; e++)
    ft(n, e) || (n[e] = null);
  return n;
}
function Ut(n) {
  const e = ms(null);
  for (const [t, r] of cs(n))
    ft(n, t) && (Array.isArray(r) ? e[t] = v4(r) : r && typeof r == "object" && r.constructor === Object ? e[t] = Ut(r) : e[t] = r);
  return e;
}
function q0(n, e) {
  for (; n !== null; ) {
    const r = h4(n, e);
    if (r) {
      if (r.get)
        return Oe(r.get);
      if (typeof r.value == "function")
        return Oe(r.value);
    }
    n = m4(n);
  }
  function t() {
    return null;
  }
  return t;
}
const Oi = Le(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), fn = Le(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), pn = Le(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), b4 = Le(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), gn = Le(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), y4 = Le(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Pi = Le(["#text"]), Hi = Le(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), _n = Le(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Ui = Le(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), gr = Le(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), w4 = lt(/\{\{[\w\W]*|[\w\W]*\}\}/gm), k4 = lt(/<%[\w\W]*|[\w\W]*%>/gm), D4 = lt(/\$\{[\w\W]*/gm), x4 = lt(/^data-[\-\w.\u00B7-\uFFFF]+$/), S4 = lt(/^aria-[\-\w]+$/), hs = lt(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), A4 = lt(/^(?:\w+script|data):/i), $4 = lt(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), ds = lt(/^html$/i), F4 = lt(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Vi = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: S4,
  ATTR_WHITESPACE: $4,
  CUSTOM_ELEMENT: F4,
  DATA_ATTR: x4,
  DOCTYPE_NAME: ds,
  ERB_EXPR: k4,
  IS_ALLOWED_URI: hs,
  IS_SCRIPT_OR_DATA: A4,
  MUSTACHE_EXPR: w4,
  TMPLIT_EXPR: D4
});
const R0 = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, C4 = function() {
  return typeof window > "u" ? null : window;
}, E4 = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let r = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (r = t.getAttribute(a));
  const i = "dompurify" + (r ? "#" + r : "");
  try {
    return e.createPolicy(i, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + i + " could not be created."), null;
  }
}, Gi = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function fs() {
  let n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : C4();
  const e = (V) => fs(V);
  if (e.version = "3.2.6", e.removed = [], !n || !n.document || n.document.nodeType !== R0.document || !n.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = n;
  const r = t, a = r.currentScript, {
    DocumentFragment: i,
    HTMLTemplateElement: l,
    Node: o,
    Element: c,
    NodeFilter: m,
    NamedNodeMap: d = n.NamedNodeMap || n.MozNamedAttrMap,
    HTMLFormElement: p,
    DOMParser: y,
    trustedTypes: v
  } = n, x = c.prototype, S = q0(x, "cloneNode"), F = q0(x, "remove"), E = q0(x, "nextSibling"), D = q0(x, "childNodes"), g = q0(x, "parentNode");
  if (typeof l == "function") {
    const V = t.createElement("template");
    V.content && V.content.ownerDocument && (t = V.content.ownerDocument);
  }
  let A, C = "";
  const {
    implementation: T,
    createNodeIterator: z,
    createDocumentFragment: P,
    getElementsByTagName: R
  } = t, {
    importNode: Q
  } = r;
  let U = Gi();
  e.isSupported = typeof cs == "function" && typeof g == "function" && T && T.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: ee,
    ERB_EXPR: Ce,
    TMPLIT_EXPR: ie,
    DATA_ATTR: ye,
    ARIA_ATTR: we,
    IS_SCRIPT_OR_DATA: He,
    ATTR_WHITESPACE: se,
    CUSTOM_ELEMENT: Ae
  } = Vi;
  let {
    IS_ALLOWED_URI: ke
  } = Vi, te = null;
  const le = re({}, [...Oi, ...fn, ...pn, ...gn, ...Pi]);
  let ce = null;
  const Ee = re({}, [...Hi, ..._n, ...Ui, ...gr]);
  let N = Object.seal(ms(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Ge = null, qe = null, Ye = !0, st = !0, ot = !1, qt = !0, vt = !1, bt = !0, ut = !1, m0 = !1, h0 = !1, yt = !1, Rt = !1, Nt = !1, ia = !0, la = !1;
  const bs = "user-content-";
  let Pr = !0, $0 = !1, d0 = {}, f0 = null;
  const sa = re({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let oa = null;
  const ua = re({}, ["audio", "video", "img", "source", "image", "track"]);
  let Hr = null;
  const ca = re({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), Z0 = "http://www.w3.org/1998/Math/MathML", K0 = "http://www.w3.org/2000/svg", It = "http://www.w3.org/1999/xhtml";
  let p0 = It, Ur = !1, Vr = null;
  const ys = re({}, [Z0, K0, It], dn);
  let Q0 = re({}, ["mi", "mo", "mn", "ms", "mtext"]), J0 = re({}, ["annotation-xml"]);
  const ws = re({}, ["title", "style", "font", "a", "script"]);
  let F0 = null;
  const ks = ["application/xhtml+xml", "text/html"], Ds = "text/html";
  let Fe = null, g0 = null;
  const xs = t.createElement("form"), ma = function(k) {
    return k instanceof RegExp || k instanceof Function;
  }, Gr = function() {
    let k = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(g0 && g0 === k)) {
      if ((!k || typeof k != "object") && (k = {}), k = Ut(k), F0 = // eslint-disable-next-line unicorn/prefer-includes
      ks.indexOf(k.PARSER_MEDIA_TYPE) === -1 ? Ds : k.PARSER_MEDIA_TYPE, Fe = F0 === "application/xhtml+xml" ? dn : kr, te = ft(k, "ALLOWED_TAGS") ? re({}, k.ALLOWED_TAGS, Fe) : le, ce = ft(k, "ALLOWED_ATTR") ? re({}, k.ALLOWED_ATTR, Fe) : Ee, Vr = ft(k, "ALLOWED_NAMESPACES") ? re({}, k.ALLOWED_NAMESPACES, dn) : ys, Hr = ft(k, "ADD_URI_SAFE_ATTR") ? re(Ut(ca), k.ADD_URI_SAFE_ATTR, Fe) : ca, oa = ft(k, "ADD_DATA_URI_TAGS") ? re(Ut(ua), k.ADD_DATA_URI_TAGS, Fe) : ua, f0 = ft(k, "FORBID_CONTENTS") ? re({}, k.FORBID_CONTENTS, Fe) : sa, Ge = ft(k, "FORBID_TAGS") ? re({}, k.FORBID_TAGS, Fe) : Ut({}), qe = ft(k, "FORBID_ATTR") ? re({}, k.FORBID_ATTR, Fe) : Ut({}), d0 = ft(k, "USE_PROFILES") ? k.USE_PROFILES : !1, Ye = k.ALLOW_ARIA_ATTR !== !1, st = k.ALLOW_DATA_ATTR !== !1, ot = k.ALLOW_UNKNOWN_PROTOCOLS || !1, qt = k.ALLOW_SELF_CLOSE_IN_ATTR !== !1, vt = k.SAFE_FOR_TEMPLATES || !1, bt = k.SAFE_FOR_XML !== !1, ut = k.WHOLE_DOCUMENT || !1, yt = k.RETURN_DOM || !1, Rt = k.RETURN_DOM_FRAGMENT || !1, Nt = k.RETURN_TRUSTED_TYPE || !1, h0 = k.FORCE_BODY || !1, ia = k.SANITIZE_DOM !== !1, la = k.SANITIZE_NAMED_PROPS || !1, Pr = k.KEEP_CONTENT !== !1, $0 = k.IN_PLACE || !1, ke = k.ALLOWED_URI_REGEXP || hs, p0 = k.NAMESPACE || It, Q0 = k.MATHML_TEXT_INTEGRATION_POINTS || Q0, J0 = k.HTML_INTEGRATION_POINTS || J0, N = k.CUSTOM_ELEMENT_HANDLING || {}, k.CUSTOM_ELEMENT_HANDLING && ma(k.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (N.tagNameCheck = k.CUSTOM_ELEMENT_HANDLING.tagNameCheck), k.CUSTOM_ELEMENT_HANDLING && ma(k.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (N.attributeNameCheck = k.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), k.CUSTOM_ELEMENT_HANDLING && typeof k.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (N.allowCustomizedBuiltInElements = k.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), vt && (st = !1), Rt && (yt = !0), d0 && (te = re({}, Pi), ce = [], d0.html === !0 && (re(te, Oi), re(ce, Hi)), d0.svg === !0 && (re(te, fn), re(ce, _n), re(ce, gr)), d0.svgFilters === !0 && (re(te, pn), re(ce, _n), re(ce, gr)), d0.mathMl === !0 && (re(te, gn), re(ce, Ui), re(ce, gr))), k.ADD_TAGS && (te === le && (te = Ut(te)), re(te, k.ADD_TAGS, Fe)), k.ADD_ATTR && (ce === Ee && (ce = Ut(ce)), re(ce, k.ADD_ATTR, Fe)), k.ADD_URI_SAFE_ATTR && re(Hr, k.ADD_URI_SAFE_ATTR, Fe), k.FORBID_CONTENTS && (f0 === sa && (f0 = Ut(f0)), re(f0, k.FORBID_CONTENTS, Fe)), Pr && (te["#text"] = !0), ut && re(te, ["html", "head", "body"]), te.table && (re(te, ["tbody"]), delete Ge.tbody), k.TRUSTED_TYPES_POLICY) {
        if (typeof k.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw B0('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof k.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw B0('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        A = k.TRUSTED_TYPES_POLICY, C = A.createHTML("");
      } else
        A === void 0 && (A = E4(v, a)), A !== null && typeof C == "string" && (C = A.createHTML(""));
      Le && Le(k), g0 = k;
    }
  }, ha = re({}, [...fn, ...pn, ...b4]), da = re({}, [...gn, ...y4]), Ss = function(k) {
    let q = g(k);
    (!q || !q.tagName) && (q = {
      namespaceURI: p0,
      tagName: "template"
    });
    const H = kr(k.tagName), de = kr(q.tagName);
    return Vr[k.namespaceURI] ? k.namespaceURI === K0 ? q.namespaceURI === It ? H === "svg" : q.namespaceURI === Z0 ? H === "svg" && (de === "annotation-xml" || Q0[de]) : !!ha[H] : k.namespaceURI === Z0 ? q.namespaceURI === It ? H === "math" : q.namespaceURI === K0 ? H === "math" && J0[de] : !!da[H] : k.namespaceURI === It ? q.namespaceURI === K0 && !J0[de] || q.namespaceURI === Z0 && !Q0[de] ? !1 : !da[H] && (ws[H] || !ha[H]) : !!(F0 === "application/xhtml+xml" && Vr[k.namespaceURI]) : !1;
  }, wt = function(k) {
    M0(e.removed, {
      element: k
    });
    try {
      g(k).removeChild(k);
    } catch {
      F(k);
    }
  }, _0 = function(k, q) {
    try {
      M0(e.removed, {
        attribute: q.getAttributeNode(k),
        from: q
      });
    } catch {
      M0(e.removed, {
        attribute: null,
        from: q
      });
    }
    if (q.removeAttribute(k), k === "is")
      if (yt || Rt)
        try {
          wt(q);
        } catch {
        }
      else
        try {
          q.setAttribute(k, "");
        } catch {
        }
  }, fa = function(k) {
    let q = null, H = null;
    if (h0)
      k = "<remove></remove>" + k;
    else {
      const $e = Li(k, /^[\r\n\t ]+/);
      H = $e && $e[0];
    }
    F0 === "application/xhtml+xml" && p0 === It && (k = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + k + "</body></html>");
    const de = A ? A.createHTML(k) : k;
    if (p0 === It)
      try {
        q = new y().parseFromString(de, F0);
      } catch {
      }
    if (!q || !q.documentElement) {
      q = T.createDocument(p0, "template", null);
      try {
        q.documentElement.innerHTML = Ur ? C : de;
      } catch {
      }
    }
    const Me = q.body || q.documentElement;
    return k && H && Me.insertBefore(t.createTextNode(H), Me.childNodes[0] || null), p0 === It ? R.call(q, ut ? "html" : "body")[0] : ut ? q.documentElement : Me;
  }, pa = function(k) {
    return z.call(
      k.ownerDocument || k,
      k,
      // eslint-disable-next-line no-bitwise
      m.SHOW_ELEMENT | m.SHOW_COMMENT | m.SHOW_TEXT | m.SHOW_PROCESSING_INSTRUCTION | m.SHOW_CDATA_SECTION,
      null
    );
  }, Yr = function(k) {
    return k instanceof p && (typeof k.nodeName != "string" || typeof k.textContent != "string" || typeof k.removeChild != "function" || !(k.attributes instanceof d) || typeof k.removeAttribute != "function" || typeof k.setAttribute != "function" || typeof k.namespaceURI != "string" || typeof k.insertBefore != "function" || typeof k.hasChildNodes != "function");
  }, ga = function(k) {
    return typeof o == "function" && k instanceof o;
  };
  function Lt(V, k, q) {
    pr(V, (H) => {
      H.call(e, k, q, g0);
    });
  }
  const _a = function(k) {
    let q = null;
    if (Lt(U.beforeSanitizeElements, k, null), Yr(k))
      return wt(k), !0;
    const H = Fe(k.nodeName);
    if (Lt(U.uponSanitizeElement, k, {
      tagName: H,
      allowedTags: te
    }), bt && k.hasChildNodes() && !ga(k.firstElementChild) && Ne(/<[/\w!]/g, k.innerHTML) && Ne(/<[/\w!]/g, k.textContent) || k.nodeType === R0.progressingInstruction || bt && k.nodeType === R0.comment && Ne(/<[/\w]/g, k.data))
      return wt(k), !0;
    if (!te[H] || Ge[H]) {
      if (!Ge[H] && ba(H) && (N.tagNameCheck instanceof RegExp && Ne(N.tagNameCheck, H) || N.tagNameCheck instanceof Function && N.tagNameCheck(H)))
        return !1;
      if (Pr && !f0[H]) {
        const de = g(k) || k.parentNode, Me = D(k) || k.childNodes;
        if (Me && de) {
          const $e = Me.length;
          for (let Ue = $e - 1; Ue >= 0; --Ue) {
            const Ot = S(Me[Ue], !0);
            Ot.__removalCount = (k.__removalCount || 0) + 1, de.insertBefore(Ot, E(k));
          }
        }
      }
      return wt(k), !0;
    }
    return k instanceof c && !Ss(k) || (H === "noscript" || H === "noembed" || H === "noframes") && Ne(/<\/no(script|embed|frames)/i, k.innerHTML) ? (wt(k), !0) : (vt && k.nodeType === R0.text && (q = k.textContent, pr([ee, Ce, ie], (de) => {
      q = z0(q, de, " ");
    }), k.textContent !== q && (M0(e.removed, {
      element: k.cloneNode()
    }), k.textContent = q)), Lt(U.afterSanitizeElements, k, null), !1);
  }, va = function(k, q, H) {
    if (ia && (q === "id" || q === "name") && (H in t || H in xs))
      return !1;
    if (!(st && !qe[q] && Ne(ye, q))) {
      if (!(Ye && Ne(we, q))) {
        if (!ce[q] || qe[q]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(ba(k) && (N.tagNameCheck instanceof RegExp && Ne(N.tagNameCheck, k) || N.tagNameCheck instanceof Function && N.tagNameCheck(k)) && (N.attributeNameCheck instanceof RegExp && Ne(N.attributeNameCheck, q) || N.attributeNameCheck instanceof Function && N.attributeNameCheck(q)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            q === "is" && N.allowCustomizedBuiltInElements && (N.tagNameCheck instanceof RegExp && Ne(N.tagNameCheck, H) || N.tagNameCheck instanceof Function && N.tagNameCheck(H)))
          ) return !1;
        } else if (!Hr[q]) {
          if (!Ne(ke, z0(H, se, ""))) {
            if (!((q === "src" || q === "xlink:href" || q === "href") && k !== "script" && p4(H, "data:") === 0 && oa[k])) {
              if (!(ot && !Ne(He, z0(H, se, "")))) {
                if (H)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, ba = function(k) {
    return k !== "annotation-xml" && Li(k, Ae);
  }, ya = function(k) {
    Lt(U.beforeSanitizeAttributes, k, null);
    const {
      attributes: q
    } = k;
    if (!q || Yr(k))
      return;
    const H = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: ce,
      forceKeepAttr: void 0
    };
    let de = q.length;
    for (; de--; ) {
      const Me = q[de], {
        name: $e,
        namespaceURI: Ue,
        value: Ot
      } = Me, C0 = Fe($e), Wr = Ot;
      let ze = $e === "value" ? Wr : g4(Wr);
      if (H.attrName = C0, H.attrValue = ze, H.keepAttr = !0, H.forceKeepAttr = void 0, Lt(U.uponSanitizeAttribute, k, H), ze = H.attrValue, la && (C0 === "id" || C0 === "name") && (_0($e, k), ze = bs + ze), bt && Ne(/((--!?|])>)|<\/(style|title)/i, ze)) {
        _0($e, k);
        continue;
      }
      if (H.forceKeepAttr)
        continue;
      if (!H.keepAttr) {
        _0($e, k);
        continue;
      }
      if (!qt && Ne(/\/>/i, ze)) {
        _0($e, k);
        continue;
      }
      vt && pr([ee, Ce, ie], (ka) => {
        ze = z0(ze, ka, " ");
      });
      const wa = Fe(k.nodeName);
      if (!va(wa, C0, ze)) {
        _0($e, k);
        continue;
      }
      if (A && typeof v == "object" && typeof v.getAttributeType == "function" && !Ue)
        switch (v.getAttributeType(wa, C0)) {
          case "TrustedHTML": {
            ze = A.createHTML(ze);
            break;
          }
          case "TrustedScriptURL": {
            ze = A.createScriptURL(ze);
            break;
          }
        }
      if (ze !== Wr)
        try {
          Ue ? k.setAttributeNS(Ue, $e, ze) : k.setAttribute($e, ze), Yr(k) ? wt(k) : Ii(e.removed);
        } catch {
          _0($e, k);
        }
    }
    Lt(U.afterSanitizeAttributes, k, null);
  }, As = function V(k) {
    let q = null;
    const H = pa(k);
    for (Lt(U.beforeSanitizeShadowDOM, k, null); q = H.nextNode(); )
      Lt(U.uponSanitizeShadowNode, q, null), _a(q), ya(q), q.content instanceof i && V(q.content);
    Lt(U.afterSanitizeShadowDOM, k, null);
  };
  return e.sanitize = function(V) {
    let k = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, q = null, H = null, de = null, Me = null;
    if (Ur = !V, Ur && (V = "<!-->"), typeof V != "string" && !ga(V))
      if (typeof V.toString == "function") {
        if (V = V.toString(), typeof V != "string")
          throw B0("dirty is not a string, aborting");
      } else
        throw B0("toString is not a function");
    if (!e.isSupported)
      return V;
    if (m0 || Gr(k), e.removed = [], typeof V == "string" && ($0 = !1), $0) {
      if (V.nodeName) {
        const Ot = Fe(V.nodeName);
        if (!te[Ot] || Ge[Ot])
          throw B0("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (V instanceof o)
      q = fa("<!---->"), H = q.ownerDocument.importNode(V, !0), H.nodeType === R0.element && H.nodeName === "BODY" || H.nodeName === "HTML" ? q = H : q.appendChild(H);
    else {
      if (!yt && !vt && !ut && // eslint-disable-next-line unicorn/prefer-includes
      V.indexOf("<") === -1)
        return A && Nt ? A.createHTML(V) : V;
      if (q = fa(V), !q)
        return yt ? null : Nt ? C : "";
    }
    q && h0 && wt(q.firstChild);
    const $e = pa($0 ? V : q);
    for (; de = $e.nextNode(); )
      _a(de), ya(de), de.content instanceof i && As(de.content);
    if ($0)
      return V;
    if (yt) {
      if (Rt)
        for (Me = P.call(q.ownerDocument); q.firstChild; )
          Me.appendChild(q.firstChild);
      else
        Me = q;
      return (ce.shadowroot || ce.shadowrootmode) && (Me = Q.call(r, Me, !0)), Me;
    }
    let Ue = ut ? q.outerHTML : q.innerHTML;
    return ut && te["!doctype"] && q.ownerDocument && q.ownerDocument.doctype && q.ownerDocument.doctype.name && Ne(ds, q.ownerDocument.doctype.name) && (Ue = "<!DOCTYPE " + q.ownerDocument.doctype.name + `>
` + Ue), vt && pr([ee, Ce, ie], (Ot) => {
      Ue = z0(Ue, Ot, " ");
    }), A && Nt ? A.createHTML(Ue) : Ue;
  }, e.setConfig = function() {
    let V = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Gr(V), m0 = !0;
  }, e.clearConfig = function() {
    g0 = null, m0 = !1;
  }, e.isValidAttribute = function(V, k, q) {
    g0 || Gr({});
    const H = Fe(V), de = Fe(k);
    return va(H, de, q);
  }, e.addHook = function(V, k) {
    typeof k == "function" && M0(U[V], k);
  }, e.removeHook = function(V, k) {
    if (k !== void 0) {
      const q = d4(U[V], k);
      return q === -1 ? void 0 : f4(U[V], q, 1)[0];
    }
    return Ii(U[V]);
  }, e.removeHooks = function(V) {
    U[V] = [];
  }, e.removeAllHooks = function() {
    U = Gi();
  }, e;
}
fs();
const {
  HtmlTagHydration: _D,
  SvelteComponent: vD,
  add_render_callback: bD,
  append_hydration: yD,
  attr: wD,
  bubble: kD,
  check_outros: DD,
  children: xD,
  claim_component: SD,
  claim_element: AD,
  claim_html_tag: $D,
  claim_space: FD,
  claim_text: CD,
  create_component: ED,
  create_in_transition: TD,
  create_out_transition: MD,
  destroy_component: zD,
  detach: BD,
  element: qD,
  get_svelte_dataset: RD,
  group_outros: ND,
  init: ID,
  insert_hydration: LD,
  listen: OD,
  mount_component: PD,
  run_all: HD,
  safe_not_equal: UD,
  set_data: VD,
  space: GD,
  stop_propagation: YD,
  text: WD,
  toggle_class: jD,
  transition_in: XD,
  transition_out: ZD
} = window.__gradio__svelte__internal, { createEventDispatcher: KD, onMount: QD } = window.__gradio__svelte__internal, {
  SvelteComponent: JD,
  append_hydration: ex,
  attr: tx,
  bubble: rx,
  check_outros: nx,
  children: ax,
  claim_component: ix,
  claim_element: lx,
  claim_space: sx,
  create_animation: ox,
  create_component: ux,
  destroy_component: cx,
  detach: mx,
  element: hx,
  ensure_array_like: dx,
  fix_and_outro_and_destroy_block: fx,
  fix_position: px,
  group_outros: gx,
  init: _x,
  insert_hydration: vx,
  mount_component: bx,
  noop: yx,
  safe_not_equal: wx,
  set_style: kx,
  space: Dx,
  transition_in: xx,
  transition_out: Sx,
  update_keyed_each: Ax
} = window.__gradio__svelte__internal, {
  SvelteComponent: $x,
  attr: Fx,
  children: Cx,
  claim_element: Ex,
  detach: Tx,
  element: Mx,
  empty: zx,
  init: Bx,
  insert_hydration: qx,
  noop: Rx,
  safe_not_equal: Nx,
  set_style: Ix
} = window.__gradio__svelte__internal, {
  SvelteComponent: T4,
  append_hydration: M4,
  assign: z4,
  attr: _r,
  check_outros: B4,
  children: q4,
  claim_component: R4,
  claim_element: N4,
  claim_space: I4,
  create_component: L4,
  create_slot: O4,
  destroy_component: P4,
  detach: Yi,
  element: H4,
  get_all_dirty_from_scope: U4,
  get_slot_changes: V4,
  get_spread_object: G4,
  get_spread_update: Y4,
  group_outros: W4,
  init: j4,
  insert_hydration: X4,
  mount_component: Z4,
  safe_not_equal: K4,
  set_style: vr,
  space: Q4,
  toggle_class: Kt,
  transition_in: L0,
  transition_out: Dr,
  update_slot_base: J4
} = window.__gradio__svelte__internal;
function Wi(n) {
  let e, t;
  const r = [
    { autoscroll: (
      /*gradio*/
      n[8].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      n[8].i18n
    ) },
    /*loading_status*/
    n[7],
    {
      status: (
        /*loading_status*/
        n[7] ? (
          /*loading_status*/
          n[7].status == "pending" ? "generating" : (
            /*loading_status*/
            n[7].status
          )
        ) : null
      )
    }
  ];
  let a = {};
  for (let i = 0; i < r.length; i += 1)
    a = z4(a, r[i]);
  return e = new u4({ props: a }), {
    c() {
      L4(e.$$.fragment);
    },
    l(i) {
      R4(e.$$.fragment, i);
    },
    m(i, l) {
      Z4(e, i, l), t = !0;
    },
    p(i, l) {
      const o = l & /*gradio, loading_status*/
      384 ? Y4(r, [
        l & /*gradio*/
        256 && { autoscroll: (
          /*gradio*/
          i[8].autoscroll
        ) },
        l & /*gradio*/
        256 && { i18n: (
          /*gradio*/
          i[8].i18n
        ) },
        l & /*loading_status*/
        128 && G4(
          /*loading_status*/
          i[7]
        ),
        l & /*loading_status*/
        128 && {
          status: (
            /*loading_status*/
            i[7] ? (
              /*loading_status*/
              i[7].status == "pending" ? "generating" : (
                /*loading_status*/
                i[7].status
              )
            ) : null
          )
        }
      ]) : {};
      e.$set(o);
    },
    i(i) {
      t || (L0(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Dr(e.$$.fragment, i), t = !1;
    },
    d(i) {
      P4(e, i);
    }
  };
}
function ec(n) {
  let e, t, r, a = `calc(min(${/*min_width*/
  n[2]}px, 100%))`, i, l = (
    /*loading_status*/
    n[7] && /*show_progress*/
    n[9] && /*gradio*/
    n[8] && Wi(n)
  );
  const o = (
    /*#slots*/
    n[11].default
  ), c = O4(
    o,
    n,
    /*$$scope*/
    n[10],
    null
  );
  return {
    c() {
      e = H4("div"), l && l.c(), t = Q4(), c && c.c(), this.h();
    },
    l(m) {
      e = N4(m, "DIV", { id: !0, class: !0 });
      var d = q4(e);
      l && l.l(d), t = I4(d), c && c.l(d), d.forEach(Yi), this.h();
    },
    h() {
      _r(
        e,
        "id",
        /*elem_id*/
        n[3]
      ), _r(e, "class", r = "column " + /*elem_classes*/
      n[4].join(" ") + " svelte-1m1obck"), Kt(
        e,
        "gap",
        /*gap*/
        n[1]
      ), Kt(
        e,
        "compact",
        /*variant*/
        n[6] === "compact"
      ), Kt(
        e,
        "panel",
        /*variant*/
        n[6] === "panel"
      ), Kt(e, "hide", !/*visible*/
      n[5]), vr(
        e,
        "flex-grow",
        /*scale*/
        n[0]
      ), vr(e, "min-width", a);
    },
    m(m, d) {
      X4(m, e, d), l && l.m(e, null), M4(e, t), c && c.m(e, null), i = !0;
    },
    p(m, [d]) {
      /*loading_status*/
      m[7] && /*show_progress*/
      m[9] && /*gradio*/
      m[8] ? l ? (l.p(m, d), d & /*loading_status, show_progress, gradio*/
      896 && L0(l, 1)) : (l = Wi(m), l.c(), L0(l, 1), l.m(e, t)) : l && (W4(), Dr(l, 1, 1, () => {
        l = null;
      }), B4()), c && c.p && (!i || d & /*$$scope*/
      1024) && J4(
        c,
        o,
        m,
        /*$$scope*/
        m[10],
        i ? V4(
          o,
          /*$$scope*/
          m[10],
          d,
          null
        ) : U4(
          /*$$scope*/
          m[10]
        ),
        null
      ), (!i || d & /*elem_id*/
      8) && _r(
        e,
        "id",
        /*elem_id*/
        m[3]
      ), (!i || d & /*elem_classes*/
      16 && r !== (r = "column " + /*elem_classes*/
      m[4].join(" ") + " svelte-1m1obck")) && _r(e, "class", r), (!i || d & /*elem_classes, gap*/
      18) && Kt(
        e,
        "gap",
        /*gap*/
        m[1]
      ), (!i || d & /*elem_classes, variant*/
      80) && Kt(
        e,
        "compact",
        /*variant*/
        m[6] === "compact"
      ), (!i || d & /*elem_classes, variant*/
      80) && Kt(
        e,
        "panel",
        /*variant*/
        m[6] === "panel"
      ), (!i || d & /*elem_classes, visible*/
      48) && Kt(e, "hide", !/*visible*/
      m[5]), d & /*scale*/
      1 && vr(
        e,
        "flex-grow",
        /*scale*/
        m[0]
      ), d & /*min_width*/
      4 && a !== (a = `calc(min(${/*min_width*/
      m[2]}px, 100%))`) && vr(e, "min-width", a);
    },
    i(m) {
      i || (L0(l), L0(c, m), i = !0);
    },
    o(m) {
      Dr(l), Dr(c, m), i = !1;
    },
    d(m) {
      m && Yi(e), l && l.d(), c && c.d(m);
    }
  };
}
function tc(n, e, t) {
  let { $$slots: r = {}, $$scope: a } = e, { scale: i = null } = e, { gap: l = !0 } = e, { min_width: o = 0 } = e, { elem_id: c = "" } = e, { elem_classes: m = [] } = e, { visible: d = !0 } = e, { variant: p = "default" } = e, { loading_status: y = void 0 } = e, { gradio: v = void 0 } = e, { show_progress: x = !1 } = e;
  return n.$$set = (S) => {
    "scale" in S && t(0, i = S.scale), "gap" in S && t(1, l = S.gap), "min_width" in S && t(2, o = S.min_width), "elem_id" in S && t(3, c = S.elem_id), "elem_classes" in S && t(4, m = S.elem_classes), "visible" in S && t(5, d = S.visible), "variant" in S && t(6, p = S.variant), "loading_status" in S && t(7, y = S.loading_status), "gradio" in S && t(8, v = S.gradio), "show_progress" in S && t(9, x = S.show_progress), "$$scope" in S && t(10, a = S.$$scope);
  }, [
    i,
    l,
    o,
    c,
    m,
    d,
    p,
    y,
    v,
    x,
    a,
    r
  ];
}
let rc = class extends T4 {
  constructor(e) {
    super(), j4(this, e, tc, ec, K4, {
      scale: 0,
      gap: 1,
      min_width: 2,
      elem_id: 3,
      elem_classes: 4,
      visible: 5,
      variant: 6,
      loading_status: 7,
      gradio: 8,
      show_progress: 9
    });
  }
};
const {
  SvelteComponent: nc,
  attr: N0,
  children: ac,
  claim_component: ic,
  claim_element: lc,
  component_subscribe: ji,
  create_component: sc,
  create_slot: oc,
  destroy_component: uc,
  detach: Xi,
  element: cc,
  get_all_dirty_from_scope: mc,
  get_slot_changes: hc,
  init: dc,
  insert_hydration: fc,
  mount_component: pc,
  safe_not_equal: gc,
  set_style: Zi,
  transition_in: ps,
  transition_out: gs,
  update_slot_base: _c
} = window.__gradio__svelte__internal, { getContext: vc, onMount: bc, createEventDispatcher: yc, tick: wc } = window.__gradio__svelte__internal;
function kc(n) {
  let e;
  const t = (
    /*#slots*/
    n[11].default
  ), r = oc(
    t,
    n,
    /*$$scope*/
    n[12],
    null
  );
  return {
    c() {
      r && r.c();
    },
    l(a) {
      r && r.l(a);
    },
    m(a, i) {
      r && r.m(a, i), e = !0;
    },
    p(a, i) {
      r && r.p && (!e || i & /*$$scope*/
      4096) && _c(
        r,
        t,
        a,
        /*$$scope*/
        a[12],
        e ? hc(
          t,
          /*$$scope*/
          a[12],
          i,
          null
        ) : mc(
          /*$$scope*/
          a[12]
        ),
        null
      );
    },
    i(a) {
      e || (ps(r, a), e = !0);
    },
    o(a) {
      gs(r, a), e = !1;
    },
    d(a) {
      r && r.d(a);
    }
  };
}
function Dc(n) {
  let e, t, r, a;
  return t = new rc({
    props: {
      $$slots: { default: [kc] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      e = cc("div"), sc(t.$$.fragment), this.h();
    },
    l(i) {
      e = lc(i, "DIV", { id: !0, class: !0, role: !0 });
      var l = ac(e);
      ic(t.$$.fragment, l), l.forEach(Xi), this.h();
    },
    h() {
      N0(
        e,
        "id",
        /*elem_id*/
        n[0]
      ), N0(e, "class", r = "tabitem " + /*elem_classes*/
      n[1].join(" ") + " svelte-ztmw93"), N0(e, "role", "tabpanel"), Zi(
        e,
        "display",
        /*$selected_tab*/
        n[4] === /*id*/
        n[2] && /*visible*/
        n[3] ? "block" : "none"
      );
    },
    m(i, l) {
      fc(i, e, l), pc(t, e, null), a = !0;
    },
    p(i, [l]) {
      const o = {};
      l & /*$$scope*/
      4096 && (o.$$scope = { dirty: l, ctx: i }), t.$set(o), (!a || l & /*elem_id*/
      1) && N0(
        e,
        "id",
        /*elem_id*/
        i[0]
      ), (!a || l & /*elem_classes*/
      2 && r !== (r = "tabitem " + /*elem_classes*/
      i[1].join(" ") + " svelte-ztmw93")) && N0(e, "class", r), l & /*$selected_tab, id, visible*/
      28 && Zi(
        e,
        "display",
        /*$selected_tab*/
        i[4] === /*id*/
        i[2] && /*visible*/
        i[3] ? "block" : "none"
      );
    },
    i(i) {
      a || (ps(t.$$.fragment, i), a = !0);
    },
    o(i) {
      gs(t.$$.fragment, i), a = !1;
    },
    d(i) {
      i && Xi(e), uc(t);
    }
  };
}
function xc(n, e, t) {
  let r, a, { $$slots: i = {}, $$scope: l } = e, { elem_id: o = "" } = e, { elem_classes: c = [] } = e, { name: m } = e, { id: d = {} } = e, { visible: p } = e, { interactive: y } = e;
  const v = yc(), { register_tab: x, unregister_tab: S, selected_tab: F, selected_tab_index: E } = vc("good-tabs");
  ji(n, F, (g) => t(4, a = g)), ji(n, E, (g) => t(10, r = g));
  let D;
  return bc(() => () => S({ name: m, id: d, elem_id: o })), n.$$set = (g) => {
    "elem_id" in g && t(0, o = g.elem_id), "elem_classes" in g && t(1, c = g.elem_classes), "name" in g && t(7, m = g.name), "id" in g && t(2, d = g.id), "visible" in g && t(3, p = g.visible), "interactive" in g && t(8, y = g.interactive), "$$scope" in g && t(12, l = g.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*name, id, elem_id, visible, interactive*/
    397 && t(9, D = x({ name: m, id: d, elem_id: o, visible: p, interactive: y })), n.$$.dirty & /*$selected_tab_index, tab_index, name*/
    1664 && r === D && wc().then(() => v("select", { value: m, index: D }));
  }, [
    o,
    c,
    d,
    p,
    a,
    F,
    E,
    m,
    y,
    D,
    r,
    i,
    l
  ];
}
class Sc extends nc {
  constructor(e) {
    super(), dc(this, e, xc, Dc, gc, {
      elem_id: 0,
      elem_classes: 1,
      name: 7,
      id: 2,
      visible: 3,
      interactive: 8
    });
  }
}
const {
  SvelteComponent: Ac,
  claim_component: $c,
  create_component: Fc,
  create_slot: Cc,
  destroy_component: Ec,
  get_all_dirty_from_scope: Tc,
  get_slot_changes: Mc,
  init: zc,
  mount_component: Bc,
  safe_not_equal: qc,
  transition_in: _s,
  transition_out: vs,
  update_slot_base: Rc
} = window.__gradio__svelte__internal;
function Nc(n) {
  let e;
  const t = (
    /*#slots*/
    n[7].default
  ), r = Cc(
    t,
    n,
    /*$$scope*/
    n[9],
    null
  );
  return {
    c() {
      r && r.c();
    },
    l(a) {
      r && r.l(a);
    },
    m(a, i) {
      r && r.m(a, i), e = !0;
    },
    p(a, i) {
      r && r.p && (!e || i & /*$$scope*/
      512) && Rc(
        r,
        t,
        a,
        /*$$scope*/
        a[9],
        e ? Mc(
          t,
          /*$$scope*/
          a[9],
          i,
          null
        ) : Tc(
          /*$$scope*/
          a[9]
        ),
        null
      );
    },
    i(a) {
      e || (_s(r, a), e = !0);
    },
    o(a) {
      vs(r, a), e = !1;
    },
    d(a) {
      r && r.d(a);
    }
  };
}
function Ic(n) {
  let e, t;
  return e = new Sc({
    props: {
      elem_id: (
        /*elem_id*/
        n[0]
      ),
      elem_classes: (
        /*elem_classes*/
        n[1]
      ),
      name: (
        /*label*/
        n[2]
      ),
      visible: (
        /*visible*/
        n[5]
      ),
      interactive: (
        /*interactive*/
        n[6]
      ),
      id: (
        /*id*/
        n[3]
      ),
      $$slots: { default: [Nc] },
      $$scope: { ctx: n }
    }
  }), e.$on(
    "select",
    /*select_handler*/
    n[8]
  ), {
    c() {
      Fc(e.$$.fragment);
    },
    l(r) {
      $c(e.$$.fragment, r);
    },
    m(r, a) {
      Bc(e, r, a), t = !0;
    },
    p(r, [a]) {
      const i = {};
      a & /*elem_id*/
      1 && (i.elem_id = /*elem_id*/
      r[0]), a & /*elem_classes*/
      2 && (i.elem_classes = /*elem_classes*/
      r[1]), a & /*label*/
      4 && (i.name = /*label*/
      r[2]), a & /*visible*/
      32 && (i.visible = /*visible*/
      r[5]), a & /*interactive*/
      64 && (i.interactive = /*interactive*/
      r[6]), a & /*id*/
      8 && (i.id = /*id*/
      r[3]), a & /*$$scope*/
      512 && (i.$$scope = { dirty: a, ctx: r }), e.$set(i);
    },
    i(r) {
      t || (_s(e.$$.fragment, r), t = !0);
    },
    o(r) {
      vs(e.$$.fragment, r), t = !1;
    },
    d(r) {
      Ec(e, r);
    }
  };
}
function Lc(n, e, t) {
  let { $$slots: r = {}, $$scope: a } = e, { elem_id: i = "" } = e, { elem_classes: l = [] } = e, { label: o } = e, { id: c } = e, { gradio: m } = e, { visible: d = !0 } = e, { interactive: p = !0 } = e;
  const y = ({ detail: v }) => m.dispatch("select", v);
  return n.$$set = (v) => {
    "elem_id" in v && t(0, i = v.elem_id), "elem_classes" in v && t(1, l = v.elem_classes), "label" in v && t(2, o = v.label), "id" in v && t(3, c = v.id), "gradio" in v && t(4, m = v.gradio), "visible" in v && t(5, d = v.visible), "interactive" in v && t(6, p = v.interactive), "$$scope" in v && t(9, a = v.$$scope);
  }, [
    i,
    l,
    o,
    c,
    m,
    d,
    p,
    r,
    y,
    a
  ];
}
class Ox extends Ac {
  constructor(e) {
    super(), zc(this, e, Lc, Ic, qc, {
      elem_id: 0,
      elem_classes: 1,
      label: 2,
      id: 3,
      gradio: 4,
      visible: 5,
      interactive: 6
    });
  }
}
export {
  Ox as default
};
