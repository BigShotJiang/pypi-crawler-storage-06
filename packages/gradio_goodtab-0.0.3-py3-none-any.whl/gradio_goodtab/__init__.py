
from .goodtab import GoodTab

__all__ = ['GoodTab']
