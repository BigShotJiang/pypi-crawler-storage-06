def despedir():
    print("Adiós, me despido desde despedida.despedir()")

class Despedida:
    def __init__(self):
        print("Adiós, me despedido desde Despedida.__init__()")