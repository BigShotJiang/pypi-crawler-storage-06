2025-08-22 Version: 3.0.3
- Generated python 2020-01-01 for ddoscoo.

2025-08-21 Version: 3.0.2
- Update API DescribeAttackAnalysisMaxQps: add request parameters Ip.
- Update API DescribeDDosAllEventList: add request parameters Ip.
- Update API DescribeDDosEventMax: add request parameters Ip.


2025-06-23 Version: 3.0.1
- Update API DescribeDomainTopAttackList: add request parameters Interval.


2025-04-14 Version: 3.0.0
- Support API ConfigL7GlobalRule.
- Support API DescribeL7GlobalRule.
- Update API DescribeDDosAllEventList: add request parameters RegionId.
- Update API DescribeDDosAllEventList: change request The number of host parameters has changed.
- Update API DescribeDDosEventAttackType: add request parameters RegionId.
- Update API DescribeDDosEventAttackType: change request The number of host parameters has changed.
- Update API DescribeDDosEventMax: add request parameters RegionId.
- Update API DescribeDDosEventMax: change request The number of host parameters has changed.
- Update API DescribeDomainViewTopUrl: add request parameters Inerval.
- Update API DescribeWebReportTopIp: add request parameters RegionId.
- Update API DescribeWebReportTopIp: change request The number of host parameters has changed.


2025-02-12 Version: 2.6.0
- Support API ModifyInstance.
- Update API DeleteAutoCcBlacklist: add param QueryType.
- Update API DescribeAutoCcBlacklist: add param QueryType.
- Update API DescribeDomainStatusCodeCount: update response param.
- Update API DescribeDomainStatusCodeList: update response param.


2024-10-24 Version: 2.5.1
- Generated python 2020-01-01 for ddoscoo.

2024-10-24 Version: 2.5.0
- Support API DescribeDomainBps.
- Support API DescribeDomainH2Fingerprint.
- Support API DescribeDomainTopFingerprint.
- Support API DescribeDomainTopHttpMethod.
- Support API DescribeDomainTopReferer.
- Support API DescribeDomainTopUserAgent.
- Update API DescribePortCcAttackTopIP: add param RegionId.
- Update API DescribePortCcAttackTopIP: update response param.


2024-09-19 Version: 2.4.4
- Update API AssociateWebCert: delete param ResourceGroupId.
- Update API DescribeDomainResource: update param PageSize.
- Update API DescribeL7RsPolicy: update response param.
- Update API DescribePort: update param PageNumber.
- Update API DescribePort: update param PageSize.
- Update API DescribeWebRules: update param PageSize.
- Update API DescribeWebRules: update response param.


2024-08-29 Version: 2.4.3
- Update API CreatePort: add param ProxyEnable.
- Update API DescribeNetworkRules: update response param.
- Update API ModifyPort: add param ProxyEnable.


2024-07-30 Version: 2.4.2
- Update API DescribeWebCCRulesV2: update response param.


2024-07-11 Version: 2.4.1
- Generated python 2020-01-01 for ddoscoo.

2024-07-05 Version: 2.4.0
- Support API DescribeDestinationPortEvent.
- Update API DescribeDDosEventArea: add param RegionId.
- Update API DescribeDDosEventArea: add param Range.
- Update API DescribeDDosEventArea: update param EventType.
- Update API DescribeDDosEventArea: update response param.
- Update API DescribeDDosEventIsp: add param RegionId.
- Update API DescribeDDosEventIsp: add param Range.
- Update API DescribeDDosEventIsp: update param EventType.
- Update API DescribeDDosEventIsp: update response param.
- Update API DescribeDDosEventSrcIp: add param RegionId.
- Update API DescribeDDosEventSrcIp: update param EventType.
- Update API DescribeDDosEventSrcIp: update response param.


2024-06-24 Version: 2.3.1
- Update API DescribeNetworkRegionBlock: update response param.


2024-06-20 Version: 2.3.0
- Support API ConfigDomainSecurityProfile.
- Support API ConfigL7UsKeepalive.
- Support API DescribeL7UsKeepalive.
- Update API DescribeInstanceDetails: update response param.


2024-05-30 Version: 2.2.0
- Support API ConfigWebCCRuleV2.
- Support API DescribeWebCCRulesV2.


2024-05-29 Version: 2.1.0
- Support API DeleteWebCCRuleV2.
- Support API ModifyWebCCGlobalSwitch.


2024-05-29 Version: 2.0.2
- Update API AssociateWebCert: update param Cert.
- Update API AssociateWebCert: update param CertId.
- Update API AssociateWebCert: update param CertIdentifier.
- Update API AssociateWebCert: update param CertName.
- Update API AssociateWebCert: update param CertRegion.
- Update API AssociateWebCert: update param Domain.
- Update API AssociateWebCert: update param Key.


2024-05-09 Version: 2.0.1
- Update API ConfigL7RsPolicy: add param UpstreamRetry.
- Update API DescribeL7RsPolicy: update response param.


2024-04-29 Version: 2.0.0
- Support API DescribeElasticQps.
- Support API DescribeElasticQpsRecord.
- Support API ModifyElasticBizQps.
- Support API ModifyQpsMode.
- Delete API DescribeDomainQpsWithCache.
- Update API ConfigWebIpSet: update param BlackList.
- Update API ConfigWebIpSet: update param WhiteList.
- Update API DescribeSlaEventList: update param Page.
- Update API DescribeSlaEventList: update param PageSize.


2024-01-23 Version: 1.2.1
- Generated python 2020-01-01 for ddoscoo.

2024-01-17 Version: 1.2.0
- Generated python 2020-01-01 for ddoscoo.

2023-11-13 Version: 1.1.0
- Generated python 2020-01-01 for ddoscoo.

2023-07-19 Version: 1.0.3
- Update sdk.

2022-06-30 Version: 1.0.2
- Update sdk.

2021-03-30 Version: 1.0.1
- Generated python 2020-01-01 for ddoscoo.

2021-02-20 Version: 1.0.0
- AMP Version Change.

