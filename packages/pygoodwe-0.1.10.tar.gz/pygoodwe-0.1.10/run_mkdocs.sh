#!/bin/bash

python3 -m mkdocs serve --livereload
