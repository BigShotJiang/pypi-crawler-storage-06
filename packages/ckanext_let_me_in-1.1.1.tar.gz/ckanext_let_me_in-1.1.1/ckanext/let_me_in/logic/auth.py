from __future__ import annotations

from ckan import types


def lmi_generate_otl(context: types.Context, data_dict: types.DataDict) -> types.AuthResult:
    return {"success": False}
