## 🚴 WebStorage
* localStorage
* sessionStorage

### 🔬 Test in Headless Browsers with `wasm-pack test`
```
wasm-pack test --headless --firefox --chrome
```
