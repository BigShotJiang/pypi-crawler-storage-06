use {super::JsonStorage, gluesql_core::store::Transaction};

impl Transaction for JsonStorage {}
