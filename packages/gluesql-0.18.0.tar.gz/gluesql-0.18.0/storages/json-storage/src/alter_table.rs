use {super::JsonStorage, gluesql_core::store::AlterTable};

impl AlterTable for JsonStorage {}
