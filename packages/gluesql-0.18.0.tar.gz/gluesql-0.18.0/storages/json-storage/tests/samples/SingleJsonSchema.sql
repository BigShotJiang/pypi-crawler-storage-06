CREATE TABLE SingleJsonSchema (
  data LIST
);
