ALTER TABLE WrongSchema ADD COLUMN dostNotWork INT;
