CREATE TABLE ArrayOfJsonsSchema (
  id INT,
  name TEXT
);
