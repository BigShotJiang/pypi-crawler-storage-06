## 🚴 IdbStorage - IndexedDB storage support for GlueSQL

### 🔬 Test in Headless Browsers with `wasm-pack test`
```
WASM_BINDGEN_TEST_TIMEOUT=60 wasm-pack test --headless --firefox --chrome
```
