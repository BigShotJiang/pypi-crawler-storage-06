# Copyright 2025 UW-IT, University of Washington
# SPDX-License-Identifier: Apache-2.0

# This is just a test runner for coverage

if __name__ == '__main__':
    from nose2 import discover
    discover()
