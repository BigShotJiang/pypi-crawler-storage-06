from kirin import ir

dialect = ir.Dialect("bloqade.shuttle.measure")
