"""Package aimed at containing shared functions accross CLI application."""
