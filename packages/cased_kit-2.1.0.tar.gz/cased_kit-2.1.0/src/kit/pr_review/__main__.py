"""Entry point for running the PR review debug CLI as a module."""

from .debug import app

if __name__ == "__main__":
    app()
