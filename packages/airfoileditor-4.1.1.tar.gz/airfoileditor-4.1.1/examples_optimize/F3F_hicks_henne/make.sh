# xoptfoil2 must be in the search path

xoptfoil2 -i F3F_hicks_henne.xo2
