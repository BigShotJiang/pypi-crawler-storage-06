# xoptfoil2 must be in the search path

xoptfoil2 -i SD7003_fast.xo2

