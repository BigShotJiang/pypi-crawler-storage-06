
.. _scenedetect-stats_manager:

-----------------------------------------------------------------------
StatsManager
-----------------------------------------------------------------------

.. automodule:: scenedetect.stats_manager
   :members:
