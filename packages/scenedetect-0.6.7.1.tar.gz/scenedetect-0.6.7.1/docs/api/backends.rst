
.. _scenedetect-backends:

----------------------------------------
Backends
----------------------------------------

.. automodule:: scenedetect.backends
   :members:

.. automodule:: scenedetect.backends.opencv
   :members:

.. automodule:: scenedetect.backends.pyav
   :members:

.. automodule:: scenedetect.backends.moviepy
   :members:
