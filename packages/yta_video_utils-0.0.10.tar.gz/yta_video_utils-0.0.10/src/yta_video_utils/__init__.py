"""
Module to include some utils related to
video, but importing not any big library,
please.
"""

# TODO: I think this library has become
# @deprecated and has to be abandoned...