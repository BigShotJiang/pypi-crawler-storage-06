"""Mock integration tests for finlab-guard.

This package contains integration tests that use mocked finlab environment
to test the complete functionality without requiring actual finlab package.
"""
