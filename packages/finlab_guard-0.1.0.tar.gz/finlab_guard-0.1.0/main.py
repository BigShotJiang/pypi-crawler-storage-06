def main():
    print("Hello from finlab-guard!")


if __name__ == "__main__":
    main()
