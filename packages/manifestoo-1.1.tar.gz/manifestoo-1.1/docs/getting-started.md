# Getting started

```{include} ../README.md
:start-after: <!--- quickstart-begin -->
:end-before: <!--- quickstart-end -->
```
