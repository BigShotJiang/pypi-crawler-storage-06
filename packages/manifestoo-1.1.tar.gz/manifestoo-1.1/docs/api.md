# Programmatic API

This project does not expose a programmatic API. Only the command line interface is
stable and documented.

A public programmatic API is being developed in
[manifestoo_core](https://pypi.org/project/manifestoo-core/)
on which this project relies.
