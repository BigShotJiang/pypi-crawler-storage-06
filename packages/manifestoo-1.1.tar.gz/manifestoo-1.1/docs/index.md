# Manifestoo

```{include} ../README.md
:start-after: <!--- shortdesc-begin -->
:end-before: <!--- shortdesc-end -->
```

```{toctree}
:hidden:
:maxdepth: 2

installation
getting-started
addons_selection
addons_path
CLI <cli>
API <api>
Development <develop>
Changelog <changelog>
GitHub Repository <https://github.com/acsone/manifestoo>
```

```{include} ../README.md
:start-after: <!--- features-begin -->
:end-before: <!--- features-end -->
```
