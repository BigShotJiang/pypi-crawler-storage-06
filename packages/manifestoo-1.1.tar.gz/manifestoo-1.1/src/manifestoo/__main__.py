from .main import app  # pragma: no cover

app(prog_name="manifestoo")  # pragma: no cover
