from typer import Exit


class CycleErrorExit(Exit):
    pass
