"""
InMemoryExecutor module contains components of an executor
that can run your vector embeddings on a local computer.
"""
