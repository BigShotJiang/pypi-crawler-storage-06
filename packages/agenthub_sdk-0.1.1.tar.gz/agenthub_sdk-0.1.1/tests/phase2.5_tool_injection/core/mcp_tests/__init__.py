"""Phase 2.5 Tool Injection - Core/MCP Tests"""
