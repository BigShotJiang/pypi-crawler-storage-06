from .types import Resource, Segment, Group
from .splitter import split