from embykeeper import __version__
