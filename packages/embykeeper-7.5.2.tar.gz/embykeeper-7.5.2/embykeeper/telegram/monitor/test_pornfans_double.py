from .pornfans_double import PornfansDoubleMonitor

__ignore__ = True


class TestPornfansDoubleMonitor(PornfansDoubleMonitor):
    name = "PornFans 怪兽自动翻倍 测试"
    chat_name = "api_group"
    chat_user = "embykeeper_test_bot"
    chat_allow_outgoing = True
