from ._templ_a import TemplateACheckin

__ignore__ = True


class MJJCheckin(TemplateACheckin):
    name = "MJJ"
    bot_username = "mjjemby_uesr_bot"
