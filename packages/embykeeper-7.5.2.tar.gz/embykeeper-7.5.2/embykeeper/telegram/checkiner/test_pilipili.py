from .pilipili import PilipiliCheckin

__ignore__ = True


class TestPilipiliCheckin(PilipiliCheckin):
    name = "Pilipili 签到测试"
    bot_username = "embykeeper_test_bot"
