from ._templ_a import TemplateACheckin


class EPubCheckin(TemplateACheckin):
    name = "EPub 电子书库 Emby 机器人签到"
    bot_username = "wenjian_emby_bot"
