from ._templ_a import TemplateACheckin

__ignore__ = True


class AWAMusicCheckin(TemplateACheckin):
    name = "AWA 音乐服"
    bot_username = "awamm_bot"
    bot_use_captcha = False
