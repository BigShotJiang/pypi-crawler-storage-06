from ._templ_a import TemplateACheckin

__ignore__ = True


class YounoCheckin(TemplateACheckin):
    name = "Youno"
    bot_username = "YounoEmbyAgain_bot"
