from . import BotCheckin

__ignore__ = True


class Carll1SGKCheckin(BotCheckin):
    name = "Carll 社工库 1"
    bot_username = "Carllnet_bot"
    bot_checkin_cmd = "/qd"
