from ._templ_a import TemplateACheckin


class ShufuCheckin(TemplateACheckin):
    name = "叔服Emby"
    bot_username = "dashu660_bot"
