from ._templ_a import TemplateACheckin

__ignore__ = True


class FeiyueMusicCheckin(TemplateACheckin):
    name = "飞跃星空"
    bot_username = "xingkongmusic_bot"
    bot_success_pat = None
