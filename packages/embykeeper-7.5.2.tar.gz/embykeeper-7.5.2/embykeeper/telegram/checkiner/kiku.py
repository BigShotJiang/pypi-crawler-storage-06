from ._templ_a import TemplateACheckin


class KikuCheckin(TemplateACheckin):
    name = "Kiku"
    bot_username = "kikuemby_bot"
