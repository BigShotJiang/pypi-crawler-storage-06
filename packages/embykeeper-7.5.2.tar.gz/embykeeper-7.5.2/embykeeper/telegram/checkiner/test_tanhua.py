from .tanhua import TanhuaCheckin

__ignore__ = True


class TestTanhuaCheckin(TanhuaCheckin):
    name = "Tanhua 签到测试"
    bot_username = "embykeeper_test_bot"
