from ._templ_a import TemplateACheckin

__ignore__ = True


class JulyCheckin(TemplateACheckin):
    name = "july"
    bot_username = "NASTOOL7_bot"
