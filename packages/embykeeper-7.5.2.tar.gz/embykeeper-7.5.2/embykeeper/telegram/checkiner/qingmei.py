from ._templ_a import TemplateACheckin

__ignore__ = True


class QingmeiCheckin(TemplateACheckin):
    name = "青梅映画"
    bot_username = "qingmeiemby_bot"
