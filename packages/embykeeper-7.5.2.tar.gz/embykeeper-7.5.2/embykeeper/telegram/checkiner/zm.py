from ._templ_a import TemplateACheckin


class ZmCheckin(TemplateACheckin):
    name = "鹅服"
    bot_username = "ZXCHSJSHbot"
    bot_use_captcha = False
