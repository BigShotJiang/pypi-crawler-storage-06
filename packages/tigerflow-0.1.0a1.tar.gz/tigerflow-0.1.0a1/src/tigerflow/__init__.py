from .cli import app


def main():
    app()
