"""
Placeholder for tests
"""


def test_mock():
    assert True
