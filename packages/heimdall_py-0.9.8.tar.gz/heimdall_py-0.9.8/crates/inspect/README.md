# heimdall-inspect

Detailed inspection of Ethereum transactions, including calldata & trace decoding, log visualization, and more.
