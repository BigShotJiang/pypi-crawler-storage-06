# heimdall-cache

This crate is a simple on-disc caching system utilized by the Heimdall library. Heimdall modules may use this library to save immutable on-chain data to disc, such as bytecode, calldata, as well as the results of expensive computations.
