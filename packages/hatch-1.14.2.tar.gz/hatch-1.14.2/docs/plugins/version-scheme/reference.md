# Version scheme plugins

-----

## Known third-party

- [hatch-semver](https://github.com/Nagidal/hatch-semver) - uses [semantic versioning](https://semver.org)

::: hatchling.version.scheme.plugin.interface.VersionSchemeInterface
    options:
      members:
      - PLUGIN_NAME
      - root
      - config
      - update
