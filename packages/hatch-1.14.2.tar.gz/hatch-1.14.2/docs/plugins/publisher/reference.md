# Publisher plugins

-----

## Known third-party

- [hatch-aws-publisher](https://github.com/aka-raccoon/hatch-aws-publisher) - publish AWS Lambda functions with SAM

::: hatch.publish.plugin.interface.PublisherInterface
    options:
      members:
      - PLUGIN_NAME
      - app
      - root
      - cache_dir
      - project_config
      - plugin_config
      - disable
      - publish
