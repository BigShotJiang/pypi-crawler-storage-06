# Authors

-----

## Maintainers

- Ofek Lev [:material-web:](https://ofek.dev) [:material-github:](https://github.com/ofek) [:material-twitter:](https://twitter.com/Ofekmeister)

## Contributors

- Amjith Ramanujam [:material-twitter:](https://twitter.com/amjithr)
- Arnaud Crowther [:material-github:](https://github.com/areknow)
- Chaojie [:material-web:](https://chaojie.fun) [:material-github:](https://github.com/ischaojie)
- Chris Warrick [:material-twitter:](https://twitter.com/Kwpolska)
- Lumír 'Frenzy' Balhar [:material-email:](mailto:frenzy.madness@gmail.com) [:material-twitter:](https://twitter.com/lumirbalhar)
- Ofek Lev [:material-web:](https://ofek.dev) [:material-github:](https://github.com/ofek) [:material-twitter:](https://twitter.com/Ofekmeister)
- Olga Matoula [:material-github:](https://github.com/olgarithms) [:material-twitter:](https://twitter.com/olgarithms_)
- Philip Blair [:material-email:](mailto:philip@pblair.org)
- Robert Rosca [:material-github:](https://github.com/robertrosca)
