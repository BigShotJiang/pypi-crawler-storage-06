"""bdsca_analysis_config_file package.

Tools and CLI for handling BDSCA analysis configuration files.
"""

__all__ = ["__version__"]

__version__ = "0.1.2"
