nwb2bids Documentation
======================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Summary
-------

nwb2bids reorganizes NWB files into a BIDS directory layout.

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
