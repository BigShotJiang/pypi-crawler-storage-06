# Documentation

To build the documentation locally:

```bash
# Install documentation dependencies
pip install -r docs/requirements.txt

# Build HTML documentation
cd docs
make html

# View the built documentation
# Open docs/build/html/index.html in your browser
```
