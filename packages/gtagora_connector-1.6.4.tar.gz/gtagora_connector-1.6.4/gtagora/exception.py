class AgoraException(Exception):
    pass


class DownloadError(AgoraException):
    pass
