"""Tap executable."""

from __future__ import annotations

from tap_jotform.tap import TapJotform

TapJotform.cli()
