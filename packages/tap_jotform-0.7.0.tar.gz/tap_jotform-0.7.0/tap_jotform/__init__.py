"""Singer Tap for Jotform."""
