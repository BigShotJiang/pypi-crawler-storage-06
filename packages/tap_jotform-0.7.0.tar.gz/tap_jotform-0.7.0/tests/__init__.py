"""Test suite for tap-readthedocs."""
