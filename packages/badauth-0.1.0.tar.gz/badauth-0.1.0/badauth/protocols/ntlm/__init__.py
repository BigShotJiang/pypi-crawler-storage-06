import logging

logger = logging.getLogger('badauth.ntlm')
logger.propagate = True