import logging

logger = logging.getLogger('badauth.credssp')
logger.propagate = True