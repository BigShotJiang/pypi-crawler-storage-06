This addon provides the bases to implement addons to export information to
Typesense_ indexes.

.. _Typesense: https://typesense.org
