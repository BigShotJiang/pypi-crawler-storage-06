We recommend to use the typesense-dashboard for managing your typesense server.
I will allow you to configure the mapping of index with a nice UI.
Please take a look here: https://github.com/bfritscher/typesense-dashboard/releases
