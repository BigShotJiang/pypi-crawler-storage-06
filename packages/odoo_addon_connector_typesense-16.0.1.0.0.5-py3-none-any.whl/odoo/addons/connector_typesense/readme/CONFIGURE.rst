You have to configure (Host, Port, Protocol, Typesense API Key) in a new backend form view:

Search Engine > Configuration > Backends
