:notoc: true

.. _api:

API Reference
=============

This section provides the complete API reference for ``mapflow``.

.. toctree::
   :maxdepth: 1

   api/static
   api/animations
