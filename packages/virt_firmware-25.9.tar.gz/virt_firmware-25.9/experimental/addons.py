#!/usr/bin/python
# promoted out of experimental
""" compat wrapper for uki-addons """
import sys
from virt.firmware.bootcfg.addons import main

if __name__ == '__main__':
    sys.exit(main())
