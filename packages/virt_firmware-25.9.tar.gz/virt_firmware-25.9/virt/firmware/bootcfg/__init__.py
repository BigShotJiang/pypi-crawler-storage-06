""" efi boot configuration """
__all__ = [ "bootcfg", "linuxcfg", "main", "menu" ]
