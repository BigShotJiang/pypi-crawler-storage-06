# Function Chaining

This directory contains a executable version of [this](https://docs.microsoft.com/en-us/azure/azure-functions/durable/durable-functions-sequence?tabs=python) tutorial. Please review the link above for instructions on how to run it.