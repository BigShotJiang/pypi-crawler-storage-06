def main(name: str) -> str:
    return f"Hello {name}!"
