# Repository Guidelines

## Project Structure & Module Organization
- `SPEC.md` is the authoritative plan
- `ARCHITECTURE.md` must mirror SPEC decisions
- `README.md` captures repo intent
