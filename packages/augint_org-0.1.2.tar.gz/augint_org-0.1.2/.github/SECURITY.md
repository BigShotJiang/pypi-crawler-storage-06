# Security Policy

If you discover a security vulnerability, please report it responsibly.

## How to report

- Please contact the repository owner directly via email or GitHub issues.
