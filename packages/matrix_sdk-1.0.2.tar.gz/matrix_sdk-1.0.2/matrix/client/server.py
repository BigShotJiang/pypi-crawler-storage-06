import os
SERVER_URI = os.environ.get("MATRIX_API_BASE_URL", "https://api.matrix-ai.app")
UPLOAD_FILES_URI = "/upload/files/"
MODEL_REQUEST_URI = "/repo/model/"
REQUEST_RESULT_URI = "/repo/results/"
REPO_LIST_URI = "/repo/list/"
