import os
SERVER_URI = os.environ.get("MATRIX_API_BASE_URL", "https://api.matrix-ai.app")
REPO_DELETE_URI = "/repo/delete/"
REPO_TASKS_LIST_URI = "/repo/tasks/"
REPO_MODELS_LIST_URI = "/repo/models/"
REPO_TASK_RESULT_URI = "/repo/results/"
REPO_BUILD_URI = "/repo/build/"
UPLOAD_SINGLE_FILE_URI = "/upload/file/"
UPLOAD_REPO_URI = "/upload/repo/"
UPLOAD_REPO_DONE_URI = "/upload/done/"