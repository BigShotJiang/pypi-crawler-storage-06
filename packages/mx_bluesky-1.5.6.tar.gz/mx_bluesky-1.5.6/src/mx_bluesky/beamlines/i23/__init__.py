from mx_bluesky.beamlines.i23.serial import serial_collection

__all__ = ["serial_collection"]
