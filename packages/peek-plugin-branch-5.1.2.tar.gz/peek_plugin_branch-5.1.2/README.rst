=============
Branch Plugin
=============

The Peek Plugin provides a common branch detail object. This is like a header only,
other plugins implement their own branch logic.

For example, The following two plugins could have branches in their data :

*   peek_plugin_diagram
*   peek_plugin_graphdb

