branchPluginName = "peek_plugin_branch"
branchFilt = {"plugin": "peek_plugin_branch"}
branchTuplePrefix = "peek_plugin_branch."
branchObservableName = "peek_plugin_branch"
branchActionProcessorName = "peek_plugin_branch"
branchTupleOfflineServiceName = "peek_plugin_branch"
