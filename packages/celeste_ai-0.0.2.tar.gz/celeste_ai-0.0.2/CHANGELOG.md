# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-09-22)

- Initial Release
