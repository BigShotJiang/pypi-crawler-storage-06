from .singleton import SingletonMeta
