

class Connector:
    pass