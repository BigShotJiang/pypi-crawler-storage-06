# Duploctl AWS Plugin  

A wrapper for Boto3 to interact with AWS services. This adds some useful high level functions as well as a helper for creating a session using JIT. 
