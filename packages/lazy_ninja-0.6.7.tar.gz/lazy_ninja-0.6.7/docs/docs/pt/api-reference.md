# Referência da API

::: lazy_ninja.builder.DynamicAPI
    options:
      heading_level: 2
      show_root_heading: false
      show_source: false

::: lazy_ninja.pagination
    options:
      heading_level: 2
      show_root_heading: false
      show_source: false