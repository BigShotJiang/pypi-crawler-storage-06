Changelog
=========

1.0.5 (2023-10-10)
------------------
- Initial release.
