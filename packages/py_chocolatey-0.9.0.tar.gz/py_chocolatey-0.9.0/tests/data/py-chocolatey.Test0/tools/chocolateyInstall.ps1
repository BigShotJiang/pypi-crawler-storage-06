﻿$ErrorActionPreference = 'Stop'; # stop on all errors
