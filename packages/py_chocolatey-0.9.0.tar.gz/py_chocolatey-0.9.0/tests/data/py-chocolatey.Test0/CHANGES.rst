Changelog
=========

1.0.0 (2023-10-10)
------------------
- Initial release.
