﻿$ErrorActionPreference = 'Stop'; # stop on all errors

Write-Host "I am from [[Country]]"
