Changelog
=========

1.0.4 (2023-10-10)
------------------
- Initial release.
