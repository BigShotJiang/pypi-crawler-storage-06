from gtagora.models.base import BaseModel


class Breadcrumb(BaseModel):
    pass