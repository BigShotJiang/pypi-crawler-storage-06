from pytest_archon.rule import archrule

__all__ = ["archrule"]
