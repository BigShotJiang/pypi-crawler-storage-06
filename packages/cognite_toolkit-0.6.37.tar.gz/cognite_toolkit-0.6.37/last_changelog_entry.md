## cdf 

### Fixed

- When running `cdf build` Toolkit no longer give warnings on extraction
pipelines for unused field allowedNotSeenRangeInMinutes. For example:
`In notificationConfig unused field:
'allowedNotSeenRangeInMinutes'`

## templates

No changes.