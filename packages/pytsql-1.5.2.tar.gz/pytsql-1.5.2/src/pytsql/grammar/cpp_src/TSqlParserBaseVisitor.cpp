
// Generated from TSqlParser.g4 by ANTLR 4.13.1


#include "TSqlParserBaseVisitor.h"


