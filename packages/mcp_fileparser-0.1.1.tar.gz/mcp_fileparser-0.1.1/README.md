# MCP File Parser

[![PyPI version](https://badge.fury.io/py/mcp-fileparser.svg)](https://badge.fury.io/py/mcp-fileparser)

A file parser using Kimi AI.

## Installation

```bash
pip install mcp-fileparser
```

## Usage

1.  **Set up your environment variables.**

    Create a `.env` file in your project root and add your Kimi API key:

    ```
    KIMI_API_KEY="your_api_key"
    ```

2.  **Use the `parse_file` function.**

    ```python
    from mcp_fileparser import parse_file

    content = parse_file("/path/to/your/file.xlsx")
    print(content)
    ```

## License

This project is licensed under the MIT License.