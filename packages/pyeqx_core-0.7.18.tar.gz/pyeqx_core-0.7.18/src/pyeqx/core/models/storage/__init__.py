from pyeqx.core.models.storage.data import Data

__all__ = ["Data"]
