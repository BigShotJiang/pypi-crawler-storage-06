from pyeqx.core.models.module.data_module import DataModule

__all__ = ["DataModule"]
