class ResCountry:
    pass


class FakeModel1:
    pass
