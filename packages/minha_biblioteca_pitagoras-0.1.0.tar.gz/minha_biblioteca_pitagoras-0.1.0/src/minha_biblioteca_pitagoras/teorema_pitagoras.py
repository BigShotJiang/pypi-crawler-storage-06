# função com teorema de pitágoras para a biblioteca

def calcular_hipotenusa(cateto1, cateto2):
    return (cateto1**2 + cateto2**2) ** 0.5 
    # Retorna a hipotenusa de um triângulo retângulo dado os dois catetos

