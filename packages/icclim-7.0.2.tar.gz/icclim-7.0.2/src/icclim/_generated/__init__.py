"""
icclim generated API.

This module contains the API generated from the IndicatorRegistries
using the `tools/extract_icclim_funs.py` script.
"""
