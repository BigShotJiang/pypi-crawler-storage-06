"""
Threshold package.

This package contains the threshold definitions used in conjunction with generic indices
to create personalized indices.
"""
