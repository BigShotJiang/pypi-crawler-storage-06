def appreq(x, y):
    return abs(x - y) < 1e-4
