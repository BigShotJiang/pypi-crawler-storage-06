from . import get_grounding_terms, get_gilda_models


if __name__ == '__main__':
    get_grounding_terms()
    get_gilda_models()
