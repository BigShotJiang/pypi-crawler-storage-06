.. gilda documentation master file, created by
   sphinx-quickstart on Thu Jun 27 01:36:53 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Software documentation
======================

.. toctree::
   :maxdepth: 3

   modules/index


.. mdinclude:: ../README.md

