# `Function schema`

::: agents.function_schema
