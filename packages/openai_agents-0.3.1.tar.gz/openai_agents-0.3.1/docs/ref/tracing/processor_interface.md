# `Processor interface`

::: agents.tracing.processor_interface
