Changelog
=========


(unreleased)
------------
- Release v1.0.0. [Mathieu Malaterre]
- Start main module. [Mathieu Malaterre]
- Update documentation. [Mathieu Malaterre]
- Adapt to project and remove 3.7. [Mathieu Malaterre]

  Original project at:

  * https://github.com/MArpogaus/minimal_python_project_skeleton
- Initial commit. [Mathieu Malaterre]


