from pathlib import Path
root_dir = Path(__file__).resolve().parent