# Mapping of WKID values to PROJ4 definitions for WKID >= 32767
wkid_to_proj = {
    102100: '+units=m +init=epsg:3857', #Web Mercator Auxiliary Sphere
}