"""
    manage_django_project
    Helper to develop Django projects.
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.10.1'
__author__ = 'Jens Diemer <git@jensdiemer.de>'
