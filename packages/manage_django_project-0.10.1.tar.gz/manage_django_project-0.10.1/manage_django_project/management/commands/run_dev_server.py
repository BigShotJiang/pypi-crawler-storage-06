from django_tools.management.commands.run_testserver import Command as RunServerCommand


class Command(RunServerCommand):
    pass
