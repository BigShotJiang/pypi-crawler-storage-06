"""
    Just a "Fake" command: A modul that doesn't has a "class Command()"
"""
