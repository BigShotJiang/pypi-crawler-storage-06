import manage_django_project


# Just the same version as the real project:
__version__ = manage_django_project.__version__
