#  Copyright (c) yibocat 2025 All Rights Reserved
#  Python: 3.12.7
#  Date: 2025/8/25 10:53
#  Author: yibow
#  Email: yibocat@yeah.net
#  Software: AxisFuzzy

from .frame import FuzzyDataFrame

__all__ = ["FuzzyDataFrame"]
