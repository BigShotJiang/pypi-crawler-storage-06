from smart_covdefaults.plugin import coverage_init as coverage_init
