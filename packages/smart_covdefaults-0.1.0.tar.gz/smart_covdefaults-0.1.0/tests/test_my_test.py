def test():
    print("Hello!")
