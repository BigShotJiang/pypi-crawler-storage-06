from .interaction_affordance import (
    InteractionAffordance,
    PropertyAffordance,
    ActionAffordance,
    EventAffordance,
)
from .tm import ThingModel
