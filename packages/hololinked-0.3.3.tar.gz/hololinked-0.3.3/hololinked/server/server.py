class BaseProtocolServer:
    def add_thing(self, thing):
        pass

    def remove_thing(self, thing):
        pass

    def add_property(self, thing, prop):
        pass

    def add_action(self, thing, action):
        pass

    def add_event(self, thing, event):
        pass

    def build_thing_description(self, thing):
        pass
