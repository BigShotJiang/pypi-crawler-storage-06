from plone.portlets.interfaces import IPortletDataProvider


class ILabelJarPortlet(IPortletDataProvider):
    pass


class ILabelingPortlet(IPortletDataProvider):
    pass
