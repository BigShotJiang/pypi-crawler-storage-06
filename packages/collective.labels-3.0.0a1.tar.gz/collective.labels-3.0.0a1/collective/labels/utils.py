import unicodedata


def make_sortable(text):
    """Converts a string to a sortable string by lowercasing
    it and removing diacritics.
    """
    text = text.lower()
    normalized = unicodedata.normalize('NFKD', text)
    text = u''.join([c for c in normalized if not unicodedata.combining(c)])
    return text


def title_by_user(title, by_label):
    """ Format title with by_label information """
    return "%s%s" % (title, by_label and ' (*)' or '')
