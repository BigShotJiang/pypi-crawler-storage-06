class AnyParser:
    parser_type = "any"


class EmailParser:
    parser_type = "email"


class PdfParser:
    parser_type = "pdf"


class PptxParser:
    parser_type = "pptx"


class XlsxParser:
    parser_type = "xlsx"
