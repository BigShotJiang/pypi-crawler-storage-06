# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""Durable Task SDK for Python"""


PACKAGE_NAME = "durabletask"
