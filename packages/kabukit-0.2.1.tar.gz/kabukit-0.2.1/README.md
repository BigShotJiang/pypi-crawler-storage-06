# kabukit

A Python toolkit for Japanese financial market data, supporting J-Quants and EDINET APIs.

[![PyPI Version][pypi-v-image]][pypi-v-link]
[![Python Version][python-v-image]][python-v-link]

## Installation

```bash
pip install kabukit
```

<!-- Badges -->
[pypi-v-image]: https://img.shields.io/pypi/v/kabukit.svg
[pypi-v-link]: https://pypi.org/project/kabukit/
[python-v-image]: https://img.shields.io/pypi/pyversions/kabukit.svg
[python-v-link]: https://pypi.org/project/kabukit
