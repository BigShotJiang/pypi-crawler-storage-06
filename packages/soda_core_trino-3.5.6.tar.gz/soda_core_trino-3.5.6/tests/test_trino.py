def test_trino():
    """Add plugin specific tests here. Present so that CI is simpler and to avoid false plugin-specific tests passing."""
