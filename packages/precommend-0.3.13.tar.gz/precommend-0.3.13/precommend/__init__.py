# The version file is generated automatically by setuptools_scm
from precommend._version import version as __version__
