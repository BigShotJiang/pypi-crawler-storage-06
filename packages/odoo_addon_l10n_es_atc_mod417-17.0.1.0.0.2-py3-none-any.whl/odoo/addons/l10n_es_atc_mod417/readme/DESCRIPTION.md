Módulo para la presentación del modelo 417 (Suministro Inmediato de Información - Autodeclaración) de
la Agencia Tributaria Canaria.

Instrucciones del modelo:
<https://www3.gobiernodecanarias.org/tributos/atc/estatico/asistencia_contribuyente/modelos/ref_y_propios/igic/mod417/pdf/instrucciones/417.pdf>
