To install this module, you need to:

#. Only install

NOTE. There is a soft dependency on stock_valuation_fifo_lot module, as Odoo uses a financial FIFO valuation, not a real FIFO valuation, which is solved by the stock_valuation_fifo_lot module.
