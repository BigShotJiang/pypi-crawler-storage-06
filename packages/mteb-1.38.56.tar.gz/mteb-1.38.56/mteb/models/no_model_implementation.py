from __future__ import annotations


def no_model_implementation_available():
    raise NotImplementedError("No model implementation is available for this model.")
