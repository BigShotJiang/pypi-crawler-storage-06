def main():
    print("Hello from kerberos!")


if __name__ == "__main__":
    main()
