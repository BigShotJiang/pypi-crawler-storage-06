COMMAND_CODES = {
    "TRANSITION": 2,
    "ACTIVE": 1,
    "SLEEP": 0,
    "DEAD": -1,
    "ERROR": -2
}
