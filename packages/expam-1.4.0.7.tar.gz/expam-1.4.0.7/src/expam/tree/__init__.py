RANK_ORDER = [
    "0", "root", "top", "superkingdom", "kingdom", "subkingdom", "superclade", "clade", "subclade",
    "superphylum", "phylum", "subphylum", "superclass", "class", "subclass", "superorder", "order",
    "suborder", "superfamily", "family", "subfamily", "supergenus", "genus", "subgenus", "species group",
    "species subgroup", "superspecies", "species", "subspecies", "serogroup", "serotype", "superstrain",
    "strain", "substrain", "no rank"
]
