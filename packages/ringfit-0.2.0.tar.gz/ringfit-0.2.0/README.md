# ringfit

Tools for detecting, fitting, and characterizing rings in astronomical images.

## Install

```bash
cd /path/to/ring_fitting
python3 -m venv venv
source venv/bin/activate
pip install -e .
