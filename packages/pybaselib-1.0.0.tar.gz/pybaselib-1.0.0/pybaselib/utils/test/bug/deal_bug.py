# -*- coding: utf-8 -*-
# @Author: maoyongfan
# @email: maoyongfan@163.com
# @Date: 2025/2/26 14:18

from pybaselib.utils import Issue
def deal_bug(bug_title: str, bug_description: str, priority: str, testcase: str,
                   version: str, controllerInfo, issue: Issue, default_project_id=1911):
    pass