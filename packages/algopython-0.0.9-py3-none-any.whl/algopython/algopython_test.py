from __init__ import *

algopython_init()

face_smile_detection()

algopython_exit()