Relation Type
~~~~~~~~~~~~~

You can specify that a relation type can have a function attached to it.

Relation
~~~~~~~~

You can enter a function for relation types that allow this. The display name
for the relation will reflect the function entered, if any.
