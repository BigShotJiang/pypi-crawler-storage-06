This module gives the posibility to have a relation between partners have a function.

Of course there is a function field on partner, but this ignores the fact that
persons can have multiple functions depending on the relations they are in. For
instance a person can be a CEO in one company and a volunteer in another organisation.
