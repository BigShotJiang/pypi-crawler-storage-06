# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).
from . import res_partner_relation_type
from . import res_partner_relation_type_selection
from . import res_partner_relation
from . import res_partner_relation_all
