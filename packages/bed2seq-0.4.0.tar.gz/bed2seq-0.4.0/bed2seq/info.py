

APPNAME   = "bed2seq"
SHORTDESC = "From a BED file, return the sequences according to the genome supplied"
LICENCE   = "GPL3"
VERSION   = "0.4.0"
AUTHOR    = "Benoit Guibert"
AUTHOR_EMAIL = "benoit.guibert@free.fr"
