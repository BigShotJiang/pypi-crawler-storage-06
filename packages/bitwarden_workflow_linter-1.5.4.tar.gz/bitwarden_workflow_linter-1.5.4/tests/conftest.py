"""Shared configuration for tests."""

FIXTURE_DIR = "./tests/fixtures"
