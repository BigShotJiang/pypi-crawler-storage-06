from gooddata_api_client.paths.api_v1_entities_data_sources_data_source_id_data_source_tables.get import ApiForget


class ApiV1EntitiesDataSourcesDataSourceIdDataSourceTables(
    ApiForget,
):
    pass
