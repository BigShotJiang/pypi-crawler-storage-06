from gooddata_api_client.paths.api_v1_layout_workspace_data_filters.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_workspace_data_filters.put import ApiForput


class ApiV1LayoutWorkspaceDataFilters(
    ApiForget,
    ApiForput,
):
    pass
