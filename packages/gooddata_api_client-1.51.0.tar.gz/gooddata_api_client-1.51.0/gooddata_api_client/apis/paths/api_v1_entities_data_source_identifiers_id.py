from gooddata_api_client.paths.api_v1_entities_data_source_identifiers_id.get import ApiForget


class ApiV1EntitiesDataSourceIdentifiersId(
    ApiForget,
):
    pass
