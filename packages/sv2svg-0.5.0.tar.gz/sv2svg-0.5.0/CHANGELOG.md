# [0.5.0](https://github.com/ErikMeinders/sv2svg/compare/v0.4.0...v0.5.0) (2025-09-22)


### Features

* --orientation flag implemented ([423bef5](https://github.com/ErikMeinders/sv2svg/commit/423bef586b3fc80eeb1c3d71a721e471df27ca4d))

# [0.4.0](https://github.com/ErikMeinders/sv2svg/compare/v0.3.0...v0.4.0) (2025-09-22)


### Features

* style option for different colors release ([1919779](https://github.com/ErikMeinders/sv2svg/commit/19197798caf3021b69f109edb15bafc768e8b289))

# [0.3.0](https://github.com/ErikMeinders/sv2svg/compare/v0.2.3...v0.3.0) (2025-09-22)


### Features

* style option for different colors ([d383d0a](https://github.com/ErikMeinders/sv2svg/commit/d383d0a96a158bc87609f87b220519da546ad801))

## [0.2.3](https://github.com/ErikMeinders/sv2svg/compare/v0.2.2...v0.2.3) (2025-09-22)


### Bug Fixes

* potential crash for empty output ([9a97752](https://github.com/ErikMeinders/sv2svg/commit/9a977523dd4931cdf04fb69093a174160ed4091a))

## [0.2.2](https://github.com/ErikMeinders/sv2svg/compare/v0.2.1...v0.2.2) (2025-09-22)


### Bug Fixes

* repaired release ([662128d](https://github.com/ErikMeinders/sv2svg/commit/662128d92162452ca638b24381b562810a1aec8c))

## [0.2.1](https://github.com/ErikMeinders/sv2svg/compare/v0.2.0...v0.2.1) (2025-09-22)


### Bug Fixes

* added versioning ([872d94e](https://github.com/ErikMeinders/sv2svg/commit/872d94e9a7e0272deca0554214c3e70c79e11c18))

# Changelog

All notable changes to this project will be documented in this file. The release process is automated by semantic-release and follows [Semantic Versioning](https://semver.org/).

<!-- Entries are added automatically during release -->
