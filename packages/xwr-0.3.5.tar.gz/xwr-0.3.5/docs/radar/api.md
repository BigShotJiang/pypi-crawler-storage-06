::: xwr.radar
    options:
        inherited_members:
        - start
        - stop
        - setup
