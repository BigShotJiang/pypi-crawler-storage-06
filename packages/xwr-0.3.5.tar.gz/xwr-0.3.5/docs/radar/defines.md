::: xwr.radar.defines
