::: xwr.rsp.torch
