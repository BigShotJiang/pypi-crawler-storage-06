::: xwr.capture
