"""KeyCard AI OAuth SDK Types"""
