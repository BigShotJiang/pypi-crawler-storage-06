"""Tests for KeyCard AI Oauth SDK."""
