"""Tests for keycardai.oauth.types package."""
