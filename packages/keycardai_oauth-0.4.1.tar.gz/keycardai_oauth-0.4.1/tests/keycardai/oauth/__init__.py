"""Tests for keycardai.oauth package."""
