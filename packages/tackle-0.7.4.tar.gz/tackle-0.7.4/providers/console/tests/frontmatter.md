---

foo: bar
# A comment
stuff:
  - things

---

# Stuff!

foo bar