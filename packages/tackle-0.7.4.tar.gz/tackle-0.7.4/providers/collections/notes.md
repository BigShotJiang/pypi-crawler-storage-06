
### Potential Hooks

- list_key_values
  - Hook for getting a list of values from a list of maps.
- list_key_value
  - Hook for getting an item in a list of maps with a key matching a value.
  - Not needed because above can be run with index 0

