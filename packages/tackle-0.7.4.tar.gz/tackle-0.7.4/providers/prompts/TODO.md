Tests

- [ ] editor
- [ ] expand
- [ ] rawlist

- [ ] Test exceptions