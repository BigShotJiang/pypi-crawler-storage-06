
foo bar

[//]: # (--start--)

things

foo

bar

[//]: # (--end--)

foo baz

