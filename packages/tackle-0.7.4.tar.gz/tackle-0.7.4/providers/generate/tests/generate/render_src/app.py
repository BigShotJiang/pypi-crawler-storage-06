"""Template."""
print("{{stuff}}")
