"""Template."""
print("{{foo}}")
