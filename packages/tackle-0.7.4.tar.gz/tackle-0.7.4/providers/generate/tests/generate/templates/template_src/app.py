"""Template."""
print("{{this}}")
