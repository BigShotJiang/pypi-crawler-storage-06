print({"stuff": "{{ stuff }}"})
