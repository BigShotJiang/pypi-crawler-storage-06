
Foo bar

[//]: # (--start-here--)
foo:
  bar: 1
[//]: # (--end-here--)

Baz
