import reversion_compare


# Just the same version as the real project:
__version__ = reversion_compare.__version__
