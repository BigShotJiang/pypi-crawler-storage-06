# Home
{%
    include-markdown "../README.md"
    start="<!-- start intro -->"
    end="<!-- end intro -->"
%}
[Get started](quickstart.md){ .md-button .md-button--primary}