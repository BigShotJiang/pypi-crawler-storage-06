# -*- coding: utf-8 -*-
"""
Created on Mon Aug  7 10:45:26 2023

@author: Administrator
"""

# import usual
# import wechat

blog = 'https://note.youdao.com/s/6TBmbe1q'
tip = f'\n========================================\n\n函数功能目录 及 应用示例代码 见作者(Elias)笔记：\n{blog}\n\n========================================\n'
print(tip)