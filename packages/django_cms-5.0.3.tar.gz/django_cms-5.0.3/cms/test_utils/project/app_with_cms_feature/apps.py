from django.apps import AppConfig


class CMSFeatureConfig(AppConfig):
    name = 'cms.test_utils.project.app_with_cms_feature'
    label = 'app_with_cms_feature'
