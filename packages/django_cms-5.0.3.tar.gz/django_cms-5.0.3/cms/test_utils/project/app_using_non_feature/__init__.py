default_app_config = 'cms.test_utils.project.app_using_non_feature.apps.NonFeatureCMSConfig'
