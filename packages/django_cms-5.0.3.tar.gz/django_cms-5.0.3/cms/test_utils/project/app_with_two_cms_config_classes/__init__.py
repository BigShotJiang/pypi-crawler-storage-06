default_app_config = 'cms.test_utils.project.app_with_two_cms_config_classes.apps.TwoCMSAppClassesConfig'
