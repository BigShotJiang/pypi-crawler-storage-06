from django.apps import AppConfig


class TwoCMSAppClassesConfig(AppConfig):
    name = 'cms.test_utils.project.app_with_two_cms_feature_classes'
    label = 'app_with_two_cms_feature_classes'
