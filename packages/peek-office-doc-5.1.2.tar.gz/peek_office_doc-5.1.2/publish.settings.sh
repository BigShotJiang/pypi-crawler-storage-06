#!/usr/bin/env bash

PY_PACKAGE="peek_office_doc"
PYPI_PUBLISH="1"

VER_FILES_TO_COMMIT=""

VER_FILES=""
VER_FILES="${VER_FILES} ${PY_PACKAGE}/conf.py"
