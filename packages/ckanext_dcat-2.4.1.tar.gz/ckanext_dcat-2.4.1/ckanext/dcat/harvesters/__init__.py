from ckanext.dcat.harvesters.rdf import DCATRDFHarvester

from ckanext.dcat.harvesters.xml import DCATXMLHarvester
from ckanext.dcat.harvesters._json import DCATJSONHarvester
