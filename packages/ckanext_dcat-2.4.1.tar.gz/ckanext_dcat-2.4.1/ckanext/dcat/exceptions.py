# -*- coding: utf-8 -*-

class RDFParserException(Exception):
    pass


class RDFProfileException(Exception):
    pass
