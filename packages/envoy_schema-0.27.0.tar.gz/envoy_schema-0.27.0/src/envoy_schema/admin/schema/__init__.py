"""Schemas represent the public facing models that are exposed via HTTP endpoints and serialised to xml/json etc"""
