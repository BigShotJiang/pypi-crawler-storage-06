# Authors

This file lists all individuals having contributed content to the project.

## Project Founders

- Håvard Eidnes <havard.eidnes@sikt.no>

## Contributors

- Hanne Moa <hanne.moa@sikt.no> ([hmpf](https://github.com/hmpf))
- Johanna England <johanna.england@sikt.no> ([johannaengland](https://github.com/johannaengland))
- Morten Brekkevold <morten.brekkevold@sikt.no> ([lunkwill42](https://github.com/lunkwill42))
- Simon Oliver Tveit <simon.tveit@sikt.no> ([stveit](https://github.com/stveit))
