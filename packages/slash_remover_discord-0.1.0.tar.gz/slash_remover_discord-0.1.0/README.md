# slash-remover-discord

Clear all slash commands (global & guild) from your Discord bot By Syntax Development.

## Usage

# import the main function from the package
from slash_remover_discord import main

# run it
main()