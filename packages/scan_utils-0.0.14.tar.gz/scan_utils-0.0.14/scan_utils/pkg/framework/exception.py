
#业务执行异常
class BusinessException(Exception):
    pass

#凭证失败
class AuthException(Exception):
    pass

