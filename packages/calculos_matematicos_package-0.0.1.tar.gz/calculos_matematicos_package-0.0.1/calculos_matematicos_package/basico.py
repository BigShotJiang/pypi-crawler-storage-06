def adicionar(termo1, termo2):
    print(termo1 + termo2)


def subtrair(termo1, termo2):
    print(termo1 - termo2)


def multiplicar(termo1, termo2):
    print(termo1 * termo2)


def dividir(termo1, termo2):
    print(termo1 / termo2)


def dividir_inteiro(termo1, termo2):
    print(termo1 // termo2)


def exponencial(termo1, termo2):
    print(termo1 ** termo2)


def modulo(termo1, termo2):
    print(termo1 % termo2)
