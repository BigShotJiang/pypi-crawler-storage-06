import math


def arredondar(numero, digitos):
    print(round(numero, digitos))


def raiz_quadrada(numero):
    print(math.sqrt(numero))
