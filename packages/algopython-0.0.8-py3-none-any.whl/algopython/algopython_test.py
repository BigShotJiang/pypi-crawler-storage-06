from __init__ import *

algopython_init()

#Your code here

algopython_exit()
