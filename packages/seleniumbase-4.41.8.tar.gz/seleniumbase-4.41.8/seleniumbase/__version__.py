# seleniumbase package
__version__ = "4.41.8"
