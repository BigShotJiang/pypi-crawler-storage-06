|pypi| |actions| |codecov| |downloads|

edc_microbiology
----------------

Microbiology model mixins in clinicedc/edc projects

.. |pypi| image:: https://img.shields.io/pypi/v/edc-microbiology.svg
    :target: https://pypi.python.org/pypi/edc-microbiology

.. |actions| image:: https://github.com/clinicedc/edc-microbiology/actions/workflows/build.yml/badge.svg
  :target: https://github.com/clinicedc/edc-microbiology/actions/workflows/build.yml

.. |codecov| image:: https://codecov.io/gh/clinicedc/edc-microbiology/branch/develop/graph/badge.svg
  :target: https://codecov.io/gh/clinicedc/edc-microbiology

.. |downloads| image:: https://pepy.tech/badge/edc-microbiology
   :target: https://pepy.tech/project/edc-microbiology
