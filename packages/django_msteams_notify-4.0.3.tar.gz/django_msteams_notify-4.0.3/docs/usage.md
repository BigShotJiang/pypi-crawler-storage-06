# Usage

To use Python Boilerplate in a project:

```python
import django_msteams_notify
```
