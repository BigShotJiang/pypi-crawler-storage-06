"""Shell integration modules for uvve."""
