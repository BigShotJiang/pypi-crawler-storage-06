"""uvve: A CLI tool for managing Python virtual environments using uv."""

__version__ = "1.1.1"
