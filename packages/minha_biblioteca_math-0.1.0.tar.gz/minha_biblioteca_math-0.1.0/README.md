# Minha biblioteca

Esta Biblioteca foi criada durante a formação UFCD 10794

Oferece funções matemáticas com impressão dos resultados em tela.

# Instalação

pip install minha-biblioteca-math