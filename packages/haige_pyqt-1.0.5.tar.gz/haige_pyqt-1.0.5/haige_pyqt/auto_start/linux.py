# Linux系统可以使用~/.config/autostart/目录
def enable_autostart(app_name, app_path):
    return False


def disable_autostart(app_name):
    return False


def is_autostart_enabled(app_name):
    return False
