A package to retrieve build files for diagnostics and log them in a server
