from .point import Point
from .stampdb import StampDB
