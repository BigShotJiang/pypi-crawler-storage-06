# OpenCatWebJson
Python Library for handling CatWeb's JSON Formats
