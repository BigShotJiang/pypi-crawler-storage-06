import for_runners


# Just the same version as the real project:
__version__ = for_runners.__version__
