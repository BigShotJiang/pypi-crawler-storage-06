from bx_django_utils.test_utils.fixtures import RenewAllFixturesBaseCommand


class Command(RenewAllFixturesBaseCommand):
    pass
