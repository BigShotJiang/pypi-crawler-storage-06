class GpxDataError(ValueError):
    """
    e.g.: uploaded gpx file is not valid or has no tracks etc...
    """

    pass
