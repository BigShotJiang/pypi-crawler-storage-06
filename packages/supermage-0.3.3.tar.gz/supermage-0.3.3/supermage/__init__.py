from . import __meta__

__version__ = __meta__.version
