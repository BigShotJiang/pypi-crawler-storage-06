class DjangoGlueResponse {
    constructor() {}
}
