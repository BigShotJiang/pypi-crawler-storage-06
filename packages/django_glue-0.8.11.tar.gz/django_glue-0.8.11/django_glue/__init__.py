from django_glue.shortcuts import glue_model_object, glue_function, glue_query_set, glue_template


__all__ = [
    'glue_model_object',
    'glue_function',
    'glue_query_set',
    'glue_template'
]