.. currentmodule:: py3dframe.matrix

py3dframe.matrix.O3_project
============================

.. autofunction:: O3_project