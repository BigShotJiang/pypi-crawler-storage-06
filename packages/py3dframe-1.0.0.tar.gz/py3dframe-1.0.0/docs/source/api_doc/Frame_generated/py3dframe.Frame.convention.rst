﻿py3dframe.Frame.convention
==========================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.convention