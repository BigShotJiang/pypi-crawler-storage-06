﻿py3dframe.Frame.save\_to\_dict
==============================

.. currentmodule:: py3dframe

.. automethod:: Frame.save_to_dict