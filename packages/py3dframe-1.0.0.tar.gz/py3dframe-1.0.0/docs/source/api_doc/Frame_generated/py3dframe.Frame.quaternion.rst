﻿py3dframe.Frame.quaternion
==========================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.quaternion