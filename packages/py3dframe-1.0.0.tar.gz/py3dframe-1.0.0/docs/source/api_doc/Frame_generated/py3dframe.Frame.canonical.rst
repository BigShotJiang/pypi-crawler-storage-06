﻿py3dframe.Frame.canonical
=========================

.. currentmodule:: py3dframe

.. automethod:: Frame.canonical