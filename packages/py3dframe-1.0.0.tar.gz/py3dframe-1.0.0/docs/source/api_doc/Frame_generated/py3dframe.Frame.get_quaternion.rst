﻿py3dframe.Frame.get\_quaternion
===============================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_quaternion