﻿py3dframe.Frame.origin
======================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.origin