﻿py3dframe.Frame.from\_rotation
==============================

.. currentmodule:: py3dframe

.. automethod:: Frame.from_rotation