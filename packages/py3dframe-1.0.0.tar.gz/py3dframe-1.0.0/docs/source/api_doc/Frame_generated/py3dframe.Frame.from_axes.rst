﻿py3dframe.Frame.from\_axes
==========================

.. currentmodule:: py3dframe

.. automethod:: Frame.from_axes