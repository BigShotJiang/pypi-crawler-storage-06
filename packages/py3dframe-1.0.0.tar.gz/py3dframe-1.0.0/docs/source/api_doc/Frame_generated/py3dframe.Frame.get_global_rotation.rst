﻿py3dframe.Frame.get\_global\_rotation
=====================================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_global_rotation