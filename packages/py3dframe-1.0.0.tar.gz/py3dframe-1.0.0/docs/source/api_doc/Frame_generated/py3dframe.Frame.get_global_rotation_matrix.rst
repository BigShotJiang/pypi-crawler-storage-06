﻿py3dframe.Frame.get\_global\_rotation\_matrix
=============================================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_global_rotation_matrix