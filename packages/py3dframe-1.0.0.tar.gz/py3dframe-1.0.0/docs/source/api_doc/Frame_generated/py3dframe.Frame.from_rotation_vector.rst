﻿py3dframe.Frame.from\_rotation\_vector
======================================

.. currentmodule:: py3dframe

.. automethod:: Frame.from_rotation_vector