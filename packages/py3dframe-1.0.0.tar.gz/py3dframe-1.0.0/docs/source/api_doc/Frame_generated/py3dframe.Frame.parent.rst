﻿py3dframe.Frame.parent
======================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.parent