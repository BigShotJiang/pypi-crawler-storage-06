﻿py3dframe.Frame.from\_rotation\_matrix
======================================

.. currentmodule:: py3dframe

.. automethod:: Frame.from_rotation_matrix