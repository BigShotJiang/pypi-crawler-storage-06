.. currentmodule:: py3dframe.matrix

py3dframe.matrix.is_SO3
=======================

.. autofunction:: is_SO3