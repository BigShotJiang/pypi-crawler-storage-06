.. currentmodule:: py3dframe.matrix

py3dframe.matrix.SO3_project
============================

.. autofunction:: SO3_project