﻿py3dframe.FrameTransform.translation
====================================

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.translation