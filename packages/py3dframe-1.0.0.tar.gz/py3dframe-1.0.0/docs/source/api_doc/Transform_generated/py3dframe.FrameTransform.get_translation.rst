﻿py3dframe.FrameTransform.get\_translation
=========================================

.. currentmodule:: py3dframe

.. automethod:: FrameTransform.get_translation