﻿py3dframe.FrameTransform.convention
===================================

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.convention