﻿py3dframe.FrameTransform.rotation\_matrix
=========================================

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.rotation_matrix