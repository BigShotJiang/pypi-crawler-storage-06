﻿py3dframe.FrameTransform.dynamic
================================

.. currentmodule:: py3dframe

.. autoproperty:: FrameTransform.dynamic