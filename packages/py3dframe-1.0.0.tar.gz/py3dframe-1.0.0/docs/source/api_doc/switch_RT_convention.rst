py3dframe.switch_RT_convention
==============================

.. autofunction:: py3dframe.switch_RT_convention