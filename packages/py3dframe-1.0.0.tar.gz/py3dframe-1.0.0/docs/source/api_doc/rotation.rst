py3dframe.Rotation
==================

``py3dframe.Rotation`` class is used to manage 3D rotations.
This class is an alias of the ``scipy.spatial.transform.Rotation`` class.
For more information, refer to the `scipy documentation <https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.transform.Rotation.html>`_.


    

