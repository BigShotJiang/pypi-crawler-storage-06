# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BindSiteDto:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'receptor': 'ReceptorDrugFile',
        'engine': 'str',
        'docking_type': 'str',
        'bounding_box': 'BoundingBoxDto',
        'remove_ion': 'bool',
        'remove_water': 'bool',
        'remove_ligand': 'bool',
        'add_hydrogen': 'bool'
    }

    attribute_map = {
        'name': 'name',
        'receptor': 'receptor',
        'engine': 'engine',
        'docking_type': 'docking_type',
        'bounding_box': 'bounding_box',
        'remove_ion': 'remove_ion',
        'remove_water': 'remove_water',
        'remove_ligand': 'remove_ligand',
        'add_hydrogen': 'add_hydrogen'
    }

    def __init__(self, name=None, receptor=None, engine=None, docking_type=None, bounding_box=None, remove_ion=None, remove_water=None, remove_ligand=None, add_hydrogen=None):
        r"""BindSiteDto

        The model defined in huaweicloud sdk

        :param name: 靶点名称，只能设置为target1或者target2。
        :type name: str
        :param receptor: 
        :type receptor: :class:`huaweicloudsdkeihealth.v1.ReceptorDrugFile`
        :param engine: **参数解释**： 引擎[，仅支持VINA，默认值为VINA](tag:hcs)[，支持DSDP、AUTODOCK_VINA，默认值为AUTODOCK_VINA](tag:hws)。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 
        :type engine: str
        :param docking_type: **参数解释**： 对接类型[，仅支持POCKET_DOCKING](tag:hws)[，支持BLIND_DOCKING、POCKET_DOCKING](tag:hcs)。 **约束限制**： 不涉及 **取值范围**： * POCKET_DOCKING：口袋对接 * [BLIND_DOCKING：全局对接](tag:hcs) **默认取值**： POCKET_DOCKING 
        :type docking_type: str
        :param bounding_box: 
        :type bounding_box: :class:`huaweicloudsdkeihealth.v1.BoundingBoxDto`
        :param remove_ion: 去除受体中的离子
        :type remove_ion: bool
        :param remove_water: 去除受体中的水分子
        :type remove_water: bool
        :param remove_ligand: 去除受体中的配体分子
        :type remove_ligand: bool
        :param add_hydrogen: 增加氢原子
        :type add_hydrogen: bool
        """
        
        

        self._name = None
        self._receptor = None
        self._engine = None
        self._docking_type = None
        self._bounding_box = None
        self._remove_ion = None
        self._remove_water = None
        self._remove_ligand = None
        self._add_hydrogen = None
        self.discriminator = None

        if name is not None:
            self.name = name
        self.receptor = receptor
        if engine is not None:
            self.engine = engine
        if docking_type is not None:
            self.docking_type = docking_type
        if bounding_box is not None:
            self.bounding_box = bounding_box
        if remove_ion is not None:
            self.remove_ion = remove_ion
        if remove_water is not None:
            self.remove_water = remove_water
        if remove_ligand is not None:
            self.remove_ligand = remove_ligand
        if add_hydrogen is not None:
            self.add_hydrogen = add_hydrogen

    @property
    def name(self):
        r"""Gets the name of this BindSiteDto.

        靶点名称，只能设置为target1或者target2。

        :return: The name of this BindSiteDto.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this BindSiteDto.

        靶点名称，只能设置为target1或者target2。

        :param name: The name of this BindSiteDto.
        :type name: str
        """
        self._name = name

    @property
    def receptor(self):
        r"""Gets the receptor of this BindSiteDto.

        :return: The receptor of this BindSiteDto.
        :rtype: :class:`huaweicloudsdkeihealth.v1.ReceptorDrugFile`
        """
        return self._receptor

    @receptor.setter
    def receptor(self, receptor):
        r"""Sets the receptor of this BindSiteDto.

        :param receptor: The receptor of this BindSiteDto.
        :type receptor: :class:`huaweicloudsdkeihealth.v1.ReceptorDrugFile`
        """
        self._receptor = receptor

    @property
    def engine(self):
        r"""Gets the engine of this BindSiteDto.

        **参数解释**： 引擎[，仅支持VINA，默认值为VINA](tag:hcs)[，支持DSDP、AUTODOCK_VINA，默认值为AUTODOCK_VINA](tag:hws)。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :return: The engine of this BindSiteDto.
        :rtype: str
        """
        return self._engine

    @engine.setter
    def engine(self, engine):
        r"""Sets the engine of this BindSiteDto.

        **参数解释**： 引擎[，仅支持VINA，默认值为VINA](tag:hcs)[，支持DSDP、AUTODOCK_VINA，默认值为AUTODOCK_VINA](tag:hws)。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :param engine: The engine of this BindSiteDto.
        :type engine: str
        """
        self._engine = engine

    @property
    def docking_type(self):
        r"""Gets the docking_type of this BindSiteDto.

        **参数解释**： 对接类型[，仅支持POCKET_DOCKING](tag:hws)[，支持BLIND_DOCKING、POCKET_DOCKING](tag:hcs)。 **约束限制**： 不涉及 **取值范围**： * POCKET_DOCKING：口袋对接 * [BLIND_DOCKING：全局对接](tag:hcs) **默认取值**： POCKET_DOCKING 

        :return: The docking_type of this BindSiteDto.
        :rtype: str
        """
        return self._docking_type

    @docking_type.setter
    def docking_type(self, docking_type):
        r"""Sets the docking_type of this BindSiteDto.

        **参数解释**： 对接类型[，仅支持POCKET_DOCKING](tag:hws)[，支持BLIND_DOCKING、POCKET_DOCKING](tag:hcs)。 **约束限制**： 不涉及 **取值范围**： * POCKET_DOCKING：口袋对接 * [BLIND_DOCKING：全局对接](tag:hcs) **默认取值**： POCKET_DOCKING 

        :param docking_type: The docking_type of this BindSiteDto.
        :type docking_type: str
        """
        self._docking_type = docking_type

    @property
    def bounding_box(self):
        r"""Gets the bounding_box of this BindSiteDto.

        :return: The bounding_box of this BindSiteDto.
        :rtype: :class:`huaweicloudsdkeihealth.v1.BoundingBoxDto`
        """
        return self._bounding_box

    @bounding_box.setter
    def bounding_box(self, bounding_box):
        r"""Sets the bounding_box of this BindSiteDto.

        :param bounding_box: The bounding_box of this BindSiteDto.
        :type bounding_box: :class:`huaweicloudsdkeihealth.v1.BoundingBoxDto`
        """
        self._bounding_box = bounding_box

    @property
    def remove_ion(self):
        r"""Gets the remove_ion of this BindSiteDto.

        去除受体中的离子

        :return: The remove_ion of this BindSiteDto.
        :rtype: bool
        """
        return self._remove_ion

    @remove_ion.setter
    def remove_ion(self, remove_ion):
        r"""Sets the remove_ion of this BindSiteDto.

        去除受体中的离子

        :param remove_ion: The remove_ion of this BindSiteDto.
        :type remove_ion: bool
        """
        self._remove_ion = remove_ion

    @property
    def remove_water(self):
        r"""Gets the remove_water of this BindSiteDto.

        去除受体中的水分子

        :return: The remove_water of this BindSiteDto.
        :rtype: bool
        """
        return self._remove_water

    @remove_water.setter
    def remove_water(self, remove_water):
        r"""Sets the remove_water of this BindSiteDto.

        去除受体中的水分子

        :param remove_water: The remove_water of this BindSiteDto.
        :type remove_water: bool
        """
        self._remove_water = remove_water

    @property
    def remove_ligand(self):
        r"""Gets the remove_ligand of this BindSiteDto.

        去除受体中的配体分子

        :return: The remove_ligand of this BindSiteDto.
        :rtype: bool
        """
        return self._remove_ligand

    @remove_ligand.setter
    def remove_ligand(self, remove_ligand):
        r"""Sets the remove_ligand of this BindSiteDto.

        去除受体中的配体分子

        :param remove_ligand: The remove_ligand of this BindSiteDto.
        :type remove_ligand: bool
        """
        self._remove_ligand = remove_ligand

    @property
    def add_hydrogen(self):
        r"""Gets the add_hydrogen of this BindSiteDto.

        增加氢原子

        :return: The add_hydrogen of this BindSiteDto.
        :rtype: bool
        """
        return self._add_hydrogen

    @add_hydrogen.setter
    def add_hydrogen(self, add_hydrogen):
        r"""Sets the add_hydrogen of this BindSiteDto.

        增加氢原子

        :param add_hydrogen: The add_hydrogen of this BindSiteDto.
        :type add_hydrogen: bool
        """
        self._add_hydrogen = add_hydrogen

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BindSiteDto):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
