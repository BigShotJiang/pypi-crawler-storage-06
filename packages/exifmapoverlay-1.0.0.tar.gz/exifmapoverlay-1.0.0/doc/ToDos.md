- Pfeiltasten links rechts evtl. zum Spulen des Timers verwenden.
- add version and help argument to CLI

