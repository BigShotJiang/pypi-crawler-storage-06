from exifMapOverlay.emo import ExifMapOverlay


if __name__ == "__main__":
    emo = ExifMapOverlay()
    emo.main()
