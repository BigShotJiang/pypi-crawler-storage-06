 nuro placeholder

