# Django Auto-Complete Plugin

A Django plugin that provides auto-import functionality for classes in your project.

## Installation

```bash
pip install django-autocomplete-package