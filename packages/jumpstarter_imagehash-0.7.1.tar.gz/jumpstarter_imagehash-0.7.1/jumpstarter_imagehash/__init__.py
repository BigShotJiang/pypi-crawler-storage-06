from .imagehash import ImageHash

ImageHash = ImageHash
