# Copyright 2025 Binhex <https://www.binhex.cloud>
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import product_template_id_category
from . import product_template
from . import res_partner_id_number
from . import sale_order
