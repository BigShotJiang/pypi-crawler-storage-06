from typing import Iterable

from .sample import Sample

Dataset = Iterable[Sample]
