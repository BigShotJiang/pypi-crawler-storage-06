# src/playbook/__init__.py
"""Playbook - A workflow engine for operations"""

__version__ = "0.5.0"
