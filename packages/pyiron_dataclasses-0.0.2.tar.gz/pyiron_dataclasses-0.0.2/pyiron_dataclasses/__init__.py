import pyiron_dataclasses._version

__version__ = pyiron_dataclasses._version.__version__
