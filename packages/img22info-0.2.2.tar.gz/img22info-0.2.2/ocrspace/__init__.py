"""OCR.Info Python SDK - upgraded version
Exports main client and models.
"""
from .client import OCRClient
from .errors import OCRError, AuthError, RequestError, ProcessingError
from .models import OCRResult, ParsedResult

__all__ = [
    "OCRClient",
    "OCRError", "AuthError", "RequestError", "ProcessingError",
    "OCRResult", "ParsedResult",
]
