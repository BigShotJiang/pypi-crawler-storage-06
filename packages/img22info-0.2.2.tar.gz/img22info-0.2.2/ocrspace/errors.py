
class OCRError(Exception):
    """Base exception for OCRSpace SDK."""
class AuthError(OCRError):
    """Raised when authentication fails (bad key)."""
class RequestError(OCRError):
    """Raised on network or HTTP errors."""
class ProcessingError(OCRError):
    """Raised when OCR.Space reports processing errors."""
