# -*- coding: utf-8 -*-

pad = '<pad>'
unk = '<unk>'
bos = '<bos>'
eos = '<eos>'
