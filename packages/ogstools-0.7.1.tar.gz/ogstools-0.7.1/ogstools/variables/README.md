# variables

See the documentation for more info:

- [Documentation source](../../docs/user-guide/variables.md)
- [Documentation web site](https://ogstools.opengeosys.org/stable/user-guide/variables.html)
