# FEFLOWlib - FEFLOW to ogs converter

See the documentation for more info:

- [Documentation source](../../docs/user-guide/feflowlib.md)
- [Documentation web site](https://ogstools.opengeosys.org/stable/user-guide/feflowlib.html)
