Pre-processing: preparing the simulation
========================================

This section shows how to create bulk meshes for the OGS simulation.
To complete the model, boundary meshes and a prj file must be created in
addition to the bulk mesh. Examples on those subjects will be added in the
future.
