Post-processing: reading and analyzing the data
===============================================
