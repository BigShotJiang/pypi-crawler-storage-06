Run a Simulation
================

We will show how to run a OGS simulation. The Project files and the meshes must be prepared in advance.
