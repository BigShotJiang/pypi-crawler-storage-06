Create and manipulate prj-files
===============================

The following Jupyter notebooks provide some examples of how to use OGSTools to
create and manipulate Project-files to configure OGS models.
