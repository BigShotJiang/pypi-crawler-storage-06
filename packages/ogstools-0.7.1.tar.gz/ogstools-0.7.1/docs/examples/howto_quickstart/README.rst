Quick start
===========

In this section you will find examples helping you use the most commonly used
features of ogstools: reading data, plotting and simple post-processing

.. toctree::
   :maxdepth: 3
