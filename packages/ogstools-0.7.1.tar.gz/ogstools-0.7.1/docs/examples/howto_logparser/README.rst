Analyze logs
============

This section covers the usage of the logparser, which can be used to analyze OGS
simulations with respect to the runtime or convergence behavior.
