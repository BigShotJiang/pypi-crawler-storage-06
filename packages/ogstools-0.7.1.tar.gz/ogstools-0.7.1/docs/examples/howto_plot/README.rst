Plotting the data
=================

The following jupyter notebooks provide some examples of how to use ogstools to
create all different kinds of plots.
