Conversion tools
================

This section covers tools designed to help with converting already existing
simulations setup with alternative software to open formats compatible with OGS.
