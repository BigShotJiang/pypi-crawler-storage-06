# API reference

```{eval-rst}
.. include:: ogstools.rst
```

```{toctree}
---
hidden:
caption: Indices and tables
---
/genindex
/modindex
```
