# OGSTools 0.7.0 Release Notes

# Breaking changes

## API breaking changes

## Deprecations

### Examples

# Changes (non API-breaking)

## Bugfixes

## Features

## Infrastructure

## Documentation

### Tests

### Imports

## Maintainer TODOs

### next sub release

### next main release
