# Release notes

```{toctree}
---
maxdepth: 3
---
0.x (upcoming release)  <ogstools-0.x>
0.7.1 <ogstools-0.7.1>
0.7.0 <ogstools-0.7.0>
0.6.0 <ogstools-0.6.0>
0.5.0 <ogstools-0.5.0>
0.4.0 <ogstools-0.4.0>
0.3.1 <ogstools-0.3.1>
0.3.0 <ogstools-0.3.0>
0.2.0 <ogstools-0.2.0>
0.1.0 <ogstools-0.1.0>
0.0.3 <ogstools-0.0.3>
```
