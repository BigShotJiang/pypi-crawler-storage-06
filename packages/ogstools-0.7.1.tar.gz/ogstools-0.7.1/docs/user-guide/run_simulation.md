# Running OGS Simulation

- [](../auto_examples/howto_simulation/plot_010_simulate.rst)

## Run interactively

- [](../auto_examples/howto_simulation/plot_100_ogs_interactive_simulator.rst)
- Mesh manipulation
  - [](../auto_examples/howto_simulation/plot_200_ogs_interactive_meshes_from_simulator.rst)
  - [](../auto_examples/howto_simulation/plot_250_ogs_interactive_mesh_native.rst)
