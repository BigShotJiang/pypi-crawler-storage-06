"""MEMG Core - Lightweight memory system for AI agents"""

__version__ = "0.1.0"
