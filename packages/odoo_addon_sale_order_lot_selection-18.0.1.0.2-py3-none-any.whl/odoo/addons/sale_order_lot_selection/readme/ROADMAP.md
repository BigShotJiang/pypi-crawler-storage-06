Block sale order validation on confirmation if the selected lot has been
removed of this module Indeed nobody seems to know what it had been
implemented on early versions and it is really blocking other generic
use case. One may want to validate a sale order restricting it to a lot
that will be produced for instance and does not exist yet.

This feature may be easyly put it back, in a separated module, if a use
case requires it. The removal of this feature was made on this commit :
3234b2ccccf1dffafbe0a8fa8efaaea44f2e47ef.
