==================================================
supplementary
==================================================

Description
=================================
補助情報関係のコマンドです。


Available Commands
=================================


.. toctree::
   :maxdepth: 1
   :titlesonly:

   delete
   list
   put

Usage Details
=================================

.. argparse::
   :ref: annofabcli.supplementary.subcommand_supplementary.add_parser
   :prog: annofabcli supplementary
   :nosubcommands:
