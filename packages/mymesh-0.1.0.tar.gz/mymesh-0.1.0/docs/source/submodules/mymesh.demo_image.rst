﻿mymesh.demo\_image
==================

.. currentmodule:: mymesh

.. autofunction:: demo_image