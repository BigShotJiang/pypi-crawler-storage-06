﻿mymesh.demo\_mesh
=================

.. currentmodule:: mymesh

.. autofunction:: demo_mesh