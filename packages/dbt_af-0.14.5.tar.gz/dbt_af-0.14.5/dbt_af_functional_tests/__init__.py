from .main import cli  # noqa

__all__ = [
    'cli',
]
