class UnknownTableauResourceTypeException(Exception):
    pass


class FailedTableauRefreshTasksException(Exception):
    pass
