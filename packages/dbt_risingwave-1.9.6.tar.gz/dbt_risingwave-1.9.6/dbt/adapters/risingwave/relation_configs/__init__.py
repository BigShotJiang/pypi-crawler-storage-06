from dbt.adapters.risingwave.relation_configs.index import (
    RisingWaveIndexConfig,
    RisingWaveIndexConfigChange,
)
from dbt.adapters.risingwave.relation_configs.materialized_view import (
    RisingWaveMaterializedViewConfig,
    RisingWaveMaterializedViewConfigChangeCollection,
)
