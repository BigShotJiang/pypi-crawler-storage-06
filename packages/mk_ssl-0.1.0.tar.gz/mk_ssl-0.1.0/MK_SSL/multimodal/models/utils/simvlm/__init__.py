from MK_SSL.multimodal.models.utils.simvlm.resblock import BottleneckBlock

__all__ = ["BottleneckBlock"]
