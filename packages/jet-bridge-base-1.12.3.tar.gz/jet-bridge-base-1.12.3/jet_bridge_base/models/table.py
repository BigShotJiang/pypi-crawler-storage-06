
class Table(object):

    def __init__(self, name, columns):
        self.name = name
        self.columns = columns
