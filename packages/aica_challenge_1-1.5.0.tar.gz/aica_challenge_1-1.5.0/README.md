This is a SW package to enable running of the fist AICA challenge.

All information can be found here: [aica-challenge.csirt.muni.cz](https://aica-challenge.csirt.muni.cz)