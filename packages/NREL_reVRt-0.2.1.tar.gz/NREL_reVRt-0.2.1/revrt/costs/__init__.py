"""reVRt Cost Layer functionality"""
