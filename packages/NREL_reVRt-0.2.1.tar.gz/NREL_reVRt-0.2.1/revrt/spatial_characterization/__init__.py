"""Spatial characterization routines for transmission routes"""
