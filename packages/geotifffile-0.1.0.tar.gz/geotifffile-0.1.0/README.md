# geotifffile
Building on the tifffile package, this is a simple helper function that will read a single-channel GeoTIFF file into an xarray DataArray.
