"""
GAdapt genetic algorithm
"""
