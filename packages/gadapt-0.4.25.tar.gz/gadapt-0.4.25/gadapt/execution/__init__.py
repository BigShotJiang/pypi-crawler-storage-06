"""
Еxecuting the Genetic Algorithm flow.
"""
