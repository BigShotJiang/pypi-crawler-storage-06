"""
Parent selection algorithms
"""
