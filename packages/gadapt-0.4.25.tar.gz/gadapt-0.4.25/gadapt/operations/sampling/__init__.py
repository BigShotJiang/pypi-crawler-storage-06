"""
Sampling methods are used in a parent selection, but also in other\
    algorithms based on rainking chromosomes and genes.
"""
