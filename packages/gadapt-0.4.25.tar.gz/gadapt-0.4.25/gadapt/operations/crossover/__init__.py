"""
Crossover functionality
"""
