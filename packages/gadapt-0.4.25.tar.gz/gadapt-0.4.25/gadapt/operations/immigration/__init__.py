"""
Application of the Random Immigrants Concept
"""
