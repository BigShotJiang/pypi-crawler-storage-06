"""
Genetic Algorithm Operations:
- Finding Costs
- Crossover
- Exit Check
- Gene Combination
- Immigration
- Mutation
- Parent Selection
- Sampling
- Gene Update
"""
