"""
Population update algorithms
"""
