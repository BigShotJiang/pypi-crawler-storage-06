"""
Genetic Algorithm Utility
"""
