"""
GA Options validation
"""
