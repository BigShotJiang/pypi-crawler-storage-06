"""
Genetic Algorithm Model
"""
