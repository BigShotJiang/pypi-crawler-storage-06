class ClassA(object):
    pass
