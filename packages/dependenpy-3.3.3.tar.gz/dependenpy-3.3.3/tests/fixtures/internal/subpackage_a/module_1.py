import internal.subpackage_a.subpackage_1.module_i


class Class1(object):
    def function(self):
        import sys
