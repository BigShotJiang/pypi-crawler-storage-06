"""
Logging utilities for ZeroBuffer serve
"""