DEFAULT_IGNORES: list[str] = [
    ".cspell.*",
    "*-lock.*",
    "*.lock",
    "*.lockb",
    "CHANGELOG.md",
    "cspell.*",
]
