---
title: License
---

# License

```
--8<-- "LICENSE"
```
