def test_always_pass():
    assert True
