class DataprocError(Exception):
    pass
