from .tp_base import send, send2
from .config import init
from mgo_processor.tp_processing.method_cols import method_cols
