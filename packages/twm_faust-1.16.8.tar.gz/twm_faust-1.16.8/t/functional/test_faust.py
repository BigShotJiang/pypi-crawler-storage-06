import faust


def test_dir():
    assert dir(faust)
