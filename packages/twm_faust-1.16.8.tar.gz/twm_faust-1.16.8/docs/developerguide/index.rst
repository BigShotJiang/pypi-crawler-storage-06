.. _developers-guide:

=================
 Developer Guide
=================

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    overview
    partition_assignor

