=====================================================
 ``faust.stores``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.stores

.. automodule:: faust.stores
    :members:
    :undoc-members:
