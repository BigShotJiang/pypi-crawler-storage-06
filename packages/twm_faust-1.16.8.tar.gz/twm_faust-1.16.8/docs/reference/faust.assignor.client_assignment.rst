=====================================================
 ``faust.assignor.client_assignment``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.assignor.client_assignment

.. automodule:: faust.assignor.client_assignment
    :members:
    :undoc-members:
