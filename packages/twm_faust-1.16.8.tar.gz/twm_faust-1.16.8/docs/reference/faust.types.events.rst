=====================================================
 ``faust.types.events``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.events

.. automodule:: faust.types.events
    :members:
    :undoc-members:
