=====================================================
 ``faust.utils.functional``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.utils.functional

.. automodule:: faust.utils.functional
    :members:
    :undoc-members:
