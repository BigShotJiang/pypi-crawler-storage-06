=====================================================
 ``faust.cli.params``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.params

.. automodule:: faust.cli.params
    :members:
    :undoc-members:
