=====================================================
 ``faust.assignor.leader_assignor``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.assignor.leader_assignor

.. automodule:: faust.assignor.leader_assignor
    :members:
    :undoc-members:
