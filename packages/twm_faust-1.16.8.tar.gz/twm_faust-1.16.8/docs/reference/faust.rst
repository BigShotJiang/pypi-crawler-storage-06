=====================================================
 ``faust``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust

.. automodule:: faust
    :members:
    :undoc-members:
