=====================================================
 ``faust.models.tags``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.models.tags

.. automodule:: faust.models.tags
    :members:
    :undoc-members:
