=====================================================
 ``faust.cli.livecheck``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.livecheck

.. automodule:: faust.cli.livecheck
    :members:
    :undoc-members:
