=====================================================
 ``faust.types.stores``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.stores

.. automodule:: faust.types.stores
    :members:
    :undoc-members:
