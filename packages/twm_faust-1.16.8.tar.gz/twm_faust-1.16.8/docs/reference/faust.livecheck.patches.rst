=====================================================
 ``faust.livecheck.patches``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.livecheck.patches

.. automodule:: faust.livecheck.patches
    :members:
    :undoc-members:
