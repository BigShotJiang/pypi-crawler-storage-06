=====================================================
 ``faust.assignor.cluster_assignment``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.assignor.cluster_assignment

.. automodule:: faust.assignor.cluster_assignment
    :members:
    :undoc-members:
