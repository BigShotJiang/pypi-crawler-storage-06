=====================================================
 ``faust.sensors.statsd``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.sensors.statsd

.. automodule:: faust.sensors.statsd
    :members:
    :undoc-members:
