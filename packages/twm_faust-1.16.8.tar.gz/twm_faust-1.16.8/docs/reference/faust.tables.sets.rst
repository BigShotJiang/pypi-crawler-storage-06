=====================================================
 ``faust.tables.sets``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.tables.sets

.. automodule:: faust.tables.sets
    :members:
    :undoc-members:
