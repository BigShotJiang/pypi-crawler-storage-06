=====================================================
 ``faust.agents``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.agents

.. automodule:: faust.agents
    :members:
    :undoc-members:
