=====================================================
 ``faust.fixups.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.fixups.base

.. automodule:: faust.fixups.base
    :members:
    :undoc-members:
