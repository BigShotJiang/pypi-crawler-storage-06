=====================================================
 ``faust.stores.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.stores.base

.. automodule:: faust.stores.base
    :members:
    :undoc-members:
