=====================================================
 ``faust.sensors.datadog``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.sensors.datadog

.. automodule:: faust.sensors.datadog
    :members:
    :undoc-members:
