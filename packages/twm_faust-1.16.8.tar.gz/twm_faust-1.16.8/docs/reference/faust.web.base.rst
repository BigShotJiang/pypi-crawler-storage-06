=====================================================
 ``faust.web.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.base

.. automodule:: faust.web.base
    :members:
    :undoc-members:
