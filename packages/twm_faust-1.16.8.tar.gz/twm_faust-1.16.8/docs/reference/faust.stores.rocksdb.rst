=====================================================
 ``faust.stores.rocksdb``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.stores.rocksdb

.. automodule:: faust.stores.rocksdb
    :members:
    :undoc-members:
