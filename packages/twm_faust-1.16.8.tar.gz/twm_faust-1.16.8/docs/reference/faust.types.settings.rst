=====================================================
 ``faust.types.settings``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.settings

.. automodule:: faust.types.settings
    :members:
    :undoc-members:
