=====================================================
 ``faust.cli.agents``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.agents

.. automodule:: faust.cli.agents
    :members:
    :undoc-members:
