=====================================================
 ``faust.app``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.app

.. automodule:: faust.app
    :members:
    :undoc-members:
