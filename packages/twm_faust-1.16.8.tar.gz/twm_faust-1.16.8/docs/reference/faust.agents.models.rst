=====================================================
 ``faust.agents.models``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.agents.models

.. automodule:: faust.agents.models
    :members:
    :undoc-members:
