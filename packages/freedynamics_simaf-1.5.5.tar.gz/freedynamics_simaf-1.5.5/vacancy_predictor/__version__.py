"""Version information for vacancy-predictor"""

__version__ = "1.5.5"
__author__ = "Bergamin Santiago"
__email__ = "santiagobergamin@com.com"
__description__ = "A comprehensive ML tool for vacancy prediction with GUI"