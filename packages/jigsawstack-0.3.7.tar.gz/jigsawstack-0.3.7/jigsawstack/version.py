__version__ = "0.3.7"


def get_version() -> str:
    """
    Returns the current version of this lib
    """
    return __version__
