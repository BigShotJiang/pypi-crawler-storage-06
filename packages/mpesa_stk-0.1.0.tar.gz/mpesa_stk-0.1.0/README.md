# Mpesa STK Library

A simple Python library for Safaricom M-Pesa STK Push integration.

## Installation
```bash
pip install mpesa-stk
