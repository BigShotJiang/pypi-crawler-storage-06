"""Package initialization for smp_lib."""
