# noqa: N999
from betterKickAPI.kick import Kick

__all__ = ["Kick"]
