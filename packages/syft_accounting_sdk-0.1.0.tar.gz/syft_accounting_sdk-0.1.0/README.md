# Accounting Service Python SDK

## Installation

You can install directly from GitHub:

```sh
pip install git+ssh://git@github.com/OpenMined/accounting-sdk.git
```

If you prefer `uv`:

```sh
uv pip install git+ssh://git@github.com/OpenMined/accounting-sdk.git
```

## Examples

Check out the `./notebooks/` directory for examples on using the SDK.
