from gpframe.contracts.protocols import gproot as _gproot

Context = _gproot.ipc.event.Context
