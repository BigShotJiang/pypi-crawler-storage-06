To use this module, you need to:

1.  Go to Knowledge \> Pages
2.  Create a new page and choose the previously created category.
3.  A notification is sent to the approvers group with a link to the
    page history to review.
4.  Depending on the review, the page history is approved or not.
5.  Users reading the page see the last approved version.
