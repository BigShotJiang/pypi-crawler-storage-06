This module executes user-provided code though a safe_eval which might be
unsecure.
How to mitigate risks should be adressed in future versions of this module.
