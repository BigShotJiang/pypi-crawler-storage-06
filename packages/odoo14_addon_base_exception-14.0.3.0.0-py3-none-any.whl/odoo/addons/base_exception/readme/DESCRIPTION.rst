This module provide an abstract model to manage customizable
exceptions to be applied on different models (sale order, invoice, ...).

It is not useful by itself. You can see an example of implementation
in the 'sale_exception' module. (sale-workflow repository) or
'purchase_exception' module (purchase-workflow repository).
