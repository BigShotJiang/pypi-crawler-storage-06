def get_direct_link_from_streamtape(embeded_streamtape_link: str) -> str:
    pass
