from .components.assets_builder import register_plot as register_plot
from .components.assets_builder import register_plotly as register_plotly

app_name = "deckz"
