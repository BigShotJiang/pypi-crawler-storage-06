mod deterministic;
pub use deterministic::DeterministicFunnyNumberFactory;

mod random;
pub use random::RandomFunnyNumberFactory;
