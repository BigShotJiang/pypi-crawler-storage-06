1.  Create a purchase order and confirm it.
2.  Receive the products/services.
3.  Create a vendor bill and reduce the invoiced quantity. The purchase
    order invoicing status is 'Waiting Bills'.
4.  Lock the Purchase Order and change its status to 'Done'.
5.  Check the field 'Force Invoiced'.

The field is only visible for users that have the technical setting 'Set
purchase orders to Force Invoiced'. By default, all purchase managers have this
setting.
