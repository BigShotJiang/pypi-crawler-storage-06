"""
Módulo de renderizadores - Generación de salidas visuales PNG únicamente
"""

from .pillow_renderer import PillowRenderer

__all__ = ["PillowRenderer"]
