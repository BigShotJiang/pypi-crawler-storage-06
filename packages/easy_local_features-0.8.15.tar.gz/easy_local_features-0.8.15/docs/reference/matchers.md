# Matchers (reference)

- NearestNeighborMatcher: default for feature-based pipelines
- LoFTR, SuperGlue, LightGlue: advanced matchers in `matching/`

Tune thresholds and checks per application.
