# License

This repository aggregates wrappers for third-party models and tools. Each baseline/model keeps its original upstream license. See `LICENSES.md`.
