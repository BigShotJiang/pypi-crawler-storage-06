#!/usr/bin/env python

"""Tests for `climdata` package."""


import unittest

from climdata import climdata


class TestClimdata(unittest.TestCase):
    """Tests for `climdata` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
