# Welcome to climdata


[![image](https://img.shields.io/pypi/v/climdata.svg)](https://pypi.python.org/pypi/climdata)


**This project automates the fetching and extraction of weather data from multiple sources — such as MSWX, DWD HYRAS, ERA5-Land, NASA-NEX-GDDP, and more — for a given location and time range.**


-   Free software: MIT License
-   Documentation: <https://Kaushikreddym.github.io/climdata>
    

## Features

-   TODO
