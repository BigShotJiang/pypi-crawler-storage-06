"""Test suite for variable definitions."""
