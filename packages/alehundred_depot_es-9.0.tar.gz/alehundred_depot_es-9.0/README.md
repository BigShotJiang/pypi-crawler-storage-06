# Alehundred-Depot (Versión en Español)

Una herramienta con interfaz de texto (TUI) para facilitar la instalación y gestión de un servidor Perforce Helix Core en hardware de bajo costo como una Raspberry Pi.

## Instalación

```bash
pip install alehundred-depot-es