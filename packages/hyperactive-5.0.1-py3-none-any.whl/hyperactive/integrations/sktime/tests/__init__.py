"""Tests for integrations for sktime."""
