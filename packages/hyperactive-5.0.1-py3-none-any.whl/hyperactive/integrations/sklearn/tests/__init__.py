"""Tests for sklearn integrations."""
