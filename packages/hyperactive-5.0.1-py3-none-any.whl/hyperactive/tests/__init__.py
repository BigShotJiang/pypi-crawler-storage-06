"""Object unified API test suite."""
