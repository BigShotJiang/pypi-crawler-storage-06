sid = 'xiaomiio'
msgURL = f'https://account.xiaomi.com/pass/serviceLogin?sid={sid}&_json=true'
loginURL = 'https://account.xiaomi.com/pass/serviceLoginAuth2'
qrURL = 'https://account.xiaomi.com/longPolling/loginUrl'
apiURL = 'https://api.io.mi.com/app'
deviceURL = 'https://home.miot-spec.com/spec/'
accountURL = 'https://account.xiaomi.com/pass2/profile/home?bizFlag=&userId='

defaultUA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36 Edg/126.0.0.0'
