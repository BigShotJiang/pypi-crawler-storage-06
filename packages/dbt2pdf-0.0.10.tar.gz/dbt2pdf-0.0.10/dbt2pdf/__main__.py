"""Dbt2Pdf CLI access point."""

from dbt2pdf.cli import app

if __name__ == "__main__":
    app()
