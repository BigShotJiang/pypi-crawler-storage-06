from .detection import ConflictDetection
from .resolution import ConflictResolution
from .statebased import StateBased
from .mvp import MVP