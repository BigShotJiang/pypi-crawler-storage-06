#!/usr/bin/env python3
"""
Test documentation completeness and integration.
Validates that all documentation files are up-to-date and properly cross-referenced.
"""

def test_readme_security_sections():
    """Test that README.md has comprehensive security documentation."""
    print("Testing README.md security sections...")

    try:
        with open('README.md', 'r') as f:
            content = f.read()

        required_security_elements = [
            'OAuth 2.0 with PKCE',
            'No Client Secrets',
            'Zero-Setup Security',
            'PKCE Security',
            'Proof Key for Code Exchange',
            'SECURITY.md',
            'public client',
            'security validation'
        ]

        missing_elements = []
        for element in required_security_elements:
            if element not in content:
                missing_elements.append(element)

        if missing_elements:
            print(f"❌ Missing security elements in README.md: {missing_elements}")
            return False

        print("✅ README.md has comprehensive security documentation")
        return True

    except FileNotFoundError:
        print("❌ README.md not found")
        return False

def test_deployment_security_sections():
    """Test that DEPLOYMENT.md has security validation and OAuth guidance."""
    print("\nTesting DEPLOYMENT.md security sections...")

    try:
        with open('DEPLOYMENT.md', 'r') as f:
            content = f.read()

        required_deployment_elements = [
            'Security Validation',
            'test_pkce_security.py',
            'test_final_security.py',
            'OAuth Configuration for Developers',
            'public client',
            'Desktop application',
            'Do NOT generate a client secret',
            'Run security validation tests',
            'PKCE implementation is complete'
        ]

        missing_elements = []
        for element in required_deployment_elements:
            if element not in content:
                missing_elements.append(element)

        if missing_elements:
            print(f"❌ Missing elements in DEPLOYMENT.md: {missing_elements}")
            return False

        print("✅ DEPLOYMENT.md has comprehensive security guidance")
        return True

    except FileNotFoundError:
        print("❌ DEPLOYMENT.md not found")
        return False

def test_cross_references():
    """Test that documentation files properly reference each other."""
    print("\nTesting cross-references between documentation files...")

    try:
        with open('README.md', 'r') as f:
            readme_content = f.read()

        with open('DEPLOYMENT.md', 'r') as f:
            deployment_content = f.read()

        # Check that README references SECURITY.md and DEPLOYMENT.md
        readme_refs = [
            'SECURITY.md',
            'DEPLOYMENT.md'
        ]

        missing_readme_refs = []
        for ref in readme_refs:
            if ref not in readme_content:
                missing_readme_refs.append(ref)

        if missing_readme_refs:
            print(f"❌ Missing references in README.md: {missing_readme_refs}")
            return False

        print("✅ All cross-references are present")
        return True

    except FileNotFoundError as e:
        print(f"❌ Documentation file not found: {e}")
        return False

def test_security_file_exists():
    """Test that SECURITY.md exists and has comprehensive content."""
    print("\nTesting SECURITY.md existence and content...")

    try:
        with open('SECURITY.md', 'r') as f:
            content = f.read()

        required_security_content = [
            'PKCE',
            'Proof Key for Code Exchange',
            'public client',
            'OAuth 2.0',
            'code_verifier',
            'code_challenge',
            'SHA256',
            'Security Features'
        ]

        missing_content = []
        for item in required_security_content:
            if item not in content:
                missing_content.append(item)

        if missing_content:
            print(f"❌ Missing content in SECURITY.md: {missing_content}")
            return False

        # Check minimum length
        if len(content) < 2000:
            print("❌ SECURITY.md appears to be too short")
            return False

        print("✅ SECURITY.md is comprehensive and detailed")
        return True

    except FileNotFoundError:
        print("❌ SECURITY.md not found")
        return False

def test_developer_vs_user_clarity():
    """Test that documentation clearly distinguishes developer vs user setup."""
    print("\nTesting developer vs user setup clarity...")

    try:
        with open('README.md', 'r') as f:
            readme_content = f.read()

        with open('DEPLOYMENT.md', 'r') as f:
            deployment_content = f.read()

        # Check README has user-focused messaging
        user_focused_elements = [
            'No setup required',
            'zero-setup',
            'automatically prompt',
            'Package Maintainers'
        ]

        # Check DEPLOYMENT has developer-focused guidance
        developer_focused_elements = [
            'OAuth Configuration for Developers',
            'Before deploying',
            'YOUR_CLIENT_ID',
            'Configure OAuth Application'
        ]

        missing_user_elements = [elem for elem in user_focused_elements if elem not in readme_content]
        missing_dev_elements = [elem for elem in developer_focused_elements if elem not in deployment_content]

        if missing_user_elements:
            print(f"❌ Missing user-focused elements in README.md: {missing_user_elements}")
            return False

        if missing_dev_elements:
            print(f"❌ Missing developer-focused elements in DEPLOYMENT.md: {missing_dev_elements}")
            return False

        print("✅ Clear distinction between developer and user setup")
        return True

    except FileNotFoundError as e:
        print(f"❌ Documentation file not found: {e}")
        return False

def main():
    """Run all documentation completeness tests."""
    print("Gmail MCP Documentation Completeness Validation")
    print("=" * 60)

    tests = [
        test_readme_security_sections,
        test_deployment_security_sections,
        test_cross_references,
        test_security_file_exists,
        test_developer_vs_user_clarity
    ]

    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test.__name__} failed with exception: {e}")
            results.append(False)

    print("\n" + "=" * 60)
    print("Documentation Completeness Summary:")
    print(f"✅ Passed: {sum(results)}")
    print(f"❌ Failed: {len(results) - sum(results)}")
    print(f"📊 Total: {len(results)}")

    if all(results):
        print("\n🎉📚 Documentation is COMPLETE and PROFESSIONAL!")
        print("\n📋 Documentation Quality Summary:")
        print("✅ README.md: Comprehensive security features and user guidance")
        print("✅ DEPLOYMENT.md: Complete security validation and OAuth setup")
        print("✅ SECURITY.md: Detailed PKCE implementation explanation")
        print("✅ Cross-references: All documentation properly linked")
        print("✅ User vs Developer: Clear distinction in guidance")
        print("✅ Security focus: Prominent security messaging throughout")
        print("\n🚀 Ready for professional PyPI deployment!")
        print("\n📝 Final steps:")
        print("1. Replace YOUR_CLIENT_ID in oauth.py")
        print("2. Run security validation tests")
        print("3. Build and deploy to PyPI")
        print("4. Users will have secure, zero-setup Gmail experience!")
    else:
        print("\n⚠️  Some documentation completeness tests failed.")

    return all(results)

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)