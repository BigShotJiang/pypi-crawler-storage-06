#!/usr/bin/env python3
"""
Test OAuth structure without importing MCP dependencies.
"""

def test_oauth_file_structure():
    """Test that oauth.py has the correct structure."""
    print("Testing OAuth file structure...")

    try:
        with open('gmail_mcp/auth/oauth.py', 'r') as f:
            content = f.read()

        # Check for embedded credentials (secure version)
        assert 'EMBEDDED_OAUTH_CREDENTIALS' in content, "Missing EMBEDDED_OAUTH_CREDENTIALS"
        assert 'YOUR_CLIENT_ID' in content, "Missing client ID placeholder"
        assert 'YOUR_CLIENT_SECRET' not in content, "Client secret should be removed for security"

        # Check for automatic OAuth flow method
        assert '_run_automatic_oauth_flow' in content, "Missing automatic OAuth flow method"

        # Check for callback handler
        assert 'OAuthCallbackHandler' in content, "Missing OAuth callback handler"
        assert 'use_embedded_credentials' in content, "Missing embedded credentials support"

        print("✅ OAuth file structure is correct")
        return True

    except FileNotFoundError:
        print("❌ oauth.py file not found")
        return False
    except AssertionError as e:
        print(f"❌ Structure check failed: {e}")
        return False

def test_server_file_structure():
    """Test that server.py has the correct structure for auto-OAuth."""
    print("\nTesting server file structure...")

    try:
        with open('gmail_mcp/server.py', 'r') as f:
            content = f.read()

        # Check for automatic OAuth initialization
        assert 'use_embedded_credentials=' in content, "Missing embedded credentials parameter"
        assert 'self.credentials_path is None' in content, "Missing automatic credentials detection"

        # Check for updated setup command
        assert 'Legacy Mode' in content or 'no longer required' in content, "Setup command not updated for auto-OAuth"

        print("✅ Server file structure is correct")
        return True

    except FileNotFoundError:
        print("❌ server.py file not found")
        return False
    except AssertionError as e:
        print(f"❌ Structure check failed: {e}")
        return False

def test_documentation_updated():
    """Test that documentation reflects the zero-setup flow."""
    print("\nTesting documentation updates...")

    try:
        with open('README.md', 'r') as f:
            readme_content = f.read()

        with open('examples/setup_guide.md', 'r') as f:
            guide_content = f.read()

        # Check README
        assert 'No setup required' in readme_content, "README missing zero-setup messaging"
        assert 'automatically prompt' in readme_content, "README missing automatic auth explanation"

        # Check setup guide
        assert 'Zero-Setup Installation' in guide_content, "Setup guide missing zero-setup section"
        assert 'No Google Cloud setup required' in guide_content, "Setup guide missing simplified instructions"

        print("✅ Documentation has been updated for zero-setup flow")
        return True

    except FileNotFoundError as e:
        print(f"❌ Documentation file not found: {e}")
        return False
    except AssertionError as e:
        print(f"❌ Documentation check failed: {e}")
        return False

def main():
    """Run structure tests."""
    print("Gmail MCP Auto-OAuth Structure Validation")
    print("=" * 50)

    tests = [
        test_oauth_file_structure,
        test_server_file_structure,
        test_documentation_updated,
    ]

    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test.__name__} failed with exception: {e}")
            results.append(False)

    print("\n" + "=" * 50)
    print("Structure Validation Summary:")
    print(f"✅ Passed: {sum(results)}")
    print(f"❌ Failed: {len(results) - sum(results)}")
    print(f"📊 Total: {len(results)}")

    if all(results):
        print("\n🎉 Auto-OAuth structure validation passed!")
        print("\n📋 Implementation Summary:")
        print("✅ Embedded OAuth credentials configured")
        print("✅ Automatic OAuth flow implemented")
        print("✅ HTTP callback server for OAuth")
        print("✅ Server uses embedded credentials by default")
        print("✅ CLI updated for zero-setup experience")
        print("✅ Documentation updated for new flow")
        print("\n🚀 Ready for deployment!")
        print("\n📝 Before deploying to PyPI:")
        print("1. Replace YOUR_CLIENT_ID in oauth.py with your public OAuth client ID")
        print("2. Test the actual OAuth flow manually")
        print("3. Run: python -m build")
        print("4. Upload: twine upload dist/*")
        print("\n✨ Users will have zero-setup experience!")
    else:
        print("\n⚠️  Some structure validation failed.")

    return all(results)

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)