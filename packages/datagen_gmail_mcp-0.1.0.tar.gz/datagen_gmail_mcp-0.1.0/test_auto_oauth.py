#!/usr/bin/env python3
"""
Test script to verify automatic OAuth integration.
This script tests the automatic OAuth flow without actually connecting to Gmail.
"""

def test_embedded_credentials():
    """Test that embedded OAuth credentials are properly configured."""
    print("Testing embedded OAuth credentials...")

    try:
        from gmail_mcp.auth.oauth import EMBEDDED_OAUTH_CREDENTIALS

        # Check structure
        assert "installed" in EMBEDDED_OAUTH_CREDENTIALS, "Missing 'installed' key"
        installed = EMBEDDED_OAUTH_CREDENTIALS["installed"]

        required_keys = [
            "client_id", "client_secret", "auth_uri",
            "token_uri", "auth_provider_x509_cert_url", "redirect_uris"
        ]

        for key in required_keys:
            assert key in installed, f"Missing required key: {key}"

        # Check that placeholders are present (will need to be replaced with real credentials)
        assert "YOUR_CLIENT_ID" in installed["client_id"], "Client ID placeholder found (needs replacement)"
        assert "YOUR_CLIENT_SECRET" in installed["client_secret"], "Client secret placeholder found (needs replacement)"

        print("✅ Embedded OAuth credentials structure is correct")
        print("⚠️  Remember to replace YOUR_CLIENT_ID and YOUR_CLIENT_SECRET with real values")
        return True

    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False
    except AssertionError as e:
        print(f"❌ Credential structure error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False


def test_oauth_handler_initialization():
    """Test that GmailOAuth can be initialized with embedded credentials."""
    print("\nTesting GmailOAuth initialization...")

    try:
        from gmail_mcp.auth.oauth import GmailOAuth

        # Test with embedded credentials (default)
        oauth_handler = GmailOAuth()
        assert oauth_handler.use_embedded_credentials == True, "Should use embedded credentials by default"
        assert oauth_handler.credentials_data is not None, "Credentials data should be loaded"
        assert oauth_handler.credentials_path is None, "Credentials path should be None for embedded mode"

        # Test with custom credentials path
        oauth_handler_legacy = GmailOAuth(credentials_path="/some/path", use_embedded_credentials=False)
        assert oauth_handler_legacy.use_embedded_credentials == False, "Should not use embedded credentials when disabled"

        print("✅ GmailOAuth initialization working correctly")
        return True

    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Initialization error: {e}")
        return False


def test_server_initialization():
    """Test that GmailMCPServer initializes with automatic OAuth."""
    print("\nTesting GmailMCPServer initialization...")

    try:
        from gmail_mcp.server import GmailMCPServer

        # Test default initialization (should use embedded credentials)
        server = GmailMCPServer()
        assert server.credentials_path is None, "Should use embedded credentials by default"

        # Test with custom credentials
        server_custom = GmailMCPServer(credentials_path="/some/path")
        assert server_custom.credentials_path == "/some/path", "Should use provided credentials path"

        print("✅ GmailMCPServer initialization working correctly")
        return True

    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Server initialization error: {e}")
        return False


def test_callback_handler():
    """Test that OAuth callback handler is properly implemented."""
    print("\nTesting OAuth callback handler...")

    try:
        from gmail_mcp.auth.oauth import OAuthCallbackHandler

        # Check that the class exists and has required methods
        assert hasattr(OAuthCallbackHandler, 'do_GET'), "Missing do_GET method"
        assert hasattr(OAuthCallbackHandler, 'log_message'), "Missing log_message method"

        print("✅ OAuth callback handler is properly implemented")
        return True

    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Callback handler error: {e}")
        return False


def main():
    """Run all tests."""
    print("Gmail MCP Auto-OAuth Integration Test")
    print("=" * 50)

    tests = [
        test_embedded_credentials,
        test_oauth_handler_initialization,
        test_server_initialization,
        test_callback_handler,
    ]

    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test.__name__} failed with exception: {e}")
            results.append(False)

    print("\n" + "=" * 50)
    print("Auto-OAuth Test Summary:")
    print(f"✅ Passed: {sum(results)}")
    print(f"❌ Failed: {len(results) - sum(results)}")
    print(f"📊 Total: {len(results)}")

    if all(results):
        print("\n🎉 All auto-OAuth tests passed!")
        print("\n📝 Next steps:")
        print("1. Replace YOUR_CLIENT_ID and YOUR_CLIENT_SECRET in oauth.py")
        print("2. Deploy to PyPI: python -m build && twine upload dist/*")
        print("3. Users can install with: uvx install datagen-gmail-mcp")
        print("4. Zero-setup experience: just add to Claude Desktop config!")
    else:
        print("\n⚠️  Some auto-OAuth tests failed. Please fix the issues.")

    return all(results)


if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)