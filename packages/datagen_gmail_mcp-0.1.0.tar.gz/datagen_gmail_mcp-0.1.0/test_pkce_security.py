#!/usr/bin/env python3
"""
Test script to verify PKCE security implementation.
This script tests that the OAuth flow works securely without client secrets.
"""

def test_no_client_secret_in_embedded_credentials():
    """Test that embedded credentials don't contain client_secret."""
    print("Testing embedded credentials security...")

    try:
        with open('gmail_mcp/auth/oauth.py', 'r') as f:
            content = f.read()

        # Verify client_secret is removed from embedded credentials
        lines = content.split('\n')
        in_embedded_creds = False
        has_client_secret = False

        for line in lines:
            if 'EMBEDDED_OAUTH_CREDENTIALS' in line:
                in_embedded_creds = True
            elif in_embedded_creds and line.strip() == '}':
                break
            elif in_embedded_creds and 'client_secret' in line:
                has_client_secret = True

        assert not has_client_secret, "client_secret found in embedded credentials"
        assert 'client_secret' not in content[content.find('EMBEDDED_OAUTH_CREDENTIALS'):content.find('EMBEDDED_OAUTH_CREDENTIALS') + 500], "client_secret found near embedded credentials"

        print("✅ No client secret in embedded credentials")
        return True

    except FileNotFoundError:
        print("❌ oauth.py file not found")
        return False
    except AssertionError as e:
        print(f"❌ Security check failed: {e}")
        return False

def test_pkce_code_generation():
    """Test PKCE code generation functions."""
    print("\nTesting PKCE code generation...")

    try:
        # Test PKCE code generation structure without importing MCP dependencies
        with open('gmail_mcp/auth/oauth.py', 'r') as f:
            content = f.read()

        # Check for PKCE implementation
        required_functions = [
            '_generate_pkce_codes',
            'code_verifier',
            'code_challenge',
            'secrets.token_bytes',
            'hashlib.sha256',
            'base64.urlsafe_b64encode'
        ]

        for func in required_functions:
            assert func in content, f"Missing PKCE component: {func}"

        # Check for PKCE parameters in OAuth flow
        pkce_params = [
            'code_challenge',
            'code_challenge_method',
            'code_verifier'
        ]

        for param in pkce_params:
            assert param in content, f"Missing PKCE parameter: {param}"

        print("✅ PKCE code generation properly implemented")
        return True

    except AssertionError as e:
        print(f"❌ PKCE implementation check failed: {e}")
        return False

def test_pkce_flow_integration():
    """Test that OAuth flows use PKCE correctly."""
    print("\nTesting PKCE flow integration...")

    try:
        with open('gmail_mcp/auth/oauth.py', 'r') as f:
            content = f.read()

        # Check automatic OAuth flow uses PKCE
        auto_flow_start = content.find('_run_automatic_oauth_flow')
        auto_flow_end = content.find('def _find_available_port', auto_flow_start)
        auto_flow_content = content[auto_flow_start:auto_flow_end]

        assert 'code_verifier, code_challenge = self._generate_pkce_codes()' in auto_flow_content, "Automatic flow doesn't generate PKCE codes"
        assert 'code_challenge=code_challenge' in auto_flow_content, "Automatic flow doesn't use code_challenge"
        assert 'code_verifier=code_verifier' in auto_flow_content, "Automatic flow doesn't use code_verifier"

        # Check legacy flow supports both public and confidential clients
        legacy_flow_start = content.find('_run_legacy_oauth_flow')
        legacy_flow_end = content.find('def _run_legacy_pkce_flow', legacy_flow_start)
        legacy_flow_content = content[legacy_flow_start:legacy_flow_end]

        assert 'is_public_client' in legacy_flow_content, "Legacy flow doesn't check for public clients"
        assert "'client_secret' not in creds_data['installed']" in legacy_flow_content, "Legacy flow doesn't detect public clients"

        print("✅ PKCE flow integration is correct")
        return True

    except AssertionError as e:
        print(f"❌ PKCE flow integration check failed: {e}")
        return False

def test_security_comments_and_documentation():
    """Test that security improvements are documented."""
    print("\nTesting security documentation...")

    try:
        with open('gmail_mcp/auth/oauth.py', 'r') as f:
            content = f.read()

        # Check for security-related comments
        security_indicators = [
            'PKCE for security',
            'public OAuth client',
            'no client secret needed',
            'PKCE flow for public client'
        ]

        found_indicators = []
        for indicator in security_indicators:
            if indicator in content:
                found_indicators.append(indicator)

        assert len(found_indicators) >= 2, f"Insufficient security documentation. Found: {found_indicators}"

        print(f"✅ Security documentation present: {found_indicators}")
        return True

    except AssertionError as e:
        print(f"❌ Security documentation check failed: {e}")
        return False

def test_imports_for_pkce():
    """Test that required imports for PKCE are present."""
    print("\nTesting PKCE imports...")

    try:
        with open('gmail_mcp/auth/oauth.py', 'r') as f:
            content = f.read()

        required_imports = [
            'import base64',
            'import hashlib',
            'import secrets'
        ]

        for imp in required_imports:
            assert imp in content, f"Missing import for PKCE: {imp}"

        print("✅ All required PKCE imports present")
        return True

    except AssertionError as e:
        print(f"❌ PKCE imports check failed: {e}")
        return False

def main():
    """Run all PKCE security tests."""
    print("Gmail MCP PKCE Security Validation")
    print("=" * 50)

    tests = [
        test_no_client_secret_in_embedded_credentials,
        test_imports_for_pkce,
        test_pkce_code_generation,
        test_pkce_flow_integration,
        test_security_comments_and_documentation,
    ]

    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test.__name__} failed with exception: {e}")
            results.append(False)

    print("\n" + "=" * 50)
    print("PKCE Security Validation Summary:")
    print(f"✅ Passed: {sum(results)}")
    print(f"❌ Failed: {len(results) - sum(results)}")
    print(f"📊 Total: {len(results)}")

    if all(results):
        print("\n🎉 All PKCE security tests passed!")
        print("\n🔒 Security Improvements Summary:")
        print("✅ Client secret removed from public package")
        print("✅ PKCE (Proof Key for Code Exchange) implemented")
        print("✅ Secure OAuth flow for public clients")
        print("✅ Support for both public and confidential clients")
        print("✅ SHA256-based code challenge generation")
        print("✅ Secure random code verifier generation")
        print("\n🚀 Package is now secure for PyPI deployment!")
        print("\n📝 Next steps:")
        print("1. Replace YOUR_CLIENT_ID in oauth.py with your public OAuth client ID")
        print("2. Configure Google OAuth app as 'Desktop Application' (public client)")
        print("3. Test OAuth flow manually")
        print("4. Deploy to PyPI with confidence!")
    else:
        print("\n⚠️  Some PKCE security tests failed. Please review implementation.")

    return all(results)

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)