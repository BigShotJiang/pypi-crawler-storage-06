"""Gmail API client wrapper with error handling and utilities."""

import base64
import email
import mimetypes
import os
import time
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any, Dict, List, Optional, Union

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.oauth2.credentials import Credentials

from .auth.oauth import GmailOAuth


class GmailClient:
    """Gmail API client with high-level operations."""

    def __init__(self, oauth_handler: Optional[GmailOAuth] = None):
        """Initialize Gmail client.

        Args:
            oauth_handler: OAuth handler for authentication
        """
        self.oauth = oauth_handler or GmailOAuth()
        self._service = None
        self._user_id = 'me'  # Use 'me' for authenticated user

    @property
    def service(self):
        """Get Gmail API service, initializing if needed."""
        if not self._service:
            credentials = self.oauth.get_credentials()
            self._service = build('gmail', 'v1', credentials=credentials)
        return self._service

    def _handle_api_error(self, error: HttpError) -> str:
        """Convert API errors to user-friendly messages."""
        error_details = error.error_details[0] if error.error_details else {}
        reason = error_details.get('reason', 'unknown')
        message = error_details.get('message', str(error))

        if error.resp.status == 400:
            return f"Bad request: {message}"
        elif error.resp.status == 401:
            return "Authentication failed. Please check your credentials."
        elif error.resp.status == 403:
            if 'quota' in reason.lower():
                return "API quota exceeded. Please try again later."
            return f"Permission denied: {message}"
        elif error.resp.status == 404:
            return "Resource not found."
        elif error.resp.status == 429:
            return "Rate limit exceeded. Please try again later."
        elif error.resp.status >= 500:
            return "Gmail server error. Please try again later."
        else:
            return f"API error: {message}"

    def _retry_with_backoff(self, func, *args, max_retries: int = 3, **kwargs):
        """Retry API calls with exponential backoff."""
        for attempt in range(max_retries):
            try:
                return func(*args, **kwargs)
            except HttpError as e:
                if e.resp.status == 429 and attempt < max_retries - 1:
                    # Rate limited, wait and retry
                    wait_time = (2 ** attempt) + 1
                    time.sleep(wait_time)
                    continue
                raise

    def list_messages(
        self,
        query: str = "",
        max_results: int = 10,
        page_token: Optional[str] = None,
        label_ids: Optional[List[str]] = None,
        include_spam_trash: bool = False
    ) -> Dict[str, Any]:
        """List messages with optional filtering.

        Args:
            query: Gmail search query (e.g., "from:user@example.com")
            max_results: Maximum number of messages to return
            page_token: Token for pagination
            label_ids: List of label IDs to filter by
            include_spam_trash: Whether to include spam and trash

        Returns:
            Dictionary with messages list and pagination info
        """
        try:
            result = self._retry_with_backoff(
                self.service.users().messages().list,
                userId=self._user_id,
                q=query,
                maxResults=max_results,
                pageToken=page_token,
                labelIds=label_ids,
                includeSpamTrash=include_spam_trash
            ).execute()

            messages = result.get('messages', [])
            return {
                'messages': messages,
                'next_page_token': result.get('nextPageToken'),
                'result_size_estimate': result.get('resultSizeEstimate', 0)
            }
        except HttpError as e:
            raise Exception(self._handle_api_error(e))

    def get_message(
        self,
        message_id: str,
        format: str = 'full',
        metadata_headers: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Get a specific message.

        Args:
            message_id: Gmail message ID
            format: Message format ('minimal', 'full', 'raw', 'metadata')
            metadata_headers: List of headers to include (for metadata format)

        Returns:
            Message data
        """
        try:
            result = self._retry_with_backoff(
                self.service.users().messages().get,
                userId=self._user_id,
                id=message_id,
                format=format,
                metadataHeaders=metadata_headers
            ).execute()

            # Parse the message for easier consumption
            parsed = self._parse_message(result)
            return parsed
        except HttpError as e:
            raise Exception(self._handle_api_error(e))

    def get_thread(self, thread_id: str, format: str = 'full') -> Dict[str, Any]:
        """Get an email thread.

        Args:
            thread_id: Gmail thread ID
            format: Message format for thread messages

        Returns:
            Thread data with parsed messages
        """
        try:
            result = self._retry_with_backoff(
                self.service.users().threads().get,
                userId=self._user_id,
                id=thread_id,
                format=format
            ).execute()

            # Parse all messages in the thread
            messages = []
            for message in result.get('messages', []):
                parsed = self._parse_message(message)
                messages.append(parsed)

            return {
                'id': result['id'],
                'snippet': result.get('snippet', ''),
                'history_id': result.get('historyId'),
                'messages': messages,
                'message_count': len(messages)
            }
        except HttpError as e:
            raise Exception(self._handle_api_error(e))

    def send_message(
        self,
        to: Union[str, List[str]],
        subject: str,
        body: str,
        cc: Optional[Union[str, List[str]]] = None,
        bcc: Optional[Union[str, List[str]]] = None,
        reply_to: Optional[str] = None,
        attachments: Optional[List[str]] = None,
        html: bool = False,
        thread_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Send an email message.

        Args:
            to: Recipient email address(es)
            subject: Email subject
            body: Email body content
            cc: CC recipients
            bcc: BCC recipients
            reply_to: Reply-to email address
            attachments: List of file paths to attach
            html: Whether body is HTML content
            thread_id: Thread ID for replies

        Returns:
            Sent message info
        """
        try:
            message = self._create_message(
                to=to,
                subject=subject,
                body=body,
                cc=cc,
                bcc=bcc,
                reply_to=reply_to,
                attachments=attachments,
                html=html
            )

            send_request = {
                'userId': self._user_id,
                'body': {'raw': message, 'threadId': thread_id} if thread_id else {'raw': message}
            }

            result = self._retry_with_backoff(
                self.service.users().messages().send,
                **send_request
            ).execute()

            return {
                'id': result['id'],
                'thread_id': result['threadId'],
                'label_ids': result.get('labelIds', [])
            }
        except HttpError as e:
            raise Exception(self._handle_api_error(e))

    def reply_to_message(
        self,
        message_id: str,
        body: str,
        html: bool = False,
        reply_all: bool = False
    ) -> Dict[str, Any]:
        """Reply to an existing message.

        Args:
            message_id: ID of message to reply to
            body: Reply body content
            html: Whether body is HTML
            reply_all: Whether to reply to all recipients

        Returns:
            Sent reply info
        """
        try:
            # Get original message to extract reply information
            original = self.get_message(message_id, format='full')

            # Extract reply details
            to_addresses = []
            cc_addresses = []

            # Add original sender to recipients
            if original.get('from'):
                to_addresses.append(original['from'])

            if reply_all:
                # Add original recipients
                if original.get('to'):
                    if isinstance(original['to'], list):
                        to_addresses.extend(original['to'])
                    else:
                        to_addresses.append(original['to'])

                if original.get('cc'):
                    if isinstance(original['cc'], list):
                        cc_addresses.extend(original['cc'])
                    else:
                        cc_addresses.append(original['cc'])

            # Create reply subject
            subject = original.get('subject', '')
            if not subject.lower().startswith('re:'):
                subject = f"Re: {subject}"

            # Send reply in the same thread
            return self.send_message(
                to=to_addresses,
                subject=subject,
                body=body,
                cc=cc_addresses if cc_addresses else None,
                html=html,
                thread_id=original.get('thread_id')
            )
        except HttpError as e:
            raise Exception(self._handle_api_error(e))

    def _parse_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Parse Gmail message for easier consumption."""
        result = {
            'id': message['id'],
            'thread_id': message['threadId'],
            'snippet': message.get('snippet', ''),
            'history_id': message.get('historyId'),
            'internal_date': message.get('internalDate'),
            'label_ids': message.get('labelIds', []),
            'size_estimate': message.get('sizeEstimate', 0)
        }

        # Parse headers
        if 'payload' in message and 'headers' in message['payload']:
            headers = {}
            for header in message['payload']['headers']:
                name = header['name'].lower()
                value = header['value']
                headers[name] = value

                # Extract common headers
                if name == 'from':
                    result['from'] = value
                elif name == 'to':
                    result['to'] = value
                elif name == 'cc':
                    result['cc'] = value
                elif name == 'bcc':
                    result['bcc'] = value
                elif name == 'subject':
                    result['subject'] = value
                elif name == 'date':
                    result['date'] = value

            result['headers'] = headers

        # Parse body
        if 'payload' in message:
            body_data = self._extract_body(message['payload'])
            result.update(body_data)

        return result

    def _extract_body(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Extract body content from message payload."""
        result = {
            'body_text': '',
            'body_html': '',
            'attachments': []
        }

        def decode_data(data: str) -> str:
            """Decode base64url encoded data."""
            try:
                return base64.urlsafe_b64decode(data).decode('utf-8')
            except Exception:
                return ''

        def process_part(part: Dict[str, Any]):
            """Process a message part."""
            mime_type = part.get('mimeType', '')

            if mime_type == 'text/plain':
                if 'data' in part.get('body', {}):
                    result['body_text'] = decode_data(part['body']['data'])
            elif mime_type == 'text/html':
                if 'data' in part.get('body', {}):
                    result['body_html'] = decode_data(part['body']['data'])
            elif part.get('filename'):
                # This is an attachment
                attachment_info = {
                    'filename': part['filename'],
                    'mime_type': mime_type,
                    'size': part.get('body', {}).get('size', 0),
                    'attachment_id': part.get('body', {}).get('attachmentId')
                }
                result['attachments'].append(attachment_info)

            # Process nested parts
            if 'parts' in part:
                for subpart in part['parts']:
                    process_part(subpart)

        # Start processing
        if 'parts' in payload:
            for part in payload['parts']:
                process_part(part)
        else:
            process_part(payload)

        return result

    def _create_message(
        self,
        to: Union[str, List[str]],
        subject: str,
        body: str,
        cc: Optional[Union[str, List[str]]] = None,
        bcc: Optional[Union[str, List[str]]] = None,
        reply_to: Optional[str] = None,
        attachments: Optional[List[str]] = None,
        html: bool = False
    ) -> str:
        """Create a MIME message for sending."""
        message = MIMEMultipart() if attachments else MIMEText(body, 'html' if html else 'plain')

        if isinstance(message, MIMEMultipart):
            message.attach(MIMEText(body, 'html' if html else 'plain'))

        # Set headers
        message['to'] = ','.join(to) if isinstance(to, list) else to
        message['subject'] = subject

        if cc:
            message['cc'] = ','.join(cc) if isinstance(cc, list) else cc
        if bcc:
            message['bcc'] = ','.join(bcc) if isinstance(bcc, list) else bcc
        if reply_to:
            message['reply-to'] = reply_to

        # Add attachments
        if attachments and isinstance(message, MIMEMultipart):
            for file_path in attachments:
                if os.path.exists(file_path):
                    content_type, encoding = mimetypes.guess_type(file_path)

                    if content_type is None or encoding is not None:
                        content_type = 'application/octet-stream'

                    main_type, sub_type = content_type.split('/', 1)

                    with open(file_path, 'rb') as fp:
                        if main_type == 'text':
                            attachment = MIMEText(fp.read().decode(), _subtype=sub_type)
                        elif main_type == 'image':
                            attachment = MIMEImage(fp.read(), _subtype=sub_type)
                        elif main_type == 'audio':
                            attachment = MIMEAudio(fp.read(), _subtype=sub_type)
                        else:
                            attachment = MIMEBase(main_type, sub_type)
                            attachment.set_payload(fp.read())

                    attachment.add_header(
                        'Content-Disposition',
                        'attachment',
                        filename=os.path.basename(file_path)
                    )
                    message.attach(attachment)

        # Encode message
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
        return raw_message

    def search_messages(
        self,
        query: str,
        max_results: int = 50
    ) -> List[Dict[str, Any]]:
        """Search messages and return full message data.

        Args:
            query: Gmail search query
            max_results: Maximum number of results

        Returns:
            List of parsed messages
        """
        try:
            # Get message IDs from search
            search_result = self.list_messages(query=query, max_results=max_results)
            messages = []

            # Get full message data for each result
            for msg_ref in search_result['messages']:
                try:
                    full_message = self.get_message(msg_ref['id'])
                    messages.append(full_message)
                except Exception as e:
                    # Skip messages that can't be retrieved
                    continue

            return messages
        except HttpError as e:
            raise Exception(self._handle_api_error(e))