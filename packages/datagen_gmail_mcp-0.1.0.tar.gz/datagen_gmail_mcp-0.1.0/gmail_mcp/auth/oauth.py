"""OAuth 2.0 authentication for Gmail API."""

import base64
import hashlib
import json
import os
import pickle
import secrets
import socket
import threading
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse, parse_qs

from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import Flow, InstalledAppFlow
from google.oauth2.credentials import Credentials


# Embedded OAuth credentials for centralized authentication
# Note: Google requires a client_secret even for PKCE flows (non-standard behavior)
# For desktop applications, Google treats client_secret as "not secret" per their documentation
# PKCE provides the actual security through code_challenge/code_verifier parameters
EMBEDDED_OAUTH_CREDENTIALS = {
    "installed": {
        "client_id": "135436440459-r1rb7ojeaklj0l8dgvvtd2rfgst4pms3.apps.googleusercontent.com",
        "client_secret": "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",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "redirect_uris": ["http://localhost"]
    }
}


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP request handler for OAuth callback."""

    def do_GET(self):
        """Handle GET request with OAuth callback."""
        # Parse the authorization code from the callback URL
        parsed_url = urlparse(self.path)
        query_params = parse_qs(parsed_url.query)

        if 'code' in query_params:
            # Store the authorization code for the main thread
            self.server.auth_code = query_params['code'][0]
            self.server.auth_success = True

            # Send success response to browser
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b"""
            <html>
                <head><title>Gmail MCP Server - Authentication Complete</title></head>
                <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
                    <h1>&#x2705; Authentication Successful!</h1>
                    <p>You have successfully authenticated with Gmail.</p>
                    <p>You can now close this window and return to Claude Desktop.</p>
                    <script>
                        setTimeout(function() { window.close(); }, 3000);
                    </script>
                </body>
            </html>
            """)
        elif 'error' in query_params:
            # Handle OAuth error (user denied permission)
            self.server.auth_success = False
            self.server.auth_error = query_params.get('error', ['unknown'])[0]

            self.send_response(400)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b"""
            <html>
                <head><title>Gmail MCP Server - Authentication Failed</title></head>
                <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
                    <h1>&#x274C; Authentication Failed</h1>
                    <p>You denied access to Gmail or an error occurred.</p>
                    <p>Gmail MCP Server requires access to function properly.</p>
                    <p>You can close this window and try again later.</p>
                </body>
            </html>
            """)

    def log_message(self, format, *args):
        """Suppress HTTP server logs."""
        pass


class GmailOAuth:
    """Handles OAuth 2.0 authentication for Gmail API."""

    # Gmail API scopes
    # Note: Google automatically adds 'openid', 'userinfo.profile', 'userinfo.email'
    # and sometimes 'gmail.compose' to OAuth grants for desktop applications
    SCOPES = {
        'readonly': ['https://www.googleapis.com/auth/gmail.readonly'],
        'send': ['https://www.googleapis.com/auth/gmail.send'],
        'modify': ['https://www.googleapis.com/auth/gmail.modify'],
        'labels': ['https://www.googleapis.com/auth/gmail.labels'],
        'full': [
            # Core Gmail API scopes we need
            'https://www.googleapis.com/auth/gmail.readonly',
            'https://www.googleapis.com/auth/gmail.send',
            'https://www.googleapis.com/auth/gmail.modify',
            'https://www.googleapis.com/auth/gmail.labels',
            # Additional scopes that Google typically grants automatically
            # 'https://www.googleapis.com/auth/gmail.compose',
            # 'https://www.googleapis.com/auth/userinfo.email',
            # 'https://www.googleapis.com/auth/userinfo.profile',
            # 'openid'
        ]
    }

    def __init__(
        self,
        credentials_path: Optional[str] = None,
        token_dir: Optional[str] = None,
        scopes: Optional[List[str]] = None,
        use_embedded_credentials: bool = True
    ):
        """Initialize Gmail OAuth handler.

        Args:
            credentials_path: Path to OAuth 2.0 credentials JSON file (legacy)
            token_dir: Directory to store access tokens (defaults to ~/.gmail-mcp)
            scopes: List of Gmail API scopes (defaults to full access)
            use_embedded_credentials: Whether to use embedded OAuth credentials (recommended)
        """
        self.use_embedded_credentials = use_embedded_credentials

        if use_embedded_credentials:
            self.credentials_data = EMBEDDED_OAUTH_CREDENTIALS
            self.credentials_path = None
        else:
            # Legacy mode: use provided credentials file
            self.credentials_path = credentials_path or self._find_credentials()
            self.credentials_data = None

        self.token_dir = Path(token_dir or Path.home() / '.gmail-mcp')
        self.token_file = self.token_dir / 'token.pickle'
        self.scopes = scopes or self.SCOPES['full']

        # Ensure token directory exists
        self.token_dir.mkdir(exist_ok=True)

        self._credentials: Optional[Credentials] = None

    def _find_credentials(self) -> str:
        """Find OAuth credentials file in common locations."""
        possible_paths = [
            os.environ.get('GMAIL_CREDENTIALS_PATH'),
            os.environ.get('GOOGLE_CREDENTIALS_PATH'),
            'credentials.json',
            str(Path.home() / '.gmail-mcp' / 'credentials.json'),
            str(Path.home() / '.config' / 'gmail-mcp' / 'credentials.json'),
        ]

        for path in possible_paths:
            if path and Path(path).exists():
                return path

        raise FileNotFoundError(
            "Gmail OAuth credentials not found. Please provide credentials.json file. "
            "You can download it from Google Cloud Console > APIs & Services > Credentials."
        )

    def _load_saved_credentials(self) -> Optional[Credentials]:
        """Load saved credentials from token file."""
        if not self.token_file.exists():
            return None

        try:
            with open(self.token_file, 'rb') as token:
                credentials = pickle.load(token)
                if credentials and credentials.valid:
                    return credentials
                elif credentials and credentials.expired and credentials.refresh_token:
                    try:
                        credentials.refresh(Request())
                        self._save_credentials(credentials)
                        return credentials
                    except Exception as e:
                        print(f"Failed to refresh token: {e}")
                        return None
        except Exception as e:
            print(f"Failed to load saved credentials: {e}")

        return None

    def _save_credentials(self, credentials: Credentials) -> None:
        """Save credentials to token file."""
        try:
            with open(self.token_file, 'wb') as token:
                pickle.dump(credentials, token)
        except Exception as e:
            print(f"Failed to save credentials: {e}")

    def _run_oauth_flow(self) -> Credentials:
        """Run the OAuth 2.0 authorization flow."""
        if self.use_embedded_credentials:
            return self._run_automatic_oauth_flow()
        else:
            return self._run_legacy_oauth_flow()

    def _run_legacy_oauth_flow(self) -> Credentials:
        """Run OAuth flow using user-provided credentials file (legacy mode)."""
        if not Path(self.credentials_path).exists():
            raise FileNotFoundError(f"Credentials file not found: {self.credentials_path}")

        # Check if credentials file has client_secret (confidential client) or not (public client)
        try:
            with open(self.credentials_path, 'r') as f:
                creds_data = json.load(f)

            # Determine if this is a public client (no client_secret)
            is_public_client = (
                'installed' in creds_data and
                'client_secret' not in creds_data['installed']
            )

            if is_public_client:
                # Use PKCE flow for public clients
                return self._run_legacy_pkce_flow(creds_data)
            else:
                # Use traditional flow for confidential clients
                flow = InstalledAppFlow.from_client_secrets_file(
                    self.credentials_path,
                    self.scopes
                )

                # Use local server for OAuth flow
                credentials = flow.run_local_server(
                    port=0,
                    prompt='select_account',
                    authorization_prompt_message='Please visit this URL to authorize this application: {url}',
                    success_message='The auth flow is complete; you may close this window.',
                    open_browser=True
                )

                self._save_credentials(credentials)
                return credentials

        except Exception as e:
            raise Exception(f"Failed to process credentials file: {e}")

    def _run_legacy_pkce_flow(self, creds_data: Dict[str, Any]) -> Credentials:
        """Run PKCE OAuth flow for legacy public client credentials."""
        print("🔐 Using PKCE flow for public client credentials...")

        # Generate PKCE codes
        code_verifier, code_challenge = self._generate_pkce_codes()

        # Find an available port for callback
        callback_port = self._find_available_port()
        redirect_uri = f"http://localhost:{callback_port}"

        # Update redirect URI in credentials
        creds_data["installed"]["redirect_uris"] = [redirect_uri]

        # Create OAuth flow
        flow = Flow.from_client_config(
            creds_data,
            scopes=self.scopes,
            redirect_uri=redirect_uri
        )

        # Get authorization URL with PKCE
        auth_url, _ = flow.authorization_url(
            access_type='offline',
            include_granted_scopes='true',
            prompt='select_account',
            code_challenge=code_challenge,
            code_challenge_method='S256'
        )

        # Start callback server
        callback_server = HTTPServer(('localhost', callback_port), OAuthCallbackHandler)
        callback_server.auth_code = None
        callback_server.auth_success = False
        callback_server.auth_error = None

        # Start server in background thread
        server_thread = threading.Thread(target=callback_server.serve_forever, daemon=True)
        server_thread.start()

        try:
            # Open browser
            print(f"🌐 If your browser doesn't open automatically, visit: {auth_url}")
            webbrowser.open(auth_url)

            # Wait for callback
            import time
            timeout = 300  # 5 minutes
            start_time = time.time()

            while time.time() - start_time < timeout:
                if callback_server.auth_success:
                    break
                elif hasattr(callback_server, 'auth_error') and callback_server.auth_error:
                    raise Exception(f"OAuth failed: {callback_server.auth_error}")
                time.sleep(1)

            if not callback_server.auth_success:
                raise Exception("OAuth timeout - please try again")

            # Exchange code for credentials using PKCE
            flow.fetch_token(
                code=callback_server.auth_code,
                code_verifier=code_verifier
            )
            credentials = flow.credentials

            self._save_credentials(credentials)
            print("✅ Authentication successful!")

            return credentials

        finally:
            # Clean up server
            callback_server.shutdown()

    def _run_automatic_oauth_flow(self) -> Credentials:
        """Run OAuth flow using embedded credentials with PKCE for security."""
        print("🔐 Gmail authentication required...")
        print("📱 Opening browser for Gmail authentication...")

        # Generate PKCE codes for security
        code_verifier, code_challenge = self._generate_pkce_codes()

        # Find an available port for our callback server
        callback_port = self._find_available_port()
        redirect_uri = f"http://localhost:{callback_port}"

        # Update redirect URI in credentials
        self.credentials_data["installed"]["redirect_uris"] = [redirect_uri]

        # Create OAuth flow from embedded credentials
        flow = Flow.from_client_config(
            self.credentials_data,
            scopes=self.scopes,
            redirect_uri=redirect_uri
        )

        # Get authorization URL with PKCE parameters
        auth_url, _ = flow.authorization_url(
            access_type='offline',
            include_granted_scopes='true',
            prompt='select_account',
            code_challenge=code_challenge,
            code_challenge_method='S256'
        )

        # Start callback server
        callback_server = HTTPServer(('localhost', callback_port), OAuthCallbackHandler)
        callback_server.auth_code = None
        callback_server.auth_success = False
        callback_server.auth_error = None

        # Start server in background thread
        server_thread = threading.Thread(target=callback_server.serve_forever, daemon=True)
        server_thread.start()

        try:
            # Open browser
            print(f"🌐 If your browser doesn't open automatically, visit: {auth_url}")
            webbrowser.open(auth_url)

            # Wait for callback (with timeout)
            import time
            timeout = 300  # 5 minutes
            start_time = time.time()

            while time.time() - start_time < timeout:
                if callback_server.auth_success:
                    break
                elif hasattr(callback_server, 'auth_error') and callback_server.auth_error:
                    raise Exception(f"OAuth failed: {callback_server.auth_error}")
                time.sleep(1)

            if not callback_server.auth_success:
                raise Exception("OAuth timeout - please try again")

            # Exchange authorization code for credentials using PKCE
            flow.fetch_token(
                code=callback_server.auth_code,
                code_verifier=code_verifier
            )
            credentials = flow.credentials

            self._save_credentials(credentials)
            print("✅ Authentication successful!")

            return credentials

        finally:
            # Clean up server
            callback_server.shutdown()

    def _find_available_port(self) -> int:
        """Find an available port for the OAuth callback server."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('localhost', 0))
            return s.getsockname()[1]

    def _generate_pkce_codes(self) -> tuple[str, str]:
        """Generate PKCE code verifier and code challenge.

        Returns:
            Tuple of (code_verifier, code_challenge)
        """
        # Generate code verifier (43-128 characters, URL-safe)
        code_verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('utf-8').rstrip('=')

        # Generate code challenge (SHA256 hash of code verifier, base64url encoded)
        code_challenge = base64.urlsafe_b64encode(
            hashlib.sha256(code_verifier.encode('utf-8')).digest()
        ).decode('utf-8').rstrip('=')

        return code_verifier, code_challenge

    def get_credentials(self, force_refresh: bool = False, silent: bool = False) -> Credentials:
        """Get valid Gmail API credentials.

        Args:
            force_refresh: Force a new OAuth flow even if saved credentials exist
            silent: If True, don't print status messages (for background operations)

        Returns:
            Valid Google OAuth credentials

        Raises:
            Exception: If authentication fails
        """
        if force_refresh or not self._credentials:
            # Try to load saved credentials first
            if not force_refresh:
                self._credentials = self._load_saved_credentials()

            # If no valid saved credentials, run OAuth flow
            if not self._credentials:
                if not silent:
                    if self.use_embedded_credentials:
                        print("🔐 Gmail MCP Server requires authentication with your Gmail account.")
                    else:
                        print("Gmail authentication required. Opening browser...")

                self._credentials = self._run_oauth_flow()

                if not silent and self.use_embedded_credentials:
                    print("🎉 Gmail MCP Server is ready to use!")

        if not self._credentials or not self._credentials.valid:
            raise Exception("Failed to obtain valid Gmail credentials")

        return self._credentials

    def is_authenticated(self) -> bool:
        """Check if user is currently authenticated without triggering OAuth flow.

        Returns:
            True if valid credentials exist, False otherwise
        """
        try:
            # Try to load saved credentials
            saved_creds = self._load_saved_credentials()
            return saved_creds is not None and saved_creds.valid
        except Exception:
            return False

    def needs_authentication(self) -> bool:
        """Check if authentication is needed.

        Returns:
            True if authentication is required, False if user is already authenticated
        """
        return not self.is_authenticated()

    def revoke_credentials(self) -> None:
        """Revoke and delete saved credentials."""
        if self.token_file.exists():
            try:
                # Try to revoke the token
                if self._credentials:
                    self._credentials.revoke(Request())
            except Exception:
                pass  # Ignore revocation errors

            # Delete the token file
            self.token_file.unlink()
            self._credentials = None
            print("Credentials revoked and deleted.")

    def get_auth_status(self) -> Dict[str, Any]:
        """Get current authentication status.

        Returns:
            Dictionary with authentication status information
        """
        status = {
            'authenticated': False,
            'token_file_exists': self.token_file.exists(),
            'credentials_file_exists': Path(self.credentials_path).exists() if self.credentials_path else False,
            'use_embedded_credentials': self.use_embedded_credentials,
            'scopes': self.scopes,
            'token_valid': False,
            'token_expired': False,
            'has_refresh_token': False
        }

        try:
            credentials = self._load_saved_credentials()
            if credentials:
                status['authenticated'] = credentials.valid
                status['token_valid'] = credentials.valid
                status['token_expired'] = credentials.expired
                status['has_refresh_token'] = bool(credentials.refresh_token)
        except Exception:
            pass

        return status

    @classmethod
    def setup_credentials_interactive(cls) -> str:
        """Interactive setup for OAuth credentials.

        Returns:
            Path to the saved credentials file
        """
        print("\n=== Gmail MCP Server Setup ===")
        print("To use Gmail MCP server, you need to set up OAuth 2.0 credentials.")
        print("\nSteps:")
        print("1. Go to Google Cloud Console (https://console.cloud.google.com/)")
        print("2. Create a new project or select existing one")
        print("3. Enable Gmail API")
        print("4. Go to 'Credentials' and create 'OAuth 2.0 Client ID'")
        print("5. Choose 'Desktop application'")
        print("6. Download the JSON file")

        credentials_path = input("\nEnter path to your credentials.json file: ").strip()

        if not Path(credentials_path).exists():
            raise FileNotFoundError(f"File not found: {credentials_path}")

        # Verify it's a valid credentials file
        try:
            with open(credentials_path, 'r') as f:
                creds_data = json.load(f)
                if 'installed' not in creds_data and 'web' not in creds_data:
                    raise ValueError("Invalid credentials file format")
        except Exception as e:
            raise ValueError(f"Invalid credentials file: {e}")

        # Copy to standard location
        config_dir = Path.home() / '.gmail-mcp'
        config_dir.mkdir(exist_ok=True)
        target_path = config_dir / 'credentials.json'

        import shutil
        shutil.copy2(credentials_path, target_path)

        print(f"\nCredentials saved to: {target_path}")
        print("Setup complete! You can now run the Gmail MCP server.")

        return str(target_path)