"""Gmail MCP Server - Main server implementation."""

import asyncio
import logging
import os
import sys
from typing import Any, Dict, List, Optional

from mcp.server import Server
from mcp.types import Resource, Tool, TextContent, LoggingLevel, TextResourceContents, ReadResourceResult
from mcp.server.stdio import stdio_server

from .auth.oauth import GmailOAuth
from .gmail_client import GmailClient
from .tools.read_tools import ReadTools
from .tools.send_tools import SendTools
from .tools.label_tools import LabelTools


class GmailMCPServer:
    """Gmail MCP Server for integrating Gmail with AI assistants."""

    def __init__(self, credentials_path: Optional[str] = None, token_dir: Optional[str] = None):
        """Initialize Gmail MCP Server.

        Args:
            credentials_path: Path to OAuth credentials file
            token_dir: Directory to store access tokens
        """
        self.server = Server("gmail-mcp")
        self.oauth_handler = None
        self.gmail_client = None
        self.credentials_path = credentials_path
        self.token_dir = token_dir

        # Initialize components
        self._setup_logging()
        self._register_handlers()
        self._register_tools_early()

    def _setup_logging(self) -> None:
        """Set up logging for the server."""
        log_level = os.environ.get('GMAIL_MCP_LOG_LEVEL', 'INFO').upper()
        logging.basicConfig(
            level=getattr(logging, log_level, logging.INFO),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def _register_handlers(self) -> None:
        """Register MCP server handlers."""

        @self.server.list_resources()
        async def list_resources() -> List[Resource]:
            """List available resources."""
            return [
                Resource(
                    uri="gmail://info",
                    name="Gmail Account Info",
                    description="Information about the connected Gmail account",
                    mimeType="text/plain"
                ),
                Resource(
                    uri="gmail://auth-status",
                    name="Authentication Status",
                    description="Current authentication status and configuration",
                    mimeType="application/json"
                )
            ]

        @self.server.read_resource()
        async def read_resource(uri: str) -> str:
            """Read a specific resource."""
            self.logger.info(f"Resource read request for URI: {uri}")
            self.logger.info(f"URI type: {type(uri)}, URI repr: {repr(uri)}")

            # Convert AnyUrl to string for comparison
            uri_str = str(uri)
            self.logger.info(f"URI as string: {uri_str}")

            if uri_str == "gmail://info":
                self.logger.info("Matched gmail://info URI")
                try:
                    self.logger.info("Starting authentication for gmail://info")
                    await self._ensure_authenticated()
                    self.logger.info("Authentication completed successfully")

                    # Get user profile information
                    self.logger.info("Calling Gmail API for profile")
                    profile = self.gmail_client.service.users().getProfile(userId='me').execute()
                    self.logger.info("Gmail profile retrieved successfully")

                    content = f"Gmail Account: {profile.get('emailAddress', 'Unknown')}\n" \
                             f"Messages Total: {profile.get('messagesTotal', 'Unknown')}\n" \
                             f"Threads Total: {profile.get('threadsTotal', 'Unknown')}\n" \
                             f"History ID: {profile.get('historyId', 'Unknown')}"
                    return content
                except Exception as e:
                    self.logger.error(f"Error in gmail://info handler: {str(e)}", exc_info=True)
                    return f"Error getting Gmail account info: {str(e)}"

            elif uri_str == "gmail://auth-status":
                self.logger.info("Matched gmail://auth-status URI")
                try:
                    status = self.oauth_handler.get_auth_status() if self.oauth_handler else {}
                    import json
                    content = json.dumps(status, indent=2)
                    self.logger.info("Auth status retrieved successfully")
                    return content
                except Exception as e:
                    self.logger.error(f"Error in gmail://auth-status handler: {str(e)}", exc_info=True)
                    return f"Error getting authentication status: {str(e)}"

            else:
                self.logger.warning(f"No handler found for URI: {uri_str}")
                return f"Unknown resource: {uri_str}"

        @self.server.list_tools()
        async def list_tools() -> List[Tool]:
            """List available tools."""
            try:
                # Return all available tools (authentication happens when tools are called)
                tools = [
                    # Reading tools
                    Tool(
                        name="list_messages",
                        description="List Gmail messages with optional filtering using Gmail search syntax",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "query": {
                                    "type": "string",
                                    "description": "Gmail search query (e.g., 'from:user@example.com', 'subject:meeting', 'is:unread')",
                                    "default": ""
                                },
                                "max_results": {
                                    "type": "integer",
                                    "description": "Maximum number of messages to return (1-100)",
                                    "minimum": 1,
                                    "maximum": 100,
                                    "default": 10
                                },
                                "include_spam_trash": {
                                    "type": "boolean",
                                    "description": "Whether to include spam and trash messages",
                                    "default": False
                                },
                                "label_ids": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                    "description": "List of label IDs to filter by (e.g., ['INBOX', 'IMPORTANT'])"
                                }
                            }
                        }
                    ),
                    Tool(
                        name="get_message",
                        description="Get the full content of a specific Gmail message including headers and attachments",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "message_id": {
                                    "type": "string",
                                    "description": "The Gmail message ID"
                                },
                                "include_headers": {
                                    "type": "boolean",
                                    "description": "Whether to include all email headers",
                                    "default": False
                                },
                                "include_attachments": {
                                    "type": "boolean",
                                    "description": "Whether to include attachment information",
                                    "default": True
                                }
                            },
                            "required": ["message_id"]
                        }
                    ),
                    Tool(
                        name="search_messages",
                        description="Search Gmail messages using advanced Gmail search queries",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "query": {
                                    "type": "string",
                                    "description": "Gmail search query (e.g., 'from:boss@company.com subject:urgent', 'has:attachment newer_than:7d')"
                                },
                                "max_results": {
                                    "type": "integer",
                                    "description": "Maximum number of results to return (1-50)",
                                    "minimum": 1,
                                    "maximum": 50,
                                    "default": 20
                                },
                                "full_content": {
                                    "type": "boolean",
                                    "description": "Whether to return full message content or just summaries",
                                    "default": False
                                }
                            },
                            "required": ["query"]
                        }
                    ),
                    Tool(
                        name="get_thread",
                        description="Get an entire email thread/conversation with all messages",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "thread_id": {
                                    "type": "string",
                                    "description": "The Gmail thread ID"
                                },
                                "max_messages": {
                                    "type": "integer",
                                    "description": "Maximum number of messages to include from the thread",
                                    "minimum": 1,
                                    "default": 10
                                }
                            },
                            "required": ["thread_id"]
                        }
                    ),
                    Tool(
                        name="get_unread_count",
                        description="Get the count of unread messages in the inbox",
                        inputSchema={
                            "type": "object",
                            "properties": {}
                        }
                    ),

                    # Sending tools
                    Tool(
                        name="send_email",
                        description="Send a new email message with optional attachments",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "to": {
                                    "type": "string",
                                    "description": "Recipient email address(es), comma-separated"
                                },
                                "subject": {
                                    "type": "string",
                                    "description": "Email subject line"
                                },
                                "body": {
                                    "type": "string",
                                    "description": "Email message body (plain text)"
                                },
                                "cc": {
                                    "type": "string",
                                    "description": "CC recipients, comma-separated (optional)"
                                },
                                "bcc": {
                                    "type": "string",
                                    "description": "BCC recipients, comma-separated (optional)"
                                },
                                "reply_to": {
                                    "type": "string",
                                    "description": "Reply-to email address (optional)"
                                }
                            },
                            "required": ["to", "subject", "body"]
                        }
                    ),
                    Tool(
                        name="reply_to_email",
                        description="Reply to an existing email message",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "message_id": {
                                    "type": "string",
                                    "description": "ID of the message to reply to"
                                },
                                "body": {
                                    "type": "string",
                                    "description": "Reply message body"
                                },
                                "reply_all": {
                                    "type": "boolean",
                                    "description": "Whether to reply to all recipients",
                                    "default": False
                                }
                            },
                            "required": ["message_id", "body"]
                        }
                    ),
                    Tool(
                        name="forward_email",
                        description="Forward an existing email message to new recipients",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "message_id": {
                                    "type": "string",
                                    "description": "ID of the message to forward"
                                },
                                "to": {
                                    "type": "string",
                                    "description": "New recipient email address(es), comma-separated"
                                },
                                "body": {
                                    "type": "string",
                                    "description": "Additional message to add before forwarded content",
                                    "default": ""
                                }
                            },
                            "required": ["message_id", "to"]
                        }
                    ),
                    Tool(
                        name="send_html_email",
                        description="Send an HTML formatted email message",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "to": {
                                    "type": "string",
                                    "description": "Recipient email address(es), comma-separated"
                                },
                                "subject": {
                                    "type": "string",
                                    "description": "Email subject line"
                                },
                                "html_body": {
                                    "type": "string",
                                    "description": "Email message body in HTML format"
                                },
                                "cc": {
                                    "type": "string",
                                    "description": "CC recipients, comma-separated (optional)"
                                },
                                "bcc": {
                                    "type": "string",
                                    "description": "BCC recipients, comma-separated (optional)"
                                }
                            },
                            "required": ["to", "subject", "html_body"]
                        }
                    ),
                    Tool(
                        name="send_email_with_attachment",
                        description="Send an email with a single file attachment",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "to": {
                                    "type": "string",
                                    "description": "Recipient email address(es), comma-separated"
                                },
                                "subject": {
                                    "type": "string",
                                    "description": "Email subject line"
                                },
                                "body": {
                                    "type": "string",
                                    "description": "Email message body (plain text)"
                                },
                                "attachment_path": {
                                    "type": "string",
                                    "description": "Path to the file to attach"
                                },
                                "attachment_name": {
                                    "type": "string",
                                    "description": "Name for the attachment (optional, uses filename if not provided)"
                                }
                            },
                            "required": ["to", "subject", "body", "attachment_path"]
                        }
                    ),
                    Tool(
                        name="draft_email",
                        description="Validate email parameters without sending (draft mode)",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "to": {
                                    "type": "string",
                                    "description": "Recipient email address(es), comma-separated"
                                },
                                "subject": {
                                    "type": "string",
                                    "description": "Email subject line"
                                },
                                "body": {
                                    "type": "string",
                                    "description": "Email message body"
                                }
                            },
                            "required": ["to", "subject", "body"]
                        }
                    ),

                    # Label tools
                    Tool(
                        name="list_labels",
                        description="List all Gmail labels (system and user-created)",
                        inputSchema={
                            "type": "object",
                            "properties": {}
                        }
                    ),
                    Tool(
                        name="create_label",
                        description="Create a new Gmail label",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "name": {
                                    "type": "string",
                                    "description": "Name for the new label"
                                },
                                "label_list_visibility": {
                                    "type": "string",
                                    "enum": ["labelShow", "labelHide"],
                                    "description": "Whether the label is shown in the label list",
                                    "default": "labelShow"
                                },
                                "message_list_visibility": {
                                    "type": "string",
                                    "enum": ["show", "hide"],
                                    "description": "Whether the label is shown in the message list",
                                    "default": "show"
                                }
                            },
                            "required": ["name"]
                        }
                    ),
                    Tool(
                        name="delete_label",
                        description="Delete a user-created Gmail label",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "label_id": {
                                    "type": "string",
                                    "description": "ID of the label to delete"
                                }
                            },
                            "required": ["label_id"]
                        }
                    ),
                    Tool(
                        name="add_label_to_message",
                        description="Add one or more labels to a message",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "message_id": {
                                    "type": "string",
                                    "description": "ID of the message to label"
                                },
                                "label_ids": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                    "description": "List of label IDs to add to the message"
                                }
                            },
                            "required": ["message_id", "label_ids"]
                        }
                    ),
                    Tool(
                        name="remove_label_from_message",
                        description="Remove one or more labels from a message",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "message_id": {
                                    "type": "string",
                                    "description": "ID of the message to modify"
                                },
                                "label_ids": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                    "description": "List of label IDs to remove from the message"
                                }
                            },
                            "required": ["message_id", "label_ids"]
                        }
                    ),
                    Tool(
                        name="get_label_details",
                        description="Get detailed information about a specific label",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "label_id": {
                                    "type": "string",
                                    "description": "ID of the label to get details for"
                                }
                            },
                            "required": ["label_id"]
                        }
                    ),
                    Tool(
                        name="messages_with_label",
                        description="Get messages that have a specific label",
                        inputSchema={
                            "type": "object",
                            "properties": {
                                "label_id": {
                                    "type": "string",
                                    "description": "ID of the label to search for"
                                },
                                "max_results": {
                                    "type": "integer",
                                    "description": "Maximum number of messages to return",
                                    "minimum": 1,
                                    "maximum": 100,
                                    "default": 10
                                }
                            },
                            "required": ["label_id"]
                        }
                    ),
                ]

                return tools
            except Exception as e:
                self.logger.error(f"Error listing tools: {e}")
                return []

    async def _ensure_authenticated(self) -> None:
        """Ensure Gmail client is authenticated and ready."""
        if self.gmail_client is None:
            try:
                # Initialize OAuth handler with embedded credentials by default
                self.oauth_handler = GmailOAuth(
                    credentials_path=self.credentials_path,
                    token_dir=self.token_dir,
                    use_embedded_credentials=self.credentials_path is None
                )

                # Check if authentication is needed
                if self.oauth_handler.needs_authentication():
                    self.logger.info("Gmail authentication required - starting OAuth flow")

                    # For MCP servers, we need to handle OAuth gracefully
                    try:
                        # Get credentials (this will trigger OAuth if needed)
                        self.oauth_handler.get_credentials()
                    except Exception as auth_error:
                        self.logger.error(f"OAuth authentication failed: {auth_error}")

                        # Provide helpful error message for MCP context
                        if "OAuth timeout" in str(auth_error) or "OAuth failed" in str(auth_error):
                            raise Exception(
                                "Gmail authentication required. The Gmail MCP server needs access to your Gmail account. "
                                "Please run 'gmail-mcp-server --setup' manually to complete authentication, "
                                "then restart Claude Desktop."
                            )
                        else:
                            raise Exception(f"Gmail authentication failed: {auth_error}")

                # Initialize Gmail client
                self.gmail_client = GmailClient(self.oauth_handler)

                # Test authentication by getting profile
                profile = self.gmail_client.service.users().getProfile(userId='me').execute()
                self.logger.info(f"Gmail MCP Server authenticated as: {profile.get('emailAddress', 'Unknown')}")

                # Initialize tool instances now that we're authenticated
                self._initialize_tool_instances()

            except Exception as e:
                # Log the detailed error for debugging
                self.logger.error(f"Gmail MCP Server initialization failed: {e}")

                # Re-raise with user-friendly message
                if "authentication" in str(e).lower():
                    raise Exception(str(e))  # Pass through authentication errors as-is
                else:
                    raise Exception(f"Gmail MCP Server setup failed: {e}")

    def _register_tools_early(self) -> None:
        """Register tool handlers early (before authentication)."""
        # Register call_tool handler
        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: dict) -> list[TextContent]:
            """Handle tool calls from the MCP client."""
            try:
                # Ensure authentication before any tool call
                await self._ensure_authenticated()
                # Reading tools
                if name == "list_messages":
                    return await self.read_tools.list_messages(
                        query=arguments.get("query", ""),
                        max_results=arguments.get("max_results", 10),
                        include_spam_trash=arguments.get("include_spam_trash", False),
                        label_ids=arguments.get("label_ids")
                    )
                elif name == "get_message":
                    return await self.read_tools.get_message(
                        message_id=arguments["message_id"],
                        include_headers=arguments.get("include_headers", False),
                        include_attachments=arguments.get("include_attachments", True)
                    )
                elif name == "search_messages":
                    return await self.read_tools.search_messages(
                        query=arguments["query"],
                        max_results=arguments.get("max_results", 20),
                        full_content=arguments.get("full_content", False)
                    )
                elif name == "get_thread":
                    return await self.read_tools.get_thread(
                        thread_id=arguments["thread_id"],
                        max_messages=arguments.get("max_messages", 10)
                    )
                elif name == "get_unread_count":
                    return await self.read_tools.get_unread_count()

                # Sending tools
                elif name == "send_email":
                    return await self.send_tools.send_email(
                        to=arguments["to"],
                        subject=arguments["subject"],
                        body=arguments["body"],
                        cc=arguments.get("cc"),
                        bcc=arguments.get("bcc"),
                        reply_to=arguments.get("reply_to")
                    )
                elif name == "reply_to_email":
                    return await self.send_tools.reply_to_email(
                        message_id=arguments["message_id"],
                        body=arguments["body"],
                        reply_all=arguments.get("reply_all", False)
                    )
                elif name == "forward_email":
                    return await self.send_tools.forward_email(
                        message_id=arguments["message_id"],
                        to=arguments["to"],
                        body=arguments.get("body", "")
                    )
                elif name == "send_html_email":
                    return await self.send_tools.send_html_email(
                        to=arguments["to"],
                        subject=arguments["subject"],
                        html_body=arguments["html_body"],
                        cc=arguments.get("cc"),
                        bcc=arguments.get("bcc")
                    )
                elif name == "send_email_with_attachment":
                    return await self.send_tools.send_email_with_attachment(
                        to=arguments["to"],
                        subject=arguments["subject"],
                        body=arguments["body"],
                        attachment_path=arguments["attachment_path"],
                        attachment_name=arguments.get("attachment_name")
                    )
                elif name == "draft_email":
                    return await self.send_tools.draft_email(
                        to=arguments["to"],
                        subject=arguments["subject"],
                        body=arguments["body"]
                    )

                # Label tools
                elif name == "list_labels":
                    return await self.label_tools.list_labels()
                elif name == "create_label":
                    return await self.label_tools.create_label(
                        name=arguments["name"],
                        label_list_visibility=arguments.get("label_list_visibility", "labelShow"),
                        message_list_visibility=arguments.get("message_list_visibility", "show")
                    )
                elif name == "delete_label":
                    return await self.label_tools.delete_label(
                        label_id=arguments["label_id"]
                    )
                elif name == "add_label_to_message":
                    return await self.label_tools.add_label_to_message(
                        message_id=arguments["message_id"],
                        label_ids=arguments["label_ids"]
                    )
                elif name == "remove_label_from_message":
                    return await self.label_tools.remove_label_from_message(
                        message_id=arguments["message_id"],
                        label_ids=arguments["label_ids"]
                    )
                elif name == "get_label_details":
                    return await self.label_tools.get_label_details(
                        label_id=arguments["label_id"]
                    )
                elif name == "messages_with_label":
                    return await self.label_tools.messages_with_label(
                        label_id=arguments["label_id"],
                        max_results=arguments.get("max_results", 10)
                    )

                else:
                    raise Exception(f"Unknown tool: {name}")

            except Exception as e:
                self.logger.error(f"Tool {name} failed: {e}")
                return [TextContent(type="text", text=f"Error: {str(e)}")]

        self.logger.info("Gmail tool handlers registered successfully")

    def _initialize_tool_instances(self) -> None:
        """Initialize tool instances after authentication."""
        if self.gmail_client is None:
            raise Exception("Gmail client not initialized")

        # Initialize tool handlers
        self.read_tools = ReadTools(self.gmail_client)
        self.send_tools = SendTools(self.gmail_client)
        self.label_tools = LabelTools(self.gmail_client)

        self.logger.info("Gmail tool instances initialized successfully")

    async def run(self) -> None:
        """Run the Gmail MCP server."""
        try:
            self.logger.info("Starting Gmail MCP Server...")
            self.logger.info("Gmail MCP Server is ready! Authentication will happen when tools are first used.")

            # Run the server with better error handling
            async with stdio_server() as (read_stream, write_stream):
                try:
                    await self.server.run(
                        read_stream,
                        write_stream,
                        self.server.create_initialization_options()
                    )
                except Exception as server_error:
                    self.logger.error(f"Server run error: {server_error}", exc_info=True)
                    raise

        except KeyboardInterrupt:
            self.logger.info("Server stopped by user")
        except Exception as e:
            self.logger.error(f"Server error: {e}", exc_info=True)
            raise

    @classmethod
    def setup_credentials(cls) -> None:
        """Legacy interactive setup for Gmail OAuth credentials.

        Note: Setup is no longer required! The Gmail MCP server now uses
        automatic authentication when first accessed. This command is
        kept for backward compatibility only.
        """
        try:
            print("🔧 Gmail MCP Server Setup (Legacy Mode)")
            print("=" * 50)
            print("ℹ️  Note: Manual setup is no longer required!")
            print("   The Gmail MCP server now authenticates automatically.")
            print("   You can simply add it to Claude Desktop and it will")
            print("   prompt for authentication when first used.")
            print("")

            choice = input("Do you want to continue with legacy setup? (y/N): ").lower().strip()
            if choice not in ['y', 'yes']:
                print("Skipping legacy setup. You can now add the server directly to Claude Desktop:")
                print("")
                print("📖 Claude Desktop Configuration:")
                print('```json')
                print('{')
                print('  "mcpServers": {')
                print('    "gmail": {')
                print('      "command": "gmail-mcp-server"')
                print('    }')
                print('  }')
                print('}')
                print('```')
                return

            # Run interactive setup
            credentials_path = GmailOAuth.setup_credentials_interactive()

            print(f"\n✅ Legacy setup complete!")
            print(f"📁 Credentials saved to: {credentials_path}")
            print(f"\n🚀 You can now run: gmail-mcp-server")
            print(f"\n📖 For Claude Desktop, add this to your configuration:")
            print(f'```json')
            print(f'{{')
            print(f'  "mcpServers": {{')
            print(f'    "gmail": {{')
            print(f'      "command": "gmail-mcp-server"')
            print(f'    }}')
            print(f'  }}')
            print(f'}}')
            print(f'```')

        except Exception as e:
            print(f"❌ Setup failed: {e}")
            sys.exit(1)

    @classmethod
    def test_authentication(cls, credentials_path: Optional[str] = None) -> None:
        """Test Gmail authentication."""
        try:
            print("🔍 Testing Gmail authentication...")

            oauth_handler = GmailOAuth(
                credentials_path=credentials_path,
                use_embedded_credentials=credentials_path is None
            )
            gmail_client = GmailClient(oauth_handler)

            # Test by getting profile
            profile = gmail_client.service.users().getProfile(userId='me').execute()

            print(f"✅ Authentication successful!")
            print(f"📧 Email: {profile.get('emailAddress', 'Unknown')}")
            print(f"📨 Total Messages: {profile.get('messagesTotal', 'Unknown')}")
            print(f"🧵 Total Threads: {profile.get('threadsTotal', 'Unknown')}")

        except Exception as e:
            print(f"❌ Authentication failed: {e}")
            print(f"\n💡 Try running: gmail-mcp-server --setup")
            sys.exit(1)


def main() -> None:
    """Main entry point for the Gmail MCP server."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Gmail MCP Server - Integrate Gmail with AI assistants via Model Context Protocol"
    )
    parser.add_argument(
        "--setup",
        action="store_true",
        help="Run legacy interactive setup for Gmail OAuth credentials (no longer required)"
    )
    parser.add_argument(
        "--test-auth",
        action="store_true",
        help="Test Gmail authentication"
    )
    parser.add_argument(
        "--credentials",
        type=str,
        help="Path to Gmail OAuth credentials JSON file"
    )
    parser.add_argument(
        "--token-dir",
        type=str,
        help="Directory to store access tokens (default: ~/.gmail-mcp)"
    )
    parser.add_argument(
        "--log-level",
        type=str,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Set logging level (default: INFO)"
    )

    args = parser.parse_args()

    # Set log level
    os.environ['GMAIL_MCP_LOG_LEVEL'] = args.log_level

    if args.setup:
        GmailMCPServer.setup_credentials()
        return

    if args.test_auth:
        GmailMCPServer.test_authentication(args.credentials)
        return

    # Run the server
    try:
        server = GmailMCPServer(
            credentials_path=args.credentials,
            token_dir=args.token_dir
        )
        asyncio.run(server.run())
    except Exception as e:
        print(f"❌ Server failed to start: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()