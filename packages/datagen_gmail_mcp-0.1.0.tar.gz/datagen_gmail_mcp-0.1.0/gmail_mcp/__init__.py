"""Gmail MCP Server - A Model Context Protocol server for Gmail integration.

This package provides Gmail functionality through the Model Context Protocol (MCP),
allowing AI assistants like Claude to interact with Gmail for reading, sending,
and managing emails.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .server import GmailMCPServer

__all__ = ["GmailMCPServer"]