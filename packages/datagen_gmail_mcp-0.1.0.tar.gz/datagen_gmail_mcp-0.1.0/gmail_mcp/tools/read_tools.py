"""MCP tools for reading Gmail messages."""

from typing import Any, Dict, List, Optional
from mcp.types import TextContent

from ..gmail_client import GmailClient


class ReadTools:
    """Gmail reading tools for MCP server."""

    def __init__(self, gmail_client: GmailClient):
        """Initialize with Gmail client."""
        self.gmail = gmail_client

    async def list_messages(
        self,
        query: str = "",
        max_results: int = 10,
        include_spam_trash: bool = False,
        label_ids: Optional[List[str]] = None
    ) -> List[TextContent]:
        """List Gmail messages with optional filtering.

        Args:
            query: Gmail search query (e.g., "from:user@example.com", "subject:meeting", "is:unread")
            max_results: Maximum number of messages to return (1-100)
            include_spam_trash: Whether to include spam and trash messages
            label_ids: List of label IDs to filter by (e.g., ["INBOX", "IMPORTANT"])

        Returns:
            List of messages with basic information
        """
        try:
            # Validate parameters
            max_results = min(max(1, max_results), 100)

            result = self.gmail.list_messages(
                query=query,
                max_results=max_results,
                include_spam_trash=include_spam_trash,
                label_ids=label_ids
            )

            if not result['messages']:
                return [TextContent(
                    type="text",
                    text="No messages found matching the criteria."
                )]

            # Get basic info for each message
            messages_info = []
            for msg_ref in result['messages']:
                try:
                    # Get message metadata only for performance
                    msg = self.gmail.get_message(msg_ref['id'], format='metadata')

                    info = {
                        'id': msg['id'],
                        'snippet': msg.get('snippet', ''),
                        'from': msg.get('from', 'Unknown'),
                        'subject': msg.get('subject', 'No Subject'),
                        'date': msg.get('date', 'Unknown'),
                        'labels': msg.get('label_ids', [])
                    }
                    messages_info.append(info)
                except Exception as e:
                    # Skip messages that can't be retrieved
                    continue

            # Format output
            output_lines = [
                f"Found {len(messages_info)} messages:",
                ""
            ]

            for i, msg in enumerate(messages_info, 1):
                output_lines.extend([
                    f"{i}. {msg['subject']}",
                    f"   From: {msg['from']}",
                    f"   Date: {msg['date']}",
                    f"   ID: {msg['id']}",
                    f"   Preview: {msg['snippet'][:100]}...",
                    ""
                ])

            if result.get('next_page_token'):
                output_lines.append("(More messages available - use pagination for additional results)")

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error listing messages: {str(e)}"
            )]

    async def get_message(
        self,
        message_id: str,
        include_headers: bool = False,
        include_attachments: bool = True
    ) -> List[TextContent]:
        """Get the full content of a specific Gmail message.

        Args:
            message_id: The Gmail message ID
            include_headers: Whether to include all email headers
            include_attachments: Whether to include attachment information

        Returns:
            Full message content including body and metadata
        """
        try:
            message = self.gmail.get_message(message_id, format='full')

            output_lines = [
                "=== EMAIL MESSAGE ===",
                f"Message ID: {message['id']}",
                f"Thread ID: {message['thread_id']}",
                f"From: {message.get('from', 'Unknown')}",
                f"To: {message.get('to', 'Unknown')}",
                f"Subject: {message.get('subject', 'No Subject')}",
                f"Date: {message.get('date', 'Unknown')}",
                ""
            ]

            # Add CC/BCC if present
            if message.get('cc'):
                output_lines.append(f"CC: {message['cc']}")
            if message.get('bcc'):
                output_lines.append(f"BCC: {message['bcc']}")

            if message.get('cc') or message.get('bcc'):
                output_lines.append("")

            # Add labels
            if message.get('label_ids'):
                output_lines.extend([
                    f"Labels: {', '.join(message['label_ids'])}",
                    ""
                ])

            # Add body content
            output_lines.append("=== MESSAGE CONTENT ===")

            # Prefer HTML content if available, otherwise use plain text
            if message.get('body_html'):
                # For HTML content, we'll include it but note it's HTML
                output_lines.extend([
                    "(HTML content - showing raw HTML)",
                    message['body_html']
                ])
            elif message.get('body_text'):
                output_lines.append(message['body_text'])
            else:
                output_lines.append("(No readable content found)")

            # Add attachment information
            if include_attachments and message.get('attachments'):
                output_lines.extend([
                    "",
                    "=== ATTACHMENTS ===",
                ])
                for i, attachment in enumerate(message['attachments'], 1):
                    output_lines.extend([
                        f"{i}. {attachment['filename']}",
                        f"   Type: {attachment['mime_type']}",
                        f"   Size: {attachment['size']} bytes",
                        f"   ID: {attachment.get('attachment_id', 'N/A')}",
                    ])

            # Add headers if requested
            if include_headers and message.get('headers'):
                output_lines.extend([
                    "",
                    "=== ALL HEADERS ===",
                ])
                for header_name, header_value in message['headers'].items():
                    output_lines.append(f"{header_name}: {header_value}")

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error retrieving message: {str(e)}"
            )]

    async def search_messages(
        self,
        query: str,
        max_results: int = 20,
        full_content: bool = False
    ) -> List[TextContent]:
        """Search Gmail messages using Gmail's advanced search syntax.

        Args:
            query: Gmail search query (e.g., "from:boss@company.com subject:urgent", "has:attachment newer_than:7d")
            max_results: Maximum number of results to return (1-50)
            full_content: Whether to return full message content or just summaries

        Returns:
            Search results with message content
        """
        try:
            # Validate parameters
            max_results = min(max(1, max_results), 50)

            if not query.strip():
                return [TextContent(
                    type="text",
                    text="Please provide a search query. Examples:\n"
                         "- from:user@example.com\n"
                         "- subject:meeting\n"
                         "- is:unread\n"
                         "- has:attachment\n"
                         "- newer_than:7d\n"
                         "- from:boss@company.com subject:urgent"
                )]

            messages = self.gmail.search_messages(query=query, max_results=max_results)

            if not messages:
                return [TextContent(
                    type="text",
                    text=f"No messages found for query: {query}"
                )]

            output_lines = [
                f"Search Results for: {query}",
                f"Found {len(messages)} messages:",
                ""
            ]

            for i, message in enumerate(messages, 1):
                output_lines.extend([
                    f"--- MESSAGE {i} ---",
                    f"ID: {message['id']}",
                    f"From: {message.get('from', 'Unknown')}",
                    f"Subject: {message.get('subject', 'No Subject')}",
                    f"Date: {message.get('date', 'Unknown')}",
                ])

                if full_content:
                    # Include full message content
                    if message.get('body_text'):
                        output_lines.extend([
                            "Content:",
                            message['body_text'][:500] + ("..." if len(message.get('body_text', '')) > 500 else "")
                        ])
                    elif message.get('body_html'):
                        output_lines.extend([
                            "Content (HTML):",
                            message['body_html'][:500] + ("..." if len(message.get('body_html', '')) > 500 else "")
                        ])
                else:
                    # Just include snippet
                    output_lines.append(f"Preview: {message.get('snippet', 'No preview')}")

                output_lines.append("")

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error searching messages: {str(e)}"
            )]

    async def get_thread(
        self,
        thread_id: str,
        max_messages: int = 10
    ) -> List[TextContent]:
        """Get an entire email thread/conversation.

        Args:
            thread_id: The Gmail thread ID
            max_messages: Maximum number of messages to include from the thread

        Returns:
            Complete thread with all messages
        """
        try:
            thread = self.gmail.get_thread(thread_id)

            output_lines = [
                f"=== EMAIL THREAD ===",
                f"Thread ID: {thread['id']}",
                f"Messages in thread: {thread['message_count']}",
                f"Thread snippet: {thread.get('snippet', 'No preview')}",
                ""
            ]

            # Limit messages if requested
            messages = thread['messages'][:max_messages]
            if len(thread['messages']) > max_messages:
                output_lines.append(f"(Showing first {max_messages} of {thread['message_count']} messages)")
                output_lines.append("")

            for i, message in enumerate(messages, 1):
                output_lines.extend([
                    f"--- MESSAGE {i} ---",
                    f"From: {message.get('from', 'Unknown')}",
                    f"To: {message.get('to', 'Unknown')}",
                    f"Date: {message.get('date', 'Unknown')}",
                    f"Subject: {message.get('subject', 'No Subject')}",
                    ""
                ])

                # Add message content
                if message.get('body_text'):
                    content = message['body_text']
                    if len(content) > 1000:
                        content = content[:1000] + "\n[Content truncated...]"
                    output_lines.extend([
                        "Content:",
                        content,
                        ""
                    ])
                elif message.get('body_html'):
                    content = message['body_html']
                    if len(content) > 1000:
                        content = content[:1000] + "\n[Content truncated...]"
                    output_lines.extend([
                        "Content (HTML):",
                        content,
                        ""
                    ])

                # Add attachment info if present
                if message.get('attachments'):
                    output_lines.append("Attachments:")
                    for attachment in message['attachments']:
                        output_lines.append(f"  - {attachment['filename']} ({attachment['mime_type']})")
                    output_lines.append("")

                output_lines.append("=" * 50)
                output_lines.append("")

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error retrieving thread: {str(e)}"
            )]

    async def get_unread_count(self) -> List[TextContent]:
        """Get the count of unread messages.

        Returns:
            Number of unread messages
        """
        try:
            result = self.gmail.list_messages(query="is:unread", max_results=1)
            count = result.get('result_size_estimate', 0)

            return [TextContent(
                type="text",
                text=f"You have {count} unread messages."
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error getting unread count: {str(e)}"
            )]