"""MCP tools for sending Gmail messages."""

import os
from typing import Any, Dict, List, Optional
from mcp.types import TextContent

from ..gmail_client import GmailClient


class SendTools:
    """Gmail sending tools for MCP server."""

    def __init__(self, gmail_client: GmailClient):
        """Initialize with Gmail client."""
        self.gmail = gmail_client

    async def send_email(
        self,
        to: str,
        subject: str,
        body: str,
        cc: Optional[str] = None,
        bcc: Optional[str] = None,
        reply_to: Optional[str] = None,
        html: bool = False,
        attachments: Optional[List[str]] = None
    ) -> List[TextContent]:
        """Send a new email message.

        Args:
            to: Recipient email address (required)
            subject: Email subject line (required)
            body: Email body content (required)
            cc: CC recipients (comma-separated for multiple)
            bcc: BCC recipients (comma-separated for multiple)
            reply_to: Reply-to email address (optional)
            html: Whether the body contains HTML content
            attachments: List of file paths to attach

        Returns:
            Confirmation of sent email with message ID
        """
        try:
            # Validate required parameters
            if not to.strip():
                return [TextContent(
                    type="text",
                    text="Error: 'to' field is required and cannot be empty."
                )]

            if not subject.strip():
                return [TextContent(
                    type="text",
                    text="Error: 'subject' field is required and cannot be empty."
                )]

            if not body.strip():
                return [TextContent(
                    type="text",
                    text="Error: 'body' field is required and cannot be empty."
                )]

            # Parse recipient lists
            to_list = [email.strip() for email in to.split(',') if email.strip()]
            cc_list = [email.strip() for email in cc.split(',') if cc and email.strip()] if cc else None
            bcc_list = [email.strip() for email in bcc.split(',') if bcc and email.strip()] if bcc else None

            # Validate file attachments
            validated_attachments = []
            if attachments:
                for file_path in attachments:
                    if os.path.exists(file_path):
                        validated_attachments.append(file_path)
                    else:
                        return [TextContent(
                            type="text",
                            text=f"Error: Attachment file not found: {file_path}"
                        )]

            # Send the email
            result = self.gmail.send_message(
                to=to_list,
                subject=subject,
                body=body,
                cc=cc_list,
                bcc=bcc_list,
                reply_to=reply_to,
                html=html,
                attachments=validated_attachments if validated_attachments else None
            )

            # Format response
            output_lines = [
                "✅ Email sent successfully!",
                f"Message ID: {result['id']}",
                f"Thread ID: {result['thread_id']}",
                "",
                "Details:",
                f"  To: {to}",
                f"  Subject: {subject}",
            ]

            if cc:
                output_lines.append(f"  CC: {cc}")
            if bcc:
                output_lines.append(f"  BCC: {bcc}")
            if validated_attachments:
                output_lines.append(f"  Attachments: {len(validated_attachments)} file(s)")

            output_lines.append(f"  Content Type: {'HTML' if html else 'Plain Text'}")

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error sending email: {str(e)}"
            )]

    async def reply_to_email(
        self,
        message_id: str,
        body: str,
        html: bool = False,
        reply_all: bool = False
    ) -> List[TextContent]:
        """Reply to an existing email message.

        Args:
            message_id: The ID of the message to reply to (required)
            body: Reply body content (required)
            html: Whether the body contains HTML content
            reply_all: Whether to reply to all recipients (not just sender)

        Returns:
            Confirmation of sent reply with message ID
        """
        try:
            # Validate required parameters
            if not message_id.strip():
                return [TextContent(
                    type="text",
                    text="Error: 'message_id' is required."
                )]

            if not body.strip():
                return [TextContent(
                    type="text",
                    text="Error: 'body' field is required and cannot be empty."
                )]

            # Send the reply
            result = self.gmail.reply_to_message(
                message_id=message_id,
                body=body,
                html=html,
                reply_all=reply_all
            )

            # Get original message info for context
            try:
                original = self.gmail.get_message(message_id, format='metadata')
                original_subject = original.get('subject', 'Unknown')
                original_from = original.get('from', 'Unknown')
            except Exception:
                original_subject = 'Unknown'
                original_from = 'Unknown'

            # Format response
            output_lines = [
                "✅ Reply sent successfully!",
                f"Reply Message ID: {result['id']}",
                f"Thread ID: {result['thread_id']}",
                "",
                "Reply Details:",
                f"  Original From: {original_from}",
                f"  Original Subject: {original_subject}",
                f"  Reply Type: {'Reply All' if reply_all else 'Reply to Sender'}",
                f"  Content Type: {'HTML' if html else 'Plain Text'}",
            ]

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error sending reply: {str(e)}"
            )]

    async def forward_email(
        self,
        message_id: str,
        to: str,
        additional_message: Optional[str] = None,
        cc: Optional[str] = None,
        bcc: Optional[str] = None
    ) -> List[TextContent]:
        """Forward an existing email message to new recipients.

        Args:
            message_id: The ID of the message to forward (required)
            to: Recipient email address for forwarding (required)
            additional_message: Optional additional message to add to the forward
            cc: CC recipients (comma-separated for multiple)
            bcc: BCC recipients (comma-separated for multiple)

        Returns:
            Confirmation of forwarded email with message ID
        """
        try:
            # Validate required parameters
            if not message_id.strip():
                return [TextContent(
                    type="text",
                    text="Error: 'message_id' is required."
                )]

            if not to.strip():
                return [TextContent(
                    type="text",
                    text="Error: 'to' field is required for forwarding."
                )]

            # Get original message
            original = self.gmail.get_message(message_id, format='full')

            # Create forward subject
            subject = original.get('subject', 'No Subject')
            if not subject.lower().startswith('fwd:'):
                subject = f"Fwd: {subject}"

            # Create forward body
            forward_body_lines = []

            if additional_message:
                forward_body_lines.extend([
                    additional_message,
                    "",
                    "---------- Forwarded message ---------"
                ])
            else:
                forward_body_lines.append("---------- Forwarded message ---------")

            forward_body_lines.extend([
                f"From: {original.get('from', 'Unknown')}",
                f"Date: {original.get('date', 'Unknown')}",
                f"Subject: {original.get('subject', 'No Subject')}",
                f"To: {original.get('to', 'Unknown')}",
                ""
            ])

            # Add original content
            if original.get('body_text'):
                forward_body_lines.append(original['body_text'])
            elif original.get('body_html'):
                forward_body_lines.append("(Original message contained HTML content)")
                forward_body_lines.append(original['body_html'])

            forward_body = "\n".join(forward_body_lines)

            # Parse recipient lists
            to_list = [email.strip() for email in to.split(',') if email.strip()]
            cc_list = [email.strip() for email in cc.split(',') if cc and email.strip()] if cc else None
            bcc_list = [email.strip() for email in bcc.split(',') if bcc and email.strip()] if bcc else None

            # Send the forward
            result = self.gmail.send_message(
                to=to_list,
                subject=subject,
                body=forward_body,
                cc=cc_list,
                bcc=bcc_list,
                html=False  # Keep as plain text for forwards
            )

            # Format response
            output_lines = [
                "✅ Email forwarded successfully!",
                f"Forward Message ID: {result['id']}",
                f"Thread ID: {result['thread_id']}",
                "",
                "Forward Details:",
                f"  Original From: {original.get('from', 'Unknown')}",
                f"  Original Subject: {original.get('subject', 'No Subject')}",
                f"  Forwarded To: {to}",
            ]

            if cc:
                output_lines.append(f"  CC: {cc}")
            if bcc:
                output_lines.append(f"  BCC: {bcc}")
            if additional_message:
                output_lines.append(f"  Additional Message: Yes")

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error forwarding email: {str(e)}"
            )]

    async def send_html_email(
        self,
        to: str,
        subject: str,
        html_body: str,
        text_fallback: Optional[str] = None,
        cc: Optional[str] = None,
        bcc: Optional[str] = None
    ) -> List[TextContent]:
        """Send an HTML email with optional text fallback.

        Args:
            to: Recipient email address (required)
            subject: Email subject line (required)
            html_body: HTML email content (required)
            text_fallback: Plain text version for clients that don't support HTML
            cc: CC recipients (comma-separated for multiple)
            bcc: BCC recipients (comma-separated for multiple)

        Returns:
            Confirmation of sent HTML email
        """
        try:
            # Use the regular send_email with HTML flag
            return await self.send_email(
                to=to,
                subject=subject,
                body=html_body,
                cc=cc,
                bcc=bcc,
                html=True
            )

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error sending HTML email: {str(e)}"
            )]

    async def send_email_with_attachment(
        self,
        to: str,
        subject: str,
        body: str,
        attachment_path: str,
        cc: Optional[str] = None,
        bcc: Optional[str] = None,
        html: bool = False
    ) -> List[TextContent]:
        """Send an email with a single attachment.

        Args:
            to: Recipient email address (required)
            subject: Email subject line (required)
            body: Email body content (required)
            attachment_path: Full path to the file to attach (required)
            cc: CC recipients (comma-separated for multiple)
            bcc: BCC recipients (comma-separated for multiple)
            html: Whether the body contains HTML content

        Returns:
            Confirmation of sent email with attachment
        """
        try:
            # Validate attachment exists
            if not os.path.exists(attachment_path):
                return [TextContent(
                    type="text",
                    text=f"Error: Attachment file not found: {attachment_path}"
                )]

            # Use the regular send_email with attachments
            return await self.send_email(
                to=to,
                subject=subject,
                body=body,
                cc=cc,
                bcc=bcc,
                html=html,
                attachments=[attachment_path]
            )

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error sending email with attachment: {str(e)}"
            )]

    async def draft_email(
        self,
        to: str,
        subject: str,
        body: str,
        cc: Optional[str] = None,
        bcc: Optional[str] = None,
        html: bool = False
    ) -> List[TextContent]:
        """Create a draft email (note: Gmail API doesn't support drafts, so this validates the email instead).

        Args:
            to: Recipient email address (required)
            subject: Email subject line (required)
            body: Email body content (required)
            cc: CC recipients (comma-separated for multiple)
            bcc: BCC recipients (comma-separated for multiple)
            html: Whether the body contains HTML content

        Returns:
            Validation of the email parameters
        """
        try:
            # Validate email parameters
            errors = []

            if not to.strip():
                errors.append("'to' field is required")
            if not subject.strip():
                errors.append("'subject' field is required")
            if not body.strip():
                errors.append("'body' field is required")

            # Validate email addresses
            import re
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

            def validate_email_list(email_string: str, field_name: str):
                if email_string:
                    emails = [e.strip() for e in email_string.split(',')]
                    for email in emails:
                        if not re.match(email_pattern, email):
                            errors.append(f"Invalid email address in {field_name}: {email}")

            validate_email_list(to, "to")
            validate_email_list(cc, "cc") if cc else None
            validate_email_list(bcc, "bcc") if bcc else None

            if errors:
                return [TextContent(
                    type="text",
                    text=f"Draft validation failed:\n" + "\n".join(f"- {error}" for error in errors)
                )]

            # If validation passes, show draft summary
            output_lines = [
                "✅ Email draft validated successfully!",
                "",
                "Draft Summary:",
                f"  To: {to}",
                f"  Subject: {subject}",
            ]

            if cc:
                output_lines.append(f"  CC: {cc}")
            if bcc:
                output_lines.append(f"  BCC: {bcc}")

            output_lines.extend([
                f"  Content Type: {'HTML' if html else 'Plain Text'}",
                f"  Body Length: {len(body)} characters",
                "",
                "Note: Use 'send_email' tool to actually send this email."
            ])

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error validating draft: {str(e)}"
            )]