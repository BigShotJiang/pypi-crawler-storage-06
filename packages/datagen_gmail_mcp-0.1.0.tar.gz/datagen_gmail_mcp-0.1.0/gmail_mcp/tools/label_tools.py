"""MCP tools for Gmail label management."""

from typing import Any, Dict, List, Optional
from mcp.types import TextContent

from ..gmail_client import GmailClient


class LabelTools:
    """Gmail label management tools for MCP server."""

    def __init__(self, gmail_client: GmailClient):
        """Initialize with Gmail client."""
        self.gmail = gmail_client

    async def list_labels(
        self,
        show_system_labels: bool = True,
        show_user_labels: bool = True
    ) -> List[TextContent]:
        """List all Gmail labels.

        Args:
            show_system_labels: Whether to include system labels (INBOX, SENT, etc.)
            show_user_labels: Whether to include user-created labels

        Returns:
            List of all labels with their details
        """
        try:
            result = self.gmail.service.users().labels().list(userId='me').execute()
            labels = result.get('labels', [])

            if not labels:
                return [TextContent(
                    type="text",
                    text="No labels found."
                )]

            # Filter labels based on parameters
            filtered_labels = []
            for label in labels:
                label_type = label.get('type', '')
                if label_type == 'system' and show_system_labels:
                    filtered_labels.append(label)
                elif label_type == 'user' and show_user_labels:
                    filtered_labels.append(label)

            # Sort labels: system first, then user labels alphabetically
            system_labels = [l for l in filtered_labels if l.get('type') == 'system']
            user_labels = sorted([l for l in filtered_labels if l.get('type') == 'user'],
                               key=lambda x: x.get('name', '').lower())

            output_lines = [f"Found {len(filtered_labels)} labels:", ""]

            if system_labels and show_system_labels:
                output_lines.extend(["=== SYSTEM LABELS ==="])
                for label in system_labels:
                    output_lines.extend([
                        f"📁 {label['name']}",
                        f"   ID: {label['id']}",
                        f"   Messages Total: {label.get('messagesTotal', 'Unknown')}",
                        f"   Messages Unread: {label.get('messagesUnread', 'Unknown')}",
                        ""
                    ])

            if user_labels and show_user_labels:
                if system_labels and show_system_labels:
                    output_lines.append("")
                output_lines.extend(["=== USER LABELS ==="])
                for label in user_labels:
                    visibility = "👀 Visible" if label.get('labelListVisibility') == 'labelShow' else "🔍 Hidden"
                    output_lines.extend([
                        f"🏷️  {label['name']} ({visibility})",
                        f"   ID: {label['id']}",
                        f"   Messages Total: {label.get('messagesTotal', 'Unknown')}",
                        f"   Messages Unread: {label.get('messagesUnread', 'Unknown')}",
                        ""
                    ])

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error listing labels: {str(e)}"
            )]

    async def create_label(
        self,
        name: str,
        label_list_visibility: str = "labelShow",
        message_list_visibility: str = "show"
    ) -> List[TextContent]:
        """Create a new Gmail label.

        Args:
            name: Name of the new label (required)
            label_list_visibility: Label visibility in label list ("labelShow", "labelHide")
            message_list_visibility: Message visibility ("show", "hide")

        Returns:
            Details of the created label
        """
        try:
            if not name.strip():
                return [TextContent(
                    type="text",
                    text="Error: Label name cannot be empty."
                )]

            # Check if label already exists
            existing_labels = self.gmail.service.users().labels().list(userId='me').execute()
            for label in existing_labels.get('labels', []):
                if label['name'].lower() == name.lower():
                    return [TextContent(
                        type="text",
                        text=f"Error: Label '{name}' already exists with ID: {label['id']}"
                    )]

            # Validate visibility parameters
            valid_label_visibility = ["labelShow", "labelHide"]
            valid_message_visibility = ["show", "hide"]

            if label_list_visibility not in valid_label_visibility:
                return [TextContent(
                    type="text",
                    text=f"Error: Invalid label_list_visibility. Must be one of: {valid_label_visibility}"
                )]

            if message_list_visibility not in valid_message_visibility:
                return [TextContent(
                    type="text",
                    text=f"Error: Invalid message_list_visibility. Must be one of: {valid_message_visibility}"
                )]

            # Create the label
            label_object = {
                'name': name,
                'labelListVisibility': label_list_visibility,
                'messageListVisibility': message_list_visibility
            }

            result = self.gmail.service.users().labels().create(
                userId='me',
                body=label_object
            ).execute()

            return [TextContent(
                type="text",
                text=f"✅ Label created successfully!\n"
                     f"Name: {result['name']}\n"
                     f"ID: {result['id']}\n"
                     f"Label List Visibility: {result['labelListVisibility']}\n"
                     f"Message List Visibility: {result['messageListVisibility']}"
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error creating label: {str(e)}"
            )]

    async def delete_label(
        self,
        label_id: str
    ) -> List[TextContent]:
        """Delete a Gmail label.

        Args:
            label_id: ID of the label to delete (required)

        Returns:
            Confirmation of label deletion
        """
        try:
            if not label_id.strip():
                return [TextContent(
                    type="text",
                    text="Error: Label ID cannot be empty."
                )]

            # Check if label exists and get its details
            try:
                label = self.gmail.service.users().labels().get(
                    userId='me',
                    id=label_id
                ).execute()
                label_name = label['name']
                label_type = label.get('type', 'user')

                # Prevent deletion of system labels
                if label_type == 'system':
                    return [TextContent(
                        type="text",
                        text=f"Error: Cannot delete system label '{label_name}' (ID: {label_id})"
                    )]

            except Exception:
                return [TextContent(
                    type="text",
                    text=f"Error: Label with ID '{label_id}' not found."
                )]

            # Delete the label
            self.gmail.service.users().labels().delete(
                userId='me',
                id=label_id
            ).execute()

            return [TextContent(
                type="text",
                text=f"✅ Label '{label_name}' (ID: {label_id}) deleted successfully!"
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error deleting label: {str(e)}"
            )]

    async def add_label_to_message(
        self,
        message_id: str,
        label_ids: List[str]
    ) -> List[TextContent]:
        """Add labels to a message.

        Args:
            message_id: ID of the message to label (required)
            label_ids: List of label IDs to add (required)

        Returns:
            Confirmation of labels added to message
        """
        try:
            if not message_id.strip():
                return [TextContent(
                    type="text",
                    text="Error: Message ID cannot be empty."
                )]

            if not label_ids:
                return [TextContent(
                    type="text",
                    text="Error: At least one label ID must be provided."
                )]

            # Validate that message exists
            try:
                message = self.gmail.get_message(message_id, format='minimal')
            except Exception:
                return [TextContent(
                    type="text",
                    text=f"Error: Message with ID '{message_id}' not found."
                )]

            # Validate label IDs
            all_labels = self.gmail.service.users().labels().list(userId='me').execute()
            valid_label_ids = {label['id']: label['name'] for label in all_labels.get('labels', [])}

            invalid_labels = [lid for lid in label_ids if lid not in valid_label_ids]
            if invalid_labels:
                return [TextContent(
                    type="text",
                    text=f"Error: Invalid label IDs: {invalid_labels}"
                )]

            # Add labels to message
            result = self.gmail.service.users().messages().modify(
                userId='me',
                id=message_id,
                body={'addLabelIds': label_ids}
            ).execute()

            # Get label names for response
            added_label_names = [valid_label_ids[lid] for lid in label_ids]

            return [TextContent(
                type="text",
                text=f"✅ Labels added to message successfully!\n"
                     f"Message ID: {message_id}\n"
                     f"Added Labels: {', '.join(added_label_names)}\n"
                     f"Current Labels: {', '.join(result.get('labelIds', []))}"
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error adding labels to message: {str(e)}"
            )]

    async def remove_label_from_message(
        self,
        message_id: str,
        label_ids: List[str]
    ) -> List[TextContent]:
        """Remove labels from a message.

        Args:
            message_id: ID of the message to unlabel (required)
            label_ids: List of label IDs to remove (required)

        Returns:
            Confirmation of labels removed from message
        """
        try:
            if not message_id.strip():
                return [TextContent(
                    type="text",
                    text="Error: Message ID cannot be empty."
                )]

            if not label_ids:
                return [TextContent(
                    type="text",
                    text="Error: At least one label ID must be provided."
                )]

            # Validate that message exists
            try:
                message = self.gmail.get_message(message_id, format='minimal')
                current_labels = message.get('label_ids', [])
            except Exception:
                return [TextContent(
                    type="text",
                    text=f"Error: Message with ID '{message_id}' not found."
                )]

            # Check which labels can actually be removed
            removable_labels = [lid for lid in label_ids if lid in current_labels]
            not_present_labels = [lid for lid in label_ids if lid not in current_labels]

            if not removable_labels:
                return [TextContent(
                    type="text",
                    text=f"No labels to remove. The message doesn't have any of the specified labels."
                )]

            # Get label names for response
            all_labels = self.gmail.service.users().labels().list(userId='me').execute()
            valid_label_ids = {label['id']: label['name'] for label in all_labels.get('labels', [])}

            # Remove labels from message
            result = self.gmail.service.users().messages().modify(
                userId='me',
                id=message_id,
                body={'removeLabelIds': removable_labels}
            ).execute()

            removed_label_names = [valid_label_ids.get(lid, lid) for lid in removable_labels]

            response_lines = [
                "✅ Labels removed from message successfully!",
                f"Message ID: {message_id}",
                f"Removed Labels: {', '.join(removed_label_names)}",
                f"Remaining Labels: {', '.join(result.get('labelIds', []))}"
            ]

            if not_present_labels:
                not_present_names = [valid_label_ids.get(lid, lid) for lid in not_present_labels]
                response_lines.append(f"Note: These labels were not on the message: {', '.join(not_present_names)}")

            return [TextContent(
                type="text",
                text="\n".join(response_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error removing labels from message: {str(e)}"
            )]

    async def get_label_details(
        self,
        label_id: str
    ) -> List[TextContent]:
        """Get detailed information about a specific label.

        Args:
            label_id: ID of the label to get details for (required)

        Returns:
            Detailed information about the label
        """
        try:
            if not label_id.strip():
                return [TextContent(
                    type="text",
                    text="Error: Label ID cannot be empty."
                )]

            # Get label details
            label = self.gmail.service.users().labels().get(
                userId='me',
                id=label_id
            ).execute()

            output_lines = [
                f"=== LABEL DETAILS ===",
                f"Name: {label['name']}",
                f"ID: {label['id']}",
                f"Type: {label.get('type', 'Unknown')}",
                f"Messages Total: {label.get('messagesTotal', 'Unknown')}",
                f"Messages Unread: {label.get('messagesUnread', 'Unknown')}",
                f"Threads Total: {label.get('threadsTotal', 'Unknown')}",
                f"Threads Unread: {label.get('threadsUnread', 'Unknown')}",
                f"Label List Visibility: {label.get('labelListVisibility', 'Unknown')}",
                f"Message List Visibility: {label.get('messageListVisibility', 'Unknown')}",
            ]

            # Add color information if available
            if 'color' in label:
                output_lines.extend([
                    "",
                    "Color Settings:",
                    f"  Text Color: {label['color'].get('textColor', 'Default')}",
                    f"  Background Color: {label['color'].get('backgroundColor', 'Default')}"
                ])

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            if "Not Found" in str(e):
                return [TextContent(
                    type="text",
                    text=f"Error: Label with ID '{label_id}' not found."
                )]
            return [TextContent(
                type="text",
                text=f"Error getting label details: {str(e)}"
            )]

    async def messages_with_label(
        self,
        label_id: str,
        max_results: int = 10
    ) -> List[TextContent]:
        """Get messages that have a specific label.

        Args:
            label_id: ID of the label to search for (required)
            max_results: Maximum number of messages to return (1-50)

        Returns:
            List of messages with the specified label
        """
        try:
            if not label_id.strip():
                return [TextContent(
                    type="text",
                    text="Error: Label ID cannot be empty."
                )]

            # Validate max_results
            max_results = min(max(1, max_results), 50)

            # Verify label exists
            try:
                label = self.gmail.service.users().labels().get(
                    userId='me',
                    id=label_id
                ).execute()
                label_name = label['name']
            except Exception:
                return [TextContent(
                    type="text",
                    text=f"Error: Label with ID '{label_id}' not found."
                )]

            # Get messages with this label
            result = self.gmail.list_messages(
                label_ids=[label_id],
                max_results=max_results
            )

            if not result['messages']:
                return [TextContent(
                    type="text",
                    text=f"No messages found with label '{label_name}' (ID: {label_id})"
                )]

            output_lines = [
                f"Messages with label '{label_name}' (ID: {label_id}):",
                f"Found {len(result['messages'])} messages:",
                ""
            ]

            # Get message details
            for i, msg_ref in enumerate(result['messages'], 1):
                try:
                    msg = self.gmail.get_message(msg_ref['id'], format='metadata')
                    output_lines.extend([
                        f"{i}. {msg.get('subject', 'No Subject')}",
                        f"   From: {msg.get('from', 'Unknown')}",
                        f"   Date: {msg.get('date', 'Unknown')}",
                        f"   ID: {msg['id']}",
                        f"   Snippet: {msg.get('snippet', 'No preview')[:100]}...",
                        ""
                    ])
                except Exception:
                    output_lines.extend([
                        f"{i}. [Message could not be retrieved]",
                        f"   ID: {msg_ref['id']}",
                        ""
                    ])

            if result.get('next_page_token'):
                output_lines.append("(More messages available)")

            return [TextContent(
                type="text",
                text="\n".join(output_lines)
            )]

        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Error getting messages with label: {str(e)}"
            )]