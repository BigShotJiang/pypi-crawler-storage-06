#!/usr/bin/env python3
"""
Simple test to validate the Gmail MCP package structure and imports.
"""

def test_imports():
    """Test that all main components can be imported."""
    print("Testing Gmail MCP package imports...")

    try:
        # Test main package import
        import gmail_mcp
        print("✅ gmail_mcp package imported successfully")
        print(f"   Version: {gmail_mcp.__version__}")

        # Test server import
        from gmail_mcp.server import GmailMCPServer
        print("✅ GmailMCPServer imported successfully")

        # Test OAuth import
        from gmail_mcp.auth.oauth import GmailOAuth
        print("✅ GmailOAuth imported successfully")

        # Test Gmail client import
        from gmail_mcp.gmail_client import GmailClient
        print("✅ GmailClient imported successfully")

        # Test tool imports
        from gmail_mcp.tools.read_tools import ReadTools
        from gmail_mcp.tools.send_tools import SendTools
        from gmail_mcp.tools.label_tools import LabelTools
        print("✅ All tool classes imported successfully")

        return True

    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False


def test_package_structure():
    """Test that the package structure is correct."""
    import os
    from pathlib import Path

    print("\nTesting package structure...")

    base_dir = Path(".")
    required_files = [
        "pyproject.toml",
        "README.md",
        "LICENSE",
        "requirements.txt",
        "gmail_mcp/__init__.py",
        "gmail_mcp/server.py",
        "gmail_mcp/gmail_client.py",
        "gmail_mcp/auth/__init__.py",
        "gmail_mcp/auth/oauth.py",
        "gmail_mcp/tools/__init__.py",
        "gmail_mcp/tools/read_tools.py",
        "gmail_mcp/tools/send_tools.py",
        "gmail_mcp/tools/label_tools.py",
        "examples/claude_desktop_config.json",
        "examples/basic_usage.py",
    ]

    missing_files = []
    for file_path in required_files:
        if not (base_dir / file_path).exists():
            missing_files.append(file_path)
        else:
            print(f"✅ {file_path}")

    if missing_files:
        print(f"\n❌ Missing files: {missing_files}")
        return False
    else:
        print(f"\n✅ All {len(required_files)} required files present")
        return True


def test_server_instantiation():
    """Test that the server can be instantiated without authentication."""
    print("\nTesting server instantiation...")

    try:
        from gmail_mcp.server import GmailMCPServer

        # This should work without credentials (just creates the object)
        server = GmailMCPServer()
        print("✅ GmailMCPServer instantiated successfully")

        # Test that it has the expected attributes
        assert hasattr(server, 'server'), "Missing 'server' attribute"
        assert hasattr(server, 'oauth_handler'), "Missing 'oauth_handler' attribute"
        assert hasattr(server, 'gmail_client'), "Missing 'gmail_client' attribute"
        print("✅ Server has expected attributes")

        return True

    except Exception as e:
        print(f"❌ Server instantiation failed: {e}")
        return False


def main():
    """Run all tests."""
    print("Gmail MCP Package Validation")
    print("=" * 40)

    tests = [
        test_package_structure,
        test_imports,
        test_server_instantiation,
    ]

    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test.__name__} failed with exception: {e}")
            results.append(False)

    print("\n" + "=" * 40)
    print("Test Summary:")
    print(f"✅ Passed: {sum(results)}")
    print(f"❌ Failed: {len(results) - sum(results)}")
    print(f"📊 Total: {len(results)}")

    if all(results):
        print("\n🎉 All tests passed! The package is ready for use.")
        print("\nNext steps:")
        print("1. Install dependencies: pip install -e .")
        print("2. Set up Gmail credentials: datagen-gmail-mcp-server --setup")
        print("3. Test authentication: datagen-gmail-mcp-server --test-auth")
        print("4. Configure Claude Desktop with the server")
    else:
        print("\n⚠️  Some tests failed. Please fix the issues before using the package.")

    return all(results)


if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)