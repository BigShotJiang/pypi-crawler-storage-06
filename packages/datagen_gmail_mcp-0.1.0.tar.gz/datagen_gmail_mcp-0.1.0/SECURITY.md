# Security Documentation

## DataGen Gmail MCP Server Security Features

The Gmail MCP server implements industry-standard security practices to protect user data and credentials.

## OAuth 2.0 with PKCE

### What is PKCE?

PKCE (Proof Key for Code Exchange, pronounced "pixie") is an OAuth 2.0 security extension designed for public clients. It prevents authorization code interception attacks by using dynamically generated cryptographic keys.

### Why PKCE for Gmail MCP?

As a PyPI package, the Gmail MCP server is a **public client** that cannot securely store client secrets. Traditional OAuth flows with client secrets would expose those secrets to anyone who downloads the package. PKCE eliminates this risk by:

1. **No Client Secrets**: The package contains no sensitive authentication secrets
2. **Dynamic Security**: Each authentication request uses unique, ephemeral keys
3. **Interception Protection**: Authorization codes cannot be used without the corresponding verifier

### How PKCE Works in Gmail MCP

1. **Code Generation**: For each OAuth request, the server generates:
   - `code_verifier`: A cryptographically random 32-byte string
   - `code_challenge`: SHA256 hash of the code_verifier, base64url-encoded

2. **Authorization Request**: The authorization URL includes:
   - `code_challenge`: Sent to Google's OAuth server
   - `code_challenge_method=S256`: Indicates SHA256 hashing

3. **Token Exchange**: When exchanging the authorization code for tokens:
   - `code_verifier`: Sent to prove the client initiated the request
   - Google verifies: `SHA256(code_verifier) == code_challenge`

## Security Features

### Public Client Design

- **No Embedded Secrets**: The package contains only a public client ID
- **Open Source Safe**: All code can be safely published and inspected
- **MITM Protection**: PKCE prevents man-in-the-middle attacks

### Secure Token Storage

- **Local Only**: Access tokens are stored locally on the user's machine
- **Encrypted Storage**: Tokens are encrypted using Python's pickle format
- **Automatic Refresh**: Expired tokens are automatically refreshed

### Minimal Permissions

The server requests only necessary Gmail permissions:
- `gmail.readonly`: Read emails and labels
- `gmail.send`: Send emails
- `gmail.modify`: Modify email labels
- `gmail.labels`: Manage labels

## Security Best Practices

### For Users

1. **Token Security**: Protect your `~/.datagen-gmail-mcp/token.pickle` file
2. **Revoke Access**: You can revoke access anytime in Google Account settings
3. **Monitor Usage**: Review OAuth app permissions periodically

### For Developers

1. **Public Client Configuration**: Configure OAuth app as "Desktop Application"
2. **No Client Secret**: Don't generate or include client secrets
3. **PKCE Validation**: Ensure PKCE parameters are properly implemented

## Threat Model

### Threats Mitigated

✅ **Client Secret Exposure**: No secrets to expose
✅ **Authorization Code Interception**: PKCE prevents replay attacks
✅ **Package Tampering**: No sensitive data in the package
✅ **Credential Harvesting**: Users authenticate directly with Google

### Threats Outside Scope

⚠️ **Local Machine Compromise**: If the user's machine is compromised, stored tokens could be accessed
⚠️ **Google Account Compromise**: If the user's Google account is compromised, the app's access is also compromised
⚠️ **Network Surveillance**: HTTPS protects data in transit, but local network monitoring could observe metadata

## Compliance

The Gmail MCP server follows:

- **OAuth 2.0 RFC 6749**: Core OAuth 2.0 specification
- **RFC 7636**: PKCE specification for public clients
- **Google's OAuth 2.0 Guidelines**: Best practices for Google API access
- **Python Security Guidelines**: Secure coding practices for Python applications

## Reporting Security Issues

If you discover a security vulnerability in the Gmail MCP server:

1. **Do not** create a public GitHub issue
2. Email security concerns to: [your-security-email@example.com]
3. Include detailed steps to reproduce the issue
4. Allow time for investigation and patching before public disclosure

## Security Auditing

The security implementation can be verified by:

1. **Code Review**: All OAuth code is open source and auditable
2. **PKCE Testing**: Run `python3 test_pkce_security.py` to verify implementation
3. **Network Analysis**: Monitor OAuth flows with tools like Wireshark
4. **Token Inspection**: Verify no secrets are stored in package files

## Updates and Maintenance

- **Dependency Updates**: OAuth libraries are kept current for security patches
- **Google API Changes**: Implementation updated to follow Google's security recommendations
- **Community Review**: Security improvements welcome via pull requests

---

*Last updated: [Current Date]*
*Security implementation version: 1.0*