# DataGen Gmail MCP Server

A Model Context Protocol (MCP) server that provides Gmail integration for AI assistants like Claude Desktop. This server enables reading, sending, and managing Gmail messages through a standardized interface.

## Features

### 📧 Email Operations
- **Read Messages**: List, search, and retrieve full email content
- **Send Messages**: Compose and send emails with attachments
- **Reply & Forward**: Reply to messages or forward them to others
- **Thread Management**: Handle entire email conversations

### 🏷️ Label Management
- **List Labels**: View all system and user-created labels
- **Create/Delete Labels**: Manage custom labels
- **Apply Labels**: Add or remove labels from messages
- **Filter by Labels**: Find messages with specific labels

### 🔐 Secure Authentication
- **OAuth 2.0 with PKCE**: Secure authentication for public clients
- **No Client Secrets**: Enhanced security using PKCE flow
- **Zero-Setup Security**: Automatic secure authentication without user configuration
- **Token Management**: Automatic token refresh
- **Local Storage**: Secure credential storage

## Installation

### Option 1: Using uvx (Recommended)
```bash
uvx install datagen-gmail-mcp
```

### Option 2: Using pip
```bash
pip install datagen-gmail-mcp
```

## Quick Start

### 1. Install the Package

Using uvx (recommended):
```bash
uvx install datagen-gmail-mcp
```

Or using pip:
```bash
pip install datagen-gmail-mcp
```

### 2. Configure Claude Desktop

**No setup required!** This is a zero-setup experience - simply add the server to Claude Desktop and it will automatically prompt for Gmail authentication when first used.

Add to your Claude Desktop configuration file:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "gmail": {
      "command": "datagen-gmail-mcp-server"
    }
  }
}
```

### Alternative uvx Configuration

```json
{
  "mcpServers": {
    "gmail": {
      "command": "uvx",
      "args": ["datagen-gmail-mcp-server"]
    }
  }
}
```

### 3. Start Using Gmail

Restart Claude Desktop and start using Gmail commands! The server will automatically:
1. Open your browser for Gmail authentication
2. Save your credentials securely
3. Connect to your Gmail account

Try asking Claude:
- "Show me my recent emails"
- "How many unread messages do I have?"
- "List my Gmail labels"

## Usage Examples

Once configured, you can use Gmail functionality through Claude Desktop:

### Reading Emails
- "Show me my recent emails"
- "Search for emails from my boss about the project"
- "Get the content of the email with ID xyz123"
- "Show me unread messages"

### Sending Emails
- "Send an email to john@example.com about the meeting"
- "Reply to the last email in my inbox"
- "Forward this email to the team"

### Managing Labels
- "Show me all my Gmail labels"
- "Create a new label called 'Important Projects'"
- "Add the 'Work' label to this message"

## Available Tools

### Email Reading
- `list_messages` - List emails with filtering options
- `get_message` - Get full message content
- `search_messages` - Search using Gmail query syntax
- `get_thread` - Get entire conversation thread
- `get_unread_count` - Count unread messages

### Email Sending
- `send_email` - Send new messages
- `reply_to_email` - Reply to existing messages
- `forward_email` - Forward messages
- `send_html_email` - Send HTML formatted emails
- `send_email_with_attachment` - Send with file attachments
- `draft_email` - Validate email without sending

### Label Management
- `list_labels` - List all labels
- `create_label` - Create new labels
- `delete_label` - Delete user labels
- `add_label_to_message` - Apply labels to messages
- `remove_label_from_message` - Remove labels from messages
- `get_label_details` - Get label information
- `messages_with_label` - Find messages with specific labels

## Configuration Options

### Environment Variables
- `GMAIL_CREDENTIALS_PATH` - Path to OAuth credentials file
- `GMAIL_MCP_LOG_LEVEL` - Logging level (DEBUG, INFO, WARNING, ERROR)

### Command Line Options
```bash
datagen-gmail-mcp-server --help

Options:
  --setup              Run legacy interactive setup (no longer required)
  --test-auth          Test authentication
  --credentials PATH   Custom credentials file path
  --token-dir PATH     Custom token storage directory
  --log-level LEVEL    Set logging level
```

## Gmail Search Syntax

The server supports Gmail's advanced search syntax:

```
from:user@example.com          # Emails from specific sender
to:user@example.com            # Emails to specific recipient
subject:meeting                # Emails with subject containing "meeting"
has:attachment                 # Emails with attachments
is:unread                      # Unread emails
is:important                   # Important emails
label:work                     # Emails with "work" label
newer_than:7d                  # Emails newer than 7 days
older_than:1y                  # Emails older than 1 year
"exact phrase"                 # Emails containing exact phrase
```

## Security & Privacy

- **PKCE Security**: Uses Proof Key for Code Exchange (PKCE) for enhanced security - this prevents authorization code interception attacks and eliminates the need for client secrets
- **No Client Secrets**: Public client design eliminates secret exposure risks in the distributed package
- **Zero-Setup Security**: No manual OAuth configuration required by users - security is built-in
- **Local Authentication**: All tokens stored locally on your machine
- **OAuth 2.0**: Uses Google's secure authentication flow following best practices
- **No Data Sharing**: No email data is sent to third parties
- **Token Encryption**: Access tokens are securely stored
- **Minimal Permissions**: Only requests necessary Gmail permissions

📚 **For detailed security information**, see [SECURITY.md](SECURITY.md) which explains the PKCE implementation and security architecture.

## Troubleshooting

### Authentication Issues
```bash
# Test your authentication
datagen-gmail-mcp-server --test-auth

# Clear saved credentials if needed
rm ~/.gmail-mcp/token.pickle
# Then restart Claude Desktop to re-authenticate
```

### Permission Errors
Make sure your OAuth credentials have the correct scopes:
- `https://www.googleapis.com/auth/gmail.readonly` - Read emails
- `https://www.googleapis.com/auth/gmail.send` - Send emails
- `https://www.googleapis.com/auth/gmail.modify` - Modify emails
- `https://www.googleapis.com/auth/gmail.labels` - Manage labels

### Debug Mode
```bash
datagen-gmail-mcp-server --log-level DEBUG
```

## Development

### Requirements
- Python 3.8+
- Gmail API access
- MCP-compatible client (like Claude Desktop)

### For Package Maintainers

If you're maintaining this package, you'll need to configure the OAuth application:

1. **Create Google Cloud Project** and enable Gmail API
2. **Configure OAuth Application** as "Desktop Application" (public client)
3. **Replace `YOUR_CLIENT_ID`** in `gmail_mcp/auth/oauth.py` with your client ID
4. **No client secret needed** - the package uses PKCE for security

See [DEPLOYMENT.md](DEPLOYMENT.md) for detailed deployment instructions.

### Local Development
```bash
git clone <repository>
cd gmail-mcp
pip install -e ".[dev]"

# Run tests
pytest

# Run security validation
python3 test_pkce_security.py
python3 test_final_security.py

# Code formatting
black .
isort .
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/gmail-mcp/issues)
- **Documentation**: [GitHub README](https://github.com/yourusername/gmail-mcp#readme)
- **Email**: your.email@example.com

## Related Projects

- [MCP](https://github.com/modelcontextprotocol/python-sdk) - Model Context Protocol
- [Claude Desktop](https://claude.ai/download) - AI assistant with MCP support
- [Gmail API](https://developers.google.com/gmail/api) - Google's Gmail API documentation