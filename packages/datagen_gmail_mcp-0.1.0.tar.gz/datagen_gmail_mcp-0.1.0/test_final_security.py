#!/usr/bin/env python3
"""
Final comprehensive security test for Gmail MCP package.
This validates all security improvements and documentation.
"""

def test_package_security_overview():
    """Test overall package security posture."""
    print("Testing overall package security...")

    security_files = [
        'SECURITY.md',
        'test_pkce_security.py',
        'test_final_security.py'
    ]

    missing_files = []
    for file_path in security_files:
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                assert len(content) > 100, f"{file_path} appears to be empty or too short"
        except FileNotFoundError:
            missing_files.append(file_path)

    if missing_files:
        print(f"❌ Missing security files: {missing_files}")
        return False

    print("✅ All security documentation files present")
    return True

def test_no_secrets_in_any_files():
    """Scan all Python files for potential secret leaks."""
    print("\nScanning all files for secrets...")

    import os

    # Only look for actual hardcoded secrets, not variable names
    dangerous_patterns = [
        'client_secret": "',  # Actual client secret value
        'secret_key": "',     # Actual secret key value
        'api_key": "',        # Actual API key value
        'password": "',       # Actual password value
    ]

    # Files that should be checked for secrets
    files_to_check = []
    for root, dirs, files in os.walk('gmail_mcp'):
        for file in files:
            if file.endswith('.py'):
                files_to_check.append(os.path.join(root, file))

    # Also check main configuration files
    files_to_check.extend([
        'pyproject.toml',
        'requirements.txt'
    ])

    issues_found = []

    for file_path in files_to_check:
        try:
            with open(file_path, 'r') as f:
                content = f.read().lower()
                lines = content.split('\n')

                for i, line in enumerate(lines, 1):
                    # Skip comments and documentation
                    stripped_line = line.strip()
                    if stripped_line.startswith('#') or stripped_line.startswith('"""') or stripped_line.startswith("'''"):
                        continue

                    # Check for suspicious patterns
                    for pattern in dangerous_patterns:
                        if pattern in line:
                            # Skip placeholder values
                            if 'YOUR_CLIENT_SECRET' not in line and '"GOCSPX-' not in line:
                                issues_found.append(f"{file_path}:{i} - Potential secret: {line.strip()}")

        except FileNotFoundError:
            continue
        except Exception as e:
            print(f"⚠️  Could not scan {file_path}: {e}")

    if issues_found:
        print("❌ Potential secrets found:")
        for issue in issues_found:
            print(f"  {issue}")
        return False

    print("✅ No secrets found in package files")
    return True

def test_pkce_implementation_complete():
    """Test that PKCE implementation is complete and correct."""
    print("\nTesting PKCE implementation completeness...")

    try:
        with open('gmail_mcp/auth/oauth.py', 'r') as f:
            oauth_content = f.read()

        # Critical PKCE components that must be present
        critical_components = [
            ('PKCE imports', ['import base64', 'import hashlib', 'import secrets']),
            ('PKCE generation', ['_generate_pkce_codes', 'secrets.token_bytes', 'hashlib.sha256']),
            ('PKCE in automatic flow', ['code_verifier, code_challenge = self._generate_pkce_codes()', 'code_challenge=code_challenge', 'code_verifier=code_verifier']),
            ('Public client detection', ['is_public_client', "'client_secret' not in creds_data"]),
            ('No client secret in embedded', ['EMBEDDED_OAUTH_CREDENTIALS']),
        ]

        missing_components = []
        for component_name, required_elements in critical_components:
            found_elements = [elem for elem in required_elements if elem in oauth_content]
            if len(found_elements) != len(required_elements):
                missing_elements = set(required_elements) - set(found_elements)
                missing_components.append(f"{component_name}: missing {missing_elements}")

        if missing_components:
            print("❌ Incomplete PKCE implementation:")
            for component in missing_components:
                print(f"  {component}")
            return False

        # Verify no client_secret in embedded credentials section
        embedded_start = oauth_content.find('EMBEDDED_OAUTH_CREDENTIALS')
        embedded_end = oauth_content.find('}', embedded_start) + 1
        embedded_section = oauth_content[embedded_start:embedded_end]

        if 'client_secret' in embedded_section and 'YOUR_CLIENT_SECRET' not in embedded_section:
            print("❌ client_secret found in embedded credentials")
            return False

        print("✅ PKCE implementation is complete and correct")
        return True

    except FileNotFoundError:
        print("❌ oauth.py file not found")
        return False

def test_documentation_security_updates():
    """Test that all documentation reflects security improvements."""
    print("\nTesting documentation security updates...")

    docs_to_check = {
        'README.md': ['PKCE', 'No Client Secrets', 'secure authentication'],
        'examples/setup_guide.md': ['PKCE', 'Enhanced Security', 'No Client Secrets'],
        'DEPLOYMENT.md': ['PKCE Implementation', 'No Client Secrets'],
        'SECURITY.md': ['PKCE', 'Proof Key for Code Exchange', 'public client']
    }

    missing_updates = []
    for doc_file, required_terms in docs_to_check.items():
        try:
            with open(doc_file, 'r') as f:
                content = f.read()

            missing_terms = [term for term in required_terms if term not in content]
            if missing_terms:
                missing_updates.append(f"{doc_file}: missing {missing_terms}")

        except FileNotFoundError:
            missing_updates.append(f"{doc_file}: file not found")

    if missing_updates:
        print("❌ Documentation missing security updates:")
        for update in missing_updates:
            print(f"  {update}")
        return False

    print("✅ All documentation updated with security improvements")
    return True

def test_package_structure_secure():
    """Test that package structure follows security best practices."""
    print("\nTesting secure package structure...")

    # Files that should NOT contain sensitive data
    public_files = [
        'pyproject.toml',
        'requirements.txt',
        'README.md',
        'MANIFEST.in'
    ]

    # Check that public files don't contain secrets
    for file_path in public_files:
        try:
            with open(file_path, 'r') as f:
                content = f.read().lower()

            # Look for actual secret values in public files
            suspicious_patterns = [
                'client_secret": "',
                'secret_key": "',
                'api_key": "',
                'password": "'
            ]

            has_secrets = any(pattern in content for pattern in suspicious_patterns)

            if has_secrets and 'your_client_secret' not in content.lower():
                print(f"❌ Suspicious content in {file_path}")
                return False

        except FileNotFoundError:
            continue

    print("✅ Package structure follows security best practices")
    return True

def main():
    """Run comprehensive security validation."""
    print("Gmail MCP Final Security Validation")
    print("=" * 50)

    tests = [
        test_package_security_overview,
        test_no_secrets_in_any_files,
        test_pkce_implementation_complete,
        test_documentation_security_updates,
        test_package_structure_secure
    ]

    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test.__name__} failed with exception: {e}")
            results.append(False)

    print("\n" + "=" * 50)
    print("Final Security Validation Summary:")
    print(f"✅ Passed: {sum(results)}")
    print(f"❌ Failed: {len(results) - sum(results)}")
    print(f"📊 Total: {len(results)}")

    if all(results):
        print("\n🎉🔒 Gmail MCP Package is SECURE and ready for deployment!")
        print("\n📋 Security Achievement Summary:")
        print("✅ No client secrets in public package")
        print("✅ PKCE (Proof Key for Code Exchange) fully implemented")
        print("✅ Public client OAuth design")
        print("✅ Secure random code generation")
        print("✅ SHA256-based code challenges")
        print("✅ Comprehensive security documentation")
        print("✅ Zero-setup user experience maintained")
        print("\n🚀 Ready for PyPI Deployment:")
        print("1. Replace YOUR_CLIENT_ID with your Google OAuth client ID")
        print("2. Configure Google OAuth app as 'Desktop Application' (public client)")
        print("3. Test authentication flow")
        print("4. Build: python -m build")
        print("5. Deploy: twine upload dist/*")
        print("\n✨ Users will have a secure, zero-setup Gmail experience!")
    else:
        print("\n⚠️  Some security validations failed. Please address issues before deployment.")

    return all(results)

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)