# Deployment Guide

This guide covers how to deploy the Gmail MCP server to PyPI and distribute it.

## Package Validation

Before deployment, validate both the package structure and security implementation:

### Structure Validation
```bash
python3 test_package.py
```

Note: Import tests will fail until dependencies are installed, which is expected.

### Security Validation
```bash
# Validate PKCE implementation and security
python3 test_pkce_security.py

# Comprehensive security validation
python3 test_final_security.py

# OAuth structure validation
python3 test_oauth_structure.py
```

These tests ensure:
- No client secrets are exposed in the package
- PKCE implementation is correct and complete
- OAuth flows are secure for public clients
- Documentation reflects security improvements

## Development Setup

1. **Install in development mode:**
```bash
pip install -e ".[dev]"
```

2. **Run tests:**
```bash
pytest
```

3. **Code formatting:**
```bash
black .
isort .
```

4. **Type checking:**
```bash
mypy gmail_mcp/
```

## Building the Package

1. **Install build tools:**
```bash
pip install build twine
```

2. **Build the package:**
```bash
python -m build
```

This creates:
- `dist/datagen_gmail_mcp-*.tar.gz` (source distribution)
- `dist/datagen_gmail_mcp-*.whl` (wheel distribution)

## Testing the Built Package

1. **Test installation from wheel:**
```bash
pip install dist/datagen_gmail_mcp-*.whl
```

2. **Test the command line tool:**
```bash
datagen-datagen-gmail-mcp-server --help
```

3. **Test with uvx:**
```bash
uvx --from ./dist/datagen_gmail_mcp-*.whl datagen-datagen-gmail-mcp-server --help
```

## Publishing to PyPI

### Test PyPI (Recommended First)

1. **Upload to Test PyPI:**
```bash
twine upload --repository testpypi dist/*
```

2. **Test installation from Test PyPI:**
```bash
pip install --index-url https://test.pypi.org/simple/ datagen-gmail-mcp
```

### Production PyPI

1. **Upload to PyPI:**
```bash
twine upload dist/*
```

2. **Verify installation:**
```bash
pip install datagen-gmail-mcp
```

## Version Management

Update version in `gmail_mcp/__init__.py`:

```python
__version__ = "0.1.1"  # Update this
```

The `pyproject.toml` is configured to read version from this file.

## Release Checklist

- [ ] Update version number
- [ ] Update CHANGELOG.md (if you create one)
- [ ] Run all tests
- [ ] **Run security validation tests**
- [ ] **Verify no secrets in package files**
- [ ] **Confirm PKCE implementation is complete**
- [ ] Build the package
- [ ] Test installation locally
- [ ] Upload to Test PyPI
- [ ] Test installation from Test PyPI
- [ ] Upload to production PyPI
- [ ] Test installation from production PyPI
- [ ] Create GitHub release (if using GitHub)
- [ ] Update documentation

## uvx Compatibility

The package is designed to work with uvx out of the box:

```bash
# Install and run
uvx datagen-gmail-mcp-server

# Or run directly
uvx run datagen-gmail-mcp-server

# Specific version
uvx run datagen-gmail-mcp==0.1.0 datagen-gmail-mcp-server
```

## OAuth Configuration for Developers

Before deploying, you need to configure your Google OAuth application:

### 1. Create Google Cloud Project
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable the Gmail API

### 2. Configure OAuth Application
1. Go to "APIs & Services" > "Credentials"
2. Click "Create Credentials" > "OAuth 2.0 Client IDs"
3. **Important**: Choose "Desktop application" for Application type
4. **Do NOT generate a client secret** (this creates a public client)
5. Download the client configuration
6. Replace `YOUR_CLIENT_ID` in `gmail_mcp/auth/oauth.py` with your client ID

### 3. Public Client Configuration
The package uses a **public client** OAuth configuration:
- No client secret required or stored
- Uses PKCE for security
- Safe for distribution in public packages
- Follows Google's recommendations for installed applications

## Claude Desktop Integration

Users can add to their Claude Desktop config:

```json
{
  "mcpServers": {
    "gmail": {
      "command": "uvx",
      "args": ["datagen-gmail-mcp-server"]
    }
  }
}
```

## Troubleshooting Deployment

### Build Issues

- Ensure all required files are in MANIFEST.in
- Check pyproject.toml syntax
- Verify all dependencies are listed

### Upload Issues

- Check PyPI credentials
- Ensure version number is unique
- Verify package name availability

### Installation Issues

- Test in clean virtual environment
- Check dependency conflicts
- Verify entry points work correctly

## Security Considerations

- **PKCE Implementation**: Uses secure Proof Key for Code Exchange flow
- **No Client Secrets**: Public client design eliminates secret exposure risks
- Never include credentials in the package
- Use environment variables for sensitive config
- Validate all user inputs
- Follow OAuth 2.0 best practices for public clients
- Keep dependencies updated

## Maintenance

- Monitor for security updates in dependencies
- Update Google API client library regularly
- Test with new Python versions
- Keep MCP SDK updated
- Respond to user issues and feature requests