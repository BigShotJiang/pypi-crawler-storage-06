# DataGen Gmail MCP Server Setup Guide

This guide will walk you through setting up the Gmail MCP server for use with Claude Desktop.

## Zero-Setup Installation (Recommended)

**No Google Cloud setup required!** The Gmail MCP server now handles authentication automatically using secure PKCE (Proof Key for Code Exchange) flow.

### Step 1: Install DataGen Gmail MCP Server

Choose one of these options:

### Option A: Using uvx (Recommended)
```bash
uvx install gmail-mcp
```

### Option B: Using pip
```bash
pip install gmail-mcp
```

### Step 2: Configure Claude Desktop

### Find your Claude config file:
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%/Claude/claude_desktop_config.json`

### Add the server configuration:

**For regular installation:**
```json
{
  "mcpServers": {
    "gmail": {
      "command": "datagen-gmail-mcp-server"
    }
  }
}
```

**For uvx installation:**
```json
{
  "mcpServers": {
    "gmail": {
      "command": "uvx",
      "args": ["datagen-gmail-mcp-server"]
    }
  }
}
```

### Step 3: Restart Claude Desktop

Close and reopen Claude Desktop to load the new server configuration.

### Step 4: Start Using Gmail

The server will automatically authenticate when you first use Gmail features! Simply ask Claude:
- "How many unread emails do I have?"
- "Show me my recent emails"
- "List my Gmail labels"

The first time you use a Gmail command, Claude will:
1. Automatically open your browser
2. Ask you to sign in to Gmail
3. Save your authentication securely
4. Start working with your Gmail immediately

## Legacy Manual Setup (Optional)

If you prefer to set up your own Google Cloud credentials or need custom OAuth settings, you can still use the manual setup process.

## Troubleshooting

### Authentication Issues

If you get authentication errors:

```bash
# Test authentication
datagen-gmail-mcp-server --test-auth

# Clear saved tokens to re-authenticate
rm ~/.gmail-mcp/token.pickle
# Then restart Claude Desktop
```

### Permission Errors

With automatic authentication, OAuth scopes are pre-configured. If you experience permission issues:
1. Clear saved tokens: `rm ~/.gmail-mcp/token.pickle`
2. Restart Claude Desktop to re-authenticate with fresh permissions

### Claude Desktop Not Recognizing Server

1. Check that the config file is valid JSON
2. Restart Claude Desktop
3. Check Claude Desktop's logs for errors

### Server Won't Start

```bash
# Run with debug logging
datagen-gmail-mcp-server --log-level DEBUG
```

## Security Notes

- **Enhanced Security**: Uses PKCE (Proof Key for Code Exchange) flow
- **No Client Secrets**: Public client design eliminates credential exposure risks
- Your Gmail credentials and tokens are stored locally on your machine
- The server only accesses your Gmail account when running
- No data is sent to third parties
- You can revoke access anytime in your Google Account settings

## Advanced Configuration

### Custom Credentials Path

```json
{
  "mcpServers": {
    "gmail": {
      "command": "datagen-gmail-mcp-server",
      "args": ["--credentials", "/path/to/credentials.json"]
    }
  }
}
```

### Custom Token Directory

```json
{
  "mcpServers": {
    "gmail": {
      "command": "datagen-gmail-mcp-server",
      "args": ["--token-dir", "/path/to/tokens"]
    }
  }
}
```

### Environment Variables

You can also use environment variables:

```json
{
  "mcpServers": {
    "gmail": {
      "command": "datagen-gmail-mcp-server",
      "env": {
        "GMAIL_CREDENTIALS_PATH": "/path/to/credentials.json",
        "GMAIL_MCP_LOG_LEVEL": "DEBUG"
      }
    }
  }
}
```

## Getting Help

If you encounter issues:

1. Check the [troubleshooting section](#troubleshooting) above
2. Run with debug logging to see detailed error messages
3. Check your Google Cloud Console for API quotas and limits
4. Verify your OAuth app configuration

For additional support, see the main README.md file.