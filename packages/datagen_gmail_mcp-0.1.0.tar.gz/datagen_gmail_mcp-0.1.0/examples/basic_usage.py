#!/usr/bin/env python3
"""
Basic usage example for Gmail MCP Server.

This demonstrates how to use the Gmail MCP server programmatically
(not through Claude Desktop).
"""

import asyncio
from gmail_mcp import GmailMCPServer


async def main():
    """Example of basic Gmail MCP server usage."""

    # Initialize the server
    server = GmailMCPServer()

    # You can also specify custom paths:
    # server = GmailMCPServer(
    #     credentials_path="/path/to/credentials.json",
    #     token_dir="/path/to/token/storage"
    # )

    print("Gmail MCP Server Example")
    print("=" * 30)

    try:
        # Test authentication
        await server._ensure_authenticated()
        print("✅ Authentication successful!")

        # Example: Get profile information
        profile = server.gmail_client.service.users().getProfile(userId='me').execute()
        print(f"📧 Email: {profile.get('emailAddress')}")
        print(f"📨 Total Messages: {profile.get('messagesTotal')}")

        # Example: List recent messages
        print("\n📬 Recent Messages:")
        messages = server.gmail_client.list_messages(max_results=5)

        for i, msg_ref in enumerate(messages['messages'], 1):
            msg = server.gmail_client.get_message(msg_ref['id'], format='metadata')
            print(f"{i}. {msg.get('subject', 'No Subject')}")
            print(f"   From: {msg.get('from', 'Unknown')}")
            print(f"   Date: {msg.get('date', 'Unknown')}")
            print()

        # Example: Search for unread messages
        print("📥 Unread Messages:")
        unread = server.gmail_client.list_messages(query="is:unread", max_results=3)
        print(f"Found {len(unread['messages'])} unread messages")

        # Example: List labels
        print("\n🏷️  Labels:")
        labels_result = server.gmail_client.service.users().labels().list(userId='me').execute()
        user_labels = [l for l in labels_result['labels'] if l.get('type') == 'user']

        if user_labels:
            for label in user_labels[:5]:  # Show first 5 user labels
                print(f"   - {label['name']} ({label.get('messagesTotal', 0)} messages)")
        else:
            print("   No user-created labels found")

    except FileNotFoundError:
        print("❌ Gmail credentials not found!")
        print("Run 'datagen-gmail-mcp-server --setup' to configure authentication.")

    except Exception as e:
        print(f"❌ Error: {e}")


def test_server_tools():
    """Test that all server tools are properly defined."""

    print("\nTesting Server Tools:")
    print("=" * 30)

    server = GmailMCPServer()

    # Test that tools are properly defined
    try:
        # This would normally require authentication, but we're just testing structure
        print("✅ Server initialized successfully")
        print(f"✅ OAuth handler: {server.oauth_handler is not None}")
        print(f"✅ Gmail client: {server.gmail_client is not None}")

    except Exception as e:
        print(f"❌ Server initialization failed: {e}")


if __name__ == "__main__":
    print("Gmail MCP Server - Basic Usage Example")
    print("=" * 50)

    # Test server structure
    test_server_tools()

    # Run async example
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Example stopped by user")
    except Exception as e:
        print(f"\n❌ Example failed: {e}")