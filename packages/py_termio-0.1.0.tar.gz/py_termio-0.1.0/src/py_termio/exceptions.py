class TermError(Exception):
    """Error thrown on failing terminal operations."""

    pass
