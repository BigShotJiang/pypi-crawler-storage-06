# py-termio
A cross platform (windows and linux) set of tools for working with the terminal.