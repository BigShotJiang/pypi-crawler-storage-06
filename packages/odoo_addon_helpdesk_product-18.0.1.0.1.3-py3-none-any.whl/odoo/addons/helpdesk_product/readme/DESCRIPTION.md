This module adds the option to select product in the helpdesk tickets.
