# Bio-Bookshelf

[![PyPI version](https://badge.fury.io/py/biobookshelf.svg)](https://badge.fury.io/py/biobookshelf)

A collection of python scripts and functions for exploratory analysis of bioinformatic data in Python.
