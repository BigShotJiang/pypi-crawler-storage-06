
.. image:: https://badge.fury.io/py/galaxy-objectstore.svg
   :target: https://pypi.org/project/galaxy-objectstore/


Overview
--------

The Galaxy_ object store framework and default implementations.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
