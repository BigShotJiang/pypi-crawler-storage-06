import importlib.metadata as im

from qibojit.backends import MetaBackend

__version__ = im.version(__package__)
