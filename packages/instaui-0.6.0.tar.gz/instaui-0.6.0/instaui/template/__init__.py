from .web_template import render_web_html
from .zero_template import render_zero_html

__all__ = ["render_web_html", "render_zero_html"]
