from __future__ import annotations
from instaui.components.element import Element


class Div(Element):
    def __init__(self):
        super().__init__("div")
