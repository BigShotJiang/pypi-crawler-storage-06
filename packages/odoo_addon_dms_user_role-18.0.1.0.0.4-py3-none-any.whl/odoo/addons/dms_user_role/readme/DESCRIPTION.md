Use of roles (module base_user_role) in DMS access groups.
