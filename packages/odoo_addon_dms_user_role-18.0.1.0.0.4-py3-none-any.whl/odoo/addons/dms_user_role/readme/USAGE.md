1.  Go to Settings / Users & Companies / Roles and create a new one.
2.  Go to Documents / Configuration / Access groups and create or edit
    one.
3.  Set in the "Roles" tab the one we have just created.
4.  Go back to the role, edit it and add an extra user.
5.  The extra user will have been added in the "Users" tab.
