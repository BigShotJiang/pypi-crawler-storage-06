from physt.examples import show_examples

show_examples()
