"""STAC MCP Server - An MCP Server for STAC requests."""

__version__ = "0.3.0"
