"""
Scorpius CLI Module
Professional command-line interface for the world's strongest scanner
"""

from .main import main, cli

__all__ = ["main", "cli"]