class ItemNotRegistered(Exception):
    pass
