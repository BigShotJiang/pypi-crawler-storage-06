"""
CrysPyEditor
======

"""
name = "cryspy_editor"
__version__ = "1.7.1"

from cryspy_editor.__main__ import main

if __name__ == "__main__":
    main()
