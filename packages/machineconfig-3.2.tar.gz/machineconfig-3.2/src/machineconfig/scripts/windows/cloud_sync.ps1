uv run --python 3.13 --no-dev --project $HOME/code/machineconfig cloud_sync $args
