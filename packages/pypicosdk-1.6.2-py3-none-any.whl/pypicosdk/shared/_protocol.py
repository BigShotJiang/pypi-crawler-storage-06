"""
Copyright (C) 2025-2025 Pico Technology Ltd. See LICENSE file for terms.
"""


from typing import Protocol


class _ProtocolBase(Protocol):
    """Protocol placeholder class for shared methods"""
    def _set_ylim(self, *args, **kwargs): ...
