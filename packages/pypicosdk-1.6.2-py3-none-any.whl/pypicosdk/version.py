"""Copyright (C) 2025-2025 Pico Technology Ltd. See LICENSE file for terms."""
VERSION = "1.6.2"
