- [CorporateHub](https://corporatehub.eu/)

  - Alexey Pelykh \<<alexey.pelykh@corphub.eu>\>

- [Therp BV](https://therp.nl/)

  - Ronald Portier \<<ronald@therp.nl>\>

- Thanakrit Pintana \<<thanakrit.p39@gmail.com>\>

- [Trobz](https://trobz.com):

  > - Son Ho \<<sonho@trobz.com>\>

- [Tecnativa](https://www.tecnativa.com):
  - Carlos Roca
- `Heliconia Solutions Pvt. Ltd. <https://www.heliconia.io>`_
