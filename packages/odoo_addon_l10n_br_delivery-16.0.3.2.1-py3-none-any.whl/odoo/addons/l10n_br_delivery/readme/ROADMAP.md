- Integrar o modulo com os metódos de calculo automáticos do modulo
  delivery, hoje o usuário deve informar a Transportadora e o valor do
  Frete é informado manualmente.
