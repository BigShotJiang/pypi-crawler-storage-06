Cadastre os Métodos de Envio que poderão ser selecionados nos Pedidos de
Vendas, em:

> - Inventário \> Configuração \> Entrega \> Métodos de Envio

Veja que cada método é referente a uma Transportadora, também é possível
cadastrar os Veículos da Transportadora em:

> - Inventário \> Configuração \> Entrega \> Veículo
