__version__ = "0.12.0"


def get_version() -> str:
    return __version__
