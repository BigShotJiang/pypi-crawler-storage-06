def makeAdminBackendHandlers(dbSessionCreator):
    return []
