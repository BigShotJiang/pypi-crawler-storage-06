from enum import Enum

class MouseButton(Enum):
    LEFT = 0
    RIGHT = 1
    MIDDLE = 2
    MOUSE4 = 3
    MOUSE5 = 4