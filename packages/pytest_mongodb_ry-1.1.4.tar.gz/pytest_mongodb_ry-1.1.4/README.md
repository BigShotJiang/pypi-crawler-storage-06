# pytest-mongodb

该插件适用于pytest框架与mongodb连接访问，将测试用例上传至mongodb使用