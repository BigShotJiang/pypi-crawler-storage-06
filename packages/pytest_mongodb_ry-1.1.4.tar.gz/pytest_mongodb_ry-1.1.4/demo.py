


# import pyotp
#
from pytest_mongodb_ry.plugin import MongoClient


key = 'VLS2A4EAV3XYNMO5K5V7R32XEAKX5J2C'

# totp = pyotp.TOTP(key)

