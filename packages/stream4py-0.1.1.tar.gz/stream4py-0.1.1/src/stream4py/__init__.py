from stream4py.functional import Stream

__all__ = ["Stream"]
