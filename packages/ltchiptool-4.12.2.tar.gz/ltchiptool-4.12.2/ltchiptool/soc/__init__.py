# Copyright (c) Kuba Szczodrzyński 2022-07-29.

from .common import SocInterfaceCommon
from .interface import SocInterface

__all__ = [
    "SocInterface",
    "SocInterfaceCommon",
]
