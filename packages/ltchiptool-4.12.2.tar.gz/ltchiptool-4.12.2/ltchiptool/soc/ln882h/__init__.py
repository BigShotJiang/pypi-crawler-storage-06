# Copyright (c) Etienne Le Cousin 2025-01-02.

from .main import LN882hMain

__all__ = [
    "LN882hMain",
]
