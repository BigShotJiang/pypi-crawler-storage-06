# Copyright (c) Kuba Szczodrzyński 2022-07-29.

from .main import AmebaZMain

__all__ = [
    "AmebaZMain",
]
