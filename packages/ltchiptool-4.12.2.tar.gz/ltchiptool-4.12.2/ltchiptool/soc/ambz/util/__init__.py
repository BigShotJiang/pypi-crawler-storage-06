# Copyright (c) Kuba Szczodrzyński 2022-07-29.
