# Copyright (c) Kuba Szczodrzyński 2022-07-29.

from .main import BK72XXMain

__all__ = [
    "BK72XXMain",
]
