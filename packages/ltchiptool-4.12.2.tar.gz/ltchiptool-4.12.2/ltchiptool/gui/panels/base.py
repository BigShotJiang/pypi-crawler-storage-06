#  Copyright (c) Kuba Szczodrzyński 2023-6-21.

from ltchiptool.gui.base.panel import BasePanel

__all__ = [
    "BasePanel",
]
