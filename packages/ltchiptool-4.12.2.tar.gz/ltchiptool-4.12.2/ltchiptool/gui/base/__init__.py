#  Copyright (c) Kuba Szczodrzyński 2023-11-28.
