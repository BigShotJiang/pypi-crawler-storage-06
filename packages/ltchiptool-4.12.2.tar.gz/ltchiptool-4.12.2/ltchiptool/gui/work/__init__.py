#  Copyright (c) Kuba Szczodrzyński 2023-1-9.
