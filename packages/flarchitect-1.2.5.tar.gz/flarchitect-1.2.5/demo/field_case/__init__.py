"""Demo application showcasing API field casing options."""

from .app import Person, create_app, db

__all__ = ["create_app", "db", "Person"]
