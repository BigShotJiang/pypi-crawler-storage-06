# vim: set ts=4
#
# Copyright 2025-present Linaro Limited
#
# SPDX-License-Identifier: MIT


def test_nothing():
    """Dummy test to make pytest pass."""
    pass
