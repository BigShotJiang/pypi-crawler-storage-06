# vim: set ts=4
#
# Copyright 2025-present Linaro Limited
#
# SPDX-License-Identifier: MIT

import sys

from laam import main

if __name__ == "__main__":
    sys.exit(main())
