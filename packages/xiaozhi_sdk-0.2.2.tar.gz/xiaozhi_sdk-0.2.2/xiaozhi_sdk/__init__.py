__version__ = "0.2.2"

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
