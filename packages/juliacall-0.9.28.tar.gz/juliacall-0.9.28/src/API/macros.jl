# Core
macro pyconst end
macro pyeval end
macro pyexec end

# Convert
macro pyconvert end

# PyMacro
macro py end
