"""Odoo Backup Tool Package"""
__version__ = "0.1.2"