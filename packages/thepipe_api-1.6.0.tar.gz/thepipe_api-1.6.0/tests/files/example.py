class ExampleClass:
    def greet():
        print("Hello, World!")


ExampleClass.greet()
