#ifndef GREET_H
#define GREET_H

void greet();

#endif