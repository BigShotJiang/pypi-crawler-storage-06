mcp-name: io.github.tedfytw1209/mcp-server-EVEfleet
