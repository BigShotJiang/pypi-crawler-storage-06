"""
Development and utility scripts for the trading bot.
"""