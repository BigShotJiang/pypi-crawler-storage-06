__version__ = "0.7"

def info():
    return "This is a dummy libopenblas package for PyPI."
