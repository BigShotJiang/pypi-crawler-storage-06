# libopenblas\nA dummy Python package version of libopenblas.
