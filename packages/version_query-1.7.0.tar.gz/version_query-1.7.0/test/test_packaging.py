"""Tests for packaging."""

import boilerplates.packaging_tests


class Tests(boilerplates.packaging_tests.PackagingTests):
    pass
