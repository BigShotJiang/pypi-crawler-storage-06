"""Version of version_query package."""

from version_query import predict_version_str

VERSION = predict_version_str()
