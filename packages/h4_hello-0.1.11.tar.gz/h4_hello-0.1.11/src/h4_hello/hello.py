def hello() -> str:
    return "Hello!"
