"""
Entry point for running envseal as a module: python -m envseal
"""

from .cli import main

if __name__ == "__main__":
    main()
