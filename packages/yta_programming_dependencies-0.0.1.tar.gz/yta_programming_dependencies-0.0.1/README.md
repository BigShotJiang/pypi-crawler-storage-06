# Youtube Autonomous Programming Dependencies add-on

The way to work internally with some of the functionalities we need related to handling dependencies.