This is a pretty useful tool to update Odoo installations after tax
reforms on the official charts of accounts, or to apply fixes performed
on the chart template.

The wizard:

- Allows the user to compare a chart and a template showing differences
  on accounts, taxes, tax codes and fiscal positions.
- It may create the new account, taxes, tax codes and fiscal positions
  detected on the template.
- It can also update (overwrite) the accounts, taxes, tax codes and
  fiscal positions that got modified on the template.
