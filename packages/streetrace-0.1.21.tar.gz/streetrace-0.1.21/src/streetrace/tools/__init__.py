"""StreetRace🚗💨 built-in tools.

Most of these tools can be replaced with MCP alternatives, but they are not
always optimal. I.e., for a coder, I don't want to show any .gitignore files
or folders, and I want to inject the working directory into tools.
"""
