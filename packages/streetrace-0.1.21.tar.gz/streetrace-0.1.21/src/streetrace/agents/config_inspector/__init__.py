"""Config inspector agent."""
