"""UI components for the Streetrace application.

This package contains user interface components for rendering conversation
history, command output, and other visual elements in the console UI.
"""
