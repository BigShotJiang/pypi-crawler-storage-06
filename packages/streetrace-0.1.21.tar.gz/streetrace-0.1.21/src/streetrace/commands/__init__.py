"""Commands package for the Streetrace application.

This package contains command definitions and command execution infrastructure
for slash commands like /exit, /history, and others.
"""
