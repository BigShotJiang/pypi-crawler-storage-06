# External Example

这是一个如何为本插件增加自定义内容的插件示例

你可以直接把此文件夹当做插件包扔给 nonebot2 加载，并按照下方说明更改配置项查看效果

```properties
PS_TEMPLATE=example_template
PS_BG_PROVIDER=lgc_icon
```
