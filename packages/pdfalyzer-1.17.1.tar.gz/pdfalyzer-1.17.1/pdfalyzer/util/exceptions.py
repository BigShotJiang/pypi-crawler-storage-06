class PdfWalkError(RuntimeError):
    """For errors that arise while walking the document tree"""
