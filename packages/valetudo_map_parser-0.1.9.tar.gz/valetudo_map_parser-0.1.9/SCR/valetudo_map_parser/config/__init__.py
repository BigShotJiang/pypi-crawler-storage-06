"""Configuration module for the SCR package."""
