from sempy_functions_geopandas._geopandas import to_geopandas

__all__ = [
    "to_geopandas",
]
