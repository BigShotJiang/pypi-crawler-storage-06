"""CLI tool for pydantic-rpc."""

__version__ = "0.10.0"
