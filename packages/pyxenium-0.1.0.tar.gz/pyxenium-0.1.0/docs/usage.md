## Usage

```bash
pip install myxenium
myxenium demo
```
