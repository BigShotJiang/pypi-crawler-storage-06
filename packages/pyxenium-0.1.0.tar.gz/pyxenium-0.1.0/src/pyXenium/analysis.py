def toy_pipeline():
    print('Run analysis pipeline here')
