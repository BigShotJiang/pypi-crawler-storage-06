# Phylogenetic inference using Phylo2Vec

This module is currently not under active development. Hill-climbing
optimisation ("\_hc") is left here as part of our publication
(<https://doi.org/10.1093/sysbio/syae030>). We plan to include
[GradME](https://github.com/Neclow/GradME) and other suitable phylogenetic tree
optimisation schemes in the future.

Contributions are welcome!
