from . import test_stock_rule_reservation
