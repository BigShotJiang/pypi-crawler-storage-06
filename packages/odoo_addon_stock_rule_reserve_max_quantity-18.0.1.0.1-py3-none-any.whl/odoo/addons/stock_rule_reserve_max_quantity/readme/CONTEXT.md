This module was developed because if you want to send variable product weights with Warehouse configured with 2 or 3 steps for Outgoing Shipments, you have to double check the quantity done on every picking if the quantity done exceedes the demand quantity.

It will be useful for you if you want to auto-reserve all the quantities done in the last steps for Outgoing Shipments.
