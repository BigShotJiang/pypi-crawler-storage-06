"""Simulation module for Laflammscape.

This module provides the simulation orchestrator and state transition
components for running landscape simulations.
"""
