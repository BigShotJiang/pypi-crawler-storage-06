"""Output module for Laflammscape.

This module provides functionality for exporting simulation results,
generating visualizations, and performing analysis.
"""
