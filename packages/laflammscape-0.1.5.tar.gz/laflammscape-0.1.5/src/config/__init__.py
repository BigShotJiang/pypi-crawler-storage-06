"""Configuration management module for Laflammscape.

This module provides functionality for loading, validating, and tracking
configuration settings for simulations.
"""
