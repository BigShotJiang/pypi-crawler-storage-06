"""State representation module for Laflammscape.

This module provides data structures and utilities for representing
landscape state and its evolution over time.
"""
