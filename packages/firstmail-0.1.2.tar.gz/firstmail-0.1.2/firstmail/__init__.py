from .base import FirstMail, EmailMessage, firstmail_client

VERSION = "0.1.2"

__all__ = ["FirstMail", "EmailMessage", "firstmail_client"]
