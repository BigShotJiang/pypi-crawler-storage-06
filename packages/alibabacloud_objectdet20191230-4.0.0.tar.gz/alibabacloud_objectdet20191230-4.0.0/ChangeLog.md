2023-01-11 Version: 3.0.9
- Update sdk.

2022-12-15 Version: 3.0.8
- Update DetectVehicleICongestion DetectVehicleIllegalParking.

2022-10-17 Version: 3.0.7
- Update DetectVehicleICongestion DetectVehicleIllegalParking.

2022-09-29 Version: 3.0.6
- Update DetectVehicleICongestion DetectVehicleIllegalParking.

2021-11-15 Version: 3.0.5
- Update DetectVehicleICongestion DetectVehicleIllegalParking.

2021-11-01 Version: 3.0.4
- Release DetectKitchenAnimals DetectWorkwear.

2021-04-08 Version: 3.0.3
- Add DetectIPCVideoObject.

2021-03-10 Version: 3.0.2
- AMP Version Change.

2021-02-04 Version: 3.0.1
- Update DetectVehicleIllegalParking DetectVehicleICongestion.

2021-02-01 Version: 3.0.0
- Release DetectVehicleIllegalParking DetectVehicleICongestion.

2020-12-30 Version: 2.0.0
- AMP Version Change.

