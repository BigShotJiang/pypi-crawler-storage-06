def main():
    with open("test.txt", "w") as f:
        f.write("test")
    print("test")

if __name__ == "__main__":
    main()