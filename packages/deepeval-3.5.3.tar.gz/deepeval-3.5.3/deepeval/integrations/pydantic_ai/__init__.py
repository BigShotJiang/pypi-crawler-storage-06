from .patcher import instrument as instrument_pydantic_ai

__all__ = ["instrument_pydantic_ai"]
