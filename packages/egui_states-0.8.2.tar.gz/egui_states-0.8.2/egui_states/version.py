VERSION = "0.8.2"
__version__ = VERSION
