from django.apps import AppConfig


class DatasetsConfig(AppConfig):
    name = 'localcosmos_server.datasets'
