"""
Talk to Your PC - MCP Server

A Model Context Protocol server for PC system management and troubleshooting.
"""

__version__ = "0.1.0"
__author__ = "Irene-123"

from .server import main

__all__ = ["main"]