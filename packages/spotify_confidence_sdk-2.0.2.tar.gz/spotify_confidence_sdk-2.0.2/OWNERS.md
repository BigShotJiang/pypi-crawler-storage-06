# Owners

- See [CONTRIBUTING.md](CONTRIBUTING.md) for general contribution guidelines.

## Core Developers

- Johan Rydberg (Spotify)
- Mattias Frånberg (mfranberg, Spotify)
- Nicklas Lundin (nicklasl, Spotify)