# maksim_132

Библиотека для управления сервомотором через Arduino.

## Установка

```bash
pip install maksim_132