from typing import Optional

import numpy as np
from scipy.interpolate import CubicSpline
from sklearn.base import BaseEstimator, TransformerMixin, OneToOneFeatureMixin
from sklearn.utils.validation import check_is_fitted, validate_data


class CubicSplineCorrection(TransformerMixin, OneToOneFeatureMixin, BaseEstimator):
    """
    A transformer that corrects a baseline by subtracting a cubic spline through the
    points defined by the indices.

    Parameters
    ----------
    indices : list, optional
        The indices of the features to use for the baseline correction.

    Attributes
    ----------
    n_features_in_ : int
        The number of features in the input data.

    _is_fitted : bool
        Whether the transformer has been fitted to data.

    Methods
    -------
    fit(X, y=None)
        Fit the transformer to the input data.

    transform(X, y=0, copy=True)
        Transform the input data by subtracting the constant baseline value.

    _spline_baseline_correct(x)
        Internal method: compute the baseline for a single spectrum.

    Examples
    --------
    >>> from chemotools.baseline import CubicSplineCorrection
    >>> import numpy as np
    >>> X = np.array([[1, 2, 3, 4, 5]])
    >>> csc = CubicSplineCorrection(indices=[0, 4])
    >>> X_corrected = csc.fit_transform(X)
    """

    def __init__(self, indices: Optional[list] = None) -> None:
        self.indices = indices

    def fit(self, X: np.ndarray, y=None) -> "CubicSplineCorrection":
        """
        Fit the transformer to the input data.

        Parameters
        ----------
        X : np.ndarray of shape (n_samples, n_features)
            The input data to fit the transformer to.

        y : None
            Ignored.

        Returns
        -------
        self : ConstantBaselineCorrection
            The fitted transformer.
        """
        # Check that X is a 2D array and has only finite values
        X = validate_data(
            self, X, y="no_validation", ensure_2d=True, reset=True, dtype=np.float64
        )

        if self.indices is None:
            self.indices_ = [0, len(X[0]) - 1]
        else:
            self.indices_ = self.indices

        return self

    def transform(self, X: np.ndarray, y=None, copy=True) -> np.ndarray:
        """
        Transform the input data by subtracting the baseline.

        Parameters
        ----------
        X : np.ndarray of shape (n_samples, n_features)
            The input data to transform.

        y : None
            Ignored.

        copy : bool, optional
            Whether to copy the input data or not.

        Returns
        -------
        X_ : np.ndarray of shape (n_samples, n_features)
            The transformed data.
        """
        # Check that the estimator is fitted
        check_is_fitted(self, "indices_")

        # Check that X is a 2D array and has only finite values
        X_ = validate_data(
            self,
            X,
            y="no_validation",
            ensure_2d=True,
            copy=True,
            reset=False,
            dtype=np.float64,
        )

        # Calculate spline baseline correction
        for i, x in enumerate(X_):
            X_[i] = self._spline_baseline_correct(x)
        return X_.reshape(-1, 1) if X_.ndim == 1 else X_

    def _spline_baseline_correct(self, x: np.ndarray) -> np.ndarray:
        indices = self.indices_
        intensity = x[indices]
        spl = CubicSpline(indices, intensity)
        baseline = spl(range(len(x)))
        return x - baseline
