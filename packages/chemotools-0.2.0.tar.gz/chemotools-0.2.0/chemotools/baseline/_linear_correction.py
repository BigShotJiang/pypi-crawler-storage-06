import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin, OneToOneFeatureMixin
from sklearn.utils.validation import check_is_fitted, validate_data


class LinearCorrection(TransformerMixin, OneToOneFeatureMixin, BaseEstimator):
    """
    A transformer that corrects a baseline by subtracting a linear baseline through the
    initial and final points of the spectrum.

    Methods
    -------
    fit(X, y=None)
        Fit the transformer to the input data.

    transform(X, y=0, copy=True)
        Transform the input data by subtracting the constant baseline value.

    _drift_correct_spectrum(x)
        Internal method: compute the baseline for a single spectrum.

    Examples
    --------
    >>> from chemotools.baseline import LinearCorrection
    >>> import numpy as np
    >>> X = np.array([[1, 2, 3, 4, 5]])
    >>> lc = LinearCorrection()
    >>> X_corrected = lc.fit_transform(X)
    """

    def fit(self, X: np.ndarray, y=None) -> "LinearCorrection":
        """
        Fit the transformer to the input data.

        Parameters
        ----------
        X : np.ndarray of shape (n_samples, n_features)
            The input data to fit the transformer to.

        y : None
            Ignored.

        Returns
        -------
        self : ConstantBaselineCorrection
            The fitted transformer.
        """
        # Check that X is a 2D array and has only finite values
        X = validate_data(
            self, X, y="no_validation", ensure_2d=True, reset=True, dtype=np.float64
        )

        return self

    def transform(self, X: np.ndarray, y=0, copy=True) -> np.ndarray:
        """
        Transform the input data by subtracting the constant baseline value.

        Parameters
        ----------
        X : np.ndarray of shape (n_samples, n_features)
            The input data to transform.

        y : int, float, optional
            Ignored.

        copy : bool, optional
            Whether to copy the input data or not.

        Returns
        -------
        X_ : np.ndarray of shape (n_samples, n_features)
            The transformed data.
        """
        # Check that the estimator is fitted
        check_is_fitted(self, "n_features_in_")

        # Check that X is a 2D array and has only finite values
        X_ = validate_data(
            self,
            X,
            y="no_validation",
            ensure_2d=True,
            copy=True,
            reset=False,
            dtype=np.float64,
        )

        # Calculate non-negative values
        for i, x in enumerate(X_):
            X_[i, :] = self._drift_correct_spectrum(x)
        return X_.reshape(-1, 1) if X_.ndim == 1 else X_

    def _drift_correct_spectrum(self, x: np.ndarray) -> np.ndarray:
        # Can take any array and returns with a linear baseline correction
        # Find the x values at the edges of the spectrum
        y1: float = x[0]
        y2: float = x[-1]

        # Find the max and min wavenumebrs
        x1 = 0
        x2 = len(x)
        x_range = np.linspace(x1, x2, x2)

        # Calculate the straight line initial and end point
        slope = (y2 - y1) / (x2 - x1)
        intercept = y1 - slope * x1
        drift_correction = slope * x_range + intercept

        # Return the drift corrected spectrum
        return x - drift_correction
