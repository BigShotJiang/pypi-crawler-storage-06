# Test compliance with scikit-learn
# Note that this test is commented out because it currently fails. You can uncomment it
# and run it to check compliance once the issues are resolved.
# def test_compliance_gaussian_broadening():
#    # Arrange
#    transformer = GaussianBroadening()
#    # Act & Assert
#    check_estimator(transformer)
