# Security Policy

## Supported Versions

Security updates are always made for the latest version of this component.  

## Reporting a Vulnerability

Security issues with this component should be reported to the maintainer.

If in the course of using this tool you discover a security issue with someone else's code, please disclose responsibly to the appropriate party.
