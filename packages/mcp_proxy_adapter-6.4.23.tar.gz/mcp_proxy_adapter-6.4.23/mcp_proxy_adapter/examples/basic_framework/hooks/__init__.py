"""Basic Framework Hooks.

Hooks for the basic framework example.
"""
