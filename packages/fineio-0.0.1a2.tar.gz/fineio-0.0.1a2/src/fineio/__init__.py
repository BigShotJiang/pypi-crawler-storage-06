# __init__.py
from .executor import run
from .shutdown import shutdown

__version__ = "0.0.1a2"
