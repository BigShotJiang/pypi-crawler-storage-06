"""fastapi_router_viz

Utilities to introspect a FastAPI application and visualize its routing tree.
"""
from .version import __version__  # noqa: F401
