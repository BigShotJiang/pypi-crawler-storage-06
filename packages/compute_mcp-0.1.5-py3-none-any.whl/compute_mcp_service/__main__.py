from src.compute_mcp_service import main
main()