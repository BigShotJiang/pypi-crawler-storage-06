from .addon_anthropic_sse import AddonAnthropicSSEMarker
from .addon_anthropic_view import RegisterAnthropicView
addons = [AddonAnthropicSSEMarker(), RegisterAnthropicView()]
