"""Init file for VSS CLI (vss-cli)."""
