class LibXRInfo:
    COMMIT = 'f3e73fccb2e702ff0a5d319d41b33136d69179c6'
