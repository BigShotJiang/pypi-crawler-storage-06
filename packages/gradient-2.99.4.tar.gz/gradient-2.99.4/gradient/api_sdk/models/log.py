from collections import namedtuple

LogRow = namedtuple("LogRow", "line message timestamp")
