from gradient.cli.cli import cli as _cli_entry_point


def main():
    _cli_entry_point()
