"""
Hook system for the Crow build system
"""

from .hooks import HookContext

ctx = HookContext()
