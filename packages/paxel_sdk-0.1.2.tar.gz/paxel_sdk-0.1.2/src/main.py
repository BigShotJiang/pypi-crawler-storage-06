print("If you installed this `paxel-sdk` library, you are probably looking for an internal WCC `paxel-sdk` library.")
