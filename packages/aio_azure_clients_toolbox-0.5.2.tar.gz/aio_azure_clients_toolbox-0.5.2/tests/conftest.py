# # # # # # # # # # # # # # # # # #
# Use fixtures provided by library
# # # # # # # # # # # # # # # # # #

pytest_plugins = [
    "aio_azure_clients_toolbox.testing_utils.fixtures",
]
