# coding:utf-8

__project__ = "xkits-network"
__version__ = "0.1.alpha.1"
__urlhome__ = "https://github.com/bondbox/xcommand/"
__description__ = "Automatically created by xkits-command."

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
