"""Prebuilt UI widgets for SIDS."""
