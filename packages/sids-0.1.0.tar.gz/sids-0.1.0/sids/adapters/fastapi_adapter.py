"""FastAPI integration for SIDS."""
