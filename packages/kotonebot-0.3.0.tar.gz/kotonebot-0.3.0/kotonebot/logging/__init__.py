from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL, basicConfig
from .log import getLogger, enable_verbose, LEVEL_VERBOSE as VERBOSE
