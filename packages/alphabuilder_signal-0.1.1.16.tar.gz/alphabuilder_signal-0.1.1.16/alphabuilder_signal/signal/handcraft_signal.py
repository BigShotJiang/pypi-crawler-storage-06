import pandas as pd
import numpy as np
from src import fetch_data
from utils import techindi

