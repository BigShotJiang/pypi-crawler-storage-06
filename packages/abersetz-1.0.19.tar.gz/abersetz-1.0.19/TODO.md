---
this_file: TODO.md
---
## Active TODO Items
- [ ] Add CLI regression test covering the missing target-language guard in `_build_options_from_cli`.
- [ ] Add CLI regression test confirming `prolog`/`voc` JSON inputs populate `TranslatorOptions`.
- [ ] Add CLI regression test asserting `save_voc`/`write_over` and chunk-size flags propagate to `TranslatorOptions`.
