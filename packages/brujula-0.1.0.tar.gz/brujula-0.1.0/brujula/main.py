def hello_world():
    """A simple hello world function."""
    return "Hello, world!"


def main():
    """Main entry point for the brujula package."""
    print(hello_world())


if __name__ == "__main__":
    main()
