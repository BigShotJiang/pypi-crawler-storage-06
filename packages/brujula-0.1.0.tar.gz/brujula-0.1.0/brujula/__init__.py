"""Brujula - A simple hello world Python package."""

from .main import hello_world

__version__ = "0.1.0"
__all__ = ["hello_world"]
