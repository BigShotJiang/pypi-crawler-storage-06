2025-05-14 Version: 1.1.1
- Update API CreatePlayingList: add response parameters Body.Code.
- Update API CreatePlayingList: add response parameters Body.Message.


2025-05-14 Version: 1.1.1
- Update API CreatePlayingList: add response parameters Body.Code.
- Update API CreatePlayingList: add response parameters Body.Message.


2025-04-22 Version: 1.1.0
- Support API CreatePlayingList.


2025-04-07 Version: 1.0.0
- Generated python oauth2_1.0 for AliGenie.

