"""CLI package for prefect-aws infrastructure deployment."""
