var class_py_x_make_1_1_plugin_1_1____poetry_1_1_plugin =
[
    [ "activate", "class_py_x_make_1_1_plugin_1_1____poetry_1_1_plugin.html#a446076f8933e8ddf60cdd056b62464e2", null ]
];