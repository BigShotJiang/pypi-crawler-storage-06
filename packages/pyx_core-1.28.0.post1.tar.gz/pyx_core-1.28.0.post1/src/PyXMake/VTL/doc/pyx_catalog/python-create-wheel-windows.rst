------------------------------------------
Create a python platform wheel for Windows
------------------------------------------

.. literalinclude:: ../../../templates/python-create-wheel-windows/template.yml
   :language: yaml