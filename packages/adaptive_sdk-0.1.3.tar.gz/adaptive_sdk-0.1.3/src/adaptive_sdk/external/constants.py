from typing import Final

SCORE_PATH: Final = "/score"
BATCH_SCORE_PATH: Final = "/batch_score"
INFO_PATH: Final = "/info"
VALIDATE_METADATA: Final = "/validate_metadata"
BATCH_VALIDATE_METADATA: Final = "/batch_validate_metadata"
METADATA_SCHEMA_PATH: Final = "/metadata_schema"
