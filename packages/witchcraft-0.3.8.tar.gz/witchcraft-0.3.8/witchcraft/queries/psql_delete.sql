DELETE FROM :schema_name.:table_name;
