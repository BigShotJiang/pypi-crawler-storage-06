__version__ = "0.17.1"
VERSION = __version__  # synonym
