GEOMETRY_DATA_TYPES = [
    "gml:MultiPolygonPropertyType",
    "gml:MultiSurfacePropertyType",
    "gml:PolygonPropertyType",
    "gml:SurfacePropertyType",
    "gml:MultiLineStringPropertyType",
    "gml:MultiCurvePropertyType",
    "gml:LineStringPropertyType",
    "gml:GeometryPropertyType",
    "gml:CurvePropertyType",
    "gml:PointPropertyType",
    "gml:MultiPointPropertyType"
]
