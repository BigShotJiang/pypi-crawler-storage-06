from ows_lib.client.wfs.mixins import WebFeatureServiceMixin


class WebFeatureService(WebFeatureServiceMixin):

    type_name_qp = "TYPENAMES"
    output_format_qp = "OUTPUTFORMAT"
