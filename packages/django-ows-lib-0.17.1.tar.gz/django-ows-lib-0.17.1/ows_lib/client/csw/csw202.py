from ows_lib.client.csw.mixins import CatalogueServiceMixin


class CatalogueService(CatalogueServiceMixin):
    pass
