
"""Create a dummy IntensityScaleShift3D class simply for API coherence"""
from ..transforms import IntensityScaleShift

IntensityScaleShift3D = IntensityScaleShift
