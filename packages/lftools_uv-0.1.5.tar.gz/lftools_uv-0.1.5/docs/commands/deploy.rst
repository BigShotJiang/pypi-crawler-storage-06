.. SPDX-FileCopyrightText: 2025 The Linux Foundation
..
.. SPDX-License-Identifier: EPL-1.0

******
deploy
******

.. program-output:: lftools-uv deploy --help

Commands
========



archives
--------

.. program-output:: lftools-uv deploy archives --help

copy-archives
-------------

.. program-output:: lftools-uv deploy copy-archives --help

logs
----

.. program-output:: lftools-uv deploy logs --help

maven-file
----------

.. program-output:: lftools-uv deploy maven-file --help

nexus
-----

.. program-output:: lftools-uv deploy nexus --help

nexus-stage
-----------

.. program-output:: lftools-uv deploy nexus-stage --help

nexus-zip
---------

.. program-output:: lftools-uv deploy nexus-zip --help
