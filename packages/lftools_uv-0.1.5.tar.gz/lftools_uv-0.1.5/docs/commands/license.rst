.. SPDX-FileCopyrightText: 2025 The Linux Foundation
..
.. SPDX-License-Identifier: EPL-1.0

*******
license
*******

.. program-output:: lftools-uv license --help

Commands
========



check
-----

.. program-output:: lftools-uv license check --help
