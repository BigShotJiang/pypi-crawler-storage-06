.. SPDX-FileCopyrightText: 2025 The Linux Foundation
..
.. SPDX-License-Identifier: EPL-1.0

*******
version
*******

.. program-output:: lftools-uv version --help

Commands
========



bump
----

.. program-output:: lftools-uv version bump --help

patch
-----

.. program-output:: lftools-uv version patch --help

release
-------

.. program-output:: lftools-uv version release --help
