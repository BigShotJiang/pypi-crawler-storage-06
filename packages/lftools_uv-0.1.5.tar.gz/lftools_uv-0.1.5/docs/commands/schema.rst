.. SPDX-FileCopyrightText: 2025 The Linux Foundation
..
.. SPDX-License-Identifier: EPL-1.0

******
schema
******

.. program-output:: lftools-uv schema --help

Commands
========

verify
-------

.. program-output:: lftools-uv schema verify --help
