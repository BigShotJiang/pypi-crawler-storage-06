# Test configuration for azuredevops-tools
