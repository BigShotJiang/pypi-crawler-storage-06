
"""
Main entry point for the Azure DevOps Tools MCP server.
This is a backwards compatibility wrapper.
"""

from src.azuredevops_tools.main import main

if __name__ == "__main__":
    main()
