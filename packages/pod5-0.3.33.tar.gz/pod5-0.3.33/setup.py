"""
pod5 setup.py
Proprietary and confidential information of Oxford Nanopore Technologies plc
All rights reserved; (c)2022: Oxford Nanopore Technologies plc

This script can either install a development version of pod5 to the current
Python environment, or create a Python wheel.

"""

import setuptools

if __name__ == "__main__":
    setuptools.setup()
