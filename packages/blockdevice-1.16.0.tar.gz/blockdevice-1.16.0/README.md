
# Blockdevice

[![Build](https://github.com/Omena0/blockdevice/actions/workflows/publish.yml/badge.svg)](https://github.com/Omena0/blockdevice/actions/workflows/publish.yml)
[![pytest](https://github.com/Omena0/blockdevice/actions/workflows/pytest.yml/badge.svg)](https://github.com/Omena0/blockdevice/actions/workflows/pytest.yml)

Simple library for creating Block Devices.
