#!/usr/bin/env python
# -*- coding: utf-8 -*-

# run as a module using "python -m acertmgr"
# Copyright (c) Rudolf Mayerhofer, 2019.
# available under the ISC license, see LICENSE

import acertmgr

if __name__ == "__main__":
    acertmgr.main()
