from typing import Optional, List, Dict
import json
from weaviate_cli.utils import older_than_version, parse_permission
from weaviate import WeaviateClient
from weaviate.rbac.models import Role, RoleBase
from weaviate_cli.defaults import (
    CreateRoleDefaults,
    DeleteRoleDefaults,
    GetRoleDefaults,
)


class RoleManager:
    def __init__(self, client: WeaviateClient):
        self.client = client

    def create_role(
        self,
        role_name: str = CreateRoleDefaults.role_name,
        permissions: tuple = CreateRoleDefaults.permission,
    ) -> None:
        try:
            rbac_permissions = []
            for perm in permissions:
                parsed = parse_permission(perm)
                if isinstance(parsed, list):
                    rbac_permissions.extend(parsed)
                else:
                    rbac_permissions.append(parsed)

            self.client.roles.create(role_name=role_name, permissions=rbac_permissions)

        except Exception as e:
            raise Exception(f"Error creating role '{role_name}': {e}")

    def get_role(self, role_name: str) -> Optional[Role]:
        try:
            return self.client.roles.get(role_name=role_name)
        except Exception as e:
            raise Exception(f"Error getting role '{role_name}': {e}")

    def get_roles_from_user(
        self, user_name: str, user_type: str = GetRoleDefaults.user_type
    ) -> Dict[str, RoleBase]:
        try:
            if older_than_version(self.client, "1.30.0"):
                return self.client.users.get_assigned_roles(user_id=user_name)
            if user_type == "db":
                return self.client.users.db.get_assigned_roles(
                    user_id=user_name, include_permissions=False
                )
            elif user_type == "oidc":
                return self.client.users.oidc.get_assigned_roles(
                    user_id=user_name, include_permissions=False
                )
        except Exception as e:
            raise Exception(
                f"Error getting roles from {user_type} user '{user_name}': {e}"
            )

    def delete_role(self, role_name: str = DeleteRoleDefaults.role_name) -> None:
        try:
            if not self.client.roles.exists(role_name=role_name):
                raise Exception(f"Role '{role_name}' does not exist.")
            self.client.roles.delete(role_name=role_name)
            assert not self.client.roles.exists(role_name=role_name)
        except Exception as e:
            raise Exception(f"Error deleting role '{role_name}': {e}")

    def get_all_roles(self) -> Dict[str, Role]:
        try:
            return self.client.roles.list_all()
        except Exception as e:
            raise Exception(f"Error getting all roles: {e}")

    def role_of_current_user(self) -> Dict[str, Role]:
        """Get the role of the current user."""
        try:
            return self.client.users.get_my_user().roles
        except Exception as e:
            raise Exception(f"Error getting role of current user: {e}")

    def add_permission(self, permission: str, role_name: str) -> None:
        try:
            rbac_permissions = []
            for perm in permission:
                parsed = parse_permission(perm)
                rbac_permissions = rbac_permissions + parsed
            self.client.roles.add_permissions(
                permissions=rbac_permissions, role_name=role_name
            )
        except Exception as e:
            raise Exception(
                f"Error adding permission '{permission}' to role '{role_name}': {e}"
            )

    def revoke_permission(self, permission: str, role_name: str) -> None:
        try:
            rbac_permissions = []
            for perm in permission:
                parsed = parse_permission(perm)
                rbac_permissions = rbac_permissions + parsed
            self.client.roles.remove_permissions(
                permissions=rbac_permissions, role_name=role_name
            )
        except Exception as e:
            raise Exception(
                f"Error revoking permission '{permission}' from role '{role_name}': {e}"
            )

    def print_role(self, role: Optional[Role] = None) -> None:
        """Print a role and its permissions in a human readable format."""
        if not role:
            raise ValueError("The role does not exist.")

        separator = "-" * 50
        print(f"\n{separator}")
        print(f"Role: {role.name}")

        if role.cluster_permissions:
            print("\nCluster Actions:")
            for perm in role.cluster_permissions:
                print(f"  - {', '.join([action.value for action in perm.actions])}")

        if role.nodes_permissions:
            print("\nNodes Permissions:")
            for perm in role.nodes_permissions:
                print(
                    f"  - Verbosity: {perm.verbosity}, Collection: {perm.collection if perm.collection else '*'}, Action: {', '.join([action.value for action in perm.actions])}"
                )

        if role.backups_permissions:
            print("\nBackups Permissions:")
            for perm in role.backups_permissions:
                print(
                    f"  - Collection: {perm.collection}, Action: {', '.join([action.value for action in perm.actions])}"
                )

        if role.roles_permissions:
            print("\nRoles Permissions:")
            for perm in role.roles_permissions:
                print(
                    f"  - Role: {perm.role}, Action: {', '.join([action.value for action in perm.actions])}, Scope: {perm.scope}"
                )

        if role.users_permissions:
            print("\nUsers Permissions:")
            for perm in role.users_permissions:
                print(
                    f"  - User: {perm.users}, Action: {', '.join([action.value for action in perm.actions])}"
                )

        if role.collections_permissions:
            print("\nCollections (schema) Permissions:")
            for perm in role.collections_permissions:
                print(
                    f"  - Collection: {perm.collection}, Action: {', '.join([action.value for action in perm.actions])}"
                )

        if role.tenants_permissions:
            print("\nTenants Permissions:")
            for perm in role.tenants_permissions:
                print(
                    f"  - Collection: {perm.collection}, Tenant: {perm.tenant}, Action: {', '.join([action.value for action in perm.actions])}"
                )

        if role.data_permissions:
            print("\nData Permissions:")
            for perm in role.data_permissions:
                print(
                    f"  - Collection: {perm.collection}, Action: {', '.join([action.value for action in perm.actions])}"
                )

        if role.replicate_permissions:
            print("\nReplicate Permissions:")
            for perm in role.replicate_permissions:
                print(
                    f"  - Collection: {perm.collection}, Action: {', '.join([action.value for action in perm.actions])}"
                )

        if role.alias_permissions:
            print("\nAliases Permissions:")
            for perm in role.alias_permissions:
                print(
                    f"  - Collection: {perm.collection}, Alias: {perm.alias}, Action: {', '.join([action.value for action in perm.actions])}"
                )
