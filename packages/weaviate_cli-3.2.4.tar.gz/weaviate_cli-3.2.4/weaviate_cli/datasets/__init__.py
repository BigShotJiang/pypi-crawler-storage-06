# This file is required to make the package a Python package and allow package_data to work
# The movies.json file will be included via package_data in setup.py/pyproject.toml
