Welcome to mim's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   installation.md
   customization.md
   abbreviation.md
   api.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
