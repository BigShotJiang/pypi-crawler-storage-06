# Copyright (c) OpenMMLab. All rights reserved.

__version__ = '0.4.0rc2'
