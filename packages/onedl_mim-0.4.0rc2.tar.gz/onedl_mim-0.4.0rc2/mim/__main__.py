# Copyright (c) OpenMMLab. All rights reserved.
"""With this module, we can use `python -m mim`."""
from .cli import cli

if __name__ == '__main__':
    cli()
