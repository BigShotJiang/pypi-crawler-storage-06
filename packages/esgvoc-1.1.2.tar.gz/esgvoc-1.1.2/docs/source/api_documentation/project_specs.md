# Project specs

```{eval-rst}
.. automodule:: esgvoc.api.project_specs
   :members:
   :member-order: groupwise
```