import esgvoc.core.logging_handler  # noqa

__version__ = "1.1.2"
