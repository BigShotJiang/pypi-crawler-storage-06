from esgvoc.api.data_descriptors.data_descriptor import PlainTermDataDescriptor


class ObsType(PlainTermDataDescriptor):
    description: str
