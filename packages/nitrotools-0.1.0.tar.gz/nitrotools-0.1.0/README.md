# Nitro

A shared library for common utilities.

## Installation

```bash
pip install nitro
```

## Usage

```python
from nitro.core import hello

print(hello())
```

## Contributing

Contributions are welcome!

## License

MIT
