from pythonsi.node.data import Data

__all__ = [
    "Data",
]
