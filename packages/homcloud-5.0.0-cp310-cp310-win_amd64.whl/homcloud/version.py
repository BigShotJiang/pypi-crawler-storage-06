# This file should be compatible with Makefile
__version__ = "5.0.0"
