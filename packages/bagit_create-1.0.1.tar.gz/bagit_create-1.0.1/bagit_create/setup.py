from setuptools import find_packages, setup

setup(
    name="bagit_create",
    packages=find_packages(),
)
