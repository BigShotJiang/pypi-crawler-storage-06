"""IAM service protobuf definitions."""
