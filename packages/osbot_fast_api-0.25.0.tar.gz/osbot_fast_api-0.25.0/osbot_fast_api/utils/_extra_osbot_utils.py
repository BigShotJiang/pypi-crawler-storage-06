import threading
import uuid


# def is_guid(value):
#     try:
#         uuid.UUID(value, version=4)
#         return True
#     except ValueError:
#         return False