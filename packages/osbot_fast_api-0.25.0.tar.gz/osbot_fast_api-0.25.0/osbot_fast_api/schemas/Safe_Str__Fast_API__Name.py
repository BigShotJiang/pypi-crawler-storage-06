from osbot_utils.type_safe.primitives.core.Safe_Str import Safe_Str
from osbot_fast_api.schemas.consts__Fast_API            import REGEX__SAFE__STR__FAST_API__TITLE


class Safe_Str__Fast_API__Name(Safe_Str):
    regex = REGEX__SAFE__STR__FAST_API__TITLE