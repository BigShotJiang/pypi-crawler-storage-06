# solve

a small cli tool for ps

---

## install

```bash
pip install --user solve-ps
```

## Usage

```bash
solve get boj 1000
solve tc 2 -p 1000
solve run 1000.cpp
solve diff
```
