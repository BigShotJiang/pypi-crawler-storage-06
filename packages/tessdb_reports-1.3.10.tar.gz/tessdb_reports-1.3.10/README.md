# tessdb-reports

Repository to extract varios reports from the tessdb database

The reports generated include:
* IDA monthly files, in the aforementioned format
* geographic distribution of photometers, in CSV format

