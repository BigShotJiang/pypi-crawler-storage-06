from blinker import signal

volttron_home_set_evnt = signal("volttron_home_set")
