"""
DBBasic CLI - The crate engine for web apps
"""

__version__ = "0.1.1"

from .cli import app

__all__ = ["app"]