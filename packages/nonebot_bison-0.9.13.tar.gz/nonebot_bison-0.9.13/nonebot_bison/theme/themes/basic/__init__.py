from .build import BasicTheme

__theme_meta__ = BasicTheme()
