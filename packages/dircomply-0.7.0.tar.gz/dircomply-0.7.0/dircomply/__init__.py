"""
dircomply: A small package to compare the files between two project folders.
"""
__title__ = "dircomply"
__author__ = "Benevant Mathew"
__license__ = "MIT License"