class APIException(Exception):
    """Base class for all API exceptions."""
    pass
