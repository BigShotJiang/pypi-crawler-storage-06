def get_version(data):
    new_data = {
        'content': 'version'
    }
    return (new_data)
