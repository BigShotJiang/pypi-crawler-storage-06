This fixture allows testing a project that uses the repository version of `poetry-core`
as a PEP 517 backend.
