#!/usr/bin/env python

from __future__ import annotations


hello = "Hello World!"
