"""Example module"""

__version__ = "0.1"
