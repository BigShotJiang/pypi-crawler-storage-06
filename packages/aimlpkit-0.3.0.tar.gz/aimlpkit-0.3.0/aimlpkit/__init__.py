from .main import (
    disp,
    disp_1,
    disp_2,
    disp_3,
    disp_4,
    disp_5,
    disp_6,
    disp_7,
    disp_8,
    disp_9,
    disp_10,
)
