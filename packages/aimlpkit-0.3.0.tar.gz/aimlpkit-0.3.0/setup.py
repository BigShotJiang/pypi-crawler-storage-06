from setuptools import find_packages, setup

setup(name="aimlpkit", version="0.2", packages=find_packages())
