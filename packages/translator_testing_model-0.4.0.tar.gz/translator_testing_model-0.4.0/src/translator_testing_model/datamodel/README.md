# Generated Python Datamodels

* [Pydantic](src/translator_testing_model/datamodel/pydanticmodel.py) -  this is a version 2 model
* [Python Dataclasses](src/translator_testing_model/datamodel/translator_testing_model.py)