"""I exist so that mypy.ini "[mypy-tests.*]" config works.
"""
