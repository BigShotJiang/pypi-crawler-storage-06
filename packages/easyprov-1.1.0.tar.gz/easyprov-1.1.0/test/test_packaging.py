# {# pkglts, glabpkg_dev
import easyprov


def test_package_exists():
    assert easyprov.__version__

# #}
