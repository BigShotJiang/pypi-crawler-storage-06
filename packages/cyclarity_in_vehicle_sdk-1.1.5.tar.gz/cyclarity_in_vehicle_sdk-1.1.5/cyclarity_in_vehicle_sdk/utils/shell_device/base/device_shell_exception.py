class DeviceShellException(Exception):
    pass  

