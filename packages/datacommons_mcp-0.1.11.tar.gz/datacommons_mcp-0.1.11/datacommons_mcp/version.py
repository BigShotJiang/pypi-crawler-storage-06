"""
Version information for datacommons-mcp package.
"""

# Updating the version here will trigger a new version of datacommons-mcp
# package on PyPI when pushed to the main branch on github
# See .github/workflows/build-and-publish-datacommons-mcp.yaml
__version__ = "0.1.11"
