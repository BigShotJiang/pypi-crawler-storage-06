# Contributors
======

Below is a list of those who have contributed code or data to the releases of Fast LISA Response. Note this is not an exhaustive list of those who have contributed to Fast LISA Response development for each version, as often people are also involved via extensive discussion and paper writing.

- Fast LISA Response v1.0 (Initial Release)
	* [Michael Katz](https://github.com/mikekatz04)
	* [Jean Baptiste-Bayle](https://github.com/j2bbayle)
	* [Lorenzo Speri](https://github.com/lorenzsp)
	* [Alvin Chua](https://github.com/alvincjk)
	* [Michele Vallisneri](https://github.com/vallis)
