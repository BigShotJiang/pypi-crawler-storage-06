import torch

EPS = torch.finfo(torch.get_default_dtype()).eps