DEFAULT_EVAL_LLM_ENGINE = "gpt-4o-mini"
EVAL_COST_FALLBACK = 0.001
LLM_ENGINE_FIELD_NAME = "llm_engine"

# Import constants for default values
UTC_EPOCH = "1970-01-01 00:00:00"