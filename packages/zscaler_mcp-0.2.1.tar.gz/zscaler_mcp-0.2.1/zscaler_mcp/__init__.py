"""
Zscaler MCP Server Package

This package provides the Zscaler MCP server with support for ZCC, ZDX, ZIA, ZPA, ZTW, ZIdentity services.
"""

__version__ = "0.2.1"
