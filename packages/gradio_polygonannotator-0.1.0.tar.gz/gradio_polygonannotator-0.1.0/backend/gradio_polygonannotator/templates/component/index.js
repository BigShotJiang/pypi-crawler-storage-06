import { ap as f } from "./Index-Ct_1BCRd.js";
export {
  f as default
};
