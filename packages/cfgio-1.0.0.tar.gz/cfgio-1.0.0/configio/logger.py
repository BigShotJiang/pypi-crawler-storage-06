import logging


logger = logging.getLogger("ConfigIO")
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

# "%(levelname)s: %(message)s"
