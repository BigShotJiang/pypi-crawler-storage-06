import logging

logger = logging.getLogger('kxy.framework')
logger.setLevel(logging.INFO)