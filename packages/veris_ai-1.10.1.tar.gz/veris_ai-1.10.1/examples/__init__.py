"""Examples for using the Veris AI SDK."""
