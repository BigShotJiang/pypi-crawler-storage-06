## v1.0.0 (2025-09-19)

### Feat

- **grouping**: add transformation support for aggregation functions
- **grouping**: add new aggregation functions and support for `as_index` parameter
## v0.4.0 (2025-06-17)

### Feat

- **dataframe**: ✨ add functions to retrieve column names and data

## v0.3.0 (2025-06-06)

### Feat

- **dataframe**: ✨ add `df_reset_index` and `df_get_index` functions
- **rows**: ✨ add `get_index` function to retrieve DataFrame index
- **manipulation**: ✨ add `reset_index` function to reset DataFrame index
- **dataseries**: ✨ add `ser_to_df` function to convert Series to DataFrame

### Refactor

- **io**: ♻️ update `after_set_value` to use `update_other_io_options`

## v0.2.8 (2024-10-21)

## v0.2.7 (2024-09-26)

## v0.2.6 (2024-09-13)

## v0.2.5 (2024-09-13)

## v0.2.3 (2024-09-04)

## v0.2.2 (2024-09-03)

## v0.2.1 (2024-08-29)

## v0.2.0 (2024-08-29)
