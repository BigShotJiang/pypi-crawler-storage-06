class InputCalled(Exception):
    """When the input() function is called, this exception is raised
    to pause the runtime."""

    pass


class FunctionCalled(Exception):
    pass
