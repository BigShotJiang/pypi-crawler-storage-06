import enum


class BlockResult(enum.Enum):
    JUMP = 0
    SHIFT = 1
