# physical constants
g = 9.81  # gravity acceleration [m/s^2]