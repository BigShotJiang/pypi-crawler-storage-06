<!-- SPDX-License-Identifier: MIT -->

# zih-models

Pydantic models for ZIH services
