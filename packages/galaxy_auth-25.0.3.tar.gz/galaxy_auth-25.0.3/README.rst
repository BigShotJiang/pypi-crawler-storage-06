
.. image:: https://badge.fury.io/py/galaxy-auth.svg
   :target: https://pypi.org/project/galaxy-auth/



Overview
--------

The Galaxy_ auth framework and default plugins.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
