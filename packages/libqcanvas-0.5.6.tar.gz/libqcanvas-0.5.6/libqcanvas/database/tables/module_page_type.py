from enum import Enum


class ModulePageType(Enum):
    PAGE = 0
    FILE = 1
