"""
WithResourcesOrnamentalMixin and WithAttachmentsOrnamentalMixin are stubs that tell pycharm about the extra attributes added by the resource link decorators
"""


class WithResourcesOrnamentalMixin:
    pass


class WithAttachmentsOrnamentalMixin:
    pass
