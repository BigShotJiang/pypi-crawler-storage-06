SYNC_GOAL = "Sync"
