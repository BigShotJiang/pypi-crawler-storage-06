TABPFN_TS_DEFAULT_QUANTILE_CONFIG = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
TABPFN_TS_DEFAULT_CONFIG = {
    "tabpfn_internal": {"model_path": "tabpfn-v2-regressor-2noar4o2.ckpt"},
    "tabpfn_output_selection": "median",  # mean or median
}
