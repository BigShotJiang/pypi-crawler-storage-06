.. _view_nested:

Nested View
===========

.. automodule:: view_nested
  :members:
