.. _hipchat:

Hipchat
==========

.. automodule:: hipchat_notif
   :members:
