.. _view_categorized:

Categorized View
================

.. automodule:: view_categorized
  :members:
