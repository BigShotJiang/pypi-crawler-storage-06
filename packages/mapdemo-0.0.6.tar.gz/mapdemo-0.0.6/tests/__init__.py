"""Unit test package for mapdemo."""
