"""Static HTML files for paidiverpy."""
