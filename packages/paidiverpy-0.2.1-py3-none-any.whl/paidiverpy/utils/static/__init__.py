"""Static files for paidiverpy."""
