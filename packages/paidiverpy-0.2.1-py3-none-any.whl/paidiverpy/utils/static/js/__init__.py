"""Static js files for paidiverpy."""
