"""Static CSS files for paidiverpy."""
