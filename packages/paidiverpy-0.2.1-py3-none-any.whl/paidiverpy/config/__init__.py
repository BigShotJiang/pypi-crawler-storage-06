"""__init__.py for config module."""

from .configuration import Configuration

__all__ = ["Configuration"]
