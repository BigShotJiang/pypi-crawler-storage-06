"""__init__.py for colour_layer module."""

from .colour_layer import ColourLayer

__all__ = ["ColourLayer"]
