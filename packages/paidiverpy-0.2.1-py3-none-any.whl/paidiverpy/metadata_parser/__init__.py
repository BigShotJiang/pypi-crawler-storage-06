"""__init__.py for metadata_parser module."""

from .metadata_parser import MetadataParser

__all__ = ["MetadataParser"]
