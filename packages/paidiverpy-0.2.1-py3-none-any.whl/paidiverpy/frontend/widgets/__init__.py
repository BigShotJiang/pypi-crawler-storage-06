"""__init__.py for frontend wigets module."""
