from .core import Bloco1

__all__ = ['Bloco1']
