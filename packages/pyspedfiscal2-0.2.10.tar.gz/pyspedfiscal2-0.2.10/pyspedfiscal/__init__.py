from pyspedfiscal.core import SpedFiscal

__all__ = ['SpedFiscal']
