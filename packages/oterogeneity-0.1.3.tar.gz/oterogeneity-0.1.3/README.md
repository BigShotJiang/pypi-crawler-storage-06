# ot-heterogeneity

## Repository about computing heterogeneity indexes using Optimal Transport.

## _This repository will be further documented and converted to a python-pip module later on !__

Canonical exemples are located at [src/tests/](./src/tests/) with the python files generating them alongside.

Real-world analysis using our method are located at [src/results/article/](./src/results/article/) with the python script generating them being located at [src/](./src).