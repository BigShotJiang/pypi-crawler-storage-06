Welcome to stcal's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

API
===

.. toctree::
   :maxdepth: 1

   api.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

=====================
Package Documentation
=====================

.. toctree::
   :maxdepth: 1

   stcal/package_index.rst
   stcal/changes.rst
