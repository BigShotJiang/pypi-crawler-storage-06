.. _resample_module:

========
Resample
========

.. toctree::
   :maxdepth: 1

   description.rst

**Also See:**

.. toctree::
   :maxdepth: 1

   utils.rst

.. automodapi:: stcal.resample
