Description
============

This sub-package contains the functions and objects useful for skymatch.
