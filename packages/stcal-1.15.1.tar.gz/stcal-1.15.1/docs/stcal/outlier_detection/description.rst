Description
============

This sub-package contains functions useful for outlier detection.
