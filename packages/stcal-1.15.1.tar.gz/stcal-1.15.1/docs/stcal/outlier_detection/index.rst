.. _outlier_detection:

=======================
Outlier Detection Utils
=======================

.. toctree::
   :maxdepth: 2

   description.rst

.. automodapi:: stcal.outlier_detection.median
.. automodapi:: stcal.outlier_detection.utils
