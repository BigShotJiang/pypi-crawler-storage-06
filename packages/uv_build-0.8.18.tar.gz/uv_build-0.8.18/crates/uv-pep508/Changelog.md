# 0.7.0

* Remove pyo3 bindings
* Update rkyv to 0.8

# 0.6.1

* Update to pyo3 0.22

# 0.6.0

* Added `origin` to `Requirement`

# 0.5.0

* Update to pyo3 0.21
* Update to pyo3-log 0.1.0

# v0.4.2

* CI fixes, mac os builds are temporarily disabled.

# v0.4.1

* CI fixes, mac os builds are temporarily disabled.

# v0.4.0

* Package and extra names are now validated and normalized.
* Updated `pep440_rs` to 0.5.0.
* [rkyv](https://github.com/rkyv/rkyv) support.
* `tracing` is now a separate feature.
