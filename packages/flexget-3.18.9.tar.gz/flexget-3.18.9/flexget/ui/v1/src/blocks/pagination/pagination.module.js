/* global angular */
(function () {
  'use strict';

  angular.module('blocks.pagination', ['ig.linkHeaderParser']);
})();
