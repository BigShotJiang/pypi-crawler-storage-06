from llama_index.multi_modal_llms.openai.base import OpenAIMultiModal

__all__ = ["OpenAIMultiModal"]
