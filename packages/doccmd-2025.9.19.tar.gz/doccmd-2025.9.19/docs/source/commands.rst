Commands
========

.. click:: doccmd:main
  :prog: doccmd
  :show-nested:
