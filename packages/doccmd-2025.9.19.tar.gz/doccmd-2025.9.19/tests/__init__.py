"""
Tests for `doccmd`.
"""
