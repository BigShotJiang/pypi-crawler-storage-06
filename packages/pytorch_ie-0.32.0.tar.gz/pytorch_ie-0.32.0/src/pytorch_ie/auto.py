# kept for backward compatibility
from pie_core import AutoTaskModule

# kept for backward compatibility
from pytorch_ie.model import AutoPyTorchIEModel as AutoModel
from pytorch_ie.pipeline import PyTorchIEPipeline as AutoPipeline
