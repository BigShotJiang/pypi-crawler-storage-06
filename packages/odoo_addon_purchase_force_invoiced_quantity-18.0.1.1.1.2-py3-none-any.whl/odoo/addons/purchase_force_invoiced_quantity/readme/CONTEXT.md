This module implements additional featured for the [Purchase Force
Invoiced](https://github.com/OCA/purchase-workflow/tree/16.0/purchase_force_invoiced)
module.

It covers the following scenarios:

- One need to modify the quantity to be invoiced after the products were
  received. Eg .you negotiated an extra discount from your vendor.
- You would like to fix some issues with quantities invoiced cause by
  incorrect data entry.
