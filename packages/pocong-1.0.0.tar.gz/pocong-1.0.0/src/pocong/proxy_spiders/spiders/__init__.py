# Init file for spiders module to make it a package
