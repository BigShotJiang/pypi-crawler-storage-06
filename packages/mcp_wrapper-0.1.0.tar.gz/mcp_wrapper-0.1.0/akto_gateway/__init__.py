"""Akto Gateway - MCP Gateway with PII Detection."""

__version__ = "0.1.0"
__author__ = "Akto Team"
__description__ = "Simple MCP Gateway for logging and monitoring with PII detection"
