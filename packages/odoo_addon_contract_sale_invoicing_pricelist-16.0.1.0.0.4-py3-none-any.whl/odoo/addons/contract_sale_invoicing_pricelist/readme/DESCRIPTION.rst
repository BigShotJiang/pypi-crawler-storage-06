This module will set the invoice pricelist and currency based on the contract pricelist
and currency when recurring invoices created from the contract.
