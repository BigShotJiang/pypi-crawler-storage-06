def main():
    print("Hello from modelscope!")


if __name__ == "__main__":
    main()
