pthelma
=======

.. image:: https://github.com/openmeteo/pthelma/actions/workflows/run-tests.yml/badge.svg
    :alt: Build button
    :target: https://github.com/openmeteo/pthelma/actions/workflows/run-tests.yml

.. image:: https://codecov.io/github/openmeteo/pthelma/coverage.svg?branch=master
    :alt: Coverage
    :target: https://codecov.io/gh/openmeteo/pthelma

.. image:: https://img.shields.io/pypi/v/pthelma.svg
        :target: https://pypi.python.org/pypi/pthelma

A Python library with utilities for hydrological and meteorological time
series processing.

Documentation: https://pthelma.readthedocs.io
