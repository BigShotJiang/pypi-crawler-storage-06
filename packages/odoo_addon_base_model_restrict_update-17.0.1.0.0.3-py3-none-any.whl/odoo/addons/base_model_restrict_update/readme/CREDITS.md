- This module borrows the idea from 'Moises Lopez
  \<<https://odoo-community.org/groups/contributors-15/contributors-161807>\>'
