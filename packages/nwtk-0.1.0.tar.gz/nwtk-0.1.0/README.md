# INTRO

A library for machine learning on tabular data.
