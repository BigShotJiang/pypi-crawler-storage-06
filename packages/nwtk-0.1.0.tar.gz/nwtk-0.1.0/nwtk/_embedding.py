from torch import nn

class EmbeddingBlock(nn.Module):
    def __init__(self):
        