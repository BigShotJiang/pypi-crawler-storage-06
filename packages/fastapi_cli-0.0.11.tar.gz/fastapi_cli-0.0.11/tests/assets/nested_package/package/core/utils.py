def get_hello_world() -> str:
    return "Hello World"
