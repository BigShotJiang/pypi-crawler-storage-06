---
hide:
  - navigation
---

# Planned Features

- S3 bucket interface to push database files to storage
- Server to provide data to Grafana dashboard over network (pathfinder working on local computer)
- User authentication
- Smarter Grafana dashboards (auto populate input/output selector buttons for scatter plots, etc.)