"""
test_mypip_setup - 一个示例Python包
"""

__version__ = "0.2.2"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .test2 import fun1,fun2

__all__ = ["fun1","fun2"]