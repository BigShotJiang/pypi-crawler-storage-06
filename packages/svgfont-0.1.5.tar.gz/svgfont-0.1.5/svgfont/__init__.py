#!/usr/bin/env python3
# import svgfont
# from importlib import reload
# reload(svgfont)

from .svgfont import (load_font,
                      rect,
                      transform_to_rect,
                      text_paths,
                      text_width)
