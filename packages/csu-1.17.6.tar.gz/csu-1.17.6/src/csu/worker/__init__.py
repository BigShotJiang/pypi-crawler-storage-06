from logging import getLogger

logger = getLogger("worker")
