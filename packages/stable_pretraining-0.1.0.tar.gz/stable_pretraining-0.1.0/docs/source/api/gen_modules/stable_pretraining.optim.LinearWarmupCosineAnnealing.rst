﻿LinearWarmupCosineAnnealing
===========================

.. currentmodule:: stable_pretraining.optim

.. autoclass:: LinearWarmupCosineAnnealing
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.optim.LinearWarmupCosineAnnealing:

.. minigallery:: stable_pretraining.optim.LinearWarmupCosineAnnealing
    :add-heading: Examples using ``LinearWarmupCosineAnnealing``:
