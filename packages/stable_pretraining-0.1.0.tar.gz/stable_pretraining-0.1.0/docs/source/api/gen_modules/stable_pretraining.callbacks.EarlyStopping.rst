﻿EarlyStopping
=============

.. currentmodule:: stable_pretraining.callbacks

.. autoclass:: EarlyStopping
   :members:
   :show-inheritance:
   :no-undoc-members:
   :special-members: __mul__, __add__, __div__, __neg__, __sub__, __truediv__

.. _sphx_glr_backref_stable_pretraining.callbacks.EarlyStopping:

.. minigallery:: stable_pretraining.callbacks.EarlyStopping
    :add-heading: Examples using ``EarlyStopping``:
