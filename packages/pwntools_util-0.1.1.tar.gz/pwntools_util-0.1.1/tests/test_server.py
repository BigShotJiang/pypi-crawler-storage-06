if __name__ == "__main__":
    print("Hello world")
    print("Hello 123")
    print("Hello -1337")
    print("There are +365 days in -1 year")
    print("List 1: [1, 2, 3, 4, 5]")
    print("List 2: [1, -3, 5, -7, 9], hurray!")
    inp = input("Enter anything -> ")
    print(f"Your entered \"{inp}\"!")
