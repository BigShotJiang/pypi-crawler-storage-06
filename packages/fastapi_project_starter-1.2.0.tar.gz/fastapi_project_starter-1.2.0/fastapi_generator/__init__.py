"""
FastAPI Template Generator - FastGen
A CLI tool to generate FastAPI project templates
"""

__version__ = "0.1.0"
__author__ = "Devesh Shrestha"
__email__ = "deveshshrestha20@gmail.com"