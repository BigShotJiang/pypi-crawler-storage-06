from .new import app as new_app

__all__ = ["new_app"]