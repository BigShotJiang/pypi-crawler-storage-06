"""empty message

Revision ID: ff4bfca66bf8
Revises: 0e558d06e0e3, 352fa4f88f61
Create Date: 2018-12-24 22:42:54.188099

"""

# revision identifiers, used by Alembic.
revision = "ff4bfca66bf8"
down_revision = ("0e558d06e0e3", "352fa4f88f61")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
