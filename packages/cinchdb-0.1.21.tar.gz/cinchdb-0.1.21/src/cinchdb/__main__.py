def main():
    print("Hello from cinchdb!")


if __name__ == "__main__":
    main()
