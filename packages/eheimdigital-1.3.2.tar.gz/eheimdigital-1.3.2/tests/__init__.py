"""Tests for EHEIM Digital."""
