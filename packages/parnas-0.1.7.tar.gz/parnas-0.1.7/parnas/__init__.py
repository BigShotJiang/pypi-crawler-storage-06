# -*- coding: utf-8 -*-
from .logging import parnas_logger
