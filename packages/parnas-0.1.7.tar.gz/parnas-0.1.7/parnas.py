#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from parnas.cli import run_parnas_cli

if __name__ == '__main__':
    run_parnas_cli()
