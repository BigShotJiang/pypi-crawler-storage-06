"""
Old Algorithm Implementations.

This package contains older versions of algorithm implementations that are kept for future
development.
"""
