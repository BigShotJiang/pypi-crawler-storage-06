from enum import Enum


class ZentisLoadStep(Enum):
    FERTIGARTIKEL = "Fertigartikel"
    REZEPTURDATEN = "Rezepturdaten"
    JOINED_DATA = "JoinedData"