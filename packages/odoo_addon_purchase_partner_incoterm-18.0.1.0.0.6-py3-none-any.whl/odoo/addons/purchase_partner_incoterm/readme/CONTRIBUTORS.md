- [Camptocamp](https://www.camptocamp.com):
  - Thierry Ducrest \<<thierry.ducrest@camptocamp.com>\>
  - Denis Leemann \<<denis.leemann@camptocamp.com>\>

- [Trobz](https://trobz.com):
  - Son Ho \<<sonhd@trobz.com>\>
  - Chau Le \<<chaulb@trobz.com>\>
  - Nhan Tran \<<nhant@trobz.com>\>

- [Akretion](https://akretion.com):
  - David BEAL \<<david.beal@akretion.com>\>
  - Raphaël Reverdy \<<raphael.reverdy@akretion.com>\>

- [InitOS](https://www.initos.com):
  - Dhara Solanki \<<dhara.solanki@initos.com>\>

- Manish Kumar Bohra <manishkumarbohra@outlook.com>
