from . import test_purchase_partner_incoterm
