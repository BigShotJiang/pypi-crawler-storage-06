"""Universal CLI tool for managing AI agent configurations across different platforms."""

__version__ = "0.1.1"
__author__ = "FradSer"
__email__ = "frad@frad.io"
