To use this module, you need to:

- go to Management Systems \> Audits
- create a new audit
- fill up its name, its auditors and schedule the date
- prepare your questions with the verification list and print it
- drive the audit and log answers in your verification list
- finish your audit by writing the strong points, points to improve and
  creating improvements opportunities and nonconformities
- print the audit report and close the audit

For further information, please visit:

- <http://fr.slideshare.net/max3903/iso-anmanagement-systemswithopenerpen>
