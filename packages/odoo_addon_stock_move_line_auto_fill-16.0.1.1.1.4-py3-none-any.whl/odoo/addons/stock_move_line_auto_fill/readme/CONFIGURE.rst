To configure this module, you need to:

#. Make sure you have selected the proper removal strategy on your product
   categories.
#. Configure the product on the page "Inventory", field "Tracking" with one of
   these values: "By Unique Serial Number" or "By Lots" if you want autoassign
   lots.
#. Check in Operation type if you want auto assign quantities, by default if
   you want assign quantities done to reserved quantities you must push the
   button "Auto Fill" when the picking is in ready state and has move lines
#. Check in Operation type if you do not want auto assign lots quantities with
   "Avoid auto-assignment of lots".
