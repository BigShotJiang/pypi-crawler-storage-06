print("If you installed this `paxel` library, you are probably looking for an internal WCC `paxel-sdk` library.")
