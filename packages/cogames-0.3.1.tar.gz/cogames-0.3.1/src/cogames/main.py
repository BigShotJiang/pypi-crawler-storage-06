from cogames.cogs_vs_clips.scenarios import make_cogs_vs_clips_scenario


def main():
    scenario = make_cogs_vs_clips_scenario()
    print(scenario)


if __name__ == "__main__":
    main()
