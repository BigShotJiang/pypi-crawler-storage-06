"""Parameter Server package for distributed parameter management."""

__version__ = "1.0.0"
__author__ = "Cognexa"
__description__ = "A distributed parameter server for managing configuration across processes"
