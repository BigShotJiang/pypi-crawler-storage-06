user_quit = 'user quit'
