from .data.test_data import texts_zh_jp_ko_en, texts_de_fr_en
