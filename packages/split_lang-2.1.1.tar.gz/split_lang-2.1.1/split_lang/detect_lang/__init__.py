from .detector import detect_lang_combined, possible_detection_list

__all__ = ["detect_lang_combined", "possible_detection_list"]
