The cv_1.pdf file was copied from https://github.com/agno-agi/agno/tree/main/libs/agno/tests/integration/knowledge/data/filters,
where it is used for integration testing. It's a nice small file, which is why it was preferred
