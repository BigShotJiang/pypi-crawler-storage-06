from .azure import AzureProvider

__all__ = ["AzureProvider"]
