## Model Types

Data models and types for model operations.

::: any_llm.types.model
