# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.8.1
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x03O\
(\
\xb5/\xfd`d\x0b-\x1a\x00\x16gm# q\xdb\
\xccq\xe1\xe6\xd2\xb7\xd0\xfa\x906\x94\xdc\x14\xf9\x1c\xdb\
D{\x809,S\x9e\x83P\x05\xa0\x01\xc0\x0d8\x0f\
b\x00d\x00a\x00\xfe\xfeq\xba\x11D\x8cit\xda\
\x9e\x89\x1e\xe5D\x92\xc9\xe1!\x22'\x9e\xcf\xb0\xd1\x84\
\x0cc\xae\xd3dK\xbf>e\x8b7#\xf6\xab\xdfC\
\xe8\x10\x14\xa1\x84I\x11s\x9e\xde\x1b\x7f\x22\x9d\xd3\x90\
#\xf9\x11\xe9:\x97\xbf\x97\x93\x9b\xf4\xcf\xe5u\xfc.\
_\x9f\xcf\x00\xd6*\xa9c\x02Hf=IIEj\
\xc2~(\x18\x01\x07\xc3\x04\xbe\x989N\x7f\xb1D\xaa\
u\xd1\x9fCY\xda\xfc\xdf\x9bT\xcf\xd0I \x7f\x85\
\x83T\x8e\xeb]\x8523\x99\x8dd\x18\xc8\x1c\x92\x22\
Z3\x0e\x01&\xc1t\x9e\x90\xb5~\xb2\xf6O\x82\xed\
\xf9\xa4\xa0c\x01eu\xac\x148\x9e\xbf\xf2[_q\
x\xa7\xaf\xa4\xe5\xebp(\x08\xfd?\xf9\xd1\x93\xb2\xf8\
\x810)j\xde\xbb\xe3\xf5\x95\xbc\xe2\x06\x0d\xc2A*\
\xd6\xe8\x89w\xed\x90\xf3\xc9'}\x8d0^o\xa9~\
\xfb3\x98\xe2\xf9\xf3Q\xb7!\x0a\xbav\x9e\xb6w\xfc\
\x14r-n\xa7J\x8d_\xf2\x18\xdc\x96T?a\x06\
\x9f?\xcb)B\x0a\xe4@&~u\x98\xf1\xa6\xe2\x87\
\xe3\xfbTP\xb3u\xa1<\xdd\xf4x\x9f7\x09\xa9`\
\xec\xd5\xc7\xb6[\xe2\x7ff\x0a\xa5z\xce\x02\xcc\x85!\
\xd3I*\xb6\xf4/\xe5\x06\xd8\x0e\x8f\x5c\xc8\xe7\x1d\xc7\
,\xc1g\xe9?\xb3\xa6a\xf3\xe3\x07#r\x8f\x07\x11\
=]\x17\x9da\x9f_\xfc\xe3\x82\xd7\x1f }\x18\x08\
\xa9\x9e\xdf\xbe`\xd7,Zo\x96_\x9f/\x8e\x18\xc0\
\xc7K\xa1\x89\x07\xc8%\xde\xb9F?\x86X\xa4rN\
\xb3\x07\xd3\xd5\xff\xd8\xb2\xfc\x1ay\xc7\xad\xf9\xba\x5c\x96\
y\x80\xab\xa0\x01\x1a33$2\x93\x14\xa5\xb0\x1c \
\x84\x18\xc4\x10V\x07\xa9\xd1^C\xdd\x1dfi\x00\x82\
\x17\xc5\x10\x8b\xaeWv\xbd\xa2\x90\xb7\xfc?\x96\x99V\
\x8b\xf4\xf2{\xc1.\x8f>\xf5\x1b\xd8\x1c\x87\xe8\x12\xab\
\xd1\xca\x19\xbd+!'\x7fz\x09\x08\xa95\xdbgM\
\xb1\xd4\xben\xb8\xfb\xc8tbv\xa6\x9f\x7f\xb4\xde\x01\
bP\xb2\x030\x89D\x13\x86\xfd\xe8r\xd9\x94-\xd4\
\x95\x06\xb7\x84;,<\xd5f\xfd\xe7\x01o-\xc7~\
[Q\x9a2\xf6\x17<\x83$_B\x83\xb8v\xd4\x22\
\xb4\xafz\xd6\x1c\x0c\x10\xff'4pro\xd5\xbe\xad\
\xac\xce\x08\x868\xfd l\x1aU\xabM\xa9\xe6h\xd6\
-\xc8!\x99\xfa\xca\x05h\xd7X?jY(\xb7\x0f\
o<\xae\xeb\xf8]\xf9ax@\xf3\xe7_qw\x8b\
\xe60\x16\xee\xfcy\xfb1\xdb\xf1\xa2\xe3\x96\xd2ud\
\x04\x95\xed\xd8\xb6\xd4}\xd9\xb9\xday:\xa1ETN\
\xd4m\x89\x9c\x16\x05c\x17x\xcb<\xf2\x1e\xbf\xb1[\
\x9c}\xd5e\xe5\xbd\xb6!\xf6\x0fmy7\xb7\xc2\xd2\
\x83\x18\x13#}g\xd7$\x05\xa0\xadxi\x96W-\
d'\xde\xa4\x00P\xc3\xfdt\xa5w@_\x1af\xb8\
i=\x11I\x83XF\x938Im\x99\x0a$\xa7n\
\xaa\xc2@\x01\x8b~\x88g%\xe5E\x16\xe4\x06\xf6F\
[j\x9e\x87\x5c\xcbt\x07\xb2\xfe\x83A \xcet\x93\
\xd1\xb3\xdc\x01\xbe.@a%S\xa6\xb9\x99}\x80G\
\xb0\xa5\xf9\x01M\x8d\x07\xbe\xa4\xfaY\xbe\x98\xb4\x10R\
\xc0\xe4\xe2\xfb)\x082\xaeJP\xeb\x0b\xb8>\
\x00\x00\x02\x04\
i\
mport QtQuick\x0a\x0aL\
istModel {\x0a    L\
istElement {\x0a   \
     file_name: \
\x22texas.pdf\x22\x0a    \
    resource_id:\
 \x221\x22\x0a        dow\
nload_state: \x22NO\
T_DOWNLOADED\x22\x0a  \
  }\x0a    ListElem\
ent {\x0a        fi\
le_name: \x22oh_no_\
what_a_terribly_\
long_file_name_i\
ts_not_like_some\
one_would_actual\
ly_do_this.pdf\x22\x0a\
        resource\
_id: \x222\x22\x0a       \
 download_state:\
 \x22FAILED\x22\x0a    }\x0a\
    ListElement \
{\x0a        file_n\
ame: \x22i was tran\
sported to anoth\
er world where j\
avascript doesn'\
t exist.cbz\x22\x0a   \
     resource_id\
: \x223\x22\x0a        do\
wnload_state: \x22D\
OWNLOADED\x22\x0a    }\
\x0a}\x0a\
\x00\x00\x00\xa3\
i\
mport QtQuick\x0a\x0aT\
hemedRectangle {\
\x0a    anchors.fil\
l: parent\x0a\x0a    C\
ommentsList {\x0a  \
      anchors.fi\
ll: parent\x0a     \
   model: commen\
ts\x0a        palet\
te: theme\x0a    }\x0a\
}\x0a\
\x00\x00\x03\xf9\
i\
mport QtQuick\x0a\x0aR\
ectangle {\x0a    p\
roperty Palette \
theme: getTheme(\
)\x0a    color: the\
me.base\x0a\x0a    fun\
ction getTheme()\
 {\x0a        if (a\
ppTheme.theme ==\
= \x22native\x22)\x0a    \
        return p\
alette\x0a        e\
lse if (appTheme\
.dark_mode === t\
rue)\x0a           \
 return darkThem\
e\x0a        else\x0a \
           retur\
n lightTheme\x0a   \
 }\x0a\x0a    Palette \
{\x0a        id: li\
ghtTheme\x0a       \
 base: \x22#f8f9fa\x22\
\x0a        window:\
 \x22#f8f9fa\x22\x0a     \
   midlight: \x22#f\
8f9fa\x22\x0a        a\
ccent: \x22#e02424\x22\
\x0a        link: a\
ccent\x0a        da\
rk: \x22#dadce0\x22\x0a  \
      text: \x22#4d\
5157\x22\x0a    }\x0a\x0a   \
 Palette {\x0a     \
   id: darkTheme\
\x0a        base: \x22\
#202124\x22\x0a       \
 window: \x22#f8f9f\
a\x22\x0a        midli\
ght: \x22#202124\x22\x0a \
       accent: \x22\
#e02424\x22\x0a       \
 link: accent\x0a  \
      dark: \x22#3f\
4042\x22\x0a        te\
xt: \x22#e4e7eb\x22\x0a  \
  }\x0a\x0a    Connect\
ions {\x0a        t\
arget: appTheme\x0a\
\x0a        functio\
n onThemeChanged\
() {\x0a           \
 updateTheme()\x0a \
       }\x0a\x0a      \
  function onDar\
kModeChanged() {\
\x0a            upd\
ateTheme()\x0a     \
   }\x0a\x0a        fu\
nction updateThe\
me() {\x0a         \
   theme = getTh\
eme()\x0a        }\x0a\
    }\x0a}\x0a\
\x00\x00\x00\xae\
i\
mport QtQuick\x0a\x0aT\
hemedRectangle {\
\x0a    anchors.fil\
l: parent\x0a\x0a    A\
ttachmentsList {\
\x0a        anchors\
.fill: parent\x0a  \
      model: sub\
mission_files\x0a  \
      palette: t\
heme\x0a    }\x0a}\x0a\
\x00\x00\x03\xeb\
i\
mport QtQuick\x0aim\
port QtQuick.Con\
trols\x0aimport QtQ\
uick.Layouts\x0a\x0aIt\
em {\x0a    propert\
y alias text: co\
ntent.text\x0a    p\
roperty int line\
Width: 3\x0a    pro\
perty color line\
Colour: palette.\
accent\x0a    prope\
rty alias conten\
t: content\x0a\x0a    \
Layout.fillWidth\
: true\x0a    heigh\
t: content.conte\
ntHeight\x0a    cli\
p: true\x0a\x0a    Ite\
m {\x0a        anch\
ors.fill: parent\
\x0a        height:\
 content.content\
Height\x0a\x0a        \
Rectangle {\x0a    \
        id: deco\
ration\x0a         \
   width: lineWi\
dth\x0a            \
color: lineColou\
r\x0a            ra\
dius: 1\x0a        \
    anchors {\x0a  \
              le\
ft: parent.left\x0a\
                \
top: parent.top\x0a\
                \
bottom: parent.b\
ottom\x0a          \
  }\x0a        }\x0a\x0a \
       Text/*Edi\
t*/ {\x0a          \
  id: content\x0a  \
          Layout\
.fillWidth: true\
\x0a            col\
or: palette.text\
\x0a            //r\
eadOnly: true\x0a  \
          //text\
Format: TextEdit\
.AutoText\x0a      \
      anchors {\x0a\
                \
left: decoration\
.right\x0a         \
       leftMargi\
n: 10\x0a          \
      right: par\
ent.right\x0a      \
      }\x0a        \
}\x0a    }\x0a}\x0a\
\x00\x00\x08C\
i\
mport QtQuick\x0aim\
port QtQuick.Lay\
outs\x0a\x0aItem {\x0a   \
 id: delegate\x0a  \
  height: childr\
enRect.height\x0a  \
  anchors {\x0a    \
    left: parent\
.left\x0a        ri\
ght: parent.righ\
t\x0a    }\x0a\x0a    Col\
umnLayout {\x0a    \
    spacing: 0\x0a\x0a\
        anchors \
{\x0a            le\
ft: parent.left\x0a\
            righ\
t: parent.right\x0a\
        }\x0a\x0a     \
   RowLayout {\x0a \
           heigh\
t: childrenRect.\
implicitHeight\x0a \
           Layou\
t.fillWidth: tru\
e\x0a            sp\
acing: 10\x0a\x0a     \
       Image {\x0a \
               f\
unction attachme\
ntIcon(downloadS\
tatus) {\x0a       \
             swi\
tch(downloadStat\
us)\x0a            \
        {\x0a      \
                \
  case \x22DOWNLOAD\
ED\x22:\x0a           \
                \
 return \x22qrc:///\
icons/universal/\
downloads/downlo\
aded.svg\x22;\x0a     \
                \
   case \x22FAILED\x22\
:\x0a              \
              re\
turn \x22qrc:///ico\
ns/universal/dow\
nloads/download_\
failed.svg\x22;\x0a   \
                \
     case \x22NOT_D\
OWNLOADED\x22:\x0a    \
                \
        return \x22\
qrc:///icons/uni\
versal/downloads\
/not_downloaded.\
svg\x22;\x0a          \
              de\
fault:\x0a         \
                \
   return \x22qrc:/\
//icons/universa\
l/downloads/unkn\
own.svg\x22\x0a       \
             }\x0a \
               }\
\x0a\x0a              \
  id: fileIcon\x0a \
               s\
ource: attachmen\
tIcon(modelData.\
download_state)\x0a\
                \
fillMode: Image.\
PreserveAspectFi\
t\x0a              \
  sourceSize.hei\
ght: 17\x0a        \
        sourceSi\
ze.width: 17\x0a   \
         }\x0a\x0a    \
        Text {\x0a \
               i\
d: file_name_tex\
t\x0a              \
  text: modelDat\
a.file_name\x0a    \
            wrap\
Mode: Text.WrapA\
tWordBoundaryOrA\
nywhere\x0a        \
        Layout.f\
illWidth: true\x0a \
               f\
ont.underline: t\
rue\x0a            \
    color: palet\
te.link\x0a\x0a       \
         MouseAr\
ea {\x0a           \
         id: tex\
tClickArea\x0a     \
               a\
nchors.fill: par\
ent\x0a            \
        cursorSh\
ape: Qt.Pointing\
HandCursor\x0a     \
               h\
overEnabled: tru\
e\x0a              \
  }\x0a            \
}\x0a        }\x0a\x0a   \
     Spacer {\x0a  \
          size: \
5\x0a            vi\
sible: index !==\
 count - 1\x0a     \
   }\x0a    }\x0a\x0a    \
Connections {\x0a  \
      target: te\
xtClickArea\x0a\x0a   \
     function on\
Clicked() {\x0a    \
        modelDat\
a.opened(modelDa\
ta.resource_id)\x0a\
        }\x0a    }\x0a\
}\x0a\
\x00\x00\x01\xdd\
\x0a\
\x0a/*\x0aThis is a UI\
 file (.ui.qml) \
that is intended\
 to be edited in\
 Qt Design Studi\
o only.\x0aIt is su\
pposed to be str\
ictly declarativ\
e and only uses \
a subset of QML.\
 If you edit\x0athi\
s file manually,\
 you might intro\
duce QML code th\
at is not suppor\
ted by Qt Design\
 Studio.\x0aCheck o\
ut https://doc.q\
t.io/qtcreator/c\
reator-quick-ui-\
forms.html for d\
etails on .ui.qm\
l files.\x0a*/\x0aimpo\
rt QtQuick\x0a\x0aList\
View {\x0a    id: v\
iew\x0a    model: C\
ommentsListModel\
 {}\x0a    delegate\
: CommentsListDe\
legate {}\x0a}\x0a\
\x00\x00\x08\xb6\
i\
mport QtQuick\x0a\x0aL\
istModel {\x0a    L\
istElement {\x0a   \
     body: \x22This\
 is a comment. G\
aze at it. Be am\
azed.\x22\x0a        a\
uthor: \x22I am Ste\
ve\x22\x0a        date\
: \x222001-01-01 36\
:00\x22\x0a        att\
achments: [\x0a    \
        ListElem\
ent {\x0a          \
      file_name:\
 \x22texas.pdf\x22\x0a   \
             res\
ource_id: \x221\x22\x0a  \
              do\
wnload_state: \x22N\
OT_DOWNLOADED\x22\x0a \
           },\x0a  \
          ListEl\
ement {\x0a        \
        file_nam\
e: \x22oh_no_what_a\
_terribly_long_f\
ile_name_its_not\
_like_someone_wo\
uld_actually_do_\
this.pdf\x22\x0a      \
          resour\
ce_id: \x222\x22\x0a     \
           downl\
oad_state: \x22FAIL\
ED\x22\x0a            \
},\x0a            L\
istElement {\x0a   \
             fil\
e_name: \x22i was t\
ransported to an\
other world wher\
e javascript doe\
sn't exist.cbz\x22\x0a\
                \
resource_id: \x223\x22\
\x0a               \
 download_state:\
 \x22DOWNLOADED\x22\x0a  \
          }\x0a    \
    ]\x0a    }\x0a    \
ListElement {\x0a  \
      body: \x22If \
Morbius has a mi\
llion fans, I am\
 one of them.\x5cnI\
f Morbius has 5 \
fans, I am one o\
f them.\x5cnIf Morb\
ius has one fan,\
 That one is me.\
\x5cnIf Morbius has\
 no fans, I am n\
o longer alive.\x5c\
nIf the world is\
 against Morbius\
, I am against t\
he world.\x5cnTill \
my last breath, \
I'll love Morbiu\
s (2022).\x22\x0a     \
   author: \x22Goku\
\x22\x0a        date: \
\x221942-16-34 06:6\
3\x22\x0a        attac\
hments: [\x0a      \
      ListElemen\
t {\x0a            \
    file_name: \x22\
morbius_x264_108\
0.mkv\x22\x0a         \
       resource_\
id: \x22blahblah\x22\x0a \
               d\
ownload_state: \x22\
NOT_DOWNLOADED\x22\x0a\
            }\x0a  \
      ]\x0a    }\x0a  \
  ListElement {\x0a\
        body: \x22a\
aaaaaaaaaaaaaaaa\
aaaaaaaaaaaaaaaa\
aaaaaaaaaaaaaaaa\
aaaaaaaaaaaaaaaa\
aaaaaaaaaaaaaaaa\
aaaaaaaaaaaaaaaa\
aaaaaaaaaaaaaaaa\
aaaaaaaaaaa\x5cnbbb\
bbbbbbbbbbbbbbbb\
bbbbbbbbbbbbbbbb\
bbbbbbbbbbbbbbbb\
bbbbbbbbbbbbbbbb\
bbbbbbbbbbbbbbbb\
bbbbbbbbbbbbbbbb\
bbbbbbb\x22\x0a       \
 author: \x22Word W\
rap Test\x22\x0a      \
  date: \x222000-02\
-02\x22\x0a        att\
achments: []\x0a   \
 }\x0a    ListEleme\
nt {\x0a        bod\
y: \x22x264 forms t\
he core of many \
web video servic\
es, such as Yout\
ube, Facebook, V\
imeo, and Hulu. \
It is widely use\
d by television \
broadcasters and\
 ISPs.\x22\x0a        \
author: \x22BideoJA\
N Wordsblahblah\x22\
\x0a        date: \x22\
2027-07-28\x22\x0a    \
    attachments:\
 [\x0a            L\
istElement {\x0a   \
             fil\
e_name: \x22Ass1_SO\
MEDUDE_48.pdf\x22\x0a \
               r\
esource_id: \x22bla\
h_v345\x22\x0a        \
        download\
_state: \x22DOWNLOA\
DED\x22\x0a           \
 }\x0a        ]\x0a   \
 }\x0a}\x0a\
\x00\x00\x01\xe3\
\x0a\
\x0a/*\x0aThis is a UI\
 file (.ui.qml) \
that is intended\
 to be edited in\
 Qt Design Studi\
o only.\x0aIt is su\
pposed to be str\
ictly declarativ\
e and only uses \
a subset of QML.\
 If you edit\x0athi\
s file manually,\
 you might intro\
duce QML code th\
at is not suppor\
ted by Qt Design\
 Studio.\x0aCheck o\
ut https://doc.q\
t.io/qtcreator/c\
reator-quick-ui-\
forms.html for d\
etails on .ui.qm\
l files.\x0a*/\x0aimpo\
rt QtQuick\x0a\x0aList\
View {\x0a    id: v\
iew\x0a    model: A\
ttachmentsListMo\
del {}\x0a    deleg\
ate: Attachments\
ListDelegate {}\x0a\
}\x0a\
\x00\x00\x00N\
i\
mport QtQuick\x0a\x0aI\
tem {\x0a    proper\
ty real size\x0a   \
 height: size\x0a  \
  width: 1\x0a}\x0a\
"

qt_resource_name = b"\
\x00\x03\
\x00\x00x<\
\x00q\
\x00m\x00l\
\x00\x1b\
\x0d\x0f\x19\xfc\
\x00C\
\x00o\x00m\x00m\x00e\x00n\x00t\x00s\x00L\x00i\x00s\x00t\x00D\x00e\x00l\x00e\x00g\
\x00a\x00t\x00e\x00.\x00u\x00i\x00.\x00q\x00m\x00l\
\x00\x18\
\x04\x161<\
\x00A\
\x00t\x00t\x00a\x00c\x00h\x00m\x00e\x00n\x00t\x00s\x00L\x00i\x00s\x00t\x00M\x00o\
\x00d\x00e\x00l\x00.\x00q\x00m\x00l\
\x00\x10\
\x03\xe1\xc1\xfc\
\x00C\
\x00o\x00m\x00m\x00e\x00n\x00t\x00s\x00P\x00a\x00n\x00e\x00.\x00q\x00m\x00l\
\x00\x13\
\x08\xe5\xf4\x1c\
\x00T\
\x00h\x00e\x00m\x00e\x00d\x00R\x00e\x00c\x00t\x00a\x00n\x00g\x00l\x00e\x00.\x00q\
\x00m\x00l\
\x00\x13\
\x05\xa6\xc5|\
\x00A\
\x00t\x00t\x00a\x00c\x00h\x00m\x00e\x00n\x00t\x00s\x00P\x00a\x00n\x00e\x00.\x00q\
\x00m\x00l\
\x00\x14\
\x0c\x17\xd1<\
\x00D\
\x00e\x00c\x00o\x00r\x00a\x00t\x00e\x00d\x00T\x00e\x00x\x00t\x00.\x00u\x00i\x00.\
\x00q\x00m\x00l\
\x00\x1b\
\x0c\xf7\xd6\xbc\
\x00A\
\x00t\x00t\x00a\x00c\x00h\x00m\x00e\x00n\x00t\x00s\x00L\x00i\x00s\x00t\x00D\x00e\
\x00l\x00e\x00g\x00a\x00t\x00e\x00.\x00q\x00m\x00l\
\x00\x13\
\x0a.\xb3\xfc\
\x00C\
\x00o\x00m\x00m\x00e\x00n\x00t\x00s\x00L\x00i\x00s\x00t\x00.\x00u\x00i\x00.\x00q\
\x00m\x00l\
\x00\x15\
\x0cYK\xbc\
\x00C\
\x00o\x00m\x00m\x00e\x00n\x00t\x00s\x00L\x00i\x00s\x00t\x00M\x00o\x00d\x00e\x00l\
\x00.\x00q\x00m\x00l\
\x00\x16\
\x0dg\x00\x9c\
\x00A\
\x00t\x00t\x00a\x00c\x00h\x00m\x00e\x00n\x00t\x00s\x00L\x00i\x00s\x00t\x00.\x00u\
\x00i\x00.\x00q\x00m\x00l\
\x00\x0d\
\x01wq\xfc\
\x00S\
\x00p\x00a\x00c\x00e\x00r\x00.\x00u\x00i\x00.\x00q\x00m\x00l\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x0b\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x01\xf4\x00\x00\x00\x00\x00\x01\x00\x00#i\
\x00\x00\x01\x94S\xec~\x99\
\x00\x00\x00~\x00\x00\x00\x00\x00\x01\x00\x00\x05[\
\x00\x00\x01\x94T\xb8\x224\
\x00\x00\x00H\x00\x00\x00\x00\x00\x01\x00\x00\x03S\
\x00\x00\x01\x94S\xec~\x97\
\x00\x00\x00\xd0\x00\x00\x00\x00\x00\x01\x00\x00\x09\xff\
\x00\x00\x01\x94T\xb8Af\
\x00\x00\x00\xa4\x00\x00\x00\x00\x00\x01\x00\x00\x06\x02\
\x00\x00\x01\x94T\xc4\xc8\xa7\
\x00\x00\x01f\x00\x00\x00\x00\x00\x01\x00\x00\x16\xe7\
\x00\x00\x01\x94S\xec~\x98\
\x00\x00\x00\xfc\x00\x00\x00\x00\x00\x01\x00\x00\x0a\xb1\
\x00\x00\x01\x94S\xec~\x98\
\x00\x00\x01\x92\x00\x00\x00\x00\x00\x01\x00\x00\x18\xc8\
\x00\x00\x01\x94S\xec~\x98\
\x00\x00\x01*\x00\x00\x00\x00\x00\x01\x00\x00\x0e\xa0\
\x00\x00\x01\x94S\xec~\x97\
\x00\x00\x00\x0c\x00\x04\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x94S\xec~\x98\
\x00\x00\x01\xc2\x00\x00\x00\x00\x00\x01\x00\x00!\x82\
\x00\x00\x01\x94S\xec~\x97\
"


def qInitResources():
    QtCore.qRegisterResourceData(
        0x03, qt_resource_struct, qt_resource_name, qt_resource_data
    )


def qCleanupResources():
    QtCore.qUnregisterResourceData(
        0x03, qt_resource_struct, qt_resource_name, qt_resource_data
    )


qInitResources()
