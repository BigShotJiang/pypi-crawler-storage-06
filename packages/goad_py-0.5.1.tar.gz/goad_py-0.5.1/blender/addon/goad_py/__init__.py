from .goad_py import *

__doc__ = goad_py.__doc__
if hasattr(goad_py, "__all__"):
    __all__ = goad_py.__all__