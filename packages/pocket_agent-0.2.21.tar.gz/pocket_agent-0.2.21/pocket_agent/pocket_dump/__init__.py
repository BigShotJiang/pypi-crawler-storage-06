"""
pocket-dump CLI module for dumping Pocket Agent source code.
"""

from .cli import main

__all__ = ["main"]
