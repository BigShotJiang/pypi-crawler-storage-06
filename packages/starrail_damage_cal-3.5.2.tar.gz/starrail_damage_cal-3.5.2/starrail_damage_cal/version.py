StarRail_version = "3.5.0"
