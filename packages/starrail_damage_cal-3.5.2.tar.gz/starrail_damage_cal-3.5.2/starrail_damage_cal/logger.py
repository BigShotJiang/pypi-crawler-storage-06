import logging

logger = logging.getLogger("StarRailDamageCal")
