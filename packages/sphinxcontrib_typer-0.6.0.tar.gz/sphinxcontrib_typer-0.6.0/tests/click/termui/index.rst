.. typer:: termui.cli
    :preferred: html
    :width: 65
    :make-sections:
    :show-nested:

.. typer:: termui.cli:menu
    :preferred: html
    :width: 100
    :convert-png: latex
    :make-sections:
