Reference
=========

.. typer:: cli-ref.app
    :prog: python -m cli-ref.py
    :width: 65
    :convert-png: latex
    :make-sections:
