.. typer:: composite.cli.app:subgroup
    :width: 65
    :convert-png: latex
    :make-sections:
    :preferred: text
