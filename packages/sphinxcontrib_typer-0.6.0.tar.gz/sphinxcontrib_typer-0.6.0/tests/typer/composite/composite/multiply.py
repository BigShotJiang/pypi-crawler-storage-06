import typer


def multiply(arg1: float, arg2: float):
    typer.echo(f"{arg1 * arg2}")
