.. typer:: composite.cli.app
    :prog: composite
    :width: 65
    :convert-png: latex
    :make-sections:
    :preferred: text
