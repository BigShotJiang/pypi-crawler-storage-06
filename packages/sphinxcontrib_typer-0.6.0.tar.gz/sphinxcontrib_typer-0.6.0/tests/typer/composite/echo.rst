.. typer:: composite.cli.app:subgroup:echo
    :width: 65
    :convert-png: latex
    :make-sections:
    :preferred: text
