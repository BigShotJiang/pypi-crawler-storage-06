### Authenticated API Endpoint Examples

----
The scripts in this folder provide examples of how to use the `mhanndalorian-bot` Python library to interact with
authenticated API endpoints provided by https://mhanndalorianbot.work

