### Global Player Registry Examples

----
The scripts in this folder provide examples of how to use the `mhanndalorian-bot` Python library to interact with SWGOH
Player Registry provided by https://mhanndalorianbot.work

