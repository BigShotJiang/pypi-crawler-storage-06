#!/usr/bin/env python3
"""genomehubs version."""

__version__ = "2.11.6"
