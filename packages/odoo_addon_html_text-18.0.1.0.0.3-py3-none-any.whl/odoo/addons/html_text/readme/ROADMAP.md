- An option could be added to try to respect the basic HTML tags inside
  the excerpt (`<b>`, `<i>`, `<p>`, etc.).
