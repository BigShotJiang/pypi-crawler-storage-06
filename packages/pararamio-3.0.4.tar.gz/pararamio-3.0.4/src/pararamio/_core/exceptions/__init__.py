"""Exceptions module."""

# Import base exceptions
# Import auth-specific exceptions
from .auth import *
from .base import *
