# baseui

## Installation (from PyPI)
```bash
pip install baseui
```

## Installation (from github, using SSH, branch: main)
```bash
pip install git+ssh://git@github.com/Abdelmathin/baseui.git@main
```

## Installation (from github, using SSH, branch: dev)
```bash
pip install git+ssh://git@github.com/Abdelmathin/baseui.git@dev
```

## Uninstallation

```bash
pip uninstall baseui
```
