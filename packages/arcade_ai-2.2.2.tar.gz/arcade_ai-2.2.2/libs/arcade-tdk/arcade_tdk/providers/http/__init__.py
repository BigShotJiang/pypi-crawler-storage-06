from arcade_tdk.providers.http.error_adapter import HTTPErrorAdapter

__all__ = ["HTTPErrorAdapter"]
