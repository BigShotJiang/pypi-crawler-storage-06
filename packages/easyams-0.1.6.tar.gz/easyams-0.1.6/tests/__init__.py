import easyams as ams

import os

if not os.path.exists('tests/outputs'):
    os.makedirs('tests/outputs', exist_ok=True)