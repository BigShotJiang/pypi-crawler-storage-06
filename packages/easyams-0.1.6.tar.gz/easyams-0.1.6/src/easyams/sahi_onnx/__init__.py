__version__ = "0.11.20"

from easyams.sahi_onnx.annotation import BoundingBox, Category, Mask
from easyams.sahi_onnx.auto_model import AutoDetectionModel
from easyams.sahi_onnx.models.base import DetectionModel
from easyams.sahi_onnx.prediction import ObjectPrediction
