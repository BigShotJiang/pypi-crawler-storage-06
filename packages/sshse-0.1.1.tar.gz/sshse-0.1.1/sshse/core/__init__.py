"""Core domain logic for sshse."""

__all__ = ["history", "interfaces"]
