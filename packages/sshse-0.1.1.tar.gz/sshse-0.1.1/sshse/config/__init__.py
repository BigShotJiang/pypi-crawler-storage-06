"""Configuration models and loaders for sshse."""
