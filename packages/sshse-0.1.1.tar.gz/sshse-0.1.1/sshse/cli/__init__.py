"""CLI package for the sshse application."""

from .app import app

__all__ = ["app"]
