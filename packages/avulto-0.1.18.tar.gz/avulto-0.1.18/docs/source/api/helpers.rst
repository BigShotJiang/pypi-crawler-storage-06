Helpers
=======

Avulto provides several Python functions that can be useful for inspecting
codebases.

