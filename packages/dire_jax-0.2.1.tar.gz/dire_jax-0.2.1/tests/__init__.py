# Benchmarks for the DiRe package
