.. _aiokafka: https://aiokafka.readthedocs.io/en/stable/index.html
.. _Alembic: https://alembic.sqlalchemy.org/en/latest/
.. _arq: https://arq-docs.helpmanual.io
.. _asyncmy: https://github.com/long2ice/asyncmy
.. _asyncpg: https://magicstack.github.io/asyncpg/current/
.. _Click: https://click.palletsprojects.com/en/stable/
.. _cryptography: https://cryptography.io/en/latest/
.. _FastAPI: https://fastapi.tiangolo.com/
.. _fastapi_safir_app: https://github.com/lsst/templates/tree/main/project_templates/fastapi_safir_app
.. _FastStream: https://faststream.ag2.ai
.. _Gafaelfawr: https://gafaelfawr.lsst.io/
.. _Gidgethub: https://gidgethub.readthedocs.io/en/latest/
.. _HTTPX: https://www.python-httpx.org/
.. _Kafka: https://kafka.apache.org/
.. _kubernetes_asyncio: https://github.com/tomplus/kubernetes_asyncio
.. _mypy: https://www.mypy-lang.org
.. _nox: https://nox.thea.codes/en/stable/
.. _Phalanx: https://phalanx.lsst.io
.. _pre-commit: https://pre-commit.com
.. _Pydantic: https://docs.pydantic.dev/latest/
.. _Pydantic BaseSettings: https://docs.pydantic.dev/latest/concepts/pydantic_settings
.. _pydantic-xml: https://pydantic-xml.readthedocs.io/en/latest/
.. _PyPI: https://pypi.org/project/safir/
.. _pytest: https://docs.pytest.org/en/latest/
.. _redis-py: https://redis.readthedocs.io/en/stable/
.. _respx: https://lundberg.github.io/respx/
.. _Roundtable: https://roundtable.lsst.io
.. _Sasquatch: https://sasquatch.lsst.io
.. _Sasquatch app metrics configuration: https://sasquatch.lsst.io/user-guide/app-metrics.html
.. _schema registry: https://docs.confluent.io/platform/current/schema-registry/index.html
.. _scriv: https://scriv.readthedocs.io/en/stable/
.. _Sentry: https://sentry.io/welcome/
.. _semver: https://semver.org/
.. _Sphinx: https://www.sphinx-doc.org/en/master/
.. _SQLAlchemy: https://www.sqlalchemy.org/
.. _SQuaRE Bot: https://squarebot.lsst.io/
.. _structlog: https://www.structlog.org/en/stable/
.. _templatekit: https://templatekit.lsst.io
.. _Testcontainers: https://github.com/testcontainers/testcontainers-python
.. _tox: https://tox.wiki/en/latest/
.. _tox-docker: https://tox-docker.readthedocs.io/en/latest/
.. _uv: https://docs.astral.sh/uv/
.. _Uvicorn: https://www.uvicorn.org/
.. _virtualenvwrapper: https://virtualenvwrapper.readthedocs.io/en/stable/
.. _vo-models: https://vo-models.readthedocs.io/latest/
.. _Wobbly: https://github.com/lsst-sqre/wobbly/
