import l1.l2.l3


class Test(l1.l2.l3.BaseTest):
    def test(self):
        pass
