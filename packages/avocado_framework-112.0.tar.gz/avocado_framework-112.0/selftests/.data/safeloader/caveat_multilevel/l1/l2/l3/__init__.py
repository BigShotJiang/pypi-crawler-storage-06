from avocado import Test


class BaseTest(Test):
    """BaseTest nothing-burguer class"""
