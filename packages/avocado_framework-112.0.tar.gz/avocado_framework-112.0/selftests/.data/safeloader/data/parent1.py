import avocado


class Class1(avocado.Test):
    def test(self):
        pass
