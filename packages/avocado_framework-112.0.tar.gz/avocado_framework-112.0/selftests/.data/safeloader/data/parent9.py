import avocado


class Class9(avocado.Test):
    def test(self):
        pass
