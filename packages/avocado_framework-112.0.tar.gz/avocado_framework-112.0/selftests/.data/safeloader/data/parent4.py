import avocado


class Class4(avocado.Test):
    def test(self):
        pass
