import avocado


class Class5(avocado.Test):
    def test(self):
        pass
