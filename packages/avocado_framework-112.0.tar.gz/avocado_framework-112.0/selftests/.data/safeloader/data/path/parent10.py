import avocado


class Class10(avocado.Test):
    def test(self):
        pass
