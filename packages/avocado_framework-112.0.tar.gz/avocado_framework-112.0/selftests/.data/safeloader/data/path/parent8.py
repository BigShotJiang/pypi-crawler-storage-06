import avocado


class Class8(avocado.Test):
    def test(self):
        pass
