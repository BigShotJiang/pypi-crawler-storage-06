import avocado


class Class3(avocado.Test):
    def test(self):
        pass
