#!/bin/sh
# This test demonstrates that executable tests (exec-tests) have
# access to parameters as environment variables.
echo "Custom variable: $CUSTOM_VARIABLE"

