# Forwarding
from ezRay.ezRay import MultiCoreExecutionTool

__all__ = ["MultiCoreExecutionTool"]
