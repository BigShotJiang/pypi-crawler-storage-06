# Flexiplex tag reformatter

Reformats the flexiplex barcode and UMI tags from the read name of a bamfile to the specific CB/UR tags.
This tool is very specific and only does this for one specific flexiplex command.