"""Tool to reformat flexiplex tags in a bam file"""

__version__ = "1.0.4"