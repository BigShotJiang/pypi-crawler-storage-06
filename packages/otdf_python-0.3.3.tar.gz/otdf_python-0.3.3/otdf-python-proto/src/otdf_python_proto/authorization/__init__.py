"""authorization protobuf definitions."""
