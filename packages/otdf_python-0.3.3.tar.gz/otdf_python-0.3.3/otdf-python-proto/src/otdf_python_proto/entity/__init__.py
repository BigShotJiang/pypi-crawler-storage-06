"""entity protobuf definitions."""
