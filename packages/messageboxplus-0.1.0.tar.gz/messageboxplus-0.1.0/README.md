# MessageBoxPlus

A Python wrapper for native Windows MessageBox with advanced options:
- Custom X/Y position
- Opacity (transparent windows)
- Always on top
- Remove close / minimize / maximize buttons

## Installation

```bash
pip install MessageBoxPlus
