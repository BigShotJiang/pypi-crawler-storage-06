"""
Django templatetags package for Cloudflare Turnstile integration.
"""
