"""
Cloudflare Turnstile integration for Django with HTMX support.
"""

__version__ = '0.1.0'
