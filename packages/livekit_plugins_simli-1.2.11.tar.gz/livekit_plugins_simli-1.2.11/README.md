# Simli Avatar plugin for LiveKit Agents

Support for the [Simi](https://simli.com/) virtual avatar.

See [https://docs.livekit.io/agents/integrations/avatar/simli/](https://docs.livekit.io/agents/integrations/avatar/simli/) for more information.

