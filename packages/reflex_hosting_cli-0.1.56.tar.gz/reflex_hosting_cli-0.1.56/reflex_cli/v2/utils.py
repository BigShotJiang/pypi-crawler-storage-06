"""Compat module for reflex 0.6.5 -> 0.6.6."""

from reflex_cli.utils import dependency as dependency
from reflex_cli.utils import hosting as hosting

# Do not add more stuff to this module, put it in reflex_cli.utils instead.
