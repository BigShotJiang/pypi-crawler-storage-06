
.. image:: https://badge.fury.io/py/galaxy-files.svg
   :target: https://pypi.org/project/galaxy-files/



Overview
--------

The Galaxy_ file sources framework and default plugins.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
