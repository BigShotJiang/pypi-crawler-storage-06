# MYCAL

A simple calculator package for Python.

## Installation

```bash
pip install mycal