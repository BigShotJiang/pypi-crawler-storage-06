Core tutorials overview
=======================

The following set of tutorials represent Supriya's *core* functionality: how it
interacts with the :doc:`core concepts <../introduction/concepts>`
underpinning the client/server relationship between Supriya and the
SuperCollider server.
