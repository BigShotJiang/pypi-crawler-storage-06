from django.apps import AppConfig


class NetBoxLoadBalancerConfig(AppConfig):
    name = "netbox_load_balancing"
