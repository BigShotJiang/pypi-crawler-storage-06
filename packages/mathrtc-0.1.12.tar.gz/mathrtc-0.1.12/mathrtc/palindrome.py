def palindrome(a):
  b=(a[::-1])
  if a==b:
   print("It's palindrome")
  else:
 	  print("It's not palindrome")