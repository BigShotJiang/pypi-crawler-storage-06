from .main import fact
from .fib import fib
from .palindrome import palindrome