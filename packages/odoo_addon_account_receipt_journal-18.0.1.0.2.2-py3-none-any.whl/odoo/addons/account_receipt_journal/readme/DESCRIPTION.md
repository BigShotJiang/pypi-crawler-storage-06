Define journals exclusive to receipts and automatically use them in sale
and purchase receipts A normal journal cannot be used in receipts if a
receipt journal has been created.
