from .feature1 import quadratic
from .feature2 import discriminant