### This is a Quadratic Equation Package for beginners. It is used to find the roots of a quadratic equation and identify the discriminant.
    - Feature 1: Roots of the equation.
    - Feature 2: Discriminant of the eqution and the nature of the roots.