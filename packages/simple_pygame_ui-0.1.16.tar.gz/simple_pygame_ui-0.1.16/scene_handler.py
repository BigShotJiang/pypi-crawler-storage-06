from better_math import Vector2i

current_scene = None
camera_size = Vector2i(800,600)
debugging = False
FPS = 60
delta = 0