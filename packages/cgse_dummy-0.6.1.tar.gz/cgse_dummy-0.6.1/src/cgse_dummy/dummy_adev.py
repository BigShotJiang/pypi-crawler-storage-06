"""
The asynchronous version of the device class.
"""
