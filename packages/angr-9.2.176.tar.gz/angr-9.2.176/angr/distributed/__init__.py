"""angr.distributed provides a simple implementation for conducting
long-running symbolic-execution-based tasks.
"""

from __future__ import annotations

from .server import Server

__all__ = ("Server",)
