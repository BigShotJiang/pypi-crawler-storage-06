======================================
Ironic Inspector Configuration Options
======================================

The following is a sample Ironic Inspector configuration for
adaptation and use. It is auto-generated from Ironic Inspector
when this documentation is built, so if you find issues with an
option, please compare your version of Ironic Inspector with the
version of this documentation.

The sample configuration can also be downloaded as a :download:`file
</_static/ironic-inspector.conf.sample>`.

.. literalinclude:: /_static/ironic-inspector.conf.sample
