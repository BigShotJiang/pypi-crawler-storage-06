===========================================
Zed Series (10.12.0 - 11.1.x) Release Notes
===========================================

.. release-notes::
   :branch: unmaintained/zed
