Changelog
=========

0.1.1 (2025-09-17)
------------------

- Small bugfixes & refactors

0.1.0 (2025-09-17)
------------------

- Initial public scaffolding of the Perceptron SDK.
- CLI entry point `perceptron` with Typer.
- Core DSL, pointing utilities, and high-level helpers.

