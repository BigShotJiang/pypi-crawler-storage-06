# Copyright AGNTCY Contributors (https://github.com/agntcy)
# SPDX-License-Identifier: Apache-2.0

judge_system_prompt = "You are a fair judge assistant tasked with grading a response."
