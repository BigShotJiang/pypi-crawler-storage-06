"""
Test module for goal success rate plugin.
"""
