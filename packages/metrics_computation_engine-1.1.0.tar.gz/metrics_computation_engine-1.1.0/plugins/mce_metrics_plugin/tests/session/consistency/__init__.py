"""
Test module for consistency plugin.
"""
