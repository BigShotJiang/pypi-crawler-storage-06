"""
Test module for information retention plugin.
"""
