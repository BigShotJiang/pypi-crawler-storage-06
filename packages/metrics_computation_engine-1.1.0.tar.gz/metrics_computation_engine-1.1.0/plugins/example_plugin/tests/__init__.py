"""
Test module for span counter plugin.
"""
