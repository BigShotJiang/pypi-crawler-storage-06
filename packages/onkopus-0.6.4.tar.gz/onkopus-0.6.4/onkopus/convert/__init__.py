from .ProteinToGenomic import *
from.TranscriptToGenomic import *
