client
------

.. automodule:: telnetlib3.client
   :members:
