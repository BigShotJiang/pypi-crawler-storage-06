# -*- coding: utf-8 -*-
"""Digital Marketplace normalised exception classes."""


class EmailError(Exception):
    pass


class EmailTemplateError(EmailError):
    pass


class EmailInvalidError(EmailError):
    pass
