The files in this directory are kept for reference from an earlier organization
of the project.

For the latest documentation, please refer to the main README.md file in the root 
directory.
