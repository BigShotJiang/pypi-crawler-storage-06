"""Configuration module for mouse tracking runtime."""

from .config import get_config

__all__ = ["get_config"]
