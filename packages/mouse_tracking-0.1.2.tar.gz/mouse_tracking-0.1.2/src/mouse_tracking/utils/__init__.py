"""Utility module for Mouse Tracking Runtime."""
