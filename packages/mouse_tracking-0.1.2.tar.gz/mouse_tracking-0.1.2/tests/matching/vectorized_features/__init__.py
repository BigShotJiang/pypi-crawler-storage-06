"""Tests for vectorized features matching."""
