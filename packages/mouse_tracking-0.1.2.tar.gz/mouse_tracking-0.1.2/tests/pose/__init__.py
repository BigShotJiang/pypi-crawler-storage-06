"""Tests for the pose module."""
