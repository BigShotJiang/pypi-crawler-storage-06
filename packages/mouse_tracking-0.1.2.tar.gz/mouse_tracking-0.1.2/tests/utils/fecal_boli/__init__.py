"""Tests for the fecal boli utils module."""
