"""Tests for the segmentation utils module."""
