"""Test run-length encoding utility functions."""
