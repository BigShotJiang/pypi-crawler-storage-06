"""Tests for the static objects utils module."""
