"""Tests for the pose utils module."""
