minrpc
------

|Version| |License| |Python| |Tests| |Coverage|

Minimalistic RPC utility.

Please do not use. This package is only used within cpymad and pytao.


.. |Tests| image::      https://github.com/coldfix/minrpc/workflows/Tests/badge.svg
   :target:             https://github.com/coldfix/minrpc/actions?query=Tests
   :alt:                GitHub Actions Status

.. |Coverage| image::   https://coveralls.io/repos/hibtc/minrpc/badge.svg?branch=master
   :target:             https://coveralls.io/r/hibtc/minrpc
   :alt:                Coverage

.. |Version| image::    https://img.shields.io/pypi/v/minrpc.svg
   :target:             https://pypi.python.org/pypi/minrpc/
   :alt:                Latest Version

.. |License| image::    http://img.shields.io/pypi/l/minrpc.svg
   :target:             https://github.com/hibtc/minrpc/blob/master/COPYING.GPLv3.txt
   :alt:                License

.. |Python| image::     http://img.shields.io/pypi/pyversions/minrpc.svg
   :target:             https://pypi.python.org/pypi/minrpc#downloads
   :alt:                Supported Python versions
