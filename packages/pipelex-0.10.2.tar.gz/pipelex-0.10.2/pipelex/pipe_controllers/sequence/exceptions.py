class PipeSequenceBlueprintError(Exception):
    pass


class PipeSequenceError(Exception):
    pass
