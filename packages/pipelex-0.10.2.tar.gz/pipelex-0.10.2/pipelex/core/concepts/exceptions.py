class ConceptCodeError(Exception):
    pass


class ConceptStringError(Exception):
    pass


class ConceptStringOrConceptCodeError(Exception):
    pass
