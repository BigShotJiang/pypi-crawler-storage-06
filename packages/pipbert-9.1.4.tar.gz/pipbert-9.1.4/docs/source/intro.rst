===================
General Description
===================

.. automodule:: pybert

.. include:: ../../README.md
