====================
``.cdr`` - CDR Model
====================

.. automodule:: pybert.models.cdr
   :members:
