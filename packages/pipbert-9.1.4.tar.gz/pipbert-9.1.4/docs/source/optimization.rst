====================================================
``.optimization`` - Equalization Optimization Thread
====================================================

.. automodule:: pybert.threads.optimization
   :members:
