===========================
``.hspice`` - HSpice Parser
===========================

**Note:** The ``pybert.parsers.hspice`` module cannot currently be auto-documented, due to its use of the ``<<`` operator override.
If you're interested in the implementation of this parser then please see the `source code <https://github.com/capn-freako/PyBERT/blob/master/src/pybert/parsers/hspice.py>`_.
