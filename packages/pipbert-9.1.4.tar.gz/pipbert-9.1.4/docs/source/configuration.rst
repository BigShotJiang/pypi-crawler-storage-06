======================================================================
``.configuration`` - Data structure for saving *PyBERT* configuration.
======================================================================

.. automodule:: pybert.configuration
   :members:
