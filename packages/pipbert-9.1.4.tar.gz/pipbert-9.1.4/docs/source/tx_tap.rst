=========================================
``.tx_tap`` - Tx Deemphasis FIR Tap Tuner
=========================================

.. automodule:: pybert.models.tx_tap
   :members:
