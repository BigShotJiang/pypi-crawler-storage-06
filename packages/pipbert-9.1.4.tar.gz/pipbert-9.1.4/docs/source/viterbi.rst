====================================
``.viterbi`` - Viterbi Decoder Model
====================================

.. automodule:: pybert.models.viterbi
   :exclude-members: ViterbiDecoder_ISI

.. autoclass:: pybert.models.viterbi.ViterbiDecoder_ISI
   :exclude-members: prob, states, trans, trellis, sigma, v_prob
