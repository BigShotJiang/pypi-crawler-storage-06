=========================================
``.channel`` - Channel Modeling Utilities
=========================================

.. automodule:: pybert.utility.channel
   :members:
