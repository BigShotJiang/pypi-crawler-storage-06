=========================================
``.stoppable`` - Generic Stoppable Thread
=========================================

.. automodule:: pybert.threads.stoppable
   :members:
