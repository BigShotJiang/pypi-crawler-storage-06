=============================
``.help`` - GUI - Help Screen
=============================

.. automodule:: pybert.gui.help
   :members:
