"""get_assets_folder"""

import os


def get_assets_folder():
    """Get the path to the folder containing all the front end assets"""
    return os.path.dirname(__file__)
