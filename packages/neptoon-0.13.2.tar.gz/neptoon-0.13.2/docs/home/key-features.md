## Current features


## Future features

We still have plans for neptoon. Future plans can be found in the [roadmap](roadmap.md)