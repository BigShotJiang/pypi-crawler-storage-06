# Install This Plugin

`nomad-json-parser` can be installed to your oasis via the steps given in [here](https://github.com/FAIRmat-NFDI/nomad-distro-template?tab=readme-ov-file#adding-a-plugin).