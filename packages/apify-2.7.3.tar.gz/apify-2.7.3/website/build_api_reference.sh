#!/bin/bash

# Generate import shortcuts from the modules
python generate_module_shortcuts.py
