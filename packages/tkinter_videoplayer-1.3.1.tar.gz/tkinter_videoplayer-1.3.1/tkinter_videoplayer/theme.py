COLOR_CONTROLS_BG = "#171a1f"  # Main background
COLOR_SLIDER_BG = "#fff"  # Main foreground/text
FONT = ("Verdana", 9)
COLOR_PRIMARY = "#3498db"  # Primary accent (blue)
COLOR_TERTIARY = "#888"  # Tertiary accent (gray)
