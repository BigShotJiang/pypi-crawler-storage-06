"""
The ``core`` package contains the core functionality for defining and managing extractors.

It contains the base class for extractors, the runtime for running extractors, and classes for tasks and errors.
"""
