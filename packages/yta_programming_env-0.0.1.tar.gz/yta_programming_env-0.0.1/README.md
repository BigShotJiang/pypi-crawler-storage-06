# Youtube Autonomous Programming Environment add-on

The way to work internally with some of the functionalities we need related to handling environment variables.