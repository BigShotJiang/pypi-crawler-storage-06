- Philippe Rossi \<<pr@numerigraphe.com>\> (initial patch against v6.0)
- Lionel Sausin \<<ls@numerigraphe.com>\> (modularization for v7+)
- Jordi Ballester Alomar \<<jordi.ballester@forgeflow.com>\>
  (modularization v8, v9)
- Lois Rilo \<<lois.rilo@forgeflow.com>\> (migration to v10)
- Alexandre Fayolle \<<alexandre.fayolle@camptocamp.com>\>
- Pimolnat Suntian \<<pimolnats@ecosoft.co.th>\>
- Mallory Marcot \<<contact@mallory-marcot.com>\>
- Denis Roussel \<<denis.roussel@acsone.eu>\>
- Jacques-Etienne Baudoux (BCIM) \<<je@bcim.be>\>
