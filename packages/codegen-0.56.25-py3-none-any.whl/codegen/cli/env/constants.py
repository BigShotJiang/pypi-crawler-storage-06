from codegen.cli.env.enums import Environment

DEFAULT_ENV = Environment.PRODUCTION
