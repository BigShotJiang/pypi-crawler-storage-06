from differt_core import (  # Re-export version from core module
    __version__,
    __version_info__,
)

__all__ = ("__version__", "__version_info__")
