import Alpine from '@alpinejs/csp'

window.Alpine = Alpine

export default Alpine
