""" Load and export `ethology` datasets."""
