# Related projects

We are the same developer team as the one behind [`movement`](https://movement.neuroinformatics.dev/index.html#), a Python package for analysing animal body movements across space and time. We interact very closely with their community to make sure our tools are interoperable and we follow very similar conventions and standards.
