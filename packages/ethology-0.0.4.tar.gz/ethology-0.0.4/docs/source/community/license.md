# License

[The 3-Clause BSD License](https://opensource.org/license/bsd-3-clause/)

```{include} ../../../LICENSE
```
