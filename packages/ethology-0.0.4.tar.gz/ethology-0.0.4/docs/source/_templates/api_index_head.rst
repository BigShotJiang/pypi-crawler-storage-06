.. API reference
.. Information on specific functions, classes, and methods.
.. This file is used to Auto generate the API reference index page.

.. _target-api:

API reference
=============

Information on specific functions, classes, and methods.

.. rubric:: Modules

.. autosummary::
    :toctree: api
    :recursive:
    :nosignatures:
