You may be able to find older Immigration and Asylum Chamber decisions [on the Courts and Tribunals Judiciary website](https://www.judiciary.uk/courts-and-tribunals/tribunals/upper-tribunal/upper-tribunal-immigration-and-asylum-chamber/upper-tribunal-immigration-and-asylum-chamber-decisions/){target="\_blank"}.

You can read more about how to find older immigration records in The National Archives in the [Immigration and immigrants research guide](https://www.nationalarchives.gov.uk/help-with-your-research/research-guides/immigration/){target="\_blank"}.
