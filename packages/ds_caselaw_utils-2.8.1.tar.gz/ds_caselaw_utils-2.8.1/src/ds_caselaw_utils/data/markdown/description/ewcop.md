The Court of Protection makes decisions on financial or welfare matters for people who can’t make decisions at the time they need to be made (they ‘lack mental capacity’).

This court began to regularly transfer judgments to The National Archives in 2022. The oldest judgment from this court included in Find Case Law is from {start_year}.

You can read more about it on the [Court of Protection page](https://www.gov.uk/courts-tribunals/court-of-protection){target="\_blank"} on the [HM Courts and Tribunals Service website](https://www.gov.uk/government/organisations/hm-courts-and-tribunals-service/about){target="\_blank"}.
