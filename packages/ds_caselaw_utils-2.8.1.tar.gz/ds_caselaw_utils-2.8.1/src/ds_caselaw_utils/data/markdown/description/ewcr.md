The Crown Court deals with the most serious criminal offences. It is located in over 70 court centres across England and Wales, including the Central Criminal Court, more commonly known as the Old Bailey.

This court began to occasionally transfer selected judgments to The National Archives in 2024. The oldest judgment from this court included in Find Case Law is from {start_year}.

You can read more about this court on the [Crown Court page](https://www.judiciary.uk/courts-and-tribunals/crown-court/){target="\_blank"} on the [HM Courts and Tribunals Service website](https://www.judiciary.uk/){target="\_blank"}.
