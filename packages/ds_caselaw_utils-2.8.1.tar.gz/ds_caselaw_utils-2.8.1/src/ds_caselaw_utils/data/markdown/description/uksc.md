The Supreme Court is the final court of appeal for civil cases in all of the UK and for criminal cases in England, Wales and Northern Ireland. Typically this court deals with important legal questions that affect the public or the constitution.

The UK Supreme Court was established in October 2009. This court began to regularly transfer judgments to The National Archives in 2022. The oldest judgment from this court included in Find Case Law is from {start_year}. House of Lords decisions from before 2009 are held by the Parliamentary Archives.

You can read more about it on the [UK Supreme Court website](https://www.supremecourt.uk/){target="\_blank"}.
