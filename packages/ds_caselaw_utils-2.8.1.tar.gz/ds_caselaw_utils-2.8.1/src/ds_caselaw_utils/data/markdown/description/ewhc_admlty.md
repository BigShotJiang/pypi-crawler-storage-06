The Admiralty Court is a specialist court within the King's Bench Division of the High Court. It specialises in shipping and maritime disputes and has the power to arrest and sell ships in England and Wales.

This court began to regularly transfer judgments to The National Archives in 2022. The oldest judgment from this court included in Find Case Law is from {start_year}.

You can read more about [the Admiralty court on the judiciary website](https://www.judiciary.uk/courts-and-tribunals/business-and-property-courts/admiralty-court/){target="\_blank"}.
