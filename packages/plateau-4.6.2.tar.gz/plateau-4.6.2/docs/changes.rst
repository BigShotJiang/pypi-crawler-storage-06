.. _changes:

For details of the versioning schema, see :ref:`versioning`.

.. include:: ../CHANGES.rst
