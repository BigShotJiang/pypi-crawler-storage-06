from ._sizeof import register_sizeof_ktk_classes

register_sizeof_ktk_classes()
