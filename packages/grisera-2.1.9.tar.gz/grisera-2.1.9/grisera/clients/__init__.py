"""
Shared clients module for external services like MinIO, databases, etc.
"""