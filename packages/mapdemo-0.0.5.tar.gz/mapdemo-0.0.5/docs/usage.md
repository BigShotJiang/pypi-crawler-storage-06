# Usage

To use mapdemo in a project:

```
import mapdemo
```
