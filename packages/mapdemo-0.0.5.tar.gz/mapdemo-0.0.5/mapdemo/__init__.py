"""Top-level package for mapdemo."""

__author__ = """Atul Bhardwaj"""
__email__ = "atulmncfc@gmail.com"
__version__ = "0.0.5"

from .mapdemo import *