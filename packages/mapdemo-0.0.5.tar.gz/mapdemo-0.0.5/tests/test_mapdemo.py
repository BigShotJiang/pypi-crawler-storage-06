#!/usr/bin/env python

"""Tests for `mapdemo` package."""


import unittest

from mapdemo import mapdemo


class TestMapdemo(unittest.TestCase):
    """Tests for `mapdemo` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
