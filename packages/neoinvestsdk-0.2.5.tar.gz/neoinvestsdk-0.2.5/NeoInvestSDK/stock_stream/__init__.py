"""StockStream WebSocket client for real-time market data"""

from .client import StockStream

__all__ = ["StockStream"]
