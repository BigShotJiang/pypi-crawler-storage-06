# safe-esg-pai-assistance-kit

Minimal tools for SFDR PAI interpolation & diagnostics.

## Install
```bash
pip install safe-esg-pai-assistance-kit
```

## Quickstart
```python
from safe_esg_pai_assistance_kit import run_informative_regression_ols
# Use your own DataFrame and variables; reach out to the author for guidance.
```
