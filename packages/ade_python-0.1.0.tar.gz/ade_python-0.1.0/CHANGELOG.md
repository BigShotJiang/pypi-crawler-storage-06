# Changelog

## 0.1.0 (2025-09-18)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/landing-ai/ade-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([eb76a32](https://github.com/landing-ai/ade-python/commit/eb76a3275704d50396d00fd8ac79c2537ce251fc))


### Chores

* configure new SDK language ([9761e2b](https://github.com/landing-ai/ade-python/commit/9761e2bed207087deba958e693fd381eb5599a67))
* update SDK settings ([b46e740](https://github.com/landing-ai/ade-python/commit/b46e74012a27713aaa82f99bd11e527c92e912f4))
* update SDK settings ([982e228](https://github.com/landing-ai/ade-python/commit/982e2280ef59753578cfc5c4272fca2f90c2083a))
