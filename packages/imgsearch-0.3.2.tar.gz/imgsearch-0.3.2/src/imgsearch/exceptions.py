"""Exceptions"""


class NotRunningError(Exception):
    pass
