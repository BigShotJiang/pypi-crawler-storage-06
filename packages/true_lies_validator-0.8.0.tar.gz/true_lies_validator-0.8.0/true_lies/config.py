POSITIVE_MARKERS = [
    "can", "allowed", "unlimited", "earn", "earns", "accrues", "compounds",
    "applied", "applies", "calculated", "credited", "added", "gains", "yields", "returns", "benefits"
]

NEGATIVE_MARKERS = [
    "cannot", "not allowed", "no ", "not", "limited", "does not", "can't",
    "not supposed to", "should not", "not expected to", "never"
]

SIMILARITY_THRESHOLD = 0.7