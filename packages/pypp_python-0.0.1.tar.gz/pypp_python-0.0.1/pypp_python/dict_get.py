from typing import Any


def dg[T](d: dict[Any, T], index: int) -> T:
    return d[index]
