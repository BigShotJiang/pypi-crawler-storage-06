def exception(cls):
    return cls
