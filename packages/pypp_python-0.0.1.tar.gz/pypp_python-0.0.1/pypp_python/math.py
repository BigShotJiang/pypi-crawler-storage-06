def int_pow(base: int, exp: int) -> int:
    return base**exp
