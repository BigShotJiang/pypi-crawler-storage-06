from abc import ABC, abstractmethod

__all__ = ["ABC", "abstractmethod"]
