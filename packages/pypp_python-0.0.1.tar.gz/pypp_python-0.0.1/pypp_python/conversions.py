from typing import Any


def to_float32(value: Any) -> float:
    return float(value)


def to_int8_t(value: Any) -> int:
    return int(value)


def to_int16_t(value: Any) -> int:
    return int(value)


def to_int32_t(value: Any) -> int:
    return int(value)


def to_int64_t(value: Any) -> int:
    return int(value)


def to_uint8_t(value: Any) -> int:
    return int(value)


def to_uint16_t(value: Any) -> int:
    return int(value)


def to_uint32_t(value: Any) -> int:
    return int(value)


def to_uint64_t(value: Any) -> int:
    return int(value)
