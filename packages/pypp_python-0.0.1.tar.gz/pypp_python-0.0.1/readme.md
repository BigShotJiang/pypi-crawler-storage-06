# Py++ Python
This library contains necessary python code for Py++ projects.

Py++ (Compiled Python) is a Python framework for writing Python projects which can be transpiled into C++ (CMake) projects.

https://github.com/curtispuetz/pypp-cli