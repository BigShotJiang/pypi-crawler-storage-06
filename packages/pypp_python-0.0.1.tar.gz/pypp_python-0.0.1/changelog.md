# Changelog

## 0.0.1
- fix issue with pypp_get_resources pointing to the wrong place

## 0.0.0
First packaging