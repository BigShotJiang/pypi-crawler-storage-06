""" Expose version """

__version__ = "0.5.3"
VERSION = __version__.split(".")
