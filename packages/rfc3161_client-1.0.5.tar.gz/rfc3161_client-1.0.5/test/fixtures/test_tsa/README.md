The timestamp in this directory were generated using the script in [scripts/update_fixtures.py](../../../scripts/update_fixtures.py) and using a local Timestamp Server Authority from the Sigstore project ([source](https://github.com/sigstore/timestamp-authority/)). 

To update the timestamps, run the script from the root of the repository.

```bash
uv run scripts/update_fixtures.py --help
```