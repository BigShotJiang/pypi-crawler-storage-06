import cryptography.x509

SHA256_OID = cryptography.x509.ObjectIdentifier("2.16.840.1.101.3.4.2.1")
SHA512_OID = cryptography.x509.ObjectIdentifier("2.16.840.1.101.3.4.2.3")
