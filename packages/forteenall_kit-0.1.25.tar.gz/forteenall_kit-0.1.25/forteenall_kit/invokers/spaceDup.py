class Data:
    pass

class Feature:
    def createDjangoProject(self):
        pass
    def createReactNativeProject(self):
        pass
    def createDjangoProject(self):
        pass
    def execute(self):
        pass
