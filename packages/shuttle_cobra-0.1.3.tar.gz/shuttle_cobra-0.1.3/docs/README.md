---
icon: hand-wave
layout:
  width: default
  title:
    visible: true
  description:
    visible: false
  tableOfContents:
    visible: true
  outline:
    visible: true
  pagination:
    visible: true
  metadata:
    visible: true
---

# Introduction

<table data-view="cards"><thead><tr><th></th><th data-hidden data-card-target data-type="content-ref"></th></tr></thead><tbody><tr><td>Installation and quickstart guide</td><td><a href="broken-reference">Broken link</a></td></tr><tr><td>Follow one of our tutorials</td><td><a href="broken-reference">Broken link</a></td></tr><tr><td>Get started from one of many templates</td><td></td></tr><tr><td>Complete reference for all Shuttle CLI commands and options</td><td><a href="reference/cli-reference.md">cli-reference.md</a></td></tr><tr><td>Understand the core concepts and architecture of Shuttle</td><td><a href="broken-reference">Broken link</a></td></tr></tbody></table>
