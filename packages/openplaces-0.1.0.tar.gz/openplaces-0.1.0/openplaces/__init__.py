"""openplaces - A package for working with geospatial property data."""

__version__ = "0.1.0"
__author__ = "Christoph Nolte, openplaces Consortium"
__email__ = "nolte.christoph@gmail.com"

from .main import *