==============
Administration
==============

The Diagram Trace Menu allows administrators to set the colors that will be used for
a trace.


.. toctree::
    :maxdepth: 3
    :caption: Contents:

    admin_tasks/admin_tasks

