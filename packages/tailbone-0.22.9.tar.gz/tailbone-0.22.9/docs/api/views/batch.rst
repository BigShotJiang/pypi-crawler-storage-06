
``tailbone.views.batch``
========================

.. automodule:: tailbone.views.batch
