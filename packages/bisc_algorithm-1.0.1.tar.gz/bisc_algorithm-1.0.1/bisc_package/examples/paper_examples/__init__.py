"""
Examples from the BiSC paper.
"""