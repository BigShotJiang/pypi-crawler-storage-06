"""
Examples for well-known permutation classes.
"""

__all__ = []