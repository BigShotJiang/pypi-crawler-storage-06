Changelog
=========

1.0.0 (2025-09-09)
------------------
- Making and mark the package typed.
- 100% code linting.
- 100% code coverage.
- Setup (dependencies) update.

0.1.0 (2025-09-01)
------------------
- First public release.

0.0.0 (2025-07-17)
------------------
- Initial commit.
