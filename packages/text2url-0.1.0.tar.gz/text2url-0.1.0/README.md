# text2url

Serve a file or stdin input via Cloudflare Tunnel.
