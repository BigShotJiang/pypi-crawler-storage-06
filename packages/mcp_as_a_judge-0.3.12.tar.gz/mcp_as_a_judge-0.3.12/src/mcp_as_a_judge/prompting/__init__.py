"""
Prompt loading utilities and helpers.
"""
