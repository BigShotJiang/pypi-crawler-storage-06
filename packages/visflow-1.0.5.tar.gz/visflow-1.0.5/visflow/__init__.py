from __future__ import annotations

__version__ = "1.0.5"
__title__ = __project__ = "Visflow"
