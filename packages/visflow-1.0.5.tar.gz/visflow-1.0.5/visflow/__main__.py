from __future__ import annotations

from ._cli import main

main()
