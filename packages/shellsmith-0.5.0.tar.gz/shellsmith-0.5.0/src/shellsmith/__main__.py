"""Entry point for running shellsmith as a CLI tool."""

from shellsmith.cli.app import main

if __name__ == "__main__":
    main()
