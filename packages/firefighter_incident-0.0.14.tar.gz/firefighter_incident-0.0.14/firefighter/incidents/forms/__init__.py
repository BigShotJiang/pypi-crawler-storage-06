from __future__ import annotations

from firefighter.incidents.forms.create_incident import CreateIncidentForm
