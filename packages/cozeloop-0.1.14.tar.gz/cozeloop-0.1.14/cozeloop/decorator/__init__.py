# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

from cozeloop.decorator.decorator import CozeLoopDecorator

coze_loop_decorator= CozeLoopDecorator()
observe = coze_loop_decorator.observe
