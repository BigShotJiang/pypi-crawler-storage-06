## 0.0.49 - 2025-09-17

* fix locate user methods to be an exact match (79a254c)
* updating docs (636cc50)
* updating docs (67a7d49)
* Update version to 0.0.48 and changelog (a446265)