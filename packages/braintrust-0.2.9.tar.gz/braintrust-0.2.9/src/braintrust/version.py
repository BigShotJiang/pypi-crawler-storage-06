VERSION = "0.2.9"

# this will be templated during the build
GIT_COMMIT = "500c2fddb600fcbe7a7d8a48d4e1fe7c3bdcfea7"
