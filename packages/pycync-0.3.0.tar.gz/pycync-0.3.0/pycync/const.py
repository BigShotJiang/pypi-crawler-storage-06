"""Constants for the API."""

GE_CORP_ID = "1007d2ad150c4000"

REST_API_BASE_URL = "https://api.gelighting.com"