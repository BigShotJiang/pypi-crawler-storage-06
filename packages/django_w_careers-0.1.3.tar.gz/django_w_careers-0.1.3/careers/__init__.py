"""Django Careers: A reusable employment app powered by Python, Django, DRF, Wagtail CMS and TailwindCSS"""
