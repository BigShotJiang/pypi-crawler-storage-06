"""careers UI"""
