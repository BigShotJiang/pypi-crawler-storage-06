"""Tests for careers.apps.jobs.models"""

from django.test import TestCase


# Create your tests here.
class JobTests(TestCase):
    """Job model tests"""

    def setUp(self) -> None:
        """Setup before tests"""

        return super().setUp()
