"""Tests for careers.indexes"""
