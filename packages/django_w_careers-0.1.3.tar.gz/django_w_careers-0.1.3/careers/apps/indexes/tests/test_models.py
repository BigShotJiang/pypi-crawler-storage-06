"""Tests for careers.indexes.models"""

from django.test import TestCase


# Create your tests here.
class CareersIndexTests(TestCase):
    """careersIndex model tests"""

    def setUp(self) -> None:
        """Setup before tests"""

        return super().setUp()
