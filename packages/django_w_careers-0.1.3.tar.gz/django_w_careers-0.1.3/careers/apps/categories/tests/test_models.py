"""Tests for careers.apps.categories.models"""

from django.test import TestCase


# Create your tests here.
class CategoryTests(TestCase):
    """Category tests"""

    def setUp(self) -> None:
        """Setup before running tests"""
