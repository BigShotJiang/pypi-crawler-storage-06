"""Tests for careers.apps.categories"""
