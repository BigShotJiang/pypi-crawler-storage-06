"""Top-level package for SmolRouter."""

__all__ = ["__version__"]
__version__ = "1.0.0"
