docDbGenericMenuFilt = {"plugin": "peek_plugin_docdb_generic_menu"}
docDbGenericMenuTuplePrefix = "peek_plugin_docdb_generic_menu."
docDbGenericMenuObservableName = "peek_plugin_docdb_generic_menu"
docDbGenericMenuActionProcessorName = "peek_plugin_docdb_generic_menu"
docDbGenericMenuTupleOfflineServiceName = "peek_plugin_docdb_generic_menu"
