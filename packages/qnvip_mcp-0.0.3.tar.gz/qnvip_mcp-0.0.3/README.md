# 青年优品mcp工具集

## 支持功能
1. markdown的table 转 excel `python util/md2excel.py xxx.md xxx.xlsx` 



## 包构建发布命令
1. 安装打包工具
pip install setuptools twine

2. 构建包
python setup.py sdist bdist_wheel

3.  上传到 PyPI
twine upload dist/*


## 如何使用

### 方式1: 直接安装使用
```bash
# 安装你的服务
pip install -i https://pypi.org/simple/ qnvip-mcp

# 启动服务（通过你定义的命令）
qnvip-mcp
```

### 方式2: 使用 uv run（推荐）
```bash
# 直接运行，无需安装
uv run --with qnvip-mcp qnvip-mcp

# 或者指定 PyPI 源
uv run --with qnvip-mcp --index-url https://pypi.org/simple/ qnvip-mcp
```

### 方式3: 在项目中使用
```bash
# 添加到项目依赖
uv add qnvip-mcp

# 运行
uv run qnvip-mcp
```

