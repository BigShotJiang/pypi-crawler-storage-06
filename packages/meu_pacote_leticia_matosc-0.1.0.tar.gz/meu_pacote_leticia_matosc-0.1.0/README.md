# meu_pacote

Pacote simples criado como exemplo para curso de Python.

Autora: Leticia Matos
"# meu-pacote"  
