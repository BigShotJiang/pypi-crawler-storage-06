# -*- coding: utf-8 -*-

from mwfilter.apps.copy.app import CopyApp as _CopyApp


class IndexApp(_CopyApp):
    pass
