# -*- coding: utf-8 -*-

from sys import exit as sys_exit

from mwfilter.entrypoint import main

if __name__ == "__main__":
    sys_exit(main())
