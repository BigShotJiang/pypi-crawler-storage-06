"""FastBlocks routes adapters."""
