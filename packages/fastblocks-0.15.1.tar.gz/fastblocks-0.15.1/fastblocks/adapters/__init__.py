"""FastBlocks adapters package."""
