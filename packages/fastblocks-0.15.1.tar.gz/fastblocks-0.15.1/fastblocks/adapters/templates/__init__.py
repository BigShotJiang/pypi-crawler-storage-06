"""FastBlocks templates adapters."""
