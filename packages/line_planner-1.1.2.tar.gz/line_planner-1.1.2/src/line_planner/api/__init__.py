"""
API interfaces for line planning - 简化版
"""

from .stdin_processor import process_stdin_request

__all__ = [
    'process_stdin_request',
]