"""Init file for models module"""

from .file_data import FileData
