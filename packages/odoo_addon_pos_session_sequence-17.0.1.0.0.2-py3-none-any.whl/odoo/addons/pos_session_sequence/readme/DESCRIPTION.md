This module allows you to configure multiple sequences for every session in different points of sale.

