
To use this module, you need to:

- Go to Configuration > Settings
- Setup `Session Ids Sequence` for the Point of Sale
- Open the session for the point of sale and you will see the name computed with the sequence