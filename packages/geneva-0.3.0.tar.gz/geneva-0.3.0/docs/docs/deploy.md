---
title: Redirecting…
---

<meta http-equiv="refresh" content="0; url=https://lancedb.com/docs/geneva/deployment/">
<link rel="canonical" href="url=https://lancedb.com/docs/geneva/deployment/">

If you are not redirected, <a href="url=https://lancedb.com/docs/geneva/deployment/">click here</a>.
