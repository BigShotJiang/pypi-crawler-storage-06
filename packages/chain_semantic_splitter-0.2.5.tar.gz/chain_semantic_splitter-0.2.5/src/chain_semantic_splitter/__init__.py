# -*- coding: utf-8 -*-
"""
Expose the main class for easy importing.
"""
from .splitter import SemanticCharacterTextSplitter

__all__ = ["SemanticCharacterTextSplitter"]
