Allow to add a icon to clone the line.
