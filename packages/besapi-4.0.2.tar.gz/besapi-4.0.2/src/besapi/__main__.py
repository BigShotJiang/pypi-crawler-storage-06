"""To run this module directly."""

import logging

from bescli import bescli

logging.basicConfig()
bescli.main()
