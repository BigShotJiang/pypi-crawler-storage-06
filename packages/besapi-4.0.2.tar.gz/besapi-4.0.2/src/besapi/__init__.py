"""Besapi is a python module for interacting with the BigFix REST API."""

# https://stackoverflow.com/questions/279237/import-a-module-from-a-relative-path/4397291

from . import besapi
