.. CurrencyConverter documentation master file, created by
   sphinx-quickstart on Sun Mar  4 20:29:15 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CurrencyConverter's documentation!
=============================================

.. automodule:: currency_converter.currency_converter
    :members:
    :special-members: __init__
    :undoc-members:
    :show-inheritance:
