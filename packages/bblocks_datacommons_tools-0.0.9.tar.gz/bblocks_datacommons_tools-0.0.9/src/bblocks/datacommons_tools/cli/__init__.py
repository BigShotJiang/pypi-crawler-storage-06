"""Command line interface for ``bblocks.datacommons_tools`` package."""

from bblocks.datacommons_tools.cli.main import main

__all__ = ["main"]
