# sage_setup: distribution = sagemath-schemes
