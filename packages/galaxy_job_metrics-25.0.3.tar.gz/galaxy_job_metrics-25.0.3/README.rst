
.. image:: https://badge.fury.io/py/galaxy-job-metrics.svg
   :target: https://pypi.org/project/galaxy-job-metrics/


Overview
--------

The Galaxy_ job metrics framework and default plugins.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
