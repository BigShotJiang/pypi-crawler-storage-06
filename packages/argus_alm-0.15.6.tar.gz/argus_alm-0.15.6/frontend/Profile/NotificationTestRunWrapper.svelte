<script lang="ts">
    let { supportData } = $props();
</script>

<div>
    <!-- Placeholder -->
</div>
