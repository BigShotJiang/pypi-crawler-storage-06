<script>

    /**
     * @typedef {Object} Props
     * @property {Object} args
     */

    /** @type {Props} */
    let { args } = $props();
</script>

<div>
    <span class="spinner-border spinner-border-sm"></span> Starting next build...
</div>
