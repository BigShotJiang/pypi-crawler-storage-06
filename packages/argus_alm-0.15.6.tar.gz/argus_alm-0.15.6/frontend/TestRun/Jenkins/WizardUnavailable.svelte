<div>
    Wizard is not available for this test type.
</div>
