# starting
```shell
cd argusAI
PYTHONPATH=.. uv run event_similarity_processor.py
```
