from .fount import Fount

__version__ = "0.1.0"
__author__ = "Bibek Sahu"
__email__ = "bibek@datapoem.com"


__all__ = [
    # Main client
    "Fount",
    # Version
    "__version__",
]
