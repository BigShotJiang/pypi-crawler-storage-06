"""Logging package for structured logging."""
