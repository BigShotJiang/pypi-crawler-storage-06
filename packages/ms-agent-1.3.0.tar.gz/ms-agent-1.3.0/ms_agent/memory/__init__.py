# Copyright (c) Alibaba, Inc. and its affiliates.
from .base import Memory
from .utils import DefaultMemory, memory_mapping
