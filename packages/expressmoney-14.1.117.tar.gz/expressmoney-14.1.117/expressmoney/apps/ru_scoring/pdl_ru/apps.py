from django.apps import AppConfig


class PdlRuConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'expressmoney.apps.ru_scoring.pdl_ru'
