# AUTO GENERATED ON 2025-09-20 AT 15:57:04
# DO NOT EDIT BY HAND!
#
# To regenerate file, run
#
#     python dev/generate-tests.py
#

# fmt: off

import ctypes
import numpy as np
import pytest

from awkward_cpp.cpu_kernels import lib

@pytest.mark.skip(reason='Unable to generate any tests for kernel')
def test_cpuawkward_IndexedArrayU32_overlay_mask8_to64_1():
    raise NotImplementedError('Unable to generate any tests for kernel')
