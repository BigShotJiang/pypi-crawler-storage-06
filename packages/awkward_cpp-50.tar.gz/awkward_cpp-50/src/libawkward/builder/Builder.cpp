// BSD 3-Clause License; see https://github.com/scikit-hep/awkward/blob/main/LICENSE

#include "awkward/builder/Builder.h"

namespace awkward {
  Builder::~Builder() = default;
}
