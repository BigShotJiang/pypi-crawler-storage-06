from enum import Enum

class DecompositionMethod(Enum):
    SHANNON = 'shannon'
    