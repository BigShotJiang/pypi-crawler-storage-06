"""Several core utils"""
