# coding: utf-8

from .datawatcher import DataWatcherWidget  # noqa F401
