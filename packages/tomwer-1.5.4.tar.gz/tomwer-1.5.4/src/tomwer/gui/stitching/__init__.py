"""Widgets for stitching scans or volumes"""
