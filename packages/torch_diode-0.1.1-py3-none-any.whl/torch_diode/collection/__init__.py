"""Collection module for diode package.

This module contains utilities for collecting and managing matrix multiplication
performance data.
"""
