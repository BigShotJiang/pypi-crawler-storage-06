"""Types module for diode package.

This module contains type definitions, data structures, and serialization
utilities for matrix multiplication performance data.
"""
