"""Base handler."""
items = []
handlers = {}
handler_helps = {}
