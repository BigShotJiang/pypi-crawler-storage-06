#! /usr/bin/env bash

function test_bluer_objects_web_where_am_i() {
    bluer_objects_web_where_am_i
}
