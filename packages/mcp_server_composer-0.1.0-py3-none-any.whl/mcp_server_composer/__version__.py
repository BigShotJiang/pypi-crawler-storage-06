"""Version information for mcp_server_composer."""

__version__ = "0.1.0"
