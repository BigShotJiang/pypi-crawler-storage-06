"""Client module for SGU API."""

from .base import BaseClient

__all__ = ["BaseClient"]
