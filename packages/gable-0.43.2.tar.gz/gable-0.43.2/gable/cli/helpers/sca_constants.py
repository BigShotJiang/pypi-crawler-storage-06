"""Constants used by the Static Code Analysis (SCA) functionality."""

# Exit codes
SCA_ERROR_EXIT_CODE = 2  # Generic error exit code for SCA failures
