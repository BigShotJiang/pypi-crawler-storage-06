from opensi.node.data import Data

__all__ = [
    "Data",
]
