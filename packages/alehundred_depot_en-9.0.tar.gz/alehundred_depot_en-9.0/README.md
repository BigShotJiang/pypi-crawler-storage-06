# Alehundred-Depot (English Version)

A Text-based User Interface (TUI) tool to facilitate the installation and management of a Perforce Helix Core server on low-cost hardware like a Raspberry Pi.

## Installation

```bash
pip install alehundred-depot-en