Changelog
=========


1.0.0 (2025-09-23)
------------------

- Initial release.
  [cekk]
