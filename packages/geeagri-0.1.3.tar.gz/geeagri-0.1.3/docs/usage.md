# Usage

To use geeagri in a project:

```
import geeagri
```
