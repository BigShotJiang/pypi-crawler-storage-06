#!/usr/bin/env python

"""Tests for `geeagri` package."""


import unittest

from geeagri import geeagri


class TestGeeagri(unittest.TestCase):
    """Tests for `geeagri` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
