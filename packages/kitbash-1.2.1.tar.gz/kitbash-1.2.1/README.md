# KitBash

A GUI application which you can use to create a new .sfz drumkit from pieces of other drumkits.

