"""The ephemerista.plot package.

This package provides convenience functions for plotting Ephemerista objects.
"""
