"""The ephemerista.comms package.

This package provides classes for modelling communication systems and calculating link budgets.
"""
