"""The ephemerista.constellation package.

This package provides tools for designing satellite constellations.
"""
