"""The ephemerista.coords package.

This package provides classes for representing spacecraft states and trajectories.
"""
