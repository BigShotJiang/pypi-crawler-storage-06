"""Resources for analysis module."""
