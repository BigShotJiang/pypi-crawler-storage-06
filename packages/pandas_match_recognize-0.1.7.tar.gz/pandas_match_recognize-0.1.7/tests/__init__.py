# Tests package for the pandas-based MATCH_RECOGNIZE implementation
