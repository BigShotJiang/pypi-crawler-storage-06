The development of this module in version 14.0 and its migration from
14.0 to 16.0, 16.0 to 18.0 has been financially supported by:

- Camptocamp
