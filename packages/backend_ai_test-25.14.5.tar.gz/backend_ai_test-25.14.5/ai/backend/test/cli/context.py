import attrs


@attrs.define(auto_attribs=True, frozen=True)
class CLIContext:
    pass
