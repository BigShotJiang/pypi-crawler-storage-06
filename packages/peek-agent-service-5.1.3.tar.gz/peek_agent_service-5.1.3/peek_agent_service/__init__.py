__author__ = "peek"
__version__ = '5.1.3'

from . import sw_install
