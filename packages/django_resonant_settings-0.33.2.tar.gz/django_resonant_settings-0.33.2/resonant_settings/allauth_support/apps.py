from django.apps import AppConfig


class AllauthSupportConfig(AppConfig):
    name = "resonant_settings.allauth_support"
    verbose_name = "Resonant settings django-allauth support"
