# django-resonant-settings
[![PyPI](https://img.shields.io/pypi/v/django-resonant-settings)](https://pypi.org/project/django-resonant-settings/)

Shared Django settings for Resonant applications.

# Installation and Usage
This package is tightly coupled to
[`cookiecutter-resonant`](https://github.com/kitware-resonant/cookiecutter-resonant) and should
be used within a cookiecutter-derived Resonant application.
