To enable Odoo logs tracking the actions start and duration, you just
need to install this module. To track SQL queries during an action's
execution, open the action form view and check field `Enable SQL Debug`.
