import numpy as np

def nu1_nu2(alpha,beta):
    
    nu1= -2-alpha
    nu2= -2-beta
    return nu1,nu2 