# REST client for UW GradePage API

[![Build Status](https://github.com/uw-it-aca/uw-restclients-gradepage/workflows/tests/badge.svg)](https://github.com/uw-it-aca/uw-restclients-gradepage/actions)
[![Coverage Status](https://coveralls.io/repos/github/uw-it-aca/uw-restclients-gradepage/badge.svg?branch=main)](https://coveralls.io/github/uw-it-aca/uw-restclients-gradepage?branch=main)
[![PyPi Version](https://img.shields.io/pypi/v/uw-restclients-gradepage.svg)](https://pypi.python.org/pypi/uw-restclients-gradepage)
![Python versions](https://img.shields.io/badge/python-3.12-blue.svg)
