from enum import Enum


class OrderTypeEnum(str, Enum):
    ASC = "ASC"
    DESC = "DESC"
