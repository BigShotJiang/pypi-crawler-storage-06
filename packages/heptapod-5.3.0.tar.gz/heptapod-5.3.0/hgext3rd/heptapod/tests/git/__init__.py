"""Package for tests of the hg-git related subsystem.

We'll split the tests in layers depending on the integration level
"""
