# flake8: noqa
"""Compatibility reexport."""
from .perm import check_publish
