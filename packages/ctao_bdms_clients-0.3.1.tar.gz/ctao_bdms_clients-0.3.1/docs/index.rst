Welcome to the BDMS documentation!
==================================

**Version**: |version| **Date**: |today|

.. toctree::
    :maxdepth: 1
    :caption: Contents:

    getting_started
    server_setup/index
    chart
    data_ingestion_acada
    data_transfers
    reference/index
    changelog



Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
