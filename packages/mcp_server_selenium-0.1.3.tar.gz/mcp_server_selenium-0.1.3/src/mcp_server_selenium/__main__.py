# __main__.py

from mcp_server_selenium import main

main()
