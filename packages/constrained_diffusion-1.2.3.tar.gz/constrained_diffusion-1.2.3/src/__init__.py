# Package initialization for src
from .constrained_diffusion import constrained_diffusion_decomposition
