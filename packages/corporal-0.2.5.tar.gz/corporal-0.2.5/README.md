<!-- -*- mode: markdown; -*- -->

# Corporal

This is a starter Rattail project.  See the
[Rattail website](https://rattailproject.org/)
for more info.
