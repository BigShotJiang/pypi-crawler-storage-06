# -*- coding: utf-8; -*-
"""
Include all supplemental views
"""


def includeme(config):
    config.include('corporal.web.views.projects')
