"""
Fabric library for Corporal
"""

from rattail_fabric2 import make_deploy


deploy_common = make_deploy(__file__)
