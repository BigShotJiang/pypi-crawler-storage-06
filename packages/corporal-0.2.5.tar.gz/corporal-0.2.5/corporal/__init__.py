"""
Corporal package root
"""

from ._version import __version__
