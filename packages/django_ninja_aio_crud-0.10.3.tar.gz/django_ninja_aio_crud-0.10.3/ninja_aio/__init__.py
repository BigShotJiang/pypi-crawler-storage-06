"""Django Ninja AIO CRUD - Rest Framework"""

__version__ = "0.10.3"

from .api import NinjaAIO

__all__ = ["NinjaAIO"]
