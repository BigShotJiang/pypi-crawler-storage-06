"""Entry point for the images_to_zarr package."""

from .CLI import main

if __name__ == "__main__":
    main()
