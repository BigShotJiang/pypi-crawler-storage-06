r"""Execute the Cambiato CLI as `python -m cambiato`."""

# Local
from cambiato.cli.main import main

if __name__ == '__main__':
    main()
