r"""The Cambiato web app."""

# Local
from cambiato.app.main import APP_PATH

# The Public API
__all__ = ['APP_PATH']
