r"""The order related views."""

from .edit_orders_view import edit_orders_view

# The Public API
__all__ = ['edit_orders_view']
