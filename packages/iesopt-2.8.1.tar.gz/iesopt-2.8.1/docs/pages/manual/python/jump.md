# JuMP

```{eval-rst}
.. autodata:: iesopt.JuMP

.. autofunction:: iesopt.jump_value
.. autofunction:: iesopt.jump_dual
.. autofunction:: iesopt.jump_reduced_cost
.. autofunction:: iesopt.jump_shadow_price
```
