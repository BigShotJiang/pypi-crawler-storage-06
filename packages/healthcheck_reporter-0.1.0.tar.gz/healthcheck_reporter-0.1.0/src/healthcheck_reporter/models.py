"""Simple models for the health checker service."""

def get_hello_message():
    return "Hello from healtcheck"