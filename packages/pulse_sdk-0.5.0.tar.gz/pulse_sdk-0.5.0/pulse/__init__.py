# SPDX-License-Identifier: MIT
# SPDX-FileCopyrightText: 2025 Researchwise AI

"""Pulse Client package."""

__version__ = "0.6.1"

# Import debug module to ensure auto-initialization
