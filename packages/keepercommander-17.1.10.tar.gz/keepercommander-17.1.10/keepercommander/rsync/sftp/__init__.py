
from .sftp import SFtpPlugin as RSyncPlugin

__all__ = ['RSyncPlugin']