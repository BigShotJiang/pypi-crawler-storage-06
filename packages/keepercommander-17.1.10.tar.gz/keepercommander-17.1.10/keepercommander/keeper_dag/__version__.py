__version__ = '1.0.27'  # pragma: no cover
