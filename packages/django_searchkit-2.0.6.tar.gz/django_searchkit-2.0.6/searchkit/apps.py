from django.apps import AppConfig


class SearchkitConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'searchkit'
