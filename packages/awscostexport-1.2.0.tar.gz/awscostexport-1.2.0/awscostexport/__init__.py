"""AWS Cost Export - Export comprehensive AWS cost data for analysis and optimization"""

__version__ = "1.2.0"
