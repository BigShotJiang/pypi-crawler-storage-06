This module adds a field *Receiption Status* on purchase orders. On a confirmed purchase order, it can have 3 different values:

* Nothing Received
* Partially Received
* Fully Received
