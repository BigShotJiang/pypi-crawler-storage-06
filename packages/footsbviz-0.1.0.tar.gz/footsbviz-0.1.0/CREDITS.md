# Credits

This package was inspired by work from the football analytics community.
In particular, parts of the plotting ideas and expected DataFrame columns
were informed by Edd Webster’s public scripts on StatsBomb Open Data.

Where our implementation was influenced by a specific function or layout,
we re-implemented it for library use and removed hard-coded paths/branding.
Original author credit retained here; please see their repository for details.

If we missed anyone, open an issue and we’ll update credits promptly.
