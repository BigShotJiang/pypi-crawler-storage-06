Installation
============

As this is released on `PyPI <https://pypi.python.org/pypi/tariochbctools/>`__ you can simply install it with

.. code-block:: console

   pip install tariochbctools
