meta = {
    'name': 'name',
    'author': 'author',
    'version': (0, 1, 0),
    'blender': (4, 2, 0),
    'location': 'location',
    'description': 'description',
    'warning': '',
    'doc_url': '',
    'tracker_url': '',
    'category': 'category'
}
