from pyx3270.cli import app

if __name__ == '__main__':
    app()
