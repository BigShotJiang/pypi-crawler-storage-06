import pybammsolvers


def test_import():
    assert hasattr(pybammsolvers, "idaklu")
