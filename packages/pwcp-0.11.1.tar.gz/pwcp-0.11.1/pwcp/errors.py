class PreprocessorError(Exception):
    pass
