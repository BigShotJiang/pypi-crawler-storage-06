from duck_django_soft_delete.table.soft_delete_table import SoftDeleteTable

__all__ = [
    "SoftDeleteTable",
]
