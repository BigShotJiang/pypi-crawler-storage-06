from duck_django_soft_delete.queryset.non_soft_deleted_query_set import (
    NonSoftDeletedQuerySet,
)

__all__ = [
    "NonSoftDeletedQuerySet",
]
