This module allows to create sessions associated with events.
