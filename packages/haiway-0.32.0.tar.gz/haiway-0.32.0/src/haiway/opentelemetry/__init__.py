from haiway.opentelemetry.observability import OpenTelemetry

__all__ = ("OpenTelemetry",)
