"""
Compatibility layer for the *classic* `commune` library.

Note:
    Anywhere you see **classic** in this docs, it means that the class/method/function/thing refers to or interacts with the `classic commune library`_.

.. _classic commune library:
    https://github.com/commune-ai/commune
"""
