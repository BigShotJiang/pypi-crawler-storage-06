export const taskName = 'Task';
export const taskDescription =
  'A fast, cross-platform build tool inspired by Make, designed for modern workflows.';

export const ogUrl = 'https://taskfile.dev/';
