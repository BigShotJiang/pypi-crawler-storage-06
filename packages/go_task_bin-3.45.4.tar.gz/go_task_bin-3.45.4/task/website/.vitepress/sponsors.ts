export const sponsors = [
  {
    tier: 'Gold Sponsors',
    size: 'big',
    items: [
      {
        name: 'devowl',
        url: 'https://devowl.io/',
        img: '/img/devowl.io.svg'
      }
    ]
  }
];
