Connection
==========

.. currentmodule:: dagger

.. autofunction:: connection

.. autoclass:: Connection
   :no-show-inheritance:

.. autoclass:: Config
   :no-show-inheritance:

.. autoclass:: Timeout
   :no-show-inheritance:
   
.. autoclass:: Retry
   :no-show-inheritance:
