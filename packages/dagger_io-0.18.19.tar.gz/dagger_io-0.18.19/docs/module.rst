Modules
=======

Dagger Modules support.

.. currentmodule:: dagger

.. autodecorator:: object_type

.. autofunction:: field

.. autodecorator:: function

.. autodecorator:: enum_type

.. autodecorator:: interface

.. autoclass:: DefaultPath

.. autoclass:: Ignore

.. autoclass:: Enum

.. autoclass:: Name

.. autoclass:: Doc
