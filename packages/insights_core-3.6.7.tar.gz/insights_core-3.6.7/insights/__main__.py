from insights import run


if __name__ == "__main__":
    run(print_summary=True)
