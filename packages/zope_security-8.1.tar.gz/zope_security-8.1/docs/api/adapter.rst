=======================
 zope.security.adapter
=======================

.. automodule:: zope.security.adapter
