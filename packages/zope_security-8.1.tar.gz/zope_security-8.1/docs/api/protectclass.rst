============================
 zope.security.protectclass
============================

.. automodule:: zope.security.protectclass
