==========================
 zope.security.interfaces
==========================

.. automodule:: zope.security.interfaces
