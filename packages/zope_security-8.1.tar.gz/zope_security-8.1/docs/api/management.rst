==========================
 zope.security.management
==========================

.. automodule:: zope.security.management
