=============================
 zope.security.metaconfigure
=============================

.. automodule:: zope.security.metaconfigure
