==============================
 zope.security.simplepolicies
==============================

.. automodule:: zope.security.simplepolicies
