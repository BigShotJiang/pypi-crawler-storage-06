"""Version information for ssiamb."""

__version__ = "0.1.0"
