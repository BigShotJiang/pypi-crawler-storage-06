from . import (
    create_subscription_from_partner,
    create_lead_from_partner,
    mail_compose_message,
)
