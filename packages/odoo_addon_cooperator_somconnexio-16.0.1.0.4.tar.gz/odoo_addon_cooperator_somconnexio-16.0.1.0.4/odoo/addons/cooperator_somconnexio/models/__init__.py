from . import (
    account_move,
    coop_agreement,
    cooperative_membership,
    contract,
    crm_lead,
    crm_lead_line,
    discovery_channel,
    operation_request,
    operation_request_terminate_reason,
    res_partner,
    subscription_request,
)
