# Classification

::: sieves.tasks.predictive.classification.core
::: sieves.tasks.predictive.classification.bridges