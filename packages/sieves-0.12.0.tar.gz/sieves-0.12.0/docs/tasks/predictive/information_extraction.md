# Information Extraction

::: sieves.tasks.predictive.information_extraction.core
::: sieves.tasks.predictive.information_extraction.bridges