# Ollama

::: sieves.engines.ollama_.Ollama