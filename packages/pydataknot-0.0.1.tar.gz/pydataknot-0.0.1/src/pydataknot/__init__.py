def main() -> None:
    print("Hello from pydataknot!")
