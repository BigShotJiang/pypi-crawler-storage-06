"""Manifest schema utilities."""
SCHEMA_VERSION = "1.0"

__all__ = ["SCHEMA_VERSION"]
