#exonware/xwsystem/tests/core/plugins/__init__.py
"""
Plugins Core Tests Package

Tests for XSystem plugin system including plugin management, loading,
and lifecycle management.
"""
