"""Constants for the resolver_athena_client's image properties."""

# Athena's classifier expects images to be 448x448 pixels.
EXPECTED_WIDTH = 448
EXPECTED_HEIGHT = 448
