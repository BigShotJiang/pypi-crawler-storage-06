# standard
# third party
# custom
from sunwaee.aegen.model import Model

GEMINI_2_5_PRO = Model(
    name="gemini-2.5-flash",
    display_name="Gemini 2.5 Flash",
    origin="google",
)

GEMINI_2_5_FLASH = Model(
    name="gemini-2.5-flash",
    display_name="Gemini 2.5 Flash",
    origin="google",
)

GEMINI_2_5_FLASH_LITE = Model(
    name="gemini-2.5-flash-lite",
    display_name="Gemini 2.5 Flash Lite",
    origin="google",
)

GOOGLE_MODELS = [
    GEMINI_2_5_PRO,
    GEMINI_2_5_FLASH,
    GEMINI_2_5_FLASH_LITE,
]
