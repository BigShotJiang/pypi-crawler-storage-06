"""Dice manipulation library."""

from __future__ import annotations

__all__ = ["Dice"]


from .dice import Dice
