# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
class _ApiVersion:
    CURRENT = "2025-08-27.basil"
    CURRENT_MAJOR = "basil"
