# shilling
Brewing calculations


## Build

In root folder say:
python -m build 
twine upload --repository pypi dist/*
