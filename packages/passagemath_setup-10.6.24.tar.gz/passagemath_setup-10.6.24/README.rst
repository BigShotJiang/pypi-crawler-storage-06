sage-setup: Build system of the Sage library
================================================

This is the build system of the Sage library, based on setuptools.
