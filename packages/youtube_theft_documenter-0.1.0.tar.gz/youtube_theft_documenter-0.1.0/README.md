# youtube-theft-documenter
A tool to help creators document theft on YouTube
