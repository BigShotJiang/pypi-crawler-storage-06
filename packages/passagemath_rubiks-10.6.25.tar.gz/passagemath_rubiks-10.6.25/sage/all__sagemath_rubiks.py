# sage_setup: distribution = sagemath-rubiks
# delvewheel: patch

from sage.all__sagemath_groups import *
