from .base import *

PUBLIC_URLS = [
    "/api/",
]
