.. Argus documentation master file, created by
   sphinx-quickstart on Fri Apr 24 09:29:51 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Argus' documentation!
================================

   Argus is an alert aggregator for monitoring systems.

.. toctree::
   about-argus
   reference
   user-manual
   integrations/index
   customization
   development
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
