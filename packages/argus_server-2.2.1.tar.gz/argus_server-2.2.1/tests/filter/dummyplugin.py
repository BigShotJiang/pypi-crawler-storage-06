class DummyClass:
    pass
