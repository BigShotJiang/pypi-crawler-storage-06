# `ETL` class

The `ETL` class is the main class in the `ExTraLo` package. It can be imported directly from `extralo`.

```python
from extralo import ETL
```

::: extralo.ETL
