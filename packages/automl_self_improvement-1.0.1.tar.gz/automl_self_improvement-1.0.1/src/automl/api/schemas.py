# Pydantic request/response models
