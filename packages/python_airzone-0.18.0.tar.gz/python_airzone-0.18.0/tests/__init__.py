"""Tests for the airzone integration."""
