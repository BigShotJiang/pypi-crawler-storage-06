class Main:
    ...

def main():
    print('DOTC (like Yahtzee) - Access Nested Dicts and Lists via Dots')