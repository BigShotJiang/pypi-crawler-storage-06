- Patrick Tombez \<<patrick.tombez@camptocamp.com>\>

- Alexandre Fayolle \<<alexandre.fayolle@camptocamp.com>\>

- Carlos Serra Toro \<<carlos.serra@camptocamp.com>\>

- [Trobz](https://trobz.com):  
  - Hai Lang \<<hailn@trobz.com>\>
