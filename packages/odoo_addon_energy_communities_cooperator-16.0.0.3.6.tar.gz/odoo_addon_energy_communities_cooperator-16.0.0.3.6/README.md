# Energy Communities Cooperator

## Changelog

### 2025-09-23 (v16.0.0.3.6)

- Fix translations

### 2025-05-21

- Added Readme
