# Tyro CLI Shell Completion

Helper to setup shell completion for a Tyro based CLI program.

Supports Bash shell

Supports Z-Shell

Usage: Expand you Tyro CLI and call `setup_tyro_shell_completion()` from your program ;)