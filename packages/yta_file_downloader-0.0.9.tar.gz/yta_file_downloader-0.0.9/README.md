# Youtube Autonomous Multimedia File Downloader Add-on

The way to download files from the internet very easy.

This library needs these API keys to work:
- GIPHY_API_KEY (to download gifs)