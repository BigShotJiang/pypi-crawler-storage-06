"""Package-wide test fixtures."""
