nima.nima
---------

.. automodule:: nima.nima
   :undoc-members:
