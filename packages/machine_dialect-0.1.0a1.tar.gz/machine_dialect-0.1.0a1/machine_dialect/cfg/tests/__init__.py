"""Tests for the CFG module."""
