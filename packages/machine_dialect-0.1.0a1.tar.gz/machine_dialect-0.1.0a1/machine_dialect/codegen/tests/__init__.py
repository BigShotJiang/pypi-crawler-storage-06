"""Tests for the codegen module."""
