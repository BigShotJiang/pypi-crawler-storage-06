"""Machine Dialect™ AI Agent module."""

from machine_dialect.agent.agent import Agent

__all__ = ["Agent"]
