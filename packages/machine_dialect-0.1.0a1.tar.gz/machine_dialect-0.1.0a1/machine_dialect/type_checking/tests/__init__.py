"""Tests for the Machine Dialect™ type system."""
