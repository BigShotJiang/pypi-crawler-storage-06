from machine_dialect.repl.repl import main

__all__ = ["main"]
