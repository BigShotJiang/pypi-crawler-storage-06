"""Tests for the Machine Dialect™ linter."""
