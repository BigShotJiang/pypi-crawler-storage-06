__all__ = ["version", "version_info"]


version = "0.5.2"
version_info = (0, 5, 2, "final", 0)
