from setuptools import setup

setup(
    name='MProcs',
    version='4.3.0.7.1',
    entry_points={
        'console_scripts': [
            'MProcs=MProcs'
        ]
    }
)
