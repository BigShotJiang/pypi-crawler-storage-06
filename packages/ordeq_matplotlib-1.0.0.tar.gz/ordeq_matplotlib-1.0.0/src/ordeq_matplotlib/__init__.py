from ordeq_matplotlib.figure import MatplotlibFigure

__all__ = ("MatplotlibFigure",)
