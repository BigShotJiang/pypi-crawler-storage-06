<div align="center">
    <img src="https://www.trickler.com/images/tricklerlogo256.png">
</div>

Trickler enables streaming of simple data to the Trickler mobile app for real-time visualization on the go. 

At present the mobile app is pre-release and under internal testing for both iOS and Android.

---