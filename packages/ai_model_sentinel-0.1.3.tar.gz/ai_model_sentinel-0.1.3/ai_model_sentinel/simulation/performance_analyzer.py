        latest = self.metrics_history[-1] 
