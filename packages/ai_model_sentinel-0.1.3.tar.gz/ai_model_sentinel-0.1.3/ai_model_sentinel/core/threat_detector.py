import numpy as np 
 
class ThreatDetector: 
    def __init__(self): 
        print("ThreatDetector initialized") 
 
    def detect_anomalies(self, data): 
        return {"threat_level": 0.5} 
 
    def calculate_threat_level(self, detection_results): 
        return 0.5 
