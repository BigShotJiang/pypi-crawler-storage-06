Development guide
=================

This document is unfinished but you may check it out periodically to
read some related notes.

The release process is fairly simple:

1. Go to
   https://github.com/cherrypy/cheroot/actions/workflows/ci-cd.yml.

2. Click ``Run workflow``.

3. Fill out the form. Ideally, only use the mandatory version field.

   .. important::

      Do not change the branch to use the workflow from.

4. Click green ``Run workflow`` submit button.

5. Wait until the CI completes and the new version appears on PyPI.
