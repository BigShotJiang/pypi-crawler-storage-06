:tocdepth: 2

.. spelling::

   reproducibility

**********
Change log
**********

.. only:: not is_release

   *To be included in the next release*
   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

   .. towncrier-draft-entries:: |version| :sub:`/UNRELEASED DRAFT/`

   Released versions
   ^^^^^^^^^^^^^^^^^

   .. include:: ../CHANGES.rst
      :start-after: .. towncrier release notes start

.. only:: is_release

   .. include:: ../CHANGES.rst
      :start-after: .. towncrier release notes start
