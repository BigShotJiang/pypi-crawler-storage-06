from koegelbrunf.core import *
from koegelbrunf.tests import *

if __name__ == "__main__":
    main()
