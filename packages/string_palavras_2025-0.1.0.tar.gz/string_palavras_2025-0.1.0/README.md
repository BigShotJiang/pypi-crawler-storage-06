# Minha Biblioteca

Esta biblioteca foi criada durante a formação da UFCD 10794.

Oferece funções para manipulação de strings: `contar_vogais` contar vogais; `inverter` inverter palavras e `contar_palavras` para contar palavras.


# Instalação

pip install string-palavras