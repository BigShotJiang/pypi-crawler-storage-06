To pull historical bank statements:

1.  Go to *Invoicing \> Configuration \> Online Bank Statement
    Providers*
2.  Select a specific provider
3.  Click on *PULL ONLINE BANK STATEMENT*
4.  Configure date interval and click *Pull*

**NOTE**: To access these features, user needs to belong to *Show Full
Accounting Features* group.
