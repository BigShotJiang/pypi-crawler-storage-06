To configure online bank statements provider:

1.  Go to *Invoicing \> Configuration \> Online Bank Statement
    Providers*
2.  Create a provider and configure provider-specific settings.

If you want to allow empty bank statements to be created every time the
information is pulled, you can check the option "Allow empty statements"
at the provider configuration level.

**NOTE**: To access these features, user needs to belong to *Show Full
Accounting Features* group.
