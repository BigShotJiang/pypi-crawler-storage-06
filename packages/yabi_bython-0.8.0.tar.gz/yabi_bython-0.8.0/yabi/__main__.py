from . import main


main()
