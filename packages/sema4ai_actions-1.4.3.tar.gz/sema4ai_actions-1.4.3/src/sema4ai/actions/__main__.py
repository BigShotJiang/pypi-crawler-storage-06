if __name__ == "__main__":
    from sema4ai.actions.cli import main

    main()
