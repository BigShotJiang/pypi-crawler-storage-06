"""Add AI assistant command for adding assistants to existing projects."""

from .add_ai import add_ai_command

__all__ = ["add_ai_command"]
