"""Runtime templates for project use"""
