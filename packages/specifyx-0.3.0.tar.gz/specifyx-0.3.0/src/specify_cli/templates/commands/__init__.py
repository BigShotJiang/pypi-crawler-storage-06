"""AI-specific command templates"""
