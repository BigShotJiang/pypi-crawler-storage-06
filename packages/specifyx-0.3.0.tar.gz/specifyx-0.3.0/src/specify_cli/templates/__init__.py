"""
SpecifyX initialization templates

This package contains Jinja2 templates for initializing projects with
AI-specific command templates, cross-platform scripts, memory files,
and runtime templates.
"""
