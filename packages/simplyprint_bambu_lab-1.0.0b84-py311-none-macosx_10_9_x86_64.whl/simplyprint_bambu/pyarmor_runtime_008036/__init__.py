# Pyarmor 9.0.8 (ci), 008036, 2025-09-22T17:22:30.350983
from .pyarmor_runtime import __pyarmor__
