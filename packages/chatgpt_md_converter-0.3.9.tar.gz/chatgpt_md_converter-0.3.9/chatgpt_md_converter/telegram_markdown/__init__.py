"""Modular Telegram Markdown → HTML conversion helpers."""

from .renderer import telegram_format

__all__ = ["telegram_format"]
