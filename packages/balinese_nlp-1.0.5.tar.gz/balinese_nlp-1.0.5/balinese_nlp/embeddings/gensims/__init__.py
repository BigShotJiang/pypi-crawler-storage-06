from .BaliFastText import BaliFastText
from .BaliWord2Vec import BaliWord2Vec