#!/usr/bin/python3

import tator.openapi.tator_openapi
__version__ = tator.openapi.tator_openapi.__version__

if __name__ == '__main__':
    print(__version__)
