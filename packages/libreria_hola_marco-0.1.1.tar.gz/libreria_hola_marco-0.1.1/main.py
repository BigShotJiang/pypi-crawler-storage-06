def hello_marco():
    """
    This function prints a greeting message from Marco.
    """
    print("Hello from Marco!")


def main():
    hello_marco()


if __name__ == "__main__":
    main()
