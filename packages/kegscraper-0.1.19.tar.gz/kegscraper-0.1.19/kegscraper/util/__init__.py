"""
Utility functions for the rest of the kegscraping module
"""