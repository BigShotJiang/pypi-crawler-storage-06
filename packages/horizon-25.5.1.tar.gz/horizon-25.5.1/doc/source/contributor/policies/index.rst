================
Project Policies
================

This page collects basic policies on horizon development.

.. toctree::
   :maxdepth: 1

   supported-software
   horizon-groups
   core-reviewers
   horizon-bugs
   releasing
