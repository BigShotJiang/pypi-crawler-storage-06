========================================================
Verify operation for Red Hat Enterprise Linux and CentOS
========================================================

Verify operation of the dashboard.

Access the dashboard using a web browser at
``http://controller/dashboard``.

Authenticate using ``admin`` or ``demo`` user
and ``default`` domain credentials.
