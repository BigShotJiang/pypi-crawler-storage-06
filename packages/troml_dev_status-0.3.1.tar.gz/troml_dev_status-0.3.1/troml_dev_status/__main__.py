# troml_dev_status/__main__.py

from troml_dev_status.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
