from .core import emojify_text

__all__ = ["emojify_text"]
