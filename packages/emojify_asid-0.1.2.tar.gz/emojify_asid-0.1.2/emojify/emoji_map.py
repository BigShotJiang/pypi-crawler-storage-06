# This will be the default mapping provided by the modules
EMOJI_MAP = {
    "happy": "😊",
    "sad": "😢",
    "love": "❤️",
    "cat": "🐱",
    "dog": "🐶",
    "money": "💰",
    "food": "🍕",
    "party": "🎉",
    "car": "🚗",
    "travel": "✈️",
    "fire": "🔥",
    "music": "🎵",
    "computer": "💻",
}
