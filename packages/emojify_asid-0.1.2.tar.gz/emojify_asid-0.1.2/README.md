# emojify-nlp
Creating text with emojis based on input text with the help of NLP
