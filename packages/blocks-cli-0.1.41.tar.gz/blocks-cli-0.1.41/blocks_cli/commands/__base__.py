import typer

blocks_cli = typer.Typer(no_args_is_help=True)