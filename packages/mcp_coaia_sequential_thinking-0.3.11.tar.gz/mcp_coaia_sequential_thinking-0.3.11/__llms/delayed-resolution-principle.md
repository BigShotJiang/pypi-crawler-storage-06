moved to `llms-delayed-resolution-principle.md` (reason: Adequate naming)

