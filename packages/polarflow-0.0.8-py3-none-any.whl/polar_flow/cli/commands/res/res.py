import typer

res_app = typer.Typer(help="资源获取与控制")
