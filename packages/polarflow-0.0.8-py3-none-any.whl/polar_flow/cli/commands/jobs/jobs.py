import typer

job_app = typer.Typer(help="作业提交/查看/控制")
