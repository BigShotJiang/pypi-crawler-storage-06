Module blaxel.core.client.api.jobs
==================================

Sub-modules
-----------
* blaxel.core.client.api.jobs.create_job
* blaxel.core.client.api.jobs.delete_job
* blaxel.core.client.api.jobs.get_job
* blaxel.core.client.api.jobs.list_job_revisions
* blaxel.core.client.api.jobs.list_jobs
* blaxel.core.client.api.jobs.update_job