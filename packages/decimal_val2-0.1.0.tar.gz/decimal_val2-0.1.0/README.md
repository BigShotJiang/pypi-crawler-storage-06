# DECIMAL_VAL2

A simple Python package to round values to **2 decimal places** with typing support (`py.typed` included).

---

## 📦 Installation
```bash
pip install DECIMAL_VAL2
