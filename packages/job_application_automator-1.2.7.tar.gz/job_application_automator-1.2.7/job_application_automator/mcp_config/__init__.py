"""
MCP (Model Context Protocol) subpackage for job application automator.
This package contains MCP-specific utilities and configurations.
"""

__version__ = "1.2.4"