"""
Tauro - Scalable Data Pipeline Execution Framework
"""

__version__ = "0.1.1"
