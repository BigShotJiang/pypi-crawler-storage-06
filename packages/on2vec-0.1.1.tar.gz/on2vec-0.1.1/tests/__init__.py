"""
Test suite for on2vec package.
"""