This module:

Adds extra fields to the batch picking creation wizard
Adds extra fields and functionalities to the batch picking form.
