wzhmultimap
================

The Multimap in Python.
