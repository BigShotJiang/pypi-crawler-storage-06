from loguru import logger

logger = logger.bind(source="moduvent")
