"""
Test package for atadata-cli.
"""
