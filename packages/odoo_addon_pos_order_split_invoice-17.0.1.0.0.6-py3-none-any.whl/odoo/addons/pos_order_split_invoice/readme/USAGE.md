Change the amount pricelist of products to a splitting one and the amount will be correctly computed on PoS.

After PoS validation, the invoice to the splitting partner will be created.
