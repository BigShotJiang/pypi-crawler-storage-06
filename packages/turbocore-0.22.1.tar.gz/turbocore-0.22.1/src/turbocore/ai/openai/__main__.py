from turbocore.ai.openai import main


if __name__ == "__main__":
    main()
