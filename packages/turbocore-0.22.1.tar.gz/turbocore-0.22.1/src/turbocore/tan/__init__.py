import turbocore


def tan_gen():
    pass


def main():
    turbocore.cli_this(__name__, "tan_")
