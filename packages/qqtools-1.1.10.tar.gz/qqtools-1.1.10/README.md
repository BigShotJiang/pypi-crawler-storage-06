# qqtools

A small tool package for qq


# Data Format Support

Non-torch formats:
```bash
qDict : Enhanced of basic Dict.
qScalaDict : Dict[str, num]. A dict that maps str to scala;
qListData : List[dict]. A list of dicts.
```

Torch-related data formats
```bash
qData
```
