from file import File
from line import Line
from datetime import datetime
from pathlib import Path
from db import Db
import asyncio

# inits
db = Db(host="localhost", port=27017, db_name="batch_db", batch_collection_name="lines", file_collection_name="file_infos")
file = File(db=db,file_name_format=f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_batch.jsonl", folder_path=Path("./batches"))

# save 10000 lines concurrently to db
# async def save_lines_concurrently():
#     tasks = []
#     for i in range(10000):
#         line = Line(
#             db=db,
#             custom_id=str(i),
#             user_prompt=f"Hello, how are you? {i}",
#             sys_prompt="You are a helpful assistant.",
#             top_p=0.9,
#             temperature=0.1,
#             max_output_tokens=1024,
#         )
#         tasks.append(asyncio.to_thread(line.save_line_in_db))
#     await asyncio.gather(*tasks)

# asyncio.run(save_lines_concurrently())


# step one : receive payloads
# line = Line(
#     db=db,
#     custom_id="12345",
#     user_prompt="Hello, how are you?",
#     sys_prompt="You are a helpful assistant.",
#     top_p=0.9,
#     temperature=0.1,
#     max_output_tokens=1024,
# )
# line.save_line_in_db()

# step two : cron job to write payloads to file then process them
payloads = db.get_payloads_by_status("PENDING")
file.write(payloads)
file.process()
# step three : get file and treat them