from pydantic import BaseModel


class Paylod(BaseModel):
    custom_id: str
    prompt_user:str
    
