# jack_fluidsynth

A wrapper for fluidsynth.Synth with extra methods for playing midi files,
listing SoundFont presets, and capturing samples.
