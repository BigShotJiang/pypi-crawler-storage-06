"""Unit tests for XRayLabTool components."""
