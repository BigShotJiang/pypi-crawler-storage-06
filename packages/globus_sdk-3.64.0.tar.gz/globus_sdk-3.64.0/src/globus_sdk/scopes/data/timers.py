from ..builder import ScopeBuilder

TimersScopes = ScopeBuilder(
    "524230d7-ea86-4a52-8312-86065a9e0417",
    known_url_scopes=[
        "timer",
    ],
)
