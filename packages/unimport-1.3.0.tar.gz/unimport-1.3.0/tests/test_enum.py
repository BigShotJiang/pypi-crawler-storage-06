from unimport.enums import Emoji


def test_emoji():
    assert Emoji.STAR == "🤩"
    assert Emoji.PARTYING_FACE == "🥳"
