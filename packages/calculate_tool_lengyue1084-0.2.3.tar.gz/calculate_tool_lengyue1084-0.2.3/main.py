def main():
    print("Hello from calculate!")


if __name__ == "__main__":
    main()
