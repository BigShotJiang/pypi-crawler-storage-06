# Active Tasks
_Status: not started • Version: v0.1 • Date: <YYYY-MM-DD>_

> Produced per `.spec-dev/Tasks.md`. Capture the task board, then pause for review.

## Plan Snapshot
- **Key Modules/Areas:** <list from active-plan>
- **Feature Flags / Milestones:** <if applicable>

## Backlog
<!-- Append new task cards here using the strict format. -->

## In Progress
<!-- Move cards here with `spec-dev tasks-move T-### --to in-progress`. -->

## Done
<!-- Completed cards live here until `spec-dev cycle` archives the board. -->

Gate: FAIL (set to READY FOR IMPLEMENTATION when the board is complete)
