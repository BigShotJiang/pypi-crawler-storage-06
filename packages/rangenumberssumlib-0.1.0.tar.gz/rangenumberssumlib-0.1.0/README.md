# RangeNumbersSumLib
A simple Python library to calculate the sum of numbers from a to b.
