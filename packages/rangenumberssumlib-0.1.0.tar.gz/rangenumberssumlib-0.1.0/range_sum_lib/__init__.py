def range_sum(a: int, b: int) -> int:
    return sum(range(a, b + 1))
