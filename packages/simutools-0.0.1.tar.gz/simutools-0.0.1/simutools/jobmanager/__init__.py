#!/usr/bin/env python
# -*- coding: utf-8 -*-
from .slurm import Slurm


__all__ = [Slurm]
