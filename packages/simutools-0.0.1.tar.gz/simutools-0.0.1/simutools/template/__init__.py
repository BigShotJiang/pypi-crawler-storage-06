#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
TEMPLATE_DIR = os.path.dirname(os.path.abspath(__file__))
