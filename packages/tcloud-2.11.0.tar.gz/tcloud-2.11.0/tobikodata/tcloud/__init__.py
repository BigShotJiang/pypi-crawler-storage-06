# ruff: noqa: F401
"""
.. include:: ../README.md
"""

try:
    from tobikodata.tcloud._version import __version__  # type: ignore
except ImportError:
    pass
