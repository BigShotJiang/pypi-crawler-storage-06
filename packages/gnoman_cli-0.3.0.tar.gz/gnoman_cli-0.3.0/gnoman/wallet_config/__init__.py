"""Wallet configuration package providing derivation templates."""
