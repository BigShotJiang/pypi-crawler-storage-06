"""Static resource files bundled with gnoman."""
