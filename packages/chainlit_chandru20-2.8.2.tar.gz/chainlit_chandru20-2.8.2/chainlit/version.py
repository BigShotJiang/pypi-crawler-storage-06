"""Package version.

This file is parsed by the build backend (hatchling) using a simple regex per
`[tool.hatch.version]` in pyproject.toml. Keep it to a single assignment.
"""

__version__ = "2.8.2"
