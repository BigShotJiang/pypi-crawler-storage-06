Products.PloneMeeting profile fir City of Charleroi (Belgium)
