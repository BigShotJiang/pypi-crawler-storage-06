``OrderedMapSeq``
===========================

.. autoclass:: mapdeduce.OrderedMapSeq
   :members:
