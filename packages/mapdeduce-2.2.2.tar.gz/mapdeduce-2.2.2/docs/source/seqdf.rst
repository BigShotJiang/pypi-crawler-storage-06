``SeqDf``
===================

.. autoclass:: mapdeduce.SeqDf
   :members:
