``MapSeq``
====================

.. autoclass:: mapdeduce.MapSeq
   :members:
