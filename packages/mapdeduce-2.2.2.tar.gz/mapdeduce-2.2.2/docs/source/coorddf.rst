``CoordDf``
=====================

.. autoclass:: mapdeduce.CoordDf
   :members:
