from enum import Enum


class DetailType(Enum):
    """
        Enum for starting details type
    """
    CONFIG_WEAKNESS_COMP = "config_weakness_comp"
    CONFIG_WEAKNESS_ATTACKER = "config_weakness_attacker"
    CONFIG_ATTACKER_IMPACT = "config_attacker_impact"
    CONFIG_CAUSE_ATTACKER = "config_cause_attacker"
    CONFIG_CAUSE_WEAKNESS = "config_cause_weakness"
    WEAKNESS_COMP_CONFIG = "weakness_comp_config"
    WEAKNESS_CONFIG_COMP = "weakness_config_comp"
    WEAKNESS_CONFIG_ATTACKER = "weakness_config_attacker"
    WEAKNESS_CONFIG_VECTOR = "weakness_config_vector"
    COMPONENT_CONFIG_WEAKNESS = "comp_config_weakness"
    COMPONENT_CONFIG_ATTACKER = "comp_config_attacker"
    COMPONENT_CONFIG_CAUSE = "comp_config_cause"
