# cve-driller
A package for analyzing and extracting information from CVE descriptions.
