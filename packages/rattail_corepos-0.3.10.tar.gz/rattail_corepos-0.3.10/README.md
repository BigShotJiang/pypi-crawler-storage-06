
# rattail-corepos

Rattail is a retail software framework, released under the GNU General Public
License.

This package contains software interfaces for the [CORE
POS](https://github.com/CORE-POS/IS4C) system.

Please see Rattail's [home page](https://rattailproject.org/) for more
information.
