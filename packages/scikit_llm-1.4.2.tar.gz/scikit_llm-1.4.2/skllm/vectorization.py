from skllm.models.gpt.vectorization import GPTVectorizer
