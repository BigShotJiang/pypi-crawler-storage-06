def get_translation_dataset():
    X = [
        r"Me encanta bailar salsa y bachata. Es una forma divertida de expresarme.",
        r"J'ai passé mes dernières vacances en Grèce. Les plages étaient magnifiques.",
        (
            r"Ich habe gestern ein tolles Buch gelesen. Die Geschichte war fesselnd bis"
            r" zum Ende."
        ),
        (
            r"Gosto de cozinhar pratos tradicionais italianos. O espaguete à carbonara"
            r" é um dos meus favoritos."
        ),
        (
            r"Mám v plánu letos v létě vyrazit na výlet do Itálie. Doufám, že navštívím"
            r" Řím a Benátky."
        ),
        (
            r"Mijn favoriete hobby is fotograferen. Ik hou ervan om mooie momenten vast"
            r" te leggen."
        ),
    ]

    return X
