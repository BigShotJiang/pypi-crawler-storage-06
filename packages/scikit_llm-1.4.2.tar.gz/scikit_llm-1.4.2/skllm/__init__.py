__version__ = '1.4.2'
__author__ = 'Iryna Kondrashchenko, Oleh Kostromin'
