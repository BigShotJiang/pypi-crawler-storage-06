# Authors of Bigraph Schema

The maintainers of the Process-Bigraph project are:

* Ryan Spangler (@prismofeverything)
* Eran Agmon  (@eagmon)
