To configure this module, you need to:

- Go to a product with variants or create one.
- In the *Attributes and variants* tab, *Sales Variant Selection* section, select
  **Order grid entry**.
