"""A module for file handlers in Bear Utils."""
