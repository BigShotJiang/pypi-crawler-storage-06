from .calculator import add,sub,mul,div,pow

__version__= "0.1.0"