import importlib_metadata

VERSION = importlib_metadata.version("dreadnode")
