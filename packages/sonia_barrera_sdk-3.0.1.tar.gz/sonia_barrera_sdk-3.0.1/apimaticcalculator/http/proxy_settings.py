
"""
apimaticcalculator

This file was automatically generated for dgfgfdg by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

from apimatic_core.http.configurations.proxy_settings import ProxySettings as CoreProxySettings

class ProxySettings(CoreProxySettings):
    """
    A simple data model for configuring HTTP(S) proxy settings.
    """
