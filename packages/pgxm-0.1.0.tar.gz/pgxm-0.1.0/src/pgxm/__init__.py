def main() -> None:
    print("Hello from pgxm!")
