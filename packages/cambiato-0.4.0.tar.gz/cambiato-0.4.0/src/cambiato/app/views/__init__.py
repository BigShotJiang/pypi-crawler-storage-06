r"""The views of the pages of the app."""

from .orders import edit_orders_view

# The Public API
__all__ = ['edit_orders_view']
