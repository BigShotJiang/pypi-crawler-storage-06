r"""The commands of the Cambiato CLI."""
