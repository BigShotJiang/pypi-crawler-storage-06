r"""The Cambiato CLI (cambiato) for managing the application."""
