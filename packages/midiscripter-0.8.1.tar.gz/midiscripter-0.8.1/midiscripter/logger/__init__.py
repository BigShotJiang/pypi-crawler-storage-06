from midiscripter.logger.log_obj import Log as _Log

log = _Log()
