from typing import TYPE_CHECKING

import midiscripter.base.msg_base

if TYPE_CHECKING:
    from collections.abc import Sequence, Container
    from midiscripter.gui.gui_widgets.gui_widget_base import GuiWidget


class GuiEvent(midiscripter.base.msg_base.AttrEnum):
    """GUI event type enumerator
    to use as [`GuiEventMsg`][midiscripter.GuiEventMsg] `type` attribute"""

    CONTENT_SET = 'CONTENT_SET'
    COLOR_SET = 'COLOR_SET'
    RANGE_SET = 'RANGE_SET'

    TRIGGERED = 'TRIGGERED'
    TOGGLED = 'TOGGLED'
    SELECTED = 'SELECTED'
    VALUE_CHANGED = 'VALUE_CHANGED'


class GuiEventMsg(midiscripter.base.msg_base.Msg):
    """GUI interaction message produced by GUI widget"""

    type: GuiEvent
    """GUI event type"""

    data: 'str | int | bool | Sequence | None'
    """New value set by event.
    
    Data meaning for event types:  
    TRIGGERED - None  
    CONTENT_SET - New content  
    COLOR_SET - New text color  
    TOGGLED - New toggle state  
    SELECTED - Selected item text  
    VALUE_CHANGED - New value  
    RANGE_SET - New value range  
    """

    source: 'None | GuiWidget'
    """`GuiWidget` instance that generated the message"""

    __match_args__: tuple[str] = ('type', 'data')

    def __init__(
        self,
        type: GuiEvent,
        data: 'str | int | bool | Sequence | None' = None,
        *,
        source: 'None | GuiWidget' = None,
    ):
        super().__init__(source)
        self.type = type
        self.data = data

    def matches(
        self,
        type: 'None | Container[GuiEvent] | GuiEvent' = None,
        data: 'None | Container | str | int | bool | Sequence' = None,
    ) -> bool:
        return super().matches(type, data)
