import pathlib
from typing import TYPE_CHECKING, overload

import watchdog.events
import watchdog.observers

import midiscripter.base.port_base
import midiscripter.file_event
from midiscripter.logger import log

if TYPE_CHECKING:
    from collections.abc import Container, Callable
    from midiscripter.file_event.file_event_msg import FileEvent, FileEventMsg

shared_observer = watchdog.observers.Observer()
shared_observer.daemon = True
shared_observer.start()


class FileEventIn(midiscripter.base.port_base.Input, watchdog.events.FileSystemEventHandler):
    """File system events input port. Watches file/directory modifications.
    Produces [`FileEventMsg`][midiscripter.FileEventMsg] objects.
    """

    _log_description: str = 'file event listener'

    def __init__(self, path: str | pathlib.Path, recursive: bool = False):
        """
        Args:
            path: File/directory path to watch
            recursive: `True` to watch directory path recursively
        """
        if isinstance(path, str):
            path = pathlib.Path(path)

        midiscripter.base.port_base.Input.__init__(self, path)
        watchdog.events.FileSystemEventHandler.__init__(self)

        self.__path = path

        if self.__path.is_dir():
            self.__path_to_watch = self.__path
            self.__watch_dir_changes = True
        else:
            self.__path_to_watch = self.__path.parent  # some editors recreate a file on save
            self.__watch_dir_changes = False

        self.__recursive = recursive
        self.__watch = None

    def __str__(self):
        return f"'{self.__path.relative_to(self.__path.parent.parent)}' watcher"

    def _open(self) -> None:
        self.__watch = shared_observer.schedule(
            self, str(self.__path_to_watch), recursive=self.__recursive
        )
        if not shared_observer.is_alive():
            shared_observer.start()
        self.is_opened = True
        log._port_open(self, True)

    def _close(self) -> None:
        if self.__watch:
            shared_observer.unschedule(self.__watch)
        self.is_opened = False
        log._port_close(self, True)

    def on_any_event(self, event: watchdog.events.FileSystemEvent) -> None:
        # Override for `watchdog.events.FileSystemEventHandler` method.
        # Runs on each file system change in `_path`.
        event_path = pathlib.Path(event.src_path)

        if self.__watch_dir_changes or event_path == self.__path:
            msg = midiscripter.file_event.file_event_msg.FileEventMsg(
                event.event_type.upper(), self.__path, source=self
            )
            self._send_input_msg_to_calls(msg)

    @overload
    def subscribe(self, call: 'Callable[[FileEventMsg], None]') -> 'Callable': ...

    @overload
    def subscribe(
        self,
        type: 'None | Container[FileEvent] | FileEvent | str' = None,
        path: 'None | Container[pathlib.Path] | pathlib.Path' = None,
    ) -> 'Callable': ...

    def subscribe(
        self,
        type: 'None | Container[FileEvent] | FileEvent | str' = None,
        path: 'None | Container[pathlib.Path] | pathlib.Path' = None,
    ) -> 'Callable':
        return super().subscribe(type, path)
