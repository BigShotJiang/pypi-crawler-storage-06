from PySide6.QtWidgets import QListWidget

class AssetRelationsWindow(QListWidget):
    def __init__(self, parent=None):
        super(AssetRelationsWindow, self).__init__(parent)
