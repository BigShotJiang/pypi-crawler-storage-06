# Copyright (c) 2021 The Toltec Contributors
# SPDX-License-Identifier: MIT
"""Toltec build system"""

from .recipe_parsers import parse as parse_recipe
