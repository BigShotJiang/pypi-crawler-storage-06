def run():
    print("Osint tool download")
