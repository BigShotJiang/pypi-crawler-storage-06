# Copyright 2020-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0


from openfl.interface.aggregation_functions.core.adaptive_aggregation import AdaptiveAggregation
from openfl.interface.aggregation_functions.core.interface import AggregationFunction
