from .service import ApiAcademicoService
