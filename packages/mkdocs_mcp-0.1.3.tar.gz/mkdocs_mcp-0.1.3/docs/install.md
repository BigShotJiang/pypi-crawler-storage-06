# Install

> This is just a demo page

Use `uv` to install and run the project

## Install dev

```bash
uv sync --all-extras --dev
```

## Run

```bash
uv run python -m mkdocs_mcp --help
```
