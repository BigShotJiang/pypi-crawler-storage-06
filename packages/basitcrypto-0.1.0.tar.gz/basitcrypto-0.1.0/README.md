# BasitCrypto

A simple encryption library for Python that supports XOR and Caesar cipher.

## Installation

```bash
pip install basitcrypto
```


## Installation Local

```bash
pip install dist/basitcrypto-0.1.0-py3-none-any.whl
```
