from termgraph import termgraph as tg


def test_init_args():
    tg.init_args()