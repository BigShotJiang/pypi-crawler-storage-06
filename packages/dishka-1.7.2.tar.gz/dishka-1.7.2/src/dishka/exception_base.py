class DishkaError(Exception):
    pass
