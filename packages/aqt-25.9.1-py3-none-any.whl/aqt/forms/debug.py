from _aqt.forms.debug_qt6 import *
