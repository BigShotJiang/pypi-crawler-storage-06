from _aqt.forms.synclog_qt6 import *
