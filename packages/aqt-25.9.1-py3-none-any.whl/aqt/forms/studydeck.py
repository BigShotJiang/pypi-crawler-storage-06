from _aqt.forms.studydeck_qt6 import *
