from _aqt.forms.edithtml_qt6 import *
