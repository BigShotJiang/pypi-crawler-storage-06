from _aqt.forms.addonconf_qt6 import *
