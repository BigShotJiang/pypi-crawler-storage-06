from _aqt.forms.forget_qt6 import *
