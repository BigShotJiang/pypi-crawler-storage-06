from _aqt.forms.stats_qt6 import *
