import{T as n,S as d}from"./D0Kcqh4a.mjs";function s(t,e,i){var a=n(t,e);a&&a.set&&(t[e]=i,d(()=>{t[e]=null}))}export{s as b};
