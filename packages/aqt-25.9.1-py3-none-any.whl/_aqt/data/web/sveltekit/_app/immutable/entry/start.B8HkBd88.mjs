import{l as o,a as r}from"../chunks/DGXUj5Q6.mjs";export{o as load_css,r as start};
