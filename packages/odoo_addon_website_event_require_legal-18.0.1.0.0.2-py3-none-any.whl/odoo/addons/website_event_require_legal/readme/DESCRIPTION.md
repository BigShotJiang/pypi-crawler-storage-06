This module enforces to accept the legal terms for the registration from
the website on the events configured so.
