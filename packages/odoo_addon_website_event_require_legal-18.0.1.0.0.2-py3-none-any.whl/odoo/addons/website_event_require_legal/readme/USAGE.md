On the website go to events and register for the event that has been
configured to require acceptance of legal terms. In the registration
pop-up window you will see the acceptance box and the default text or
custom text. In order to be able to register you will need to accept the
terms. Once the registration is created, the metadata can be consulted
in the chatter for each registration that has been made.
