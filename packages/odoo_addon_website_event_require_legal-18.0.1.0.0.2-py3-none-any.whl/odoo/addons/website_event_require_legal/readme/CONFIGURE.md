To configure this module, you need to:

1.  Go to an event and set the Website Require Legal option on.
2.  Set the custom text to be displayed to accept the terms and
    conditions. If none is set, a default text will be displayed with a
    link to ‘/terms’.
