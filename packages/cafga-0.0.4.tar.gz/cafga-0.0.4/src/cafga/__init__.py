import dotenv

dotenv.load_dotenv()

from .cafga import CafGa