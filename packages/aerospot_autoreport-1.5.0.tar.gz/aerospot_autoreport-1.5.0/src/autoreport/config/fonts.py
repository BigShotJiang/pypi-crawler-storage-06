

# 字体配置
SONG_FONT_NAMES = ["宋体", "SimSun", "SimSun-ExtB"]
HEI_FONT_NAMES = ["黑体", "SimHei"]
TIMES_NEW_ROMAN = ["Times New Roman"]