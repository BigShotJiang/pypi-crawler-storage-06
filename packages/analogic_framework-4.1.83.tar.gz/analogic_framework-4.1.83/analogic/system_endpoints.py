from flask import Blueprint

system_endpoints = Blueprint('system_endpoints', __name__)
