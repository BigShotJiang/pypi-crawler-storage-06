'use strict';

class RestRequest {

    constructor(description) {
        this.description = description;
    }

    getDescription(){
        return this.description;
    }
}