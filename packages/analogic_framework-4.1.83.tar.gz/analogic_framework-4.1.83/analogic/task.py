from flask_apscheduler import APScheduler

scheduler = APScheduler()

