# django_client_logger

[![Build Status](https://github.com/uw-it-aca/django_client_logger/workflows/tests/badge.svg)](https://github.com/uw-it-aca/django_client_logger/actions)
[![Coverage Status](https://coveralls.io/repos/github/uw-it-aca/django_client_logger/badge.svg?branch=main)](https://coveralls.io/github/uw-it-aca/django_client_logger?branch=main)
[![PyPi Version](https://img.shields.io/pypi/v/django_client_logger.svg)](https://pypi.python.org/pypi/django_client_logger)
![Python versions](https://img.shields.io/badge/python-3.12-blue.svg)

