from _aqt.forms.editcurrent_qt6 import *
