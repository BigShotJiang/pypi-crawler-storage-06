from _aqt.forms.preferences_qt6 import *
