
# Rattail Demo

This project serves as a working demo, to illustrate various concepts
of the Rattail software framework.  See the [Rattail
Wiki](https://rattailproject.org/moin/) for more info.

Note that it *can be* usable as a starting point for your own project(s),
should you need one.  But probably the Rattail Tutorial is a better one.
