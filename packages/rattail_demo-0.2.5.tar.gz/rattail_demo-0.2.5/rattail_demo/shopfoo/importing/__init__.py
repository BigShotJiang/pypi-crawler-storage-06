# -*- coding: utf-8 -*-
"""
Importing into Shopfoo
"""

from . import model
