# -*- coding: utf-8 -*-
"""
Rattail Demo
"""

from __future__ import unicode_literals, absolute_import

from ._version import __version__
