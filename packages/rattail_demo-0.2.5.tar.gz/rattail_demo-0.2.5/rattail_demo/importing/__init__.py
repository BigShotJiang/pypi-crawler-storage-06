# -*- coding: utf-8 -*-
"""
Importing into Rattail Demo
"""

from . import model
