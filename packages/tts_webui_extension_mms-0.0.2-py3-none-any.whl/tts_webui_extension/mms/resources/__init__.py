# MMS resources
