"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "3f3c682c3a80d2730cb1de35a9f9c988c1c808c2"
short_id = "3f3c682"
