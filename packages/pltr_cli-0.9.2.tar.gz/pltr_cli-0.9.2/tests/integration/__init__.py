"""Integration tests for pltr-cli."""
