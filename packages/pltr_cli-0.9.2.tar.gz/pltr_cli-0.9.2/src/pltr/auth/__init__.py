"""Authentication module for pltr."""
