# amsdal-glue-connections

The connection implementations for AMSDAL Glue.

[![PyPI - Version](https://img.shields.io/pypi/v/amsdal-glue-connections.svg)](https://pypi.org/project/amsdal-glue-connections)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/amsdal-glue-connections.svg)](https://pypi.org/project/amsdal-glue-connections)

-----

## Table of Contents

- [Installation](#installation)

## Installation

```console
pip install amsdal-glue-connections
```
