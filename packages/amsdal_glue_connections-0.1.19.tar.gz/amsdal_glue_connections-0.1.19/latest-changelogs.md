## [v0.1.19](https://pypi.org/project/amsdal-glue-connections/0.1.19/) - 2025-09-20

### Changed

- Recreate table in sqlite on constraint changes
