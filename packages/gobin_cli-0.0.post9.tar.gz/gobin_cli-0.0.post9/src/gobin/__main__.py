# gobin/__main__.py
from gobin.cli import run_cli


def main():
    run_cli()
