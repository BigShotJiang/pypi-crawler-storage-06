"""A package for CLI command modules."""
