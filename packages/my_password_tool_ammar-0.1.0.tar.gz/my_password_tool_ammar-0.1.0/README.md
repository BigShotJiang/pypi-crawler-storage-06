# my_password_tool_ammar

أداة بسيطة بالبايثون لتقييم وتوليد كلمات المرور باللغة العربية.

التشغيل محلياً:
- python -m my_password_tool_ammar

بعد التثبيت:
- my-password-tool

المؤلف: عمار الشقاقي
