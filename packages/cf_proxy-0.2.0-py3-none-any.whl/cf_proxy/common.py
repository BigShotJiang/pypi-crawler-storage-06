class CFProxyError(Exception):
    """Exception raised for CF Proxy related errors."""
    pass
