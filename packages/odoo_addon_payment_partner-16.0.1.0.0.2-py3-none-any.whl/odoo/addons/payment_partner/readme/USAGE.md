1. Access the Payment Providers page
2. Unset the is global selector
3. Access the partners and select the specific non global payment providers

After this, we will be able to select this provider for the partner.
