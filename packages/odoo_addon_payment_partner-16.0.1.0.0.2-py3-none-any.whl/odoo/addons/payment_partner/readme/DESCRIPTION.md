This module allows to filter payment providers by partner.
