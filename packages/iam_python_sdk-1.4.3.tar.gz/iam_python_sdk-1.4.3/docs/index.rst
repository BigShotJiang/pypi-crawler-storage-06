.. include:: ../README.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage
   asyncio
   frameworks
   modules
   contributing
   authors
   changelog

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
