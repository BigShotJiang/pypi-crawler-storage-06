=======
Credits
=======

Maintainers
----------------

This project is maintained by AccelByte's Justice Analytics team. Feel free to reach us on justice-analytics-team@accelbyte.net

Contributors
------------

Many thanks for all contributors. The list of all contributors can be seen on this page https://github.com/AccelByte/iam-python-sdk/graphs/contributors


Generators
----------

This package was generated with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
