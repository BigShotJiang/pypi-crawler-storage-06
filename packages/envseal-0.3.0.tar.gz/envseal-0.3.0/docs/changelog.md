# Changelog
See the [GitHub Releases](https://github.com/justTil/envseal/releases).
