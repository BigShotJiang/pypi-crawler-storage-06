# API Reference

::: envseal
