# fluxgraph/__init__.py
from .core.app import FluxApp

__all__ = ["FluxApp"]
