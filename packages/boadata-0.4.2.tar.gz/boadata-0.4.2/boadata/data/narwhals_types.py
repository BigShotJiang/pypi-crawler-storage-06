import narwhals as nw


class NarwhalsDataFrameBase(DataObject):

