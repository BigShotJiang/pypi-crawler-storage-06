pycvcam.read_transform
=============================

.. autofunction:: pycvcam.read_transform
