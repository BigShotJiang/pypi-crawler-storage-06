from .main import Console
from .main import Cursor
from .main import Widget