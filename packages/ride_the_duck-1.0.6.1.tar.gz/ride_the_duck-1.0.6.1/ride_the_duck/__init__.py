"""
Ride the Duck - A terminal-based gambling card game.
"""

__version__ = "1.0.3"
__author__ = "Braeden Sy Tan"

from .mainGame import main

__all__ = ["main"]