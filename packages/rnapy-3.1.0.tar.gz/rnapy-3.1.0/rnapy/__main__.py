#!/usr/bin/env python3
"""
RNApy CLI module entry point for python -m rnapy
"""

from .cli import main

if __name__ == '__main__':
    main() 