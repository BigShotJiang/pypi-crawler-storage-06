'''
__init__.py
'''

from .sp import dijkstra

__all__ = ["dijkstra"]
__version__ = "0.1.0"
