
from setuptools import setup

setup(package_data={'xmltodict-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
