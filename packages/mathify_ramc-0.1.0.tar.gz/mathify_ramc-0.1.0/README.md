# MATHIFY

A simple arithmetic and algebric package for Python.

## Installation

```bash
pip install mathify-ramc