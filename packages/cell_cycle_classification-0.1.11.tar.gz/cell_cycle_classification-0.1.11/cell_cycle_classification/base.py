"""
cell_cycle_classification base module.

This is the principal module of the cell_cycle_classification project.
here you put your main classes and objects.

Be creative! do whatever you want!

If you want to replace this with a Flask application run:

    $ make init

and then choose `flask` as template.
"""

# example constant variable
NAME = "cell_cycle_classification"
