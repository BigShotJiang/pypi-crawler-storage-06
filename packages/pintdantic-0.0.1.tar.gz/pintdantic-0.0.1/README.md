[![pytest](https://github.com/ppak10/pintdantic/actions/workflows/pytest.yml/badge.svg)](https://github.com/ppak10/pintdantic/actions/workflows/pytest.yml)
[![codecov](https://codecov.io/gh/ppak10/pintdantic/graph/badge.svg?token=542K2LPT47)](https://codecov.io/gh/ppak10/pintdantic)

# pintdantic
Pydantic bindings for Pint

