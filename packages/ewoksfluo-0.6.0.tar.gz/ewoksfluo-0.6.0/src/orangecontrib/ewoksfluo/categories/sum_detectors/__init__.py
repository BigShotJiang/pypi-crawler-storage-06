NAME = "Fluo Summing"

DESCRIPTION = "Fluo Summing"

LONG_DESCRIPTION = "Fluo Summing"

ICON = "icons/category.png"

BACKGROUND = "light-blue"
