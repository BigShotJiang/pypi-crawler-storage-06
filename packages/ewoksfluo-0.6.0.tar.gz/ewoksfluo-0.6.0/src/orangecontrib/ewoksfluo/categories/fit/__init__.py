NAME = "Fluo Fitting"

DESCRIPTION = "Fluo Fitting"

LONG_DESCRIPTION = "Fluo Fitting"

ICON = "icons/category.png"

BACKGROUND = "light-blue"
