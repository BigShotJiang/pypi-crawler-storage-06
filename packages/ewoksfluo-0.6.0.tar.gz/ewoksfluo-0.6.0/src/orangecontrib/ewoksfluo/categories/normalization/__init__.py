NAME = "Fluo Normalization"

DESCRIPTION = "Fluo Normalization"

LONG_DESCRIPTION = "Fluo Normalization"

ICON = "icons/category.png"

BACKGROUND = "light-blue"
