NAME = "Fluo Scan Selection"

DESCRIPTION = "Fluo Scan Selection"

LONG_DESCRIPTION = "Fluo Scan Selection"

ICON = "icons/category.png"

BACKGROUND = "light-blue"
