NAME = "Fluo Regridding"

DESCRIPTION = "Fluo Regridding"

LONG_DESCRIPTION = "Fluo Regridding"

ICON = "icons/category.png"

BACKGROUND = "light-blue"
