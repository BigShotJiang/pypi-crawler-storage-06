NAME = "Fluo Counters"

DESCRIPTION = "Fluo Counters"

LONG_DESCRIPTION = "Fluo Counters"

ICON = "icons/category.png"

BACKGROUND = "light-blue"
