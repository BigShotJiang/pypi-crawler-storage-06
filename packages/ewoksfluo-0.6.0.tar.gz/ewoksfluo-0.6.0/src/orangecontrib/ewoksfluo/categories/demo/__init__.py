NAME = "Fluo Demo"

DESCRIPTION = "Fluo Example Data"

LONG_DESCRIPTION = "Fluo Example Data"

ICON = "icons/category.png"

BACKGROUND = "light-blue"
