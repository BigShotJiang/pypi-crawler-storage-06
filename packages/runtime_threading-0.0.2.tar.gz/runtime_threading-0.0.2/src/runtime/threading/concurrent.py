from runtime.threading.core.concurrent.queue import Queue

__all__ = (
    'Queue',
)