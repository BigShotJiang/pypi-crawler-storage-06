class ThreadingException(Exception):
    """The ThreadingException exception is the base exception from which all other exceptions in this package derives,
    but it's also raised  if a precondition fails."""
    pass