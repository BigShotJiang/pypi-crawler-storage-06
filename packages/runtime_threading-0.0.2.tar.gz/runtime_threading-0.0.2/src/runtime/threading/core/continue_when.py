from enum import IntEnum

class ContinueWhen(IntEnum):
    ANY = 1
    ALL = 2