/// Discrete sampling utilities (alias method) for negative sampling.
pub mod alias;
