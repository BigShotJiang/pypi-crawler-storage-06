"""Init module for urls."""
