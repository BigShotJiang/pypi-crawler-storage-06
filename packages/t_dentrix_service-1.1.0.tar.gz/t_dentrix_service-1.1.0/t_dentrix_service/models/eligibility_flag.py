"""Contain enums for Eligibility Flag."""


class EligibilityFlag:
    """Attachment types for Dentrix."""

    YES = "YES"
    NO = "NO"
    OTHER = "OTHER"
