"""Test the Cutesy package against spec documents."""
