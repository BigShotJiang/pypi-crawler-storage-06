#!/bin/bash
"$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/deploy-to-production.sh" "$@"
