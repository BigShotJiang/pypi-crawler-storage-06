from .selected_document_data import selected_document_data

__all__ = ["selected_document_data"]
