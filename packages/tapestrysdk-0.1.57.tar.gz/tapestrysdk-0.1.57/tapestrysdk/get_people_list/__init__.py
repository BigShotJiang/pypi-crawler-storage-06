from .get_people_list import get_people_list

__all__ = ["get_people_list"]
