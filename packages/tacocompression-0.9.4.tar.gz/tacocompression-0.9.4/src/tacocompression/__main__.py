import argparse
from tacocompression.compression import compress, decompress
from tacocompression.input_output import load_inputs, save_output


parser = argparse.ArgumentParser()
parser.add_argument("-m", "--mode", type=str, help="c for compress or d for decompress", choices=["c", "d"])
parser.add_argument("-o", "--output", help="Specify the output directory")
parser.add_argument("-d", "--decimals", type=int, default=1,
                    help="Precision of the reconstruction, i.e., number of decimals recoverable during decompression.")
parser.add_argument("-p", "--pairing_function", type=str, default="rosenberg",
                    help="The pairing function to use to combined two values in the time series.",
                    choices=["rosenberg", "szudzik", "cantor"])
kw_args, inputs = parser.parse_known_args()
data, file_names = load_inputs(inputs, kw_args.mode == 'c')
if kw_args.mode == "c":
    outputs, _ = compress(data, kw_args.pairing_function, kw_args.decimals)
    file_names = ["compressed_" + fn for fn in file_names]
    save_output(outputs, file_names, kw_args.output)
else:
    outputs = decompress((data, kw_args.decimals), kw_args.pairing_function)
    file_names = [fn[11:] if fn.startswith("compressed_") else fn for fn in file_names]
    save_output(outputs, file_names, kw_args.output)