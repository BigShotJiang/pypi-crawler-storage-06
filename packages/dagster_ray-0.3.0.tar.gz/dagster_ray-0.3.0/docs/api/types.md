# Types API Reference

Type definitions and base classes used throughout `dagster-ray`.

---

::: dagster_ray.types.AnyDagsterContext
::: dagster_ray.types.OpOrAssetExecutionContext
