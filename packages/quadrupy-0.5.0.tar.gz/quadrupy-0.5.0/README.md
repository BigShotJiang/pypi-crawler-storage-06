to run this code and for it to work you must have a device connceted to the com 12, specifically an esp32

it is also notable that you should not really use this package for anything other then the STQV1 robot quadruped. 