# Aioampio

## Asynchronous library to control Ampio Devices

Requires Python 3.12+ and uses asyncio.

For usage examples, see the examples folder.

It is used by Ampio Home Assistance custom component.
