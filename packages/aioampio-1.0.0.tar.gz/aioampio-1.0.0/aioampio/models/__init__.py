"""Schemas for Ampio entities."""
