/* eslint-disable @typescript-eslint/no-explicit-any */
export const JsonRefs: {
  resolveRefs(schema: any): Promise<{ resolved: any }>;
};
