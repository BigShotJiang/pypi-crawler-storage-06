# le ponemos documentación para que vs code sepa de que va este modulo
# triple comilla doble es un doc string si va al principio, esto es una documentación para nuestros paquetes
# y para nuestros modulos, si van al comienzo de larchivo python sabe que es la documentación si va dentro del __init__.py
"""
Esta es la documentacion del paquete
"""
