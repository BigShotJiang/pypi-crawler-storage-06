# This file is currently (2022-06) required in order for pip to be able to create
# editable installs when build meta is included to pyproject.toml. Likely that at
# some future point this will no longer be required and file can be removed.
# Reference: https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html

from setuptools import setup

setup()
