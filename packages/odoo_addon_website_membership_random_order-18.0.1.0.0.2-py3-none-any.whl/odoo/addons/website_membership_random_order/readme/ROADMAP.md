- All the members will be displayed at once, without pager, as this is
  the only way to get a whole randomized list. On contrary, paging the
  content, on each render, we will get random elements belonging to that
  slice. Don't use this module with a long list of members.
- Random mode does not work with free members.
