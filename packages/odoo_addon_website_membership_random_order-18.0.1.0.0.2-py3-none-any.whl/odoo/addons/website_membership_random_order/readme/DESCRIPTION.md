This modules extends the online members directory for displaying the
results in a random order, and displays a disclaimer about it at the top
of the list.
