from setuptools import setup

setup(
    name="koxs-color",          # pip 显示的包名（可以带-）
    version="0.1.0",
    packages=['koxs_color'],    # 实际的Python包名（必须匹配目录名）
    description="一个实用的 koxs 工具包",
    author="您的名字",
    python_requires=">=3.6",
)