
User guide
=============

.. toctree::
   :maxdepth: 1

   sources
   data
   data_format/index.rst
   encoders
   targets/index.rst
   streams
   config
   caching
   xarray/index.rst
   misc/index.rst
