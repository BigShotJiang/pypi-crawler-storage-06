.. _xr_profile_grib:

Profiles: grib
-------------------------

This is the definition of the built-in ``"grib"`` profile for the :ref:`xr_engine`.


.. module-output:: xr_engine_profile_rst grib
