import earthkit.data

# Reset a named config option to its default value
earthkit.data.config.reset("user-cache-directory")

# Reset all the config options to their default values
earthkit.data.config.reset()
