"""Test package for pysfmc."""
