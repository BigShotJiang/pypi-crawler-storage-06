"""Data models for SFMC API responses and requests."""

from .assets import *  # noqa: F403
from .base import SFMC_MODEL_CONFIG as SFMC_MODEL_CONFIG
