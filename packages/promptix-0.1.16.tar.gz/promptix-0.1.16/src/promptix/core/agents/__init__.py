"""
Agent-related functionality for Promptix.

This module contains agent-related classes and utilities.
"""
