"""
Agent adapter functionality for Promptix.

This module contains agent adapter classes and utilities.
"""
