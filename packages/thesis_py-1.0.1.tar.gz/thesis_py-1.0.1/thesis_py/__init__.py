from .api import Thesis as Thesis


__all__ = [
    "Thesis",
]
