import pytest

from oshconnect import OSHConnect, System, Node, Datastream

node = Node()
app = OSHConnect()