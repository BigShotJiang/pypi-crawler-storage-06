# Changelog

## 0.1.0 (2022-03-23)

* First release on PyPI.
