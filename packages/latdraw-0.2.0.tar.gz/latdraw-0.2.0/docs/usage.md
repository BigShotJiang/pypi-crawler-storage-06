# Usage

To use latdraw in a project

```
import latdraw
```
