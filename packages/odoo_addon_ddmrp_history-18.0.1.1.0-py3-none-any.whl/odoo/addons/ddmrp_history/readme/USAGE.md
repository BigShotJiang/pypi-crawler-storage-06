You can access, as a inventory manager, to all the DDMRP historical data
throught *Inventory \> Reports \> DDMRP Buffer History*. Additionally
you can see a historical evolution chart of any buffer at the bottom of
its form view, either by a planning or a execution perspective.
