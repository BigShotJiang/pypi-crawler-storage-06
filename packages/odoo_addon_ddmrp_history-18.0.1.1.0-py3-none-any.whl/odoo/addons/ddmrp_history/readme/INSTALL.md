You need to install the python pandas library:

    pip install pandas==0.25.3
