Allow to extend DDMRP App to store historical data of buffers.
