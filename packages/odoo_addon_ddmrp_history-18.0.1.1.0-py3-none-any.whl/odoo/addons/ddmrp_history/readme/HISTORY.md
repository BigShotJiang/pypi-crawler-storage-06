## 13.0.1.0.0 (2020-06-16)

- Migration to v13.

## 11.0.1.0.1 (2019-02-07)

- Make history charts responsive and remove NFP from execution chart.
- Use user's language to format dates in the charts.

## 11.0.1.0.0 (2018-08-01)

- Start of the history
