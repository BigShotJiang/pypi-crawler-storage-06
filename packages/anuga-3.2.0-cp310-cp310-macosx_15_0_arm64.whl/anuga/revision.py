"""Stored git revision info.

This file provides the git sha id and commit date for the installed revision of ANUGA.
The file is automatically generated and should not be modified manually.
"""

__git_sha__ = "f0791cdf7ca442f934499762427954ac364086a9"
__git_committed_datetime__ = "2025-09-25 17:41:51+10:00"
__version__ = "3.2.1rc17"
