""" Simulation Module

    This module wraps the standard anuga script into a simulation class which
    allows for the user to define the standard creation of domain etc

"""

from numpy._pytesttester import PytestTester
test = PytestTester(__name__)
del PytestTester