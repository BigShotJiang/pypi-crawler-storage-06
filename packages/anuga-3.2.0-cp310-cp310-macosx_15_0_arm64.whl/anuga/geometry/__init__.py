"""
    Geometry classes.
    
    Classes that represent 2D geometry: polygons, quadtrees, and bounding boxes.
"""


from numpy._pytesttester import PytestTester
test = PytestTester(__name__)
del PytestTester



