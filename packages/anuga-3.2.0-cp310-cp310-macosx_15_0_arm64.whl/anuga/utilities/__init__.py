"""
    Generic utility classes not concerned with the specifics of ANUGA.
    
    Utility functions for managing files, numerical constants, and generic
    mathematical and programming idioms.
"""

from numpy._pytesttester import PytestTester
test = PytestTester(__name__)
del PytestTester



