# cloud_instance

Usage example:

```text
ansible-playbook play.yaml
```
