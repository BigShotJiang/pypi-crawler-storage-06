# gesture-blocks

Block-style gesture control for Arduino + Python.

## Install
```bash
pip install gesture-blocks
