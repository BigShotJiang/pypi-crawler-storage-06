# Math Tools

مكتبة بسيطة في بايثون لإجراء عمليات رياضية أساسية.

## التثبيت
```bash
pip install math-tools
