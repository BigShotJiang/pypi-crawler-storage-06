# Nimpy

**Nimpy** is a Python library.

---

## Installation

Install via pip:

```bash
pip install nimpy-mannny
