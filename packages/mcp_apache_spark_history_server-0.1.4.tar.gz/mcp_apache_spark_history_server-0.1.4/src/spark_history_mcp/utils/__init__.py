"""Utility functions and helpers for Spark History Server MCP."""
