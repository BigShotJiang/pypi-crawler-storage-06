"""Core application components for Spark History Server MCP."""
