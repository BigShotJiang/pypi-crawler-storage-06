"""MCP tools implementation for Spark History Server."""
