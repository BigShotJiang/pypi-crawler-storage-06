# Scripts

These scripts can be used to enhance GAM's capabilities; all are supported with Advanced GAM,
many are supported with Legacy GAM. They require that Python 3 be installed on you computer.

* https://github.com/taers232c/GAM-Scripts3
* https://www.python.org/
