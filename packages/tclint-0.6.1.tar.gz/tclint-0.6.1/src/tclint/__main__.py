import sys
from tclint.cli.tclint import main

sys.exit(main())
