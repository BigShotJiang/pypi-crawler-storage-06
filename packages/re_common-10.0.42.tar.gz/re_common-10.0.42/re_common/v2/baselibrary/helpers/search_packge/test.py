aa ="肿瘤 学 研究 进展"
print(str.split(aa))