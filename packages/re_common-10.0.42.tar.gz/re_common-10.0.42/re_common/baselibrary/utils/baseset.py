class BaseSet(object):

    def __init__(self):
        pass

    def union(self, *args):
        one = set()
        return one.union(*args)
