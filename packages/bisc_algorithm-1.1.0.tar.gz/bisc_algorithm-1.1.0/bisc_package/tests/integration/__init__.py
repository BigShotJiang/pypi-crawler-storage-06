"""
Integration tests for the BiSC algorithm.
"""