from .endpoint import OAuth2Endpoint
