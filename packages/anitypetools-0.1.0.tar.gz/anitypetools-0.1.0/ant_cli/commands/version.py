VERSION = "0.1.0"

def show(params):
    print(f"ant version {VERSION}")