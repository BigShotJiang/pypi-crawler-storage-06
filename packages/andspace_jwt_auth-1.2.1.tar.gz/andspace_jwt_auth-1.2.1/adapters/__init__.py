"""Framework adapters for easy integration with web frameworks."""
