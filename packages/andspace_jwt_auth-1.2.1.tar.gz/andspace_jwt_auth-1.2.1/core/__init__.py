"""Core components for JWT authentication library."""
