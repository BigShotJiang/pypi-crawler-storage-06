"""Authentication providers for JWT token validation."""
