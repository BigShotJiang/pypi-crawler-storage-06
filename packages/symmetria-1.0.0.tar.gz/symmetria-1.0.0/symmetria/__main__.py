from symmetria.cli.cli import run_command_line_interface


def main() -> None:
    """Entry point for the command line interface."""
    run_command_line_interface()


if __name__ == "__main__":
    main()
