"""
JSON Schema Storage Directory

Generated SchemaSpec JSON files are stored here when no custom path is specified.
"""
