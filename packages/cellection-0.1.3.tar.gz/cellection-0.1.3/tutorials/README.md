## Try CELLECTION in Google Colab

Click the badge below to launch an interactive Colab notebook using a test dataset and CELLECTION:


[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1lEgEcbNuzq65_f_j7HZ64QD9s34SoENJ)


---

## 📂 Test Data Access

You can download the example dataset used in the notebook here:

🔗 [(Google Drive)](https://drive.google.com/file/d/1-VdTJSIvzbTuF2HH2EgIgwcomzkUJc9l/view?usp=sharing)

Or it will be automatically downloaded when running the Colab notebook.
