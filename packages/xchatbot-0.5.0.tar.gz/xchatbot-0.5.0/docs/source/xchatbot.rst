xchatbot module
===============

.. automodule:: xchatbot
   :members:
   :undoc-members:
   :show-inheritance:
