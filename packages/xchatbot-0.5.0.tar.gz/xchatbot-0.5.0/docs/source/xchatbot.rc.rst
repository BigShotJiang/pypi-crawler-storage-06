xchatbot.rc
===========


