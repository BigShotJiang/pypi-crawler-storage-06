"""
A simple dummy Python package.

This package provides basic utility functions as a template example.
"""

__version__ = "0.2.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .utils import greet, calculate

__all__ = ["greet", "calculate", "__version__"]
