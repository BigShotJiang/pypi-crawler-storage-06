"""Crypto plugin for KillerTools."""

from killer_tools.plugins.crypto.plugin import CryptoPlugin

__all__ = ["CryptoPlugin"]
