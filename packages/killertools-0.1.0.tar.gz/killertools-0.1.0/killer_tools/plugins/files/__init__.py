"""Files plugin for KillerTools."""

from killer_tools.plugins.files.plugin import FilesPlugin

__all__ = ["FilesPlugin"]
