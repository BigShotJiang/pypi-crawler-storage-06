"""DevTools plugin for KillerTools."""

from killer_tools.plugins.devtools.plugin import DevToolsPlugin

__all__ = ["DevToolsPlugin"]
