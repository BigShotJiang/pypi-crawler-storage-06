"""GUI application for KillerTools."""
