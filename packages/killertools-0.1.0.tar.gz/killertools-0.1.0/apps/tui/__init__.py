"""TUI application for KillerTools."""
