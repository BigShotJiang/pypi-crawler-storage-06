"""Applications for KillerTools."""
