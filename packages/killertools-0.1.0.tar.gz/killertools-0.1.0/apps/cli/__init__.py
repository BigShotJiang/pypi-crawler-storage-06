"""CLI application for KillerTools."""
