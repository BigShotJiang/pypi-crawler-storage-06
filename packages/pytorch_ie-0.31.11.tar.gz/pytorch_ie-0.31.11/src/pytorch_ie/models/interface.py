class RequiresModelNameOrPath:
    pass


class RequiresNumClasses:
    pass
