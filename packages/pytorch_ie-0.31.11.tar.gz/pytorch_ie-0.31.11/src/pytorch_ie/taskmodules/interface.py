class ChangesTokenizerVocabSize:
    pass
