# calc_maker

A tiny Python library that generates a simple calculator Python file.
