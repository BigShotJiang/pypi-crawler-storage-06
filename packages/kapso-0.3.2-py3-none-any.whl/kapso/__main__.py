"""
Main entry point for the Kapso CLI when run as a module.
"""

from kapso.cli.main import main

if __name__ == "__main__":
    main()
