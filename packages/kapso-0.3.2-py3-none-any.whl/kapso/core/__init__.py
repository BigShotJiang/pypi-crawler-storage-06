"""
Core utilities for Kapso SDK.
"""