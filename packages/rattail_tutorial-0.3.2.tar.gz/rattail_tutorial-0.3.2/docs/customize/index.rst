
Customizing the App!
====================

Now that you've made it through the "setup" gauntlet, it's finally time for
some fun stuff.

As we're building this tutorial, at this point our project is *basically* the
same as any other "Poser" project, as generated via scaffold.  But as we keep
going, our project will become more and more customized for the purposes of the
tutorial.

So if you have just created a new project, some of this might make more sense
to you, vs. if you're running the rattail-tutorial project itself, many things
described in this section will have already been done (and then some) to the
code base, so you should keep that in mind when reading.


.. toctree::
   :maxdepth: 2

   disable-web-view
