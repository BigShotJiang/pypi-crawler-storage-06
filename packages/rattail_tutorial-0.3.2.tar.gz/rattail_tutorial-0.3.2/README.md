
# rattail-tutorial

This project is intended for use as a "tutorial" for Rattail app development.

It contains documentation for the tutorial itself, but also contains
code for the tutorial app, which users may run locally for testing.

See the [Rattail website](https://rattailproject.org/) for more info.
