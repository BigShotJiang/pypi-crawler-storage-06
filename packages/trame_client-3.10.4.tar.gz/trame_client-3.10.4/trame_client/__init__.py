from .utils.version import get_version

__version__ = get_version("trame-client")
