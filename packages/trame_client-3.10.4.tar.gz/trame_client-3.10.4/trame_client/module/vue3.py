from pathlib import Path

www = str(Path(__file__).with_name("vue3-www").resolve())
