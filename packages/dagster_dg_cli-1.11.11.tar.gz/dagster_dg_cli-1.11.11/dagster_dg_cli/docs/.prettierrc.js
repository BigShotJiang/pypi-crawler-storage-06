module.exports = {
  bracketSpacing: false,
  printWidth: 100,
  singleQuote: true,
  trailingComma: 'all',
};
