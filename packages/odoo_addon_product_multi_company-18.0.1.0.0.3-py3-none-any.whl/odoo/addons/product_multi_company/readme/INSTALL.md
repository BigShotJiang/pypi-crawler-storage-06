This module uses the post and uninstall hooks for updating default
product template security rule. This only means that updating the module
will not restore the security rule this module changes. Only a complete
removal and reinstallation will serve.
