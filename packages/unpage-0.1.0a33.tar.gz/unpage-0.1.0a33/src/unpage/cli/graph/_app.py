from cyclopts import App

graph_app = App(help="Build a knowledge graph")
