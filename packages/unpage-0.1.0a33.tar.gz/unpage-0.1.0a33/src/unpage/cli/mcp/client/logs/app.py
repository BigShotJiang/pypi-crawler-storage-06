from cyclopts import App

client_logs_app = App(
    help="Show logs for a client of the Unpage MCP Server, like Claude Desktop",
)
