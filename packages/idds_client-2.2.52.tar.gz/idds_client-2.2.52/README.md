idds-client
====

idds-client subpackage is for iDDS rest client.
