[project]
name = "truthai-sdk"
version = "0.0.1"
description = "Coming soon from TruthAI"
authors = [{name = "Your Name", email = "your@email.com"}]

