//
// Created by Quarter on 27.02.2023.
//

#include "chromosome_evaluator.h"
