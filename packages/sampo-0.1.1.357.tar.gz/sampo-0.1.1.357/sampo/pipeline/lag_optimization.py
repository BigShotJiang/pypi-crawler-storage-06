from enum import Enum


class LagOptimizationStrategy(Enum):
    TRUE = True
    FALSE = False
    AUTO = None
