from sampo.generator.pipeline import SyntheticGraphType
from sampo.generator.base import SimpleSynthetic
from sampo.generator.pipeline import get_small_graph, get_graph, get_cluster_works
