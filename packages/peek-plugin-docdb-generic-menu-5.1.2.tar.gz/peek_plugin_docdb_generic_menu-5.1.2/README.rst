==============================
Peek DocDB Generic Menu Plugin
==============================

This Peek Plugin provides generic menus in the DocDB popups. The menus
will open other websites, passing information from the selected equipment and
adding information found in the DocDB plugin.