"""
Algorithmic differentiators and invariators
"""

