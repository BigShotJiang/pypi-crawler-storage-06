from pettingzoo.utils import env

AgentID = env.AgentID
ObsType = env.ObsType
ActionType = env.ActionType
