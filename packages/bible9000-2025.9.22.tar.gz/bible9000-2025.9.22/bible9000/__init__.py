#!/usr/bin/env python3
from bible9000.main import mainloop
mainloop()
