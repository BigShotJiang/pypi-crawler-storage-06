# The-Stick-of-Joseph
Ancient Prophecy designed for Our Times

## Foreword
Pure religion has nothing to do with me controlling you - it has to do with God, controlling me. 

Adam, after all, was permitted to do whatever she did.

By their fruit, shall ye know them?

So I make no apologies for the fact that I - like billions of others - get a great feeling when I read the scriptures. 

Indeed, in order to share the warm-and-fuzzy feelings with any who might be able to experience the same, I have learned many technologies. 

Here is where I share "The Stick of Joseph" (a.k.a. "The 81 Books of Terror" :^)

Sharing is caring?

## Universal User Interface
The Stick of Joseph is forever a console user interface.

### Why a TUI?
From our pockets to the clouds ditching GUI's permits maximum - dare I say global - software re-use.

## Features & Function
This first release offers:

* Verse-Numbers to facilitate faster verse sharing.
* Classic chapter-verse lookup to allow classic browsing.
* Random verse browsing to allow infinite inspirations.
* Verse notation & reporting.
* Verse "starring" & reporting.

## Running
To run the 'app, merely:

```
python3 -m bible9000
```

Stay inspired!

--- Doctor Randall 
