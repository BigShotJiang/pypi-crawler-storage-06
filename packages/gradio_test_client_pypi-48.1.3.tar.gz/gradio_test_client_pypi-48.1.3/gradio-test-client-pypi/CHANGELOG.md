# gradio-test-client-pypi

## 48.1.0

### Fixes

- [#32](https://github.com/pngwn/pypi-npm-changeset/pull/32) [`343bda7`](https://github.com/pngwn/pypi-npm-changeset/commit/343bda7ccf39458fb7172693c137e3773f834eea) - update client. Thanks [@pngwn](https://github.com/pngwn)!