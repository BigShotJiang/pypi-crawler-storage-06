def foo(value=False):
    a = 'a'
    b = 'b'
    if value:
        c = 'c'
        d = 'd'
        e = 'e'
    else:
        f = 'f'
