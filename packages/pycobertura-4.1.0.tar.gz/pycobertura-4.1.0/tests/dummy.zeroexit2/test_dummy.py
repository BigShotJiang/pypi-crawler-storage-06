def test_foo():
    from dummy.dummy import foo
    foo(value=True)
