def test_qualified_for_discount():
    from dummy.dummy import qualifies_for_discount
    qualifies_for_discount(8, 90)
