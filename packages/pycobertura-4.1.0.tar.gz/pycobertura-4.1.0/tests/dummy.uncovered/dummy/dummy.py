def baz():
    pass

def foo():
    if foo is None:
        print("I never happen")
    pass

def bar():
    pass
