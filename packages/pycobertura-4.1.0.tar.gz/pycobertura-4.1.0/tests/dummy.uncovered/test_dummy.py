def test_foo():
    from dummy.dummy import foo
    foo()


def test_bar():
    from dummy.dummy import bar
    bar()


def test_baz():
    from dummy.dummy import baz
    baz()
