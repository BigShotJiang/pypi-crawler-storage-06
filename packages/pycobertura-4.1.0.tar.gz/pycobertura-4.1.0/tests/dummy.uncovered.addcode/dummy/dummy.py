def baz():
    if baz is str:
        print("something else that doesn't happen")
    pass

def foo():
    if foo is None:
        print("I never happen")
    pass

def bar():
    pass
