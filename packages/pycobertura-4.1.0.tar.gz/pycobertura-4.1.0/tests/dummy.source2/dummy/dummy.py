def foo():
    pass

def bar():
    a = 'a'
    d = 'd'
