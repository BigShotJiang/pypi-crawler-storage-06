def baz():
    c = 'c'

def bat():
    pass
