def test_imports():
    from pycobertura import Cobertura
    from pycobertura import CoberturaDiff
    from pycobertura import TextReporter
    from pycobertura import TextReporterDelta
