def foo():
    pass

def bar():
    a = 'a'
    b = 'b'
