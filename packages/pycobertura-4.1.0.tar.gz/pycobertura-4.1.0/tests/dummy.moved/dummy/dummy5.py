def barbaz():
    pass

def foobarbaz():
    a = 1 + 3
    pass
