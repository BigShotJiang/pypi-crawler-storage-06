def test_foo():
    from dummy.dummy import foo
    foo()


def test_baz():
    from dummy.dummy2 import baz
    baz()
