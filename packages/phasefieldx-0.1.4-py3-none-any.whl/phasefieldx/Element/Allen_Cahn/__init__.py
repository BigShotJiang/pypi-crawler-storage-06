# phasefieldx/Element/Allen_Cahn/__init__.py

# Import submodules to be included in the package namespace

from .Input import *
from .solver import *
