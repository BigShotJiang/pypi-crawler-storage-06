"""Constitute MCP Server - Constitutional Document Analysis and Scraping Tools."""

__version__ = "0.1.25"
__author__ = "Your Name"
__email__ = "your.email@example.com"
