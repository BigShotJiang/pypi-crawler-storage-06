La ritenuta d’acconto provvede a calcolare automaticamente i valori
delle diverse tipologie di ritenuta presenti nella contaiblità italiana.

Con questo modulo è possibile, tramite apposito workflow, gestire i
diversi passaggi di stato delle ritenute rilevate: dovuta, applicata,
versata
