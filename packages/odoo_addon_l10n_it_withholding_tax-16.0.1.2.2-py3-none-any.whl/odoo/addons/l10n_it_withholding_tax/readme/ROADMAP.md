The Residual Net To Pay set in the Payment wizard should be converted in
the wizard's currency when it changes
