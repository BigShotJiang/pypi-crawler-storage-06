---
orphan: true
---

# Arizona

> This state uses the Job Center platform. See the [Job Center docs](job_center.md)
> for details on the scraping strategy.

- [Home page](https://www.azjobconnection.gov)
- [Search form](https://www.azjobconnection.gov/search/warn_lookups/new)
- [All data][]
- General contact form is [here](https://arizonaatwork.com/contact)

[All data]: https://www.azjobconnection.gov/search/warn_lookups?utf8=%E2%9C%93&q%5Bemployer_name_cont%5D=&q%5Bmain_contact_contact_info_addresses_full_location_city_matches%5D=&q%5Bzipcode_code_start%5D=&q%5Bservice_delivery_area_id_eq%5D=&q%5Bnotice_on_gteq%5D=&q%5Bnotice_on_lteq%5D=&q%5Bnotice_eq%5D=&commit=Search
