---
orphan: true
---

# Virgina

### July 20, 2021
Created a ticket to contact VA about some ambiguous and confusing fields. Frankly they could've done a better job data vetting, but I guess that's what we're here for.

-"Location/City" and "Location State" fields
(seems to be associated with the location of the layoff, and all but like one entry are in Virginia. Why do they have that one Washington, DC entry??)

-"Company Address 1", "Company Address 2", and "City/Town".
(seems to be associated with the HQ of the business, and many of these list different states. probably not useful for our purposes but it would be good to ask clarification about what these exist for.)
