ALTER TABLE :schema_name.:table_name ADD COLUMN :column_name :column_type;
