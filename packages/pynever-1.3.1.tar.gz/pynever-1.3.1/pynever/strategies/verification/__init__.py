import logging

VERIFICATION_LOGGER = logging.getLogger("pynever.strategies.verification")
