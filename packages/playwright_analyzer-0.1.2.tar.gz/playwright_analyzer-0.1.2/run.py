#!/usr/bin/env python3
"""Convenience launcher for the Playwright analyzer."""

from src.playwright_analyzer.analyze_report import main

if __name__ == "__main__":
    main()