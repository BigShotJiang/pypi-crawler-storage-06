from PyQt6.QtWidgets import QWidget, QFrame

class QBlanckWidget1(QWidget):
    def __init__(self):
        super().__init__()
        
class QSeparator1(QFrame):
    def __init__(self):
        super().__init__()
        