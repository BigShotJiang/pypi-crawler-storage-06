# backwards compatibility
from .dictionary import flatten_dict, list_of_dicts2dict_of_lists
from .hydra import resolve_type
