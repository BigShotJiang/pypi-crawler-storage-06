# ❄🔥 Frostfire

> *“Ice remembers what flame forgets.”*  
> — Kareth of the Ember Vault, spoken beneath a frozen moon

**Frostfire** is a compact library of Python functions.

☠️ Disclaimer

The code is indifferent.
