"""
🎼 ABCWeaver CLI Entry Point

Allows running abcweaver as a module: python -m abcweaver
"""

from .cli import abcweaver

if __name__ == "__main__":
    abcweaver()