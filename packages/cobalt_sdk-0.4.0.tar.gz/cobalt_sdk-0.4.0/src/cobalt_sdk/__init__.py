"""Cobalt Python API package."""

"""Cobalt Python APIパッケージ。"""

__version__ = "0.4.0"

from .lib import *
from .types import *
