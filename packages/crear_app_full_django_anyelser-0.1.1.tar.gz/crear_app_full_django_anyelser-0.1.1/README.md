# instalar

pip install crear-app-full-django-anyelser

# Ejecutar tu comando

crear-app-full-django mi_app_prueba
