# mymodule.py

class CustomClass(object):
    def __iter__(self):
        return iter([1, 2, 3])
