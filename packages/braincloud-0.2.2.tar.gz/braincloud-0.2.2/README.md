# BrainCloud
Deep research bring-your-own-keys web application.

# Upstream
Based on Apache 2.0 licensed code and model
from Alibaba Tongyi Lab's DeepResearch:

* https://tongyi-agent.github.io/blog/introducing-tongyi-deep-research/
* https://github.com/Alibaba-NLP/DeepResearch
* https://huggingface.co/Alibaba-NLP/Tongyi-DeepResearch-30B-A3B

...and many other free software projects...

# 📄 License
This project is licensed under the Apache License 2.0.
See the [LICENSE](LICENSE-apache.txt) file for details.

*Copyright © 2025 Jeff Moe*
