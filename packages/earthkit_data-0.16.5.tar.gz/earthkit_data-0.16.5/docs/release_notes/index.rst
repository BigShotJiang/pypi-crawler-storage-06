Release notes
=============

Deprecated features
+++++++++++++++++++++

.. toctree::
    :maxdepth: 1

    deprecations

Version updates
+++++++++++++++++++++

.. toctree::
    :maxdepth: 1

    version_0.16_updates
    version_0.15_updates
    version_0.14_updates
    version_0.13_updates
    version_0.12_updates
    version_0.11_updates
    version_0.10_updates
    version_0.9_updates
    version_0.8_updates
    version_0.7_updates
    version_0.6_updates
    version_0.5_updates
    version_0.4_updates
    version_0.3_updates
    version_0.2_updates
