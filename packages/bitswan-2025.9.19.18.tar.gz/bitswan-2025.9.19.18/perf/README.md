# BitSwan BSPump Performance testing

This folder contains various performance testing suites for BSPump.

