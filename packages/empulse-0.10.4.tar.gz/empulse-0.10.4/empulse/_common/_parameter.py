from enum import Enum


class Parameter(Enum):
    """Used to know if parameters have been set."""

    UNCHANGED = 'unchanged'
