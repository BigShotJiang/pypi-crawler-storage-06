2009 Pacific-Asia Knowledge Discovery and Data Mining conference (PAKDD) competition

This dataset comes from the private label credit card operation of a major Brazilian retail chain,
along stable inflation condition (2003-2008).
The goal is to predict whether a customer will default on their credit card payment.

=================   ==============
Classes                          2
Defaulters                    7743
Non-defaulters               31195
Samples                      38938
Features                        25
=================   ==============

For more information, read the User Guide https://empulse.readthedocs.io/en/latest/guide/datasets_guide.html
