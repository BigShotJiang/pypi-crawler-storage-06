2011 Kaggle competition Give Me Some Credit

This is a Kaggle dataset from the credit agency Credit Fusion.
The goal is to predict whether a customer will default on a loan in the next two years.

Banks play a crucial role in market economies.
They decide who can get finance and on what terms and can make or break investment decisions.
For markets and society to function, individuals and companies need access to credit.
Credit scoring algorithms, which make a guess at the probability of default,
are the method banks use to determine whether or not a loan should be granted.

=================   ==============
Classes                          2
Defaulters                    7616
Non-defaulters              105299
Samples                     112915
Features                        10
=================   ==============

For more information, read the User Guide https://empulse.readthedocs.io/en/latest/guide/datasets_guide.html
