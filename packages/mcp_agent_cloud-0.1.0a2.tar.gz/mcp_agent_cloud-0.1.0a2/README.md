# MCP Agent Cloud Python API library

MCP Agent Cloud API is now directly integrated in [mcp-agent](https://pypi.org/project/mcp-agent/); please use that package instead.
