# Changelog

## 0.1.0-alpha.1 (2025-04-21)

Full Changelog: [v0.0.1-alpha.0...v0.1.0-alpha.1](https://github.com/lastmile-ai/mcp-agent-cloud/compare/v0.0.1-alpha.0...v0.1.0-alpha.1)

### Features

* **api:** api update ([86bd287](https://github.com/lastmile-ai/mcp-agent-cloud/commit/86bd287b7759b55d6251d50ddbe4209732cd2706))
* **api:** api update ([25b6815](https://github.com/lastmile-ai/mcp-agent-cloud/commit/25b6815f121bd919bbe2eefd25cc9222263e60a5))


### Chores

* go live ([6228023](https://github.com/lastmile-ai/mcp-agent-cloud/commit/62280234eb7e5184f0d4aa2a551c7074e8f825e8))
* update SDK settings ([6f04997](https://github.com/lastmile-ai/mcp-agent-cloud/commit/6f049975c23493dbadc096dd9c38b07391343124))
