# test_icoads.py

import pytest

def test_icoads():
   pass
