# __main__.py

from sast_fixer_mcp import main

main()