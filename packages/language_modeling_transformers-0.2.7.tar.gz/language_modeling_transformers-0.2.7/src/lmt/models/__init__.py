"""Implementation of various language model architectures."""

from .config import ModelConfig

__all__ = ['ModelConfig']
