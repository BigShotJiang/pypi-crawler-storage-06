"""wind_up package."""

from importlib.metadata import version

__version__ = version("res-wind-up")
