from .random_color_hex import RandomColorHex

__version__="1.1.2"
__author__="Nathan Honn"
__email__="randomhexman@gmail.com"
__all__=["RandomColorHex", "main"]

main=RandomColorHex.main
Credits=RandomColorHex.Credits
Help=RandomColorHex.Help
