Adds tags to Maintenance Requests
