- Creu Blanca
  - Jaime Arroyo
  - Núria Sancho
  - Kevin Luna
- [Dixmit](www.dixmit.com)
  - Enric Tobella
  