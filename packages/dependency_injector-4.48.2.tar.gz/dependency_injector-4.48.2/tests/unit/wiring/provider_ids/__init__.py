"""Tests for wiring based on provider instance identification."""
