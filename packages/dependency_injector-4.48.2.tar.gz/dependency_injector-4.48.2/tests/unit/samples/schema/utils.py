def return_(instance):
    return instance
