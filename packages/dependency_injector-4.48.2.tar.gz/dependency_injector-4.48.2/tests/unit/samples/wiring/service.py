class Service:
    service_attr: int
