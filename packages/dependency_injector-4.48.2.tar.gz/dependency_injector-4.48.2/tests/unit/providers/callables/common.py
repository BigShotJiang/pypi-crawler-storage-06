"""Common test artifacts."""


def example(arg1, arg2, arg3, arg4):
    return arg1, arg2, arg3, arg4
