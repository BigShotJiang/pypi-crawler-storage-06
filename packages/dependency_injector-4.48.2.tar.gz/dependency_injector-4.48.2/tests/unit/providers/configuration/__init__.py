"""Configuration provider tests."""
