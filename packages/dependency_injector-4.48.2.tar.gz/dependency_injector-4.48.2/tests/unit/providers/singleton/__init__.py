"""Singleton provider tests."""
