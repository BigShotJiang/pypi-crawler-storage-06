"""Top-level package."""

__version__ = "4.48.2"
"""Version number.

:type: str
"""
