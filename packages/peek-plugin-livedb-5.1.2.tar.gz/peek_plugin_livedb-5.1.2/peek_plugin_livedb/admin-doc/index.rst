==============
Administration
==============

LiveDB stores the SCADA + calculated "live" values.

An example use of the LiveDB is driving dynamic updates for the Peek Diagram.

.. toctree::
    :maxdepth: 3
    :caption: Contents:

    overview
    admin_tasks
