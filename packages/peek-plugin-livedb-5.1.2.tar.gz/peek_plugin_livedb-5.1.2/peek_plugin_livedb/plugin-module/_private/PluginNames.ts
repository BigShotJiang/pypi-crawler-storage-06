export let livedbFilt = { plugin: "peek_plugin_livedb" };
export let livedbTuplePrefix = "peek_plugin_livedb.";

export let livedbObservableName = "peek_plugin_livedb";
export let livedbActionProcessorName = "peek_plugin_livedb";
export let livedbTupleOfflineServiceName = "peek_plugin_livedb";

export let livedbBaseUrl = "peek_plugin_livedb";
