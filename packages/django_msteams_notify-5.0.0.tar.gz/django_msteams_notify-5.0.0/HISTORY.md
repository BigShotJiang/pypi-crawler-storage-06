# History

## 1 (2025-09-01)

* First release on PyPI.
