from .file_utils import get_type_from_file

__all__ = [
    "get_type_from_file",
]