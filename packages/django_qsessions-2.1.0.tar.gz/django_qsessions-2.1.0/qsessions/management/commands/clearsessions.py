from django.contrib.sessions.management.commands.clearsessions import Command

__all__ = ("Command",)
