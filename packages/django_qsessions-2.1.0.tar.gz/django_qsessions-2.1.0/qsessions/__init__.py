IP_SESSION_KEY = "_qsessions_ip"
USER_AGENT_SESSION_KEY = "_qsessions_user_agent"
