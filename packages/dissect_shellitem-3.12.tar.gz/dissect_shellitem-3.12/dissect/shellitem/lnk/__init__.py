from dissect.shellitem.lnk.lnk import Lnk, c_lnk

__all__ = ["Lnk", "c_lnk"]
