from __future__ import annotations

from retro_data_structures import cli

if __name__ == "__main__":
    cli.main()
