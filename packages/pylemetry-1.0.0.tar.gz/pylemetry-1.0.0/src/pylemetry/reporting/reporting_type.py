from enum import Enum


class ReportingType(Enum):
    CUMULATIVE = 0
    INTERVAL = 1
