# 3xx 兼容层

from ncatbot.core.event.message_segment import MessageArray as MessageChain
from ncatbot.core.event.message import GroupMessageEvent as GroupMessage
from ncatbot.core.event.message import PrivateMessageEvent as PrivateMessage
from ncatbot.core.event.message import BaseMessageEvent as BaseMessage



