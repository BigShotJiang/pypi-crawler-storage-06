from setuptools import setup, find_packages

setup(
    name="simplematchcalc",
    version="0.1.0",
    description="A simple calculator SDK for add, sub, mul, div, mod",
    author="Your Name",
    packages=find_packages(),
    python_requires=">=3.7",
)
