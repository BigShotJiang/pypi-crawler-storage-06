screening_identifier = "[A-Z0-9]{6,8}"
