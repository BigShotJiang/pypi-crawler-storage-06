# `unxt.dims`

```{eval-rst}

.. currentmodule:: unxt.dims

.. automodule:: unxt.dims

```
