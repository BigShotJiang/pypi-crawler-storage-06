"""
Set of interfaces to deploy and interact with the assistant on Slack, email, Discord and other.
"""
