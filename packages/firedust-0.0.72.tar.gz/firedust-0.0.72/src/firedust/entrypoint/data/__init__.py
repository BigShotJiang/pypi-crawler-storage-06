from firedust._data import embed, safetycheck

__all__ = ["embed", "safetycheck"]
