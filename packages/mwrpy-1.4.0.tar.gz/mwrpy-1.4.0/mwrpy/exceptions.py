class MissingInputData(Exception):
    pass


class InvalidFileError(Exception):
    pass


class MissingCoefficientsError(Exception):
    pass
