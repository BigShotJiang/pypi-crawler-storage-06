from .generate_plots import generate_figure
