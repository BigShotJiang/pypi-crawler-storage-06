from uoapi.timetable import query_timetable
from uoapi.timetable.cli import (
    parser,
    cli,
    available,
    main as py_cli,
    help as cli_help,
    description as cli_description,
    epilog as cli_epilog,
)
