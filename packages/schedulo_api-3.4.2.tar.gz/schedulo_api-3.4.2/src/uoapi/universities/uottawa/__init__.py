"""
University of Ottawa provider implementation.
"""

from .provider import UOttawaProvider

__all__ = ["UOttawaProvider"]
