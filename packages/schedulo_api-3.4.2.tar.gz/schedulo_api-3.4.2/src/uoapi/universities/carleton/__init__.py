"""
Carleton University provider implementation.
"""

from .provider import CarletonProvider

__all__ = ["CarletonProvider"]
