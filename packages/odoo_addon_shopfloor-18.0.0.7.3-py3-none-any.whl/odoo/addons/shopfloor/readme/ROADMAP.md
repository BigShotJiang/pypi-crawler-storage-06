- improve documentation
- split out scenario components to their own modules
- maybe split common stock features to shopfloor_stock_base and move
  scenario to shopfloor_wms?


**WARNING v18**

We don't want to split now the scenario to keep it as much as possible in line w/ v16.
We'll do it later.
