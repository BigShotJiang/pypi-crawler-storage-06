# pySunSpec version
VERSION = '1.1.5'
