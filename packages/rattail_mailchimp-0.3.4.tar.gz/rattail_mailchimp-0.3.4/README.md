
# rattail_mailchimp

Rattail is a retail software framework, released under the GNU General
Public License.

This package contains software interfaces for the
[MailChimp](https://mailchimp.com/) system.

Please see the [Rattail Project](https://rattailproject.org/) for more
information.
