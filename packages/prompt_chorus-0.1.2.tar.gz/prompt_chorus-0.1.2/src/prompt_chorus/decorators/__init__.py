"""
Decorators for Chorus prompt versioning.
"""

from .chorus import chorus

__all__ = [
    "chorus",
]
