## [Thonny](https://thonny.org/) plugin for [Lahendus](https://lahendus.ut.ee/).

### Installation instructions
To install this plugin, please refer to the Thonny [plug-in installation guide](https://github.com/thonny/thonny/wiki/Plugins#plug-ins).

### Availability
You can find this plugin on PyPI at [thonny-lahendus](https://pypi.org/project/thonny-lahendus/).
