from .text import slugify_fa

__all__ = ["slugify_fa"]
