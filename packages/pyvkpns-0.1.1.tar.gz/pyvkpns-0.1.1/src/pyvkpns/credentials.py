VKPNS_LINK='https://vkpns-universal.rustore.ru/v1/send'
HEADERS={"Content-Type": "application/json"}