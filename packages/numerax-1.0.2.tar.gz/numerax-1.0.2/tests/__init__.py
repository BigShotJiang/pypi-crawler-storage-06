"""Test configuration for numerax."""
