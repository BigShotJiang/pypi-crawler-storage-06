# Numerax

::: numerax
    options:
      show_source: false
      heading_level: 1

## Citation

[![DOI](https://zenodo.org/badge/1018495069.svg)](https://zenodo.org/badge/latestdoi/1018495069)

If you use `numerax` in your research, please cite it using the citation information from Zenodo (click the badge above) to ensure you get the correct DOI for the version you used.