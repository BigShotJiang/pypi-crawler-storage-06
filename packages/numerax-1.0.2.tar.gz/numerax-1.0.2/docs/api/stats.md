# Statistics

::: numerax.stats
    options:
      show_source: false
      heading_level: 2
      show_submodules: true