# Special Functions

::: numerax.special
    options:
      show_source: false
      heading_level: 2