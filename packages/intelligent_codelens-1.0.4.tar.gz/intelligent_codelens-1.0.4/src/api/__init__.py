"""
API 服务器模块

提供代码搜索的Web API接口
"""

__version__ = "1.0.0"