from gitlabform import GitLabForm


def run():
    GitLabForm().run()


if __name__ == "__main__":
    run()
