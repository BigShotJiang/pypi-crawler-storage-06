from typing import Protocol, runtime_checkable
from numpy.typing import NDArray
from wslink import register as exportRpc
from wslink.websocket import LinkProtocol


@runtime_checkable
class AbstractWindow(Protocol):
    """
    Protocol defining the interface for interacting with a remote window through RCA.

    Any class matching this interface can be used as a remote window, regardless of inheritance.
    Implementing classes must define the required methods and properties to enable window interaction.
    """

    @property
    def img_cols_rows(self) -> tuple[NDArray, int, int]:
        """
        Returns a tuple containing:
        - the window content as a NumPy array,
        - the number of columns,
        - and the number of rows.

        Called by the scheduler to render the current window view.
        """
        pass

    def process_resize_event(self, width: int, height: int) -> None:
        """
        Handle a resize event for the RCA (RenderWindowInteractor).

        This method is triggered by the adapter whenever the window is resized.
        """
        pass

    def process_interaction_event(self, event: dict) -> None:
        """
        Handle an interaction event from the RCA (RenderWindowInteractor).

        This method is invoked by the adapter whenever an interaction event occurs.
        Refer to the event types defined in:
        https://github.com/Kitware/vtk-js/blob/master/Sources/Rendering/Core/RenderWindowInteractor/index.js
        """
        pass


class AreaAdapter:
    def __init__(self, name):
        self.area_name = name
        self.streamer = None
        self.last_meta = None

    def set_streamer(self, stream_manager):
        self.streamer = stream_manager

    def update_size(self, origin, size):
        width = size.get("w", 300)
        height = size.get("h", 300)
        device_pixel_ratio = size.get("p", 1)
        print(f"{origin}: {width}x{height} - PixelRatio: {device_pixel_ratio}")

    def push(self, content, meta=None):
        if meta is not None:
            self.last_meta = meta
        self.streamer.push_content(self.area_name, self.last_meta, content)

    def on_interaction(self, origin, event):
        event_type = event.get("t", "mouse-down")
        position = event.get("p", (0, 0))
        modifier_shift = event.get("shift", 0)
        modifier_ctrl = event.get("ctrl", 0)
        modifier_alt = event.get("alt", 0)
        modifier_cmd = event.get("cmd", 0)
        modifier_fn = event.get("fn", 0)
        print(f"{origin}::{event_type}: {position}")
        print(
            f"Modifier: shift({modifier_shift}), "
            f"ctrl({modifier_ctrl}), "
            f"alt({modifier_alt}), "
            f"command({modifier_cmd}), "
            f"fn({modifier_fn})"
        )


class StreamManager(LinkProtocol):
    def __init__(self):
        super().__init__()
        self._area_adapters = {}

    def register_area(self, area_adapter):
        self._area_adapters[area_adapter.area_name] = area_adapter
        area_adapter.set_streamer(self)

    def unregister_area(self, area_name):
        adapter = self._area_adapters.pop(area_name)
        adapter.set_streamer(None)

    @exportRpc("trame.rca.size")
    def update_size(self, area_name, origin, size):
        adapter = self._area_adapters.get(area_name, None)
        if adapter:
            adapter.update_size(origin, size)
        else:
            print(f"No area {area_name} available for size")

    @exportRpc("trame.rca.push")
    def push_content(self, area_name, metadata, content):
        self.publish(
            "trame.rca.topic.stream",
            dict(name=area_name, meta=metadata, content=self.addAttachment(content)),
        )

    @exportRpc("trame.rca.event")
    def on_interaction(self, area_name, origin, event):
        adapter = self._area_adapters.get(area_name, None)
        if adapter:
            adapter.on_interaction(origin, event)
        else:
            print(f"No area {area_name} available for event")
