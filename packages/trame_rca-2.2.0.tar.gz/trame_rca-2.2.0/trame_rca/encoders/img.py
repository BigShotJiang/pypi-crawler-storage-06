TO_IMAGE_TYPE = {
    "avif": "image/avif",
    "jpeg": "image/jpeg",
    "turbo-jpeg": "image/jpeg",
    "png": "image/png",
    "webp": "image/webp",
}

TO_IMAGE_FORMAT = {
    "avif": "avif",
    "jpeg": "jpeg",
    "turbo-jpeg": "jpeg",
    "png": "png",
    "webp": "webp",
}
