"""Formatters for DDL statements."""

IF_NOT_EXISTS: str = "IF NOT EXISTS"
IF_EXISTS: str = "IF EXISTS"
