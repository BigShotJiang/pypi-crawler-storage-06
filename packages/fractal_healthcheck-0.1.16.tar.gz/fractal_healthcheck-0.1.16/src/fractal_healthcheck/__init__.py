__VERSION__ = "0.1.16"
LOGGER_NAME = "fractal-health"
