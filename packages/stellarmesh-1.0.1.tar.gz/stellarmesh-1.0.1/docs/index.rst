.. toctree::
   :maxdepth: 1
   :hidden:

   install
   tutorials
   api/index

.. include:: ../README.rst