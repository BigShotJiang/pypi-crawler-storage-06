# -----------------------------------------------------------------------------
# Hapsolutely - Reconstruct haplotypes and produce genealogy graphs
# Copyright (C) 2023  Patmanidis Stefanos
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
# -----------------------------------------------------------------------------

from PySide6 import QtCore, QtGui, QtWidgets

from itaxotools.blastax import resources
from itaxotools.common.utility import AttrDict
from itaxotools.common.widgets import VLineSeparator
from itaxotools.taxi_gui.view.cards import Card
from itaxotools.taxi_gui.view.tasks import ScrollTaskView

from . import blast_url, homepage_url, itaxotools_url, pixmap_medium, title


class HtmlLabel(QtWidgets.QLabel):
    def __init__(self, text):
        super().__init__(text)

        self.setTextFormat(QtCore.Qt.RichText)
        self.setOpenExternalLinks(True)
        self.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse | QtCore.Qt.LinksAccessibleByMouse)
        self.setWordWrap(True)

        # fix italics kerning
        font = self.font()
        font.setHintingPreference(QtGui.QFont.HintingPreference.PreferNoHinting)
        self.setFont(font)


class AboutTitleCard(Card):
    def __init__(self, title, description, pixmap, parent=None):
        super().__init__(parent)

        label_title = QtWidgets.QLabel(title)
        font = label_title.font()
        font.setPixelSize(18)
        font.setBold(True)
        font.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 1)
        label_title.setFont(font)

        label_description = HtmlLabel(description)

        separator = VLineSeparator(1)

        homepage = QtWidgets.QPushButton("Homepage")
        itaxotools = QtWidgets.QPushButton("iTaxoTools")
        blast = QtWidgets.QPushButton("BLAST")
        homepage.setFixedWidth(120)

        label_pixmap = QtWidgets.QLabel()
        label_pixmap.setPixmap(pixmap)
        label_pixmap.setFixedSize(pixmap.size())

        text_layout = QtWidgets.QVBoxLayout()
        text_layout.setContentsMargins(0, 10, 0, 8)
        text_layout.addWidget(label_title)
        text_layout.addWidget(label_description, 1)
        text_layout.setSpacing(8)

        pixmap_layout = QtWidgets.QVBoxLayout()
        pixmap_layout.setContentsMargins(0, 8, 0, 4)
        pixmap_layout.addWidget(label_pixmap)
        pixmap_layout.addStretch(1)

        buttons = QtWidgets.QVBoxLayout()
        buttons.setContentsMargins(0, 10, 0, 4)
        buttons.setSpacing(8)
        buttons.addWidget(homepage)
        buttons.addWidget(itaxotools)
        buttons.addWidget(blast)
        buttons.addStretch(1)

        layout = QtWidgets.QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)
        layout.addLayout(pixmap_layout)
        layout.addLayout(text_layout, 1)
        layout.addSpacing(64)
        layout.addWidget(separator, 0)
        layout.addLayout(buttons)

        self.addLayout(layout)

        homepage.clicked.connect(self.openHomepage)
        itaxotools.clicked.connect(self.openItaxotools)
        blast.clicked.connect(self.openBlast)

        self.controls.title = label_title
        self.controls.description = label_description
        self.controls.pixmap = label_pixmap

    def openHomepage(self):
        QtGui.QDesktopServices.openUrl(homepage_url)

    def openItaxotools(self):
        QtGui.QDesktopServices.openUrl(itaxotools_url)

    def openBlast(self):
        QtGui.QDesktopServices.openUrl(blast_url)


class DocumentCard(Card):
    def __init__(self, title, description, parent=None):
        super().__init__(parent)

        label_title = QtWidgets.QLabel(title)
        font = label_title.font()
        font.setPixelSize(16)
        font.setBold(True)
        font.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 1)
        label_title.setFont(font)

        label_description = HtmlLabel(description)

        self.controls.title = label_title

        layout = QtWidgets.QVBoxLayout()
        layout.setContentsMargins(8, 12, 64, 12)
        layout.addWidget(label_title)
        layout.addWidget(label_description)
        layout.setSpacing(16)
        self.addLayout(layout)

    def set_title(self, text: str):
        self.controls.title.setText(text)


class View(ScrollTaskView):
    def __init__(self, parent):
        super().__init__(parent)
        self.draw_cards()

    def draw_cards(self):
        self.cards = AttrDict()
        self.cards.title = AboutTitleCard(title, resources.documents.about.resource, pixmap_medium.resource, self)
        self.cards.blast = DocumentCard("About BLAST+ (???)", resources.documents.blast.resource, self)
        self.cards.cutadapt = DocumentCard("About Cutadapt (???)", resources.documents.cutadapt.resource, self)
        self.cards.museo = DocumentCard("About Museoscript", resources.documents.museo.resource, self)
        self.cards.mafft = DocumentCard("About MAFFT", resources.documents.mafft.resource, self)
        layout = QtWidgets.QVBoxLayout()
        for card in self.cards:
            layout.addWidget(card)
        layout.addStretch(1)
        layout.setSpacing(6)
        layout.setContentsMargins(6, 6, 6, 6)

        self.setLayout(layout)

    def setObject(self, object):
        self.object = object
        self.binder.unbind_all()
        self.binder.bind(object.notification, self.showNotification)
        self.binder.bind(object.properties.cutadapt_version, self._update_cutadapt_version)
        self.binder.bind(object.properties.blast_version, self._update_blast_version)

    def _update_blast_version(self, version: str):
        self.cards.blast.set_title(f"About BLAST+ ({version})")

    def _update_cutadapt_version(self, version: str):
        self.cards.cutadapt.set_title(f"About Cutadapt ({version})")
