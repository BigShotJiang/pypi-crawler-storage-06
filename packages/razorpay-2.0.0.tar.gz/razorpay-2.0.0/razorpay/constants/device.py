class DeviceMode:
    WIRED = "wired"
    WIRELESS = "wireless" 