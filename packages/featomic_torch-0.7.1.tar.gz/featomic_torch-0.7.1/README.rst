featomic-torch
===============

This package contains the TorchScript bindings to featomic.
