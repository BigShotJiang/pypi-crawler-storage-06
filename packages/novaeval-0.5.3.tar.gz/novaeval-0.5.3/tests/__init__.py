"""
Test suite for NovaEval.

This package contains unit and integration tests for the NovaEval framework.
"""
