"""Make the CLI runnable using python -m aiohomeconnect."""

from .cli import cli

cli(prog_name="aiohomeconnect")
