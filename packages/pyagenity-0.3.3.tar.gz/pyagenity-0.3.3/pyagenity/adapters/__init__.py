"""Integration adapters for optional third-party SDKs."""
