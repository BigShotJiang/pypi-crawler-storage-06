# Copyright (c) 1994 Adam Karpierz
# SPDX-License-Identifier: Zlib

import sys
import os
import platform

__all__ = (
    'is_windows', 'is_wsl', 'is_cygwin', 'is_msys', 'is_linux', 'is_macos',
    'is_bsd', 'is_sunos', 'is_aix', 'is_android', 'is_posix', 'is_32bits',
    'is_ucs2', 'is_cpython', 'is_pypy', 'is_ironpython',
)

is_windows = (bool(platform.win32_ver()[0])
              or (sys.platform in ("win32", "cygwin", "msys"))
              or (sys.platform == "cli" and os.name in ("nt", "ce"))
              or (os.name == "java"
                  and "windows" in platform.java_ver()[3][0].lower()))
is_wsl     = ("microsoft-standard" in platform.uname().release)
is_cygwin  = (sys.platform == "cygwin")
is_msys    = (sys.platform == "msys")
is_linux   = sys.platform.startswith("linux")
is_macos   = sys.platform.startswith("darwin")
is_bsd     = sys.platform.startswith(("freebsd", "openbsd", "netbsd"))
is_sunos   = sys.platform.startswith(("sunos", "solaris"))
is_aix     = sys.platform.startswith("aix")
is_android = hasattr(sys, "getandroidapilevel")
is_posix   = (os.name == "posix")
is_32bits  = (sys.maxsize <= 2**32)
is_ucs2    = (sys.maxunicode < 0x10FFFF)
is_cpython = (platform.python_implementation().lower() == "cpython")
is_pypy    = (platform.python_implementation().lower() == "pypy")
is_ironpython = (platform.python_implementation().lower() == "ironpython"
                 or "cli" in (platform.system().lower(), sys.platform))

del sys, os, platform
