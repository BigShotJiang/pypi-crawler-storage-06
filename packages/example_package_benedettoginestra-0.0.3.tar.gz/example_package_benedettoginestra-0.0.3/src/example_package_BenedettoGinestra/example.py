import os


def add(a, b):
    return a + b

def __main__():
    print("Current working dir is", os.getcwd())

if __name__ == "__main__":
    __main__()
