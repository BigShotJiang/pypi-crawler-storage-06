# Dataimport_AICARE

Submodule for frequently used data loading and preprocessing methods inside of the AI-CARE project.

To include it in your project use ```pip install dataimport-aicare```.
