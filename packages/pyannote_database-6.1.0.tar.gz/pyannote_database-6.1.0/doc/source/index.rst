.. pyannote.core documentation master file, created by
   sphinx-quickstart on Thu Jan 19 13:25:34 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

#################
pyannote.database
#################

`pyannote.database` is an open-source Python library that provides a common interface to multimedia databases and associated experimental protocol.

Installation
============

::

$ pip install pyannote.database


API documentation
=================

.. toctree::
   :maxdepth: 2

   changelog
