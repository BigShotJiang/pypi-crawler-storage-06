pycvcam.compute_rays
=================================


.. autofunction:: pycvcam.compute_rays