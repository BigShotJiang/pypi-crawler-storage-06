from portion.portion import Portion


if __name__ == "__main__":
    Portion().run()
