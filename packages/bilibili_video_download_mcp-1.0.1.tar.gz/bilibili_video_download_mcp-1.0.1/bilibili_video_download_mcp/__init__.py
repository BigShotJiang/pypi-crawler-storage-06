"""Video Download MCP Server - A universal video downloader using you-get."""

__version__ = "1.0.0"
