# -*- coding: utf-8 -*-
# vim:fenc=utf-8

"""
Import the pages.
"""

import meerschaum.api.dash.pages.error
import meerschaum.api.dash.pages.login
import meerschaum.api.dash.pages.dashboard
import meerschaum.api.dash.pages.plugins
import meerschaum.api.dash.pages.tokens
import meerschaum.api.dash.pages.register
import meerschaum.api.dash.pages.pipes
import meerschaum.api.dash.pages.jobs
import meerschaum.api.dash.pages.settings
