class GeoDB:
    db_type = "geo"


class GraphDB:
    db_type = "graph"


class KVDB:
    db_type = "kv"


class NoSQLDB:
    db_type = "nosql"


class RelationalDB:
    db_type = "relational"


class TimeSeriesDB:
    db_type = "time_series"


class VectorDB:
    db_type = "vector"
