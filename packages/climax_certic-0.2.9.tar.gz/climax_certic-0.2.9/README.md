# CLIMAX

Climax est un utilitaire en ligne de commande pour la gestion des projets [MaX v2](https://www.certic.unicaen.fr/max-v2/).

Pour la documentation utilisateur, voir https://www.certic.unicaen.fr/max-v2/climax/

Pour les développeurs, voir le [Makefile](https://git.unicaen.fr/pdn-certic/climax/-/blob/main/Makefile?ref_type=heads) 
(pré-requis: [uv](https://docs.astral.sh/uv/) et [gettext](https://www.gnu.org/software/gettext/) / msgfmt).