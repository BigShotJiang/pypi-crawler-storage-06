from climax.__main__ import wrap_app_exceptions

if __name__ == "__main__":
    wrap_app_exceptions()
