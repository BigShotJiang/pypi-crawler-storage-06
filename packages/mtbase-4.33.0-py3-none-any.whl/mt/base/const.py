'''Some useful constants.'''

__all__ = ['ansi_ul']

# useful ansi sequences. Needs colorama initialised.
ansi_ul = '\033[F' # move up one line and at the beginning
