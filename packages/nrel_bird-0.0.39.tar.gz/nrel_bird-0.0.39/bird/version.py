"""Bio reactor design version"""

__version__ = "0.0.39"
