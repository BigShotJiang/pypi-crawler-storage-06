# -*- coding: utf-8; -*-

# TODO: add real tests at some point but this at least gives us basic
# coverage when running this "test" module alone

from tailbone import db

