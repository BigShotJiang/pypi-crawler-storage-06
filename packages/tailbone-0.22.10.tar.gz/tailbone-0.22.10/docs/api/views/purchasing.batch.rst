
``tailbone.views.purchasing.batch``
===================================

.. automodule:: tailbone.views.purchasing.batch

.. autoclass:: PurchasingBatchView

   .. automethod:: save_edit_row_form
