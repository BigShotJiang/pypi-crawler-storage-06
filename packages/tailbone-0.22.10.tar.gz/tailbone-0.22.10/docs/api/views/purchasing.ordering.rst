
``tailbone.views.purchasing.ordering``
======================================

.. automodule:: tailbone.views.purchasing.ordering

.. autoclass:: OrderingBatchView

   .. autoattribute:: model_class

   .. autoattribute:: default_handler_spec

   .. automethod:: configure_row_form

   .. automethod:: worksheet_update
