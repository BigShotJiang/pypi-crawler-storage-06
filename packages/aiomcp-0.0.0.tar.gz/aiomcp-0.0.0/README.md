# aiomcp
A Simple Python MCP Solution
