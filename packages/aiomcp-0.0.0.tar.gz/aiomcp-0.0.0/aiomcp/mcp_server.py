class McpServer:
    pass