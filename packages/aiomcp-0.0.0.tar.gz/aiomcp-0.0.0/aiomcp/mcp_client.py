class McpClient:
    pass