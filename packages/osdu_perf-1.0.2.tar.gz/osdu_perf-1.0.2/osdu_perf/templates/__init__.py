# osdu_perf/templates/__init__.py
"""Templates for OSDU Performance Testing Framework"""
