# -*- coding: utf-8 -*-

from importlib_metadata import version

from .config import _config

__version__ = version(__package__)
