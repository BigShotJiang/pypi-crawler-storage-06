# GPUBackendTools: Backend tools for GPU/CPU agnostic codes.


## Getting Started


### Prerequisites


### Installing


## Running the Tests


## Versioning

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/mikekatz04/GPUBackendTools/tags).

Current Version: 0.0.1

## Authors

* Michael Katz
* Maxime Pigou
* Mathieu Dubois

## Contributors


## License

This project is licensed under the Apache License - see the [LICENSE](https://github.com/mikekatz04/GPUBackendTools/blob/master/LICENSE) file for details.
