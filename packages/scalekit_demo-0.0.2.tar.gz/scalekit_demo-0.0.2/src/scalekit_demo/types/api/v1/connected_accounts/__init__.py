# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .magic_link_create_params import MagicLinkCreateParams as MagicLinkCreateParams
from .magic_link_create_response import MagicLinkCreateResponse as MagicLinkCreateResponse
from .magic_link_redirect_params import MagicLinkRedirectParams as MagicLinkRedirectParams
from .magic_link_redirect_response import MagicLinkRedirectResponse as MagicLinkRedirectResponse
