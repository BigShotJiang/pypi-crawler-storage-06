# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["StaticAuthConfigParam"]


class StaticAuthConfigParam(TypedDict, total=False):
    static_config: object
