# Changelog

## 0.0.2 (2025-09-20)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/saif-at-scalekit/scalekit-demo-python/compare/v0.0.1...v0.0.2)

### Chores

* update SDK settings ([0be4d97](https://github.com/saif-at-scalekit/scalekit-demo-python/commit/0be4d97b6d598844d542f303bd171c5ae51f48d1))
* update SDK settings ([9020161](https://github.com/saif-at-scalekit/scalekit-demo-python/commit/902016190642e563a6b0c9139291d5e39ae2b44d))
