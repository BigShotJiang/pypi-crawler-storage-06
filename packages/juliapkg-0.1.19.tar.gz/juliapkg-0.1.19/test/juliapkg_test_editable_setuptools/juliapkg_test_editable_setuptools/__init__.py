"""Test package for editable installs with juliapkg.json."""

__version__ = "0.1.0"
