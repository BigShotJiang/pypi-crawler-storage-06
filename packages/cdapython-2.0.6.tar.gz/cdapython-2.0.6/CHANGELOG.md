2025-09-17: 2.0.6: update ternary numeric comparison handling for latest API ternary operator syntax support

2025-08-18: 2.0.2: update PyYAML build dependency

2025-08-18: 2.0.1: update default API URL

2025-08-18: 2.0.0: initial public release to PyPI
