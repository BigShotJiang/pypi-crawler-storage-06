"""Installation instructions for local, editable installs"""
import setuptools

if __name__ == "__main__":
    setuptools.setup()
