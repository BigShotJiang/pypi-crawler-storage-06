"""
Admin configuration for Leads app.
"""

from .leads_admin import LeadAdmin

__all__ = [
    'LeadAdmin',
]
