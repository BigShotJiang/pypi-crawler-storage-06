from .keyboard_generator import keyboard_gen

__all__ = ("keyboard_gen",)
