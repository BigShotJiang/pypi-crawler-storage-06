from .swear_handler import swear

__all__ = ("swear",)
