
class PermissionDenied(Exception):
    pass
