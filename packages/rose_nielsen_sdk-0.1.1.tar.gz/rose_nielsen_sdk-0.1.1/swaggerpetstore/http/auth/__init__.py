__all__ = [
    'api_key',
    'http_basic',
    'petstore_auth',
]
