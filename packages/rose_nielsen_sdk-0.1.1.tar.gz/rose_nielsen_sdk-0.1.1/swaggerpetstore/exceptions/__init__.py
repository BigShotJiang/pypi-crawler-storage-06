__all__ = [
    'api_exception',
    'o_auth_provider_exception',
]
