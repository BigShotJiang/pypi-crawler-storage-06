It is important to note that the "brand use level" **should** be set to `Optional` or `Required`.
The brand use level is configured in the Users & Companies settings.
By default it is set to 'Do not use brands on business document'.
Then the field to select a brand on the invoice view will not be available.

To change the "brand use level":

#. Go to Settings > General Settings
#. Select the brand use level, the following options are available:
  `Do not use brands on business document` (Default)
  `Optional`
  `Required`
