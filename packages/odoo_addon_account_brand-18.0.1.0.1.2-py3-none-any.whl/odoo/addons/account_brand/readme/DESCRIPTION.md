This module allows you to send branded invoices to your customers. It
adds a brand field on the invoice and the brand information to the PDF
report.
