To use this module, you need to:

1.  Go to Accounting \> Customers \> Invoices
2.  Select or create an invoice
3.  Enter the information and select the brand
4.  Print the PDF report. It includes the style and information of the brand.

To do point 4, the [Brand External Report Layout](https://github.com/OCA/brand/tree/18.0/brand_external_report_layout/README.rst) OCA module must be installed.
