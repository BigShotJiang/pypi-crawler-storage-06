# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

# SPDX-FileCopyrightText: Microsoft Corporation
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"
