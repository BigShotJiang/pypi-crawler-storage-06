# tacotoolbox

A prototype implementation of the TACO Toolbox API specification.

Status: Work in progress. Currently migrating to v2.0 specification.

Legacy Support: Version 1.0 remains available in `tacotoolbox.v1` subpackage.

