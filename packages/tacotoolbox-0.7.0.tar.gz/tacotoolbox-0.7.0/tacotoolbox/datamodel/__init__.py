from tacotoolbox.sample.datamodel import Sample
from tacotoolbox.tortilla.datamodel import Tortilla  
from tacotoolbox.taco.datamodel import Taco


from tacotoolbox.datamodel import sample
from tacotoolbox.datamodel import tortilla
from tacotoolbox.datamodel import taco



__all__ = ['Sample', 'sample', 'Tortilla', 'tortilla', 'Taco', 'taco']