"""kedro-graphql
"""
__version__ = "1.2.0"
