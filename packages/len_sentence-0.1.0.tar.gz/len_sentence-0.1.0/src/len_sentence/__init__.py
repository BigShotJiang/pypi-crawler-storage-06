from .count import count_sentence

__all__ = ["count_sentence"]