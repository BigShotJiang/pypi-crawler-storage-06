from pydantic import BaseModel


class BaseResponseModel(BaseModel):
    pass
