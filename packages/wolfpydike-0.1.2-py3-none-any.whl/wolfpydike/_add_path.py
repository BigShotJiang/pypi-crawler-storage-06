import os
import sys

_root_dir = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0,os.path.join(_root_dir,'..'))