# quil-py

⚠️ In Development

This crate exposes [`pyo3`](https://github.com/PyO3/pyo3) bindings for [`quil-rs`](https://github.com/rigetti/quil-rs) allowing them to be extended or used in other `pyo3` based Python packages.

This package is still in early development and breaking changes should be expected between minor versions.
