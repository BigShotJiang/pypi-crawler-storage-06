"""The `quil.instructions` module contains classes for representing Quil instructions."""

from quil.instructions import *
