"""Templates for generating discrete IQ value sequences representing Quil's defined set of waveforms."""

from quil.waveforms import *
