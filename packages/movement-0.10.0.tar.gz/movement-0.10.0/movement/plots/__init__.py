"""Plotting utilities for ``movement`` datasets."""

from movement.plots.occupancy import plot_occupancy
from movement.plots.trajectory import plot_centroid_trajectory

__all__ = ["plot_occupancy", "plot_centroid_trajectory"]
