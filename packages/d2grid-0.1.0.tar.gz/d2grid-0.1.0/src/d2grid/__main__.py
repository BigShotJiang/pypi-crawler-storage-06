from d2grid.main import main

main()