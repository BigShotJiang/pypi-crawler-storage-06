#!/usr/bin/env python
# -*- coding: utf-8 -*-
# License: MIT License
# Copyright 2024 InOrbit, Inc.

__author__ = "InOrbit, Inc."
__version__ = "1.3.1"
