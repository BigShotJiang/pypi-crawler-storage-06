# pybag

A Python library to work with bag files without ROS.

> [!Warning]
> The library is still in the early stages of development and the API is still unstable
