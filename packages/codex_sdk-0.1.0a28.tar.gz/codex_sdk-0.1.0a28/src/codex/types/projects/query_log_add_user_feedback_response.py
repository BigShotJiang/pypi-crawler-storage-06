# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["QueryLogAddUserFeedbackResponse"]


class QueryLogAddUserFeedbackResponse(BaseModel):
    custom_metadata: object

    query_log_id: str
