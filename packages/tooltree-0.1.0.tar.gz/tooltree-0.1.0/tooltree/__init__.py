"""functions for creating treemap data visualizations"""

__version__ = '0.1.0'


from .output import plot_treemap
