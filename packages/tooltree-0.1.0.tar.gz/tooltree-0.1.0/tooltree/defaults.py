from __future__ import annotations


default_colors = [
    'limegreen',
    'dodgerblue',
    'orange',
    'paleturquoise',
    '#AF6E4D',
    'mediumslateblue',
    'gold',
    'teal',
    'grey',
    '#E86100',
    '#F2C1D1',
]

default_height = 700
