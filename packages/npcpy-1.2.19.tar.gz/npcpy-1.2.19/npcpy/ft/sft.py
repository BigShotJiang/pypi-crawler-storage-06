# structured fine tuning of LLMs to produce structured output
