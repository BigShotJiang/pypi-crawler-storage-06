"""ClipDrop - Save clipboard content (text and images) to files with smart format detection."""

__version__ = "1.5"
