from prometeo import exceptions


class CurpError(exceptions.PrometeoError):
    pass
