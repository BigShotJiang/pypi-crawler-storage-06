from prometeo import exceptions


class BankingClientError(exceptions.PrometeoError):
    pass
