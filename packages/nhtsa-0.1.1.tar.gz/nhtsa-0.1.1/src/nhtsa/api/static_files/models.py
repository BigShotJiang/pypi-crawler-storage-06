# src/NHTSA/api/static_files/models.py
# No specific Pydantic models needed for this API yet, as it primarily deals with raw file downloads.
# If metadata parsing from, e.g., PDF content were required, models would be defined here.