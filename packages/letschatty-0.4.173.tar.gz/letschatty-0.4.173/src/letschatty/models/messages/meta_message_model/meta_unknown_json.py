# Clase para manejar JSON desconocidos
from .meta_base_notification_json import BaseMetaNotificationJson

class MetaUnknownJson(BaseMetaNotificationJson):
    pass