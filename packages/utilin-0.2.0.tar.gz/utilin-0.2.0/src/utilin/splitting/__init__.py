from .splits import assign_modulo_folds, assign_contiguous_folds, assign_random_folds

__all__ = ["assign_random_folds", "assign_contiguous_folds", "assign_modulo_folds"]
