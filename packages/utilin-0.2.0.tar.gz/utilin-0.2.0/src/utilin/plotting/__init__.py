from .prediction import plot_correlation_scatter

__all__ = ["plot_correlation_scatter"]
