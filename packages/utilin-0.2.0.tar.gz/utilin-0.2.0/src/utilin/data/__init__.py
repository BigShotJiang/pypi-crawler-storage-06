from .mega_scale_folding_stability import MegaScaleProteinFoldingStability
from .proteingym import ProteinGym

__all__ = ["MegaScaleProteinFoldingStability", "ProteinGym"]
