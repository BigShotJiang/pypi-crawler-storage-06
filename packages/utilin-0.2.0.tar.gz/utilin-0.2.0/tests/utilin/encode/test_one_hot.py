import numpy as np
import pandas as pd

from utilin.encode.one_hot import encode_sequences_one_hot


def test_encode_sequences_one_hot_default():
    sequences = ["ACD", "GHK"]
    expected_output = np.array(
        [
            [
                [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ],
            [
                [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ],
        ]
    )
    output = encode_sequences_one_hot(sequences)
    assert np.array_equal(output, expected_output)


def test_encode_sequences_one_hot_gremlin():
    sequences = ["A-", "CY"]
    expected_output = np.array(
        [
            [
                [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            ],
            [
                [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
            ],
        ]
    )
    output = encode_sequences_one_hot(sequences, aa_alphabet="gremlin")
    assert np.array_equal(output, expected_output)


def test_encode_empty_sequences():
    sequences = []
    expected_output = np.array([])
    output = encode_sequences_one_hot(sequences)
    assert np.array_equal(output, expected_output)


def test_encode_pandas_sequences_one_hot():
    sequences = pd.Series(["AC"])
    expected_output = np.array(
        [
            [
                [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ]
        ]
    )
    output = encode_sequences_one_hot(sequences)
    assert np.array_equal(output, expected_output)
