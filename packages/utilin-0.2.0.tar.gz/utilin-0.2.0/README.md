![setup and test workflow](https://github.com/florisvdf/utilin/actions/workflows/setup-and-test.yml/badge.svg)

# Utilin
A small utility package for tasks in protein engineering.
