from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('django_msteams_notify', '0001_initial'),
    ]

    operations = [
    ]
