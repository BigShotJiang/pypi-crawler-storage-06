#from .exemplo import cumprimentar

def cumprimentar(nome):
    return f"Olá, {nome}! Bem-vindo à UFCD 10794."