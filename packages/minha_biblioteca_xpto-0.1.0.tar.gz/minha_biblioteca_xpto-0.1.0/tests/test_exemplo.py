from minha_biblioteca import cumprimentar

def test_cumprimentar():
    assert cumprimentar("Susana") == "Olá, Susana! Bem-vindo à UFCD 10794."

