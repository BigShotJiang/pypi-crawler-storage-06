.. _api_grab_task:

.. module:: grab.spider.task

Module grab.spider.task
================

.. autoclass:: Task
   :members:

   .. automethod:: __init__