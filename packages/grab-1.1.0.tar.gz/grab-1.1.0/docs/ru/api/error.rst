.. _api_error:

=============================
grab.error: классы исключений
=============================

.. module:: grab.error

.. autoclass:: GrabError
.. autoclass:: GrabNetworkError
.. autoclass:: GrabTimeoutError
.. autoclass:: GrabMisuseError
.. autoclass:: DataNotFound
