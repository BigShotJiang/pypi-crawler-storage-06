"""FastAPI的app实例"""
from fastapi import FastAPI

app = FastAPI()
