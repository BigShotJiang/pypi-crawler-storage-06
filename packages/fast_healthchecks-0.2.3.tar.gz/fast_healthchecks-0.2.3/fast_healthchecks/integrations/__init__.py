"""Module for integrations with external frameworks."""
