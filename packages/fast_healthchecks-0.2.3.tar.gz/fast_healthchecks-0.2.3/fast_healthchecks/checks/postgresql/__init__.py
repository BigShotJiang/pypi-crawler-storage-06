"""Module for PostgreSQL health checks."""
