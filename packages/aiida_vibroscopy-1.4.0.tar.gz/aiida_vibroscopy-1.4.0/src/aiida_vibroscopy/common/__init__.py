# -*- coding: utf-8 -*-
"""Common utilities for vibrational properties."""
from .constants import DEFAULT as UNITS

__all__ = ('UNITS',)
