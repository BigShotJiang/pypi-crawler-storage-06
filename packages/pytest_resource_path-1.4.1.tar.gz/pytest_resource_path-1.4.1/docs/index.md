# Welcome to pytest-resource-path

Provides path for uniform access to test resources in isolated directory
