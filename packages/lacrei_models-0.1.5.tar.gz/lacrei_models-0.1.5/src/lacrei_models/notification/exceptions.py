class SMSError(Exception):
    pass
