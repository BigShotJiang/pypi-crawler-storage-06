# What packages are required for this module to be executed?
REQUIRED = [
	"click>=8.1.3", "inquirer>=3.4.0", "pyyaml", "pytest", "pudb", "urwid>=2.6.16"
]

from setuptools import setup

setup()