# These version placeholders will be replaced later during substitution.
__version__ = "1.5.10"
__version_tuple__ = (1, 5, 10)
