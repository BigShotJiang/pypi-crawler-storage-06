from openg2p_g2pconnect_common_lib.errors.base_error import ErrorResponse


def test_schema():
    ErrorResponse()
