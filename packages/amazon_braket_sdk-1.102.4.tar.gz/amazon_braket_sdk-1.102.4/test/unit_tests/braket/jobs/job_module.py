def some_helper():
    return "success"
