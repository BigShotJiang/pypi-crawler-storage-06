# src/playbook/cli/interaction/__init__.py
"""CLI interaction handling."""
