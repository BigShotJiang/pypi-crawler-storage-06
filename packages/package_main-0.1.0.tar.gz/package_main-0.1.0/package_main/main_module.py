def main_module_func():
    print("main_module_func")
