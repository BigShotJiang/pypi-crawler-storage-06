pytest_plugins = ("pytest_jupyter.jupyter_server", )
