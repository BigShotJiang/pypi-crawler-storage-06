import { Typography } from '@material-tailwind/react';
import { type ColumnDef } from '@tanstack/react-table';

import { useZoneAndFspMapContext } from '@/contexts/ZonesAndFspMapContext';
import { usePreferencesContext } from '@/contexts/PreferencesContext';
import type { Ticket } from '@/contexts/TicketsContext';
import {
  formatDateString,
  getPreferredPathForDisplay,
  makeBrowseLink,
  makeMapKey
} from '@/utils';
import { FileSharePath } from '@/shared.types';
import { FgStyledLink } from '../widgets/FgLink';

function FilePathCell({ item }: { item: Ticket }) {
  const { zonesAndFileSharePathsMap } = useZoneAndFspMapContext();
  const { pathPreference } = usePreferencesContext();

  const itemFsp = zonesAndFileSharePathsMap[
    makeMapKey('fsp', item.fsp_name)
  ] as FileSharePath;
  const displayPath = getPreferredPathForDisplay(
    pathPreference,
    itemFsp,
    item.path
  );

  return (
    <div className="line-clamp-2 max-w-full">
      <FgStyledLink to={makeBrowseLink(item.fsp_name, item.path)}>
        {displayPath}
      </FgStyledLink>
    </div>
  );
}

function StatusCell({ status }: { status: string }) {
  return (
    <div className="text-sm">
      <span
        className={`px-2 py-1 rounded-full text-xs ${
          status === 'Open'
            ? 'bg-blue-200 text-blue-800'
            : status === 'Pending'
              ? 'bg-yellow-200 text-yellow-800'
              : status === 'Work in progress'
                ? 'bg-purple-200 text-purple-800'
                : status === 'Done'
                  ? 'bg-green-200 text-green-800'
                  : 'bg-gray-200 text-gray-800'
        }`}
      >
        {status}
      </span>
    </div>
  );
}

export const jobsColumns: ColumnDef<Ticket>[] = [
  {
    accessorKey: 'path',
    header: 'File Path',
    cell: ({ cell, row }) => <FilePathCell item={row.original} key={cell.id} />,
    enableSorting: true
  },
  {
    accessorKey: 'description',
    header: 'Job Description',
    cell: ({ cell, getValue }) => (
      <Typography
        className="line-clamp-2 text-foreground max-w-full"
        key={cell.id}
      >
        {getValue() as string}
      </Typography>
    )
  },
  {
    accessorKey: 'status',
    header: 'Status',
    cell: ({ cell, getValue }) => (
      <StatusCell status={getValue() as string} key={cell.id} />
    ),
    enableSorting: true
  },
  {
    accessorKey: 'updated',
    header: 'Last Updated',
    cell: ({ cell, getValue }) => (
      <div className="text-sm text-foreground-muted" key={cell.id}>
        {formatDateString(getValue() as string)}
      </div>
    ),
    enableSorting: true
  }
];
