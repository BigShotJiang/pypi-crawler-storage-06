class SAMLRequestNotFound(Exception):
    pass


class SAMLRequestValueNotFound(Exception):
    pass
