from setuptools import setup

setup()  # Editable installs.
