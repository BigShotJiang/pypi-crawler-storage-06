"""
Plugins that contains non-core functionalities for lihil,
mostly simple wrappers to third-party dependencies.
if not, likely to be a standalone lib
"""

from lihil.plugins.interface import IEndpointInfo as IEndpointInfo
from lihil.plugins.interface import IPlugin as IPlugin
