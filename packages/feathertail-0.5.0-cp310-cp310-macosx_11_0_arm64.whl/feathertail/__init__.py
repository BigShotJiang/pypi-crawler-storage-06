from .feathertail import *

__doc__ = feathertail.__doc__
if hasattr(feathertail, "__all__"):
    __all__ = feathertail.__all__