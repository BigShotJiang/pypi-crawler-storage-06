# Lymia

Make a simple curses app with this easy to use wrapper.

> [!NOTE]
> This one's in an alpha stage.

## Availability

Linux, Mac (???), Windows with curses

## Dependency

`curses` (Check your Python if it has curses or not)

## Features

1. Stack-based Scenes
2. Easy to use Panels
3. Menus
4. Forms
5. Animations
6. Coloring guides
7. Several cool utility tools

### Issues & Contribution

TBA
