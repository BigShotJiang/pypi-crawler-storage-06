"""Setup for sqlite_database"""
from setuptools import setup

setup(name='lymia')
