"""Errors"""

class RenderError(Exception):
    """Cannot render"""
