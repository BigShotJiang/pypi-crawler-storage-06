__version__ = "1.0.1"
from ._widget import DataInspectionWidget

__all__ = ("DataInspectionWidget",)
