.. _api_index:

API Documentation
==================

run_dbcan Command Line Interface
--------------------------------

.. click:: dbcan.main:cli
   :prog: run_dbcan
   :nested: full
