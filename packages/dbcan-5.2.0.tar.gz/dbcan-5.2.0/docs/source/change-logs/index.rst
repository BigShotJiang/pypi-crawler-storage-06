.. _change-logs:

Change Logs
===========

Version 5.x
-----------

.. include:: /change-logs/5.0.2.rst




Version 4.x
-----------

.. include:: /change-logs/4.2.0.rst
.. include:: /change-logs/4.0.0.rst

Version 3.x
-----------

.. include:: /change-logs/3.0.7.rst
.. include:: /change-logs/3.0.6.rst
.. include:: /change-logs/3.0.5.rst
.. include:: /change-logs/3.0.4.rst
.. include:: /change-logs/3.0.2.rst

Version 2.x
-----------

.. include:: /change-logs/2.0.11.rst
.. include:: /change-logs/2.0.6.rst
