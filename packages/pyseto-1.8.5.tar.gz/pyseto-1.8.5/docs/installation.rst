Installation
============

You can install PySETO with pip:

.. code-block:: console

    $ pip install pyseto
