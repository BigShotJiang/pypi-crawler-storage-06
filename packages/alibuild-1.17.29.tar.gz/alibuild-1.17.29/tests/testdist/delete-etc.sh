package: delete-etc
version: "1"
---
rm -rf "$INSTALLROOT/etc"
