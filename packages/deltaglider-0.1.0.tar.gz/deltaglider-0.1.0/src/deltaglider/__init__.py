"""DeltaGlider - Delta-aware S3 file storage wrapper."""

__version__ = "0.1.0"
