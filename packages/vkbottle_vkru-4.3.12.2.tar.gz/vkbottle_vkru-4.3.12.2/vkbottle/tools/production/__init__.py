from .legacies import keyboard_gen

__all__ = ("keyboard_gen",)
