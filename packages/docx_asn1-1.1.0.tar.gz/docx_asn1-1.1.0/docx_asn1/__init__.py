#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from .utils import extract_text_from_docx
