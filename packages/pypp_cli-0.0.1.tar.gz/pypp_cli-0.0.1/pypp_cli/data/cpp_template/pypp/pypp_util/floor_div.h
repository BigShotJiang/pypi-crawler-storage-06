#pragma once

namespace pypp {

int py_floor_div(int a, int b);

} // namespace pypp
