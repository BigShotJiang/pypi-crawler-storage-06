SHOULDNT_HAPPEN: str = (
    "Shouldn't happen. If you are seeing this, it is a bug. "
    "Please report it at https://github.com/curtispuetz/pypp-cli/issues"
)
