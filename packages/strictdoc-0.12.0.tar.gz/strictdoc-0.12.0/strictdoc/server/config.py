class SDocServerEnvVariable:
    PATH_TO_CONFIG = "PATH_TO_CONFIG"
