"""Static files package for doweb."""
