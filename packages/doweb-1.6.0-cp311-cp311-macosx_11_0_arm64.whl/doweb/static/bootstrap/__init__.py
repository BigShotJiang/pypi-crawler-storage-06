"""Bootstrap static files for doweb."""
