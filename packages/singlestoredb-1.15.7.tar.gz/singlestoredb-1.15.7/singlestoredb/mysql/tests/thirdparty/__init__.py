from .test_MySQLdb import *  # noqa: F403, F401

if __name__ == '__main__':
    import unittest

    unittest.main()
