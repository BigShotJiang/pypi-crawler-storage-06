from sqlx.magic import load_ipython_extension


__all__ = ['load_ipython_extension']
