* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Denis Leemann <denis.leemann@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Dennis Sluijk <d.sluijk@onestein.nl>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Holger Brunn <mail@hunki-enterprises.com>
* Mark Schuit <mark@gig.solutions>
* Stefan Rijnhart <stefan@opener.amsterdam>
