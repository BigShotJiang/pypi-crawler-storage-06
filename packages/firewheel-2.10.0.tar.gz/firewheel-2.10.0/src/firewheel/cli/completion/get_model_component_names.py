"""
Callable script wrapper for the
:py:func:`firewheel.cli.completion.get_model_component_names` function.
"""

from firewheel.cli.completion.actions import get_model_component_names

if __name__ == "__main__":
    get_model_component_names()
