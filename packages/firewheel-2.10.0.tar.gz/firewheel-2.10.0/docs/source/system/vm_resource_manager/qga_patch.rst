.. _qemu-patch-file:

**************
QGA Patch File
**************

Use the link below to download the QEMU patch file needed for FIREWHEEL.
It applies cleanly with ``patch -p1`` on QEMU version 5.0.0.

:download:`Patch File <0001-Allow-exceed-processes-to-ret-data-on-every-status.patch>`.
