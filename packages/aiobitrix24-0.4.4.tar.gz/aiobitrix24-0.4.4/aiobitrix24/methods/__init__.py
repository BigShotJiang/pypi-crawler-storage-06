"""Bitrix24 request methods."""

BATCH = "batch"

CRM_ITEM_GET = "crm.item.get"
CRM_ITEM_LIST = "crm.item.list"
CRM_ITEM_UPDATE = "crm.item.update"
CRM_ITEM_ADD = "crm.item.add"
