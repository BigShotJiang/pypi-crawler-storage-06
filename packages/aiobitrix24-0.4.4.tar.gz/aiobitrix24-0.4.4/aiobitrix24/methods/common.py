"""Common request methods."""

BATCH = "batch"
