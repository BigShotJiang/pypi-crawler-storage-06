"""Dummy MassiveKit package for demonstration purposes."""

__version__ = "0.1.0"
