"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "5597365743e1aa4b4d2abe898faeaa47dbf21972"
short_id = "5597365"
