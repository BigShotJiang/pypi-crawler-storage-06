const s=globalThis.__sveltekit_xl5oyf?.base??"",a=globalThis.__sveltekit_xl5oyf?.assets??s;export{a,s as b};
