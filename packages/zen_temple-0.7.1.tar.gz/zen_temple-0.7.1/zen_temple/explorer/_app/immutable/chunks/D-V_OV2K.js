import{s as e,p as r}from"./BonuoXEx.js";const t={get error(){return r.error},get status(){return r.status},get url(){return r.url}};e.updated.check;const a=t;export{a as p};
