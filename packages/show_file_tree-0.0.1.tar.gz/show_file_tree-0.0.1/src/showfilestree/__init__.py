"""
show-file-tree

A small, fast CLI tool to display styled file/folder trees with rich options.
"""
from ._version import __version__

__all__ = ["__version__"]