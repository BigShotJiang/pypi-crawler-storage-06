# Minha Biblioteca

Esta biblioteca foi criada durante a formação UFCD 10794.

Oferece uma função simples como `cumprimentar(nome)`para imprimir um cumprimento.

# Instalação

pip install minha-biblioteca-nersant