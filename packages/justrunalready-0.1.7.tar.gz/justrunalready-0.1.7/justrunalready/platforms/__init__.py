"""Platform bundler plugins."""

from justrunalready.platforms.base import PlatformBase

__all__ = ["PlatformBase"]