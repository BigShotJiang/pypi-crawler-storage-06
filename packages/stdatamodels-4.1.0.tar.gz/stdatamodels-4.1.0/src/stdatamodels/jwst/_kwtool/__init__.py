from .compare import compare_keywords

__all__ = ["compare_keywords"]
