from .cli import _from_cmdline

_from_cmdline()
