"""Datamodels for JWST and architecture to support them."""
