"""Schemas for JWST datamodels."""
