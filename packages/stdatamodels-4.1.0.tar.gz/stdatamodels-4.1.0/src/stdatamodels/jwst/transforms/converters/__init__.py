"""Convert models to and from YAML tree structures."""
