# This file must exist with these contents
from .plot_commands import plot_cli

if __name__ == "__main__":
    plot_cli()
