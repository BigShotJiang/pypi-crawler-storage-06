# This file must exist with these contents
from .project_commands import project_cli

if __name__ == "__main__":
    project_cli()
