"""napalm-eltex package."""
from napalm_eltex2448.eltex2448 import CEDriver

__all__ = ('CEDriver',)