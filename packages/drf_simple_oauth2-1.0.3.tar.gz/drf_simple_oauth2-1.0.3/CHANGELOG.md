Changelog
=========

### 1.0.3 - 2025-09-23

* Add missing migration `0002_alter_session_status`.
* Add check for missing migrations in `bin/pre_commit.sh` and GitHub actions.

### 1.0.2 - 2025-09-22

* Uses pyproject.toml to publish the package

### 1.0.1 - 2025-09-22

* Fix setup.py's long decription 

## 1.0.0 - 2025-09-22

* Initial Release
