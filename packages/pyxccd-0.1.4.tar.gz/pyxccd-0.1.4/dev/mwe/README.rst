This folder contains documentation to help figure out why the hacks in
`run_developer_setup.sh` are necessary.
