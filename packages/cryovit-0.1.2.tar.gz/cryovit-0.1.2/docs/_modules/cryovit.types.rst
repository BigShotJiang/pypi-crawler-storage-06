﻿cryovit.types
=============

.. automodule:: cryovit.types

   
   .. rubric:: Classes

   .. autosummary::
   
      BatchedModelResult
      BatchedTomogramData
      BatchedTomogramMetadata
      FileData
      ModelType
      Sample
      TomogramData
   