To use this module, you need to:

In the lines, you will see the 'Invoice Status' field and you can force
invoice.
