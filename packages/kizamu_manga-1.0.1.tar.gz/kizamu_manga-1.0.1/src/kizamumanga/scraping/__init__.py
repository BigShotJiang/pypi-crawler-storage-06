from .weeb_central import WeebCentral
from .inmanga import InManga
from .leermangaesp import LeerMangaEsp
from .interface import ScraperInterface
from .base import ScraperBase, MangaError