"""
janito: A Python package for managing and interacting with Large Language Model (LLM) providers and their APIs.
Provides a CLI for credential management and an extensible driver system for LLMs.
"""

from ._version import __version__
