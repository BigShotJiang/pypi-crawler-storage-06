abis
===========================

.. automodule:: pragma_sdk.onchain.abis.abi
   :members:
   :undoc-members:
   :show-inheritance:
