# Credits

## Development Lead

* [Quentin Coumes (Codoc)](https://github.com/qcoumes)
* [Andrea Chávez Herrejón (Codoc)](https://github.com/andreach2713)

### Contributors

* [Vincent Lefoulon](https://github.com/Vayel)

