# Changelog


### 2.1.1 (2025-09-22)

* Add conditional SSL handling in `verify_jwt` when SSL verification is disabled.
  ([#9](https://github.com/Codoc-os/france-connect-py/pull/9)),


### 2.1.0 (2025-05-20)

* Allow customization of JWT algorithms using `jwt_algorithms` when instantiating client
  ([#7](https://github.com/Codoc-os/france-connect-py/pull/7)),
  Contributed by [Vayel](https://github.com/Vayel).


### 2.0.0 (2024-10-07)

* Initial release
