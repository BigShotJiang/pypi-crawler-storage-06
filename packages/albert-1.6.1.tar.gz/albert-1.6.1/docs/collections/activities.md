::: albert.collections.activities.ActivityCollection
