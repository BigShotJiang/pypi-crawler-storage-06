使用教程
=========

可以在项目代码中使用 ``pycmd2`` ::

    import pycmd2
