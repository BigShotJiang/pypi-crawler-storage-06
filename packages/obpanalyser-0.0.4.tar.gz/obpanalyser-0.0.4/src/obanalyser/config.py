import math

class Config:
    def __init__(self):
        # Parameters for build simulation
        self.transition_time = 7.844617526 #time [s] for recoter and transition between layers
        

config = Config()