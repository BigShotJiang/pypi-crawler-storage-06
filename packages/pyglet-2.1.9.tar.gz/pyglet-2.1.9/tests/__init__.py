"""
Please see doc/internal/testing.txt for test documentation.
"""
import unittest.mock as mock
