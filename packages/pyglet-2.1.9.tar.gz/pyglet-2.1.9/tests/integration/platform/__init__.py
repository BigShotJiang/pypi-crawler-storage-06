"""
Platform integration tests. These tests are specific to certain platforms.
"""
