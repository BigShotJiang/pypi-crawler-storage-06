.. _guide_models:

3D Models and Scenes
====================

The :py:mod:`~pyglet.model` module is still a work in progress, and is
not yet documented.

TBD
---