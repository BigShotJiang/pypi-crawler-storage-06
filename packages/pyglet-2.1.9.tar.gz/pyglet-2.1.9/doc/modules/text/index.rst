pyglet.text
===========

.. rubric:: Submodules

.. toctree::
   :maxdepth: 1

   caret
   document
   layout

.. rubric:: Details

.. force the Enum to be documented by excluding and manually adding it

.. automodule:: pyglet.text
  :exclude-members: Weight
  :members:
  :undoc-members:

  .. keep the members ordered from lightest to heaviest

  .. autoclass:: Weight
     :member-order: bysource
     :members:
     :undoc-members:
