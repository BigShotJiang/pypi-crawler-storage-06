pyglet.sprite
=============

.. automodule:: pyglet.sprite

.. autoclass:: Sprite
  :members:
  :undoc-members:

.. autoclass:: AdvancedSprite

.. autoclass:: SpriteGroup
  :members:
  :undoc-members:

