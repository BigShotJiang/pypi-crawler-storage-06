"""Module entry point."""

from .exceptions import RtError

__all__ = ['RtError']
