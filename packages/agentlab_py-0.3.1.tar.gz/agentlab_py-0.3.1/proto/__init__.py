"""Proto package root for generated files."""
