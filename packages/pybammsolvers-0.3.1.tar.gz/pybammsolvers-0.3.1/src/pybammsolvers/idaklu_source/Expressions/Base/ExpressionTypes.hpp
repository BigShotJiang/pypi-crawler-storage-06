#ifndef PYBAMM_EXPRESSION_TYPES_HPP
#define PYBAMM_EXPRESSION_TYPES_HPP

using expr_int = long long int;

#endif // PYBAMM_EXPRESSION_TYPES_HPP
