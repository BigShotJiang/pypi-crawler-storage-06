# ExpEYES17 PIP Package

entry points : none. This is only a library

maintainer : Jithin B P jithinbp@gmail.com


from eyes17.eyes import *

