Lines 1-7

```cpp
  1 #include <iostream>
  2 
  3 int main() {
! 4     std::cout << "Hello World!";
! 5     return 0;
  6 }
```
