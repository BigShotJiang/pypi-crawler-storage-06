# Diff Quality
## Quality Report: pycodestyle
## Diff: origin/main...HEAD, staged and unstaged changes

- violations_test_file.py (66.7%):
  - violations_test_file.py:2: E225 missing whitespace around operator
  - violations_test_file.py:6: E302 expected 2 blank lines, found 0
  - violations_test_file.py:11: E225 missing whitespace around operator

- **Total**:   9 lines
- **Violations**: 3 lines
- **% Quality**: 66%
