print("hello")
print(unknown_var)