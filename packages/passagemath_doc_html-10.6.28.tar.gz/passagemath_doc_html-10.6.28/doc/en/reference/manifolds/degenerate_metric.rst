Degenerate Metric Manifolds
===========================

.. toctree::
   :maxdepth: 1

   sage/manifolds/differentiable/degenerate

   sage/manifolds/differentiable/degenerate_submanifold
