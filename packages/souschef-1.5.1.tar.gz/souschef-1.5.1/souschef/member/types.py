from typing_extensions import Literal, TypeAlias

RateType: TypeAlias = Literal["default", "low income", "solidary"]
