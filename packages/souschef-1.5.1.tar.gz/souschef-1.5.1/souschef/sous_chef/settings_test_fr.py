from .settings_test import *  # noqa

LANGUAGE_CODE = "fr"
