# from django.conf.urls import url

app_name = "notification"
urlpatterns = []
