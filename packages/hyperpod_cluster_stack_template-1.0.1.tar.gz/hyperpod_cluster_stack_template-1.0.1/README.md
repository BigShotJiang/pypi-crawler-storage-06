
# hyperpod-cluster-stack-template

## Installation
`pip install hyperpod-cluster-stack-template`

## Overview 
This package provides the model and template for the cloudformation required for cluster stack creation . 


