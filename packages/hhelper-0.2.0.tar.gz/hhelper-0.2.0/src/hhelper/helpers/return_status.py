from enum import Enum

STATUS = Enum("STATUS", ["WAIT", "NOWAIT"])
