print("This is my code. Imported successfully!")

def hello():
    return "Hello from mylib!"
