Go to Settings > Technical > Models

Select a model > in tab "Custom required fields", "Custom invisible fields" or "Custom readonly fields" add a line

Select a field, add one or more group and enable flag "Required", "Invisible" or "Readonly"

If needed, set a condition for which the field should be required, invisible or readonly for users of those groups.
