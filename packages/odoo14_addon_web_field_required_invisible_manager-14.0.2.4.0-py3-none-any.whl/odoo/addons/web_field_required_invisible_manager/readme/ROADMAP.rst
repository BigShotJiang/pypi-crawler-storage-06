When one model inherits another (e.g. res.users inherits res.partner) and new custom
field is created, then same field is created for inheriting model as well, which should
be avoided or at least duplicated field should be also manual, but created as base.
