* `Ooops404 <https://www.ooops404.com>`__:

  * Ilyas <irazor147@gmail.com>
* `PyTech <https://www.pytech.it>`_:

  * Simone Rubino <simone.rubino@pytech.it>
