This module allows to set a field required, invisible or readonly for users belonging to a specific group.

The field can be required, invisible or readonly in any case, or according to specific conditions.
