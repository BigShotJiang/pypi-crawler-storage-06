"""Metadata for Workflow Linter."""

__version__ = "1.5.2"
