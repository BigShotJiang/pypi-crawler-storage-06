def solve_Linear(a,b,x):
    return a*x+b

def main():
    # Your logic for algebra
    print("This is the algebra entry point")