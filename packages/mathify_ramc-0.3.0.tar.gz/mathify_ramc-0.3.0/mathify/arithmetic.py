def add(a,b):
    '''This is a arthimetic addition operation'''
    return a+b

def subtract(a,b):
    """This is a arthimetic subtraction operation"""
    return a-b

def main():
    # Your logic for algebra
    print("This is the arithmetic entry point")