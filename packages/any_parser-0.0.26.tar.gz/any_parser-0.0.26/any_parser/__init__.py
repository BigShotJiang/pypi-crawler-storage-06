"""AnyParser module for parsing data."""

from any_parser.any_parser import AnyParser

__all__ = ["AnyParser"]

__version__ = "0.0.26"
