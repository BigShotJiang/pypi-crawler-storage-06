# gridworks-admin

This package contains gridworks-admin CLI tool for use in monitoring gridworks-scada
devices. 
