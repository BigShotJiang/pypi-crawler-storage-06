# For backwards compatibility
from chalk.features.dataframe import DataFrame as ChalkDataFrameImpl

__all__ = ["ChalkDataFrameImpl"]
