"""Allow users to access the class directly."""
from fe25519.fe25519 import fe25519
