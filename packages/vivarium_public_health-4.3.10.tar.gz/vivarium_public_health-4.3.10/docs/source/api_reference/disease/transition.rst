.. automodule:: vivarium_public_health.disease.transition
