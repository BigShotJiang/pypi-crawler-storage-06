.. automodule:: vivarium_public_health.treatment.therapeutic_inertia
