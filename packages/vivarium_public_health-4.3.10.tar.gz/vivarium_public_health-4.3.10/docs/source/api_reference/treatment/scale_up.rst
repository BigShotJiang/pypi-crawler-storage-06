.. automodule:: vivarium_public_health.treatment.scale_up
