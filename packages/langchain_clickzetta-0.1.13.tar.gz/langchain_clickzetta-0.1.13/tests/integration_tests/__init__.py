"""Integration tests for langchain-clickzetta with real ClickZetta connections."""
