"""

Authors: Benedikt Lorch
Affiliation: University of Innsbruck
"""

from ._dctr import extract, extract_from_file
