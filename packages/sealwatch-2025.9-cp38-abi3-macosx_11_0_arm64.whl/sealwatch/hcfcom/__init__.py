"""

Author: Martin Benes
Affiliation: University of Innsbruck
"""

from .hcfcom import extract, extract_from_file
