"""

Authors: Martin Benes, Benedikt Lorch
Affiliation: University of Innsbruck
"""

from ._attack import attack
from . import _attack
