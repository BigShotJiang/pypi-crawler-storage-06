.. Pelita documentation master file, created by
   sphinx-quickstart on Tue Aug 13 20:04:18 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Pelita |version|
================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. container:: container-fluid

   .. container:: row

      .. container:: col-md-6

         .. image:: images/small-game@2x.png
            :scale: 50%
            :alt: Screenshot.
            :class: img-responsive

Find the Pelita documentation here: https://github.com/ASPP/pelita_template

.. toctree::
   :hidden:

   info
