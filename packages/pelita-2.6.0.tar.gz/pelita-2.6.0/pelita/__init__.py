# ruff: noqa: F401

from . import game, layout, maze_generator, network, viewer

__version__ = '2.6.0'
