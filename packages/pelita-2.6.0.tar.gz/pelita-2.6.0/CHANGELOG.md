# Pelita changelog

  * v2.6.0 (24. Sep 2025)

    - Increased bot shadow distance to 2
    - Changed behaviour of cascade kill
    - Added history viewer to Tk
    - Improved stability of the network protocol
    - Introduced game_phase attribute to game state
    - Maze generation improvements
    - Be more strict in what characters bot.say accepts
    - Changed distribution of teams in the knock-out round
    - Keep square aspect ratio in Tk UI
    - Removed compatibility for Python 3.9
    - Introduced game_uuid

  * v2.5.3 (28. May 2025)

    - Redesigned status area
    - Tkinter buttons and backgrounds are not colourised anymore on macOS

  * v2.5.2 (5. May 2025)

    - On-the-fly layout generation
    - On-the-fly food distribution with --food
    - Removal of built-in layouts
    - Making illegal moves a fatal error
    - Added Bot.has_exact_position attribute
    - Improved Bot.__repr__
    - New --store-layout option
    - New --stop-after-kill option
    - Grid labels
    - New --standalone-mode in tk viewer, enabling user-configured overlays on the maze
    - Improved internals

  * v2.5.1 (09. Oct 2024)

    - 1000 new layouts with dead ends
    - Matches will be played on a maze with dead ends/chambers with 25% chance
    - Reduced the radius of the food shadow
    - Streamlined handling of random numbers and seeding

  * v2.5.0 (08. Aug 2024)

     - Food ageing and relocation to discourage camping strategies
     - New attribute bot.shaded_food
     - Fullscreen mode added to UI
     - Enhanced CI engine
     - New and enlarged collection of layouts
     - New attribute bot.team_time in bot
     - Add send queue to server to avoid stalling
     - Fewer failures in Github CI

  * v2.4.0 (23. May 2024)

     - Greatly improved server mode
     - Bot.legal_positions becomes a static attribute
     - Bot has a new cached attribute graph
     - Small timeout improvements

  * v2.3.2 (16. Oct 2023)

     - Give advice when tkinter is not available
     - Fix colours in --ascii mode on Windows
     - Improved --progress bar

  * v2.3.1 (2. Sep 2023)

     - Tournament can be configured to include name of host and local salutation

  * v2.3.0 (31. Aug 2023)

     - Switching to pyproject.toml
     - Bot.walls and Bot.homezone are tuples of tuples for reproducibility

  * v2.2.0 (08. Sep 2022)

    - Do not have a team play two matches in a row during round-robin mode
    - Show the tournament group names in the UI and on the CLI
    - Automatic detection of network players via zeroconf

  * v2.1.0 (25. Sep 2021)

    - Bot API uses a fixed state dict instead of returning `(position, state)`
    - Layout unification: Use a,b,x,y as Bot characters instead of indexes
    - Adding shape tuple to API
    - Walls/Homezone are stored in a set for faster lookup
    - Improved debug UI
    - Changed primary branch to ‘main’
    - Use Gitlab CI actions instead of travis

  * v2.0.1 (27. Sep 2019)

    - Fixes a bug in Tk

  * v2.0.0 (3. Sep 2019)

    - Major rewrite to functional Bot API (no more `AbstractPlayer`)
    - Major rewrite of Pelita core

  * v0.9.2 (29. Oct 2018)

    - Bug fixes and API improvements

  * v0.9.1 (18. Jan 2018)

    - Minor API changes and bug fixes

  * v0.9.0 (31. Aug. 2017)

    - Python 3
    - Pelita is installable with setup.py

  * v0.2.0 (7. Sep. 2012)

    - Revised actor model to use zmq

  * v0.1.1 (23. May 2012)

    - Fixes and updates

  * v0.1.0 (21. Sep. 2011)

    - First usable version

  * v0.0.0 (1. Jun. 2011)

    - Initial commit of this repo
