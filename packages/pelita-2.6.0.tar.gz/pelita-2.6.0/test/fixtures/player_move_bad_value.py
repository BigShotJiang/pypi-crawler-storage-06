# Player whose move returns a bad value

TEAM_NAME = "Move bad value"
def move(b, s):
    return (0, 0, 0)
