# Player with an overly long team name

TEAM_NAME = "123456789 123456789 123456789 123456789"
def move(b, s):
    return b.position
