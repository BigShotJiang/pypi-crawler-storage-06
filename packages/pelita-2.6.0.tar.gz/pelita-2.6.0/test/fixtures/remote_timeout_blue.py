
import time

TEAM_NAME = "150ms timeout"
def move(b, s):
    time.sleep(0.15)
    return b.position
