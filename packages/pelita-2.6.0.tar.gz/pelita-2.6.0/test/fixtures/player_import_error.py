# Player with global import error

import this_module_does_not_exist

TEAM_NAME = "Global import error"
def move(b, s):
    return b.position
