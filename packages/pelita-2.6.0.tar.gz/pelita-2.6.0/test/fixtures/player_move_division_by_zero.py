# Player with a division by zero in move

TEAM_NAME = "Move division by zero"
def move(b, s):
    0 / 0
    return b.position
