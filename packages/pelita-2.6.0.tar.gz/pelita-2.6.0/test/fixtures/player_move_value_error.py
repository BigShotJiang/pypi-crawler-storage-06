# Player with a value error in move

TEAM_NAME = "Move value error"
def move(b, s):
    raise ValueError("Bad value")
    return b.position
