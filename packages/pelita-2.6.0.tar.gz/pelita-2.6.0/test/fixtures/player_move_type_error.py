# Player with a type error in move

TEAM_NAME = "Move type error"
def move(b, s):
    raise TypeError("Bad type")
    return b.position
