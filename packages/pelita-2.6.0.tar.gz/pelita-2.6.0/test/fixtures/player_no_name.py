# Player without a team name

def move(b, s):
    return b.position