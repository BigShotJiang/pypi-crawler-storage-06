# Player whose move has the wrong arguments

TEAM_NAME = "Move bad args"
def move(b, s, extra):
    return b.position
