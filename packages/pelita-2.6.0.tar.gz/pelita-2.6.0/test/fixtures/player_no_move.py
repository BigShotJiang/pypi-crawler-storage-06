# Player without a move function

TEAM_NAME = "TEAM without move"
