This is a python module with a syntax error.
