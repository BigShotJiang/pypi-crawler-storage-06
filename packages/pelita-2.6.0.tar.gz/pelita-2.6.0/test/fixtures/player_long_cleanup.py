# Player with a long cleanup times

import atexit
import time

def sleep():
    time.sleep(10)

TEAM_NAME = "Long cleanup"
def move(b, s):
    return b.position

atexit.register(sleep)
