# Player whose move returns a bad type

TEAM_NAME = "Move bad type"
def move(b, s):
    return "0, 0"
