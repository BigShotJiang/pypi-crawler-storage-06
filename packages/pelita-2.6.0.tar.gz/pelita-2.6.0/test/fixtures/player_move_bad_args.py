# Player whose move has the wrong arguments

TEAM_NAME = "Move bad args"
def move(b):
    return b.position
