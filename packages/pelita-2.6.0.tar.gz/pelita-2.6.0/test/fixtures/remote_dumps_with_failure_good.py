TEAM_NAME="good"
def move(b, s):
    return b.position
