# This directory contains user contributed code.
# Please add a line to this file to explain what your contribution is
# about and list the name of the files/directories related to your
# contribution.
# Example:
# - Pelita Benchmarks: in pelita_benchmarks/bench.py
#   Set of benchmarks for testing the speed of pelitagame. 
#   To run just execute the bench.py script.
