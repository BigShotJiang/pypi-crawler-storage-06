import setuptools

# This file is maintained for compatibility with older tools
# that don't support pyproject.toml

if __name__ == "__main__":
    setuptools.setup()