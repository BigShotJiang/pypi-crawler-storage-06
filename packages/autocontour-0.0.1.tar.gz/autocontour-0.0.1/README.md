# Autocontour

This package is an auxiliary tool for [Meander](https://typst.app/universe/package/meander).
It can generate contours for images so that Meander knows how to wrap text around them.

## Requirements

This project assumes that you have ImageMagick installed.
