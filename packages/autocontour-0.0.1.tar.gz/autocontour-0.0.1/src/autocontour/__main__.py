if __name__ == "__main__":
    from autocontour.main import main
    main()

