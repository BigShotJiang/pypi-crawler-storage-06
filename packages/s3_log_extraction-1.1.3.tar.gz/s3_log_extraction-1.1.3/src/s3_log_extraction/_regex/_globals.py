# Seems there were multiple IPs associated with Drogon, though it likely only utilizes the main one
# Better safe than not though
DROGON_IP_REGEX_ENCRYPTED = (
    b"gAAAAABoLL5Cln6TyMSaPfd8Cu_EIDDnIg2I7R3i-eipDcKGr0DRHXfqIGoxO36CQhEyp4aPR0Ylxu8dF"
    b"OKknTAICvDg7GV33y6dI8d1-C6GsBoSdihP2IYEMwUwasa_dYUEtuTRVz10B0TpZkocjuRPW-CfIPVDgF"
    b"yVXF8AfFESS-yRiL5nueuYsoD6MlJHmHhX0PVRVef6"
)
