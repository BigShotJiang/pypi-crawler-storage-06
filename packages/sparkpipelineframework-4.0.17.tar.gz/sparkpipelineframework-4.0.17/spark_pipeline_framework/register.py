from helixtelemetry.telemetry.register import register as telemetry_register


def register() -> None:
    telemetry_register()
