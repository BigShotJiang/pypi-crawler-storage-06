class AutomapperToFhirTransformerException(Exception):
    pass
