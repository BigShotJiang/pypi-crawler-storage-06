# flake8: noqa

from scikit_longitudinal.estimators.trees.lexicographical.lexico_decision_tree import (  # noqa
    LexicoDecisionTreeClassifier,
)

_all_ = [
    "LexicoDecisionTreeClassifier",
]
