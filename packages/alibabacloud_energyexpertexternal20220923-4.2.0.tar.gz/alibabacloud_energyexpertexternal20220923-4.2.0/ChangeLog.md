2025-07-10 Version: 4.1.0
- Support API ChatStream.


2025-06-26 Version: 4.0.0
- Update API GetChatList: update request parameters body.currentPage' type has changed.
- Update API GetChatList: update request parameters body.currentPage' format has changed.
- Update API GetChatList: update request parameters body.pageSize' type has changed.
- Update API GetChatList: update request parameters body.pageSize' format has changed.


2025-05-20 Version: 3.3.0
- Support API Chat.
- Support API CreateChatSession.
- Support API GetChatFolderList.
- Support API GetChatList.
- Support API GetChatSessionList.


2025-04-18 Version: 3.2.0
- Support API GetDocExtractionResult.
- Support API GetDocParsingResult.
- Support API GetVLExtractionResult.
- Support API SubmitDocExtractionTask.
- Support API SubmitDocParsingTask.
- Support API SubmitVLExtractionTask.


2025-02-21 Version: 3.1.0
- Support API AnalyzeVlRealtime.
- Update API BatchSaveInstructionStatus: update param body.
- Update API BatchUpdateSystemRunningPlan: update param body.
- Update API EditProhibitedDevices: update param body.
- Update API EditUnfavorableAreaDevices: update param body.
- Update API SetRunningPlan: update param body.


2025-02-12 Version: 3.0.1
- Update API BatchSaveInstructionStatus: update param body.
- Update API BatchUpdateSystemRunningPlan: update param body.
- Update API EditProhibitedDevices: update param body.
- Update API EditUnfavorableAreaDevices: update param body.
- Update API SetRunningPlan: update param body.


2024-11-22 Version: 3.0.0
- Update API SubmitDocumentAnalyzeJob: add param analysisType.
- Update API SubmitDocumentAnalyzeJob: delete param dataType.


2024-09-27 Version: 2.1.1
- Update API SubmitDocumentAnalyzeJob: add param dataType.


2024-09-21 Version: 2.1.0
- Support API BatchSaveInstructionStatus.
- Support API BatchUpdateSystemRunningPlan.
- Support API EditProhibitedDevices.
- Support API EditUnfavorableAreaDevices.
- Support API SetRunningPlan.


2024-06-14 Version: 2.0.1
- Update API SubmitDocumentAnalyzeJob: update param fileName.


2024-06-13 Version: 2.0.0
- Update API GetGasConstitute: update param body.
- Update API SubmitDocumentAnalyzeJob: add param fileName.
- Update API SubmitDocumentAnalyzeJob: delete param ossUrl.
- Update API SubmitDocumentAnalyzeJob: update param fileUrl.


2024-06-06 Version: 1.2.0
- Support API GetDocumentAnalyzeResult.
- Support API SendDocumentAskQuestion.
- Support API SubmitDocumentAnalyzeJob.


2024-04-03 Version: 1.1.0
- Support API GenerateResult.
- Support API GetAreaElecConstitute.
- Support API GetCarbonEmissionTrend.
- Support API GetDataItemList.
- Support API GetDataQualityAnalysis.
- Support API GetElecConstitute.
- Support API GetElecTrend.
- Support API GetEmissionSourceConstitute.
- Support API GetEmissionSummary.
- Support API GetEpdInventoryConstitute.
- Support API GetEpdSummary.
- Support API GetFootprintList.
- Support API GetGasConstitute.
- Support API GetGwpBenchmarkList.
- Support API GetGwpBenchmarkSummary.
- Support API GetGwpInventoryConstitute.
- Support API GetGwpInventorySummary.
- Support API GetInventoryList.
- Support API GetOrgConstitute.
- Support API GetPcrInfo.
- Support API GetReductionProposal.
- Support API IsCompleted.
- Support API PushDeviceData.
- Support API PushItemData.
- Support API RecalculateCarbonEmission.


2023-07-13 Version: 1.0.0
- For Energy.
- GetOrgAndFactory.
- GetDeviceList.
- GetDeviceInfo.

