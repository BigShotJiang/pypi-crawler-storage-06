#! /usr/bin/python3

with open("Makefile", "a") as f:
    f.write("\nHello")

