from .kinetics import TL_first_order, TL_second_order, TL_general_order
