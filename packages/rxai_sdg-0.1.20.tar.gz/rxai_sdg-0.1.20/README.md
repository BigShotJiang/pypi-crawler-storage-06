# Reactive AI: Synthetic Dataset Generators
Toolkit for Synthetic Dataset generation for Reactive Models

## Install
Library could be installed with `pip`:
- `pip install rxai-sdg`

## Memory Reinforcement Learning Datasets

Docs in progress