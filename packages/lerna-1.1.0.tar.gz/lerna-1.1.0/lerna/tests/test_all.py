from lerna import *  # noqa


def test_all():
    assert True
