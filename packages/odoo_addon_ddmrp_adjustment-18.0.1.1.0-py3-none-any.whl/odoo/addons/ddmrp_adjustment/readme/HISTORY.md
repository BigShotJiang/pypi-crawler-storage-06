## 16.0.1.0.0 (2023-12-05)

- Standard migration to v16.

## 15.0.1.0.0 (2022-03-04)

- Standard migration to v15.

## 14.0.1.0.0 (2021-06-17)

- Standard migration to v14.

## 13.0.1.0.0 (2020-07-02)

- Standard migration to v13.

## 11.0.1.1.0 (2019-02-01)

- Refactor data model to reduce complexity. Functionality unchanged.

## 11.0.1.0.0 (2018-08-01)

- Start of the history
