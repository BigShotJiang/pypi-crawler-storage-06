from colored import attr, fg  # type: ignore

NC = attr('reset')
FG_RED = fg('red')
FG_GREEN = fg('green')
FG_YELLOW = fg('yellow')
FG_GRAY = fg("dark_gray")
FG_BLUE = fg("blue")
