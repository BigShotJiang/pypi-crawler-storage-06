
def test_empty() -> None:
    assert 1 == 1
    pass
