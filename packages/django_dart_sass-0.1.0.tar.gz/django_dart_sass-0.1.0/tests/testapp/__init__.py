# Test Django app for integration tests
