# Algoritmos de filtrado colaborativo
from tracerec.algorithms.embedder import Embedder
