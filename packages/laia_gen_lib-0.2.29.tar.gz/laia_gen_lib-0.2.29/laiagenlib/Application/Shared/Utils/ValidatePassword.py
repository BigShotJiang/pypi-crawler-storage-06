def validate_password(password: str) -> bool:
    return len(password) >= 8