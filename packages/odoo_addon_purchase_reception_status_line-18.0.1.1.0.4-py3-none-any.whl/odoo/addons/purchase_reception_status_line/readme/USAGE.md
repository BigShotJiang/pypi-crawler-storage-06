If you are part of the *Purchase Manager* group, you can force a
confirmed purchase order to **Full Received** status: you have to check
the field **Force Received** located in the hidden fields on the tree
view (Order Lines tab).
