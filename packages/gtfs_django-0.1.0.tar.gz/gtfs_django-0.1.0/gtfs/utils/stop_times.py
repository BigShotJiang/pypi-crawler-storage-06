def estimate_stop_times():
    pass
