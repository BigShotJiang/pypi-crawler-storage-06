from .stop_times import estimate_stop_times


def build_vehicle_positions():
    pass


def build_trip_updates():
    estimate_stop_times()
    pass


def build_alerts():
    pass


def get_vehicle_positions():
    pass


def get_trip_updates():
    pass


def get_alerts():
    pass
