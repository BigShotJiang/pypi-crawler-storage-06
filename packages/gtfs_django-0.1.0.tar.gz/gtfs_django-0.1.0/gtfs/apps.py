from django.apps import AppConfig


class GtfsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "gtfs"
    verbose_name = "GTFS for Django"
