from SciQLop.sciqlop_launcher import main

if __name__ == '__main__':
    main()
