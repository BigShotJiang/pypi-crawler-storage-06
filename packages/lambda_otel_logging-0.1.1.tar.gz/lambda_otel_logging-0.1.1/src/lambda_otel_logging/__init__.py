from lambda_otel_logging._version import __version__  # noqa: F401
