# OpenID-federation policy

This is a Python module which allows merging `openid-federation` policies and
applying a given policy to some given metadata. All input and output is in
JSON.


`0.0.1` is a test release.

## License

BSD-2-Clause
