"""CLI domain - command line interface"""

from noxus_sdk.cli.main import main

__all__ = ["main"]
