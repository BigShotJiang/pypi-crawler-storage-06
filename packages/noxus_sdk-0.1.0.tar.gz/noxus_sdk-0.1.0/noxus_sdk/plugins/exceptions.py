"""Plugins domain exceptions."""


class PluginValidationError(Exception):
    """Exception for plugin validation errors"""
