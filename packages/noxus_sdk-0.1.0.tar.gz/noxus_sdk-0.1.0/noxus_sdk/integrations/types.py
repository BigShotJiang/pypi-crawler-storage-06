from enum import Enum


class IntegrationType(str, Enum):
    nango = "nango"
