from atomize.main.main_window import main
main()