import atomize.general_modules.general_functions as general

general.bot_message('hi', 'hi2')
