# Atomize!

##To do list:

A. Modules/Connection/Config
- Write a detailed instruction how to install gpib library on Linux. Test gpib library on windows
- check limits of sensitivity and other stuff for oscilliscopes
- libspinapi.so path into the config file
- the same for AWG

B. Liveplot


C. General
- Windows 10. GUI script. TypeError: cannot pickle 'Worker' object












