1. Move agents usage instructions to shared file
2. How we can work with prompts without copying them to target repo?