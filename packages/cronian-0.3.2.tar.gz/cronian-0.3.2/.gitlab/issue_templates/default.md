<!--
Is your issue a bug report, feature request or about documentation?
Then please select the relevant template for guidance on what information would be most helpful to address your issue.
-->

## Description

Please provide a description of the issue here.

### Checklist

- [ ] I have checked the of [existing issues](https://gitlab.tudelft.nl/demoses/cronian/-/issues) and couldn't find an issue about this.
