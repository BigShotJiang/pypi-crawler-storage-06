# c2js Generator

Note: make sure emscripten sdk is sourced and `emcc` command is in your PATH:

http://kripken.github.io/emscripten-site/docs/getting_started/downloads.html