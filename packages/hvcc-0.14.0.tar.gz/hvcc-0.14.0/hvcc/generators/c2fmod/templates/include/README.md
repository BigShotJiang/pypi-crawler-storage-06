# FMOD SDK

In order to build the project this folder needs to contain the
[FMOD SDK](https://www.fmod.com/download#fmodengine) in the sub folder `fmod`.

The directory structure should look like this.

```
include/fmod/core
include/fmod/fsbank
include/fmod/studio
```
