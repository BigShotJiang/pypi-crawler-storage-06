{{copyright}}

#ifndef {{name}}Config_H
#define {{name}}Config_H

namespace {{name}}Config
{
    static const unsigned short CompanyID = 64;
    static const unsigned short PluginID = {{plugin_id}};
}

#endif // {{name}}Config_H
