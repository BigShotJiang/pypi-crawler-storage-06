{{copyright}}

#ifndef {{name}}{{plugin_type}}Factory_H
#define {{name}}{{plugin_type}}Factory_H

AK_STATIC_LINK_PLUGIN({{name}}{{plugin_type}})

#endif // {{name}}{{plugin_type}}Factory_H
