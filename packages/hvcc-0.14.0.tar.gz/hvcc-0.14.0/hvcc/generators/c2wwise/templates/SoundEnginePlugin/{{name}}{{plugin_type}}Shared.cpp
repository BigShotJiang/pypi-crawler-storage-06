{{copyright}}

#include <AK/SoundEngine/Common/IAkPlugin.h>
#include "{{name}}{{plugin_type}}Factory.h"

#include <AK/Tools/Common/AkAssert.h>

DEFINEDUMMYASSERTHOOK;
DEFINE_PLUGIN_REGISTER_HOOK;
