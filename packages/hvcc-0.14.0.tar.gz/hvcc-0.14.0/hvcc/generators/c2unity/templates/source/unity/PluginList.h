DECLARE_EFFECT("{{patch_name}}", Hv_{{patch_name}}_UnityPlugin)
