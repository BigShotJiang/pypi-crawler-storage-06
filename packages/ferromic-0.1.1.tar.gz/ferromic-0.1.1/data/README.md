callset.tsv: 2A:GRCh38_unifiedCallset
