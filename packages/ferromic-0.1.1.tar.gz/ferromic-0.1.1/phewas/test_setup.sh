#!/bin/bash

# Install test dependencies
pip install pytest pytest-timeout numpy pandas statsmodels psutil scipy google-cloud-bigquery pyarrow fsspec gcsfs
