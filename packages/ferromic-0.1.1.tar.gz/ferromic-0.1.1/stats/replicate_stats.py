# Nucleotide Diversity Patterns between all inverted haplotypes and all direct haplotypes

# Nucleotide Diversity Patterns in Recurrent and Non-recurrent Inversions

# Inversion Formation Rate and Nucleotide Diversity

# Genetic Differentiation Between Inverted and Direct Orientations

# Nucleotide Diversity and Breakpoint Proximity

# Differential Conservation Between Recurrent and Single-Event Inversions
