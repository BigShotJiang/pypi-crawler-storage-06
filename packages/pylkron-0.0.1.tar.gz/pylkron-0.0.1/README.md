# pyLkron

## List of known endpoints:

- "sys/info.cgi" : Returns infos on the system (no authentication required??)
- "user/info.cgi" : Returns current user info and authLevel (-1 if not logged in)
- "user/logout.cgi" : Logout endpoint (returns error 405 if not logged in)
- "user/login.cgi" : Endpoint for first login procedure
- "spweco/globalstates.cgi": Endpoint to check alarm status
- "spweco/detailedstates.cgi": Endpoint to get activezone and zone + sensors states
- "spweco/plantstructure.cgi": Endpoint to get zone informations
- "spweco/activate.cgi": Endpoint to get zone informations
- "spweco/deactivate.cgi": Endpoint to get zone informations
- "spweco/getshortcuts.cgi": UNKNOWN

## Cookie Structure

- **i18next**: language selector ("it", "en", etc.)
- **TRACKID**: alphanumeric string to keep session, same value always

# Endpoint infos

## sys/info.cgi

### Request

- **GET**:
  - [*_*]: Time since epoc in ms (**Request Query Parameter**)
- **POST**: ????

### Example

```json
{
  "data": {
    "backend": "it500web 2.0.170615",
    "boardid": "",
    "bzone": 0,
    "cbrand": "elkron",
    "cmodel": "ELKRON - MP500/8",
    "cumod": 0,
    "cver": "01.07",
    "lang": "it",
    "macadd": "",
    "maxidle": 120,
    "plantname": "HAL9000",
    "sendcloud": true,
    "sesstate": -1,
    "swpver": "2.0.0-27",
    "swupdprogress": 100.0,
    "swupdstate": 0,
    "sysmode": 1
  },
  "result": "ACK",
  "title": "/sys/info.cgi"
}
```

## user/login.cgi

### Request

- **GET**: returns error 405
- **POST**: Logs in with JSON object as request body:
  - _user_: Plaintext Web panel username
  - _pwd_: Double hashed password (md5(md5(password)))

### Response

- _200 OK_: JSON object with the login result
  - _result_: Login Status
    - _NAK_: Not Logged-In
    - _ACK_: Logged-In successfully + **Session Cookie**
  - _title_: Endpoint name
  - [*data*]: if result is ACK contains authentication details
    - _authlevel_
    - _userid_
    - _username_

### Example

```json
{
  "data": {
    "authlevel": 1,
    "userid": -1,
    "username": "..."
  },
  "result": "ACK",
  "title": "/user/login.cgi"
}
```

## user/info.cgi

### Request

- **GET**:
  - [*_*]: Time since epoc in ms (**Request Query Parameter**)
- **POST**: ????

### Example

```json
{
  "data": {
    "authlevel": 1,
    "userid": -1,
    "username": "..."
  },
  "result": "ACK",
  "title": "/user/info.cgi"
}
```

## spweco/globalstates.cgi

### Request

- **GET**:
  - [*_*]: Time since epoc in ms (**Request Query Parameter**)
- **POST**: ????

### Response

- _404 KO_: If not logged-in
- _200 OK_: With the system status data
  - _result_: "ACK"
  - _title_: Endpoint name
  - _data_: Dictionary of n sectors identified by a letter and with value (0, 1, 2, ... unknown meaning)
    - _Example_: { "A": 1, "I": 2, "K": 0}

### Example

```json
{
  "data": {
    "A": 0,
    "F": 0,
    "I": 0,
    "O": 0,
    "X": 0
  },
  "result": "ACK",
  "title": "/spweco/globalstates.cgi"
}
```

## spweco/detailedstates.cgi

### Request

- **GET**:
  - [*_*]: Time since epoc in ms (**Request Query Parameter**)
- **POST**: ????

### Example

```json
{
  "data": {
    "activezone": [],
    "sensorstate": [],
    "zonestate": []
  },
  "result": "ACK",
  "title": "/spweco/detailedstates.cgi"
}
```

## spweco/plantstructure.cgi

### Request

- **GET**:
  - [*_*]: Time since epoc in ms (**Request Query Parameter**)
- **POST**: ????

### Example

```json
{
  "data": {
    "cfgarea": [{ "NAME": "", "NID": 0, "PID": [] }],
    "cfgoutput": [],
    "cfgsensor": [
      { "NAME": "Ingresso 1 - Ingresso", "NID": 1, "PID": [1] },
      { "NAME": "Ingresso 2 - ...", "NID": 2, "PID": [2] },
      { "NAME": "Ingresso 3 - Tapparelle giorno", "NID": 3, "PID": [3] },
      { "NAME": "Ingresso 4 - Barriere notte", "NID": 4, "PID": [4] },
      { "NAME": "Ingresso 5 - Tapparelle notte", "NID": 5, "PID": [5] },
      { "NAME": "Ingresso 6 - Barriere giorno", "NID": 6, "PID": [2] }
    ],
    "cfgzone": [
      { "NAME": "Settore 1 - Ingresso", "NID": 1, "PID": [0] },
      { "NAME": "Settore 2 - Barriere giorno", "NID": 2, "PID": [0] },
      { "NAME": "Settore 3 - Tapparelle giorno", "NID": 3, "PID": [0] },
      { "NAME": "Settore 4 - Barriere notte", "NID": 4, "PID": [0] },
      { "NAME": "Settore 5 - Tapparelle notte", "NID": 5, "PID": [0] }
    ],
    "exsensor": [
      { "NAME": "Ingresso 1 - Ingresso", "NID": 1, "PID": [1] },
      { "NAME": "Ingresso 2 - ...", "NID": 2, "PID": [2] },
      { "NAME": "Ingresso 3 - Tapparelle giorno", "NID": 3, "PID": [3] },
      { "NAME": "Ingresso 4 - Barriere notte", "NID": 4, "PID": [4] },
      { "NAME": "Ingresso 5 - Tapparelle notte", "NID": 5, "PID": [5] },
      { "NAME": "Ingresso 6 - Barriere giorno", "NID": 6, "PID": [2] }
    ]
  },
  "result": "ACK",
  "title": "/spweco/plantstructure.cgi"
}
```

## spweco/getshortcuts.cgi

### Request

- **GET**:
  - [*_*]: Time since epoc in ms (**Request Query Parameter**)

### Example

```json
{
  "data": [
    { "delay": 0, "enable": 0, "id": 1, "name": "", "zone": [] },
    { "delay": 0, "enable": 0, "id": 2, "name": "", "zone": [] }
  ],
  "result": "ACK",
  "title": "/spweco/getshortcuts.cgi"
}
```

## spweco/filteredstructure.cgi

### Request

- **GET**:
  - [*_*]: Time since epoc in ms (**Request Query Parameter**)

### Example

```json
{
  "data": {
    "cfgarea": [{ "NAME": "", "NID": 0, "PID": [] }],
    "cfgoutput": [],
    "cfgsensor": [
      { "NAME": "Ingresso 1 - Ingresso", "NID": 1, "PID": [1] },
      { "NAME": "Ingresso 2 - ...", "NID": 2, "PID": [2] },
      { "NAME": "Ingresso 3 - Tapparelle giorno", "NID": 3, "PID": [3] },
      { "NAME": "Ingresso 4 - Barriere notte", "NID": 4, "PID": [4] },
      { "NAME": "Ingresso 5 - Tapparelle notte", "NID": 5, "PID": [5] },
      { "NAME": "Ingresso 6 - Barriere giorno", "NID": 6, "PID": [2] }
    ],
    "cfgzone": [
      { "NAME": "Settore 1 - Ingresso", "NID": 1, "PID": [0] },
      { "NAME": "Settore 2 - Barriere giorno", "NID": 2, "PID": [0] },
      { "NAME": "Settore 3 - Tapparelle giorno", "NID": 3, "PID": [0] },
      { "NAME": "Settore 4 - Barriere notte", "NID": 4, "PID": [0] },
      { "NAME": "Settore 5 - Tapparelle notte", "NID": 5, "PID": [0] }
    ],
    "exsensor": [
      { "NAME": "Ingresso 1 - Ingresso", "NID": 1, "PID": [1] },
      { "NAME": "Ingresso 2 - ...", "NID": 2, "PID": [2] },
      { "NAME": "Ingresso 3 - Tapparelle giorno", "NID": 3, "PID": [3] },
      { "NAME": "Ingresso 4 - Barriere notte", "NID": 4, "PID": [4] },
      { "NAME": "Ingresso 5 - Tapparelle notte", "NID": 5, "PID": [5] },
      { "NAME": "Ingresso 6 - Barriere giorno", "NID": 6, "PID": [2] }
    ]
  },
  "result": "ACK",
  "title": "/spweco/filteredstructure.cgi"
}
```

## spweco/activate.cgi

### Request

- **POST**:
  - [*zone*]: Array of zone IDs

### Example

**Request**

```json
{
  "zone": [1]
}
```

**Response**

```json
{
  "result": "ACK",
  "title": "/spweco/activate.cgi"
}
```

## spweco/deactivate.cgi

### Request

- **POST**:
  - [*zone*]: Array of zone IDs

### Example

**Request**

```json
{
  "zone": [1]
}
```

**Response**

```json
{
  "result": "ACK",
  "title": "/spweco/deactivate.cgi"
}
```

## spweco/gethistory.cgi

### Request

- **POST**:
  - [*event*]: Number of events (0 for all??)
  - [*period*]: UNKNOWN (set at 0)

### Example

**Request**

```json
{
  "event": 0,
  "period": 1
}
```

**Response**

```json
{
  "data": [
    {
      "AREA": [],
      "CAT": 3,
      "CODE": "Disattivazione impianto",
      "DATE": { "DAY": 11, "HR": 18, "MIN": 0, "MT": 5, "SEC": 54, "YR": 19 },
      "DT": 3,
      "ID": 1,
      "NAME": "Tastiera 1 - KP 01",
      "USER": "Utente 3 - Jacopo",
      "ZONE": [
        "Settore 1 - Ingresso",
        "Settore 2 - Barriere giorno",
        "Settore 3 - Tapparelle giorno",
        "Settore 4 - Barriere notte",
        "Settore 5 - Tapparelle notte"
      ]
    },
    {
      "AREA": [],
      "CAT": 3,
      "CODE": "Codice valido",
      "DATE": { "DAY": 11, "HR": 18, "MIN": 0, "MT": 5, "SEC": 52, "YR": 19 },
      "DT": 3,
      "ID": 1,
      "NAME": "Tastiera 1 - KP 01",
      "USER": "Utente 3 - Jacopo",
      "ZONE": []
    },
    {
      "AREA": [],
      "CAT": 3,
      "CODE": "Attivazione impianto",
      "DATE": { "DAY": 11, "HR": 14, "MIN": 3, "MT": 5, "SEC": 42, "YR": 19 },
      "DT": 3,
      "ID": 1,
      "NAME": "Tastiera 1 - KP 01",
      "USER": "Utente 2 - Seve",
      "ZONE": [
        "Settore 1 - Ingresso",
        "Settore 2 - Barriere giorno",
        "Settore 3 - Tapparelle giorno",
        "Settore 4 - Barriere notte",
        "Settore 5 - Tapparelle notte"
      ]
    },
    {
      "AREA": [],
      "CAT": 3,
      "CODE": "Codice valido",
      "DATE": { "DAY": 11, "HR": 14, "MIN": 3, "MT": 5, "SEC": 40, "YR": 19 },
      "DT": 3,
      "ID": 1,
      "NAME": "Tastiera 1 - KP 01",
      "USER": "Utente 2 - Seve",
      "ZONE": []
    }
  ],
  "result": "ACK",
  "title": "/spweco/gethistory.cgi"
}
```

## spweco/access.cgi

Sets the user for the current session

### Request

- **POST**:
  - [*code*]: Authentication code

### Example

**Request**

```json
{
  "code": "..."
}
```

**Response**

```json
{
  "data": {
    "authlevel": 2,
    "userid": 4,
    "username": "Username"
  },
  "result": "ACK",
  "title": "/spweco/access.cgi"
}
```

## user/refresh.cgi

Checks if the user is still authenticated

### Request

- **GET**:
  - [*_*]: Time since epoc in ms (**Request Query Parameter**)

### Example

**Response**

```json
{
  "result": "ACK",
  "title": "/user/refresh.cgi"
}
```
