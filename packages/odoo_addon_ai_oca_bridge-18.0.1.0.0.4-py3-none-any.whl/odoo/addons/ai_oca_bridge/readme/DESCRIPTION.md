This module is used to create a bridge between Odoo and other AI systems like n8n.
