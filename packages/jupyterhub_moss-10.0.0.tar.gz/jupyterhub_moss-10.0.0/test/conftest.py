# Use jupyterhub's fixtures
pytest_plugins = "jupyterhub.tests.conftest"
