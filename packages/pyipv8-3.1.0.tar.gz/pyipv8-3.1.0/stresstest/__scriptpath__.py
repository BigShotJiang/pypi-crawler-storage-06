import pathlib
import sys

sys.path.insert(1, str(pathlib.Path(__file__, "..", "..").resolve()))
