class DHTError(Exception):
    """
    Generic error for DHT-related failures.
    """
