# Raw DOCX

Simple package to build on top of python-docx to assist in the handling of word documents

# Build

Build as a normal package

- Build with `python3 -m build --sdist --wheel`
- Upload to pypi.org using `twine upload dist/*`
