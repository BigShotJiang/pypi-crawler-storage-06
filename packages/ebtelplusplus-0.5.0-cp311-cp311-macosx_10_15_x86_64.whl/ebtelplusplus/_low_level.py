"""
Interface to the underlying C++ module
"""
from ._core import run

__all__ = ["run"]
