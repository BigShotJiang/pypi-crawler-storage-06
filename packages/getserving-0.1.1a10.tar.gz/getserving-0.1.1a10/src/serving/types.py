type JSON = dict | list | str | int | float | bool | None
type PlainText = str
type HTML = str
type Jinja2 = tuple[str, dict]
