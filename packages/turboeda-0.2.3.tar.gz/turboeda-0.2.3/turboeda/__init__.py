"""turboeda: One-command EDA report generator."""

from .eda_report import EDAReport  # noqa: F401

__all__ = ["EDAReport"]
