def main():
    print("Hello from ap2-sdk!")


if __name__ == "__main__":
    main()
