# Tasks scripts

See the `README.md` file for more information about these tasks.

These PowerShell `.ps1` scripts rely on implementation details in the `tasks/scripts`
directory. These are hidden when using the default VS Code settings provided by this
repository. If you need to see them, you can unhide them by changing
this setting in `.vscode/settings.json`.
