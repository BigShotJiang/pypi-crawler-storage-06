"""This file contains the environment variables for credentials."""

CLIENT_ID_PROD = "7t7snlnn801j8mjsf97eaart1s"
JWKS_URL_PROD = "https://cognito-idp.ap-northeast-1.amazonaws.com/ap-northeast-1_9TAMGx5NT/.well-known/jwks.json"
CLIENT_ID_DEV = "24nvfsrgbuvu75h4o8oj2c2oek"
JWKS_URL_DEV = "https://cognito-idp.ap-northeast-1.amazonaws.com/ap-northeast-1_1Y69fktA0/.well-known/jwks.json"

API_ENDPOINT_URL_PROD = "https://tf5tepcpn5bori46x5cyxh3ehe.appsync-api.ap-northeast-1.amazonaws.com/graphql"
API_ENDPOINT_URL_DEV = "https://jciqso7l7rhajfkt5s3dhybpcu.appsync-api.ap-northeast-1.amazonaws.com/graphql"
