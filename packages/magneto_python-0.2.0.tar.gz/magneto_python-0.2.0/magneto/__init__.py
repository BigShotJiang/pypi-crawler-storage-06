__version__ = "0.2.0"
# # To shortcut the import path
from magneto.magneto import Magneto