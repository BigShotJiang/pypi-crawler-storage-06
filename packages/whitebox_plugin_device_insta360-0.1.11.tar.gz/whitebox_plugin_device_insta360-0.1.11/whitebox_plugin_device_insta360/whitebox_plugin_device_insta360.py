from .plugin import (
    WhiteboxPluginDeviceInsta360,
    plugin_class,
)
