from bjpack.bjack import blackjack_game
def main():
    blackjack_game()
if __name__ == "__main__":
    main()
