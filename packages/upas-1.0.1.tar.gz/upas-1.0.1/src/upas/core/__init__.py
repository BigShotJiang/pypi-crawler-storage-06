"""
Core package for UPAS framework components.
"""
