"""
Reference:

- https://developers.notion.com/reference/block 
- https://developers.notion.com/reference/rich-text
"""

from .rich_text import *
from .block import *
