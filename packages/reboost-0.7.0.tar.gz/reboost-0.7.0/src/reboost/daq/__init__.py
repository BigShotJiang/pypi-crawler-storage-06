from __future__ import annotations

from .core import run_daq_non_sparse

__all__ = ["run_daq_non_sparse"]
