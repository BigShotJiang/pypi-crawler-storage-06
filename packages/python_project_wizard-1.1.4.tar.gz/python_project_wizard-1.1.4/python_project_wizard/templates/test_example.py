import unittest


class ExampleTestSuite(unittest.TestCase):
    def test_test(self):
        self.assertTrue(True)
