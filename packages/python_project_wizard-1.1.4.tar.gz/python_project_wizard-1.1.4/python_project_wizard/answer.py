from dataclasses import dataclass
from typing import Any


@dataclass
class Answer:
    value: Any
