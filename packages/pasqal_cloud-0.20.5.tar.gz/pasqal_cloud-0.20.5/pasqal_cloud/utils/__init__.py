"""
Misc utilities
"""
