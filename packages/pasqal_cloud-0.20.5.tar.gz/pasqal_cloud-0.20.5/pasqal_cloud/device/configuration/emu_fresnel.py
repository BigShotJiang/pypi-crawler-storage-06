from __future__ import annotations

from dataclasses import dataclass


@dataclass
class EmuFresnelConfig:
    """Configuration for the EMU_FRESNEL device type."""
