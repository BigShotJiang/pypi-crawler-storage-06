__version__ = '0.20.5'
deprecation_date = '2026-09-19'
