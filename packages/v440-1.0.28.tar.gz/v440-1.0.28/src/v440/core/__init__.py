from v440.core.Version import Version
from v440.core.VersionError import VersionError
