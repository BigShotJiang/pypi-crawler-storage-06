# TODO

- [x] Test the controllers
    - [x] `StaticController`
    - [x] `BinaryController`
- [ ] Test `RectangularWorldConfig` from yaml
- [ ] Try to fix the doc issue [`activating_others.rst:21`](https://github.com/kenblu24/RobotSwarmSimulator/blob/6eda9cb4d652c6b1adb9d06d25358875e9382a26/doc/source/guide/activating_others.rst?plain=1#L22)
- [ ] Test creating an agent from svg
- [ ] Check out world creation system [Link](https://github.com/kenblu24/RobotSwarmSimulator/discussions/16#discussioncomment-13542939)
- [ ] Check github workflow
