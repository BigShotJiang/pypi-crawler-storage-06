# VideoSDK Rime AI Plugin

Agent Framework plugin for TTS services from Rime.

## Installation

```bash
pip install videosdk-plugins-rime
```