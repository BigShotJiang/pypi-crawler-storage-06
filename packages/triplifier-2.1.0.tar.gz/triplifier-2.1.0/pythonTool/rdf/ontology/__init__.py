"""Ontology definitions for Python Triplifier."""
