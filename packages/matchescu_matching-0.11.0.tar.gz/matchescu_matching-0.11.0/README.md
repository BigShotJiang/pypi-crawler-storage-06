# matching
Common types and algorithms used for matching two information
