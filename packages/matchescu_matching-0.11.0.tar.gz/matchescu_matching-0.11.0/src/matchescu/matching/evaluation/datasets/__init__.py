from matchescu.matching.evaluation.datasets._magellan import MagellanDataset


__all__ = ["MagellanDataset"]
