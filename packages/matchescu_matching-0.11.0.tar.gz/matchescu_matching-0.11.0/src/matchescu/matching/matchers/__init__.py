from matchescu.matching.matchers.probabilistic.fs._matcher import FellegiSunter


__all__ = ["FellegiSunter"]
