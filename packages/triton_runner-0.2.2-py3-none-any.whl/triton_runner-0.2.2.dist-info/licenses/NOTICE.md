This project includes code from:

- Triton (MIT License): https://github.com/triton-lang/triton

  See LICENSE.triton for full license text.

- TritonBench (BSD 3-Clause License): https://github.com/pytorch-labs/tritonbench

  See LICENSE.tritonbench for full license text.
