#!/bin/bash
cd /home/rpm/claude/mcp-pdf-tools
exec uv run mcp-pdf-tools "$@"