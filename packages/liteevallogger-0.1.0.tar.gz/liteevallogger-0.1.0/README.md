# liteevallogger

A lightweight wrapper around Weave's EvaluationLogger.
