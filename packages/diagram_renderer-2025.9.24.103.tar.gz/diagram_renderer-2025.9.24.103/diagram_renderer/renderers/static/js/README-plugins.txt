This directory can include optional Mermaid external diagram plugins to enable
additional diagram types while remaining fully offline (no CDN):

- mermaid-xychart.min.js   (enables xychart-beta)
- mermaid-sankey.min.js    (enables sankey diagrams)

Place the UMD builds here. The renderer will auto-detect and register them at runtime.
