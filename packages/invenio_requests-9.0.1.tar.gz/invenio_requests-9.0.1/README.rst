..
    Copyright (C) 2021 CERN.

    Invenio-Requests is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

==================
 Invenio-Requests
==================

.. image:: https://github.com/inveniosoftware/invenio-requests/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-requests/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/inveniosoftware/invenio-requests.svg
        :target: https://github.com/inveniosoftware/invenio-requests/releases

.. image:: https://img.shields.io/pypi/dm/invenio-requests.svg
        :target: https://pypi.python.org/pypi/invenio-requests

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-requests.svg
        :target: https://github.com/inveniosoftware/invenio-requests/blob/master/LICENSE

Invenio module for generic and customizable requests.

TODO: Please provide feature overview of module

Further documentation is available on
https://invenio-requests.readthedocs.io/
