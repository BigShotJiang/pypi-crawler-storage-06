"""Top-level package for syncmodels."""

__author__ = """Asterio Gonzalez"""
__email__ = "asterio.gonzalez@gmail.com"
__version__ = "0.1.341"
