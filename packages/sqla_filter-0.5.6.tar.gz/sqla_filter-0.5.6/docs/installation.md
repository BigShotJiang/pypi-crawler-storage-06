# Installation

<!-- termynal -->

```
$ pip install sqla-filter
---> 100%
Installed
```
