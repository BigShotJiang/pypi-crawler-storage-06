# SQLAlchemy Filter

Package for convenient filtration and ordering functionality in SQLAlchemy

Quite often, optional filtration functionality is required. To facilitate the implementation of filtration functionality, this package was written

Features:

* filtration:
    * relationships
    * "or" filtration
    * manual filtration
* ordering
