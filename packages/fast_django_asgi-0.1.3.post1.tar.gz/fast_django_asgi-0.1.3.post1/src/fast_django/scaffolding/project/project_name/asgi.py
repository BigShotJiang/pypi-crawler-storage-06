from __future__ import annotations

from fast_django import Settings, create_app

app = create_app(Settings())
