#!/usr/bin/env python3
from __future__ import annotations

from fast_django.cli.main import app as cli

if __name__ == "__main__":
    cli()
