from __future__ import annotations

from .urls import router

__all__ = ["router"]
