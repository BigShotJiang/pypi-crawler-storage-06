"""distutils

Vendored from Python 3.11:

https://github.com/python/cpython/tree/3.11/Lib/distutils
"""
