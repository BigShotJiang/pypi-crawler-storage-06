# Copyright The Cloud Custodian Authors.
# SPDX-License-Identifier: Apache-2.0
from .csvout import report

__all__ = [report]
