class IssueError(Exception):
    pass
