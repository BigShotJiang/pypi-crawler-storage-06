"""
Feel The Agi AutoML Library.
"""

__version__ = "0.1.0"