from serializor.unicode.ser import serialize
from serializor.unicode.des import deserialize

__all__ = ["serialize", "deserialize"]
