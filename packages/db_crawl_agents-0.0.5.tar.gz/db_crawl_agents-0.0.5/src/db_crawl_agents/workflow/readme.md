keeps all the workflow that needs to be executed to end to end execute the crawlers


2 workflows
-> feature indentification human in loop workflow
-> feature decomposition workflow for dividing taks into multipel single cte tasks
-> validator workflow that validates and creates mire complex queries