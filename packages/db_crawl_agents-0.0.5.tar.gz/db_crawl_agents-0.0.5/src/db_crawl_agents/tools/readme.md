keeps all the llm tools that can be used by the llms to execute their tasks efficiently

-> need to implement a single tool called the rag executor so that I can get the relevant schemas from the database description tables

-> sql executor tool that can execute a query and give back a top view of the execution