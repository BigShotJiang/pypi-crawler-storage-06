this folder will keep all the input and output schemas for the project

