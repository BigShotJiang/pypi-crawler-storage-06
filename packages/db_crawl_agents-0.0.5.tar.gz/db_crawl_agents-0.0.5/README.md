# DB-CRAWL
LLM agentic database crawler


how to puild and deploy


 1. python -m build  
 2. twine upload dist/*