from django.apps import AppConfig


class HertzCaptchaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hertz_studio_django_captcha'
