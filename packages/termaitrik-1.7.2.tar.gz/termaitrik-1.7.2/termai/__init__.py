"""Top-level package for termai."""

__version__ = "1.7.2"

__all__ = ["__version__"]
