export default {
    lineColor: 'rgb(0,0,0)',
    lineWidth: 2,
    fillColor: 'rgba(0,0,0,0)'
};
