# NexusFlowMeter
A Network tool used for extracting flow data from PCAP file
