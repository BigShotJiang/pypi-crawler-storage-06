## v0.1.1rc47 (September 24, 2025)

Full Changelog: https://github.com/atlanhq/application-sdk/compare/v0.1.1rc46...v0.1.1rc47

### Bug Fixes

- partition columns defaults for daft write_parquet (#728) (by @Nishchith Shetty in [7ed4949](https://github.com/atlanhq/application-sdk/commit/7ed4949))
- Update ParquetOutput to handle file uploads correctly (#732) (by @Mustafa in [b4b2953](https://github.com/atlanhq/application-sdk/commit/b4b2953))
- CI build path (#733) (by @Nishchith Shetty in [6d04006](https://github.com/atlanhq/application-sdk/commit/6d04006))
