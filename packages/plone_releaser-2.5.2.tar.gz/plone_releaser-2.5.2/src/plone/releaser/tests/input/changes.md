Example MarkDown changelog from Products.CMFPlone package.

## 6.0.5rc1 (2023-05-25)


### Bug fixes:

- Do not truncate the sortable_title index
  [erral] #3690
- Fix password validation tests. [tschorr] #3784
- Updated metadata version to 6016.
  [maurits] #6016


### Internal:

- Update configuration files.
  [plone devs] 2a5f5557


## 6.0.4 (2023-04-24)


### Bug fixes:

- Prepare 6.0.4 final. No changes compared to the release candidate.
  [maurits] #604

