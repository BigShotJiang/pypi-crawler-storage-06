import pprint
import numpy as np


def model_sum_x(x):
    return np.sum(x)
