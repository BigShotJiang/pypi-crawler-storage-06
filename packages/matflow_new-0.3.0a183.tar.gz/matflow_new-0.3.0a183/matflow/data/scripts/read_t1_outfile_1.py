def read_t1_outfile_1(*args, **kwargs):
    return 1
