from gr_libs.tutorials.Draco.gcdraco_panda_tutorial import run_gcdraco_panda_tutorial
from gr_libs.tutorials.Draco.gcdraco_parking_tutorial import run_gcdraco_parking_tutorial


def test_gcdraco_panda_tutorial():
    run_gcdraco_panda_tutorial()


def test_gcdraco_parking_tutorial():
    run_gcdraco_parking_tutorial()
