from .format import recognizer_str_to_obj
