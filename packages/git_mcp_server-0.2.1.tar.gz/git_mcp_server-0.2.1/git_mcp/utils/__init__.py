"""Utility functions and helpers for git-mcp."""
