"""Platform adapters for different Git hosting services."""
