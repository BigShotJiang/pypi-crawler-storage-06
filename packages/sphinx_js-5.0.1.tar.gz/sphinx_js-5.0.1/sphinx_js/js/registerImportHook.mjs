import { register } from "node:module";

register("./importHooks.mjs", import.meta.url);
