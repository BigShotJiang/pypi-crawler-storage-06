```eval_rst
.. js:autofunction:: foo
```
