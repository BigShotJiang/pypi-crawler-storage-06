/**
 * Foo.
 */
function foo() {}
