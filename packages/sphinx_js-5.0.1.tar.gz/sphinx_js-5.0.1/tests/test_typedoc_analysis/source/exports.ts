export interface Blah {
  a: number;
  b: string;
}
