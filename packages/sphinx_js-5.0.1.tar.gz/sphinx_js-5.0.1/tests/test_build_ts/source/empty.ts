// Test that we don't crash on a file with no exports
