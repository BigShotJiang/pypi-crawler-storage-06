.. js:autoclass:: ClassDefinition
   :members:

   The link from the superclass in autoclass_class_with_interface_and_supers.rst will point here.

.. js:autoclass:: Interface
   :members:

   Same here.

.. js:autofunction:: weirdCodeInDescription
