.. js:autoclass:: OptionalThings
   :members:
