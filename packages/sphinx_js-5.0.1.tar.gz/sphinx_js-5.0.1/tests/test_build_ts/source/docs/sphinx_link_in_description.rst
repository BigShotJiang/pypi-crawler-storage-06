.. js:autofunction:: spinxLinkInDescription
