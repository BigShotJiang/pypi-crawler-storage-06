.. js:autoclass:: ClassDefinition
   :members: method1, *
