.. js:autoclass:: ConstructorlessClass
