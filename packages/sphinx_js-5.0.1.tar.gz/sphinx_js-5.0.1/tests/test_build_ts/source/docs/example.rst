.. js:autofunction:: exampleFunction
