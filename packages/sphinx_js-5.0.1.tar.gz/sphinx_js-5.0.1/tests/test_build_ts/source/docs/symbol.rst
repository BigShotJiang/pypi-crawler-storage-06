.. js:autoclass:: Iterable
   :members:
