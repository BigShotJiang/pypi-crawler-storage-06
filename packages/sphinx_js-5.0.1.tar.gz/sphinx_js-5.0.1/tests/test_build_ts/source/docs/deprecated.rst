.. js:autofunction:: deprecatedFunction1

.. js:autofunction:: deprecatedFunction2
