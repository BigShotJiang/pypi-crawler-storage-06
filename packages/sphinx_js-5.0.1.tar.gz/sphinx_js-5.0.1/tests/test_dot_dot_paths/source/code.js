/**
 * Bar function
 */
function bar(node) {}
