export class ClassA {
  constructor() {}

  /**
   * Here.
   */
  methodA() {}
}
