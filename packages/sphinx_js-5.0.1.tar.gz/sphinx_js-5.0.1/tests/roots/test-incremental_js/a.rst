module a
========

.. js:autoclass:: ClassA
