modules a and b
===============

.. js:autofunction:: ClassA#methodA
.. js:autofunction:: ClassB#methodB
