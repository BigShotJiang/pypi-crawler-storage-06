/**
 * Class doc.
 */
class ClassB {
  /**
   * Static.
   */
  static noUseOfThis() {}

  /**
   * Here.
   */
  methodB() {}
}
