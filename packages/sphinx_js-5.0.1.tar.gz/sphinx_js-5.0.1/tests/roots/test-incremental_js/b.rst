module b
========

.. js:autoclass:: ClassB
