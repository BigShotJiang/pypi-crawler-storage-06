/**
 * Class doc.
 */
class ClassA {
  /**
   * Static.
   */
  static noUseOfThis() {}

  /**
   * Here.
   */
  methodA() {}
}
