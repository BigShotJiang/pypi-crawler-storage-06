from pytest import register_assert_rewrite

register_assert_rewrite("tests.testing")
