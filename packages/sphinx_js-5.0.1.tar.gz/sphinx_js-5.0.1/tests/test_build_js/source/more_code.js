// This file is processed after code.js and so tends to shadow things.

/** Another thing named shadow, to threaten to shadow the one in code.js */
function shadow() {}
