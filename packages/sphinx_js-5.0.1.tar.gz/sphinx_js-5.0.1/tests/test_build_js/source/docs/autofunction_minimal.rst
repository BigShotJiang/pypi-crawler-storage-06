.. js:autofunction:: linkDensity
