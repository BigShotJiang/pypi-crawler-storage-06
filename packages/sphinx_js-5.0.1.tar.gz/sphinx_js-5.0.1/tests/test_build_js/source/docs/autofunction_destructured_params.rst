.. js:autofunction:: destructuredParams
