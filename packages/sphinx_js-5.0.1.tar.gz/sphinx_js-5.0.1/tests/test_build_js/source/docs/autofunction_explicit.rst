.. js:autofunction:: linkDensity(snorko, borko[, forko])

   Things are ``neat``.

   Off the beat.

   * Sweet
   * Fleet
