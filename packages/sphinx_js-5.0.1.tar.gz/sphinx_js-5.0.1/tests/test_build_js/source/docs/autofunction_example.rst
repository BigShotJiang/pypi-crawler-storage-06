.. js:autofunction:: exampleTag
