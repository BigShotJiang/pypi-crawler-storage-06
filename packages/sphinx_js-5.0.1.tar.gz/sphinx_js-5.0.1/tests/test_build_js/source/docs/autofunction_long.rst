.. js:autofunction:: ContainingClass#someMethod
