.. js:autofunction:: more_code.shadow
