Make sure we don't have KeyErrors on naked, memberless objects labeled as classes:

.. js:autoclass:: NoParamnames
