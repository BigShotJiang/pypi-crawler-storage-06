.. js:autoclass:: NonAlphabetical
   :members:
