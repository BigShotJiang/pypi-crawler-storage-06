.. js:autoclass:: ClosedClass
   :members:
   :exclude-members: publical2, publical3
