.. js:autoclass:: ContainingClass
   :members: bar, *, someMethod
