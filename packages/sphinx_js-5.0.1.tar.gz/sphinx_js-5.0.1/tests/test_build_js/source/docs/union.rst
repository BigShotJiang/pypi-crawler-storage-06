.. js:autofunction:: union
