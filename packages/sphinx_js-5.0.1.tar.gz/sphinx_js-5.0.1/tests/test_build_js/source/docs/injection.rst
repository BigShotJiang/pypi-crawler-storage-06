.. js:autofunction:: injection
