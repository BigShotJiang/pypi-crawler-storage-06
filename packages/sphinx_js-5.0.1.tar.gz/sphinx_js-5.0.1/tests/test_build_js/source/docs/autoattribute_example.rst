.. js:autoattribute:: ExampleAttribute
