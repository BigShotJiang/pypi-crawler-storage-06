.. js:autofunction:: defaultsDocumentedInCode
