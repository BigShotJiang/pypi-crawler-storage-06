.. js:autoattribute:: ContainingClass#bar
