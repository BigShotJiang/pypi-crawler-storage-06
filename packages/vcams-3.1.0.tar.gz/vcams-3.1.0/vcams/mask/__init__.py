"""Various masks to be used for manipulating VoxelPart objects."""

from . import function, image, random, shape, tpms
