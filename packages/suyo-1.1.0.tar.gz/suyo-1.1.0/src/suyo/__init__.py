"""suyo

Essential helper package for HamzaGSopp projects.
"""

from .core import greet, init

__all__ = ["greet", "init"]

__author__ = "HamzaGSopp"
__version__ = "1.1.0"
