from sqlalchemy.orm import DeclarativeBase


class MetricsBase(DeclarativeBase):
    pass
