import enum


class DataItemStatus(str, enum.Enum):
    DATA_ITEM_PROCESSING_COMPLETED = "DATA_ITEM_PROCESSING_COMPLETED"
