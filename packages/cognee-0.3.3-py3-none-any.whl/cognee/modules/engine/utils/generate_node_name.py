def generate_node_name(name: str) -> str:
    return name.lower().replace("'", "")
