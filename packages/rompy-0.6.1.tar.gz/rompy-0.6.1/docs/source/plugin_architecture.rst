======
Models
======


.. toctree::
   :maxdepth: 1

   plugin_architecture/execution.rst
