=======================
Demonstration notebooks
=======================


Thumbnails gallery
------------------

.. nbgallery::

    notebooks/demo.ipynb
    notebooks/templates_demo.ipynb
    notebooks/swan/example_declarative.ipynb
    notebooks/swan/example_procedural.ipynb
    notebooks/swan/example_sensitivity.ipynb
    notebooks/oceanum_example.ipynb
    notebooks/swan-config-components.ipynb
    notebooks/physics.ipynb
    notebooks/schism_procedural.ipynb
