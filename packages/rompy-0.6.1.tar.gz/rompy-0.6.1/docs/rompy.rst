rompy package
=============

Submodules
----------

rompy.cli module
----------------

.. automodule:: rompy.cli
   :members:
   :undoc-members:
   :show-inheritance:

rompy.core module
-----------------

.. automodule:: rompy.core
   :members:
   :undoc-members:
   :show-inheritance:

rompy.data module
-----------------

.. automodule:: rompy.data
   :members:
   :undoc-members:
   :show-inheritance:

rompy.filesystem module
-----------------------

.. automodule:: rompy.filesystem
   :members:
   :undoc-members:
   :show-inheritance:

rompy.filters module
--------------------

.. automodule:: rompy.filters
   :members:
   :undoc-members:
   :show-inheritance:

rompy.intake module
-------------------

.. automodule:: rompy.intake
   :members:
   :undoc-members:
   :show-inheritance:

rompy.model module
------------------

.. automodule:: rompy.model
   :members:
   :undoc-members:
   :show-inheritance:

rompy.plotting module
---------------------

.. automodule:: rompy.plotting
   :members:
   :undoc-members:
   :show-inheritance:

rompy.swan module
-----------------

.. automodule:: rompy.swan
   :members:
   :undoc-members:
   :show-inheritance:

rompy.transform module
----------------------

.. automodule:: rompy.transform
   :members:
   :undoc-members:
   :show-inheritance:

rompy.types module
------------------

.. automodule:: rompy.types
   :members:
   :undoc-members:
   :show-inheritance:

rompy.utils module
------------------

.. automodule:: rompy.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: rompy
   :members:
   :undoc-members:
   :show-inheritance:
