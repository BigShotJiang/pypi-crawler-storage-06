"""
Test package for ROMPY.

This package contains all the test modules for the ROMPY project.
"""

# This file makes the tests directory a proper Python package
# This helps with test discovery and imports
