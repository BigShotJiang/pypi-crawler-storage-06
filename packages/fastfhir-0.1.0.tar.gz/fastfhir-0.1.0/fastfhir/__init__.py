# fastfhir/__init__.py
from .models import *
from .helpers import *
from .validation import validate_resource

__version__ = "0.1.0"
