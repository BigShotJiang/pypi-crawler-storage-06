# FastFHIR
🚀 FastFHIR: A FastAPI + FHIR toolkit (work in progress).

This is a placeholder release to reserve the PyPI name.
