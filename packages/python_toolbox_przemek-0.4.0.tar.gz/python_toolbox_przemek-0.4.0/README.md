# Python Toolbox Przemek
I want to provide basic tools for my day-to-day work.

## Basic usage
```
pip install "python-toolbox-przemek[debug,nvim]"
```
