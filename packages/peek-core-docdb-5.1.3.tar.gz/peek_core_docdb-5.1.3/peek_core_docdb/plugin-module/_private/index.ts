export { DocumentResultI } from "./document-loader/PrivateDocumentLoaderService";

export { SettingPropertyTuple } from "./admin/SettingPropertyTuple";
export { AdminStatusTuple } from "./admin/AdminStatusTuple";
export * from "./PluginNames";

export { DocDbTupleService } from "./DocDbTupleService";
