from Zope2 import DB


DB.pack()
