# MCP Hacker News Server

<!-- MCP name: io.github.YinTokey/mcp_hackernews -->

A minimal MCP server that exposes a tool to search top Hacker News stories.

mcp-name: io.github.YinTokey/mcp_hackernews
