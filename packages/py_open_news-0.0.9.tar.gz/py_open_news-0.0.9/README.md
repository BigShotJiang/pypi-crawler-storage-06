# open-news
Get news data


### Develop
## Branch
1. main -> Need PR. Push it to release which will trigger version tagging and deploy 
2. Others are all feature branch
