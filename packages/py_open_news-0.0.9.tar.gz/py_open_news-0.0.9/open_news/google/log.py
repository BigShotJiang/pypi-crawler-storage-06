import logging


logger = logging.getLogger("open-news")
