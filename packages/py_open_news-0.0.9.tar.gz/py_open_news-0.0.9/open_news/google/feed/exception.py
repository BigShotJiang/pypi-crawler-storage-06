class WrongNewsXML_FormatError(RuntimeError):
    pass