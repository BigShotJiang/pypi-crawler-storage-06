from arraying.core import *
from arraying.tests import *

if __name__ == "__main__":
    main()
