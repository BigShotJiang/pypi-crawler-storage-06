========
arraying
========

Overview
--------

arraying

Installation
------------

To install ``arraying``, you can use ``pip``. Open your terminal and run:

.. code-block:: bash

    pip install arraying

License
-------

This project is licensed under the MIT License.

Links
-----

* `Download <https://pypi.org/project/arraying/#files>`_
* `Index <https://pypi.org/project/arraying/>`_
* `Source <https://github.com/johannes-programming/arraying/>`_

Credits
-------

* Author: Johannes
* Email: `johannes.programming@gmail.com <mailto:johannes.programming@gmail.com>`_

Thank you for using ``arraying``!