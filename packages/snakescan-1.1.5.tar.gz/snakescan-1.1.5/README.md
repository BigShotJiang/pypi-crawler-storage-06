Description
-------------------
Simple Scanner to scan port.
Example:
import SnakeScan
and use module to scan port 
if him not run install in pip art,tqdm,termcolor and run
added new single search enter example:
[$]Port/Skip--> --s 50
 