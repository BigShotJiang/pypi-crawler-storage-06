__author__ = "Viktor van der Valk"
__email__ = "v.o.van_der_valk@lumc.nl"

__version__ = "0.2.2"


def get_module_version():
    return __version__
