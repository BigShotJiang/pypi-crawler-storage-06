# Smart Money Concepts

A Python package for performing Smart Money Concepts (SMC) technical analysis using yfinance data.

## Installation

```bash
pip install smart-money-concepts