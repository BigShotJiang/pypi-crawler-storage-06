import enum


class ArtifactRegistryType(enum.StrEnum):
    HUGGINGFACE = "huggingface"
    RESERVOIR = "reservoir"
