from __future__ import absolute_import, division, print_function

from applitools.common.protocol import USDKProtocol

from .__version__ import __version__


class Images(USDKProtocol):
    SDK_INFO = "eyes-images", __version__
