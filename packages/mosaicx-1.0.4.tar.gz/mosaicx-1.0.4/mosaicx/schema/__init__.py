"""
MOSAICX Schema Storage Module

This module contains generated schemas in JSON and Python formats.
"""
