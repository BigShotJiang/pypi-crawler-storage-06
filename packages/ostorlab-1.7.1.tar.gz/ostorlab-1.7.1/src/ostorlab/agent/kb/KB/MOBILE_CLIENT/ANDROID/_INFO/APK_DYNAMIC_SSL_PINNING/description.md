List of all TLS Pinning methods used in the application.
