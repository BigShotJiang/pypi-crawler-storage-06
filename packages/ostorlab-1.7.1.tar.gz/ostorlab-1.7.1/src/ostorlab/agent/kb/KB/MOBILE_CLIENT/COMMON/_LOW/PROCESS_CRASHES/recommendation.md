To securely addresses exceptions and crashes in the application:

* Catch all the errors and handle them correctly
* Validate the type and the length of all the inputs
* Do not generate logs or throw errors containing personal information