List of all Hash methods used in the application.
