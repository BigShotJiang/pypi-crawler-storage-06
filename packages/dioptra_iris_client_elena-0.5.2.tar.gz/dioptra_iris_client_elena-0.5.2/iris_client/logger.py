import logging

logger = logging.getLogger("iris-client")
