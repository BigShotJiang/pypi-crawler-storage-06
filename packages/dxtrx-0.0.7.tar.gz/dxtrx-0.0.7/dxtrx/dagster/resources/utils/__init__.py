"""Dagster-adjacent utilities for dxtrx.

This package contains helper utilities used by Dagster resources, such as
DuckDB extension management and catalog injection SPI implementations.
"""


