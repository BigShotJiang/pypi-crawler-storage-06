"""Client functionality for nbdev-squ package."""

__all__ = ["foo"]


def foo():
    pass
