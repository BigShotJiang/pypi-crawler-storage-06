nima.generat
------------

.. automodule:: nima.generat
