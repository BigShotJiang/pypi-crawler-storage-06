When installing the module, all the existing ticket lines with 0 price recomputes
their invoice status, so in a huge DB it may take some time.
