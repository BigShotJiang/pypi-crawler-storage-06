This module avoids that the sales orders containing only event tickets lines with 0
price appear as invoiceable, making the "to invoice" list very dirty.
