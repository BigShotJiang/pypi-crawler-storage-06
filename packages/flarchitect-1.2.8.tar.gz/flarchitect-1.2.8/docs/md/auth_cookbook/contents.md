[← Back to Auth Cookbook index](index.md)

# Contents
- JWT patterns (HS256 and RS256, refresh, rotation)
- Basic authentication
- API key strategies (lookup function vs. hashed field)
- Role mapping examples (decorators and config‑driven)
- Multi‑tenant considerations (claims, scoping, isolation)

