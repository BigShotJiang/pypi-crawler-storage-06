"""another fidesops remote merge

Revision ID: 25adddf820a3
Revises: 7b81d34352e8, 97801300fedd
Create Date: 2022-08-24 10:40:25.875324

"""

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "25adddf820a3"
down_revision = ("7b81d34352e8", "97801300fedd")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
