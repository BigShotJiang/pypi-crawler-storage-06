import papermodels


def test_first_test():
    assert True
