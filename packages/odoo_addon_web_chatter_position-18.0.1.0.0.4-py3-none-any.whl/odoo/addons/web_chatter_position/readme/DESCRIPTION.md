Configurable chatter position from the user preferences.

Supports Both Community & Enterprise Edition.
