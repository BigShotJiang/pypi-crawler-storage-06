# deprecated way of importing:
from .parameters import WithPersistentParameters  # noqa F401
