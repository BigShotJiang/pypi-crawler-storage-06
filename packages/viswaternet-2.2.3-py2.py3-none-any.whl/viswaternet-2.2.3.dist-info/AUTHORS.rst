=======
Credits
=======

Development Lead
----------------

Tyler Trimble (TylerL.Trimble@gmail.com)
    Software, Methodology, Validation 

Meghna Thomas (meghnathomas@utexas.edu)
    Software, Methodology, Writing - Original Draft

Lina Sela (linasela@utexas.edu) 
    Conceptualization, Supervision, Funding acquisition, Writing - Review & Editing

Contributors
------------
This package is being developed and supported by the `WATSUP`_ group at UT Austin.

.. _`WATSUP`: https://sites.utexas.edu/selalina/
