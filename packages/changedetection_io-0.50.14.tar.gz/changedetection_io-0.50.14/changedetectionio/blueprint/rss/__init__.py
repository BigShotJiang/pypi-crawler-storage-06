RSS_FORMAT_TYPES = [('plaintext', 'Plain text'), ('html', 'HTML Color')]
