from nekro_agent.schemas.signal import MsgSignal

__all__ = [
    "MsgSignal",
]
