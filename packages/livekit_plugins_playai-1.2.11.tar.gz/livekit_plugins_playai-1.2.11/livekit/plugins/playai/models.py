from typing import Literal

TTSModel = Literal["Play3.0-mini", "PlayDialog", "PlayDialog-turbo"]
