from fabricks.core.jobs.base.processor import Processor


class BaseJob(Processor):
    pass
