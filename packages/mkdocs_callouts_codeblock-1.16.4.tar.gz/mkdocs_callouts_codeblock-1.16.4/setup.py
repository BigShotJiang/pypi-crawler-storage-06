from setuptools import setup

# Fake reference so GitHub still considers it a real package.
setup(name="mkdocs-callouts-codeblock")
