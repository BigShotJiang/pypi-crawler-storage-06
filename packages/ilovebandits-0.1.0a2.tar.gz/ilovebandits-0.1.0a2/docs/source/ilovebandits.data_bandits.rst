ilovebandits.data\_bandits package
==================================

Submodules
----------

ilovebandits.data\_bandits.base module
--------------------------------------

.. automodule:: ilovebandits.data_bandits.base
   :members:
   :undoc-members:
   :show-inheritance:

ilovebandits.data\_bandits.utils module
---------------------------------------

.. automodule:: ilovebandits.data_bandits.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ilovebandits.data_bandits
   :members:
   :undoc-members:
   :show-inheritance:
