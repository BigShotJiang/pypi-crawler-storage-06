ilovebandits.mab package
========================

Submodules
----------

ilovebandits.mab.agents module
------------------------------

.. automodule:: ilovebandits.mab.agents
   :members:
   :undoc-members:
   :show-inheritance:

ilovebandits.mab.q\_estimators module
-------------------------------------

.. automodule:: ilovebandits.mab.q_estimators
   :members:
   :undoc-members:
   :show-inheritance:

ilovebandits.mab.utils module
-----------------------------

.. automodule:: ilovebandits.mab.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ilovebandits.mab
   :members:
   :undoc-members:
   :show-inheritance:
