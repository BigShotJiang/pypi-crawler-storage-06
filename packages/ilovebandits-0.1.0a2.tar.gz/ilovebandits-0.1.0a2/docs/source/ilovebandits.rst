ilovebandits package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   ilovebandits.data_bandits
   ilovebandits.mab

Submodules
----------

ilovebandits.agents module
--------------------------

.. automodule:: ilovebandits.agents
   :members:
   :undoc-members:
   :show-inheritance:

ilovebandits.sim module
-----------------------

.. automodule:: ilovebandits.sim
   :members:
   :undoc-members:
   :show-inheritance:

ilovebandits.utils module
-------------------------

.. automodule:: ilovebandits.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ilovebandits
   :members:
   :undoc-members:
   :show-inheritance:
