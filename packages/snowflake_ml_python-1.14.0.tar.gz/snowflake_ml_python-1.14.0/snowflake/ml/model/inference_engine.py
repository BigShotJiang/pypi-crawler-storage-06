import enum


class InferenceEngine(enum.Enum):
    VLLM = "vllm"
