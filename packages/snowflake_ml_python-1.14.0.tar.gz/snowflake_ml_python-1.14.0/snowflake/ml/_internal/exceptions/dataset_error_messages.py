DATASET_ALREADY_EXISTS = "Dataset {} already exists."
DATASET_VERSION_ALREADY_EXISTS = "Dataset {} version {} already exists."

DATASET_NOT_EXIST = "Dataset {} does not exist or is inaccessible."
DATASET_VERSION_NOT_EXIST = "Dataset {} version '{}' does not exist or is inaccessible."
