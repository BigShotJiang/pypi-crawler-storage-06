vocab for transcription

example dir

adjust the way the quit button works

init

PyPI, uvx

Electron/Tauri

fully private mode that uses a local model for the LLM questioning.

multi-platform

headings delimiter for multi-line
