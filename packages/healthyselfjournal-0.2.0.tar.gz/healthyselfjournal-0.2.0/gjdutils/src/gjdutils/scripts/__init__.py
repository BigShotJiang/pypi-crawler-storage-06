"""Scripts package for gjdutils."""

from .install import install_export_envs

__all__ = ["install_export_envs"]
