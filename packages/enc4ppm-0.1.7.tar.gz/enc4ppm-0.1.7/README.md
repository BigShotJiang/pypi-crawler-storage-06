# enc4ppm

Encode data for predictive process monitoring

## Installation

```bash
pip install enc4ppm
```

## Usage

```python
import enc4ppm
# ...
```

## Development

### Documentation

Documentation is provided by mkdocs. To build and push the documentation website to GitHub, run the following command: `mkdocs gh-deploy`.

## License

MIT License
