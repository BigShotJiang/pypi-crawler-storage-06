# TeDS Report

- Tool: teds 0.1.dev13+g9e84ef6db.d20250920 (spec supported: 1.0-1.0; recommended: 1.0)

## /Users/yaccob/repos/github.com/yaccob/contest/tests/cases/format_divergence/spec.yaml




### Schemas

- schema.yaml#/components/schemas/Email
  - valid: 1 cases
  - invalid: 1 cases
