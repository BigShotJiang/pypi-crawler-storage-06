def show_message():
    print("This function is within the id-mlip package installed from PyPI ! version 0.7")