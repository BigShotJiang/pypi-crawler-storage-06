from django.contrib import admin
from django.urls.conf import path

urlpatterns = [path(r"admin/", admin.site.urls)]
