# -*- coding: utf-8 -*-
# This package exposes translation files for Frappe's translation loader.
