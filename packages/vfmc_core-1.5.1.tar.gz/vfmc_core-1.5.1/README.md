This directory contains Rust code that binds the cubelib code to the VFMC python code.

To compile:
```
maturin develop --target <arch>
```
Where `<arch>` is either `aarch64-apple-darwin` or `something`
