"""Packaged default configuration and templates for CopyCat."""
