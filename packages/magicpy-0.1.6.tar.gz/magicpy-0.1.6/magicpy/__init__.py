from .magicpy import MagVenture
from .utils import *
from .stimulator import *
from .devices import *

__version__ = "0.1.6"
