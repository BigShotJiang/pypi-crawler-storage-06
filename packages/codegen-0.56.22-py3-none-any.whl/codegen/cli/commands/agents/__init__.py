"""Agents command module."""
