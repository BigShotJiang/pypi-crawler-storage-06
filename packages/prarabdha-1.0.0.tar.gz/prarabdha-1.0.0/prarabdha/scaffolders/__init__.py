"""
Scaffolder modules for different programming languages and frameworks.
"""
