# climdata/__main__.py
from .main import run

if __name__ == "__main__":
    run()