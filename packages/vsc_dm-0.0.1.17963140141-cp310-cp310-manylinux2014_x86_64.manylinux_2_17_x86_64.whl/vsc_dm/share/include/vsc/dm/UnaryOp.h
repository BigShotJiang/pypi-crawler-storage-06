/*
 * UnaryOp.h
 *
 *  Created on: Oct 29, 2021
 *      Author: mballance
 */

#pragma once

namespace vsc {
namespace dm {

enum class UnaryOp {
	Not,
    Ptr // Convert the argument to a pointer
};

}
}




