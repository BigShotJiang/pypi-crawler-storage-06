
#pragma once
#include "vsc/dm/IFactory.h"

extern "C" vsc::dm::IFactory *vsc_dm_getFactory();

