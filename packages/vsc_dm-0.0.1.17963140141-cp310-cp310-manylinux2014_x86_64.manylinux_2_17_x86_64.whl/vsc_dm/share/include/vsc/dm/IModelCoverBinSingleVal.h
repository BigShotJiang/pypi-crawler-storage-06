
#pragma once
#include "vsc/dm/IModelCoverBin.h"

namespace vsc {
namespace dm {

class IModelCoverBinSingleVal : public virtual IModelCoverBin {
public:

    virtual ~IModelCoverBinSingleVal() { }

};

}
}

