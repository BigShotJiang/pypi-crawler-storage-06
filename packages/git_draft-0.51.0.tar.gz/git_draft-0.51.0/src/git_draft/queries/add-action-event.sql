insert into action_events (prompt_id, occurred_at, class, data)
  values (:prompt_id, :occurred_at, :class, :data)
