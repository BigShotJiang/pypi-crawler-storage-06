# Makes the 'color' directory a Python package so it is included in wheels
