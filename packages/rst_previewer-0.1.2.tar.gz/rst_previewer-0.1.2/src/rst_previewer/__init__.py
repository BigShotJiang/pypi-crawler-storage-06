"""A modern CLI and web-based viewer for reStructuredText files."""

__version__ = "0.1.0"
