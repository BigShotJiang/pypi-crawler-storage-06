from .downloader import (
    aio,
    fbdown,
    igdl,
    ttdl,
    twitter,
    youtube,
    mediafire,
    capcut,
    gdrive,
    pinterest
)

__version__ = "4.0.15"