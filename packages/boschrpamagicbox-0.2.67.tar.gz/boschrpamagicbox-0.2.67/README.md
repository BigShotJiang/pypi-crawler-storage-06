# BoschRpaMagicBox

This package is used for building common automation functions for sap web gui within Bosch