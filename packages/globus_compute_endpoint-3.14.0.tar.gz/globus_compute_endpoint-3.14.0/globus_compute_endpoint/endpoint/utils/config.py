# Needed for backwards compatibility
from globus_compute_endpoint.endpoint.config import Config  # noqa: F401
