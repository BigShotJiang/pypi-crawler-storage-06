This module allows users to set non-official names for partners in the
search_alias field, improving search usability by enabling searches
using alternative names. This is particularly useful for partners known
by multiple names.

The search_alias field is added to the form view after the reference
field.
