from enum import Enum

class DeploymentDownloadType(Enum):
    SOURCE = "source"
    OUTPUT = "output"
