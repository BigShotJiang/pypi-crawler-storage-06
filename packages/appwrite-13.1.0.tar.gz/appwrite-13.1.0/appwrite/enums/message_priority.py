from enum import Enum

class MessagePriority(Enum):
    NORMAL = "normal"
    HIGH = "high"
