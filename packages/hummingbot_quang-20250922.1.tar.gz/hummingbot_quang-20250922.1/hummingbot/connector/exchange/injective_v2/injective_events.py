from enum import Enum


class InjectiveEvent(int, Enum):
    ChainTransactionEvent = 9999
