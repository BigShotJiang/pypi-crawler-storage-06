set_ca_certs() -> None

Load ca certs from provided unicode string.

Note that certificates will be added only when cURL starts new connection.
