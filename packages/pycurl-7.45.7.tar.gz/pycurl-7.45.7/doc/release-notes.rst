.. include:: ../RELEASE-NOTES.rst
