.. _curlshareobject:

CurlShare Object
================

.. autoclass:: pycurl.CurlShare

    CurlShare objects have the following methods:

    .. automethod:: pycurl.CurlShare.close

    .. automethod:: pycurl.CurlShare.setopt
