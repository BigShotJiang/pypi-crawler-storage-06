def bool_or_default(obj,default=True):
    if obj == None:
        obj =  default
    return obj
