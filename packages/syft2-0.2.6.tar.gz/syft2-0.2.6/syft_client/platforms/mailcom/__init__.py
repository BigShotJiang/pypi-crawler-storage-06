"""Mail.com platform implementation"""

from .client import MailcomClient

__all__ = ['MailcomClient']