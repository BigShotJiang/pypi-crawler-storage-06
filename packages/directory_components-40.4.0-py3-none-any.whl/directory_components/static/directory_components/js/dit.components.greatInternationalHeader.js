$(document).ready(function() {
  dit.components.countrySelector.init();
  dit.components.languageSelectorDropdown.init();
});
