def topics():
    return [
        "login_page",
        "color_grid",
        "php_addition_api",
        "navigator_main",
        "named_route_navigation"
    ]
