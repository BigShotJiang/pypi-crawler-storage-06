from pydantic.fields import FieldInfo


class TopicSegment(FieldInfo):
    pass
