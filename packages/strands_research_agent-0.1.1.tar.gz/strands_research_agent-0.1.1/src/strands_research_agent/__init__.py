"""Strands Research Agent - Advanced AI Research Agent powered by Strands Agents framework."""

from .agent import main

__version__ = "1.0.0"
__all__ = ["main"]
